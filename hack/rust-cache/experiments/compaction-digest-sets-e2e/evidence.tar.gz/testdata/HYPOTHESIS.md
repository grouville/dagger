# Full-listing impact of compaction digest-set reuse

The standalone patch on main reduces allocation in the compaction component by 17.7%; the larger case's write-lock hold is 471.71 -> 441.04 ms, faster in 4/4 pairs. This does not yet establish a command improvement.

The controlled engine keeps both original and candidate digest-set loops verbatim, selected once per compaction. Every other unselected feature stays off. Four fixed alternating pairs use the same original selected Go module, a fresh CLI and fresh source comment per command, the same warm engine/volume, normal GC, telemetry and cleanup. An excluded initialization pair adds one real test (4399), and measured pairs remove it (4398). Every ordered row and successful exit is checked. Recording and profiling stay off during timing; no observations are excluded because they overlap maintenance. All source/configuration and mode changes are restored.

After the cohort, use a separate recorded diagnostic to measure actual compaction frequency, duration and lock contention. Do not infer those from component times or force a collection to obtain a favorable comparison. No repeated cohort is planned to seek better results.
