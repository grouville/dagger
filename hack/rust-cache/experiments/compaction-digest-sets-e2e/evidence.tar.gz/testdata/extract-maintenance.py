from pathlib import Path
from datetime import datetime, timezone
import json
import re
import subprocess

p = Path(__file__).parent
samples = json.loads((p / 'full-command-paired/samples.json').read_text())
messages = ['dagql collection checked eq classes', 'dagql prune compacted eq classes',
            'dagql metadata prune finished']
keys = ['compacted', 'oldSlots', 'newSlots', 'duration', 'triggered',
        'maximumEstimatedBytes', 'targetEstimatedBytes',
        'beforeEstimatedBytes', 'beforeResults', 'beforeTerms', 'beforeClassSlots',
        'afterInitialCompactionEstimatedBytes', 'afterInitialCompactionResults',
        'afterInitialCompactionTerms', 'afterInitialCompactionClassSlots',
        'afterPruneEstimatedBytes', 'afterPruneResults', 'afterPruneTerms',
        'afterPruneClassSlots', 'initialCompactionOldClassSlots',
        'initialCompactionNewClassSlots', 'finalCompactionOldClassSlots',
        'finalCompactionNewClassSlots', 'candidateCount', 'plannedRootCount',
        'removedPersistedRootCount', 'droppedValues', 'candidatesExhausted']
command = ['timeout', '15s', 'docker', 'logs', '--tail', '50000', '--timestamps', '--since', str(samples[0]['unix_start']),
           '--until', str(samples[-1]['unix_end']), 'dagger-rust-parser-state-pool-oct14']
rows = []
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
for raw in process.stdout:
    line = re.sub(r'\x1b\[[0-9;]*m', '', raw)
    message = next((msg for msg in messages if msg in line), None)
    if message is None:
        continue
    timestamp = line.split()[0]
    try:
        unix = datetime.fromisoformat(timestamp.replace('Z', '+00:00')).timestamp()
    except ValueError:
        continue
    row = dict(timestamp=timestamp, message=message)
    for key in keys:
        match = re.search(r'\b' + re.escape(key) + r'(?:=|\"\s*:\s*)\"?([0-9.a-zµ-]+)', line)
        if match:
            row[key] = match[1]
    row['command_overlap'] = [r['label'] for r in samples if r['unix_start'] <= unix <= r['unix_end']]
    rows.append(row)
exit_code = process.wait()
(p / 'maintenance-during-cohort.json').write_text(json.dumps(dict(command=command, exit_code=exit_code, rows=rows, bounded_tail_lines=50000), indent=2) + '\n')
for sample in samples:
    events = [r for r in rows if sample['label'] in r['command_overlap']]
    print(json.dumps(dict(label=sample['label'], events=events)))
