from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

protocol = Path('/tmp/rust-cache-sipsma-review/rust-go-test-collections/measure.py')
exec(protocol.read_text().split('fixtures = [f for f')[0])
p = Path(__file__).parent
workspace = Path('/tmp/dagger-go-real-repository-main')
module = Path('/tmp/dagger-go-module-test-name-index')
cli = base / 'filesync-literal-pathwalk/dagger-after'
source = workspace / 'dagql/types.go'
original = source.read_bytes()
configs = {name: (workspace / name).read_bytes() if (workspace / name).exists() else None
           for name in ['dagger.toml', 'dagger.lock']}
routes = ['batch-metadata', 'attribute-array-decode', 'reusable-declarations',
          'span-lookup-fanout', 'usage-sampling', 'builtin-receivers',
          'config-declarations', 'trivial-scalar-fields', 'direct-span-protobuf',
          'span-resource-batches', 'lazy-type-maps', 'telemetry-flush-coalescing',
          'callback-caller-reuse', 'otel-evicted-queue', 'single-toml-parse',
          'parallel-client-admission', 'prepared-schema', 'restored-posting-removal',
          'scalar-list-projection', 'upstream-leaf-arrays', 'native-search-projection',
          'restored-data-list-projection', 'span-row-sharing',
          'interface-field-snapshots', 'metric-flush-pruning', 'compaction-digest-sets']
selected = ['batch-metadata', 'attribute-array-decode', 'reusable-declarations',
            'span-lookup-fanout', 'usage-sampling', 'builtin-receivers',
            'config-declarations', 'trivial-scalar-fields', 'scalar-list-projection',
            'restored-posting-removal', 'compaction-digest-sets']
saved = {route: get(route)['enabled'] for route in routes}
env['_EXPERIMENTAL_DAGGER_VERSION'] = 'v1.0.0-beta.15'
for name in ['CPUPROFILE', 'PPROF']:
    env.pop(name, None)
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == dict(mutex_fraction=0, block_profile_rate_ns=0)
(root / 'driver.py').write_bytes(Path(__file__).read_bytes())
try:
    for route in routes:
        mode(route, route in selected)
    get('compaction-digest-sets?record=false', b'')
    command = ['python3', str(base / 'trivial-scalar-projection/verify_retained_first.py'),
               'compaction-digest-sets-e2e-post-cohort']
    tick = time.monotonic()
    with (root / 'retained.log').open('w') as output:
        retained = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    native = dict(exit_code=retained.returncode, seconds=time.monotonic()-tick,
                  command=command, mode=get('compaction-digest-sets'))
    (root / 'retained.json').write_text(json.dumps(native, indent=2) + '\n')
    assert retained.returncode == 0
    # The retained-history helper restores its two temporary modes.
    for route in ['batch-metadata', 'attribute-array-decode']:
        mode(route, True)
    idle('compaction-frequency-diagnostic')
    source.write_bytes(original + f'\n// Compaction frequency diagnostic {time.time_ns()}\n'.encode())
    (workspace / 'dagger.toml').write_text('[modules.go]\nsource = "' + str(module) + '"\n[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n')
    metadata = dict(scope='One separate fresh-edited listing with only compaction event recording; not a timing comparison.',
                    warm_engine=True, fresh_cli=True, telemetry=True, ordinary_gc=True,
                    forced_collection=False, source_reset=False, wcprof=False,
                    flags={route: get(route)['enabled'] for route in routes},
                    engine_sha256=subprocess.check_output(['docker', 'exec', record['Id'], 'sha256sum', '/usr/local/bin/dagger-engine'], text=True).split()[0],
                    cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest())
    (root / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    get('compaction-digest-sets?record=true', b'')
    before = get('snapshot-collection')
    command = [str(cli), 'check', '--module', 'go', '--check', 'test', '--list', '--all']
    tick = time.monotonic()
    with (root / 'command.stdout').open('w') as out, (root / 'command.stderr').open('w') as err:
        process = subprocess.Popen(command, cwd=workspace, env=env, stdout=out, stderr=err, start_new_session=True)
        try:
            code = process.wait(timeout=300)
            cancelled = False
        except subprocess.TimeoutExpired:
            cancelled = True
            os.killpg(process.pid, signal.SIGINT)
            code = process.wait()
    elapsed = time.monotonic() - tick
    events = get('compaction-digest-sets')
    after = get('snapshot-collection')
    expected = [line for line in (base / 'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
    listed = [line for line in (root / 'command.stdout').read_text().splitlines() if line.startswith('go ')]
    result = dict(exit_code=code, cancelled=cancelled, seconds=elapsed, rows=len(listed),
                  same_rows=listed == expected, compaction=events, collection_before=before,
                  collection_after=after)
    (root / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['exit_code', 'seconds', 'rows', 'same_rows', 'compaction']}, indent=2), flush=True)
    assert code == 0 and not cancelled and listed == expected and len(listed) == 4398
finally:
    get('compaction-digest-sets?record=false', b'')
    source.write_bytes(original)
    for name, data in configs.items():
        if data is None:
            (workspace / name).unlink(missing_ok=True)
        else:
            (workspace / name).write_bytes(data)
    for route, enabled in saved.items():
        mode(route, enabled)
    restored = dict(source=source.read_bytes() == original,
                    configs={name: ((workspace / name).read_bytes() if (workspace / name).exists() else None) == data for name, data in configs.items()},
                    modes=all(get(route)['enabled'] == enabled for route, enabled in saved.items()),
                    recording=get('compaction-digest-sets')['record'])
    (root / 'restored.json').write_text(json.dumps(restored, indent=2) + '\n')
