from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
subprocess.run([str(Path(go).with_name('gofmt')),'-w',*[str(p/name) for name in ['controlled-cache_egraph.go','mode.go','debug.go']]],check=True)
rows=[]
for enabled in [False,True]:
 label='race-'+str(enabled).lower()
 command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/'engine-overlay.json'),'-race','-count=1','-run','^(Test.*(EqClass|Egraph|Metadata).*|TestCompactEqClassesKeepsTheLiveContents)$','./dagql']
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=dict(env,DAGGER_TEST_COMPACTION_DIGEST_SETS='on' if enabled else 'off'),stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=command,digest_set_reuse=enabled,recording=False,exit_code=r.returncode,seconds=time.monotonic()-tick));(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:print((p/(label+'.log')).read_text()[-5000:],flush=True)
 assert r.returncode==0
