from collections import Counter
from pathlib import Path
import argparse,json,subprocess
parser=argparse.ArgumentParser()
parser.add_argument('capture',type=Path)
a=parser.parse_args()
counts=Counter();outcomes=Counter();functions=0;requests=0;queries=[];events=0
with (a.capture/'wcprof-complete.ndjson').open() as f:
 header=json.loads(next(f));strings=header['strings']
 for line in f:
  e=json.loads(line);events+=1
  if e.get('e')!='op':continue
  cls=strings[e.get('c',0)];kind=e.get('k');outcome=e.get('o')
  counts[(kind,cls)]+=1
  if kind=='call':outcomes[(cls,outcome)]+=1
  if cls=='sdk.dang.invoke':functions+=1
  if cls=='dang.apiRequest':requests+=1
  if cls=='session.query':queries.append(dict(id=e['id'],seconds=(e['d']-e['s'])/1e9))
selected={name:dict((outcome,n) for (cls,outcome),n in outcomes.items() if cls==name) for name in sorted(set(cls for cls,outcome in outcomes if cls.startswith(('go:', 'gomod:'))))}
functions=counts[('internal','dang.invoke')];requests=counts[('internal','dang.apiRequest')]
main=max(queries,key=lambda q:q['seconds'])
result=dict(function_evaluations=functions,sdk_requests=requests,events=events,dropped=header['dropped_events'],open_ops=len(header.get('open_ops',[])),selected_calls=selected,main_query=main,classes=[dict(kind=k,name=n,count=c) for (k,n),c in counts.most_common(80)])
(a.capture/'attribution.json').write_text(json.dumps(result,indent=2)+'\n')
with (a.capture/'main-critical-path.txt').open('w') as out:
 code=subprocess.run(['/tmp/rust-cache-wcprof-report','-view','critpath','-op',str(main['id']),'-top','30','-depth','8','-limit','80',str(a.capture/'wcprof-complete.ndjson')],stdout=out,stderr=subprocess.STDOUT).returncode
assert code==0
print(json.dumps(dict(events=events,dropped=result['dropped'],open_ops=result['open_ops'],function_evaluations=functions,sdk_requests=requests,selected_calls=selected,main_query=main)))
