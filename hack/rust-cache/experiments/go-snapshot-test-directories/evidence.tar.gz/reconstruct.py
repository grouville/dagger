"""Reconstruct a lossless wcprof stream from a capture's numbered chunks."""
import argparse
import gzip
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("capture", type=Path)
args = parser.parse_args()
headers, events = [], []
for chunk in sorted(args.capture.glob("chunk-*.ndjson.gz")):
    lines = gzip.decompress(chunk.read_bytes()).splitlines()
    headers.append(json.loads(lines[0]))
    events.extend(lines[1:])
assert headers
header = headers[-1]
for previous in headers:
    assert previous["epoch_unix_nano"] == header["epoch_unix_nano"]
    assert previous["strings"] == header["strings"][:len(previous["strings"])]
    assert previous["dropped_events"] == 0
assert not header.get("open_ops")
combined = dict(header, event_count=len(events))
(args.capture / "wcprof-complete.ndjson").write_bytes(
    (json.dumps(combined) + "\n").encode() + b"\n".join(events) + b"\n"
)
