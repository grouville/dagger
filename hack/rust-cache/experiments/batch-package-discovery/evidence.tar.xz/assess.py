from pathlib import Path
import hashlib,json,statistics,subprocess
p=Path(__file__).parent;reports={}
for family in ['test-edit','source-edit','final-test-edit','final-source-edit']:
 rows=json.loads((p/(family+'-paired')/'samples.json').read_text());pairs=[]
 for block in range(1,5):
  before=next(r for r in rows if r['block']==block and r['arm']=='before');after=next(r for r in rows if r['block']==block and r['arm']=='combined')
  pairs.append(dict(block=block,before_seconds=before['seconds'],after_seconds=after['seconds'],saved_seconds=before['seconds']-after['seconds'],before_cpu=before['engine_cpu'],after_cpu=after['engine_cpu'],before_allocated_bytes=before['heap_delta']['TotalAlloc'],after_allocated_bytes=after['heap_delta']['TotalAlloc']))
 r=dict(summary=json.loads((p/(family+'-paired')/'summary.json').read_text()),pairs=pairs,faster_pairs=sum(x['saved_seconds']>0 for x in pairs),median_paired_saved_seconds=statistics.median(x['saved_seconds'] for x in pairs),all_ten_correct=all(x['exit_code']==0 and x['correct_names'] and x['same_full_rows'] and not x['cancelled'] for x in rows),pressure_max={k:max(x['pressure'][k] for x in rows) for k in rows[0]['pressure']},restoration=json.loads((p/(family+'-paired')/'restoration.json').read_text()))
 reports[family]=r;print(family,json.dumps({k:r[k] for k in ['faster_pairs','median_paired_saved_seconds','all_ten_correct','summary']}))
for directory in ['capture-before','capture-candidate','capture-final']:
 c=p/directory
 if not (c/'result.json').exists():continue
 trace=c/'wcprof-complete.ndjson';h=hashlib.sha256();size=0
 with trace.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);size+=len(b)
 (c/'trace-identity.json').write_text(json.dumps(dict(bytes=size,sha256=h.hexdigest()),indent=2)+'\n')
 reports[directory]=json.loads((c/'attribution.json').read_text())
(p/'assessments.json').write_text(json.dumps(reports,indent=2)+'\n')
w=Path('/tmp/dagger-go-batch-package-discovery');identity=json.loads((p/'final-source-identity.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==identity['commit']
assert all(hashlib.sha256((w/n).read_bytes()).hexdigest()==h for n,h in identity['files'].items())
