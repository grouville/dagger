from pathlib import Path
import hashlib
import io
import json
import shutil
import tarfile

p=Path(__file__).parent
decision=json.loads((p/'decision.json').read_text())
assert not decision['selected'] and not decision['pr_opened']
summary=json.loads((p/'paired/summary.json').read_text())
assert summary['all_commands_succeeded'] and summary['same_rows'] and summary['pairs']==8
final=json.loads((p/'final-state.json').read_text())
assert final['retained_all_hit'] and not final['flags']['queued-log-flush-buffer']['enabled']
dest=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/log-flush-buffer')
dest.mkdir(parents=True,exist_ok=False)
sources=[f for f in p.rglob('*') if f.is_file() and f.name!='dagger-engine' and '__pycache__' not in f.parts]
records=[]
archive=dest/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as output:
    for source in sorted(sources):
        data=source.read_bytes();name=source.relative_to(p).as_posix()
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        output.addfile(member,io.BytesIO(data))
        records.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(archive,'r:gz') as saved:
    for record in records:
        data=saved.extractfile(record['path']).read()
        assert len(data)==record['size'] and hashlib.sha256(data).hexdigest()==record['sha256']
manifest=dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=records,decision=decision,omitted_binary=dict(path='dagger-engine',sha256=final['engine_sha256']))
(dest/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copy2(p/'review.patch',dest/'review.patch')
(dest/'README.md').write_text('# Log flush-buffer experiment\n\nSee [the assessment](../../NATIVE_LOG_FLUSH_BUFFER.md). The component result saves most of the flush allocation, but eight full-listing pairs measure 34.38 → 35.36 seconds with only 3/8 faster. All pairs allocate less. The option remains off and no PR is proposed.\n\nThe archive retains the SDK source variants, incompatible upgrade attempt, race checks and expected-failure control, component samples, all eighteen complete commands, warm-up counters, engine source mapping, graceful restart, all three sets of Rust cache checks and restoration. The plain patch is provided for review and targets the legacy SDK; it is not an upstream-main proposal.\n\nMANIFEST.json records every member and archive hash. Original absolute paths need adapting for replay. Existing engine dependency context is in the earlier [native telemetry archive](../telemetry-native-storage/); the current SDK sources and all selected engine overlays are included here. No engine binary, cache volume or credentials are included.\n')
print(json.dumps(dict(members=len(records),archive_bytes=archive.stat().st_size,selected=False)))
