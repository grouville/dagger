from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
component = json.loads((p/'component-commands.json').read_text())
assert len(component)==11 and all(r['exit_code']==r['expected_exit_code'] for r in component)
rows = []
steps = []
for mode in ['false','true']:
    steps.append(('sdk-diagnostic-'+mode, [go,'test','-mod=mod','-p=2','-race','-count=1','-timeout=180s','-overlay='+str(p/'diagnostic-overlay.json'),'.'],p/'sdk-diagnostic',dict(env,DAGGER_BENCH_QUEUED_FLUSH_BUFFER=mode)))
steps.append(('clientdb-race',[go,'test','-p=2','-race','-count=1','-timeout=240s','-modfile='+str(p/'engine.go.mod'),'-overlay='+str(p/'engine-overlay.json'),'./engine/clientdb'],Path('/tmp/dagger-filesync-snapshot-seeds'),env))
steps.append(('engine-build',[go,'build','-p=2','-buildvcs=false','-modfile='+str(p/'engine.go.mod'),'-overlay='+str(p/'engine-overlay.json'),'-o',str(p/'dagger-engine'),'./cmd/engine'],Path('/tmp/dagger-filesync-snapshot-seeds'),env))
for label,command,cwd,run_env in steps:
    start = time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result = subprocess.run(command,cwd=cwd,env=run_env,stdout=output,stderr=subprocess.STDOUT)
    row = dict(label=label,command=command,cwd=str(cwd),exit_code=result.returncode,seconds=time.monotonic()-start)
    if label=='engine-build' and result.returncode==0:
        row['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
    rows.append(row)
    (p/'build-steps.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==0,(p/(label+'.log')).read_text()[-5000:]
