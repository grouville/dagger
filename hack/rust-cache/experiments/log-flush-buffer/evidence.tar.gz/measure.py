from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8')
orders = [['before','after'],['after','before'],['before','after'],['after','before']]
(p/'component-plan.json').write_text(json.dumps(dict(scope='Pinned SDK v0.16.0 only. The new buffer is sized to the queued records; exporter barriers, queue capacity, timeouts and batching policy are unchanged. Enqueue plus synchronous flush is timed, with processor setup/closing outside timing. No engine replacement or command-time claim.',orders=orders,queue_capacity=[128,2048],records_per_cycle=[0,1,16],benchmark_sha256=hashlib.sha256((p/'flush_buffer_test.go').read_bytes()).hexdigest(),spec='https://opentelemetry.io/docs/specs/otel/logs/sdk/#forceflush'),indent=2)+'\n')
rows = []
def run(label, arm, flags, expected=0):
    directory = p/('sdk-'+arm)
    overlay = p/(arm+'-overlay.json' if arm in ['before','after'] else 'incorrect-empty-return-overlay.json')
    command = [go, 'test', '-mod=mod', '-p=2', '-count=1', '-timeout=180s', '-overlay='+str(overlay), *flags, '.']
    start = time.monotonic()
    log = p/(label+'.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=directory, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, arm=arm, command=command, expected_exit_code=expected, exit_code=result.returncode, process_seconds=time.monotonic()-start)
    rows.append(row)
    (p/'component-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==expected,log.read_text()[-5000:]
    if expected:
        assert 'FAIL: TestFlushEmptyQueueStillFlushesExporter' in log.read_text()
        assert 'FAIL: TestFlushEmptyQueueWaitsForInflightExport' in log.read_text()

run('before-race','before',['-race'])
run('after-final-race','after',['-race'])
run('incorrect-empty-return','incorrect-empty-return',['-race','-run=^TestFlushEmptyQueue'],expected=1)
for pair, order in enumerate(orders):
    for arm in order:
        run(f'component-{pair}-{arm}',arm,['-run=^$', '-bench=^BenchmarkLogFlushBuffer$', '-benchtime=200ms','-benchmem','-cpu=8'])
