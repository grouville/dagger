package main

import (
	"bytes"
	"fmt"
	"strings"
	"sync"
	"testing"
)

type lockedLogBuffer struct {
	mu sync.Mutex
	bytes.Buffer
}

func (b *lockedLogBuffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.Buffer.Write(p)
}

func TestControlledLogWriterModeOrder(t *testing.T) {
	var out lockedLogBuffer
	w := newControlledLogWriter(&out)
	for i, mode := range []bool{false, true, false, true} {
		if err := w.setMode(mode); err != nil {
			t.Fatal(err)
		}
		if _, err := fmt.Fprintf(w, "line-%d\n", i); err != nil {
			t.Fatal(err)
		}
	}
	if err := w.Flush(); err != nil {
		t.Fatal(err)
	}
	if got := out.String(); got != "line-0\nline-1\nline-2\nline-3\n" {
		t.Fatal(got)
	}
}

func TestControlledLogWriterConcurrentModeChanges(t *testing.T) {
	var out lockedLogBuffer
	w := newControlledLogWriter(&out)
	var group sync.WaitGroup
	for worker := range 4 {
		group.Go(func() {
			for line := range 100 {
				if _, err := fmt.Fprintf(w, "worker=%d line=%d\n", worker, line); err != nil {
					t.Error(err)
					return
				}
			}
		})
	}
	for i := range 10 {
		if err := w.setMode(i%2 == 0); err != nil {
			t.Fatal(err)
		}
	}
	group.Wait()
	if err := w.Flush(); err != nil {
		t.Fatal(err)
	}
	lines := strings.Split(strings.TrimSpace(out.String()), "\n")
	seen := map[string]bool{}
	for _, line := range lines {
		if seen[line] {
			t.Fatalf("duplicate line: %s", line)
		}
		seen[line] = true
	}
	if len(seen) != 400 {
		t.Fatalf("got %d distinct lines, want 400", len(seen))
	}
}
