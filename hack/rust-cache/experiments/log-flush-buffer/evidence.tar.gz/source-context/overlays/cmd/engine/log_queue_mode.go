package main

import (
	"encoding/json"
	"io"
	"net/http"
	"strconv"
	"sync"

	"github.com/dagger/dagger/engine/slog"
)

type controlledLogWriter struct {
	mu      sync.RWMutex
	direct  io.Writer
	queued  *slog.Writer
	enabled bool
}

func newControlledLogWriter(out io.Writer) *controlledLogWriter {
	queued := slog.NewWriter(out, 1<<20)
	queued.SyncWarn = true
	return &controlledLogWriter{direct: out, queued: queued}
}

func (w *controlledLogWriter) Write(p []byte) (int, error) {
	w.mu.RLock()
	defer w.mu.RUnlock()
	if w.enabled {
		return w.queued.Write(p)
	}
	return w.direct.Write(p)
}

// Drain before a mode switch so a direct write cannot overtake queued output.
func (w *controlledLogWriter) setMode(enabled bool) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if err := w.queued.Flush(); err != nil {
		return err
	}
	w.enabled = enabled
	return nil
}

func (w *controlledLogWriter) Flush() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.queued.Flush()
}

func controlledLogWriterDiagnostic(w http.ResponseWriter, r *http.Request) {
	if engineLogChoice == nil {
		http.Error(w, "log writer not initialized", http.StatusServiceUnavailable)
		return
	}
	if r.Method == http.MethodPost {
		if raw, ok := r.URL.Query()["enabled"]; ok {
			enabled, err := strconv.ParseBool(raw[0])
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			if err := engineLogChoice.setMode(enabled); err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
		} else if err := engineLogChoice.Flush(); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	engineLogChoice.mu.RLock()
	enabled := engineLogChoice.enabled
	engineLogChoice.mu.RUnlock()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": enabled})
}
