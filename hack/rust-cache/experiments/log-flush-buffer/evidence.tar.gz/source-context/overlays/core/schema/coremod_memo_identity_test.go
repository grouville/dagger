package schema

import (
	"sync"
	"testing"

	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/dagql/call"
	"github.com/stretchr/testify/require"
)

// Equivalent core providers must not split the schema memo into distinct sets.
func TestCoreProvidersReuseSchemaMemo(t *testing.T) {
	base := &CoreSchemaBase{}
	root := &core.Query{}
	memo := core.NewSchemaBuilderMemo()
	view := call.View("v1.0.0")
	const callers = 16
	var builders [callers]*core.SchemaBuilder
	var wg sync.WaitGroup
	for i := range callers {
		wg.Go(func() {
			builders[i] = memo.Get(core.NewSchemaBuilder(root, []core.Mod{base.CoreMod(view)}))
		})
	}
	wg.Wait()
	for _, builder := range builders {
		require.Same(t, builders[0], builder, "the same base and API view describe the same core schema")
	}

	original := base.CoreMod(view)
	otherView := call.View("v0.21.0")
	other := memo.Get(core.NewSchemaBuilder(root, []core.Mod{base.CoreMod(otherView)}))
	require.NotSame(t, builders[0], other, "API views remain distinct")
	require.Same(t, other, memo.Get(core.NewSchemaBuilder(root, []core.Mod{original.WithView(otherView)})))
	unchanged, _ := original.View()
	require.Equal(t, view, unchanged)

	differentBase := &CoreSchemaBase{}
	require.NotSame(t, builders[0], memo.Get(core.NewSchemaBuilder(root, []core.Mod{differentBase.CoreMod(view)})),
		"independent core schema bases remain distinct")
	viewWithoutBase, _ := (&CoreMod{}).WithView(view).View()
	require.Equal(t, view, viewWithoutBase)
}
