package dangv2

import (
	"encoding/json"
	"net/http"
	"strconv"
	"sync/atomic"
)

// Diagnostics for paired measurements. Excluded from any production patch.
var schemaReadBuffersEnabled atomic.Bool

func SchemaReadBuffersDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		schemaReadBuffersEnabled.Store(enabled)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": schemaReadBuffersEnabled.Load()})
}
