package core

import (
	"cmp"
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"maps"
	"os"
	"path/filepath"
	"runtime"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"

	ctrdmount "github.com/containerd/containerd/v2/core/mount"
	containerdfs "github.com/containerd/continuity/fs"

	bkcache "github.com/dagger/dagger/engine/snapshots"
	"github.com/dagger/dagger/internal/buildkit/executor"
	"github.com/dagger/dagger/internal/buildkit/solver/pb"
	utilsystem "github.com/dagger/dagger/internal/buildkit/util/system"
	"github.com/moby/sys/userns"
	"github.com/opencontainers/go-digest"
	specs "github.com/opencontainers/image-spec/specs-go/v1"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	"github.com/dagger/dagger/engine"
	"github.com/dagger/dagger/engine/engineutil"
	"github.com/dagger/dagger/engine/slog"
	"github.com/dagger/dagger/engine/wcprof"
	"github.com/dagger/dagger/network"
	telemetry "github.com/dagger/otel-go"
	"go.opentelemetry.io/otel/trace"
)

var ErrNoCommand = errors.New("no command has been set")
var ErrNoSvcCommand = errors.New("no service command has been set")

type ContainerExecOpts struct {
	// Command to run instead of the container's default command
	Args []string

	// If the container has an entrypoint, prepend it to this exec's args
	UseEntrypoint bool `default:"false"`

	// Content to write to the command's standard input before closing
	Stdin string `default:""`
	// Redirect the command's standard input from a file in the container
	RedirectStdin string `default:""`

	// Redirect the command's standard output to a file in the container
	RedirectStdout string `default:""`

	// Redirect the command's standard error to a file in the container
	RedirectStderr string `default:""`

	// Also log streams redirected with RedirectStdout/RedirectStderr, as API
	// views before v1.0.0 did. Not an API argument: withExec sets it from the
	// caller's view.
	LogRedirectedOutput bool `name:"-"`

	// Exit codes this exec is allowed to exit with
	Expect ReturnTypes `default:"SUCCESS"`

	// Provide the executed command access back to the Dagger API
	ExperimentalPrivilegedNesting bool `default:"false"`

	// Disable access to the Dagger API from the executed command.
	DisableDaggerInDagger bool `default:"false"`

	// Connect Dagger clients started by the command as new sessions instead
	// of as clients of the current session.
	DaggerInDaggerNewSession bool `default:"false"`

	// Grant the process all root capabilities
	InsecureRootCapabilities bool `default:"false"`

	// (Internal-only) execute with no network connectivity, equivalent to
	// BuildKit NetMode_NONE / Dockerfile RUN --network=none.
	NoNetwork bool `internal:"true" default:"false"`

	// (Internal-only) execute with host networking, equivalent to
	// BuildKit NetMode_HOST / Dockerfile RUN --network=host.
	HostNetwork bool `internal:"true" default:"false"`

	// Expand the environment variables in args
	Expand bool `default:"false"`

	// Skip the init process injected into containers by default so that the
	// user's process is PID 1
	NoInit bool `default:"false"`
}

type ContainerExecState struct {
	LazyState

	Parent        dagql.ObjectResult[*Container]
	Opts          ContainerExecOpts
	ExecMD        *engineutil.ExecutionMetadata
	ModuleContext dagql.ObjectResult[*Module]
	FunctionCall  *FunctionCall

	// ExecMD changes during execution and retries. Persist the supplied input.
	originalExecMD *engineutil.ExecutionMetadata
}

type ContainerExecLazy struct {
	State *ContainerExecState
}

type persistedContainerExecLazy struct {
	ParentResultID                 uint64                        `json:"parentResultID"`
	ModuleContextResultID          uint64                        `json:"moduleContextResultID,omitempty"`
	Opts                           ContainerExecOpts             `json:"opts"`
	ExecMD                         *engineutil.ExecutionMetadata `json:"execMD,omitempty"`
	VolatileCacheHitParentResultID uint64                        `json:"volatileCacheHitParentResultID,omitempty"`
	VolatileCacheHitVolatileEnv    []string                      `json:"volatileCacheHitVolatileEnv,omitempty"`
}

// ContainerVolatileExecCacheHitLazy materializes from a broad volatile exec
// cache hit, then restores the request-local volatile environment for
// descendants of the returned container.
type ContainerVolatileExecCacheHitLazy struct {
	LazyState

	Parent      dagql.ObjectResult[*Container]
	VolatileEnv []string
}

func (lazy *ContainerExecLazy) Evaluate(ctx context.Context, ctr *Container) error {
	if lazy == nil || lazy.State == nil {
		return nil
	}
	return ctr.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerExecLazy) IsEvaluated() bool {
	return lazy != nil && lazy.State != nil && lazy.State.IsEvaluated()
}

func (lazy *ContainerExecLazy) ContainerLazyState() *LazyState {
	return &lazy.State.LazyState
}

// ContainerLazyGroups implements the exec's part mapping: metadata and
// each read-only mount delegate from the parent (the run does not change
// or produce them); fs, execMeta, and every writable mount are filled
// jointly by the one process run (execOutputs).
func (lazy *ContainerExecLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	groupOf := func(part dagql.PartKey) (dagql.LazyGroupKey, error) {
		switch part {
		case ContainerPartMetadata:
			return ContainerLazyGroupMetadata, nil
		case ContainerPartFS, ContainerPartExecMeta:
			return ContainerLazyGroupExecOutputs, nil
		}
		if target, ok := strings.CutPrefix(string(part), containerPartMountPrefix); ok {
			mnt := ctr.mountAt(target)
			if mnt == nil {
				return "", fmt.Errorf("container withExec: no mount at target %q", target)
			}
			if mnt.Readonly {
				return containerDelegationGroup(part), nil
			}
			return ContainerLazyGroupExecOutputs, nil
		}
		return "", fmt.Errorf("container withExec: unknown part %q", part)
	}
	if parts == nil {
		groups := []dagql.LazyGroupKey{ContainerLazyGroupMetadata, ContainerLazyGroupExecOutputs}
		for i := range ctr.Mounts {
			mnt := &ctr.Mounts[i]
			if mnt.Readonly && (mnt.DirectorySource != nil || mnt.FileSource != nil) {
				groups = append(groups, containerDelegationGroup(ContainerPartMount(mnt.Target)))
			}
		}
		return groups, nil
	}
	var groups []dagql.LazyGroupKey
	seen := make(map[dagql.LazyGroupKey]struct{}, len(parts))
	for _, part := range parts {
		group, err := groupOf(part)
		if err != nil {
			return nil, err
		}
		if _, dup := seen[group]; dup {
			continue
		}
		seen[group] = struct{}{}
		groups = append(groups, group)
	}
	return groups, nil
}

func (lazy *ContainerExecLazy) EvaluateContainerGroup(ctx context.Context, ctr *Container, group dagql.LazyGroupKey) error {
	if lazy == nil || lazy.State == nil {
		return nil
	}
	switch group {
	case ContainerLazyGroupMetadata:
		return lazy.State.LazyState.EvaluateGroup(ctx, "Container.withExec", group, func(ctx context.Context) error {
			// The exec changes no metadata: the child's plain fields are
			// the parent's, settled without running anything. (This
			// preserves the previously evaluated-state behavior for
			// ImageRef too: WithExec clears it on the shell but the
			// parent copy restores it, exactly as the old whole-body
			// parent-state copy did.)
			return materializeContainerMetadataFromParent(ctx, ctr, lazy.State.Parent)
		})
	case ContainerLazyGroupExecOutputs:
		return lazy.State.evaluateOutputs(ctx, ctr)
	default:
		return lazy.State.LazyState.EvaluateGroup(ctx, "Container.withExec", group, func(ctx context.Context) error {
			return delegateContainerPart(ctx, ctr, lazy.State.Parent, dagql.PartKey(group))
		})
	}
}

func (lazy *ContainerExecLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	if lazy == nil || lazy.State == nil {
		return nil, nil
	}
	parent, err := attachContainerResult(attach, lazy.State.Parent, "attach container withExec parent")
	if err != nil {
		return nil, err
	}
	lazy.State.Parent = parent

	deps := []dagql.AnyResult{parent}
	if lazy.State.ModuleContext.Self() != nil {
		attached, err := attach(lazy.State.ModuleContext)
		if err != nil {
			return nil, fmt.Errorf("attach container withExec module context: %w", err)
		}
		moduleContext, ok := attached.(dagql.ObjectResult[*Module])
		if !ok {
			return nil, fmt.Errorf("attach container withExec module context: expected %T, got %T", lazy.State.ModuleContext, attached)
		}
		lazy.State.ModuleContext = moduleContext
		deps = append(deps, moduleContext)
	}

	return deps, nil
}

func (lazy *ContainerExecLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	if lazy == nil || lazy.State == nil {
		return nil, fmt.Errorf("encode persisted container withExec lazy: nil state")
	}
	if lazy.State.FunctionCall != nil {
		return nil, fmt.Errorf("cannot persist container exec with active function call")
	}
	parentID, err := encodePersistedObjectRef(enc, lazy.State.Parent, "container withExec parent")
	if err != nil {
		return nil, err
	}
	var moduleContextID uint64
	if lazy.State.ModuleContext.Self() != nil {
		moduleContextID, err = encodePersistedObjectRef(enc, lazy.State.ModuleContext, "container withExec module context")
		if err != nil {
			return nil, err
		}
	}
	return json.Marshal(persistedContainerExecLazy{
		ParentResultID:        parentID,
		ModuleContextResultID: moduleContextID,
		Opts:                  lazy.State.Opts,
		ExecMD:                lazy.State.originalExecMD,
	})
}

// execMeta copies the metadata by value, but mutates HostAliases in place.
func copyExecInputMetadata(input *engineutil.ExecutionMetadata) *engineutil.ExecutionMetadata {
	if input == nil {
		return nil
	}
	copy := *input
	copy.HostAliases = maps.Clone(input.HostAliases)
	for host, aliases := range copy.HostAliases {
		copy.HostAliases[host] = slices.Clone(aliases)
	}
	return &copy
}

func (lazy *ContainerVolatileExecCacheHitLazy) Evaluate(ctx context.Context, container *Container) error {
	if lazy == nil {
		return nil
	}
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerVolatileExecCacheHitLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerVolatileExecCacheHitLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withExec.cacheHit", container, lazy.Parent, group, func(ctx context.Context) error {
		container.VolatileEnv = slices.Clone(lazy.VolatileEnv)
		return nil
	})
}

func (lazy *ContainerVolatileExecCacheHitLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	if lazy == nil {
		return nil, nil
	}
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container volatile exec cache hit parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerVolatileExecCacheHitLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	if lazy == nil {
		return nil, fmt.Errorf("encode persisted container volatile exec cache hit lazy: nil lazy")
	}
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container volatile exec cache hit parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerExecLazy{
		VolatileCacheHitParentResultID: parentID,
		VolatileCacheHitVolatileEnv:    slices.Clone(lazy.VolatileEnv),
	})
}

func (container *Container) execMeta(
	ctx context.Context,
	opts ContainerExecOpts,
	parent *engineutil.ExecutionMetadata,
	moduleContext dagql.ObjectResult[*Module],
) (*engineutil.ExecutionMetadata, error) {
	execMD := engineutil.ExecutionMetadata{}
	if parent != nil {
		execMD = *parent
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	clientMetadata, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return nil, err
	}
	if execMD.CallDigest == "" {
		if curCall := dagql.CurrentCall(ctx); curCall != nil {
			callDigest, err := curCall.RecipeDigest(ctx)
			if err != nil {
				return nil, fmt.Errorf("compute exec call digest: %w", err)
			}
			execMD.CallDigest = callDigest
		}
	}
	if execMD.HostAliases == nil {
		execMD.HostAliases = make(map[string][]string)
	}
	execMD.RedirectStdinPath = opts.RedirectStdin
	execMD.RedirectStdoutPath = opts.RedirectStdout
	execMD.RedirectStderrPath = opts.RedirectStderr
	execMD.LogRedirectedOutput = opts.LogRedirectedOutput
	execMD.SystemEnvNames = container.SystemEnvNames
	execMD.EnabledGPUs = container.EnabledGPUs
	if opts.NoInit {
		execMD.NoInit = true
	}
	execMD.DaggerInDaggerNewSession = opts.DaggerInDaggerNewSession

	var callerModDigest digest.Digest
	if moduleContext.Self() != nil {
		implementationScopedMod, err := ImplementationScopedModule(ctx, moduleContext)
		if err != nil {
			return nil, fmt.Errorf("failed to get implementation-scoped module from exec module context: %w", err)
		}
		callerModDigest, err = implementationScopedMod.ContentPreferredDigest(ctx)
		if err != nil {
			return nil, fmt.Errorf("failed to get implementation-scoped module digest from exec module context: %w", err)
		}
	} else if callerMod, err := query.CurrentModule(ctx); err == nil && callerMod.Self() != nil {
		implementationScopedMod, err := ImplementationScopedModule(ctx, callerMod)
		if err != nil {
			return nil, fmt.Errorf("failed to get caller implementation-scoped module: %w", err)
		}
		callerModDigest, err = implementationScopedMod.ContentPreferredDigest(ctx)
		if err != nil {
			return nil, fmt.Errorf("failed to get caller implementation-scoped module digest: %w", err)
		}
	}

	if callerModDigest != "" {
		// allow the exec to reach services scoped to the module that installed it
		execMD.ExtraSearchDomains = append(execMD.ExtraSearchDomains, network.ModuleDomain(callerModDigest, clientMetadata.SessionID))
	}

	// if GPU parameters are set for this container pass them over:
	if len(execMD.EnabledGPUs) > 0 {
		if gpuSupportEnabled := os.Getenv("_EXPERIMENTAL_DAGGER_GPU_SUPPORT"); gpuSupportEnabled == "" {
			return nil, fmt.Errorf("GPU support is not enabled, set _EXPERIMENTAL_DAGGER_GPU_SUPPORT")
		}
	}

	for _, bnd := range container.Services {
		for _, alias := range bnd.Aliases {
			execMD.HostAliases[bnd.Hostname] = append(execMD.HostAliases[bnd.Hostname], alias)
		}
	}

	for i, secret := range container.Secrets {
		switch {
		case secret.EnvName != "":
			execMD.SecretEnvNames = append(execMD.SecretEnvNames, secret.EnvName)
		case secret.MountPath != "":
			execMD.SecretFilePaths = append(execMD.SecretFilePaths, secret.MountPath)
		default:
			return nil, fmt.Errorf("malformed secret config at index %d", i)
		}
	}

	return &execMD, nil
}

func (container *Container) metaSpec(ctx context.Context, opts ContainerExecOpts, volatileEnv []string) (*executor.Meta, error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, fmt.Errorf("get current query: %w", err)
	}

	cfg := container.Config
	args, err := container.command(opts)
	if err != nil {
		return nil, err
	}
	platform := container.Platform
	if platform.OS == "" {
		platform = query.Platform()
	}

	metaSpec := executor.Meta{
		Args:                      args,
		Env:                       slices.Clone(cfg.Env),
		Cwd:                       cmp.Or(cfg.WorkingDir, "/"),
		User:                      cfg.User,
		RemoveMountStubsRecursive: true,
	}
	if opts.InsecureRootCapabilities {
		metaSpec.SecurityMode = pb.SecurityMode_INSECURE
	}
	netMode, err := execNetMode(opts)
	if err != nil {
		return nil, err
	}
	if netMode != pb.NetMode_UNSET {
		metaSpec.NetMode = netMode
	}

	metaSpec.Env = addDefaultEnvvar(metaSpec.Env, "PATH", utilsystem.DefaultPathEnv(platform.OS))
	metaSpec.Env = mergeEnv(metaSpec.Env, volatileEnv)

	if opts.Expect != ReturnSuccess {
		metaSpec.ValidExitCodes = opts.Expect.ReturnCodes()
	}

	return &metaSpec, nil
}

func execNetMode(opts ContainerExecOpts) (pb.NetMode, error) {
	if opts.NoNetwork && opts.HostNetwork {
		return pb.NetMode_UNSET, fmt.Errorf("cannot set both noNetwork and hostNetwork")
	}
	if opts.NoNetwork {
		return pb.NetMode_NONE, nil
	}
	if opts.HostNetwork {
		return pb.NetMode_HOST, nil
	}
	return pb.NetMode_UNSET, nil
}

type serviceBindingExitError struct {
	binding ServiceBinding
	err     error
	// origins are the install-span contexts of the API calls that returned the
	// bound service. Embedded in the error message as traceparents so the
	// consuming exec span links its failure back to those API calls.
	origins []trace.SpanContext
}

func (e *serviceBindingExitError) Error() string {
	if e == nil {
		return "bound service exited"
	}
	name := e.binding.Hostname
	if name == "" {
		name = "unknown"
	}
	var msg string
	if e.err == nil {
		msg = fmt.Sprintf("bound service %s (%s) exited", name, e.binding.Aliases)
	} else {
		msg = fmt.Sprintf("bound service %s (%s) exited: %v", name, e.binding.Aliases, e.err)
	}
	// Append traceparents so the consuming exec span EndWithCause adds
	// LinkPurposeErrorOrigin links to the service's install spans. The inner
	// service error may already carry the service starter's origin; keep it, but
	// still add any missing current origins so reused services attribute failures
	// to every API call that installed/bound them.
	tracked := telemetry.ParseErrorOrigins(msg)
	trackedKeys := make(map[string]struct{}, len(tracked))
	for _, origin := range tracked {
		trackedKeys[spanContextKey(origin)] = struct{}{}
	}
	for _, origin := range normalizeSpanContexts(e.origins) {
		if _, alreadyTracked := trackedKeys[spanContextKey(origin)]; alreadyTracked {
			continue
		}
		msg = telemetry.TrackOrigin(errors.New(msg), origin).Error()
		trackedKeys[spanContextKey(origin)] = struct{}{}
	}
	return msg
}

func (e *serviceBindingExitError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.err
}

func isServiceBindingExitError(err error) bool {
	var svcErr *serviceBindingExitError
	return errors.As(err, &svcErr)
}

func serviceBindingErrorOrigins(ctx context.Context, binding ServiceBinding, running *RunningService) []trace.SpanContext {
	if origins := lookupServiceOriginSpanContexts(ctx, binding.Service); len(origins) > 0 {
		return origins
	}
	if running != nil {
		if origin := running.errorOriginSpanContext(); origin.IsValid() {
			return []trace.SpanContext{origin}
		}
	}
	return nil
}

// monitorServiceBindings reports the first bound service that exits while a
// dependent operation is still running. If cancel is set, it is called with the
// service error as the cause.
func monitorServiceBindings(
	ctx context.Context,
	bindings ServiceBindings,
	running []*RunningService,
	cancel context.CancelCauseFunc,
) (<-chan error, func()) {
	monitorCtx, stopMonitor := context.WithCancel(ctx)
	serviceErrCh := make(chan error, 1)

	var wg sync.WaitGroup
	for i, runningSvc := range running {
		if runningSvc == nil || runningSvc.Wait == nil {
			continue
		}

		binding := ServiceBinding{}
		if i < len(bindings) {
			binding = bindings[i]
		}
		if binding.Hostname == "" {
			binding.Hostname = runningSvc.Host
		}

		origins := serviceBindingErrorOrigins(ctx, binding, runningSvc)

		wg.Add(1)
		go func() {
			defer wg.Done()

			err := runningSvc.Wait(monitorCtx)
			if monitorCtx.Err() != nil {
				return
			}

			svcErr := &serviceBindingExitError{
				binding: binding,
				err:     err,
				origins: origins,
			}
			select {
			case serviceErrCh <- svcErr:
			default:
			}
			if cancel != nil {
				cancel(svcErr)
			}
		}()
	}

	var stopOnce sync.Once
	stop := func() {
		stopOnce.Do(func() {
			stopMonitor()
			wg.Wait()
			close(serviceErrCh)
		})
	}
	return serviceErrCh, stop
}

func (container *Container) secretEnvValues(ctx context.Context) ([]string, error) {
	env := make([]string, 0, len(container.Secrets))
	for _, secret := range container.Secrets {
		if secret.EnvName == "" {
			continue
		}
		plaintext, err := secret.Secret.Self().Plaintext(ctx)
		if err != nil {
			return nil, fmt.Errorf("secret env %q: %w", secret.EnvName, err)
		}
		env = append(env, secret.EnvName+"="+string(plaintext))
	}
	return env, nil
}

type execSecretMountConfig struct {
	Secret dagql.ObjectResult[*Secret]
	UID    int
	GID    int
	Mode   fs.FileMode
}

type execSSHMountConfig struct {
	Socket dagql.ObjectResult[*Socket]
	UID    int
	GID    int
	Mode   fs.FileMode
}

type execVolumeMountConfig struct {
	Volume dagql.ObjectResult[*Volume]
}

type execMountState struct {
	Dest      string
	Selector  string
	Readonly  bool
	MountType pb.MountType

	SourceRef bkcache.Ref

	TmpfsOpt *pb.TmpfsOpt
	Secret   *execSecretMountConfig
	SSH      *execSSHMountConfig
	Volume   *execVolumeMountConfig

	ApplyOutput func(bkcache.ImmutableRef) error

	ActiveRef       bkcache.MutableRef
	OutputMutable   bkcache.MutableRef
	OutputImmutable bkcache.ImmutableRef
}

type materializedExecPlan struct {
	Root   executor.Mount
	Mounts []executor.Mount
	States []*execMountState
}

func lockMountedCaches(ctx context.Context, mounts []ContainerMount) (func(), error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, fmt.Errorf("get current query for cache locks: %w", err)
	}
	locker := query.Locker()
	if locker == nil {
		return nil, fmt.Errorf("missing engine locker")
	}

	lockSet := make(map[string]struct{})
	for i, ctrMount := range mounts {
		if ctrMount.Readonly || ctrMount.CacheSource == nil || ctrMount.CacheSource.Volume.Self() == nil {
			continue
		}
		cacheSelf := ctrMount.CacheSource.Volume.Self()
		if !cacheSharingModeLocksWrites(cacheSelf.Sharing) {
			continue
		}
		lockKey, err := cacheSelf.lockKey()
		if err != nil {
			return nil, fmt.Errorf("cache lock key for mount %d: %w", i, err)
		}
		lockSet[lockKey] = struct{}{}
	}
	if len(lockSet) == 0 {
		return func() {}, nil
	}

	lockKeys := make([]string, 0, len(lockSet))
	for lockKey := range lockSet {
		lockKeys = append(lockKeys, lockKey)
	}
	sort.Strings(lockKeys)
	profiling := wcprof.Enabled(ctx)
	for _, lockKey := range lockKeys {
		var profWait *wcprof.Wait
		if profiling {
			profWait = wcprof.BeginWaitIdent(ctx, "cachelock:"+lockKey, wcprof.WaitReasonLock)
		}
		locker.Lock(lockKey)
		profWait.End()
	}
	return func() {
		for i := len(lockKeys) - 1; i >= 0; i-- {
			locker.Unlock(lockKeys[i])
		}
	}, nil
}

func cacheSharingModeLocksWrites(mode CacheSharingMode) bool {
	// Stop-gap: PRIVATE is implemented with the same serialized writes as LOCKED.
	return mode == CacheSharingModeLocked || mode == CacheSharingModePrivate
}

func (plan *materializedExecPlan) releaseActives(ctx context.Context) error {
	var rerr error
	for i := len(plan.States) - 1; i >= 0; i-- {
		active := plan.States[i].ActiveRef
		if active == nil {
			continue
		}
		rerr = errors.Join(rerr, active.Release(ctx))
		plan.States[i].ActiveRef = nil
	}
	return rerr
}

func (plan *materializedExecPlan) releaseOutputRefs(ctx context.Context) error {
	var rerr error
	for _, state := range plan.States {
		if state.OutputMutable != nil {
			rerr = errors.Join(rerr, state.OutputMutable.Release(ctx))
			state.OutputMutable = nil
		}
		if state.OutputImmutable != nil {
			rerr = errors.Join(rerr, state.OutputImmutable.Release(ctx))
			state.OutputImmutable = nil
		}
	}
	return rerr
}

type makeExecMutable func(dest string, ref bkcache.ImmutableRef) (bkcache.MutableRef, error)

//nolint:dupl,gocyclo // symmetric with the mount-materialization closure inside (*ContainerExecState).Evaluate; sharing hurts readability of each phase
func prepareMounts(
	ctx context.Context,
	container *Container,
	rootOutput func(bkcache.ImmutableRef) error,
	metaOutput func(bkcache.ImmutableRef) error,
	mountOutputs []func(bkcache.ImmutableRef) error,
	cache bkcache.SnapshotManager,
	cwd string,
	platform string,
	makeMutable makeExecMutable,
) (materialized materializedExecPlan, err error) {
	defer func() {
		if err != nil {
			_ = materialized.releaseActives(context.WithoutCancel(ctx))
			_ = materialized.releaseOutputRefs(context.WithoutCancel(ctx))
		}
	}()

	materializeState := func(state *execMountState) error {
		var mountable bkcache.Mountable
		if state.SourceRef != nil {
			mountable = state.SourceRef
		}

		if state.Volume != nil {
			var err error
			mountable, err = prepareExecVolumeMount(ctx, state.Volume)
			if err != nil {
				return err
			}
		} else {
			switch state.MountType {
			case pb.MountType_BIND:
				if state.ApplyOutput != nil {
					if state.Readonly && state.SourceRef != nil && state.Dest != pb.RootMount {
						iref, ok := state.SourceRef.(bkcache.ImmutableRef)
						if !ok {
							return fmt.Errorf("mount %s readonly output needs immutable input, got %T", state.Dest, state.SourceRef)
						}
						reopened, err := cache.GetBySnapshotID(ctx, iref.SnapshotID(), bkcache.NoUpdateLastUsed)
						if err != nil {
							return err
						}
						state.OutputImmutable = reopened
					} else {
						iref, ok := state.SourceRef.(bkcache.ImmutableRef)
						if state.SourceRef != nil && !ok {
							return fmt.Errorf("mount %s writable output needs immutable input, got %T", state.Dest, state.SourceRef)
						}
						active, err := makeMutable(state.Dest, iref)
						if err != nil {
							return err
						}
						mountable = active
						state.OutputMutable = active
					}
				} else {
					if !state.Readonly && state.SourceRef != nil {
						if mutable, ok := state.SourceRef.(bkcache.MutableRef); ok {
							mountable = mutable
						} else {
							iref := state.SourceRef.(bkcache.ImmutableRef)
							active, err := makeMutable(state.Dest, iref)
							if err != nil {
								return err
							}
							mountable = active
							state.ActiveRef = active
						}
					} else if !state.Readonly || state.SourceRef == nil {
						var iref bkcache.ImmutableRef
						if state.SourceRef != nil {
							parsed, ok := state.SourceRef.(bkcache.ImmutableRef)
							if !ok {
								return fmt.Errorf("mount %s writable bind needs immutable or mutable input, got %T", state.Dest, state.SourceRef)
							}
							iref = parsed
						}
						active, err := makeMutable(state.Dest, iref)
						if err != nil {
							return err
						}
						mountable = active
						state.ActiveRef = active
					}
				}

			case pb.MountType_TMPFS:
				mountable = execTmpFSMountable(state.TmpfsOpt)

			case pb.MountType_SECRET:
				mountable, err = prepareExecSecretMount(ctx, state.Secret)
				if err != nil {
					return err
				}

			case pb.MountType_SSH:
				mountable, err = prepareExecSSHMount(state.SSH)
				if err != nil {
					return err
				}

			default:
				return fmt.Errorf("mount type %s not implemented", state.MountType)
			}
		}

		if state.Dest == pb.RootMount && state.Readonly && state.ApplyOutput == nil {
			if _, ok := mountable.(bkcache.MutableRef); !ok {
				var iref bkcache.ImmutableRef
				if state.SourceRef != nil {
					parsed, ok := state.SourceRef.(bkcache.ImmutableRef)
					if !ok {
						return fmt.Errorf("root mount readonly fallback needs immutable input, got %T", state.SourceRef)
					}
					iref = parsed
				}
				active, err := makeMutable(state.Dest, iref)
				if err != nil {
					return err
				}
				mountable = active
				state.ActiveRef = active
			}
		}

		if mountable == nil {
			return nil
		}

		if state.Dest == pb.RootMount {
			root := execMount(mountable)
			root.Selector = state.Selector
			materialized.Root = root
		} else {
			mount := execMount(mountable)
			dest := state.Dest
			if !utilsystem.IsAbs(filepath.Clean(dest), platform) {
				dest = filepath.Join("/", cwd, dest)
			}
			mount.Dest = dest
			mount.Readonly = state.Readonly
			mount.Selector = state.Selector
			materialized.Mounts = append(materialized.Mounts, mount)
		}

		materialized.States = append(materialized.States, state)
		return nil
	}

	rootState := &execMountState{
		Dest:        pb.RootMount,
		Selector:    "/",
		MountType:   pb.MountType_BIND,
		ApplyOutput: rootOutput,
	}
	if container.FS != nil {
		if rootfs, ok := container.FS.Peek(); ok && rootfs != nil {
			if selector, ok := rootfs.Dir.Peek(); ok && selector != "" {
				rootState.Selector = selector
			}
			if ref, ok := rootfs.Snapshot.Peek(); ok && ref != nil {
				rootState.SourceRef = ref
			}
		}
	}
	if err := materializeState(rootState); err != nil {
		return materialized, err
	}

	metaState := &execMountState{
		Dest:        engineutil.MetaMountDestPath,
		Selector:    "/",
		MountType:   pb.MountType_BIND,
		ApplyOutput: metaOutput,
	}
	if container.MetaSnapshot != nil {
		if metaRef, ok := container.MetaSnapshot.Peek(); ok && metaRef != nil {
			metaState.SourceRef = metaRef
		}
	}
	if err := materializeState(metaState); err != nil {
		return materialized, err
	}

	for i, ctrMount := range container.Mounts {
		mountState := &execMountState{
			Dest:      ctrMount.Target,
			MountType: pb.MountType_BIND,
			Readonly:  ctrMount.Readonly,
		}

		switch {
		case ctrMount.DirectorySource != nil:
			dir, ok := ctrMount.DirectorySource.Peek()
			if !ok || dir == nil {
				return materialized, fmt.Errorf("mount %d has nil directory source", i)
			}
			if selector, ok := dir.Dir.Peek(); ok {
				mountState.Selector = selector
			}
			ref, ok := dir.Snapshot.Peek()
			if !ok {
				return materialized, fmt.Errorf("failed to get directory snapshot for mount %d", i)
			}
			mountState.SourceRef = ref

		case ctrMount.FileSource != nil:
			file, ok := ctrMount.FileSource.Peek()
			if !ok || file == nil {
				return materialized, fmt.Errorf("mount %d has nil file source", i)
			}
			if selector, ok := file.File.Peek(); ok {
				mountState.Selector = selector
			}
			ref, ok := file.Snapshot.Peek()
			if !ok {
				return materialized, fmt.Errorf("failed to get file snapshot for mount %d", i)
			}
			mountState.SourceRef = ref

		case ctrMount.CacheSource != nil:
			cacheSrc := ctrMount.CacheSource
			if cacheSrc.Volume.Self() == nil {
				return materialized, fmt.Errorf("mount %d has nil cache volume source", i)
			}
			if err := EnsureBackingSnapshot(ctx, cacheSrc.Volume); err != nil {
				return materialized, fmt.Errorf("initialize cache volume snapshot for mount %d: %w", i, err)
			}
			cacheSnapshot := cacheSrc.Volume.Self().getSnapshot()
			if cacheSnapshot == nil {
				return materialized, fmt.Errorf("mount %d has nil cache volume snapshot", i)
			}
			mountState.SourceRef = cacheSnapshot
			mountState.Selector = cacheSrc.Volume.Self().getSnapshotSelector()

		case ctrMount.VolumeSource != nil:
			if ctrMount.VolumeSource.Volume.Self() == nil {
				return materialized, fmt.Errorf("mount %d has nil volume source", i)
			}
			mountState.Volume = &execVolumeMountConfig{
				Volume: ctrMount.VolumeSource.Volume,
			}

		case ctrMount.TmpfsSource != nil:
			mountState.MountType = pb.MountType_TMPFS
			mountState.TmpfsOpt = &pb.TmpfsOpt{
				Size_: int64(ctrMount.TmpfsSource.Size),
			}

		default:
			return materialized, fmt.Errorf("mount %d has no source", i)
		}

		if i < len(mountOutputs) {
			if output := mountOutputs[i]; output != nil && !mountState.Readonly {
				mountState.ApplyOutput = output
			}
		}
		if err := materializeState(mountState); err != nil {
			return materialized, err
		}
	}

	for _, secret := range container.Secrets {
		if secret.MountPath == "" {
			continue
		}
		uid, gid := 0, 0
		if secret.Owner != nil {
			uid, gid = secret.Owner.UID, secret.Owner.GID
		}
		secretState := &execMountState{
			Dest:      secret.MountPath,
			MountType: pb.MountType_SECRET,
			Secret: &execSecretMountConfig{
				Secret: secret.Secret,
				UID:    uid,
				GID:    gid,
				Mode:   secret.Mode,
			},
		}
		if err := materializeState(secretState); err != nil {
			return materialized, err
		}
	}

	for i, socket := range container.Sockets {
		if socket.ContainerPath == "" {
			return materialized, fmt.Errorf("unsupported socket %d: only unix paths are implemented", i)
		}
		uid, gid := 0, 0
		if socket.Owner != nil {
			uid, gid = socket.Owner.UID, socket.Owner.GID
		}
		socketState := &execMountState{
			Dest:      socket.ContainerPath,
			MountType: pb.MountType_SSH,
			SSH: &execSSHMountConfig{
				Socket: socket.Source,
				UID:    uid,
				GID:    gid,
				Mode:   0o600,
			},
		}
		if err := materializeState(socketState); err != nil {
			return materialized, err
		}
	}

	sort.Slice(materialized.Mounts, func(i, j int) bool {
		return materialized.Mounts[i].Dest < materialized.Mounts[j].Dest
	})

	return materialized, nil
}

func execMount(mountable bkcache.Mountable) executor.Mount {
	_, readonly := mountable.(bkcache.ImmutableRef)
	return executor.Mount{
		Src:      mountable,
		Readonly: readonly,
	}
}

func execTmpFSMountable(opt *pb.TmpfsOpt) bkcache.Mountable {
	return &execTmpFS{opt: opt}
}

type execTmpFS struct {
	opt *pb.TmpfsOpt
}

func (tmpfs *execTmpFS) Mount(_ context.Context, readonly bool) (bkcache.MountableRef, error) {
	return &execTmpFSMount{
		readonly: readonly,
		opt:      tmpfs.opt,
	}, nil
}

type execTmpFSMount struct {
	readonly bool
	opt      *pb.TmpfsOpt
}

func (tmpfs *execTmpFSMount) Mount() ([]ctrdmount.Mount, func() error, error) {
	options := []string{"nosuid"}
	if tmpfs.readonly {
		options = append(options, "ro")
	}
	if tmpfs.opt != nil && tmpfs.opt.Size_ > 0 {
		options = append(options, fmt.Sprintf("size=%d", tmpfs.opt.Size_))
	}
	return []ctrdmount.Mount{{
		Type:    "tmpfs",
		Source:  "tmpfs",
		Options: options,
	}}, func() error { return nil }, nil
}

func prepareExecSecretMount(ctx context.Context, cfg *execSecretMountConfig) (bkcache.Mountable, error) {
	if cfg == nil {
		return nil, fmt.Errorf("invalid secret mount options")
	}
	if cfg.Secret.Self() == nil {
		return nil, fmt.Errorf("secret mount missing secret")
	}

	data, err := cfg.Secret.Self().Plaintext(ctx)
	if err != nil {
		return nil, err
	}

	return &execSecretMount{
		uid:  cfg.UID,
		gid:  cfg.GID,
		mode: cfg.Mode,
		data: data,
	}, nil
}

type execSecretMount struct {
	uid  int
	gid  int
	mode fs.FileMode
	data []byte
}

func (secret *execSecretMount) Mount(_ context.Context, _ bool) (bkcache.MountableRef, error) {
	return &execSecretMountInstance{
		secret: secret,
	}, nil
}

type execSecretMountInstance struct {
	secret *execSecretMount
}

func (secret *execSecretMountInstance) Mount() ([]ctrdmount.Mount, func() error, error) {
	dir, err := os.MkdirTemp("", "dagger-secrets")
	if err != nil {
		return nil, nil, fmt.Errorf("failed to create temp dir: %w", err)
	}
	cleanupDir := func() error {
		return os.RemoveAll(dir)
	}

	if err := os.Chmod(dir, 0o711); err != nil {
		_ = cleanupDir()
		return nil, nil, err
	}

	var mountOpts []string
	if secret.secret.mode&0o111 == 0 {
		mountOpts = append(mountOpts, "noexec")
	}

	tmpMount := ctrdmount.Mount{
		Type:    "tmpfs",
		Source:  "tmpfs",
		Options: append([]string{"nodev", "nosuid", fmt.Sprintf("uid=%d,gid=%d", os.Geteuid(), os.Getegid())}, mountOpts...),
	}
	if userns.RunningInUserNS() {
		tmpMount.Options = nil
	}

	if err := ctrdmount.All([]ctrdmount.Mount{tmpMount}, dir); err != nil {
		_ = cleanupDir()
		return nil, nil, fmt.Errorf("unable to setup secret mount: %w", err)
	}

	cleanup := func() error {
		if err := ctrdmount.Unmount(dir, 0); err != nil {
			return err
		}
		return cleanupDir()
	}

	fp := filepath.Join(dir, rand.Text())
	if err := os.WriteFile(fp, secret.secret.data, 0o600); err != nil {
		_ = cleanup()
		return nil, nil, err
	}

	if err := os.Chown(fp, secret.secret.uid, secret.secret.gid); err != nil {
		_ = cleanup()
		return nil, nil, err
	}
	if err := os.Chmod(fp, secret.secret.mode&0o777); err != nil {
		_ = cleanup()
		return nil, nil, err
	}

	return []ctrdmount.Mount{{
		Type:    "bind",
		Source:  fp,
		Options: append([]string{"ro", "rbind", "nodev", "nosuid"}, mountOpts...),
	}}, cleanup, nil
}

func prepareExecSSHMount(cfg *execSSHMountConfig) (bkcache.Mountable, error) {
	if cfg == nil {
		return nil, fmt.Errorf("invalid ssh mount options")
	}
	if cfg.Socket.Self() == nil {
		return nil, fmt.Errorf("ssh mount missing socket")
	}

	return &execSSHMount{
		socket: cfg.Socket,
		uid:    cfg.UID,
		gid:    cfg.GID,
		mode:   cfg.Mode,
	}, nil
}

type execSSHMount struct {
	socket dagql.ObjectResult[*Socket]
	uid    int
	gid    int
	mode   fs.FileMode
}

func (ssh *execSSHMount) Mount(ctx context.Context, _ bool) (bkcache.MountableRef, error) {
	sock, cleanup, err := ssh.socket.Self().MountSSHAgent(ctx)
	if err != nil {
		return nil, err
	}
	return &execSSHMountInstance{
		ssh:     ssh,
		sock:    sock,
		cleanup: cleanup,
	}, nil
}

type execSSHMountInstance struct {
	ssh     *execSSHMount
	sock    string
	cleanup func() error
}

func (ssh *execSSHMountInstance) Mount() ([]ctrdmount.Mount, func() error, error) {
	if err := os.Chown(ssh.sock, ssh.ssh.uid, ssh.ssh.gid); err != nil {
		if ssh.cleanup != nil {
			_ = ssh.cleanup()
		}
		return nil, nil, err
	}
	if err := os.Chmod(ssh.sock, ssh.ssh.mode&0o777); err != nil {
		if ssh.cleanup != nil {
			_ = ssh.cleanup()
		}
		return nil, nil, err
	}
	release := func() error {
		if ssh.cleanup == nil {
			return nil
		}
		return ssh.cleanup()
	}

	return []ctrdmount.Mount{{
		Type:    "bind",
		Source:  ssh.sock,
		Options: []string{"rbind"},
	}}, release, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithExec(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	opts ContainerExecOpts,
	execMD *engineutil.ExecutionMetadata,
	moduleContext dagql.ObjectResult[*Module],
	functionCall *FunctionCall,
) error {
	state := &ContainerExecState{
		LazyState:      NewLazyState(),
		Parent:         parent,
		Opts:           opts,
		ExecMD:         execMD,
		ModuleContext:  moduleContext,
		FunctionCall:   functionCall,
		originalExecMD: copyExecInputMetadata(execMD),
	}
	container.Lazy = &ContainerExecLazy{State: state}
	container.ImageRef = ""
	container.MetaSnapshot = new(LazyAccessor[bkcache.ImmutableRef, *Container])
	container.FS = new(LazyAccessor[*Directory, *Container])

	for i, ctrMount := range container.Mounts {
		if ctrMount.Readonly {
			continue
		}
		switch {
		case ctrMount.DirectorySource != nil:
			ctrMount.DirectorySource = new(LazyAccessor[*Directory, *Container])
			container.Mounts[i] = ctrMount
		case ctrMount.FileSource != nil:
			ctrMount.FileSource = new(LazyAccessor[*File, *Container])
			container.Mounts[i] = ctrMount
		}
	}
	return nil
}

// evaluateOutputs runs the exec's joint output group: the one process
// run fills fs, execMeta, and every writable mount at once.
//
//nolint:dupl,gocyclo // symmetric with prepareMounts; sharing hurts readability of each phase
func (state *ContainerExecState) evaluateOutputs(ctx context.Context, container *Container) (rerr error) {
	if state == nil {
		return nil
	}

	return state.LazyState.EvaluateGroup(ctx, "Container.withExec", ContainerLazyGroupExecOutputs, func(ctx context.Context) (rerr error) {
		dagCache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		if container == nil {
			return fmt.Errorf("exec output container is nil")
		}
		// The run needs the parent's rootfs and every directory/file
		// mount materialized so they can be mounted; the parent's own
		// exec metadata is not among them and stays pending. This
		// container's metadata (args/env expansion, working directory,
		// secrets, sockets, services) is already settled by the
		// resolution phase before this body starts.
		runParts := []dagql.PartKey{ContainerPartFS}
		for i := range container.Mounts {
			mnt := &container.Mounts[i]
			if mnt.DirectorySource != nil || mnt.FileSource != nil {
				runParts = append(runParts, ContainerPartMount(mnt.Target))
			}
		}
		if err := dagCache.EvaluateParts(ctx, state.Parent, runParts...); err != nil {
			return err
		}

		parent := state.Parent.Self()
		if parent == nil {
			return fmt.Errorf("exec parent is nil")
		}
		// Run inputs are the parent's settled parts; outputs land in this
		// container's own accessors through the bindings below. The mount
		// list shape is this container's settled metadata (the exec does
		// not change it), with each snapshot source read from the
		// parent's mount at the same target.
		inputRootFS := parent.FS
		inputMounts, err := execInputMounts(container.Mounts, parent)
		if err != nil {
			return err
		}

		query, err := CurrentQuery(ctx)
		if err != nil {
			return fmt.Errorf("get current query: %w", err)
		}
		clientMetadata, err := engine.ClientMetadataFromContext(ctx)
		if err != nil {
			return fmt.Errorf("get current client metadata: %w", err)
		}
		releaseLockedCaches, err := lockMountedCaches(ctx, inputMounts)
		if err != nil {
			return err
		}
		defer releaseLockedCaches()

		// The resolved values stay local to this run (they feed
		// metaSpec.Env below). VolatileEnv itself is metadata delegated
		// from the parent: every downstream consumer reads names and
		// re-resolves against its own session, so the body writes only
		// its own group's parts.
		volatileEnvsFromSession := dagCache.ResolveVolatileVars(ctx, clientMetadata.SessionID)
		var volatileEnvs []string
		for _, k := range container.VolatileEnv {
			k = strings.SplitN(k, "=", 2)[0]
			if v, ok := volatileEnvsFromSession[k]; ok {
				volatileEnvs = append(volatileEnvs, fmt.Sprintf("%s=%s", k, v))
			}
		}

		secretEnv, err := container.secretEnvValues(ctx)
		if err != nil {
			return err
		}

		opts := state.Opts
		expandedArgs := make([]string, len(opts.Args))
		for i, arg := range opts.Args {
			expandedArg, err := ExpandContainerInput(container, arg, opts.Expand)
			if err != nil {
				return err
			}
			expandedArgs[i] = expandedArg
		}
		opts.Args = expandedArgs

		if opts.RedirectStdout != "" {
			path, err := resolveContainerInputPath(container, opts.RedirectStdout, opts.Expand)
			if err != nil {
				return err
			}
			opts.RedirectStdout = path
		}
		if opts.RedirectStderr != "" {
			path, err := resolveContainerInputPath(container, opts.RedirectStderr, opts.Expand)
			if err != nil {
				return err
			}
			opts.RedirectStderr = path
		}
		if opts.RedirectStdin != "" {
			path, err := resolveContainerInputPath(container, opts.RedirectStdin, opts.Expand)
			if err != nil {
				return err
			}
			opts.RedirectStdin = path
		}

		execMD, err := container.execMeta(ctx, opts, state.ExecMD, state.ModuleContext)
		if err != nil {
			return err
		}
		state.ExecMD = execMD

		cache := query.SnapshotManager()

		metaSpec, err := container.metaSpec(ctx, opts, volatileEnvs)
		if err != nil {
			return err
		}

		engineClient, err := query.Engine(ctx)
		if err != nil {
			return fmt.Errorf("failed to get engine client: %w", err)
		}
		// User-facing cause: the resolver runs on the call_exec twin's context, but
		// exec-error attribution must name a span frontends render.
		causeCtx := dagql.UserFacingSpanContext(ctx)

		rootOutputBinding := func(ref bkcache.ImmutableRef) error {
			dirPath := "/"
			platform := container.Platform
			services := slices.Clone(container.Services)
			if inputRootFS != nil {
				if rootfs, ok := inputRootFS.Peek(); ok && rootfs != nil {
					if path, ok := rootfs.Dir.Peek(); ok && path != "" {
						dirPath = path
					}
					platform = rootfs.Platform
					services = slices.Clone(rootfs.Services)
				}
			}
			output := &Directory{
				Platform: platform,
				Services: services,
				Dir:      new(LazyAccessor[string, *Directory]),
				Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
			}
			output.SetPath(dirPath)
			output.SetSnapshot(ref)
			if container.FS == nil {
				container.FS = new(LazyAccessor[*Directory, *Container])
			}
			container.FS.setValue(output)
			return nil
		}
		metaOutputBinding := func(ref bkcache.ImmutableRef) error {
			if container.MetaSnapshot == nil {
				container.MetaSnapshot = new(LazyAccessor[bkcache.ImmutableRef, *Container])
			}
			container.MetaSnapshot.setValue(ref)
			return nil
		}
		mountOutputBindings := make([]func(bkcache.ImmutableRef) error, len(container.Mounts))
		for i, ctrMount := range inputMounts {
			if ctrMount.Readonly {
				continue
			}
			switch {
			case ctrMount.DirectorySource != nil:
				inputDir, ok := ctrMount.DirectorySource.Peek()
				if !ok || inputDir == nil {
					return fmt.Errorf("exec directory mount %d is missing materialized input", i)
				}
				dirPath, _ := inputDir.Dir.Peek()
				platform := inputDir.Platform
				services := slices.Clone(inputDir.Services)
				idx := i
				mountOutputBindings[i] = func(ref bkcache.ImmutableRef) error {
					output := &Directory{
						Platform: platform,
						Services: slices.Clone(services),
						Dir:      new(LazyAccessor[string, *Directory]),
						Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
					}
					output.SetPath(dirPath)
					output.SetSnapshot(ref)
					if container.Mounts[idx].DirectorySource == nil {
						container.Mounts[idx].DirectorySource = new(LazyAccessor[*Directory, *Container])
					}
					container.Mounts[idx].DirectorySource.setValue(output)
					return nil
				}
			case ctrMount.FileSource != nil:
				inputFile, ok := ctrMount.FileSource.Peek()
				if !ok || inputFile == nil {
					return fmt.Errorf("exec file mount %d is missing materialized input", i)
				}
				filePath, _ := inputFile.File.Peek()
				platform := inputFile.Platform
				services := slices.Clone(inputFile.Services)
				idx := i
				mountOutputBindings[i] = func(ref bkcache.ImmutableRef) error {
					output := &File{
						Platform: platform,
						Services: slices.Clone(services),
						File:     new(LazyAccessor[string, *File]),
						Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
					}
					output.SetPath(filePath)
					output.SetSnapshot(ref)
					if container.Mounts[idx].FileSource == nil {
						container.Mounts[idx].FileSource = new(LazyAccessor[*File, *Container])
					}
					container.Mounts[idx].FileSource.setValue(output)
					return nil
				}
			}
		}

		var rootMount executor.Mount
		execMounts := []executor.Mount{}
		mountStates := []*execMountState{}
		releaseActives := func() error {
			var releaseErr error
			for i := len(mountStates) - 1; i >= 0; i-- {
				active := mountStates[i].ActiveRef
				if active == nil {
					continue
				}
				releaseErr = errors.Join(releaseErr, active.Release(context.WithoutCancel(ctx)))
				mountStates[i].ActiveRef = nil
			}
			return releaseErr
		}
		releaseOutputRefs := func() error {
			var releaseErr error
			for _, state := range mountStates {
				if state.OutputMutable != nil {
					releaseErr = errors.Join(releaseErr, state.OutputMutable.Release(context.WithoutCancel(ctx)))
					state.OutputMutable = nil
				}
				if state.OutputImmutable != nil {
					releaseErr = errors.Join(releaseErr, state.OutputImmutable.Release(context.WithoutCancel(ctx)))
					state.OutputImmutable = nil
				}
			}
			return releaseErr
		}
		applyOneOutput := func(state *execMountState) (rerr error) {
			if state.ApplyOutput == nil {
				return nil
			}
			outputCtx, outputOp := wcprof.BeginOp(ctx, wcprof.OpKindExecPhase, "withExec.applyOutput", wcprof.OpOpts{Ident: state.Dest})
			defer func() { outputOp.EndErr(rerr) }()
			if state.OutputMutable != nil {
				commitCtx, commitOp := wcprof.BeginOp(outputCtx, wcprof.OpKindExecPhase, "withExec.commitOutput", wcprof.OpOpts{Ident: state.Dest})
				committed, err := state.OutputMutable.Commit(commitCtx)
				commitOp.EndErr(err)
				if err != nil {
					return fmt.Errorf("error committing %s: %w", state.OutputMutable.ID(), err)
				}
				state.OutputMutable = nil
				state.OutputImmutable = committed
			}
			if state.OutputImmutable == nil {
				return nil
			}
			_, bindOp := wcprof.BeginOp(outputCtx, wcprof.OpKindExecPhase, "withExec.bindOutput", wcprof.OpOpts{Ident: state.Dest})
			err := state.ApplyOutput(state.OutputImmutable)
			bindOp.EndErr(err)
			if err != nil {
				return err
			}
			state.OutputImmutable = nil
			return nil
		}
		applyOutputs := func() error {
			for _, state := range mountStates {
				if err := applyOneOutput(state); err != nil {
					return err
				}
			}
			return nil
		}

		makeMutable := func(dest string, ref bkcache.ImmutableRef) (bkcache.MutableRef, error) {
			desc := fmt.Sprintf("mount %s from exec %s", dest, strings.Join(metaSpec.Args, " "))
			return cache.New(ctx, ref, bkcache.WithDescription(desc))
		}
		materializeState := func(state *execMountState) error {
			var mountable bkcache.Mountable
			if state.SourceRef != nil {
				mountable = state.SourceRef
			}

			if state.Volume != nil {
				mountable, err = prepareExecVolumeMount(ctx, state.Volume)
				if err != nil {
					return err
				}
			} else {
				switch state.MountType {
				case pb.MountType_BIND:
					if state.ApplyOutput != nil {
						if state.Readonly && state.SourceRef != nil && state.Dest != pb.RootMount {
							iref, ok := state.SourceRef.(bkcache.ImmutableRef)
							if !ok {
								return fmt.Errorf("mount %s readonly output needs immutable input, got %T", state.Dest, state.SourceRef)
							}
							reopened, err := cache.GetBySnapshotID(ctx, iref.SnapshotID(), bkcache.NoUpdateLastUsed)
							if err != nil {
								return err
							}
							state.OutputImmutable = reopened
						} else {
							iref, ok := state.SourceRef.(bkcache.ImmutableRef)
							if state.SourceRef != nil && !ok {
								return fmt.Errorf("mount %s writable output needs immutable input, got %T", state.Dest, state.SourceRef)
							}
							active, err := makeMutable(state.Dest, iref)
							if err != nil {
								return err
							}
							mountable = active
							state.OutputMutable = active
						}
					} else {
						if !state.Readonly && state.SourceRef != nil {
							if mutable, ok := state.SourceRef.(bkcache.MutableRef); ok {
								mountable = mutable
							} else {
								iref := state.SourceRef.(bkcache.ImmutableRef)
								active, err := makeMutable(state.Dest, iref)
								if err != nil {
									return err
								}
								mountable = active
								state.ActiveRef = active
							}
						} else if !state.Readonly || state.SourceRef == nil {
							var iref bkcache.ImmutableRef
							if state.SourceRef != nil {
								parsed, ok := state.SourceRef.(bkcache.ImmutableRef)
								if !ok {
									return fmt.Errorf("mount %s writable bind needs immutable or mutable input, got %T", state.Dest, state.SourceRef)
								}
								iref = parsed
							}
							active, err := makeMutable(state.Dest, iref)
							if err != nil {
								return err
							}
							mountable = active
							state.ActiveRef = active
						}
					}

				case pb.MountType_TMPFS:
					mountable = execTmpFSMountable(state.TmpfsOpt)

				case pb.MountType_SECRET:
					mountable, err = prepareExecSecretMount(ctx, state.Secret)
					if err != nil {
						return err
					}

				case pb.MountType_SSH:
					mountable, err = prepareExecSSHMount(state.SSH)
					if err != nil {
						return err
					}

				default:
					return fmt.Errorf("mount type %s not implemented", state.MountType)
				}
			}

			if state.Dest == pb.RootMount && state.Readonly && state.ApplyOutput == nil {
				if _, ok := mountable.(bkcache.MutableRef); !ok {
					var iref bkcache.ImmutableRef
					if state.SourceRef != nil {
						parsed, ok := state.SourceRef.(bkcache.ImmutableRef)
						if !ok {
							return fmt.Errorf("root mount readonly fallback needs immutable input, got %T", state.SourceRef)
						}
						iref = parsed
					}
					active, err := makeMutable(state.Dest, iref)
					if err != nil {
						return err
					}
					mountable = active
					state.ActiveRef = active
				}
			}

			if mountable == nil {
				return nil
			}

			if state.Dest == pb.RootMount {
				root := execMount(mountable)
				root.Selector = state.Selector
				rootMount = root
			} else {
				mount := execMount(mountable)
				dest := state.Dest
				if !utilsystem.IsAbs(filepath.Clean(dest), runtime.GOOS) {
					dest = filepath.Join("/", container.Config.WorkingDir, dest)
				}
				mount.Dest = dest
				mount.Readonly = state.Readonly
				mount.Selector = state.Selector
				execMounts = append(execMounts, mount)
			}

			mountStates = append(mountStates, state)
			return nil
		}
		failPrepare := func(err error) error {
			_ = releaseActives()
			_ = releaseOutputRefs()
			return fmt.Errorf("failed to prepare mounts: %w", err)
		}

		profPrepareStartNS := wcprof.NowNS()

		rootState := &execMountState{
			Dest:        pb.RootMount,
			Selector:    "/",
			MountType:   pb.MountType_BIND,
			ApplyOutput: rootOutputBinding,
		}
		if inputRootFS != nil {
			if rootfs, ok := inputRootFS.Peek(); ok && rootfs != nil {
				if selector, ok := rootfs.Dir.Peek(); ok && selector != "" {
					rootState.Selector = selector
				}
				ref, ok := rootfs.Snapshot.Peek()
				if !ok {
					return failPrepare(fmt.Errorf("parent rootfs should already be materialized after parent evaluation"))
				}
				rootState.SourceRef = ref
			}
		}
		if err := materializeState(rootState); err != nil {
			return failPrepare(err)
		}

		metaState := &execMountState{
			Dest:        engineutil.MetaMountDestPath,
			Selector:    "/",
			MountType:   pb.MountType_BIND,
			ApplyOutput: metaOutputBinding,
		}
		if err := materializeState(metaState); err != nil {
			return failPrepare(err)
		}

		for i, ctrMount := range inputMounts {
			mountState := &execMountState{
				Dest:      ctrMount.Target,
				MountType: pb.MountType_BIND,
				Readonly:  ctrMount.Readonly,
			}

			switch {
			case ctrMount.DirectorySource != nil:
				dir, ok := ctrMount.DirectorySource.Peek()
				if !ok || dir == nil {
					return failPrepare(fmt.Errorf("mount %d has nil directory source", i))
				}
				if selector, ok := dir.Dir.Peek(); ok {
					mountState.Selector = selector
				}
				ref, ok := dir.Snapshot.Peek()
				if !ok {
					return failPrepare(fmt.Errorf("parent directory mount %d should already be materialized after parent evaluation", i))
				}
				mountState.SourceRef = ref

			case ctrMount.FileSource != nil:
				file, ok := ctrMount.FileSource.Peek()
				if !ok || file == nil {
					return failPrepare(fmt.Errorf("mount %d has nil file source", i))
				}
				if selector, ok := file.File.Peek(); ok {
					mountState.Selector = selector
				}
				ref, ok := file.Snapshot.Peek()
				if !ok {
					return failPrepare(fmt.Errorf("parent file mount %d should already be materialized after parent evaluation", i))
				}
				mountState.SourceRef = ref

			case ctrMount.CacheSource != nil:
				cacheSrc := ctrMount.CacheSource
				if cacheSrc.Volume.Self() == nil {
					return failPrepare(fmt.Errorf("mount %d has nil cache volume source", i))
				}
				if err := EnsureBackingSnapshot(ctx, cacheSrc.Volume); err != nil {
					return failPrepare(fmt.Errorf("initialize cache volume snapshot for mount %d: %w", i, err))
				}
				cacheSnapshot := cacheSrc.Volume.Self().getSnapshot()
				if cacheSnapshot == nil {
					return failPrepare(fmt.Errorf("mount %d has nil cache volume snapshot", i))
				}
				mountState.SourceRef = cacheSnapshot
				mountState.Selector = cacheSrc.Volume.Self().getSnapshotSelector()

			case ctrMount.VolumeSource != nil:
				if ctrMount.VolumeSource.Volume.Self() == nil {
					return failPrepare(fmt.Errorf("mount %d has nil volume source", i))
				}
				mountState.Volume = &execVolumeMountConfig{
					Volume: ctrMount.VolumeSource.Volume,
				}

			case ctrMount.TmpfsSource != nil:
				mountState.MountType = pb.MountType_TMPFS
				mountState.TmpfsOpt = &pb.TmpfsOpt{
					Size_: int64(ctrMount.TmpfsSource.Size),
				}

			default:
				return failPrepare(fmt.Errorf("mount %d has no source", i))
			}

			if output := mountOutputBindings[i]; output != nil && !mountState.Readonly {
				mountState.ApplyOutput = output
			}
			if err := materializeState(mountState); err != nil {
				return failPrepare(err)
			}
		}

		for _, secret := range container.Secrets {
			if secret.MountPath == "" {
				continue
			}
			uid, gid := 0, 0
			if secret.Owner != nil {
				uid, gid = secret.Owner.UID, secret.Owner.GID
			}
			secretState := &execMountState{
				Dest:      secret.MountPath,
				MountType: pb.MountType_SECRET,
				Secret: &execSecretMountConfig{
					Secret: secret.Secret,
					UID:    uid,
					GID:    gid,
					Mode:   secret.Mode,
				},
			}
			if err := materializeState(secretState); err != nil {
				return failPrepare(err)
			}
		}

		for i, socket := range container.Sockets {
			if socket.ContainerPath == "" {
				return failPrepare(fmt.Errorf("unsupported socket %d: only unix paths are implemented", i))
			}
			uid, gid := 0, 0
			if socket.Owner != nil {
				uid, gid = socket.Owner.UID, socket.Owner.GID
			}
			socketState := &execMountState{
				Dest:      socket.ContainerPath,
				MountType: pb.MountType_SSH,
				SSH: &execSSHMountConfig{
					Socket: socket.Source,
					UID:    uid,
					GID:    gid,
					Mode:   0o600,
				},
			}
			if err := materializeState(socketState); err != nil {
				return failPrepare(err)
			}
		}

		sort.Slice(execMounts, func(i, j int) bool {
			return execMounts[i].Dest < execMounts[j].Dest
		})

		if wcprof.Enabled(ctx) {
			wcprof.RecordOp(ctx, wcprof.OpKindExecPhase, "withExec.prepareMounts", wcprof.OpOpts{}, profPrepareStartNS, wcprof.NowNS(), wcprof.OutcomeOK)
		}

		defer func() {
			_ = releaseActives()
			_ = releaseOutputRefs()
		}()

		defer func() {
			if rerr == nil {
				return
			}

			resolveFailureRef := func(state *execMountState) (bkcache.ImmutableRef, error) {
				switch {
				case state.OutputImmutable != nil:
					ref := state.OutputImmutable
					state.OutputImmutable = nil
					return ref, nil
				case state.OutputMutable != nil:
					iref, err := state.OutputMutable.Commit(ctx)
					if err != nil {
						return nil, fmt.Errorf("commit output ref %s: %w", state.OutputMutable.ID(), err)
					}
					state.OutputMutable = nil
					return iref, nil
				case state.ActiveRef != nil:
					iref, err := state.ActiveRef.Commit(ctx)
					if err != nil {
						return nil, fmt.Errorf("commit active ref %s: %w", state.ActiveRef.ID(), err)
					}
					state.ActiveRef = nil
					return iref, nil
				default:
					sourceRef, ok := state.SourceRef.(bkcache.ImmutableRef)
					if ok && sourceRef != nil {
						return cache.GetBySnapshotID(ctx, sourceRef.SnapshotID(), bkcache.NoUpdateLastUsed)
					}
					return nil, nil
				}
			}

			resolvedRefs := []bkcache.ImmutableRef{}
			trackResolvedRef := func(ref bkcache.ImmutableRef) bkcache.ImmutableRef {
				if ref != nil {
					resolvedRefs = append(resolvedRefs, ref)
				}
				return ref
			}
			untrackResolvedRef := func(target bkcache.ImmutableRef) {
				for i, ref := range resolvedRefs {
					if ref == target {
						resolvedRefs = append(resolvedRefs[:i], resolvedRefs[i+1:]...)
						return
					}
				}
			}
			releaseResolvedRefs := func() {
				for _, ref := range resolvedRefs {
					if ref == nil {
						continue
					}
					_ = ref.Release(context.WithoutCancel(ctx))
				}
			}
			defer releaseResolvedRefs()

			var metaRef bkcache.ImmutableRef
			resolveAndTrackFailureRef := func(state *execMountState) (bkcache.ImmutableRef, error) {
				ref, err := resolveFailureRef(state)
				if err != nil {
					return nil, err
				}
				return trackResolvedRef(ref), nil
			}
			for _, mountState := range mountStates {
				keepRef := mountState.Dest == engineutil.MetaMountDestPath
				if !keepRef {
					continue
				}
				ref, err := resolveAndTrackFailureRef(mountState)
				if err != nil {
					rerr = errors.Join(rerr, err)
					continue
				}
				if ref == nil {
					continue
				}
				if mountState.Dest == engineutil.MetaMountDestPath {
					metaRef = ref
				}
			}

			// A bound service exiting is the primary failure. Don't turn it into an
			// ExecError for the command we canceled in response, or the user sees the
			// command's forced exit code instead of the service failure.
			serviceBindingExited := isServiceBindingExitError(rerr)

			execMDPresent := execMD != nil
			execInternal := false
			hasMetaSpec := metaSpec != nil
			if execMDPresent {
				execInternal = execMD.Internal
			}
			if !serviceBindingExited &&
				engineClient.Interactive &&
				execMDPresent &&
				!execInternal &&
				hasMetaSpec {
				var callID *call.ID
				var callDig digest.Digest
				if curCall := dagql.CurrentCall(ctx); curCall != nil {
					dagqlCache, err := dagql.EngineCache(ctx)
					if err != nil {
						rerr = fmt.Errorf("get dagql cache for terminal exec error: %w", err)
						return
					}
					callID, err = dagqlCache.RecipeIDForCall(ctx, curCall)
					if err != nil {
						rerr = fmt.Errorf("rebuild recipe ID for terminal exec error: %w", err)
						return
					}
					// Failed interactive execs spawn a throwaway terminal service.
					// The service manager needs a digest-shaped key for hostname/log
					// plumbing, but it must not participate in DAG/content identity.
					callDig = digest.FromString(rand.Text())
				}
				meta := *metaSpec
				meta.Args = []string{"/bin/sh"}
				if len(engineClient.InteractiveCommand) > 0 {
					meta.Args = engineClient.InteractiveCommand
				}
				var terminalContainer *Container
				terminalContainerNeedsRelease := false
				defer func() {
					if terminalContainerNeedsRelease && terminalContainer != nil {
						_ = terminalContainer.OnRelease(context.WithoutCancel(ctx))
					}
				}()
				terminalContainer, err = cloneContainerForTerminal(ctx, query, container)
				if err != nil {
					rerr = fmt.Errorf("clone terminal container: %w", err)
					return
				}
				terminalContainer.FS, err = cloneTerminalDirectorySource(ctx, query, inputRootFS)
				if err != nil {
					rerr = fmt.Errorf("clone terminal rootfs source: %w", err)
					return
				}
				terminalContainer.Mounts, err = cloneTerminalMounts(ctx, query, inputMounts)
				if err != nil {
					rerr = fmt.Errorf("clone terminal mounts: %w", err)
					return
				}
				if metaRef != nil {
					terminalMetaRef, err := query.SnapshotManager().GetBySnapshotID(
						ctx,
						metaRef.SnapshotID(),
						bkcache.NoUpdateLastUsed,
					)
					if err != nil {
						rerr = fmt.Errorf("reopen meta snapshot for terminal: %w", err)
						return
					}
					trackResolvedRef(terminalMetaRef)
					if terminalContainer.MetaSnapshot == nil {
						terminalContainer.MetaSnapshot = new(LazyAccessor[bkcache.ImmutableRef, *Container])
					}
					terminalContainer.MetaSnapshot.setValue(terminalMetaRef)
					untrackResolvedRef(terminalMetaRef)
					terminalContainerNeedsRelease = true
				}
				if len(mountStates) >= 1 {
					rootRef, err := resolveAndTrackFailureRef(mountStates[0])
					if err != nil {
						rerr = fmt.Errorf("resolve failed rootfs for terminal: %w", err)
						return
					}
					if rootRef != nil {
						rootDirPath := "/"
						rootPlatform := terminalContainer.Platform
						rootServices := slices.Clone(terminalContainer.Services)
						if inputRootFS != nil {
							if rootfs, ok := inputRootFS.Peek(); ok && rootfs != nil {
								if path, ok := rootfs.Dir.Peek(); ok && path != "" {
									rootDirPath = path
								}
								rootPlatform = rootfs.Platform
								rootServices = slices.Clone(rootfs.Services)
							}
						}
						rootDir := &Directory{
							Platform: rootPlatform,
							Services: rootServices,
							Dir:      new(LazyAccessor[string, *Directory]),
							Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
						}
						rootDir.SetPath(rootDirPath)
						rootDir.SetSnapshot(rootRef)
						untrackResolvedRef(rootRef)
						if terminalContainer.FS == nil {
							terminalContainer.FS = new(LazyAccessor[*Directory, *Container])
						}
						terminalContainer.FS.setValue(rootDir)
						terminalContainerNeedsRelease = true
					}
				}
				for i, ctrMount := range inputMounts {
					stateIdx := i + 2
					if stateIdx >= len(mountStates) {
						break
					}
					mountRef, err := resolveAndTrackFailureRef(mountStates[stateIdx])
					if err != nil {
						rerr = fmt.Errorf("resolve failed mount %d for terminal: %w", i, err)
						return
					}
					if mountRef == nil {
						continue
					}
					terminalMount, ok := terminalFailureMount(terminalContainer.Mounts[i], ctrMount, mountRef)
					if !ok {
						continue
					}
					untrackResolvedRef(mountRef)
					terminalContainer.Mounts[i] = terminalMount
					terminalContainerNeedsRelease = true
				}
				srv, err := CurrentDagqlServer(ctx)
				if err != nil {
					rerr = err
					return
				}
				terminalContainerRes, err := newSyntheticTerminalContainerResult(srv, terminalContainer, "terminal_exec_error_container")
				if err != nil {
					rerr = err
					return
				}
				if err := terminalContainer.TerminalExecError(ctx, callID, callDig, terminalContainerRes, execMD, &meta, rerr); err != nil {
					rerr = err
					return
				}
				terminalContainerNeedsRelease = false
			}

			if !serviceBindingExited {
				var existingExecErr *ExecError
				if !errors.As(rerr, &existingExecErr) {
					execErr, ok, err := execErrorFromMetaRef(ctx, engineClient, causeCtx, rerr, metaSpec, metaRef)
					if err != nil {
						rerr = errors.Join(err, rerr)
						return
					}
					if ok {
						rerr = execErr
					}
				}
			}
		}()
		emu, err := getEmulator(ctx, specs.Platform(container.Platform))
		if err != nil {
			return err
		}
		// Capture the resolved user command for wall-clock profiling here, BEFORE
		// any engine shim wraps it: the QEMU emulator prepended just below for
		// emulated execs, and the executor's /.init prepended later. A capture below
		// either shim would headline the shim instead of the user's real program
		// (e.g. "go build"), exactly backwards on the slowest, highest-value
		// (emulated) execs. This is unconditional and must stay OUTSIDE the
		// `if emu != nil` block so the common non-emulated withExec is captured too.
		// metaSpec.Args is the fully-resolved command (entrypoint + args); execMD is
		// the same in-process pointer the executor reads, so both profile sources see
		// one identical value. ProfArgs is json:"-", so this cannot perturb a cache key.
		if execMD != nil {
			execMD.ProfArgs = slices.Clone(metaSpec.Args)
			// Same in-process pattern: the executor needs the user-facing span
			// for the container's traceparent injection, and only core still
			// knows it here — the executor runs on a detached execution
			// context that does not carry this ctx's mark (see
			// ExecutionMetadata.UserFacingSpanCtx).
			execMD.UserFacingSpanCtx = dagql.UserFacingSpanContext(ctx)
			// Same in-process pattern; a module runtime's parent metadata
			// already names the function call instead.
			SetExecutionIdentity(ctx, execMD)
			// A function runtime's exec carries its own call and keeps its
			// span; an API exec run for a call that set a process span, such
			// as a module entrypoint's module process, reports to that call.
			if state.FunctionCall == nil {
				if fnCall, err := query.CurrentFunctionCall(ctx); err == nil && fnCall.ProcessSpanContext().IsValid() {
					execMD.UserFacingSpanCtx = fnCall.ProcessSpanContext()
				}
			}
		}
		if emu != nil {
			metaSpec.Args = append([]string{engineutil.DaggerQemuEmulatorMountPoint}, metaSpec.Args...)
			execMounts = append(execMounts, executor.Mount{
				Readonly: true,
				Src:      emu,
				Dest:     engineutil.DaggerQemuEmulatorMountPoint,
			})
		}

		meta := *metaSpec
		meta.Env = slices.Clone(meta.Env)
		meta.Env = append(meta.Env, secretEnv...)

		svcs, err := query.Services(ctx)
		if err != nil {
			return fmt.Errorf("failed to get services: %w", err)
		}
		detach, runningSvcs, err := svcs.StartBindings(ctx, container.Services)
		if err != nil {
			return err
		}
		defer detach()

		// Same in-process pattern as ProfArgs above: the FQDN a bound service
		// actually registered under is only known once it is running, which is
		// after every execMD digest is computed. execMD is the same pointer the
		// executor reads, so recording it here reaches the hosts-file setup
		// without perturbing a cache key.
		recordBoundServiceFQDNs(execMD, container.Services, runningSvcs)

		execCtx := ctx
		var cancelExec context.CancelCauseFunc
		var serviceErrCh <-chan error
		stopServiceMonitors := func() {}
		if len(runningSvcs) > 0 {
			execCtx, cancelExec = context.WithCancelCause(ctx)
			serviceErrCh, stopServiceMonitors = monitorServiceBindings(ctx, container.Services, runningSvcs, cancelExec)
			defer cancelExec(nil)
			defer stopServiceMonitors()
		}

		var nestedClientMetadata *engine.ClientMetadata
		if opts.ExperimentalPrivilegedNesting {
			nestedClientMetadata = &engine.ClientMetadata{
				ClientID:              rand.Text(),
				ClientVersion:         engine.Version,
				SessionID:             clientMetadata.SessionID,
				AllowedLLMModules:     slices.Clone(clientMetadata.AllowedLLMModules),
				UseRecipeIDsByDefault: execMD != nil && execMD.UseRecipeIDsByDefault,
			}
		}

		procInfo := executor.ProcessInfo{Meta: meta}
		if opts.Stdin != "" {
			procInfo.Stdin = io.NopCloser(strings.NewReader(opts.Stdin))
		}

		execErrCh := make(chan error, 1)
		go func() {
			container.recordPartDiagnostic("execRun", "")
			execErrCh <- engineClient.Run(
				execCtx,
				"",
				rootMount,
				execMounts,
				procInfo,
				nil,
				causeCtx,
				execMD,
				clientMetadata.SessionID,
				clientMetadata.ClientID,
				nestedClientMetadata,
				state.ModuleContext,
				state.FunctionCall,
			)
		}()

		// NB: no explicit wcprof wait is recorded for the exec itself: the
		// executor's exec.run op is a child of the current op (ctx flows into
		// the goroutine), which both subtracts it from self-time and gives
		// the simulation an exact join. Ident-based waits were tried first and
		// can mis-resolve when call digests are shared across execs.
		var execErr error
		select {
		case execErr = <-execErrCh:
			if execErr != nil {
				select {
				case serviceErr := <-serviceErrCh:
					if serviceErr != nil {
						execErr = serviceErr
					}
				default:
				}
			}
		case serviceErr := <-serviceErrCh:
			if serviceErr == nil {
				serviceErr = fmt.Errorf("bound service exited")
			}
			execErr = serviceErr
			if cancelExec != nil {
				cancelExec(serviceErr)
			}
			<-execErrCh
		}
		stopServiceMonitors()

		var invalidateErr error
		for i, ctrMount := range inputMounts {
			if ctrMount.Readonly || ctrMount.CacheSource == nil || ctrMount.CacheSource.Volume.Self() == nil {
				continue
			}
			if err := ctrMount.CacheSource.Volume.Self().invalidateSnapshotSize(ctx); err != nil {
				invalidateErr = errors.Join(invalidateErr, fmt.Errorf("invalidate cache mount %d size: %w", i, err))
			}
		}

		if execErr != nil {
			slog.Warn("process did not complete successfully",
				"process", strings.Join(metaSpec.Args, " "),
				"error", execErr)
			if invalidateErr != nil {
				return errors.Join(execErr, invalidateErr)
			}
			return execErr
		}
		if invalidateErr != nil {
			return invalidateErr
		}
		profApplyStartNS := wcprof.NowNS()
		applyErr := applyOutputs()
		if wcprof.Enabled(ctx) {
			outcome := wcprof.OutcomeOK
			if applyErr != nil {
				outcome = wcprof.OutcomeError
			}
			wcprof.RecordOp(ctx, wcprof.OpKindExecPhase, "withExec.applyOutputs", wcprof.OpOpts{}, profApplyStartNS, wcprof.NowNS(), outcome)
		}
		if applyErr != nil {
			return applyErr
		}
		return nil
	})
}

// terminalFailureMount returns the terminal container's mount for a writable
// input mount, showing the failed exec's output in place of the input.
//
// It always installs a new accessor on the terminal's own mount. The input
// mount's accessors belong to the exec's parent container (see
// execInputMounts), which is a cached result: writing the output through them
// would point that cached container at a snapshot only the failed operation
// holds, so once it is collected the next exec from the cached container finds
// its mount gone, and until then it silently mounts the failed output.
func terminalFailureMount(terminalMount, inputMount ContainerMount, outputRef bkcache.ImmutableRef) (ContainerMount, bool) {
	switch {
	case inputMount.DirectorySource != nil && !inputMount.Readonly:
		inputDir, ok := inputMount.DirectorySource.Peek()
		if !ok || inputDir == nil {
			return terminalMount, false
		}
		dirPath, _ := inputDir.Dir.Peek()
		outputDir := &Directory{
			Platform: inputDir.Platform,
			Services: slices.Clone(inputDir.Services),
			Dir:      new(LazyAccessor[string, *Directory]),
			Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
		}
		outputDir.SetPath(dirPath)
		outputDir.SetSnapshot(outputRef)
		terminalMount.DirectorySource = new(LazyAccessor[*Directory, *Container])
		terminalMount.DirectorySource.setValue(outputDir)
		return terminalMount, true
	case inputMount.FileSource != nil && !inputMount.Readonly:
		inputFile, ok := inputMount.FileSource.Peek()
		if !ok || inputFile == nil {
			return terminalMount, false
		}
		filePath, _ := inputFile.File.Peek()
		outputFile := &File{
			Platform: inputFile.Platform,
			Services: slices.Clone(inputFile.Services),
			File:     new(LazyAccessor[string, *File]),
			Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
		}
		outputFile.SetPath(filePath)
		outputFile.SetSnapshot(outputRef)
		terminalMount.FileSource = new(LazyAccessor[*File, *Container])
		terminalMount.FileSource.setValue(outputFile)
		return terminalMount, true
	}
	return terminalMount, false
}

// execInputMounts pairs this container's settled mount list shape with
// the parent's snapshot source accessors: the run mounts the parent's
// parts, while output bindings write this container's own accessors.
func execInputMounts(mounts ContainerMounts, parent *Container) (ContainerMounts, error) {
	inputs := make(ContainerMounts, len(mounts))
	for i, mnt := range mounts {
		in := mnt
		if mnt.DirectorySource != nil || mnt.FileSource != nil {
			parentMnt := parent.mountAt(mnt.Target)
			if parentMnt == nil {
				return nil, fmt.Errorf("exec input mount %q has no parent mount", mnt.Target)
			}
			in.DirectorySource = parentMnt.DirectorySource
			in.FileSource = parentMnt.FileSource
		}
		inputs[i] = in
	}
	return inputs, nil
}

func decodePersistedContainerExecLazy(
	ctx context.Context,
	dec *dagql.PersistDecodeContext,
	payload json.RawMessage,
) (Lazy[*Container], error) {
	var persisted persistedContainerExecLazy
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted container withExec lazy payload: %w", err)
	}
	if persisted.VolatileCacheHitParentResultID != 0 {
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.VolatileCacheHitParentResultID, "container volatile exec cache hit parent")
		if err != nil {
			return nil, err
		}
		return &ContainerVolatileExecCacheHitLazy{
			LazyState:   NewLazyState(),
			Parent:      parent,
			VolatileEnv: slices.Clone(persisted.VolatileCacheHitVolatileEnv),
		}, nil
	}
	parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container exec parent")
	if err != nil {
		return nil, err
	}
	moduleContext, err := loadPersistedObjectResultByResultID[*Module](ctx, dec, persisted.ModuleContextResultID, "container exec module context")
	if err != nil {
		return nil, err
	}
	state := &ContainerExecState{
		LazyState:      NewLazyState(),
		Parent:         parent,
		Opts:           persisted.Opts,
		ExecMD:         persisted.ExecMD,
		ModuleContext:  moduleContext,
		originalExecMD: copyExecInputMetadata(persisted.ExecMD),
	}
	return &ContainerExecLazy{State: state}, nil
}

func addDefaultEnvvar(env []string, k, v string) []string {
	for _, e := range env {
		if strings.HasPrefix(e, k+"=") {
			return env
		}
	}
	return append(env, k+"="+v)
}

func (container *Container) Stdout(ctx context.Context) (string, error) {
	return container.metaFileContents(ctx, engineutil.MetaMountStdoutPath)
}

func (container *Container) Stderr(ctx context.Context) (string, error) {
	return container.metaFileContents(ctx, engineutil.MetaMountStderrPath)
}

func (container *Container) CombinedOutput(ctx context.Context) (string, error) {
	return container.metaFileContents(ctx, engineutil.MetaMountCombinedOutputPath)
}

func (container *Container) ExitCode(ctx context.Context) (int, error) {
	contents, err := container.metaFileContents(ctx, engineutil.MetaMountExitCodePath)
	if err != nil {
		return 0, err
	}
	contents = strings.TrimSpace(contents)

	code, err := strconv.ParseInt(contents, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("could not parse exit code %q: %w", contents, err)
	}

	return int(code), nil
}

func (container *Container) metaFileContents(ctx context.Context, filePath string) (string, error) {
	if err := container.evaluatePartsDirect(ctx, ContainerPartExecMeta); err != nil {
		return "", err
	}

	if container.MetaSnapshot == nil {
		return "", ErrNoCommand
	}
	metaSnapshot, ok := container.MetaSnapshot.Peek()
	if !ok || metaSnapshot == nil {
		return "", ErrNoCommand
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return "", err
	}
	reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, metaSnapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
	if err != nil {
		return "", err
	}
	defer func() {
		_ = reopened.Release(context.WithoutCancel(ctx))
	}()

	var content []byte
	err = MountRef(ctx, reopened, func(root string, _ *ctrdmount.Mount) error {
		fullPath, err := containerdfs.RootPath(root, filePath)
		if err != nil {
			return err
		}
		content, err = os.ReadFile(fullPath)
		if err != nil {
			return TrimErrPathPrefix(err, root)
		}
		return nil
	}, mountRefAsReadOnly)
	if err != nil {
		if errors.Is(err, errEmptyResultRef) {
			return "", ErrNoCommand
		}
		if errors.Is(err, os.ErrNotExist) {
			return "", ErrNoCommand
		}
		return "", err
	}
	return string(content), nil
}
