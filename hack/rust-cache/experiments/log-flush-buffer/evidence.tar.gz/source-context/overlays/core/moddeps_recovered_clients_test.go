package core

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"testing"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	"github.com/dagger/dagger/engine"
	"github.com/stretchr/testify/require"
)

type recoveredSchemaTestMod struct {
	Mod
	installs atomic.Int32
	fields   int
}

func (*recoveredSchemaTestMod) Name() string            { return "recovered" }
func (*recoveredSchemaTestMod) View() (call.View, bool) { return "", false }
func (m *recoveredSchemaTestMod) Install(ctx context.Context, dag *dagql.Server, _ ...InstallOpts) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.installs.Add(1)
	fields := make(dagql.Fields[*Query], m.fields)
	for i := range fields {
		fields[i] = dagql.Func(fmt.Sprintf("marker%d", i), func(_ context.Context, root *Query, _ struct{}) (dagql.String, error) {
			marker, ok := root.ConstructorArgs["marker"].(dagql.String)
			if !ok {
				return "", fmt.Errorf("query root lost its constructor arguments")
			}
			return marker, nil
		}).DoNotCache("Read this client's query root.")
	}
	fields.Install(dag)
	return nil
}

type recoveredSchemaTestServer struct {
	*mockServer
	dag      *dagql.Server
	mod      *recoveredSchemaTestMod
	clients  map[string]*SchemaBuilderMemo
	sessions map[string]*SchemaBuilderMemo
}

func (s *recoveredSchemaTestServer) DefaultDeps(ctx context.Context) (*SchemaBuilder, error) {
	root, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	return NewSchemaBuilder(root, []Mod{s.mod}), nil
}

func (s *recoveredSchemaTestServer) SchemaBuilderMemo(ctx context.Context) (*SchemaBuilderMemo, error) {
	md, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return nil, err
	}
	return s.clients[md.ClientID], nil
}

func (s *recoveredSchemaTestServer) SessionSchemaBuilderMemo(ctx context.Context) (*SchemaBuilderMemo, error) {
	md, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return nil, err
	}
	return s.sessions[md.SessionID], nil
}

func (s *recoveredSchemaTestServer) Server(context.Context) (*dagql.Server, error) {
	return s.dag, nil
}

func recoveredSchemaFixture(t testing.TB, fields int) (*recoveredSchemaTestServer, context.Context) {
	t.Helper()
	cache, err := dagql.NewCache(t.Context(), "", nil, nil)
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, cache.Close(context.Background())) })
	ctx := dagql.ContextWithCache(t.Context(), cache)
	server := &recoveredSchemaTestServer{
		mockServer: &mockServer{}, mod: &recoveredSchemaTestMod{fields: fields},
		clients: map[string]*SchemaBuilderMemo{}, sessions: map[string]*SchemaBuilderMemo{},
	}
	server.dag, err = dagql.NewServer(ctx, &Query{Server: server})
	require.NoError(t, err)
	return server, ctx
}

func recoverClientSchema(ctx context.Context, root *Query, client, session string) (*dagql.Server, error) {
	ctx = ContextWithQuery(ctx, root)
	ctx = engine.ContextWithClientMetadata(ctx, &engine.ClientMetadata{ClientID: client, SessionID: session})
	deps, err := root.ModDepsForCall(ctx, &dagql.ResultCall{
		Field: "marker0", Type: dagql.NewResultCallType(dagql.String("").Type()),
	})
	if err != nil {
		return nil, err
	}
	return deps.Schema(ctx)
}

// Loading values in different clients must not reinstall the same module set.
// The resulting servers still use each client's own root and constructor input.
func TestRecoveredSchemasShareInstallationAcrossClients(t *testing.T) {
	server, ctx := recoveredSchemaFixture(t, 1)
	server.sessions["first"] = NewSchemaBuilderMemo()
	server.sessions["second"] = NewSchemaBuilderMemo()
	const clients = 8
	var roots [clients]*Query
	var schemas [clients]*dagql.Server
	var errs [clients]error
	for i := range clients {
		server.clients[fmt.Sprint(i)] = NewSchemaBuilderMemo()
		roots[i] = &Query{Server: server, ConstructorArgs: map[string]dagql.Input{"marker": dagql.NewString(fmt.Sprint(i))},
			hostHistory: &hostHistoryRegistry{}, cacheVolumeStore: &cacheVolumeStore{}}
	}
	var wg sync.WaitGroup
	for i := range clients {
		wg.Go(func() { schemas[i], errs[i] = recoverClientSchema(ctx, roots[i], fmt.Sprint(i), "first") })
	}
	wg.Wait()
	for i := range clients {
		require.NoError(t, errs[i])
		require.Same(t, roots[i], schemas[i].Root().Unwrap())
		callCtx := ContextWithQuery(ctx, roots[i])
		callCtx = engine.ContextWithClientMetadata(callCtx, &engine.ClientMetadata{ClientID: fmt.Sprint(i), SessionID: "first"})
		var marker dagql.String
		require.NoError(t, schemas[i].Select(callCtx, schemas[i].Root(), &marker, dagql.Selector{Field: "marker0"}))
		require.Equal(t, dagql.NewString(fmt.Sprint(i)), marker)
		again, err := recoverClientSchema(ctx, roots[i], fmt.Sprint(i), "first")
		require.NoError(t, err)
		require.Same(t, schemas[i], again)
	}
	require.EqualValues(t, 1, server.mod.installs.Load(), "one installation for the session's module set")
	for _, template := range server.sessions["first"].builders {
		require.Nil(t, template.root.ConstructorArgs)
		require.Nil(t, template.root.hostHistory, "the shared registry must retain no client capabilities")
		require.Nil(t, template.root.cacheVolumeStore)
	}
	server.clients["later"] = NewSchemaBuilderMemo()
	_, err := recoverClientSchema(ctx, &Query{Server: server}, "later", "second")
	require.NoError(t, err)
	require.EqualValues(t, 2, server.mod.installs.Load(), "another session installs independently")
}

func BenchmarkRecoveredModuleSchemas(b *testing.B) {
	server, ctx := recoveredSchemaFixture(b, 128)
	const clients = 64
	b.ReportAllocs()
	for b.Loop() {
		server.sessions["bench"] = NewSchemaBuilderMemo()
		for i := range clients {
			id := fmt.Sprint(i)
			server.clients[id] = NewSchemaBuilderMemo()
			_, err := recoverClientSchema(ctx, &Query{Server: server}, id, "bench")
			require.NoError(b, err)
		}
	}
}
