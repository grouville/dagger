package dangshared

import (
	"context"
	"net/http"
	"strconv"

	"github.com/Khan/genqlient/graphql"
	"github.com/dagger/dagger/engine/wcprof"
)

// Installed only for a recorded invocation. Keep the real HTTP client, request,
// response and errors; measure the caller's complete API wait in its context.
type profiledNestedClient struct {
	graphql.Client
}

func (client profiledNestedClient) MakeRequest(ctx context.Context, req *graphql.Request, resp *graphql.Response) error {
	ctx, op := wcprof.BeginOp(ctx, wcprof.OpKindInternal, "dang.apiRequest", wcprof.OpOpts{})
	err := client.Client.MakeRequest(ctx, req, resp)
	op.EndErr(err)
	return err
}

// This header crosses only the invocation's private loopback connection.
const nestedProfileParentHeader = "Dagger-Wcprof-Parent"

type profiledNestedTransport struct{ http.RoundTripper }

func (transport profiledNestedTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	if parent := wcprof.CurrentOpID(req.Context()); parent != 0 {
		req = req.Clone(req.Context())
		req.Header.Set(nestedProfileParentHeader, strconv.FormatUint(parent, 10))
	}
	return transport.RoundTripper.RoundTrip(req)
}

type profiledNestedHandler struct{ http.Handler }

func (handler profiledNestedHandler) ServeHTTP(w http.ResponseWriter, req *http.Request) {
	if parent, err := strconv.ParseUint(req.Header.Get(nestedProfileParentHeader), 10, 64); err == nil && parent != 0 {
		ctx := wcprof.ContextWithProfiling(req.Context())
		req = req.WithContext(wcprof.ContextWithOpID(ctx, parent))
	}
	next := handler.Handler
	if next == nil {
		next = http.DefaultServeMux
	}
	next.ServeHTTP(w, req)
}
