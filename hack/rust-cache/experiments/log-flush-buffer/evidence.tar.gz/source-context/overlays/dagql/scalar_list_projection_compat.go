package dagql

type valueEnumerable interface {
	Enumerable
	valueEnumerable()
}

func (Array[T]) valueEnumerable()           {}
func (DynamicArrayOutput) valueEnumerable() {}

var _ valueEnumerable = Array[String]{}
var _ valueEnumerable = DynamicArrayOutput{}

func leafValue(elem Typed) Typed {
	if elem == nil {
		return nil
	}
	if derefable, ok := elem.(Derefable); ok {
		inner, valid := derefable.Deref()
		if !valid {
			return nil
		}
		if inner != nil {
			return inner
		}
	}
	return elem
}
