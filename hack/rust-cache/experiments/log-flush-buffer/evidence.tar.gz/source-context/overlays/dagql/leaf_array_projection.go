package dagql

import (
	"context"
	"fmt"
	"github.com/dagger/dagger/engine"
)

// The upstream leaf renderer reads plain values without per-item identities.
// Retain this diagnostic engine's existing bound-session checks around it.
func projectLeafArray(ctx context.Context, parent AnyResult, values valueEnumerable) (output []any, rerr error) {
	if shared := parent.cacheSharedResult(); shared != nil && shared.id != 0 {
		md, err := engine.ClientMetadataFromContext(ctx)
		if err != nil {
			return nil, err
		}
		if md.SessionID == "" {
			return nil, fmt.Errorf("serialize leaf array: empty session ID")
		}
		cache, err := EngineCache(ctx)
		if err != nil {
			return nil, err
		}
		op, err := cache.beginSessionOperation(md.SessionID)
		if err != nil {
			return nil, err
		}
		cache.egraphMu.RLock()
		generation := shared.requiredSessionResourcesGen.Load()
		bound := cache.sessionSatisfiesResourceRequirementsLocked(md.SessionID, shared)
		cache.egraphMu.RUnlock()
		defer func() {
			if rerr == nil && !cache.sessionStillSatisfiesResourceRequirements(md.SessionID, shared, generation) {
				output = nil
				rerr = fmt.Errorf("serialize leaf array: session %q has not bound the required resources", md.SessionID)
			}
			if op.finish(rerr == nil) {
				output = nil
				rerr = fmt.Errorf("serialize leaf array: %w", ErrCacheSessionReleased)
			}
		}()
		if !bound {
			return nil, fmt.Errorf("serialize leaf array: session %q has not bound the required resources", md.SessionID)
		}
	}

	output = make([]any, values.Len())
	for nth := 1; nth <= len(output); nth++ {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		value, err := values.Nth(nth)
		if err != nil {
			return nil, fmt.Errorf("nth %d: %w", nth, err)
		}
		output[nth-1] = leafValue(value)
	}
	return output, nil
}
