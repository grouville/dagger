package dagql

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync"
	"sync/atomic"
	"time"
)

var compactionDigestSetsReuseEnabled atomic.Bool
var compactionDigestSetsRecord atomic.Bool
var compactionDigestSetsEvents struct {
	sync.Mutex
	events []compactionDigestSetsEvent
}

type compactionDigestSetsEvent struct {
	Start      time.Time `json:"start"`
	End        time.Time `json:"end"`
	DurationNS int64     `json:"duration_ns"`
	Reuse      bool      `json:"reuse"`
	Force      bool      `json:"force"`
	FreeAll    bool      `json:"free_all"`
	Changed    bool      `json:"changed"`
	OldSlots   int       `json:"old_slots"`
	NewSlots   int       `json:"new_slots"`
	Terms      int       `json:"terms"`
	Results    int       `json:"results"`
}

func init() {
	compactionDigestSetsReuseEnabled.Store(os.Getenv("DAGGER_TEST_COMPACTION_DIGEST_SETS") == "on")
}

func recordCompactionDigestSets(start time.Time, reuse, force, freeAll, changed bool, oldSlots, newSlots, terms, results int) {
	end := time.Now()
	event := compactionDigestSetsEvent{Start: start, End: end, DurationNS: end.Sub(start).Nanoseconds(), Reuse: reuse, Force: force, FreeAll: freeAll, Changed: changed, OldSlots: oldSlots, NewSlots: newSlots, Terms: terms, Results: results}
	compactionDigestSetsEvents.Lock()
	defer compactionDigestSetsEvents.Unlock()
	if len(compactionDigestSetsEvents.events) == 64 {
		copy(compactionDigestSetsEvents.events, compactionDigestSetsEvents.events[1:])
		compactionDigestSetsEvents.events = compactionDigestSetsEvents.events[:63]
	}
	compactionDigestSetsEvents.events = append(compactionDigestSetsEvents.events, event)
}

func CompactionDigestSetsDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		query := r.URL.Query()
		enabled, record := compactionDigestSetsReuseEnabled.Load(), compactionDigestSetsRecord.Load()
		if raw, ok := query["enabled"]; ok {
			v, err := strconv.ParseBool(raw[0])
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			enabled = v
		}
		if raw, ok := query["record"]; ok {
			v, err := strconv.ParseBool(raw[0])
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			record = v
		}
		compactionDigestSetsReuseEnabled.Store(enabled)
		compactionDigestSetsRecord.Store(record)
		if query.Has("record") {
			compactionDigestSetsEvents.Lock()
			compactionDigestSetsEvents.events = nil
			compactionDigestSetsEvents.Unlock()
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	compactionDigestSetsEvents.Lock()
	events := append([]compactionDigestSetsEvent(nil), compactionDigestSetsEvents.events...)
	compactionDigestSetsEvents.Unlock()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": compactionDigestSetsReuseEnabled.Load(), "record": compactionDigestSetsRecord.Load(), "events": events})
}
