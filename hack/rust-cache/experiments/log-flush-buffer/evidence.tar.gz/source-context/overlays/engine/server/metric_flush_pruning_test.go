package server

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	sdkmetric "go.opentelemetry.io/otel/sdk/metric"
)

func TestMetricFlushSelectionDoesNotWaitForBusyExporter(t *testing.T) {
	previous := metricFlushPruningEnabled.Swap(true)
	t.Cleanup(func() { metricFlushPruningEnabled.Store(previous) })
	exporter := &blockingMetricExporter{started: make(chan struct{}), release: make(chan struct{})}
	client := &clientRuntime{clientRecord: &clientRecord{clientID: "active"}}
	client.meterProvider = sdkmetric.NewMeterProvider(sdkmetric.WithReader(sdkmetric.NewPeriodicReader(exporter, sdkmetric.WithInterval(time.Hour))))
	client.metricReady.Store(true)
	gauge, err := client.meterProvider.Meter("test").Int64Gauge("test.selection")
	require.NoError(t, err)
	gauge.Record(t.Context(), 1)
	flushed := make(chan error, 1)
	go func() { flushed <- client.flushMetrics(t.Context()) }()
	defer func() {
		close(exporter.release)
		require.NoError(t, <-flushed)
		require.NoError(t, client.shutdownMetrics(context.Background()))
	}()
	select {
	case <-exporter.started:
	case <-time.After(3 * time.Second):
		t.Fatal("export did not start")
	}
	sess := &daggerSession{clientRuntimes: map[string]*clientRuntime{
		"active": client, "not initialized": {clientRecord: &clientRecord{clientID: "not initialized"}},
	}}
	selected := make(chan []*clientRuntime, 1)
	go func() { selected <- sess.clientMetricFlushRuntimes() }()
	select {
	case clients := <-selected:
		require.Equal(t, []*clientRuntime{client}, clients)
	case <-time.After(time.Second):
		t.Fatal("client selection waited for a busy exporter")
	}
}

func BenchmarkClientMetricFlushDispatch(b *testing.B) {
	for _, ready := range []int{0, 8, 800} {
		b.Run(fmt.Sprintf("ready-%d-of-800", ready), func(b *testing.B) {
			sess := &daggerSession{clientRuntimes: make(map[string]*clientRuntime, 800)}
			for i := range 800 {
				client := &clientRuntime{clientRecord: &clientRecord{clientID: fmt.Sprint(i)}}
				if i < ready {
					client.meterProvider = sdkmetric.NewMeterProvider(sdkmetric.WithReader(sdkmetric.NewManualReader()))
					client.metricReady.Store(true)
					b.Cleanup(func() { _ = client.shutdownMetrics(context.Background()) })
				}
				sess.clientRuntimes[client.clientID] = client
			}
			b.ReportAllocs()
			b.ReportMetric(float64(len(sess.clientMetricFlushRuntimes())), "dispatched/op")
			for b.Loop() {
				clients := sess.clientMetricFlushRuntimes()
				if err := runClientMetricOp(b.Context(), clients, "flush metrics", (*clientRuntime).flushMetrics); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
