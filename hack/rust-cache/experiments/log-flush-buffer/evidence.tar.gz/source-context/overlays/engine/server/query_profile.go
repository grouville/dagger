package server

import (
	"context"

	"github.com/99designs/gqlgen/graphql"
	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine/wcprof"
	"github.com/vektah/gqlparser/v2/ast"
)

// Each HTTP request owns its wrapper and context; the underlying schema stays shared.
func profiledQueryHandler(ctx context.Context, schema graphql.ExecutableSchema, profiling bool) *handler.Server {
	if profiling {
		schema = profiledExecutableSchema{ExecutableSchema: schema, ctx: ctx}
	}
	return dagql.NewDefaultHandler(schema)
}

type profiledExecutableSchema struct {
	graphql.ExecutableSchema
	ctx context.Context
}

func (schema profiledExecutableSchema) Schema() *ast.Schema {
	_, op := wcprof.BeginOp(schema.ctx, wcprof.OpKindSessionPhase, "session.querySchema", wcprof.OpOpts{})
	defer op.End(wcprof.OutcomeOK)
	return schema.ExecutableSchema.Schema()
}

func (schema profiledExecutableSchema) Exec(ctx context.Context) graphql.ResponseHandler {
	next := schema.ExecutableSchema.Exec(ctx)
	return func(ctx context.Context) (response *graphql.Response) {
		ctx, op := wcprof.BeginOp(ctx, wcprof.OpKindSessionPhase, "session.queryResolve", wcprof.OpOpts{})
		defer func() {
			if response != nil && len(response.Errors) > 0 {
				op.EndErr(response.Errors)
			} else {
				op.End(wcprof.OutcomeOK)
			}
		}()
		return next(ctx)
	}
}
