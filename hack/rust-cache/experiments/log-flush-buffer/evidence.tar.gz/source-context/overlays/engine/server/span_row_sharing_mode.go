package server

import (
	"encoding/json"
	"net/http"
	"strconv"
	"sync/atomic"
)

var spanRowSharingEnabled atomic.Bool
var spanRowSharingRecording atomic.Bool
var spanRowRouted atomic.Int64
var spanRowDestinations atomic.Int64
var spanRowEncodings atomic.Int64

func recordSpanRowRoute(destinations int) {
	if spanRowSharingRecording.Load() {
		spanRowRouted.Add(1)
		spanRowDestinations.Add(int64(destinations))
	}
}

func recordSpanRowEncoding() {
	if spanRowSharingRecording.Load() {
		spanRowEncodings.Add(1)
	}
}

func SpanRowSharingDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		if value := r.URL.Query().Get("enabled"); value != "" {
			enabled, err := strconv.ParseBool(value)
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			spanRowSharingEnabled.Store(enabled)
		}
		if value := r.URL.Query().Get("record"); value != "" {
			record, err := strconv.ParseBool(value)
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			spanRowSharingRecording.Store(false)
			spanRowRouted.Store(0)
			spanRowDestinations.Store(0)
			spanRowEncodings.Store(0)
			spanRowSharingRecording.Store(record)
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"enabled": spanRowSharingEnabled.Load(), "record": spanRowSharingRecording.Load(),
		"routed_spans": spanRowRouted.Load(), "destinations": spanRowDestinations.Load(),
		"encodings": spanRowEncodings.Load(),
	})
}
