package server

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var metadataSnapshotUnlocked atomic.Bool

func init() {
	metadataSnapshotUnlocked.Store(os.Getenv("DAGGER_TEST_UNLOCK_METADATA_SNAPSHOT") == "on")
}

func MetadataSnapshotUnlockedDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		metadataSnapshotUnlocked.Store(enabled)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": metadataSnapshotUnlocked.Load()})
}
