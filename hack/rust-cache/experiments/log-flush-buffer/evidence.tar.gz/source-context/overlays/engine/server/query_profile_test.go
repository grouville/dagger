package server

import (
	"bytes"
	"context"
	"testing"

	"github.com/99designs/gqlgen/graphql"
	"github.com/dagger/dagger/engine/wcprof"
	"github.com/stretchr/testify/require"
	"github.com/vektah/gqlparser/v2/ast"
	"github.com/vektah/gqlparser/v2/gqlerror"
)

type profileTestSchema struct {
	graphql.ExecutableSchema
	ast        *ast.Schema
	response   *graphql.Response
	factoryCtx context.Context
	handlerCtx context.Context
}

func (schema *profileTestSchema) Schema() *ast.Schema { return schema.ast }
func (schema *profileTestSchema) Exec(ctx context.Context) graphql.ResponseHandler {
	schema.factoryCtx = ctx
	return func(ctx context.Context) *graphql.Response { schema.handlerCtx = ctx; return schema.response }
}

func TestProfiledQueryPreservesSchemaResponseAndContext(t *testing.T) {
	wcprof.EnsureRecorder()
	ctx, cancel := context.WithCancel(wcprof.ContextWithProfiling(t.Context()))
	ctx, parent := wcprof.BeginOp(ctx, wcprof.OpKindSessionPhase, "test.queryProfile", wcprof.OpOpts{})
	original := &profileTestSchema{ast: &ast.Schema{}, response: &graphql.Response{Errors: gqlerror.List{gqlerror.Errorf("test failure")}}}
	profiled := profiledExecutableSchema{ExecutableSchema: original, ctx: ctx}
	require.Same(t, original.ast, profiled.Schema())
	next := profiled.Exec(ctx)
	require.Equal(t, ctx, original.factoryCtx)
	cancel()
	require.Same(t, original.response, next(ctx))
	require.ErrorIs(t, original.handlerCtx.Err(), context.Canceled)
	parent.End(wcprof.OutcomeOK)
	var buf bytes.Buffer
	require.NoError(t, wcprof.Active().WriteDump(&buf, false))
	header, events, err := wcprof.ReadDump(&buf)
	require.NoError(t, err)
	found := map[string]wcprof.DumpEvent{}
	for _, e := range events {
		if e.Type == "op" && e.ParentID == parent.ID() {
			found[header.Strings[e.ClassID]] = e
		}
	}
	require.Len(t, found, 2)
	require.Equal(t, "ok", found["session.querySchema"].Outcome)
	require.Equal(t, "error", found["session.queryResolve"].Outcome)
	require.Equal(t, found["session.queryResolve"].OpID, wcprof.CurrentOpID(original.handlerCtx))
}
