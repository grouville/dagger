package server

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var metricFlushPruningEnabled atomic.Bool

func init() { metricFlushPruningEnabled.Store(os.Getenv("DAGGER_DIAG_METRIC_FLUSH_PRUNING") == "1") }

var metricFlushPruningRecord atomic.Bool
var metricFlushCandidates atomic.Uint64
var metricFlushDispatched atomic.Uint64

func (sess *daggerSession) clientMetricFlushRuntimes() []*clientRuntime {
	clients := sess.clientMetricRuntimes()
	candidates := len(clients)
	if metricFlushPruningEnabled.Load() {
		initialized := clients[:0]
		for _, client := range clients {
			if client.metricReady.Load() {
				initialized = append(initialized, client)
			}
		}
		clients = initialized
	}
	if metricFlushPruningRecord.Load() {
		metricFlushCandidates.Add(uint64(candidates))
		metricFlushDispatched.Add(uint64(len(clients)))
	}
	return clients
}

func MetricFlushPruningDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		query := r.URL.Query()
		if raw, ok := query["enabled"]; ok {
			v, err := strconv.ParseBool(raw[0])
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			metricFlushPruningEnabled.Store(v)
		}
		if raw, ok := query["record"]; ok {
			v, err := strconv.ParseBool(raw[0])
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			metricFlushPruningRecord.Store(v)
			metricFlushCandidates.Store(0)
			metricFlushDispatched.Store(0)
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": metricFlushPruningEnabled.Load(), "record": metricFlushPruningRecord.Load(), "candidates": metricFlushCandidates.Load(), "dispatched": metricFlushDispatched.Load()})
}
