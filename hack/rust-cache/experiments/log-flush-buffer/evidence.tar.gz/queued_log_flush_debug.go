package main

import (
	"encoding/json"
	"net/http"
	"strconv"

	sdklog "go.opentelemetry.io/otel/sdk/log"
)

func installQueuedLogFlushDebug(mux *http.ServeMux) {
	mux.HandleFunc("/debug/queued-log-flush-buffer", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			record := false
			if value := r.URL.Query().Get("record"); value != "" {
				var err error
				record, err = strconv.ParseBool(value)
				if err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}
			}
			sdklog.ExperimentalConfigureFlushBuffer(enabled, record)
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(sdklog.ExperimentalFlushBufferStats())
	})
}
