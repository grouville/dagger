package log

import "os"

func init() {
	ExperimentalConfigureFlushBuffer(os.Getenv("DAGGER_BENCH_QUEUED_FLUSH_BUFFER") == "true", false)
}
