package log

import "sync/atomic"

var experimentalQueuedFlushBuffer atomic.Bool
var experimentalRecordFlushBuffers atomic.Bool
var experimentalFlushCalls atomic.Uint64
var experimentalQueuedFlushCalls atomic.Uint64
var experimentalFlushSlots atomic.Uint64

// Diagnostic controls for a same-binary comparison. These are not part of
// the proposed library patch. Configure only while the benchmark is idle.
func ExperimentalConfigureFlushBuffer(enabled, record bool) {
	experimentalRecordFlushBuffers.Store(false)
	experimentalFlushCalls.Store(0)
	experimentalQueuedFlushCalls.Store(0)
	experimentalFlushSlots.Store(0)
	experimentalQueuedFlushBuffer.Store(enabled)
	experimentalRecordFlushBuffers.Store(record)
}

func ExperimentalFlushBufferStats() any {
	return struct {
		Enabled     bool   `json:"enabled"`
		Record      bool   `json:"record"`
		Calls       uint64 `json:"calls"`
		QueuedCalls uint64 `json:"queued_calls"`
		Slots       uint64 `json:"allocated_record_slots"`
	}{experimentalQueuedFlushBuffer.Load(), experimentalRecordFlushBuffers.Load(), experimentalFlushCalls.Load(), experimentalQueuedFlushCalls.Load(), experimentalFlushSlots.Load()}
}
