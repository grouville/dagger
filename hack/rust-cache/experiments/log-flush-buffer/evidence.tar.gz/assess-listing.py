from pathlib import Path
import json
import statistics

p = Path(__file__).parent
root = p/'paired'
metadata = json.loads((root/'metadata.json').read_text())
samples = json.loads((root/'samples.json').read_text())
summary = json.loads((root/'summary.json').read_text())
restored = json.loads((root/'restored-state.json').read_text())
assert len(samples)==18 and summary['pairs']==8
assert restored['source'] and restored['test_source'] and all(restored['configs'].values()) and restored['flags_restored']
assert not restored['profiling'] and restored['locks']==dict(mutex_fraction=0,block_profile_rate_ns=0)
assert summary['all_commands_succeeded'] and summary['same_rows']
assert metadata['cli_sha256']['before']==metadata['cli_sha256']['after']
warmup = {r['arm']:r for r in samples if r['pair']==0}
for arm,row in warmup.items():
    mode=row['candidate_modes']['queued-log-flush-buffer']
    assert mode['record'] and mode['calls']>0 and mode['allocated_record_slots']>0
    assert mode['queued_calls']==(mode['calls'] if arm=='after' else 0)
pairs=[]
for pair in range(1,9):
    values={r['arm']:r for r in samples if r['pair']==pair}
    for arm,row in values.items():
        state=row['candidate_modes']['queued-log-flush-buffer']
        assert not state['record'] and state['enabled']==(arm=='after')
        assert row['listed_rows']==4398 and row['same_rows'] and row['exit_code']==0
    before,after=values['before'],values['after']
    pairs.append(dict(pair=pair,seconds_before=before['seconds'],seconds_after=after['seconds'],saving=before['seconds']-after['seconds'],engine_cpu_saving=before['engine_cpu']-after['engine_cpu'],allocated_bytes_saving=before['heap_delta']['TotalAlloc']-after['heap_delta']['TotalAlloc'],metadata_before={arm:r['gc_before']['metadata_estimate'] for arm,r in values.items()},metadata_after={arm:r['gc_after']['metadata_estimate'] for arm,r in values.items()}))
assessment=dict(scope='Complete edited Go collection listing on the retained warm development engine. Fresh CLI and source edit every command; same CLI, module, telemetry and common engine changes. Counters only in excluded warm-up. All observations retained.',
    summary=summary,pairs=pairs,
    median_paired_saving=statistics.median(r['saving'] for r in pairs),
    faster_pairs=sum(r['saving']>0 for r in pairs),
    lower_engine_cpu_pairs=sum(r['engine_cpu_saving']>0 for r in pairs),
    lower_allocated_bytes_pairs=sum(r['allocated_bytes_saving']>0 for r in pairs),
    warmup_buffer_counters={arm:r['candidate_modes']['queued-log-flush-buffer'] for arm,r in warmup.items()},
    selected=False,pr_opened=False,requires_independent_confirmation=True)
(p/'listing-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
print(json.dumps({k:assessment[k] for k in ['median_paired_saving','faster_pairs','lower_engine_cpu_pairs','lower_allocated_bytes_pairs','warmup_buffer_counters']},indent=2))
