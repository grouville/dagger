//go:build linux

package fsutil

import (
	"fmt"
	gofs "io/fs"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"github.com/dagger/dagger/internal/fsutil/types"
	"golang.org/x/sys/unix"
)

func TestWalkMetadataOptions(t *testing.T) {
	root := t.TempDir()
	if err := os.Mkdir(filepath.Join(root, "dir"), 0750); err != nil {
		t.Fatal(err)
	}
	file := filepath.Join(root, "dir/file")
	if err := os.WriteFile(file, []byte("contents"), 0640); err != nil {
		t.Fatal(err)
	}
	if err := os.Link(file, filepath.Join(root, "dir/link")); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink("file", filepath.Join(root, "dir/symlink")); err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{filepath.Join(root, "dir"), file} {
		if err := unix.Setxattr(path, "user.metadata-test", []byte("preserved by default"), 0); err != nil {
			t.Fatal(err)
		}
	}
	scan := func(filesystem FS) map[string]*types.Stat {
		t.Helper()
		stats := map[string]*types.Stat{}
		err := filesystem.Walk(t.Context(), "/", func(path string, entry gofs.DirEntry, err error) error {
			if err != nil {
				return err
			}
			info, err := entry.Info()
			if err != nil {
				return err
			}
			stats[path] = info.Sys().(*types.Stat)
			return nil
		})
		if err != nil {
			t.Fatal(err)
		}
		return stats
	}
	defaults, err := NewFS(root)
	if err != nil {
		t.Fatal(err)
	}
	skipped, err := NewFSWithOptions(root, FSOptions{SkipXattrs: true})
	if err != nil {
		t.Fatal(err)
	}
	want, got := scan(defaults), scan(skipped)
	if len(want) != 4 || len(got) != len(want) {
		t.Fatalf("different entries: %d / %d", len(want), len(got))
	}
	if len(want["dir"].Xattrs) == 0 || len(want["dir/file"].Xattrs) == 0 {
		t.Fatal("default scan lost xattrs")
	}
	for path, stat := range want {
		expected := *stat
		expected.Xattrs = nil
		if !reflect.DeepEqual(&expected, got[path]) {
			t.Fatalf("metadata changed at %s: want %+v, got %+v", path, &expected, got[path])
		}
	}
	direct, err := Stat(file)
	if err != nil {
		t.Fatal(err)
	}
	if string(direct.Xattrs["user.metadata-test"]) != "preserved by default" {
		t.Fatal("Stat lost xattrs")
	}
}

func BenchmarkMirrorMetadataWalk(b *testing.B) {
	for _, size := range []int{128, 1026} {
		b.Run(fmt.Sprint(size), func(b *testing.B) {
			root := b.TempDir()
			for n := range size {
				dir := filepath.Join(root, fmt.Sprintf("leaf_%04d", n))
				if err := os.MkdirAll(filepath.Join(dir, "src"), 0755); err != nil {
					b.Fatal(err)
				}
				for _, name := range []string{"Cargo.toml", "src/lib.rs"} {
					path := filepath.Join(dir, name)
					if err := os.WriteFile(path, []byte("test contents"), 0644); err != nil {
						b.Fatal(err)
					}
					if err := unix.Setxattr(path, "user.daggerContentHash.v2", []byte("xxh3:0123456789abcdef"), 0); err != nil {
						b.Fatal(err)
					}
				}
			}
			for _, skip := range []bool{false, true} {
				b.Run(fmt.Sprintf("skip=%t", skip), func(b *testing.B) {
					filesystem, err := NewFSWithOptions(root, FSOptions{SkipXattrs: skip})
					if err != nil {
						b.Fatal(err)
					}
					b.ReportAllocs()
					b.ResetTimer()
					for b.Loop() {
						count := 0
						err := filesystem.Walk(b.Context(), "/", func(_ string, entry gofs.DirEntry, err error) error {
							if err != nil {
								return err
							}
							if _, err := entry.Info(); err != nil {
								return err
							}
							count++
							return nil
						})
						if err != nil {
							b.Fatal(err)
						}
						if count != size*4 {
							b.Fatalf("walked %d entries, expected %d", count, size*4)
						}
					}
				})
			}
		})
	}
}
