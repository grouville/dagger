package filesync

import (
	"context"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/containerd/continuity/sysx"
	bkcontenthash "github.com/dagger/dagger/engine/contenthash"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	"github.com/dagger/dagger/internal/buildkit/util/bklog"
	"github.com/dagger/dagger/internal/fsutil"
	"github.com/dagger/dagger/internal/fsutil/types"
	"github.com/dagger/dagger/util/hashutil"
	"github.com/dagger/dagger/util/layercopy"
	digest "github.com/opencontainers/go-digest"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/metric"
	"go.opentelemetry.io/otel/trace"
	"golang.org/x/sync/errgroup"
	"golang.org/x/sys/unix"

	telemetry "github.com/dagger/otel-go"
)

const (
	hashXattrKey = "user.daggerContentHash.v2"
)

func isMissingContentHashXattr(err error) bool {
	return errors.Is(err, unix.ENODATA)
}

// localFSSharedState is the state shared between all syncs for a given client.
type localFSSharedState struct {
	// rootPath is the abs path to the mounted cache ref that we sync all files/dirs for
	// a given client
	rootPath string

	// changeCache is the cache we use to dedupe/cache changes made to the local fs across
	// different syncs (see docs on localFS.Sync for more info)
	changeCache *changeCache
}

type MirrorSharedState = localFSSharedState

func NewMirrorSharedState(rootPath string) *MirrorSharedState {
	return &MirrorSharedState{
		rootPath:    rootPath,
		changeCache: newChangeCache(),
	}
}

type ChangeWithStat struct {
	kind ChangeKind
	stat *HashedStatInfo
}

type CachedChange = *cachedChange

// localFS holds the state for a single sync of a client's fs into our cache
type localFS struct {
	*localFSSharedState

	// the subdir under rootPath that we are syncing, e.g. if the client is syncing in their
	// /foo/bar/ dir this will be /foo/bar and we will be syncing into <rootPath>/foo/bar
	subdir string

	// The actual copy path to use for that sync.
	// In 90% of the case, this will be `/` but if the client is syncing into a parent dir
	// for example to fetch .gitignore patterns then this will be the actual directory to copy.
	copyPath string

	// filterFS is the fs that applies the include/exclude patterns to our view of the current
	// cache filesystem at <rootPath>/<subdir>
	filterFS  fsutil.FS
	includes  []string // the include patterns we're using for this sync
	excludes  []string // the exclude patterns we're using for this sync
	seeds     *SnapshotSeeds
	seedScope string
}

func newLocalFS(sharedState *MirrorSharedState, subdir string, includes, excludes, followPaths []string, copyPath string) (*localFS, error) {
	baseFS, err := fsutil.NewFSWithOptions(filepath.Join(sharedState.rootPath, subdir), fsutil.FSOptions{SkipXattrs: mirrorMetadataSkipXattrs.Load()})
	if err != nil {
		return nil, fmt.Errorf("failed to create base fs: %w", err)
	}

	filterFS, err := fsutil.NewFilterFS(baseFS, &fsutil.FilterOpt{
		IncludePatterns: includes,
		ExcludePatterns: excludes,
		FollowPaths:     followPaths,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create filter fs: %w", err)
	}

	return &localFS{
		localFSSharedState: sharedState,
		subdir:             subdir,
		filterFS:           filterFS,
		includes:           includes,
		excludes:           excludes,
		copyPath:           copyPath,
	}, nil
}

func localCopyOnlyPaths(only map[string]struct{}, basePath string) map[string]struct{} {
	filtered := make(map[string]struct{}, len(only))
	basePath = cleanLocalCopyPath(basePath)
	for p := range only {
		p = cleanLocalCopyPath(p)
		if basePath != "" {
			if p == basePath {
				filtered[""] = struct{}{}
				continue
			}
			prefix := basePath + string(filepath.Separator)
			if !strings.HasPrefix(p, prefix) {
				continue
			}
			p = strings.TrimPrefix(p, prefix)
		}
		filtered[p] = struct{}{}
	}
	return filtered
}

func cleanLocalCopyPath(p string) string {
	p = filepath.Clean(p)
	if p == "." || p == string(filepath.Separator) {
		return ""
	}
	return strings.TrimPrefix(p, string(filepath.Separator))
}

// Sync the given remote fs into the local fs, returning an immutable cache ref containing the files+dirs
// as they appear in the client at the synced in path.
//
// If forParents is true, only the parent directories are synced and no cache ref is returned.
//
// To handle concurrent syncs, this relies on the local.changeCache singleflight group:
//   - Equivalent operations on the same path running in parallel will be deduped
//   - The caching of results of mutations saves repeating work and allows us to identify when the client
//     filesystem is changing in the middle of a sync in such a way that we'd potentially create inconsistent
//     syncs. If we call a mutation op and get a cached result that doesn't match what we applied, we know
//     there was a conflicting change and can error out.
//   - The fact that cache results are held only for the duration of the sync and .Released at the end allows
//     operations on paths to only be cached as long as needed. That way, if the client filesystem changes after
//     a sync in done (which is safe) we won't use cached results and hit an unnecessary conflict error.
//
// NOTE: This currently does not handle resetting parent dir modtimes to match the client. This matches
// upstream for now and avoids extra performance overhead + complication until a need for those modtimes
// matching the client's is proven.
func (local *localFS) Sync( //nolint:gocyclo
	ctx context.Context,
	remote ReadFS,
	cacheManager bkcache.SnapshotManager,
	forParents bool,
) (_ bkcache.ImmutableRef, _ digest.Digest, rerr error) {
	var newCopyRef bkcache.MutableRef       // the mutable ref we will copy into with the frozen files+dirs if needed
	var cacheCtx bkcontenthash.CacheContext // track file+dir hashes

	// skip creating a cache ref if we're only syncing parent dirs
	if !forParents {
		var err error
		newCopyRef, err = cacheManager.New(ctx, nil)
		if err != nil {
			return nil, "", fmt.Errorf("failed to create new copy ref: %w", err)
		}
		defer func() {
			ctx := context.WithoutCancel(ctx)
			if newCopyRef != nil {
				if err := newCopyRef.Release(ctx); err != nil {
					rerr = errors.Join(rerr, fmt.Errorf("failed to release copy ref: %w", err))
				}
			}
		}()

		newCopyMD, ok := any(newCopyRef).(bkcache.RefMetadata)
		if !ok {
			return nil, "", fmt.Errorf("copy ref metadata: unexpected ref type %T", newCopyRef)
		}
		cacheCtx, err = bkcontenthash.GetCacheContext(ctx, newCopyMD)
		if err != nil {
			return nil, "", fmt.Errorf("failed to get cache context: %w", err)
		}
	}

	eg, egCtx := errgroup.WithContext(ctx)

	// When a file or dir is added, modified, or deleted, we need to apply the change to the local fs. The local.changeCache
	// keeps track of which modifications we have made during this sync on a per-path basis. This is shared between
	// all syncs to the local fs cache ref. That allows us to both de-dupe equivalent changes and to know when
	// conflicting changes are being applied (due to the client filesystem changing during this sync), which would
	// otherwise create inconsistent synced filesystems.
	//
	// We need to release all the cache results from local.changeCache once we are done here to indicate that we no longer
	// care about any future changes made to the paths we hit during the sync, allowing any future changes made
	// on the client filesystem to be synced in without a conflict error.
	var cachedResults []CachedChange
	var cachedResultsMu sync.Mutex
	defer func() {
		for _, cachedResult := range cachedResults {
			cachedResult.release()
		}
	}()

	// the paths to copy from the mirror into the final snapshot
	only := map[string]struct{}{}

	// Gitignored dirs are not synced, but a re-included file inside one
	// ("!foo/bar.txt") can only be written once its parent dir exists in the
	// mirror. Track ignored dirs so they can be created on demand. They never
	// enter `only`: ignored dirs are not synced content and should not affect
	// which files are copied from the mirror into the final snapshot.
	type ignoredDir struct {
		kind    ChangeKind
		stat    *types.Stat
		created bool
	}
	ignoredDirs := map[string]*ignoredDir{}
	isIgnoredPath := func(path string) bool {
		for {
			if _, ok := ignoredDirs[path]; ok {
				return true
			}
			if path == "." || path == string(os.PathSeparator) {
				break
			}
			next := filepath.Dir(path)
			if next == path {
				break
			}
			path = next
		}
		return false
	}

	// We assert if we find a file/dir in the given relative path to correctly return
	// an error if nothing exist in there.
	// See explanations here: https://github.com/dagger/dagger/pull/10995#issuecomment-3347636652
	var relPathFound atomic.Bool

	var ensureIgnoredParentDirs func(path string) error
	ensureIgnoredParentDirs = func(path string) error {
		if len(ignoredDirs) == 0 {
			return nil
		}
		dir := filepath.Dir(path)
		if dir == "." { // paths are relative; "." means we reached the sync root
			return nil
		}
		// create outermost ancestors first
		if err := ensureIgnoredParentDirs(dir); err != nil {
			return err
		}
		ignored, ok := ignoredDirs[dir]
		if !ok || ignored.created {
			return nil
		}
		appliedChange, err := local.Mkdir(egCtx, ignored.kind, dir, ignored.stat)
		if err != nil {
			return err
		}
		ignored.created = true
		cachedResultsMu.Lock()
		cachedResults = append(cachedResults, appliedChange)
		cachedResultsMu.Unlock()

		doHandle := cacheCtx != nil
		if local.copyPath != "" {
			dir, doHandle = strings.CutPrefix(dir, local.copyPath)
		}
		if doHandle {
			relPathFound.Store(true)
			applied := appliedChange.result()
			if err := cacheCtx.HandleChange(applied.kind, dir, local.contentHashStat(applied.stat), nil); err != nil {
				return fmt.Errorf("failed to handle change in content hasher: %w", err)
			}
		}

		return nil
	}

	// Hardlinks are a bit hard; we can't create them until their source file exists but we sync in files asynchronously.
	// To deal with this we keep track of the hardlinks we need to make and apply them all at once after everything else
	// is done.
	type hardlinkChange struct {
		kind      ChangeKind
		path      string
		upperStat *types.Stat
	}
	var hardlinks []*hardlinkChange
	var hardlinkMu sync.Mutex

	// Track spans per top-level directory
	type rootPathSpan struct {
		span         trace.Span
		start        time.Time
		writtenBytes int64
		maxStop      time.Time
		mu           sync.Mutex
	}
	var rootPathSpans sync.Map
	getRootPath := func(path string) *rootPathSpan {
		rootPath := strings.Split(path, string(os.PathSeparator))[0]

		now := time.Now()
		dirSpan := &rootPathSpan{
			start:   now,
			maxStop: now,
			mu:      sync.Mutex{},
		}

		rps, _ := rootPathSpans.LoadOrStore(rootPath, dirSpan)
		rps.(*rootPathSpan).mu.Lock()
		if rps.(*rootPathSpan).span == nil {
			_, span := Tracer(egCtx).Start(egCtx, rootPath)
			rps.(*rootPathSpan).span = span
		}
		rps.(*rootPathSpan).mu.Unlock()

		return rps.(*rootPathSpan)
	}

	defer func() {
		rootPathSpans.Range(func(_, value any) bool {
			dirSpan := value.(*rootPathSpan)
			dirSpan.span.End(trace.WithTimestamp(dirSpan.maxStop))
			return true
		})
	}()

	// Stream cumulative uploaded bytes via the telemetry convention,
	// attributed to the "uploading <path>" span carried by ctx. The total is
	// unknown up front (the diff streams), so this renders as a climbing
	// byte count, and an unchanged directory emits nothing. Parent-dir
	// syncs transfer only directory entries and are skipped.
	var uploadedBytes atomic.Int64
	upload := bkcache.NewProgressTracker(ctx, "bytes", 0, "bytes")
	countUploaded := func(written int64) {
		if forParents {
			return
		}
		upload.Update(uploadedBytes.Add(written))
	}
	defer upload.Finish()

	doubleWalkDiff(egCtx, eg, local, remote, func(kind ChangeKind, path string, lowerStat, upperStat *types.Stat) error {
		if upperStat != nil && upperStat.GitIgnored {
			if upperStat.IsDir() {
				ignoredDirs[path] = &ignoredDir{kind: kind, stat: upperStat}
			}
			return nil
		}
		switch kind {
		case ChangeKindAdd, ChangeKindModify:
			if err := ensureIgnoredParentDirs(path); err != nil {
				return err
			}
			switch {
			case upperStat.IsDir():
				appliedChange, err := local.Mkdir(egCtx, kind, path, upperStat)
				if err != nil {
					return err
				}
				cachedResultsMu.Lock()
				cachedResults = append(cachedResults, appliedChange)
				only[path] = struct{}{}
				cachedResultsMu.Unlock()

				doHandle := cacheCtx != nil
				if local.copyPath != "" {
					path, doHandle = strings.CutPrefix(path, local.copyPath)
				}
				if doHandle {
					relPathFound.Store(true)
					applied := appliedChange.result()
					if err := cacheCtx.HandleChange(applied.kind, path, local.contentHashStat(applied.stat), nil); err != nil {
						return fmt.Errorf("failed to handle change in content hasher: %w", err)
					}
				}

				return nil

			case upperStat.Mode&uint32(os.ModeDevice) != 0 || upperStat.Mode&uint32(os.ModeNamedPipe) != 0:
				// NOTE: not handling devices for now since they are extremely non-portable and dubious in terms
				// of real utility vs. enabling bizarre hacks
				bklog.G(ctx).Warnf("skipping device file %q", path)
				return nil

			case upperStat.Mode&uint32(os.ModeSymlink) != 0:
				appliedChange, err := local.Symlink(egCtx, kind, path, upperStat)
				if err != nil {
					return err
				}
				cachedResultsMu.Lock()
				cachedResults = append(cachedResults, appliedChange)
				only[path] = struct{}{}
				cachedResultsMu.Unlock()

				doHandle := cacheCtx != nil
				if local.copyPath != "" {
					path, doHandle = strings.CutPrefix(path, local.copyPath)
				}
				if doHandle {
					relPathFound.Store(true)
					applied := appliedChange.result()
					if err := cacheCtx.HandleChange(applied.kind, path, local.contentHashStat(applied.stat), nil); err != nil {
						return fmt.Errorf("failed to handle change in content hasher: %w", err)
					}
				}

				return nil

			case upperStat.Linkname != "":
				// delay hardlinks until after everything else so we know the source of the link exists
				hardlinkMu.Lock()
				hardlinks = append(hardlinks, &hardlinkChange{
					kind:      kind,
					path:      path,
					upperStat: upperStat,
				})
				hardlinkMu.Unlock()

				return nil

			default:
				eg.Go(func() error {
					// since we can't really know when a root path is done as
					// all files are synced in parallel, we track everything
					// we see and then change the span end time before returning.
					rootPathSpan := getRootPath(path)

					appliedChange, written, werr := local.WriteFile(ctx, kind, path, upperStat, remote)

					writeEnd := time.Now()
					m := telemetry.Meter(ctx, "dagger.io/filesync")
					fsMetric, err := m.Int64Gauge(telemetry.FilesyncWrittenBytes)
					if err != nil {
						return err
					}
					attrs := []attribute.KeyValue{
						attribute.String(telemetry.MetricsTraceIDAttr, rootPathSpan.span.SpanContext().TraceID().String()),
						attribute.String(telemetry.MetricsSpanIDAttr, rootPathSpan.span.SpanContext().SpanID().String()),
					}
					countUploaded(written)
					rootPathSpan.mu.Lock()
					rootPathSpan.writtenBytes += written
					fsMetric.Record(ctx, written, metric.WithAttributes(attrs...))
					// only track the max(end) of all the files within a root path
					if writeEnd.After(rootPathSpan.maxStop) {
						rootPathSpan.maxStop = writeEnd
					}
					if werr != nil {
						rootPathSpan.span.SetStatus(codes.Error, werr.Error())
					}
					rootPathSpan.mu.Unlock()

					if werr != nil {
						return werr
					}

					cachedResultsMu.Lock()
					cachedResults = append(cachedResults, appliedChange)
					only[path] = struct{}{}
					cachedResultsMu.Unlock()

					doHandle := cacheCtx != nil
					if local.copyPath != "" {
						path, doHandle = strings.CutPrefix(path, local.copyPath)
					}
					if doHandle {
						relPathFound.Store(true)
						applied := appliedChange.result()
						if err := cacheCtx.HandleChange(applied.kind, path, local.contentHashStat(applied.stat), nil); err != nil {
							return fmt.Errorf("failed to handle change in content hasher: %w", err)
						}
					}

					return nil
				})
				return nil
			}

		case ChangeKindDelete:
			/*
				Deletes don't have upperStat, so we can't consult GitIgnored directly.

				Example:
				- .gitignore contains "tmp/"
				- mirror previously has tmp/a
				- client deletes tmp/a
				- remote walk includes tmp/ (GitIgnored) but not tmp/a (gone)
				- diff emits a delete for tmp/a

				We skip deletes under ignored prefixes to avoid mutating the shared mirror
				and to keep `only`/conflict tracking consistent with "ignored paths are inert."
			*/
			if isIgnoredPath(path) {
				return nil
			}

			appliedChange, err := local.RemoveAll(egCtx, path)
			if err != nil {
				return err
			}
			cachedResultsMu.Lock()
			cachedResults = append(cachedResults, appliedChange)
			only[path] = struct{}{}
			cachedResultsMu.Unlock()
			// no need to apply removals to the cacheCtx since it starts empty every Sync call.
			return nil

		case ChangeKindNone:
			if err := ensureIgnoredParentDirs(path); err != nil {
				return err
			}
			appliedChange, err := local.GetPreviousChange(egCtx, path, lowerStat)
			if err != nil {
				return err
			}
			cachedResultsMu.Lock()
			cachedResults = append(cachedResults, appliedChange)
			only[path] = struct{}{}
			cachedResultsMu.Unlock()

			doHandle := cacheCtx != nil
			if local.copyPath != "" {
				path, doHandle = strings.CutPrefix(path, local.copyPath)
			}
			if doHandle {
				relPathFound.Store(true)
				applied := appliedChange.result()
				if err := cacheCtx.HandleChange(applied.kind, path, local.contentHashStat(applied.stat), nil); err != nil {
					return fmt.Errorf("failed to handle change in content hasher: %w", err)
				}
			}

			return nil

		default:
			return fmt.Errorf("unsupported change kind: %s", kind)
		}
	})

	if err := eg.Wait(); err != nil {
		return nil, "", err
	}
	for _, hardlink := range hardlinks {
		appliedChange, err := local.Hardlink(ctx, hardlink.kind, hardlink.path, hardlink.upperStat)
		if err != nil {
			return nil, "", err
		}
		cachedResultsMu.Lock()
		cachedResults = append(cachedResults, appliedChange)
		only[hardlink.path] = struct{}{}
		cachedResultsMu.Unlock()

		doHandle := cacheCtx != nil
		path := hardlink.path
		if local.copyPath != "" {
			path, doHandle = strings.CutPrefix(path, local.copyPath)
		}
		if doHandle {
			relPathFound.Store(true)
			applied := appliedChange.result()
			if err := cacheCtx.HandleChange(applied.kind, path, local.contentHashStat(applied.stat), nil); err != nil {
				return nil, "", fmt.Errorf("failed to handle change in content hasher: %w", err)
			}
		}
	}

	if forParents {
		// we created the parent dirs, nothing else to do now
		return nil, "", nil
	}

	ctx, copySpan := Tracer(ctx).Start(ctx, "copy")
	defer telemetry.EndWithCause(copySpan, &rerr)

	// If we didn't find any files/dir in the given relative path, we can early return an error.
	if local.copyPath != "" && !relPathFound.Load() {
		return nil, "", fmt.Errorf("%s: no such file or directory", local.copyPath)
	}

	dgst, err := cacheCtx.Checksum(ctx, newCopyRef, "/", bkcontenthash.ChecksumOpts{})
	if err != nil {
		return nil, "", fmt.Errorf("failed to checksum: %w", err)
	}

	// If we have already created a cache ref with the same content hash, use that instead of copying
	// another equivalent one.
	sis, err := bkcontenthash.SearchContentHash(ctx, cacheManager, dgst)
	if err != nil {
		return nil, "", fmt.Errorf("failed to search content hash: %w", err)
	}
	for _, si := range sis {
		finalRef, err := cacheManager.LeaseExistingSnapshot(ctx, si.SnapshotID())
		if err == nil {
			bklog.G(ctx).Debugf("reusing copy ref %s", si.SnapshotID())
			return finalRef, dgst, nil
		} else {
			bklog.G(ctx).Debugf("failed to get cache ref: %v", err)
		}
	}

	var seedRecords map[string]snapshotSeedRecord
	seedDepth := 0
	if local.seeds != nil {
		seedRecords = local.snapshotSeedRecords(cachedResults, only)
		if seed, ok := local.seeds.get(local.seedScope); ok && len(seedRecords) != 0 {
			if changed, ok := seed.changedPaths(seedRecords); ok {
				parent, err := cacheManager.LeaseExistingSnapshot(ctx, seed.id)
				if err == nil {
					defer parent.Release(context.WithoutCancel(ctx))
					derived, err := cacheManager.New(ctx, parent)
					if err == nil {
						previous := newCopyRef
						newCopyRef = derived
						if err := previous.Release(context.WithoutCancel(ctx)); err != nil {
							return nil, "", err
						}
						// changed paths are already relative to the copied root.
						only = changed
						seedDepth = seed.depth + 1
					} else {
						bklog.G(ctx).Debugf("cannot derive local import from snapshot %s: %v", seed.id, err)
					}
				} else {
					bklog.G(ctx).Debugf("local import snapshot seed %s unavailable: %v", seed.id, err)
				}
			}
		}
	}

	copyRefMntable, err := newCopyRef.Mount(ctx, false)
	if err != nil {
		return nil, "", fmt.Errorf("failed to get mountable: %w", err)
	}
	copyRefMounts, copyRefRelease, err := copyRefMntable.Mount()
	if err != nil {
		return nil, "", fmt.Errorf("failed to get mounts: %w", err)
	}
	if len(copyRefMounts) == 0 {
		if copyRefRelease != nil {
			if err := copyRefRelease(); err != nil {
				return nil, "", fmt.Errorf("failed to release copy ref mount: %w", err)
			}
		}
		return nil, "", fmt.Errorf("copy ref mountable returned no mounts")
	}
	var copyRefReleaseFn func() error
	if copyRefRelease != nil {
		copyRefReleaseFn = copyRefRelease
		defer func() {
			if copyRefReleaseFn != nil {
				if err := copyRefReleaseFn(); err != nil {
					rerr = errors.Join(rerr, fmt.Errorf("failed to release copy ref mount: %w", err))
				}
			}
		}()
	}
	copyRefMnter := bkcache.LocalMounterWithMounts(copyRefMounts)
	copyRefMntPath, err := copyRefMnter.Mount()
	if err != nil {
		return nil, "", fmt.Errorf("failed to mount: %w", err)
	}
	defer func() {
		if copyRefMnter != nil {
			if err := copyRefMnter.Unmount(); err != nil {
				rerr = errors.Join(rerr, fmt.Errorf("failed to unmount: %w", err))
			}
		}
	}()

	copier, err := layercopy.NewCopier(layercopy.Mount{
		Root:  copyRefMntPath,
		Mount: &copyRefMounts[0],
	})
	if err != nil {
		return nil, "", fmt.Errorf("failed to create copier: %w", err)
	}
	defer func() {
		if copier != nil {
			if err := copier.Close(); err != nil {
				rerr = errors.Join(rerr, fmt.Errorf("failed to close copier: %w", err))
			}
		}
	}()

	copyOnly := localCopyOnlyPaths(only, local.copyPath)
	if seedDepth != 0 {
		copyOnly = only
	}
	if err := copier.Copy(ctx,
		layercopy.Mount{Root: filepath.Join(local.rootPath, local.subdir)},
		local.copyPath,
		"/",
		layercopy.CopyOptions{
			Filter: layercopy.Filter{
				// Only copy files that we know about changes for.
				Only: copyOnly,
			},
			DisableXAttrs:          true,
			CopyDirContents:        true,
			DisableSourceHardlinks: true,
			ReplaceExisting:        seedDepth != 0,
			XAttrErrorHandler: func(dst, src, key string, err error) error {
				if key != "" {
					bklog.G(ctx).Debugf("xattr %q error during local import copy from %q to %q: %v", key, src, dst, err)
				} else {
					bklog.G(ctx).Debugf("xattr error during local import copy from %q to %q: %v", src, dst, err)
				}
				return nil
			},
		},
	); err != nil {
		return nil, "", fmt.Errorf("failed to copy %q: %w", local.subdir, err)
	}
	if err := copier.Close(); err != nil {
		copier = nil
		return nil, "", fmt.Errorf("failed to close copier: %w", err)
	}
	copier = nil

	if err := copyRefMnter.Unmount(); err != nil {
		copyRefMnter = nil
		return nil, "", fmt.Errorf("failed to unmount: %w", err)
	}
	copyRefMnter = nil
	if copyRefReleaseFn != nil {
		if err := copyRefReleaseFn(); err != nil {
			copyRefReleaseFn = nil
			return nil, "", fmt.Errorf("failed to release copy ref mount: %w", err)
		}
		copyRefReleaseFn = nil
	}

	finalRef, err := newCopyRef.Commit(ctx)
	if err != nil {
		return nil, "", fmt.Errorf("failed to commit: %w", err)
	}
	newCopyRef = nil
	defer func() {
		if rerr != nil {
			if finalRef != nil {
				ctx := context.WithoutCancel(ctx)
				if err := finalRef.Release(ctx); err != nil {
					rerr = errors.Join(rerr, fmt.Errorf("failed to release: %w", err))
				}
			}
		}
	}()

	finalMD, ok := any(finalRef).(bkcache.RefMetadata)
	if !ok {
		return nil, "", fmt.Errorf("final sync metadata: unexpected ref type %T", finalRef)
	}

	if err := bkcontenthash.SetCacheContext(ctx, finalMD, cacheCtx); err != nil {
		return nil, "", fmt.Errorf("failed to set cache context: %w", err)
	}

	if err := (bkcontenthash.CacheRefMetadata{RefMetadata: finalMD}).SetContentHashKey(dgst); err != nil {
		return nil, "", fmt.Errorf("failed to set content hash key: %w", err)
	}
	if err := finalMD.SetDescription(fmt.Sprintf("local dir %s (include: %v) (exclude %v)", local.subdir, local.includes, local.excludes)); err != nil {
		return nil, "", fmt.Errorf("failed to set description: %w", err)
	}
	if len(seedRecords) != 0 {
		local.seeds.put(local.seedScope, snapshotSeed{id: finalRef.SnapshotID(), records: seedRecords, depth: seedDepth})
	}

	return finalRef, dgst, nil
}

// the full absolute path on the local filesystem
func (local *localFS) toFullPath(path string) string {
	return filepath.Join(local.rootPath, local.subdir, path)
}

// the absolute path under local.rootPath
func (local *localFS) toRootPath(path string) string {
	return filepath.Join(local.subdir, path)
}

// the cache key to use for an operation on a given path (where path is relative to local.subdir)
func (local *localFS) cacheKey(path string) string {
	return local.toRootPath(path)
}

// Content-hash paths are relative to the copied subtree. Hardlink targets
// arrive relative to the sync root and must use that same subtree namespace.
// Keep the mirror's stat intact: another import can share its cached change.
func (local *localFS) contentHashStat(info *HashedStatInfo) *HashedStatInfo {
	if local.copyPath == "" || info.Linkname == "" || info.Mode()&os.ModeSymlink != 0 {
		return info
	}
	base := cleanLocalCopyPath(local.copyPath)
	if base == "" {
		return info
	}
	link, ok := strings.CutPrefix(cleanLocalCopyPath(info.Linkname), base+string(filepath.Separator))
	if !ok {
		return info
	}
	stat := *info.Stat
	stat.Linkname = link
	rebased := *info
	rebased.Stat = &stat
	return &rebased
}

// GetPreviousChange is called when the differ identifies that our cache and the client's filesystem match at this path.
// We still need to put this into the cacheCtx object we are accumulating so that the path contributes to the content
// hash.
//
// For non-regular files (dirs, symlinks, etc.) we just base the hash on the stat, which we already have from the differ.
//
// For regular files, we also need to include the content hash of the file contents, which would be expensive to re-run.
// Instead, the WriteFile method stores the hash in an xattr, which we just read here.
//
// Unlike other methods below, we don't need to verifyExpectedChange since there was no change applied to the path.
func (local *localFS) GetPreviousChange(ctx context.Context, path string, stat *types.Stat) (CachedChange, error) {
	return local.changeCache.getOrInit(ctx, local.cacheKey(path), func(_ context.Context) (*ChangeWithStat, error) {
		fullPath := local.toFullPath(path)

		isRegular := stat.Mode&uint32(os.ModeType) == 0
		if isRegular {
			dgstBytes, err := sysx.Getxattr(fullPath, hashXattrKey)
			if err != nil {
				if !isMissingContentHashXattr(err) {
					return nil, fmt.Errorf("failed to get content hash xattr: %w", err)
				}
				f, err := os.Open(fullPath)
				if err != nil {
					return nil, fmt.Errorf("failed to open file %q for content hash repair: %w", path, err)
				}
				defer f.Close()

				h := newHashFromStat(stat)
				copyBuf := copyBufferPool.Get().(*[]byte)
				_, err = io.CopyBuffer(h, f, *copyBuf)
				copyBufferPool.Put(copyBuf)
				if err != nil {
					return nil, fmt.Errorf("failed to read file %q for content hash repair: %w", path, err)
				}

				dgst := digest.NewDigest(hashutil.XXH3, h)
				if err := sysx.Setxattr(fullPath, hashXattrKey, []byte(dgst.String()), 0); err != nil {
					return nil, fmt.Errorf("failed to set repaired content hash xattr: %w", err)
				}
				return &ChangeWithStat{
					kind: ChangeKindNone,
					stat: &HashedStatInfo{
						StatInfo: StatInfo{stat},
						dgst:     dgst,
					},
				}, nil
			}
			return &ChangeWithStat{
				kind: ChangeKindNone,
				stat: &HashedStatInfo{
					StatInfo: StatInfo{stat},
					dgst:     digest.Digest(dgstBytes),
				},
			}, nil
		}

		return &ChangeWithStat{
			kind: ChangeKindNone,
			stat: &HashedStatInfo{
				StatInfo: StatInfo{stat},
				dgst:     digest.NewDigest(hashutil.XXH3, newHashFromStat(stat)),
			},
		}, nil
	})
}

func (local *localFS) RemoveAll(ctx context.Context, path string) (CachedChange, error) {
	appliedChange, err := local.changeCache.getOrInit(ctx, local.cacheKey(path), func(ctx context.Context) (*ChangeWithStat, error) {
		fullPath := local.toFullPath(path)
		if err := os.RemoveAll(fullPath); err != nil {
			return nil, err
		}
		return &ChangeWithStat{kind: ChangeKindDelete}, nil
	})
	if err != nil {
		return nil, err
	}

	if err := verifyExpectedChange(path, appliedChange.result(), ChangeKindDelete, nil); err != nil {
		appliedChange.release()
		return nil, err
	}
	return appliedChange, nil
}

func (local *localFS) Mkdir(ctx context.Context, expectedChangeKind ChangeKind, path string, upperStat *types.Stat) (CachedChange, error) {
	appliedChange, err := local.changeCache.getOrInit(ctx, local.cacheKey(path), func(ctx context.Context) (*ChangeWithStat, error) {
		fullPath := local.toFullPath(path)

		lowerStat, err := os.Lstat(fullPath)
		if err != nil && !os.IsNotExist(err) {
			return nil, fmt.Errorf("failed to stat existing path: %w", err)
		}

		isNewDir := lowerStat == nil
		replacesNonDir := lowerStat != nil && !lowerStat.IsDir()

		if replacesNonDir {
			if err := os.Remove(fullPath); err != nil {
				return nil, fmt.Errorf("failed to remove existing file: %w", err)
			}
		}

		if isNewDir || replacesNonDir {
			if err := os.Mkdir(fullPath, os.FileMode(upperStat.Mode)&os.ModePerm); err != nil {
				return nil, fmt.Errorf("failed to create directory: %w", err)
			}
		}

		if err := rewriteMetadata(fullPath, upperStat); err != nil {
			return nil, fmt.Errorf("failed to rewrite directory metadata: %w", err)
		}

		return &ChangeWithStat{
			kind: expectedChangeKind,
			stat: &HashedStatInfo{
				StatInfo: StatInfo{upperStat},
				dgst:     digest.NewDigest(hashutil.XXH3, newHashFromStat(upperStat)),
			},
		}, nil
	})
	if err != nil {
		return nil, err
	}

	if err := verifyExpectedChange(path, appliedChange.result(), expectedChangeKind, upperStat); err != nil {
		appliedChange.release()
		return nil, err
	}
	return appliedChange, nil
}

func (local *localFS) Symlink(ctx context.Context, expectedChangeKind ChangeKind, path string, upperStat *types.Stat) (CachedChange, error) {
	appliedChange, err := local.changeCache.getOrInit(ctx, local.cacheKey(path), func(ctx context.Context) (*ChangeWithStat, error) {
		fullPath := local.toFullPath(path)

		lowerStat, err := os.Lstat(fullPath)
		if err != nil && !os.IsNotExist(err) {
			return nil, fmt.Errorf("failed to stat existing path: %w", err)
		}

		isNewSymlink := lowerStat == nil

		if !isNewSymlink {
			if err := os.RemoveAll(fullPath); err != nil {
				return nil, fmt.Errorf("failed to remove existing file: %w", err)
			}
		}

		if err := os.Symlink(upperStat.Linkname, fullPath); err != nil {
			return nil, fmt.Errorf("failed to create symlink: %w", err)
		}

		return &ChangeWithStat{
			kind: expectedChangeKind,
			stat: &HashedStatInfo{
				StatInfo: StatInfo{upperStat},
				dgst:     digest.NewDigest(hashutil.XXH3, newHashFromStat(upperStat)),
			},
		}, nil
	})
	if err != nil {
		return nil, err
	}

	if err := verifyExpectedChange(path, appliedChange.result(), expectedChangeKind, upperStat); err != nil {
		appliedChange.release()
		return nil, err
	}
	return appliedChange, nil
}

func (local *localFS) Hardlink(ctx context.Context, expectedChangeKind ChangeKind, path string, upperStat *types.Stat) (CachedChange, error) {
	appliedChange, err := local.changeCache.getOrInit(ctx, local.cacheKey(path), func(ctx context.Context) (*ChangeWithStat, error) {
		fullPath := local.toFullPath(path)

		lowerStat, err := os.Lstat(fullPath)
		if err != nil && !os.IsNotExist(err) {
			return nil, fmt.Errorf("failed to stat existing path: %w", err)
		}

		replacesExisting := lowerStat != nil

		if replacesExisting {
			if err := os.RemoveAll(fullPath); err != nil {
				return nil, fmt.Errorf("failed to remove existing file: %w", err)
			}
		}

		if err := os.Link(local.toFullPath(upperStat.Linkname), fullPath); err != nil {
			return nil, fmt.Errorf("failed to create hardlink: %w", err)
		}

		return &ChangeWithStat{
			kind: expectedChangeKind,
			stat: &HashedStatInfo{
				StatInfo: StatInfo{upperStat},
				dgst:     digest.NewDigest(hashutil.XXH3, newHashFromStat(upperStat)),
			},
		}, nil
	})
	if err != nil {
		return nil, err
	}

	if err := verifyExpectedChange(path, appliedChange.result(), expectedChangeKind, upperStat); err != nil {
		appliedChange.release()
		return nil, err
	}
	return appliedChange, nil
}

var copyBufferPool = &sync.Pool{
	New: func() any {
		buffer := make([]byte, 32*1024) // same size that fsutil.Send chunks files into
		return &buffer
	},
}

func (local *localFS) WriteFile(ctx context.Context, expectedChangeKind ChangeKind, path string, upperStat *types.Stat, upperFS ReadFS) (CachedChange, int64, error) {
	var writtenBytes int64
	appliedChange, err := local.changeCache.getOrInit(ctx, local.cacheKey(path), func(ctx context.Context) (*ChangeWithStat, error) {
		reader, err := upperFS.ReadFile(ctx, path)
		if err != nil {
			return nil, fmt.Errorf("failed to read file %q: %w", path, err)
		}
		defer reader.Close()

		fullPath := local.toFullPath(path)

		lowerStat, err := os.Lstat(fullPath)
		if err != nil && !os.IsNotExist(err) {
			return nil, fmt.Errorf("failed to stat existing path: %w", err)
		}

		replacesExisting := lowerStat != nil

		if replacesExisting {
			if err := os.RemoveAll(fullPath); err != nil {
				return nil, fmt.Errorf("failed to remove existing file: %w", err)
			}
		}

		f, err := os.OpenFile(fullPath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, os.FileMode(upperStat.Mode)&os.ModePerm)
		if err != nil {
			return nil, err
		}
		defer f.Close()

		h := newHashFromStat(upperStat)

		copyBuf := copyBufferPool.Get().(*[]byte)
		written, err := io.CopyBuffer(io.MultiWriter(f, h), reader, *copyBuf)
		writtenBytes = written
		copyBufferPool.Put(copyBuf)
		if err != nil {
			return nil, fmt.Errorf("failed to copy contents: %w", err)
		}
		if err := f.Close(); err != nil {
			return nil, fmt.Errorf("failed to close file: %w", err)
		}

		if err := rewriteMetadata(fullPath, upperStat); err != nil {
			return nil, fmt.Errorf("failed to rewrite file metadata: %w", err)
		}

		// store the hash in an xattr so GetPreviousChange above can use that instead of re-hashing the file
		dgst := digest.NewDigest(hashutil.XXH3, h)
		if err := sysx.Setxattr(fullPath, hashXattrKey, []byte(dgst.String()), 0); err != nil {
			return nil, fmt.Errorf("failed to set content hash xattr: %w", err)
		}

		return &ChangeWithStat{
			kind: expectedChangeKind,
			stat: &HashedStatInfo{
				StatInfo: StatInfo{upperStat},
				dgst:     dgst,
			},
		}, nil
	})
	if err != nil {
		return nil, 0, err
	}

	if err := verifyExpectedChange(path, appliedChange.result(), expectedChangeKind, upperStat); err != nil {
		appliedChange.release()
		return nil, 0, err
	}
	return appliedChange, writtenBytes, nil
}

func (local *localFS) Walk(ctx context.Context, path string, walkFn fs.WalkDirFunc) error {
	return local.filterFS.Walk(ctx, path, walkFn)
}

func rewriteMetadata(p string, upperStat *types.Stat) error {
	if err := os.Lchown(p, int(upperStat.Uid), int(upperStat.Gid)); err != nil {
		return fmt.Errorf("failed to change owner: %w", err)
	}

	if os.FileMode(upperStat.Mode)&os.ModeSymlink == 0 {
		if err := os.Chmod(p, os.FileMode(upperStat.Mode)); err != nil {
			return fmt.Errorf("failed to change mode: %w", err)
		}
	}

	var utimes [2]unix.Timespec
	utimes[0] = unix.NsecToTimespec(upperStat.ModTime)
	utimes[1] = utimes[0]

	if err := unix.UtimesNanoAt(unix.AT_FDCWD, p, utimes[0:], unix.AT_SYMLINK_NOFOLLOW); err != nil {
		return fmt.Errorf("failed to call utimes: %w", err)
	}

	return nil
}

// Check that the change applied by mutating methods is actually the one we thought we were applying. If not, the client
// filesystem changed during the sync and we need to error out to avoid inconsistencies.
func verifyExpectedChange(path string, appliedChange *ChangeWithStat, expectedKind ChangeKind, expectedStat *types.Stat) error {
	if appliedChange.kind == ChangeKindDelete || expectedKind == ChangeKindDelete {
		if appliedChange.kind != expectedKind {
			return &ErrConflict{Path: path, FieldName: "change kind", OldVal: changeKindString(appliedChange.kind), NewVal: expectedKind.String()}
		}
		// nothing else to compare for deletes
		return nil
	}

	if uint32(appliedChange.stat.Mode()) != expectedStat.Mode {
		return &ErrConflict{Path: path, FieldName: "mode", OldVal: fmt.Sprintf("%o", appliedChange.stat.Mode()), NewVal: fmt.Sprintf("%o", expectedStat.Mode)}
	}
	if appliedChange.stat.Uid != expectedStat.Uid {
		return &ErrConflict{Path: path, FieldName: "uid", OldVal: fmt.Sprintf("%d", appliedChange.stat.Uid), NewVal: fmt.Sprintf("%d", expectedStat.Uid)}
	}
	if appliedChange.stat.Gid != expectedStat.Gid {
		return &ErrConflict{Path: path, FieldName: "gid", OldVal: fmt.Sprintf("%d", appliedChange.stat.Gid), NewVal: fmt.Sprintf("%d", expectedStat.Gid)}
	}
	if appliedChange.stat.Size_ != expectedStat.Size_ {
		return &ErrConflict{Path: path, FieldName: "size", OldVal: fmt.Sprintf("%d", appliedChange.stat.Size()), NewVal: fmt.Sprintf("%d", expectedStat.Size_)}
	}
	if appliedChange.stat.Devmajor != expectedStat.Devmajor {
		return &ErrConflict{Path: path, FieldName: "devmajor", OldVal: fmt.Sprintf("%d", appliedChange.stat.Devmajor), NewVal: fmt.Sprintf("%d", expectedStat.Devmajor)}
	}
	if appliedChange.stat.Devminor != expectedStat.Devminor {
		return &ErrConflict{Path: path, FieldName: "devminor", OldVal: fmt.Sprintf("%d", appliedChange.stat.Devminor), NewVal: fmt.Sprintf("%d", expectedStat.Devminor)}
	}

	// Only compare link name when it's a symlink, not a hardlink. For hardlinks, whether the Linkname field
	// is set depends on whether or not the source of the link was included in the sync, which can vary between
	// different include/exclude settings on the same dir.
	if appliedChange.stat.Mode()&os.ModeType == os.ModeSymlink {
		if appliedChange.stat.Linkname != expectedStat.Linkname {
			return &ErrConflict{Path: path, FieldName: "linkname", OldVal: appliedChange.stat.Linkname, NewVal: expectedStat.Linkname}
		}
	}

	// Match the differ logic by only comparing modtime for regular files (as a heuristic to
	// expensive avoid content comparisons for every file that appears in a diff, using the
	// modtime as a proxy instead).
	//
	// We don't want to compare modtimes for directories right now since we explicitly don't
	// attempt to reset parent dir modtimes when a dirent is synced in or removed.
	if appliedChange.stat.Mode().IsRegular() {
		if appliedChange.stat.ModTime().UnixNano() != expectedStat.ModTime {
			return &ErrConflict{Path: path, FieldName: "mod time", OldVal: fmt.Sprintf("%d", appliedChange.stat.ModTime().UnixNano()), NewVal: fmt.Sprintf("%d", expectedStat.ModTime)}
		}
	}

	return nil
}

type ErrConflict struct {
	Path      string
	FieldName string
	OldVal    string
	NewVal    string
}

func (e *ErrConflict) Error() string {
	return fmt.Sprintf("conflict at %q: %s changed from %q to %q during sync", e.Path, e.FieldName, e.OldVal, e.NewVal)
}
