//go:build linux

package filesync

import (
	"context"
	"io/fs"
	"os"
	"path/filepath"
	"testing"

	"github.com/dagger/dagger/engine/contenthash"
	"github.com/dagger/dagger/engine/snapshots/testutil"
	"github.com/dagger/dagger/internal/fsutil"
	"github.com/dagger/dagger/internal/fsutil/types"
	"github.com/opencontainers/go-digest"
	"golang.org/x/sys/unix"
	"gotest.tools/v3/assert"
)

func init() {
	mirrorMetadataSkipXattrs.Store(os.Getenv("DAGGER_TEST_MIRROR_METADATA_SKIP_XATTRS") == "1")
}

func TestMirrorMetadataDigestCompatibility(t *testing.T) {
	defer mirrorMetadataSkipXattrs.Store(mirrorMetadataSkipXattrs.Load())
	store := testutil.NewStore(t)
	root := writeTree(t, map[string]string{"dir/file": "initial contents"})
	assert.NilError(t, os.Symlink("file", filepath.Join(root, "dir/symlink")))
	assert.NilError(t, unix.Setxattr(filepath.Join(root, "dir/file"), "user.client-metadata", []byte("client attribute"), 0))
	client, err := fsutil.NewFS(root)
	assert.NilError(t, err)
	locals := make([]*localFS, 2)
	for i, skip := range []bool{false, true} {
		mirrorMetadataSkipXattrs.Store(skip)
		locals[i], err = newLocalFS(NewMirrorSharedState(t.TempDir()), "", nil, nil, nil, "")
		assert.NilError(t, err)
	}
	var initial digest.Digest
	for _, stage := range []string{"cold", "warm", "missing-hash", "edit", "chmod"} {
		if stage == "missing-hash" {
			for _, local := range locals {
				assert.NilError(t, unix.Removexattr(filepath.Join(local.rootPath, "dir/file"), hashXattrKey))
			}
		}
		if stage == "edit" {
			assert.NilError(t, os.WriteFile(filepath.Join(root, "dir/file"), []byte("edited contents, different length"), 0644))
		}
		if stage == "chmod" {
			assert.NilError(t, os.Chmod(filepath.Join(root, "dir/file"), 0600))
		}
		var previous digest.Digest
		for i, local := range locals {
			ref, owner := syncPublished(t, store, local, client)
			t.Cleanup(func() {
				assert.NilError(t, ref.Release(context.Background()))
				assert.NilError(t, store.Manager.RemoveLease(context.Background(), owner))
			})
			got, err := contenthash.Checksum(t.Context(), ref, "/", contenthash.ChecksumOpts{})
			assert.NilError(t, err)
			if i == 0 {
				previous = got
			} else {
				assert.Equal(t, got, previous, "same imported digest with either metadata policy at "+stage)
			}
			expected, err := os.ReadFile(filepath.Join(root, "dir/file"))
			assert.NilError(t, err)
			assertSyncedFile(t, ref, "dir/file", string(expected))
			if stage == "cold" {
				err := local.Walk(t.Context(), "/", func(path string, entry fs.DirEntry, err error) error {
					if err != nil {
						return err
					}
					if path != "dir/file" {
						return nil
					}
					info, err := entry.Info()
					if err != nil {
						return err
					}
					stat := info.Sys().(*types.Stat)
					assert.Equal(t, len(stat.Xattrs) == 0, i == 1, "only the candidate mirror walk omits xattrs")
					return nil
				})
				assert.NilError(t, err)
			}
		}
		if stage == "cold" {
			initial = previous
		}
		if stage == "warm" || stage == "missing-hash" {
			assert.Equal(t, previous, initial, "retained hashes survive reuse and repair")
		}
		if stage == "edit" || stage == "chmod" {
			assert.Assert(t, previous != initial, "changed inputs change the digest")
		}
	}
}
