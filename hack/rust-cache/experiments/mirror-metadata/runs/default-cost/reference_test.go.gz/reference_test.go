//go:build linux

package fsutil

import (
	"context"
	"github.com/dagger/dagger/internal/fsutil/types"
	"github.com/pkg/errors"
	"io"
	gofs "io/fs"
	"os"
	"path/filepath"
)

type referenceMetadataFS struct {
	root string
}

func (fs *referenceMetadataFS) Walk(ctx context.Context, target string, fn gofs.WalkDirFunc) error {
	seenFiles := make(map[uint64]string)
	return filepath.WalkDir(filepath.Join(fs.root, target), func(path string, dirEntry gofs.DirEntry, walkErr error) (retErr error) {
		defer func() {
			if retErr != nil && isNotExist(retErr) {
				retErr = filepath.SkipDir
			}
		}()

		origpath := path
		path, err := filepath.Rel(fs.root, path)
		if err != nil {
			return err
		}
		// Skip root
		if path == "." {
			return nil
		}

		var entry gofs.DirEntry
		if dirEntry != nil {
			entry = &referenceMetadataDirEntryInfo{
				path:      path,
				origpath:  origpath,
				entry:     dirEntry,
				seenFiles: seenFiles,
			}
		}

		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
			if err := fn(path, entry, walkErr); err != nil {
				return err
			}
		}
		return nil
	})
}

func (fs *referenceMetadataFS) Open(p string) (io.ReadCloser, error) {
	rc, err := os.Open(filepath.Join(fs.root, p))
	return rc, errors.WithStack(err)
}

type referenceMetadataDirEntryInfo struct {
	*types.Stat

	entry     gofs.DirEntry
	path      string
	origpath  string
	seenFiles map[uint64]string
}

func (s *referenceMetadataDirEntryInfo) Name() string {
	if s.Stat != nil {
		return filepath.Base(s.Stat.Path)
	}
	return s.entry.Name()
}
func (s *referenceMetadataDirEntryInfo) IsDir() bool {
	if s.Stat != nil {
		return s.Stat.IsDir()
	}
	return s.entry.IsDir()
}
func (s *referenceMetadataDirEntryInfo) Type() gofs.FileMode {
	if s.Stat != nil {
		return gofs.FileMode(s.Stat.Mode)
	}
	return s.entry.Type()
}
func (s *referenceMetadataDirEntryInfo) Info() (gofs.FileInfo, error) {
	if s.Stat == nil {
		fi, err := s.entry.Info()
		if err != nil {
			return nil, err
		}
		stat, err := mkstat(s.origpath, s.path, fi, s.seenFiles, false)
		if err != nil {
			return nil, err
		}
		s.Stat = stat
	}

	st := *s.Stat
	return &StatInfo{&st}, nil
}
