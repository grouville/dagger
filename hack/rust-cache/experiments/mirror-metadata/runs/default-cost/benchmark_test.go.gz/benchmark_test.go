//go:build linux

package fsutil

import (
	"fmt"
	gofs "io/fs"
	"os"
	"path/filepath"
	"testing"

	"golang.org/x/sys/unix"
)

func BenchmarkMirrorMetadataWalk(b *testing.B) {
	for _, size := range []int{128, 1026} {
		b.Run(fmt.Sprint(size), func(b *testing.B) {
			root := b.TempDir()
			for n := range size {
				dir := filepath.Join(root, fmt.Sprintf("leaf_%04d", n))
				if err := os.MkdirAll(filepath.Join(dir, "src"), 0755); err != nil {
					b.Fatal(err)
				}
				for _, name := range []string{"Cargo.toml", "src/lib.rs"} {
					path := filepath.Join(dir, name)
					if err := os.WriteFile(path, []byte("test contents"), 0644); err != nil {
						b.Fatal(err)
					}
					if err := unix.Setxattr(path, "user.daggerContentHash.v2", []byte("xxh3:0123456789abcdef"), 0); err != nil {
						b.Fatal(err)
					}
				}
			}
			for _, reference := range []bool{false, true} {
				b.Run(fmt.Sprintf("reference=%t", reference), func(b *testing.B) {
					filesystem, err := NewFS(root)
					if reference {
						filesystem = &referenceMetadataFS{root: root}
					}
					if err != nil {
						b.Fatal(err)
					}
					b.ReportAllocs()
					b.ResetTimer()
					for b.Loop() {
						count := 0
						err := filesystem.Walk(b.Context(), "/", func(_ string, entry gofs.DirEntry, err error) error {
							if err != nil {
								return err
							}
							if _, err := entry.Info(); err != nil {
								return err
							}
							count++
							return nil
						})
						if err != nil {
							b.Fatal(err)
						}
						if count != size*4 {
							b.Fatalf("walked %d entries, expected %d", count, size*4)
						}
					}
				})
			}
		})
	}
}
