package dagql

import (
	"cmp"
	"context"
	"errors"
	"fmt"
	"math/bits"
	"slices"
	"time"

	"github.com/dagger/dagger/dagql/call"
	"github.com/dagger/dagger/util/hashutil"
	set "github.com/hashicorp/go-set/v3"
	"github.com/opencontainers/go-digest"
)

type eqClassID uint64
type egraphTermID uint64

type resultDigestPostingKind uint8

const (
	resultDigestPostingExact resultDigestPostingKind = iota
	resultDigestPostingBroad
)

// egraphTerm is purely symbolic: operation shape + canonicalized input/output
// equivalence state.
//
// Materialized payload ownership and output-digest indexing live on sharedResult
// and cache-level association maps.
type egraphTerm struct {
	// id is a unique immutable identifier for this term instance.
	// It is never rewritten during eq-class merges/repair.
	id egraphTermID

	// selfDigest identifies the operation shape itself, excluding input IDs.
	// Example: for withExec it includes exec args, but not input mount identities.
	selfDigest digest.Digest

	// inputEqIDs are the canonical eq-class IDs of this term's inputs.
	// These may be rewritten as classes merge and terms are repaired.
	inputEqIDs []eqClassID

	// termDigest is the memoized digest of (selfDigest + canonical inputEqIDs).
	// It is used for congruence checks ("same op over equivalent inputs").
	// This may be recomputed as inputEqIDs are repaired.
	termDigest string

	// outputEqID is the canonical eq-class ID for this term's output.
	// This may change as output classes are merged.
	outputEqID eqClassID
}

type egraphInputProvenanceKind string

const (
	egraphInputProvenanceKindResult egraphInputProvenanceKind = "result"
	egraphInputProvenanceKindDigest egraphInputProvenanceKind = "digest"
)

// egraphResultTermAssoc stores metadata for one result<->term association.
// Today this is just per-input provenance indicating whether each input slot
// was result-backed or digest-only when the association was created.
//
// NOTE: we intentionally assume for now that a congruent term will not be
// observed with conflicting provenance for the same input slot. If that ever
// does happen, the most recently observed provenance simply replaces the older
// one.
type egraphResultTermAssoc struct {
	inputProvenance []egraphInputProvenanceKind
}

func sameInputProvenance(a, b []egraphInputProvenanceKind) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

type eqMergePair struct {
	a eqClassID
	b eqClassID
}

func touchSharedResultLastUsed(res *sharedResult, nowUnixNano int64) {
	if res == nil {
		return
	}
	res.payloadMu.Lock()
	if nowUnixNano > res.lastUsedAtUnixNano {
		res.lastUsedAtUnixNano = nowUnixNano
	}
	res.payloadMu.Unlock()
}

func calcEgraphTermDigest(selfDigest digest.Digest, inputEqIDs []eqClassID) string {
	h := hashutil.NewHasher().WithString(selfDigest.String())
	for _, in := range inputEqIDs {
		h = h.WithDelim().
			WithUint64(uint64(in))
	}
	return h.DigestAndClose()
}

func compareEgraphTermID(a, b egraphTermID) int {
	return cmp.Compare(a, b)
}

func compareSharedResultID(a, b sharedResultID) int {
	return cmp.Compare(a, b)
}

func newEgraphTermIDSet() *set.TreeSet[egraphTermID] {
	return set.NewTreeSet(compareEgraphTermID)
}

func newSharedResultIDSet() *set.TreeSet[sharedResultID] {
	return set.NewTreeSet(compareSharedResultID)
}

func (c *Cache) ensureTermInputEqIDsLocked(ctx context.Context, inputDigests []digest.Digest) []eqClassID {
	inputEqIDs := make([]eqClassID, len(inputDigests))
	for i, inDig := range inputDigests {
		inputEqIDs[i] = c.findEqClassLocked(c.ensureEqClassForDigestLocked(ctx, inDig.String()))
	}
	return inputEqIDs
}

func (c *Cache) inputProvenanceForRefs(inputRefs []ResultCallStructuralInputRef) ([]egraphInputProvenanceKind, error) {
	inputProvenance := make([]egraphInputProvenanceKind, 0, len(inputRefs))
	for _, ref := range inputRefs {
		if err := ref.Validate(); err != nil {
			return nil, err
		}
		switch {
		case ref.Result != nil:
			inputProvenance = append(inputProvenance, egraphInputProvenanceKindResult)
		case ref.Digest != "":
			inputProvenance = append(inputProvenance, egraphInputProvenanceKindDigest)
		default:
			return nil, fmt.Errorf("structural input ref has neither ID nor digest")
		}
	}
	return inputProvenance, nil
}

func newEgraphTerm(
	id egraphTermID,
	selfDigest digest.Digest,
	inputEqIDs []eqClassID,
	outputEqID eqClassID,
) *egraphTerm {
	return &egraphTerm{
		id:         id,
		selfDigest: selfDigest,
		inputEqIDs: inputEqIDs,
		outputEqID: outputEqID,
		termDigest: calcEgraphTermDigest(selfDigest, inputEqIDs),
	}
}

func (c *Cache) initEgraphLocked() {
	if c.egraphDigestToClass == nil {
		c.egraphDigestToClass = make(map[string]eqClassID)
	}
	if c.egraphParents == nil {
		// index 0 is reserved as "unset"
		c.egraphParents = []eqClassID{0}
	}
	if c.egraphRanks == nil {
		c.egraphRanks = []uint8{0}
	}
	if c.eqClassToDigests == nil {
		c.eqClassToDigests = make(map[eqClassID]map[string]struct{})
	}
	if c.eqClassExtraDigests == nil {
		c.eqClassExtraDigests = make(map[eqClassID]map[call.ExtraDigest]struct{})
	}
	if c.inputEqClassToTerms == nil {
		c.inputEqClassToTerms = make(map[eqClassID]map[egraphTermID]struct{})
	}
	if c.outputEqClassToTerms == nil {
		c.outputEqClassToTerms = make(map[eqClassID]map[egraphTermID]struct{})
	}
	if c.resultOutputEqClasses == nil {
		c.resultOutputEqClasses = make(map[sharedResultID]map[eqClassID]struct{})
	}
	if c.outputEqClassResults == nil {
		c.outputEqClassResults = make(map[eqClassID]map[sharedResultID]struct{})
	}
	if c.termResults == nil {
		c.termResults = make(map[egraphTermID]map[sharedResultID]egraphResultTermAssoc)
	}
	if c.resultTerms == nil {
		c.resultTerms = make(map[sharedResultID]map[egraphTermID]struct{})
	}
	if c.egraphTerms == nil {
		c.egraphTerms = make(map[egraphTermID]*egraphTerm)
	}
	if c.egraphTermsByTermDigest == nil {
		c.egraphTermsByTermDigest = make(map[string]*set.TreeSet[egraphTermID])
	}
	if c.egraphResultsByDigest == nil {
		c.egraphResultsByDigest = make(map[string]*set.TreeSet[sharedResultID])
	}
	if c.resultIndexedDigests == nil {
		c.resultIndexedDigests = make(map[sharedResultID][]string)
	}
	if c.broadlyIndexedResults == nil {
		c.broadlyIndexedResults = make(map[sharedResultID]struct{})
	}
	if c.termInputProvenance == nil {
		c.termInputProvenance = make(map[egraphTermID][]egraphInputProvenanceKind)
	}
	if c.resultsByID == nil {
		c.resultsByID = make(map[sharedResultID]*sharedResult)
	}
	if c.nextEgraphClassID == 0 {
		c.nextEgraphClassID = 1
	}
	if c.nextEgraphTermID == 0 {
		c.nextEgraphTermID = 1
	}
	if c.nextSharedResultID == 0 {
		c.nextSharedResultID = 1
	}
}

func (c *Cache) ensureEqClassForDigestLocked(ctx context.Context, dig string) eqClassID {
	if dig == "" {
		return 0
	}
	c.initEgraphLocked()
	if id, ok := c.egraphDigestToClass[dig]; ok {
		return c.findEqClassLocked(id)
	}
	id := c.nextEgraphClassID
	c.nextEgraphClassID++
	c.egraphParents = append(c.egraphParents, id)
	c.egraphRanks = append(c.egraphRanks, 0)
	c.egraphDigestToClass[dig] = id
	digests := c.eqClassToDigests[id]
	if digests == nil {
		digests = make(map[string]struct{}, 1)
		c.eqClassToDigests[id] = digests
	}
	digests[dig] = struct{}{}
	c.traceEqClassCreated(ctx, id, dig)
	return id
}

func (c *Cache) findEqClassLocked(id eqClassID) eqClassID {
	if id == 0 || int(id) >= len(c.egraphParents) {
		return 0
	}
	root := id
	for c.egraphParents[root] != root {
		root = c.egraphParents[root]
	}
	for id != root {
		parent := c.egraphParents[id]
		c.egraphParents[id] = root
		id = parent
	}
	return root
}

// mergeEqClassesNoRepairLocked unions the classes of a and b and returns the
// surviving root. absorbedInputTerms reports whether the union moved input
// terms from the losing root to the survivor; those terms are still keyed by
// the losing root until the survivor is repaired.
func (c *Cache) mergeEqClassesNoRepairLocked(a, b eqClassID) (root eqClassID, absorbedInputTerms bool) {
	ra := c.findEqClassLocked(a)
	rb := c.findEqClassLocked(b)
	if ra == 0 {
		return rb, false
	}
	if rb == 0 {
		return ra, false
	}
	if ra == rb {
		return ra, false
	}

	// union by rank
	if c.egraphRanks[ra] < c.egraphRanks[rb] {
		ra, rb = rb, ra
	}
	c.egraphParents[rb] = ra
	if c.egraphRanks[ra] == c.egraphRanks[rb] {
		c.egraphRanks[ra]++
	}

	// merge reverse digest indexes
	dstDigests := c.eqClassToDigests[ra]
	srcDigests := c.eqClassToDigests[rb]
	if len(srcDigests) > 0 {
		if dstDigests == nil {
			dstDigests = make(map[string]struct{}, len(srcDigests))
			c.eqClassToDigests[ra] = dstDigests
		}
		for dig := range srcDigests {
			dstDigests[dig] = struct{}{}
		}
		delete(c.eqClassToDigests, rb)
	}

	dstExtraDigests := c.eqClassExtraDigests[ra]
	srcExtraDigests := c.eqClassExtraDigests[rb]
	if len(srcExtraDigests) > 0 {
		if dstExtraDigests == nil {
			dstExtraDigests = make(map[call.ExtraDigest]struct{}, len(srcExtraDigests))
			c.eqClassExtraDigests[ra] = dstExtraDigests
		}
		for extra := range srcExtraDigests {
			dstExtraDigests[extra] = struct{}{}
		}
		delete(c.eqClassExtraDigests, rb)
	}

	// merge reverse input-term indexes
	dst := c.inputEqClassToTerms[ra]
	src := c.inputEqClassToTerms[rb]
	if len(src) > 0 {
		if dst == nil {
			dst = make(map[egraphTermID]struct{}, len(src))
			c.inputEqClassToTerms[ra] = dst
		}
		for termID := range src {
			dst[termID] = struct{}{}
		}
		delete(c.inputEqClassToTerms, rb)
		absorbedInputTerms = true
	}

	// merge reverse output-term indexes
	dstOutputTerms := c.outputEqClassToTerms[ra]
	srcOutputTerms := c.outputEqClassToTerms[rb]
	if len(srcOutputTerms) > 0 {
		if dstOutputTerms == nil {
			dstOutputTerms = make(map[egraphTermID]struct{}, len(srcOutputTerms))
			c.outputEqClassToTerms[ra] = dstOutputTerms
		}
		for termID := range srcOutputTerms {
			dstOutputTerms[termID] = struct{}{}
		}
		delete(c.outputEqClassToTerms, rb)
	}

	// Merge result/output-class associations and eagerly rewrite the moved
	// results' forward entries to the winning canonical root.
	dstResults := c.outputEqClassResults[ra]
	srcResults := c.outputEqClassResults[rb]
	joinsEntries := len(dstResults) > 0 && len(srcResults) > 0
	if len(srcResults) > 0 {
		if dstResults == nil {
			dstResults = make(map[sharedResultID]struct{}, len(srcResults))
			c.outputEqClassResults[ra] = dstResults
		}
		for resID := range srcResults {
			dstResults[resID] = struct{}{}
			if outputEqClasses := c.resultOutputEqClasses[resID]; outputEqClasses != nil {
				delete(outputEqClasses, rb)
				outputEqClasses[ra] = struct{}{}
			}
		}
		delete(c.outputEqClassResults, rb)
	}

	// An actual union: the winner's membership and reverse indexes are in
	// place. Pending queue keys are recanonicalized in the same union.
	c.recordShareUnionLocked(ra, rb)
	if joinsEntries {
		c.noteJoinedEntriesLocked(ra)
	}
	return ra, absorbedInputTerms
}

func (c *Cache) mergeEqClassesLocked(ctx context.Context, ids ...eqClassID) eqClassID {
	if len(ids) == 0 {
		return 0
	}
	if len(ids) == 1 {
		return c.findEqClassLocked(ids[0])
	}

	root := c.findEqClassLocked(ids[0])
	for _, id := range ids[1:] {
		root, _ = c.mergeEqClassesNoRepairLocked(root, id)
	}
	c.traceEqClassMerged(ctx, ids, root)

	// Repair until closure. A root is repaired again only after a union moves
	// input terms into it, since those terms are still keyed by the losing
	// root. Each such union removes a root for good, so a root is repaired at
	// most once plus once per union that grew it, and the loop terminates.
	toRepair := []eqClassID{root}
	repaired := make(map[eqClassID]struct{})
	for len(toRepair) > 0 {
		cur := c.findEqClassLocked(toRepair[len(toRepair)-1])
		toRepair = toRepair[:len(toRepair)-1]
		if cur == 0 {
			continue
		}
		if _, ok := repaired[cur]; ok {
			continue
		}
		repaired[cur] = struct{}{}
		for _, pair := range c.repairClassTermsLocked(ctx, cur) {
			next, absorbedInputTerms := c.mergeEqClassesNoRepairLocked(pair.a, pair.b)
			if next == 0 {
				continue
			}
			if absorbedInputTerms {
				delete(repaired, next)
			}
			toRepair = append(toRepair, next)
		}
	}
	return c.findEqClassLocked(ids[0])
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (c *Cache) repairClassTermsLocked(ctx context.Context, root eqClassID) (merges []eqMergePair) {
	termSet := c.inputEqClassToTerms[root]
	if len(termSet) == 0 {
		return nil
	}
	traceEnabled := c.traceEnabled()

	termIDs := make([]egraphTermID, 0, len(termSet))
	for termID := range termSet {
		termIDs = append(termIDs, termID)
	}
	processedTermDigests := make(map[string]struct{}, len(termIDs))

	for _, termID := range termIDs {
		term := c.egraphTerms[termID]
		if term == nil {
			delete(termSet, termID)
			continue
		}

		oldInputs := term.inputEqIDs
		var newInputs []eqClassID
		inputsChanged := false
		for i, in := range oldInputs {
			rootIn := c.findEqClassLocked(in)
			if rootIn == in {
				continue
			}
			if !inputsChanged {
				newInputs = append([]eqClassID(nil), oldInputs...)
				inputsChanged = true
			}
			newInputs[i] = rootIn
		}

		if inputsChanged {
			for _, in := range oldInputs {
				if set := c.inputEqClassToTerms[in]; set != nil {
					delete(set, termID)
					if len(set) == 0 {
						delete(c.inputEqClassToTerms, in)
					}
				}
			}
			for _, in := range newInputs {
				if in == 0 {
					continue
				}
				set := c.inputEqClassToTerms[in]
				if set == nil {
					set = make(map[egraphTermID]struct{})
					c.inputEqClassToTerms[in] = set
				}
				set[termID] = struct{}{}
			}
			term.inputEqIDs = newInputs

			oldTermDigest := term.termDigest
			newTermDigest := calcEgraphTermDigest(term.selfDigest, newInputs)
			if set := c.egraphTermsByTermDigest[term.termDigest]; set != nil {
				set.Remove(termID)
				if set.Empty() {
					delete(c.egraphTermsByTermDigest, term.termDigest)
				}
			}
			set := c.egraphTermsByTermDigest[newTermDigest]
			if set == nil {
				set = newEgraphTermIDSet()
				c.egraphTermsByTermDigest[newTermDigest] = set
			}
			set.Insert(termID)
			term.termDigest = newTermDigest

			if traceEnabled {
				oldInputsCopy := append([]eqClassID(nil), oldInputs...)
				c.traceTermInputsRepaired(ctx, term.id, oldInputsCopy, newInputs)
				c.traceTermRehomedUnderEqClasses(ctx, term.id, newInputs)
				c.traceTermDigestRecomputed(ctx, term.id, oldTermDigest, newTermDigest)
			}
		}

		processedTermDigests[term.termDigest] = struct{}{}
	}

	for termDigest := range processedTermDigests {
		set := c.egraphTermsByTermDigest[termDigest]
		if set == nil || set.Size() <= 1 {
			continue
		}

		var first *egraphTerm
		for otherID := range set.Items() {
			other := c.egraphTerms[otherID]
			if other == nil {
				continue
			}
			if first == nil || other.id < first.id {
				first = other
			}
		}
		if first == nil {
			continue
		}
		for otherID := range set.Items() {
			other := c.egraphTerms[otherID]
			if other == nil || other.id == first.id {
				continue
			}
			if traceEnabled {
				c.traceTermOutputsMerged(ctx, first.id, other.id, first.outputEqID, other.outputEqID)
			}
			merges = append(merges, eqMergePair{
				a: first.outputEqID,
				b: other.outputEqID,
			})
		}
	}
	return merges
}

func (c *Cache) firstLiveTermInSetLocked(termSet *set.TreeSet[egraphTermID]) *egraphTerm {
	if termSet == nil {
		return nil
	}
	for termID := range termSet.Items() {
		term := c.egraphTerms[termID]
		if term == nil {
			continue
		}
		return term
	}
	return nil
}

func (c *Cache) hasUnexpiredResultForOutputEqClassLocked(
	outputEqID eqClassID,
	nowUnix int64,
) bool {
	outputEqID = c.findEqClassLocked(outputEqID)
	if outputEqID == 0 {
		return false
	}
	for resID := range c.outputEqClassResults[outputEqID] {
		res := c.resultsByID[resID]
		if res == nil {
			continue
		}
		if res.hasUnexpiredHoldingLocked(nowUnix) {
			// Another cache's unexpired stored copy keeps the class's
			// terms: the equivalence stays usable while any value in it is.
			return true
		}
		if res.noValueLocked() || c.resultExpiredAtLocked(res, nowUnix) {
			continue
		}
		return true
	}
	return false
}

func (c *Cache) resultExpiredAtLocked(res *sharedResult, nowUnix int64) bool {
	if res == nil || res.expiresAtUnix == 0 {
		return false
	}
	return nowUnix >= res.expiresAtUnix
}

type lookupMatch struct {
	selfDigest            digest.Digest
	inputDigests          []digest.Digest
	inputEqIDs            []eqClassID
	primaryLookupPossible bool
	missingInputIndex     int
	hitRecipeDigest       bool
	candidates            *set.TreeSet[*sharedResult]
	termDigest            string
	termSetSize           int
	// route records which index produced the current candidate set — the
	// cache-evidence hit provenance (CacheHitRouteRecipe/Digest/Structural).
	// Purely observational: candidate gathering and selection are unchanged.
	route CacheHitRoute
	// sawExpired records that expiry dropped at least one otherwise-matching
	// result during candidate accumulation (cache-evidence miss fact).
	sawExpired bool
}

func newSharedResultSet() *set.TreeSet[*sharedResult] {
	return set.NewTreeSet(compareSharedResults)
}

// sawExpired, when non-nil, is set to true if expiry drops at least one
// otherwise-matching result during accumulation (cache-evidence miss fact);
// candidate gathering itself is unchanged.
func (c *Cache) appendDigestResultsLocked(candidates *set.TreeSet[*sharedResult], dig digest.Digest, nowUnix int64, sawExpired *bool) {
	if dig == "" {
		return
	}
	resultSet := c.egraphResultsByDigest[dig.String()]
	if resultSet == nil {
		return
	}
	for resID := range resultSet.Items() {
		if res := c.servableCandidateLocked(resID, nowUnix, sawExpired); res != nil {
			candidates.Insert(res)
		}
	}
}

// appendOutputEqClassResultsLocked adds the servable results of an output
// eq-class root, read from outputEqClassResults. It finds the same results
// as appendDigestResultsLocked over every digest of the class: a result is
// posted only under digests merged into one of its output classes, and every
// output class of a result holds a digest it is posted under.
func (c *Cache) appendOutputEqClassResultsLocked(candidates *set.TreeSet[*sharedResult], root eqClassID, nowUnix int64) {
	for resID := range c.outputEqClassResults[root] {
		if res := c.servableCandidateLocked(resID, nowUnix, nil); res != nil {
			candidates.Insert(res)
		}
	}
}

// servableCandidateLocked returns the result lookup may serve for resID, or
// nil. sawExpired is set as in appendDigestResultsLocked.
func (c *Cache) servableCandidateLocked(resID sharedResultID, nowUnix int64, sawExpired *bool) *sharedResult {
	res := c.resultsByID[resID]
	if res == nil {
		return nil
	}
	if res.attachmentState() == resultAttachmentFailed {
		return nil
	}
	// An entry known only through holdings has no value to serve.
	if res.noValueLocked() {
		return nil
	}
	if c.resultExpiredAtLocked(res, nowUnix) {
		if sawExpired != nil {
			*sawExpired = true
		}
		return nil
	}
	return res
}

func (c *Cache) appendTermSetResultsLocked(candidates *set.TreeSet[*sharedResult], termSet *set.TreeSet[egraphTermID], nowUnix int64, sawExpired *bool) {
	if termSet == nil {
		return
	}

	for termID := range termSet.Items() {
		for resID := range c.termResults[termID] {
			if res := c.servableCandidateLocked(resID, nowUnix, sawExpired); res != nil {
				candidates.Insert(res)
			}
		}
	}
	if !candidates.Empty() {
		return
	}

	seenOutputEqClasses := make(map[eqClassID]struct{}, termSet.Size())
	for termID := range termSet.Items() {
		term := c.egraphTerms[termID]
		if term == nil {
			continue
		}
		outputEqID := c.findEqClassLocked(term.outputEqID)
		if outputEqID == 0 {
			continue
		}
		if _, ok := seenOutputEqClasses[outputEqID]; ok {
			continue
		}
		seenOutputEqClasses[outputEqID] = struct{}{}
		for dig := range c.eqClassToDigests[outputEqID] {
			c.appendDigestResultsLocked(candidates, digest.Digest(dig), nowUnix, sawExpired)
		}
	}
}

func (c *Cache) sessionSatisfiesResourceRequirementsLocked(sessionID string, res *sharedResult) bool {
	if res == nil || res.requiredSessionResources == nil || res.requiredSessionResources.Empty() {
		return true
	}

	// The set is immutable once published (BindSessionResource replaces it),
	// so it can be read after sessionMu is dropped.
	c.sessionMu.Lock()
	available := c.sessionHandlesBySession[sessionID]
	c.sessionMu.Unlock()
	if available == nil {
		return false
	}
	return available.Subset(res.requiredSessionResources)
}

// sessionStillSatisfiesResourceRequirements re-runs the lookup filter after
// a serve path left the selection critical section. The stored required set
// can grow after selection: an attached dep may carry requirements while
// the result's attachment is in flight, and an explicit retention edge
// (AddExplicitDependency) may land a requirement-carrying dep after the
// result settled. Every change to the stored set bumps the result's
// requirement generation inside the same egraphMu write critical section,
// so a serve whose selection-time capture still matches the current
// generation is serving the exact set the selection check validated and
// skips the locked re-check; on a mismatch the full locked subset check
// decides.
func (c *Cache) sessionStillSatisfiesResourceRequirements(sessionID string, res *sharedResult, requiredGenAtSelection uint64) bool {
	if res == nil {
		return true
	}
	if res.requiredSessionResourcesGen.Load() == requiredGenAtSelection {
		return true
	}
	c.egraphMu.RLock()
	defer c.egraphMu.RUnlock()
	return c.sessionSatisfiesResourceRequirementsLocked(sessionID, res)
}

func (c *Cache) selectLookupCandidateForSessionLocked(sessionID string, candidates *set.TreeSet[*sharedResult]) *sharedResult {
	if candidates == nil {
		return nil
	}
	for res := range candidates.Items() {
		if c.sessionSatisfiesResourceRequirementsLocked(sessionID, res) {
			return res
		}
	}
	return nil
}

func (c *Cache) lookupMatchForDigestsLocked(recipeDigest digest.Digest, extraDigests []call.ExtraDigest, nowUnix int64) lookupMatch {
	match := lookupMatch{
		primaryLookupPossible: true,
		missingInputIndex:     -1,
	}
	if recipeDigest == "" {
		return match
	}

	candidates := newSharedResultSet()
	c.appendDigestResultsLocked(candidates, recipeDigest, nowUnix, &match.sawExpired)
	if !candidates.Empty() {
		match.candidates = candidates
		match.hitRecipeDigest = true
		match.route = CacheHitRouteRecipe
		return match
	}
	for _, extra := range extraDigests {
		c.appendDigestResultsLocked(candidates, extra.Digest, nowUnix, &match.sawExpired)
	}
	if !candidates.Empty() {
		match.candidates = candidates
		match.route = CacheHitRouteDigest
	}
	return match
}

func (c *Cache) lookupMatchForCallLocked(
	frame *ResultCall,
	recipeDigest digest.Digest,
	selfDigest digest.Digest,
	inputDigests []digest.Digest,
	nowUnix int64,
) lookupMatch {
	match := lookupMatch{
		primaryLookupPossible: true,
		missingInputIndex:     -1,
	}
	if frame == nil {
		return match
	}

	match = c.lookupMatchForDigestsLocked(recipeDigest, frame.ExtraDigests, nowUnix)
	if match.candidates != nil && !match.candidates.Empty() {
		return match
	}

	match.selfDigest = selfDigest
	match.inputDigests = inputDigests
	match.inputEqIDs = make([]eqClassID, len(inputDigests))
	for i, inDig := range inputDigests {
		classID, ok := c.egraphDigestToClass[inDig.String()]
		if !ok {
			match.primaryLookupPossible = false
			match.missingInputIndex = i
			break
		}
		root := c.findEqClassLocked(classID)
		if root == 0 {
			match.primaryLookupPossible = false
			match.missingInputIndex = i
			break
		}
		match.inputEqIDs[i] = root
	}
	if match.primaryLookupPossible {
		match.termDigest = calcEgraphTermDigest(selfDigest, match.inputEqIDs)
		termSet := c.egraphTermsByTermDigest[match.termDigest]
		if termSet != nil {
			match.termSetSize = termSet.Size()
		}
		candidates := newSharedResultSet()
		c.appendTermSetResultsLocked(candidates, termSet, nowUnix, &match.sawExpired)
		if !candidates.Empty() {
			match.candidates = candidates
			match.route = CacheHitRouteStructural
		}
	}
	return match
}

func (c *Cache) indexResultDigestsLocked(res *sharedResult, requestFrame, responseFrame *ResultCall) error {
	if res == nil {
		return nil
	}
	c.initEgraphLocked()

	indexFrame := func(frame *ResultCall) error {
		if frame == nil {
			return nil
		}
		dig, err := frame.deriveRecipeDigest(c)
		if err != nil {
			return err
		}
		c.addFramePostingsLocked(res.id, dig, frame.ExtraDigests)
		return nil
	}
	if err := indexFrame(requestFrame); err != nil {
		return fmt.Errorf("index request digests: %w", err)
	}
	if err := indexFrame(responseFrame); err != nil {
		return fmt.Errorf("index response digests: %w", err)
	}
	return nil
}

// addResultDigestPostingLocked requires egraphMu and an e-graph initialized by
// initEgraphLocked.
func (c *Cache) addResultDigestPostingLocked(resID sharedResultID, dig string, kind resultDigestPostingKind) {
	if resID == 0 || dig == "" {
		return
	}
	switch kind {
	case resultDigestPostingExact, resultDigestPostingBroad:
	default:
		return
	}
	results := c.egraphResultsByDigest[dig]
	if results == nil {
		results = newSharedResultIDSet()
		c.egraphResultsByDigest[dig] = results
	}
	inserted := results.Insert(resID)
	if kind == resultDigestPostingExact && inserted {
		c.resultIndexedDigests[resID] = append(c.resultIndexedDigests[resID], dig)
	}
}

// markResultBroadlyIndexedLocked requires egraphMu and an e-graph initialized
// by initEgraphLocked.
func (c *Cache) markResultBroadlyIndexedLocked(resID sharedResultID) {
	if resID == 0 {
		return
	}
	c.broadlyIndexedResults[resID] = struct{}{}
}

func (c *Cache) removeResultDigestPostingLocked(resID sharedResultID, dig string) {
	if resID == 0 || dig == "" {
		return
	}
	results := c.egraphResultsByDigest[dig]
	if results == nil {
		return
	}
	results.Remove(resID)
	if results.Empty() {
		delete(c.egraphResultsByDigest, dig)
	}
}

func (c *Cache) removeResultDigestsLocked(resID sharedResultID, outputEqClasses map[eqClassID]struct{}) {
	if resID == 0 {
		return
	}

	for _, dig := range c.resultIndexedDigests[resID] {
		c.removeResultDigestPostingLocked(resID, dig)
	}
	if _, broad := c.broadlyIndexedResults[resID]; broad {
		for outputEqID := range outputEqClasses {
			outputEqID = c.findEqClassLocked(outputEqID)
			if outputEqID == 0 {
				continue
			}
			for dig := range c.eqClassToDigests[outputEqID] {
				c.removeResultDigestPostingLocked(resID, dig)
			}
		}
	}
	delete(c.resultIndexedDigests, resID)
	delete(c.broadlyIndexedResults, resID)
}

// lookupCacheForRequestLocked checks if the given call ID has an equivalent result in the cache.
// It first attempts direct digest lookup using the request recipe/extra digests. If that misses,
// it falls back to the canonical term lookup using (self, input eq-classes).
//
// This method assumes egraphMu is already held by the caller.
func (c *Cache) lookupCacheForRequestLocked(
	ctx context.Context,
	sessionID string,
	req *CallRequest,
	requestDigest digest.Digest,
	requestSelf digest.Digest,
	requestInputs []digest.Digest,
	requestInputRefs []ResultCallStructuralInputRef,
) (AnyResult, bool, int64, error) {
	if req == nil || req.ResultCall == nil {
		return nil, false, 0, nil
	}
	now := time.Now()
	nowUnix := now.Unix()
	persistedEdgeExpiresAtUnix := candidateSharedResultExpiryUnix(nowUnix, req.TTL)
	var match lookupMatch
	if req.ListItem {
		match = c.lookupMatchForListItemLocked(req, nowUnix)
	} else {
		match = c.lookupMatchForCallLocked(req.ResultCall, requestDigest, requestSelf, requestInputs, nowUnix)
	}
	c.traceLookupAttempt(ctx, requestDigest.String(), match.selfDigest.String(), match.inputDigests, req.IsPersistable)
	hitRes := c.selectLookupCandidateForSessionLocked(sessionID, match.candidates)

	// Fill the request's cache-evidence carrier (when armed) with the facts
	// that exist only at this decision point; plain field writes of values
	// already in hand, changing nothing about the lookup itself.
	if ev := req.CacheEvidence; ev != nil {
		if hitRes != nil {
			ev.HitRoute = match.route
		} else {
			ev.MissSawExpired = match.sawExpired
			// Expiry is applied during accumulation, so a non-empty candidate
			// set on a miss means every surviving candidate failed the
			// session-resource filter.
			ev.MissIncompatibleCandidates = match.candidates != nil && !match.candidates.Empty()
			if !match.primaryLookupPossible {
				ev.MissUnknownInputIndex = match.missingInputIndex
			}
		}
	}

	if hitRes == nil {
		c.traceLookupMissNoMatch(ctx, requestDigest.String(), match.primaryLookupPossible, match.missingInputIndex, match.termDigest, match.termSetSize)
		return nil, false, 0, nil
	}

	// fast-path: if we got a very simple recipe-digest hit we can skip trying to teach the egraph anything new
	if requestDigest != "" && len(req.ResultCall.ExtraDigests) == 0 && req.TTL == 0 && !req.IsPersistable && match.hitRecipeDigest {
		touchSharedResultLastUsed(hitRes, now.UnixNano())
		retRes := Result[Typed]{
			shared:   hitRes,
			hitCache: true,
		}
		c.traceLookupHit(ctx, requestDigest.String(), hitRes, match.termDigest)
		return retRes, true, 0, nil
	}

	// We have a cache hit. Teach this request identity onto the existing shared
	// result so any raw ID we hand back is itself resolvable by the cache later.
	res := hitRes
	// A TTL-bearing call can alias an existing result on lookup; apply the same
	// conservative expiry merge policy here so TTL remains effective on hits.
	res.expiresAtUnix = mergeSharedResultExpiryUnix(
		res.expiresAtUnix,
		persistedEdgeExpiresAtUnix,
	)
	touchSharedResultLastUsed(res, now.UnixNano())
	if err := c.teachResultIdentityLocked(ctx, res, req.ResultCall, requestDigest, requestSelf, requestInputs, requestInputRefs); err != nil {
		return nil, false, 0, err
	}
	retRes := Result[Typed]{
		shared:   res,
		hitCache: true,
	}
	c.traceLookupHit(ctx, requestDigest.String(), res, match.termDigest)
	return retRes, true, persistedEdgeExpiresAtUnix, nil
}

func (c *Cache) lookupCacheForRequest(
	ctx context.Context,
	sessionID string,
	resolver TypeResolver,
	req *CallRequest,
	requestDigest digest.Digest,
	requestSelf digest.Digest,
	requestInputs []digest.Digest,
	requestInputRefs []ResultCallStructuralInputRef,
) (AnyResult, bool, error) {
	if sessionID == "" {
		return nil, false, errors.New("lookup cache for request: empty session ID")
	}
	if resolver == nil {
		return nil, false, errors.New("lookup cache for request: type resolver is nil")
	}
	if req == nil || req.ResultCall == nil {
		return nil, false, nil
	}

	c.egraphMu.Lock()
	// One collector for this E interval: identity teaching can union classes
	// or insert a new membership, and both are flushed before the unlock.
	notify, notifyOwner := c.beginShareNotificationsLocked()
	retRes, hit, persistedEdgeExpiresAtUnix, err := c.lookupCacheForRequestLocked(ctx, sessionID, req, requestDigest, requestSelf, requestInputs, requestInputRefs)
	if err != nil || !hit {
		c.flushShareNotificationsLocked(ctx, notify, notifyOwner)
		c.egraphMu.Unlock()
		return retRes, hit, err
	}

	hitShared := retRes.cacheSharedResult()
	if hitShared == nil || hitShared.id == 0 {
		c.flushShareNotificationsLocked(ctx, notify, notifyOwner)
		c.egraphMu.Unlock()
		return nil, false, fmt.Errorf("lookup cache for request: hit missing shared result ID")
	}

	_, trackedCount, err := c.acquireSessionResultLocked(ctx, sessionID, hitShared)
	// Capture the requirement generation inside the same critical section
	// that ran the selection-time subset check. Captured after the unlock, a
	// concurrent growth's bump could already be reflected in the captured
	// value, the serve-time comparison would see equality, and the stale
	// serve would go through.
	requiredGenAtSelection := hitShared.requiredSessionResourcesGen.Load()
	c.flushShareNotificationsLocked(ctx, notify, notifyOwner)
	c.egraphMu.Unlock()
	if err != nil {
		return nil, false, err
	}

	loadedHit, err := c.ensurePersistedHitValueLoaded(ctx, resolver, retRes)
	if err != nil {
		if errors.Is(err, errAttachRefusedByProducerRelease) {
			// The hit's attachment failed only because the producing
			// session was released before its attachment-time claim ran.
			// This reader is innocent and a fresh execution would succeed,
			// so fall through to the singleflight instead of surfacing the
			// producer's release as this caller's failure. The recorded
			// session edge stays until session release, exactly as the
			// requirement re-validation's miss conversion below keeps it.
			return nil, false, nil
		}
		return nil, false, err
	}
	if c.testBeforeServeRequirementRecheck != nil {
		c.testBeforeServeRequirementRecheck(hitShared)
	}
	if !c.sessionStillSatisfiesResourceRequirements(sessionID, hitShared, requiredGenAtSelection) {
		// The required set grew after this hit was selected (an attached or
		// late explicit dep carried requirements), so serving would hand
		// the session a result it no longer satisfies. Fall through to the
		// singleflight instead. The recorded session edge stays until
		// session release; over-retaining one result is cheaper than a
		// dedicated decrement-and-collect path here.
		return nil, false, nil
	}
	if req.IsPersistable {
		// Only persistable hits pay this second graph-lock acquisition. Keep
		// the expiry captured at hit selection even if the barrier wait took
		// long enough to cross a wall-clock second.
		c.egraphMu.Lock()
		c.upsertPersistedEdgeLocked(ctx, hitShared, persistedEdgeExpiresAtUnix, false)
		c.egraphMu.Unlock()
	}

	if c.traceEnabled() {
		c.traceSessionResultTracked(ctx, sessionID, loadedHit, true, trackedCount)
	}
	return loadedHit, true, nil
}

func (c *Cache) TeachCallEquivalentToResult(ctx context.Context, sessionID string, frame *ResultCall, res AnyResult) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if sessionID != "" && c.sessionLifecycle(sessionID).lifecycle.Load()&cacheSessionReleasedBit != 0 {
		return fmt.Errorf("%w: %q", ErrCacheSessionReleased, sessionID)
	}
	if frame == nil {
		return fmt.Errorf("teach call equivalence: nil call")
	}
	if res == nil {
		return fmt.Errorf("teach call equivalence: nil result")
	}

	shared := res.cacheSharedResult()
	if shared == nil || shared.id == 0 {
		if sessionID == "" {
			return fmt.Errorf("teach call equivalence: empty session ID for detached result")
		}
		attached, err := c.AttachResult(ctx, sessionID, CurrentDagqlServer(ctx), res)
		if err != nil {
			return fmt.Errorf("teach call equivalence: attach result: %w", err)
		}
		res = attached
		shared = res.cacheSharedResult()
	}
	if shared == nil || shared.id == 0 {
		return fmt.Errorf("teach call equivalence: target result missing shared result ID")
	}

	requestDigest, err := frame.deriveRecipeDigest(c)
	if err != nil {
		return fmt.Errorf("teach call equivalence: derive request digest: %w", err)
	}
	requestSelf, requestInputRefs, err := frame.selfDigestAndInputRefs(c)
	if err != nil {
		return fmt.Errorf("teach call equivalence: derive request term digests: %w", err)
	}
	requestInputs := make([]digest.Digest, 0, len(requestInputRefs))
	for _, ref := range requestInputRefs {
		dig, err := ref.inputDigest(c)
		if err != nil {
			return fmt.Errorf("teach call equivalence: derive request term input digest: %w", err)
		}
		requestInputs = append(requestInputs, dig)
	}

	c.egraphMu.Lock()
	notify, notifyOwner := c.beginShareNotificationsLocked()
	defer func() {
		c.flushShareNotificationsLocked(ctx, notify, notifyOwner)
		c.egraphMu.Unlock()
	}()
	// Digest derivation above is outside egraphMu, so release can collect
	// the result in that gap. Numeric result IDs are engine-lifetime unique,
	// so registration under the ID means it is still this exact result.
	if _, found := c.resultsByID[shared.id]; !found {
		return fmt.Errorf("teach call equivalence: result %d was already collected", shared.id)
	}
	return c.teachResultIdentityLocked(ctx, shared, frame, requestDigest, requestSelf, requestInputs, requestInputRefs)
}

func (c *Cache) TeachContentDigest(ctx context.Context, res AnyResult, contentDigest digest.Digest, additionalLabels ...string) error {
	if res == nil {
		return fmt.Errorf("teach content digest: nil result")
	}
	if contentDigest == "" {
		return fmt.Errorf("teach content digest: empty digest")
	}
	shared := res.cacheSharedResult()
	if shared == nil || shared.id == 0 {
		return fmt.Errorf("teach content digest: result %T is not an attached result in this cache", res)
	}

	for {
		if err := ctx.Err(); err != nil {
			return err
		}

		baseFrame := shared.loadResultCall()
		if baseFrame == nil {
			return fmt.Errorf("teach content digest: result %T has no call frame", res)
		}
		oldContentDigest := baseFrame.ContentDigest()
		frame := baseFrame.fork()

		replaced := false
		var replacedDigest digest.Digest
		for i, extra := range frame.ExtraDigests {
			if extra.Label != call.ExtraDigestLabelContent {
				continue
			}
			if extra.Digest != contentDigest {
				replacedDigest = extra.Digest
			}
			frame.ExtraDigests[i].Digest = contentDigest
			replaced = true
			break
		}
		if !replaced {
			frame.ExtraDigests = append(frame.ExtraDigests, call.ExtraDigest{
				Label:  call.ExtraDigestLabelContent,
				Digest: contentDigest,
			})
		}
		// A replaced content digest still names this result. Keep it on the
		// frame, so it travels with the result to other engines.
		if replacedDigest != "" {
			kept := call.ExtraDigest{Digest: replacedDigest, Label: call.ExtraDigestLabelReplacedContent}
			if !slices.Contains(frame.ExtraDigests, kept) {
				frame.ExtraDigests = append(frame.ExtraDigests, kept)
			}
		}

		for _, label := range additionalLabels {
			extra := call.ExtraDigest{Digest: contentDigest, Label: label}
			if !slices.Contains(frame.ExtraDigests, extra) {
				frame.ExtraDigests = append(frame.ExtraDigests, extra)
			}
		}

		requestDigest, err := frame.deriveRecipeDigest(c)
		if err != nil {
			return fmt.Errorf("teach content digest: derive request digest: %w", err)
		}
		requestSelf, requestInputRefs, err := frame.selfDigestAndInputRefs(c)
		if err != nil {
			return fmt.Errorf("teach content digest: derive request term digests: %w", err)
		}
		requestInputs := make([]digest.Digest, 0, len(requestInputRefs))
		for _, ref := range requestInputRefs {
			dig, err := ref.inputDigest(c)
			if err != nil {
				return fmt.Errorf("teach content digest: derive request term input digest: %w", err)
			}
			requestInputs = append(requestInputs, dig)
		}

		c.egraphMu.Lock()
		// A fresh collector for every acquisition of E: the changed-frame
		// retry below unlocks and starts over, and a collector is never
		// carried across an unlock.
		notify, notifyOwner := c.beginShareNotificationsLocked()
		// Numeric result IDs are engine-lifetime unique, so a registered ID
		// still names the caller's result across retries.
		if _, found := c.resultsByID[shared.id]; !found {
			c.discardShareNotificationsLocked(notify, notifyOwner)
			c.egraphMu.Unlock()
			return fmt.Errorf("teach content digest: result %d was already collected", shared.id)
		}
		if shared.loadResultCall() == nil {
			c.discardShareNotificationsLocked(notify, notifyOwner)
			c.egraphMu.Unlock()
			return fmt.Errorf("teach content digest: result %T has no call frame", res)
		}
		if shared.loadResultCall() != baseFrame {
			// Nothing was mutated in this interval.
			c.discardShareNotificationsLocked(notify, notifyOwner)
			c.egraphMu.Unlock()
			continue
		}
		c.traceTeachContentDigest(ctx, shared, oldContentDigest.String(), contentDigest.String(), requestDigest.String(), requestSelf.String(), requestInputs, frame)
		if err := c.teachResultIdentityLocked(ctx, shared, frame, requestDigest, requestSelf, requestInputs, requestInputRefs); err != nil {
			// Partial identity mutation may have happened before the error;
			// flush what survives rather than dropping it.
			c.flushShareNotificationsLocked(ctx, notify, notifyOwner)
			c.egraphMu.Unlock()
			return err
		}
		shared.storeResultCall(frame)
		c.traceResultCallFrameUpdated(ctx, shared, "teach_content_digest", baseFrame, frame)
		c.flushShareNotificationsLocked(ctx, notify, notifyOwner)
		c.egraphMu.Unlock()
		return nil
	}
}

func (c *Cache) resultIDForCall(frame *ResultCall) (sharedResultID, error) {
	if frame == nil {
		return 0, fmt.Errorf("resolve result ID for call: nil call")
	}

	requestDigest, err := frame.deriveRecipeDigest(c)
	if err != nil {
		return 0, fmt.Errorf("resolve result ID for call: derive request digest: %w", err)
	}
	requestSelf, requestInputRefs, err := frame.selfDigestAndInputRefs(c)
	if err != nil {
		return 0, fmt.Errorf("resolve result ID for call: derive request term digests: %w", err)
	}
	requestInputs := make([]digest.Digest, 0, len(requestInputRefs))
	for _, ref := range requestInputRefs {
		dig, err := ref.inputDigest(c)
		if err != nil {
			return 0, fmt.Errorf("resolve result ID for call: derive request term input digest: %w", err)
		}
		requestInputs = append(requestInputs, dig)
	}

	c.egraphMu.Lock()
	defer c.egraphMu.Unlock()
	match := c.lookupMatchForCallLocked(frame, requestDigest, requestSelf, requestInputs, time.Now().Unix())
	if match.candidates == nil || match.candidates.Empty() {
		return 0, fmt.Errorf("resolve result ID for call: no attached result for %s", requestDigest)
	}
	for hitRes := range match.candidates.Items() {
		if hitRes != nil && hitRes.id != 0 {
			return hitRes.id, nil
		}
	}
	return 0, fmt.Errorf("resolve result ID for call: no attached result for %s", requestDigest)
}

func (c *Cache) termForResultByDigestLocked(resID sharedResultID, termDigest string) *egraphTerm {
	for termID := range c.resultTerms[resID] {
		term := c.egraphTerms[termID]
		if term == nil {
			continue
		}
		if term.termDigest == termDigest {
			return term
		}
	}
	return nil
}

func (c *Cache) outputEqClassesForResultLocked(resID sharedResultID) map[eqClassID]struct{} {
	classes := c.resultOutputEqClasses[resID]
	if len(classes) == 0 {
		return nil
	}
	out := make(map[eqClassID]struct{}, len(classes))
	for eqID := range classes {
		root := c.findEqClassLocked(eqID)
		if root == 0 {
			continue
		}
		out[root] = struct{}{}
	}
	return out
}

// addResultOutputEqClassLocked requires egraphMu and an e-graph initialized by
// initEgraphLocked.
func (c *Cache) addResultOutputEqClassLocked(resID sharedResultID, outputEqID eqClassID) {
	if resID == 0 || outputEqID == 0 {
		return
	}
	outputEqID = c.findEqClassLocked(outputEqID)
	if outputEqID == 0 {
		return
	}

	outputEqClasses := c.resultOutputEqClasses[resID]
	if outputEqClasses == nil {
		outputEqClasses = make(map[eqClassID]struct{})
		c.resultOutputEqClasses[resID] = outputEqClasses
	}
	_, hadForward := outputEqClasses[outputEqID]
	outputEqClasses[outputEqID] = struct{}{}

	results := c.outputEqClassResults[outputEqID]
	if results == nil {
		results = make(map[sharedResultID]struct{})
		c.outputEqClassResults[outputEqID] = results
	}
	_, hadReverse := results[resID]
	results[resID] = struct{}{}
	if !hadForward || !hadReverse {
		// New membership in an existing class, with no union of its own.
		// Recorded only once both memberships exist.
		c.recordShareMembershipLocked(outputEqID)
	}
}

// removeResultOutputEqClassesLocked requires egraphMu and an e-graph initialized
// by initEgraphLocked.
func (c *Cache) removeResultOutputEqClassesLocked(resID sharedResultID) {
	if resID == 0 {
		return
	}
	for outputEqID := range c.resultOutputEqClasses[resID] {
		outputEqID = c.findEqClassLocked(outputEqID)
		if outputEqID == 0 {
			continue
		}
		results := c.outputEqClassResults[outputEqID]
		delete(results, resID)
		if len(results) == 0 {
			delete(c.outputEqClassResults, outputEqID)
		}
	}
	delete(c.resultOutputEqClasses, resID)
}

func (c *Cache) termIDsForResultLocked(resID sharedResultID) map[egraphTermID]struct{} {
	termIDs := c.resultTerms[resID]
	if len(termIDs) == 0 {
		return nil
	}
	out := make(map[egraphTermID]struct{}, len(termIDs))
	for termID := range termIDs {
		if c.egraphTerms[termID] == nil {
			continue
		}
		out[termID] = struct{}{}
	}
	if len(out) == 0 {
		return nil
	}
	return out
}

func (c *Cache) mergeOutputsForTermDigestLocked(ctx context.Context, termDigest string, outputEqID eqClassID) eqClassID {
	set := c.egraphTermsByTermDigest[termDigest]
	if set == nil || set.Empty() {
		return c.findEqClassLocked(outputEqID)
	}

	root := c.findEqClassLocked(outputEqID)
	if root == 0 {
		return 0
	}

	mergeIDs := []eqClassID{root}
	allSameRoot := true
	for termID := range set.Items() {
		term := c.egraphTerms[termID]
		if term == nil {
			continue
		}
		termRoot := c.findEqClassLocked(term.outputEqID)
		if termRoot == 0 {
			continue
		}
		if termRoot != root {
			allSameRoot = false
		}
		mergeIDs = append(mergeIDs, termRoot)
	}
	if allSameRoot {
		for termID := range set.Items() {
			term := c.egraphTerms[termID]
			if term == nil {
				continue
			}
			term.outputEqID = root
		}
		return root
	}
	root = c.mergeEqClassesLocked(ctx, mergeIDs...)
	for termID := range set.Items() {
		term := c.egraphTerms[termID]
		if term == nil {
			continue
		}
		term.outputEqID = root
	}
	return root
}

func (c *Cache) associateResultWithTermLocked(
	ctx context.Context,
	res *sharedResult,
	termID egraphTermID,
	inputProvenance []egraphInputProvenanceKind,
) {
	if res == nil || res.id == 0 || termID == 0 {
		return
	}
	term := c.egraphTerms[termID]
	if term == nil {
		return
	}
	outputEqID := c.findEqClassLocked(term.outputEqID)
	if outputEqID == 0 {
		return
	}
	if existing, ok := c.termInputProvenance[termID]; ok {
		if !sameInputProvenance(existing, inputProvenance) {
			c.termInputProvenance[termID] = slices.Clone(inputProvenance)
			c.traceResultTermAssocUpdated(ctx, res.id, termID, inputProvenance)
		}
	} else {
		c.termInputProvenance[termID] = slices.Clone(inputProvenance)
	}

	c.addResultOutputEqClassLocked(res.id, outputEqID)

	termResults := c.termResults[termID]
	if termResults == nil {
		termResults = make(map[sharedResultID]egraphResultTermAssoc)
		c.termResults[termID] = termResults
	}
	resultTerms := c.resultTerms[res.id]
	if resultTerms == nil {
		resultTerms = make(map[egraphTermID]struct{})
		c.resultTerms[res.id] = resultTerms
	}
	assoc, ok := termResults[res.id]
	if ok {
		if !sameInputProvenance(assoc.inputProvenance, inputProvenance) {
			assoc.inputProvenance = slices.Clone(inputProvenance)
			termResults[res.id] = assoc
			c.traceResultTermAssocUpdated(ctx, res.id, termID, inputProvenance)
		}
		return
	}
	termResults[res.id] = egraphResultTermAssoc{
		inputProvenance: slices.Clone(inputProvenance),
	}
	resultTerms[termID] = struct{}{}
	c.traceResultTermAssocAdded(ctx, res.id, termID, inputProvenance)
}

func (c *Cache) teachResultIdentityLocked(
	ctx context.Context,
	res *sharedResult,
	requestFrame *ResultCall,
	requestDigest digest.Digest,
	requestSelf digest.Digest,
	requestInputs []digest.Digest,
	requestInputRefs []ResultCallStructuralInputRef,
) error {
	if res == nil || res.id == 0 || requestFrame == nil {
		return nil
	}
	provenance, err := c.inputProvenanceForRefs(requestInputRefs)
	if err != nil {
		return err
	}
	indexDigest, err := requestFrame.deriveRecipeDigest(c)
	if err != nil {
		return err
	}
	c.applyPreparedResultIdentityLocked(ctx, res, requestFrame, requestDigest, requestSelf, requestInputs, provenance, indexDigest)
	return nil
}

// applyPreparedResultIdentityLocked has no fallible work after its first mutation.
func (c *Cache) applyPreparedResultIdentityLocked(ctx context.Context, res *sharedResult, requestFrame *ResultCall, requestDigest, requestSelf digest.Digest, requestInputs []digest.Digest, inputProvenance []egraphInputProvenanceKind, indexDigest digest.Digest) {
	if res == nil || res.id == 0 || requestFrame == nil {
		return
	}
	c.initEgraphLocked()

	rootSet := c.outputEqClassesForResultLocked(res.id)
	if rootSet == nil {
		rootSet = make(map[eqClassID]struct{})
	}
	if requestDigest != "" {
		if eqID := c.ensureEqClassForDigestLocked(ctx, requestDigest.String()); eqID != 0 {
			rootSet[c.findEqClassLocked(eqID)] = struct{}{}
		}
	}
	for _, extra := range requestFrame.ExtraDigests {
		if extra.Digest == "" {
			continue
		}
		if eqID := c.ensureEqClassForDigestLocked(ctx, extra.Digest.String()); eqID != 0 {
			rootSet[c.findEqClassLocked(eqID)] = struct{}{}
		}
	}
	if len(rootSet) == 0 {
		return
	}

	mergeIDs := make([]eqClassID, 0, len(rootSet))
	for root := range rootSet {
		if root == 0 {
			continue
		}
		mergeIDs = append(mergeIDs, root)
	}
	if len(mergeIDs) == 0 {
		return
	}
	c.traceTeachResultIdentityRootSet(ctx, res, requestDigest.String(), requestSelf.String(), requestInputs, requestFrame, mergeIDs)
	outputEqID := c.mergeEqClassesLocked(ctx, mergeIDs...)
	if outputEqID == 0 {
		return
	}

	inputEqIDs := c.ensureTermInputEqIDsLocked(ctx, requestInputs)
	termDigest := calcEgraphTermDigest(requestSelf, inputEqIDs)
	existingTerm := c.firstLiveTermInSetLocked(c.egraphTermsByTermDigest[termDigest])

	switch {
	case c.termForResultByDigestLocked(res.id, termDigest) != nil:
		c.mergeOutputsForTermDigestLocked(ctx, termDigest, outputEqID)
	case existingTerm != nil:
		c.associateResultWithTermLocked(ctx, res, existingTerm.id, inputProvenance)
		c.mergeOutputsForTermDigestLocked(ctx, termDigest, outputEqID)
	default:
		mergedOutputEqID := c.mergeOutputsForTermDigestLocked(ctx, termDigest, outputEqID)

		termID := c.nextEgraphTermID
		c.nextEgraphTermID++

		newTerm := newEgraphTerm(termID, requestSelf, inputEqIDs, mergedOutputEqID)
		c.egraphTerms[termID] = newTerm
		c.traceTermCreated(ctx, "runtime", "", newTerm)

		digestTerms := c.egraphTermsByTermDigest[newTerm.termDigest]
		if digestTerms == nil {
			digestTerms = newEgraphTermIDSet()
			c.egraphTermsByTermDigest[newTerm.termDigest] = digestTerms
		}
		digestTerms.Insert(termID)

		for _, inEqID := range newTerm.inputEqIDs {
			if inEqID == 0 {
				continue
			}
			classTerms := c.inputEqClassToTerms[inEqID]
			if classTerms == nil {
				classTerms = make(map[egraphTermID]struct{})
				c.inputEqClassToTerms[inEqID] = classTerms
			}
			classTerms[termID] = struct{}{}
		}
		outputTerms := c.outputEqClassToTerms[mergedOutputEqID]
		if outputTerms == nil {
			outputTerms = make(map[egraphTermID]struct{})
			c.outputEqClassToTerms[mergedOutputEqID] = outputTerms
		}
		outputTerms[termID] = struct{}{}

		c.associateResultWithTermLocked(ctx, res, termID, inputProvenance)
	}

	c.addFramePostingsLocked(res.id, indexDigest, requestFrame.ExtraDigests)
	for termID := range c.resultTerms[res.id] {
		term := c.egraphTerms[termID]
		if term == nil {
			continue
		}
		outputEqID := c.findEqClassLocked(term.outputEqID)
		if outputEqID == 0 {
			continue
		}
		extras := c.eqClassExtraDigests[outputEqID]
		if extras == nil {
			extras = make(map[call.ExtraDigest]struct{})
			c.eqClassExtraDigests[outputEqID] = extras
		}
		for _, extra := range requestFrame.ExtraDigests {
			if extra.Digest == "" {
				continue
			}
			extras[extra] = struct{}{}
		}
	}
}

// addFramePostingsLocked posts a frame's recipe digest and extra digests for
// the result. Requires egraphMu.
func (c *Cache) addFramePostingsLocked(resID sharedResultID, recipe digest.Digest, extras []call.ExtraDigest) {
	c.addResultDigestPostingLocked(resID, recipe.String(), resultDigestPostingExact)
	for _, extra := range extras {
		c.addResultDigestPostingLocked(resID, extra.Digest.String(), resultDigestPostingExact)
	}
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (c *Cache) indexWaitResultInEgraphLocked(
	ctx context.Context,
	requestFrame *ResultCall,
	responseFrame *ResultCall,
	requestDigest digest.Digest,
	responseDigest digest.Digest,
	requestSelf digest.Digest,
	requestInputs []digest.Digest,
	requestInputRefs []ResultCallStructuralInputRef,
	resultTermSelf digest.Digest,
	resultTermInputs []digest.Digest,
	resultTermInputRefs []ResultCallStructuralInputRef,
	hasResultTerm bool,
	res *sharedResult,
) error {
	c.initEgraphLocked()

	// A result that carries an ID but is no longer registered was collected
	// after its last owner released it: its OnRelease already ran, so its
	// payload may reference released resources. Refuse to resurrect it rather
	// than re-publish a dead payload into the cache.
	if res.id != 0 {
		if _, found := c.resultsByID[res.id]; !found {
			return fmt.Errorf("index result %d: result was already collected", res.id)
		}
	}

	digestSet := make(map[string]struct{}, 6)
	addDigest := func(dig string) {
		if dig == "" {
			return
		}
		digestSet[dig] = struct{}{}
	}
	if requestFrame != nil {
		addDigest(requestDigest.String())
		for _, extra := range requestFrame.ExtraDigests {
			addDigest(extra.Digest.String())
		}
	}
	if responseFrame != nil {
		addDigest(responseDigest.String())
		for _, extra := range responseFrame.ExtraDigests {
			addDigest(extra.Digest.String())
		}
	}
	if len(digestSet) == 0 {
		return nil
	}

	// each digest associated with the request and result are all eq classes that will now
	// be merged. Gather them and their current eq classes.
	rootSet := make(map[eqClassID]struct{}, len(digestSet))
	for dig := range digestSet {
		if id := c.ensureEqClassForDigestLocked(ctx, dig); id != 0 {
			rootSet[id] = struct{}{}
		}
	}
	if len(rootSet) == 0 {
		return nil
	}

	// merge all the eq classes for the digests into the same eq class
	var outputEqID eqClassID
	if len(rootSet) == 1 {
		for root := range rootSet {
			outputEqID = root
		}
	} else {
		mergeIDs := make([]eqClassID, 0, len(rootSet))
		for root := range rootSet {
			mergeIDs = append(mergeIDs, root)
		}
		outputEqID = c.mergeEqClassesLocked(ctx, mergeIDs...)
	}
	if outputEqID == 0 {
		return nil
	}

	// ensure the result has its int ID initialized, then index it by that int it
	// and by all of its digests in our various maps
	if res.id == 0 {
		res.id = c.nextSharedResultID
		c.nextSharedResultID++
	}
	c.putResultLocked(res)
	if res.loadResultCall() == nil && requestFrame != nil {
		res.storeResultCall(requestFrame.clone())
		c.traceResultCallFrameUpdated(ctx, res, "index_wait_result_request_frame", nil, res.loadResultCall())
	}
	c.traceResultCreated(ctx, res)

	//
	// associate the result with the relevant terms and apply any necessary eq class unions + repairs
	//

	termsToIndex := []struct {
		selfDigest   digest.Digest
		inputDigests []digest.Digest
		inputRefs    []ResultCallStructuralInputRef
	}{
		{
			selfDigest:   requestSelf,
			inputDigests: requestInputs,
			inputRefs:    requestInputRefs,
		},
	}
	// Only index both input+return terms if they are actually different
	shouldIndexResultTerm := hasResultTerm
	if shouldIndexResultTerm && requestSelf == resultTermSelf && slices.Equal(requestInputs, resultTermInputs) {
		shouldIndexResultTerm = false
	}
	if shouldIndexResultTerm {
		termsToIndex = append(termsToIndex, struct {
			selfDigest   digest.Digest
			inputDigests []digest.Digest
			inputRefs    []ResultCallStructuralInputRef
		}{
			selfDigest:   resultTermSelf,
			inputDigests: resultTermInputs,
			inputRefs:    resultTermInputRefs,
		})
	}

	for _, term := range termsToIndex {
		inputProvenance, err := c.inputProvenanceForRefs(term.inputRefs)
		if err != nil {
			return fmt.Errorf("derive input provenance for term %s: %w", term.selfDigest, err)
		}
		// get all the eq classes for the inputs
		inputEqIDs := c.ensureTermInputEqIDsLocked(ctx, term.inputDigests)
		// calculate the term digest based on the resolved input eq classes
		termDigest := calcEgraphTermDigest(term.selfDigest, inputEqIDs)

		if existingTerm := c.termForResultByDigestLocked(res.id, termDigest); existingTerm != nil {
			// we already setup this res with this term, just ensure that the output eq class
			// (which is the merged eq class containing all input req digests + return val digests)
			// is associated as the output eq class for this term; doing a merge+replair if needed.
			c.mergeOutputsForTermDigestLocked(ctx, termDigest, outputEqID)
			continue
		}
		if existingTerm := c.firstLiveTermInSetLocked(c.egraphTermsByTermDigest[termDigest]); existingTerm != nil {
			// we ended up with a duplicate term that has the same digest; just associate this
			// result with that term and merge the output eq class as needed, no need to create
			// a new term
			c.associateResultWithTermLocked(ctx, res, existingTerm.id, inputProvenance)
			c.mergeOutputsForTermDigestLocked(ctx, termDigest, outputEqID)
			continue
		}

		// no existing term with this digest, create a new one and associate it with this result; also merge the output eq class as needed

		mergedOutputEqID := c.mergeOutputsForTermDigestLocked(ctx, termDigest, outputEqID)

		termID := c.nextEgraphTermID
		c.nextEgraphTermID++

		newTerm := newEgraphTerm(
			termID,
			term.selfDigest,
			inputEqIDs,
			mergedOutputEqID,
		)
		c.egraphTerms[termID] = newTerm
		c.traceTermCreated(ctx, "runtime", "", newTerm)

		digestTerms := c.egraphTermsByTermDigest[newTerm.termDigest]
		if digestTerms == nil {
			digestTerms = newEgraphTermIDSet()
			c.egraphTermsByTermDigest[newTerm.termDigest] = digestTerms
		}
		digestTerms.Insert(termID)

		for _, inEqID := range newTerm.inputEqIDs {
			if inEqID == 0 {
				continue
			}
			classTerms := c.inputEqClassToTerms[inEqID]
			if classTerms == nil {
				classTerms = make(map[egraphTermID]struct{})
				c.inputEqClassToTerms[inEqID] = classTerms
			}
			classTerms[termID] = struct{}{}
		}
		outputTerms := c.outputEqClassToTerms[mergedOutputEqID]
		if outputTerms == nil {
			outputTerms = make(map[egraphTermID]struct{})
			c.outputEqClassToTerms[mergedOutputEqID] = outputTerms
		}
		outputTerms[termID] = struct{}{}

		c.associateResultWithTermLocked(ctx, res, termID, inputProvenance)
	}

	if err := c.indexResultDigestsLocked(res, requestFrame, responseFrame); err != nil {
		return err
	}
	for termID := range c.resultTerms[res.id] {
		term := c.egraphTerms[termID]
		if term == nil {
			continue
		}
		outputEqID := c.findEqClassLocked(term.outputEqID)
		if outputEqID == 0 {
			continue
		}
		extras := c.eqClassExtraDigests[outputEqID]
		if extras == nil {
			extras = make(map[call.ExtraDigest]struct{})
			c.eqClassExtraDigests[outputEqID] = extras
		}
		if requestFrame != nil {
			for _, extra := range requestFrame.ExtraDigests {
				if extra.Digest == "" {
					continue
				}
				extras[extra] = struct{}{}
			}
		}
		if responseFrame != nil {
			for _, extra := range responseFrame.ExtraDigests {
				if extra.Digest == "" {
					continue
				}
				extras[extra] = struct{}{}
			}
		}
	}

	return nil
}

func (c *Cache) removeResultFromEgraphLocked(ctx context.Context, res *sharedResult) {
	if res == nil {
		return
	}
	c.unindexRecipesLocked(res)
	if len(c.egraphTerms) == 0 && len(c.resultsByID) == 1 && c.resultsByID[res.id] == res {
		// The last entry, with no term left: the reset clears everything it
		// indexed.
		c.deleteResultLocked(res)
		c.maybeResetEgraphLocked()
		return
	}

	affectedOutputEqClasses := c.outputEqClassesForResultLocked(res.id)
	for termID := range c.resultTerms[res.id] {
		if termResults := c.termResults[termID]; termResults != nil {
			delete(termResults, res.id)
			if len(termResults) == 0 {
				delete(c.termResults, termID)
			}
		}
		c.traceResultTermAssocRemoved(ctx, res.id, termID)
	}
	delete(c.resultTerms, res.id)
	c.removeResultDigestsLocked(res.id, affectedOutputEqClasses)
	c.removeResultOutputEqClassesLocked(res.id)
	oldFrame := res.loadResultCall()
	depCount := len(res.deps)
	res.storeResultCall(nil)
	c.deleteResultLocked(res)
	c.traceResultRemoved(ctx, res, oldFrame, depCount)

	nowUnix := time.Now().Unix()
	for outputEqID := range affectedOutputEqClasses {
		if c.hasUnexpiredResultForOutputEqClassLocked(outputEqID, nowUnix) {
			// still some results in this eq class, nothing to clean up yet
			continue
		}

		// no more results in this eq class, get the list of terms with this output eq class and clean them up
		// since their results were pruned
		termIDs := make([]egraphTermID, 0, len(c.outputEqClassToTerms[outputEqID]))
		for termID := range c.outputEqClassToTerms[outputEqID] {
			termIDs = append(termIDs, termID)
		}
		for _, termID := range termIDs {
			term := c.egraphTerms[termID]
			if term == nil {
				continue
			}
			if set := c.egraphTermsByTermDigest[term.termDigest]; set != nil {
				set.Remove(termID)
				if set.Empty() {
					delete(c.egraphTermsByTermDigest, term.termDigest)
				}
			}
			for _, in := range term.inputEqIDs {
				if set := c.inputEqClassToTerms[in]; set != nil {
					delete(set, termID)
					if len(set) == 0 {
						delete(c.inputEqClassToTerms, in)
					}
				}
			}
			if set := c.outputEqClassToTerms[outputEqID]; set != nil {
				delete(set, termID)
			}
			delete(c.egraphTerms, termID)
			delete(c.termResults, termID)
			delete(c.termInputProvenance, termID)
			c.traceTermRemoved(ctx, termID)
		}
		delete(c.outputEqClassToTerms, outputEqID)
	}
	c.maybeResetEgraphLocked()
}

func (c *Cache) maybeResetEgraphLocked() {
	// An entry can hold classes without terms, such as one known only through
	// holdings, and an entry can outlive its class's last term, such as an
	// expired entry a session still owns: nothing is reset while any entry
	// remains.
	if len(c.egraphTerms) != 0 || len(c.resultsByID) != 0 {
		return
	}

	c.egraphDigestToClass = nil
	c.egraphParents = nil
	c.egraphRanks = nil
	c.eqClassToDigests = nil
	c.eqClassExtraDigests = nil
	c.inputEqClassToTerms = nil
	c.outputEqClassToTerms = nil
	c.resultOutputEqClasses = nil
	c.outputEqClassResults = nil
	c.termResults = nil
	c.resultTerms = nil
	c.egraphTerms = nil
	c.termInputProvenance = nil
	c.egraphTermsByTermDigest = nil
	c.egraphResultsByDigest = nil
	c.resultIndexedDigests = nil
	c.broadlyIndexedResults = nil
	c.resultsByID = nil
	c.resultPayloadBytes = 0
	c.holderEntries = nil
	c.entriesByRecipe = nil
	c.remoteCaches = nil
	c.nextEgraphClassID = 0
	c.nextEgraphTermID = 0
	// nextSharedResultID deliberately survives the reset: numeric result IDs
	// must be engine-lifetime unique because they outlive this index (session
	// records, dependency edges, persisted rows, results held by in-flight
	// callers). Recycling a number could alias two different results. Class
	// and term IDs never leave the index maps cleared above, so their
	// counters can restart. Import seeds nextSharedResultID past the highest
	// persisted ID at startup for the same reason.
}

func (c *Cache) compactEqClassesLocked(force bool) (changed bool, oldSlots int, newSlots int) {
	return c.compactEqClassesModeLocked(force, false)
}

// compactEqClassesModeLocked is compactEqClassesLocked; with freeAll, it also
// frees every slot when no class is live, which compactEqClassesLocked leaves.
//
//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (c *Cache) compactEqClassesModeLocked(force, freeAll bool) (changed bool, oldSlots int, newSlots int) {
	if len(c.egraphParents) <= 1 {
		return false, 0, 0
	}

	// Class IDs already index egraphParents. A bitmap tracks live roots in
	// ascending order without hashing each reference or sorting the roots.
	liveRoots := make([]uint64, (len(c.egraphParents)+63)/64)
	liveCount := 0
	markLive := func(root eqClassID) {
		word, bit := root/64, uint64(1)<<(root%64)
		if liveRoots[word]&bit == 0 {
			liveRoots[word] |= bit
			liveCount++
		}
	}
	for _, term := range c.egraphTerms {
		if term == nil {
			continue
		}
		for _, inputEqID := range term.inputEqIDs {
			root := c.findEqClassLocked(inputEqID)
			if root != 0 {
				markLive(root)
			}
		}
		root := c.findEqClassLocked(term.outputEqID)
		if root != 0 {
			markLive(root)
		}
	}
	for _, outputEqIDs := range c.resultOutputEqClasses {
		for outputEqID := range outputEqIDs {
			root := c.findEqClassLocked(outputEqID)
			if root != 0 {
				markLive(root)
			}
		}
	}

	oldSlots = len(c.egraphParents) - 1
	newSlots = liveCount
	if (newSlots == 0 && !freeAll) || oldSlots == newSlots || (!force && oldSlots < newSlots*2) {
		return false, oldSlots, newSlots
	}

	oldRoots := make([]eqClassID, 0, liveCount)
	// A live root's rank is its new ID. Prefix counts cover preceding words;
	// the population count below includes the root itself, reserving ID zero.
	prefix := make([]eqClassID, len(liveRoots))
	for word, live := range liveRoots {
		prefix[word] = eqClassID(len(oldRoots))
		for live != 0 {
			bit := bits.TrailingZeros64(live)
			oldRoots = append(oldRoots, eqClassID(word*64+bit))
			live &= live - 1
		}
	}
	remap := func(root eqClassID) eqClassID {
		word, bit := root/64, uint(root%64)
		live := liveRoots[word]
		if live&(uint64(1)<<bit) == 0 {
			return 0
		}
		mask := ^uint64(0) >> (63 - bit)
		return prefix[word] + eqClassID(bits.OnesCount64(live&mask))
	}
	newParents := make([]eqClassID, len(oldRoots)+1)
	newRanks := make([]uint8, len(oldRoots)+1)
	for i := range oldRoots {
		newRoot := eqClassID(i + 1)
		newParents[newRoot] = newRoot
	}

	newEqClassToDigests := make(map[eqClassID]map[string]struct{}, len(oldRoots))
	newEqClassExtraDigests := make(map[eqClassID]map[call.ExtraDigest]struct{}, len(oldRoots))
	liveDigests := 0
	for _, oldRoot := range oldRoots {
		liveDigests += len(c.eqClassToDigests[oldRoot])
	}
	newEgraphDigestToClass := make(map[string]eqClassID, liveDigests)
	for _, oldRoot := range oldRoots {
		newRoot := remap(oldRoot)
		if oldDigests := c.eqClassToDigests[oldRoot]; len(oldDigests) > 0 {
			newDigests := make(map[string]struct{}, len(oldDigests))
			for dig := range oldDigests {
				newDigests[dig] = struct{}{}
				newEgraphDigestToClass[dig] = newRoot
			}
			newEqClassToDigests[newRoot] = newDigests
		}
		if oldExtras := c.eqClassExtraDigests[oldRoot]; len(oldExtras) > 0 {
			newExtras := make(map[call.ExtraDigest]struct{}, len(oldExtras))
			for extra := range oldExtras {
				newExtras[extra] = struct{}{}
			}
			newEqClassExtraDigests[newRoot] = newExtras
		}
	}

	newInputEqClassToTerms := make(map[eqClassID]map[egraphTermID]struct{})
	newOutputEqClassToTerms := make(map[eqClassID]map[egraphTermID]struct{})
	newEgraphTermsByTermDigest := make(map[string]*set.TreeSet[egraphTermID], len(c.egraphTermsByTermDigest))
	for termID, term := range c.egraphTerms {
		if term == nil {
			continue
		}
		newInputEqIDs := make([]eqClassID, 0, len(term.inputEqIDs))
		for _, inputEqID := range term.inputEqIDs {
			root := c.findEqClassLocked(inputEqID)
			newRoot := remap(root)
			if newRoot == 0 {
				continue
			}
			newInputEqIDs = append(newInputEqIDs, newRoot)
			set := newInputEqClassToTerms[newRoot]
			if set == nil {
				set = make(map[egraphTermID]struct{})
				newInputEqClassToTerms[newRoot] = set
			}
			set[termID] = struct{}{}
		}
		term.inputEqIDs = newInputEqIDs

		outputRoot := c.findEqClassLocked(term.outputEqID)
		newOutputRoot := remap(outputRoot)
		if newOutputRoot == 0 {
			continue
		}
		term.outputEqID = newOutputRoot
		outputTerms := newOutputEqClassToTerms[newOutputRoot]
		if outputTerms == nil {
			outputTerms = make(map[egraphTermID]struct{})
			newOutputEqClassToTerms[newOutputRoot] = outputTerms
		}
		outputTerms[termID] = struct{}{}

		term.termDigest = calcEgraphTermDigest(term.selfDigest, term.inputEqIDs)
		digestTerms := newEgraphTermsByTermDigest[term.termDigest]
		if digestTerms == nil {
			digestTerms = newEgraphTermIDSet()
			newEgraphTermsByTermDigest[term.termDigest] = digestTerms
		}
		digestTerms.Insert(termID)
	}

	newResultOutputEqClasses := make(map[sharedResultID]map[eqClassID]struct{}, len(c.resultOutputEqClasses))
	newOutputEqClassResults := make(map[eqClassID]map[sharedResultID]struct{}, len(c.outputEqClassResults))
	for resID, outputEqIDs := range c.resultOutputEqClasses {
		newOutputEqIDs := make(map[eqClassID]struct{}, len(outputEqIDs))
		for outputEqID := range outputEqIDs {
			root := c.findEqClassLocked(outputEqID)
			newRoot := remap(root)
			if newRoot != 0 {
				newOutputEqIDs[newRoot] = struct{}{}
			}
		}
		if len(newOutputEqIDs) > 0 {
			newResultOutputEqClasses[resID] = newOutputEqIDs
			for newOutputEqID := range newOutputEqIDs {
				results := newOutputEqClassResults[newOutputEqID]
				if results == nil {
					results = make(map[sharedResultID]struct{})
					newOutputEqClassResults[newOutputEqID] = results
				}
				results[resID] = struct{}{}
			}
		}
	}

	c.egraphParents = newParents
	c.egraphRanks = newRanks
	c.eqClassToDigests = newEqClassToDigests
	c.eqClassExtraDigests = newEqClassExtraDigests
	c.egraphDigestToClass = newEgraphDigestToClass
	c.inputEqClassToTerms = newInputEqClassToTerms
	c.outputEqClassToTerms = newOutputEqClassToTerms
	c.resultOutputEqClasses = newResultOutputEqClasses
	c.outputEqClassResults = newOutputEqClassResults
	c.egraphTermsByTermDigest = newEgraphTermsByTermDigest
	c.nextEgraphClassID = eqClassID(len(newParents))

	return true, oldSlots, newSlots
}
