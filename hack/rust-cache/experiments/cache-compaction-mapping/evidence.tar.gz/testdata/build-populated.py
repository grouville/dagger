from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for arm in ['baseline','rank']:
 command=[go,'test','-c','-p','2','-buildvcs=false','-overlay',str(root/('populated-'+arm+'-overlay.json')),'-o',str(root/('populated-'+arm+'.test')),'./dagql']
 begin=time.monotonic()
 with (root/('populated-'+arm+'-build.log')).open('w') as out:result=subprocess.run(command,cwd='/tmp/dagger-compaction-ownership-only',env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(arm=arm,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
 if result.returncode==0:row['sha256']=hashlib.sha256((root/('populated-'+arm+'.test')).read_bytes()).hexdigest()
 rows.append(row);(root/'populated-builds.json').write_text(json.dumps(rows,indent=2)+'\n');print(arm,result.returncode,flush=True)
 if result.returncode:print((root/('populated-'+arm+'-build.log')).read_text()[-5000:],flush=True)
 assert result.returncode==0
