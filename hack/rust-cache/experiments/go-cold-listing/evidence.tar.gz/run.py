from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time,urllib.request

cold_study=Path(__file__).parent
plan=json.loads((cold_study/'plan.json').read_text())
cli=Path('/tmp/rust-cache-sipsma-review/typed-artifact-metadata/dagger')
binary=Path('/tmp/rust-cache-sipsma-review/dang-shared-function-metadata/dagger-engine')
assert hashlib.sha256(binary.read_bytes()).hexdigest()==plan['engine_sha256']
assert hashlib.sha256(cli.read_bytes()).hexdigest()==plan['cli_sha256']
workspace=Path('/tmp/dagger-go-real-repository-main')
module=Path('/tmp/dagger-go-batch-package-discovery')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=module,text=True).strip()==plan['module_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=module,text=True).strip()
source=workspace/'dagql/types.go';source_original=source.read_bytes()
test=workspace/'dagql/cache_test.go';test_original=test.read_bytes()
saved={n:(workspace/n).read_bytes() if (workspace/n).exists() else None for n in ['dagger.toml','dagger.lock']}
expected_lines=[line for line in Path('/tmp/rust-cache-sipsma-review/glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
expected=[tuple(line.split()[1:3]) for line in expected_lines]
new_test='TestColdListingNativeSourceFreshness';assert new_test.encode() not in test_original
protocol=Path('/tmp/rust-cache-sipsma-review/rust-go-test-collections/measure.py').read_text().split('fixtures = [f for f')[0]
rows=[];activations=[];first_lines={}

def debug_get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16106/debug/'+route,data=data),timeout=10) as f:return json.load(f)

def stop_owned(name,out):
 # Never impose a SIGKILL timeout, including on an engine created for this study.
 tick=time.monotonic();process=subprocess.Popen(['docker','stop','--timeout','-1',name],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 checkpoint=15
 while process.poll() is None:
  if time.monotonic()-tick>=checkpoint:
   print(json.dumps(dict(stage='graceful-stop',engine=name,seconds=round(time.monotonic()-tick,1))),flush=True);checkpoint+=15
  time.sleep(.25)
 text=process.communicate()[0];assert process.returncode==0,text
 state=json.loads(subprocess.check_output(['docker','inspect',name]))[0]['State']
 assert not state['Running'] and state['ExitCode']==0 and not state['OOMKilled'],state
 result=dict(seconds=time.monotonic()-tick,exit_code=state['ExitCode'],forced=False)
 (out/'stop.json').write_text(json.dumps(result,indent=2)+'\n');return result

try:
 for replicate,name in enumerate(plan['new_container_names'],1):
  target=cold_study/('replicate-'+str(replicate));target.mkdir(exist_ok=False)
  assert not subprocess.check_output(['docker','ps','-aq','--filter','name=^/'+name+'$'],text=True).strip(),name
  assert name not in subprocess.check_output(['docker','volume','ls','--format','{{.Name}}'],text=True).splitlines(),name
  cmd=['docker','create','--name',name,'--label','codex.task=go-cold-listing-oct18','--privileged','-p','127.0.0.1:16278:1234','-p','127.0.0.1:16106:6060','--mount','type=volume,source='+name+',target=/var/lib/dagger',plan['image'],*plan['command']]
  container_id=subprocess.check_output(cmd,text=True).strip()
  subprocess.run(['docker','cp',str(binary),name+':/usr/local/bin/dagger-engine'],check=True)
  seed=cold_study/'filesync-snapshot-seeds-mode'
  if seed.exists():subprocess.run(['docker','cp',str(seed),name+':/tmp/filesync-snapshot-seeds-mode'],check=True)
  started=time.monotonic();subprocess.run(['docker','start',name],stdout=subprocess.DEVNULL,check=True)
  deadline=time.monotonic()+90
  while True:
   try:assert not debug_get('wcprof/enabled')['global_enabled'];break
   except OSError:
    assert time.monotonic()<deadline,'new engine readiness timeout';time.sleep(.1)
  startup=time.monotonic()-started
  assert not debug_get('client-lifecycle').get('sessions')
  for route,enabled in plan['flags'].items():assert debug_get(route+'?enabled='+str(enabled).lower(),b'')['enabled']==enabled
  assert debug_get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
  entry=dict(replicate=replicate,engine=name,container_id=container_id,volume=name,volume_did_not_exist=True,startup_seconds=startup,ready=True,flags_during={r:debug_get(r)['enabled'] for r in plan['flags']})
  activations.append(entry);(cold_study/'activations.json').write_text(json.dumps(activations,indent=2)+'\n')
  print(json.dumps(dict(stage='ready',replicate=replicate,startup_seconds=startup,engine=name)),flush=True)
  sys.argv=['cold-protocol','--output',str(target/'commands')]
  namespace={'__file__':__file__}
  code=protocol.replace('dagger-rust-parser-state-pool-oct14',name).replace(':16104',':16106').replace(':16276',':16278')
  exec(code,namespace)
  run_env=dict(namespace['env'],_EXPERIMENTAL_DAGGER_CLI_BIN=str(cli),_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15',DAGGER_DIAG_TYPED_ARTIFACT_METADATA='true')
  output=target/'commands'
  try:
   for kind in ['first-empty-engine','ordinary-source-edit','test-addition','test-removal']:
    source.write_bytes(source_original+f'\n// Cold listing replicate {replicate} {kind} {time.time_ns()}\n'.encode())
    add_test=kind=='test-addition'
    test.write_bytes(test_original+(f'\nfunc {new_test}(t *testing.T) {{}}\n'.encode() if add_test else b''))
    settings='[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n'
    (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n'+settings)
    if kind!='first-empty-engine':namespace['idle'](kind)
    expected_names=sorted(expected+([('dagql',new_test)] if add_test else []))
    before_heap=namespace['heap']();before_cpu=namespace['cpu']();before_pressure=namespace['pressure']();gc_before=namespace['get']('snapshot-collection')
    label=kind;resources=output/(label+'-cli-resources.json')
    command=[str(cli),'check','--module','go','--check','test','--list','--all']
    timed=['/usr/bin/time','-f','{"user_seconds":%U,"system_seconds":%S,"max_rss_kib":%M}','-o',str(resources),'--',*command]
    tick=time.monotonic()
    with (output/(label+'.stdout')).open('w') as out,(output/(label+'.stderr')).open('w') as err:
     process=subprocess.Popen(timed,cwd=workspace,env=run_env,stdout=out,stderr=err,start_new_session=True);cancelled=False
     try:exit_code=process.wait(timeout=240)
     except subprocess.TimeoutExpired:cancelled=True;os.killpg(process.pid,signal.SIGINT);exit_code=process.wait()
    cli_seconds=time.monotonic()-tick;debug_get('upstream-log-queue',b'');seconds=time.monotonic()-tick
    after_heap=namespace['heap']();after_cpu=namespace['cpu']();after_pressure=namespace['pressure']()
    lines=[line for line in (output/(label+'.stdout')).read_text().splitlines() if line.startswith('go ')]
    names=[tuple(line.split()[1:3]) for line in lines]
    first_lines.setdefault(add_test,lines)
    row=dict(replicate=replicate,kind=kind,command=command,seconds=seconds,cli_seconds=cli_seconds,startup_seconds=startup if kind=='first-empty-engine' else None,startup_plus_command_seconds=startup+seconds if kind=='first-empty-engine' else None,start_to_first_result_seconds=time.monotonic()-started if kind=='first-empty-engine' else None,exit_code=exit_code,cancelled=cancelled,rows=len(names),correct_names=names==expected_names,same_full_rows=lines==first_lines[add_test],engine_cpu=after_cpu-before_cpu,heap_delta={k:after_heap[k]-before_heap[k] for k in before_heap},pressure={k:(after_pressure[k]-before_pressure[k])/(seconds*1e6) for k in before_pressure},gc_before=gc_before,gc_after=debug_get('snapshot-collection'),cli_resources=json.loads(resources.read_text().splitlines()[-1]))
    rows.append(row);(cold_study/'samples.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps({k:row[k] for k in ['replicate','kind','seconds','startup_plus_command_seconds','rows','exit_code','correct_names','same_full_rows']}),flush=True)
    assert exit_code==0 and not cancelled and row['correct_names'] and row['same_full_rows'],row
  finally:
   source.write_bytes(source_original);test.write_bytes(test_original)
   for n,data in saved.items():
    if data is None:(workspace/n).unlink(missing_ok=True)
    else:(workspace/n).write_bytes(data)
   flags_after={r:debug_get(r+'?enabled=false',b'')['enabled'] for r in plan['flags']}
   assert not any(flags_after.values())
   (target/'restoration.json').write_text(json.dumps(dict(source_restored=source.read_bytes()==source_original,test_restored=test.read_bytes()==test_original,config_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items()),flags_after=flags_after,wcprof=debug_get('wcprof/enabled')),indent=2)+'\n')
   stop_owned(name,target)
   logs=subprocess.run(['docker','logs',name],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,check=True).stdout
   (target/'engine.log').write_text(logs)
 import statistics
 summary={kind:dict(median_seconds=statistics.median(r['seconds'] for r in rows if r['kind']==kind),median_engine_cpu=statistics.median(r['engine_cpu'] for r in rows if r['kind']==kind),commands=sum(r['kind']==kind for r in rows)) for kind in ['first-empty-engine','ordinary-source-edit','test-addition','test-removal']}
 summary['median_startup_seconds']=statistics.median(a['startup_seconds'] for a in activations)
 summary['median_startup_plus_first_command_seconds']=statistics.median(r['startup_plus_command_seconds'] for r in rows if r['kind']=='first-empty-engine')
 summary['scope']=plan['scenario'];(cold_study/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
finally:
 source.write_bytes(source_original);test.write_bytes(test_original)
 for n,data in saved.items():
  if data is None:(workspace/n).unlink(missing_ok=True)
  else:(workspace/n).write_bytes(data)
 (cold_study/'workspace-restoration.json').write_text(json.dumps(dict(source_restored=source.read_bytes()==source_original,test_restored=test.read_bytes()==test_original,config_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items())),indent=2)+'\n')
