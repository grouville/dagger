from pathlib import Path
import hashlib
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
engine = 'dagger-rust-parser-state-pool-oct14'
debug = 'http://127.0.0.1:16104/debug/'
build = json.loads((p/'build-steps.json').read_text())
assert len(build)==5 and all(r['exit_code']==r['expected_exit_code'] for r in build)
assert hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()==next(r['sha256'] for r in build if r['label']=='engine-build')
routes = list(json.loads(Path('/tmp/rust-cache-sipsma-review/telemetry-native-storage/capture/metadata.json').read_text())['flags_during'])
def get(route, data=None):
    with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=15) as response:
        return json.load(response)
before = {route:get(route)['enabled'] for route in routes}
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
current = subprocess.check_output(['docker','exec',engine,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
assert current=='4b03eb195a40e785efe89113572fafa8192329b8853ae3621f28aca0e57b01d7'
inspect = json.loads(subprocess.check_output(['docker','inspect',engine],text=True))[0]
identity = dict(engine=engine,id=inspect['Id'],image=inspect['Image'],mounts=inspect['Mounts'],before_sha256=current,after_sha256=next(r['sha256'] for r in build if r['label']=='engine-build'),flags_before=before,telemetry_v2_and_dual_readers_preserved=True,forced_termination=False,cache_reset=False)
(p/'activation-plan.json').write_text(json.dumps(identity,indent=2)+'\n')
rows = []
steps = [
    ('retained-before',['python3',str(p/'verify-retained.py'),'before']),
    ('restart',['python3','/tmp/rust-cache-sipsma-review/telemetry-native-storage/source-context/restart_owned_engine_clean.py','--engine',engine,'--debug-port','16104','--output',str(p/'restart'),'--binary',str(p/'dagger-engine'),'--readiness-timeout','360']),
]
for label,command in steps:
    start = time.monotonic()
    with (p/(label+'-driver.log')).open('w') as output:
        result = subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
    row = dict(label=label,command=command,exit_code=result.returncode,seconds=time.monotonic()-start)
    rows.append(row)
    (p/'activation-steps.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==0,(p/(label+'-driver.log')).read_text()[-5000:]
after = subprocess.check_output(['docker','exec',engine,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
assert after==identity['after_sha256']
for route,enabled in before.items():
    assert get(route+'?enabled='+str(enabled).lower(),b'')['enabled']==enabled
assert not get('response-data-projection')['enabled']
assert not get('queued-log-flush-buffer')['enabled']
assert not get('queued-log-flush-buffer')['record']
assert not get('wcprof/enabled')['global_enabled']
command=['python3',str(p/'verify-retained.py'),'after-restart']
start=time.monotonic()
with (p/'retained-after-restart-driver.log').open('w') as output:
    result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
rows.append(dict(label='retained-after-restart',command=command,exit_code=result.returncode,seconds=time.monotonic()-start))
(p/'activation-steps.json').write_text(json.dumps(rows,indent=2)+'\n')
assert result.returncode==0,(p/'retained-after-restart-driver.log').read_text()[-5000:]
identity.update(installed_sha256=after,flags_restored=all(get(route)['enabled']==value for route,value in before.items()),queued_buffer=get('queued-log-flush-buffer'),retained_checks_before=6,retained_checks_after=6,selected=False,pr_opened=False)
(p/'activation.json').write_text(json.dumps(identity,indent=2)+'\n')
print('Activation complete; all six Rust histories remain cached; response projection is off.',flush=True)
