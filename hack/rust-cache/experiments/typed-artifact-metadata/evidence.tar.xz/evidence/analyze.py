from collections import Counter
from pathlib import Path
import json, subprocess, sys, time

p=Path(sys.argv[1])
counts=Counter();calls=Counter();queries=[];long_calls=[]
with (p/'wcprof-complete.ndjson').open() as stream:
    header=json.loads(next(stream));names=header['strings']
    assert header['dropped_events']==0 and not header.get('open_ops')
    for line in stream:
        event=json.loads(line)
        if event['e']!='op':continue
        cls=names[event['c']];counts[cls]+=1
        seconds=(event['d']-event['s'])/1e9
        if event['k']=='call':
            calls[cls]+=1
            if seconds>.1:long_calls.append(dict(id=event['id'],cls=cls,seconds=seconds))
        if cls=='session.serveQuery':queries.append(dict(id=event['id'],parent=event.get('p',0),seconds=seconds))
main=max(queries,key=lambda q:q['seconds'])
command=['/tmp/rust-cache-wcprof-report-current','-view=critpath','-op='+str(main['id']),'-depth=32','-top=45','-limit=160',str(p/'wcprof-complete.ndjson')]
tick=time.monotonic()
with (p/'critical-path.txt').open('w') as out:completed=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,timeout=180)
assert completed.returncode==0
report=dict(result=json.loads((p/'result.json').read_text()),main_query=main,operation_counts=dict(counts.most_common()),call_counts=dict(calls.most_common()),longest_calls=sorted(long_calls,key=lambda e:e['seconds'],reverse=True)[:30],critical_path_command=command,analysis_seconds=time.monotonic()-tick)
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(main_query=main,queries=len(queries),api_requests=counts['dang.apiRequest'],function_evaluations=counts['dang.evaluateFunction'],configuration_stats=counts['core.config.stat'],configuration_reads=counts['core.config.read'],longest_calls=report['longest_calls'][:8]),indent=2))
