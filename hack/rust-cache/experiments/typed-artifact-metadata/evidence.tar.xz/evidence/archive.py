from pathlib import Path
import hashlib, json, tarfile, time

p=Path(__file__).parent
destination=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/typed-artifact-metadata')
destination.mkdir(exist_ok=False)
members=[]
for filename in sorted(p.rglob('*')):
    if not filename.is_file():continue
    relative=filename.relative_to(p)
    if '__pycache__' in relative.parts or filename.name in ['dagger','dagger-engine','dagql.test']:continue
    if filename.name.startswith('chunk-') and filename.name.endswith('.ndjson.gz'):continue
    data=filename.read_bytes()
    members.append(dict(path=str(relative),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
archive=destination/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as output:
    for row in members:output.add(p/row['path'],arcname='evidence/'+row['path'],recursive=False)
with tarfile.open(archive,'r:*') as stored:
    entries=stored.getmembers();assert len(entries)==len(members)
    actual={entry.name:entry for entry in entries}
    for row in members:
        with stored.extractfile(actual['evidence/'+row['path']]) as stream:assert hashlib.sha256(stream.read()).hexdigest()==row['sha256']
manifest=dict(created_unix=time.time(),archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,verified_members=len(members),uncompressed_member_bytes=sum(row['bytes'] for row in members),scope='Experimental typed metadata API and generic immutable data projection. No standalone upstream branch or PR. Every observed measurement, setup failure, unsafe control, source overlay, test result, benchmark, source identity, cache verification and restoration retained. Lossless combined traces with per-chunk metadata; original compressed chunks omitted as duplicates. Binaries, volume and credentials excluded.',inherited_engine_context='../log-flush-buffer/',preceding_diagnostic='../collection-work-amplification/',members=members)
(destination/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
(destination/'README.md').write_text('''# Typed artifact metadata experiment

See [the assessment](../../NATIVE_TYPED_ARTIFACT_METADATA.md). Complete edited listing on real dagger/dagger improves 40.86 → 26.76 seconds median, faster in all four pairs with identical rows and successful cleanup. The frozen control improves 12.26 → 6.74 seconds. The generic query projection component improves 318.76 → 39.05 ms; those component timings exclude network and final JSON encoding.

The archive contains the implementation, diagnostic controls, prototype patch, tests and expected-failure control, both full DagQL race runs, core ownership checks, builds, all thirty listing commands, compatibility checks and their initial harness failure, cache checks before/after restart and feature activation, lossless wcprof captures, source identities and final restoration. This is not a standalone patch on upstream main; the implementation extends the preceding experimental data/scalar projection support.

MANIFEST.json verifies every member and the archive. Lossless combined traces are included directly; recorded-chunks.json preserves per-dump headers, string-prefix lengths, event boundaries and hashes without duplicate trace data. The exact inherited engine source/dependency context is in the preceding [log flush archive](../log-flush-buffer/). Original absolute paths and local telemetry receiver need adapting for replay. Binaries and the retained engine volume are excluded. No new PR is open.
''')
print(json.dumps({k:manifest[k] for k in ['archive_bytes','verified_members','uncompressed_member_bytes','archive_sha256']}),flush=True)
