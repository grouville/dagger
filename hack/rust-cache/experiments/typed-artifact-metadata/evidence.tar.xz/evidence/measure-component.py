from pathlib import Path
import hashlib, json, os, re, statistics, subprocess, time

p=Path(__file__).parent
out=p/'component';out.mkdir(exist_ok=False)
binary=p/'dagql.test'
assert binary.is_file()
env=dict(os.environ,GOMAXPROCS='8',DAGGER_BENCH_RESPONSE_DATA='false')
orders=[['before','after'],['after','before'],['before','after'],['after','before']]
plan=dict(scope='Component comparison only: fresh data arrays with 4398 rows and nested keys through the real DagQL query executor. Same binary, ordinary GC, fresh process per sample, one measured fresh-generation query after setup. Selected direct scalar getters and scalar-list projection are enabled in both arms. No engine replacement or full-command claim.',orders=orders,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),rows=4398,pairs=4,benchtime='1x',normal_gc=True,gomaxprocs=8)
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
samples=[]
for pair,order in enumerate(orders):
    for arm in order:
        label=f'{pair}-{arm}'
        enabled='true' if arm=='after' else 'false'
        command=[str(binary),'-test.run=^$','-test.bench=^BenchmarkResponseDataProjection$/^enabled='+enabled+'$','-test.benchtime=1x','-test.count=1','-test.timeout=180s']
        tick=time.monotonic()
        with (out/(label+'.log')).open('w') as output:result=subprocess.run(command,cwd=p,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=200)
        text=(out/(label+'.log')).read_text()
        matches=re.findall(r'^BenchmarkResponseDataProjection/enabled=(true|false)-\d+\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',text,re.M)
        row=dict(pair=pair,arm=arm,command=command,exit_code=result.returncode,wall_seconds=time.monotonic()-tick)
        assert result.returncode==0 and len(matches)==1,(row,text[-4000:])
        flag,iterations,nanos,allocated,allocations=matches[0]
        assert flag==enabled and int(iterations)==1
        row.update(ns_per_op=float(nanos),bytes_per_op=int(allocated),allocations_per_op=int(allocations))
        samples.append(row);(out/'samples.json').write_text(json.dumps(samples,indent=2)+'\n');print(json.dumps(row),flush=True)
summary={arm:{metric:statistics.median(r[metric] for r in samples if r['arm']==arm) for metric in ['ns_per_op','bytes_per_op','allocations_per_op']} for arm in ['before','after']}
summary['faster_pairs']=sum(next(r['ns_per_op'] for r in samples if r['pair']==i and r['arm']=='after')<next(r['ns_per_op'] for r in samples if r['pair']==i and r['arm']=='before') for i in range(4))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
