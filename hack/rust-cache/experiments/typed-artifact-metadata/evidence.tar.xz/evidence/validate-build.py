from pathlib import Path
import hashlib, json, os, subprocess, time

p=Path(__file__).parent
engine=Path('/tmp/dagger-filesync-snapshot-seeds')
cli=Path('/tmp/dagger-filesync-literal-pathwalk')
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
modfile='-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod'
overlay='-overlay='+str(p/'engine-overlay.json')
steps=[
    ('dagql-race-enabled',[go,'test','-p=2','-race','-count=1','-timeout=240s',modfile,overlay,'./dagql'],engine,dict(env,DAGGER_BENCH_RESPONSE_DATA='true'),0),
    ('unsafe-extended-control',[go,'test','-p=2','-race','-count=1','-timeout=180s',modfile,'-overlay='+str(p/'unsafe-extended-overlay.json'),'-run=^TestResponseDataProjectionDoesNotBypassExtendedResolver$','./dagql'],engine,env,1),
    ('metadata-core-race',[go,'test','-p=2','-race','-count=1','-timeout=180s',modfile,overlay,'-run=^TestArtifactMetadata','./core'],engine,env,0),
    ('engine-build',[go,'build','-p=2','-buildvcs=false',modfile,overlay,'-o',str(p/'dagger-engine'),'./cmd/engine'],engine,env,0),
    ('cli-build',[go,'build','-p=2','-buildvcs=false','-overlay='+str(p/'cli-overlay.json'),'-o',str(p/'dagger'),'./cmd/dagger'],cli,dict(env,_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15'),0),
]
rows=[]
source_hashes={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in json.loads((p/'engine-overlay.json').read_text())['Replace'].values()}
(p/'build-source-hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
for label,command,cwd,run_env,expected in steps:
    tick=time.monotonic()
    with (p/(label+'.log')).open('w') as output:result=subprocess.run(command,cwd=cwd,env=run_env,stdout=output,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,cwd=str(cwd),exit_code=result.returncode,expected_exit_code=expected,seconds=time.monotonic()-tick)
    if result.returncode==0 and label in ['engine-build','cli-build']:
        row['sha256']=hashlib.sha256((p/('dagger-engine' if label=='engine-build' else 'dagger')).read_bytes()).hexdigest()
    rows.append(row);(p/'build-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==expected,(label,(p/(label+'.log')).read_text()[-5000:])
    if expected!=0:
        text=(p/(label+'.log')).read_text()
        assert 'FAIL: TestResponseDataProjectionDoesNotBypassExtendedResolver' in text and 'expected: "overridden"' in text,text[-5000:]
    assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in source_hashes.items()),'source changed during validation'
