from pathlib import Path
import json, os, signal, subprocess, time, urllib.request

p=Path(__file__).parent
workspace=Path('/tmp/dagger-go-real-repository-main')
base=p.parent
cli=p/'dagger'
removed={'DAGGER_SESSION_PORT','DAGGER_SESSION_TOKEN','SSH_AUTH_SOCK','DAGGER_CLOUD_TOKEN','DAGGER_CLOUD_URL','DAGGER_ENGINE','DAGGER_CLOUD_ENGINE','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'}
env={k:v for k,v in os.environ.items() if k not in removed and not k.startswith('OTEL_EXPORTER_')}
env.update(DAGGER_CLOUD_URL='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',DAGGER_CLOUD_TOKEN='local-benchmark-token',XDG_CONFIG_HOME='/tmp/rust-cache-oct13-filter/local-client-config',NO_PROXY='*',_EXPERIMENTAL_DAGGER_RUNNER_HOST='tcp://127.0.0.1:16276',_EXPERIMENTAL_DAGGER_CLI_BIN=str(cli),_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
out=p/'format-checks';out.mkdir(exist_ok=False)
def get(route,data=None):
    with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16104/debug/'+route,data=data),timeout=30) as response:return json.load(response)
routes=['batch-metadata','attribute-array-decode','native-telemetry-storage','response-data-projection']
flags={r:get(r)['enabled'] for r in routes}
saved={n:(workspace/n).read_bytes() if (workspace/n).exists() else None for n in ['dagger.toml','dagger.lock']}
fixtures=[('known',base/'collection-work-amplification/known-collections',4398),('object-fields',p/'object-field-fixture',4)]
rows=[]
try:
    for route in routes:get(route+'?enabled=true',b'')
    for fixture,module,count in fixtures:
        (workspace/'dagger.toml').write_text('[modules.metadata-fields]\nsource = "'+str(module)+'"\n')
        for style,extra in [('table',[]),('link',['--format=link']),('cli',['--format=cli']),('absolute-link',['--format=link','--absolute'])]:
            if fixture=='known' and style!='absolute-link':continue
            outputs={}
            for arm,enabled in [('before',False),('after',True)]:
                label=fixture+'-'+style+'-'+arm
                run_env=dict(env,DAGGER_DIAG_TYPED_ARTIFACT_METADATA=str(enabled).lower())
                command=[str(cli),'check','--module','metadata-fields','--check','test','--list','--all',*extra]
                tick=time.monotonic()
                with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
                    process=subprocess.Popen(command,cwd=workspace,env=run_env,stdout=stdout,stderr=stderr,start_new_session=True)
                    try:code=process.wait(timeout=180)
                    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGINT);code=process.wait()
                output=(out/(label+'.stdout')).read_text();outputs[arm]=output
                row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=code,bytes=len(output.encode()))
                rows.append(row);(out/'samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
                if style=='absolute-link':
                    error=(out/(label+'.stderr')).read_text()
                    assert code!=0 and output=='' and 'has no Git address' in error,(label,'absolute-address error changed')
                    continue
                assert code==0 and output.strip(),(label,'failed or empty output')
                if style=='table':assert sum(line.startswith('metadata-fields ') for line in output.splitlines())==count,(label,'incorrect row count')
                elif style in ['link','absolute-link']:assert len(output.splitlines())==count,(label,'incorrect link count')
            assert outputs['before']==outputs['after'],(fixture,style,'metadata differs')
    (out/'result.json').write_text(json.dumps(dict(all_equal=True,commands=len(rows),prior_successful_commands=6,absolute_address_error_preserved=True,object_field_dimensions=True,unicode_and_escaped_keys=True,formats=['table','link','cli','absolute-link']),indent=2)+'\n')
finally:
    for name,data in saved.items():
        if data is None:(workspace/name).unlink(missing_ok=True)
        else:(workspace/name).write_bytes(data)
    for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
    (out/'restoration.json').write_text(json.dumps(dict(config_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items()),flags_after={r:get(r) for r in routes}),indent=2)+'\n')
