from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
validation = json.loads((p/'validation-pipeline.json').read_text())
assert len(validation) == 4 and all(row['exit_code'] == 0 for row in validation)
assert 'ok  \tgithub.com/dagger/dagger/engine/clientdb' in (p/'clientdb-native-final.log').read_text()
steps = [
    ('retained-before', ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py', 'telemetry-native-storage-before'], None),
    ('engine-build', [go, 'build', '-p', '2', '-buildvcs=false', '-modfile',
        '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod', '-overlay',
        str(p / 'engine-overlay.json'), '-o', str(p / 'dagger-engine'), './cmd/engine'], '/tmp/dagger-filesync-snapshot-seeds'),
]
rows = []
for label, command, cwd in steps:
    start = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start)
    if label == 'engine-build' and result.returncode == 0:
        row['sha256'] = hashlib.sha256((p / 'dagger-engine').read_bytes()).hexdigest()
    rows.append(row)
    (p / 'engine-builds.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]
