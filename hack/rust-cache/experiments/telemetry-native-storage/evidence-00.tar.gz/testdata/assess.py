from pathlib import Path
from datetime import datetime
import json
import statistics

p=Path(__file__).parent
rows=json.loads((p/'paired/samples.json').read_text())
measured=[row for row in rows if row['pair']>0]
before={row['pair']:row for row in measured if row['arm']=='before'}
after={row['pair']:row for row in measured if row['arm']=='after'}
assert len(rows)==18 and len(before)==len(after)==8
assert all(row['exit_code']==0 and row['same_rows'] and not row['cancelled'] for row in rows)
assert all(not row['candidate_modes']['lazy-schema-candidates']['enabled'] for row in rows)
assert all(row['candidate_modes']['native-telemetry-storage']['enabled']==(row['arm']=='after') for row in rows)
assert all(json.loads((p/'paired/metadata.json').read_text())[field] for field in ['telemetry','ordinary_gc','fresh_edit_every_arm','warm_engine'])


def medians(items):
    return dict(seconds=statistics.median(r['seconds'] for r in items),
        allocated_bytes=statistics.median(r['heap_delta']['TotalAlloc'] for r in items),
        engine_cpu_seconds=statistics.median(r['engine_cpu'] for r in items),
        cli_cpu_seconds=statistics.median(r['cli_resources']['user_seconds']+r['cli_resources']['system_seconds'] for r in items))


diagnostics=[]
for row in measured:
    start=row['unix_start'];end=start+row['seconds']
    overlaps=[]
    for event in row['gc_after']['events']:
        a=datetime.fromisoformat(event['start'].replace('Z','+00:00')).timestamp()
        b=datetime.fromisoformat(event['end'].replace('Z','+00:00')).timestamp()
        if b>start and a<end:
            overlaps.append(dict(start=event['start'],end=event['end'],
                seconds=max(0,min(b,end)-max(a,start)),metadata_ns=event.get('metadata_ns')))
    diagnostics.append(dict(label=row['label'],seconds=row['seconds'],
        class_slots_before=row['gc_before']['metadata_estimate']['ClassSlotCount'],
        class_slots_after=row['gc_after']['metadata_estimate']['ClassSlotCount'],
        result_count_before=row['gc_before']['metadata_estimate']['ResultCount'],
        result_count_after=row['gc_after']['metadata_estimate']['ResultCount'],
        go_gc_cycles=row['heap_delta']['NumGC'],
        host_cpu_pressure=row['pressure']['host.cpu.some'],
        host_io_pressure=row['pressure']['host.io.some'],
        database_residency_before=row['residency_before'],database_residency_after=row['residency_after'],
        completed_snapshot_gc_overlaps=overlaps))

summary=dict(medians={arm:medians(list(items.values())) for arm,items in [('json',before),('native',after)]},
    faster_pairs=sum(after[i]['seconds']<before[i]['seconds'] for i in before),
    lower_allocation_pairs=sum(after[i]['heap_delta']['TotalAlloc']<before[i]['heap_delta']['TotalAlloc'] for i in before),
    lower_engine_cpu_pairs=sum(after[i]['engine_cpu']<before[i]['engine_cpu'] for i in before),
    median_paired_seconds_saved=statistics.median(before[i]['seconds']-after[i]['seconds'] for i in before),
    individual_pairs=[dict(pair=i,json_seconds=before[i]['seconds'],native_seconds=after[i]['seconds'],saved_seconds=before[i]['seconds']-after[i]['seconds']) for i in before],
    maintenance=diagnostics)
(p/'cohort-assessment.json').write_text(json.dumps(summary,indent=2)+'\n')
decision=dict(native_writer_selected=False,engine_binary=json.loads((p/'activation.json').read_text())['after_sha256'],
    current_state='The controlled engine keeps its dual-format readers and v2 outer store support; native writing is disabled. Do not restore an old v1-only reader over these telemetry stores without migration.',
    result='Promising complete-command and consistent CPU/allocation reductions, not yet an established selected improvement.',
    rationale='Six of eight pairs improve, with two small regressions. JSON pairs 5 and 7 overlap class-table reductions, later host I/O pressure rises, and cache state changes between arms. Keep every observation. This storage-format migration needs a new independent-order confirmation and migration review before selection or an upstream-ready proposal.',
    no_pr_opened=True,no_new_upstream_proposal=True)
(p/'decision.json').write_text(json.dumps(decision,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='maintenance'},indent=2))
