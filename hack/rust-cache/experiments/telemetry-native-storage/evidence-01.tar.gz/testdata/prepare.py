from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent
root = Path('/tmp/dagger-filesync-snapshot-seeds')
base = p.parent / 'config-preflight-phases/engine-overlay.json'
overlay = json.loads(base.read_text())
provenance = []


def change(relative, transform):
    destination = str(root / relative)
    source = Path(overlay['Replace'].get(destination, destination))
    original = source.read_text()
    updated = transform(original)
    assert updated != original, relative
    for name in ['bytes', 'protojson']:
        if name + '.' not in updated:
            updated = re.sub(r'\n\t"[^"\n]*(?:/' + name + '|' + name + ')"', '', updated)
    stem = relative.replace('/', '__')
    (p / ('before-' + stem)).write_text(original)
    target = p / stem
    target.write_text(updated)
    overlay['Replace'][destination] = str(target)
    provenance.append(dict(destination=destination, source=str(source),
                           before_sha256=hashlib.sha256(original.encode()).hexdigest(),
                           candidate=str(target)))


def span(source):
    split = source.index('// Attributes returns the attributes of the span')
    return source[:split] + source[split:].replace('UnmarshalProtoJSONs(', 'UnmarshalStoredProtos(').replace(
        'protojson.Unmarshal(ros.DB.Resource,', 'UnmarshalStoredProto(ros.DB.Resource,').replace(
        'protojson.Unmarshal(ros.DB.InstrumentationScope,', 'UnmarshalStoredProto(ros.DB.InstrumentationScope,')


change('engine/clientdb/span.go', span)
change('engine/clientdb/span_proto.go', lambda s: s.replace('UnmarshalProtoJSONs(', 'UnmarshalStoredProtos(').replace('func emptyProtoArray(data []byte) bool {', 'func emptyProtoArray(data []byte) bool {\n\tif isNativeProto(data) { return emptyNativeProtoList(data, storedLinks) || emptyNativeProtoList(data, storedEvents) }'))
change('engine/clientdb/log.go', lambda s: s.replace('UnmarshalProtoJSONs(', 'UnmarshalStoredProtos(').replace('protojson.Unmarshal(', 'UnmarshalStoredProto('))
change('engine/clientdb/batch_metadata_legacy_log.go', lambda s: s.replace('UnmarshalProtoJSONs(', 'UnmarshalStoredProtos(').replace('protojson.Unmarshal(', 'UnmarshalStoredProto('))
change('engine/clientdb/metric.go', lambda s: s.replace('protojson.Unmarshal(', 'UnmarshalStoredProto('))
change('engine/clientdb/call_index.go', lambda s: s.replace('bytes.Contains(row.Attributes,', 'storedProtoContains(row.Attributes,').replace(
    'return protoJSONStringAttr(row.Attributes, dagDigestAttrMarker)', 'return storedProtoStringAttr(row.Attributes, dagDigestAttrMarker)'))
change('engine/clientdb/archive_index.go', lambda s: s.replace('UnmarshalProtoJSONs(', 'UnmarshalStoredProtos(').replace(
    'MarshalProtoJSONs(', 'MarshalStoredProtos(').replace('bytes.Contains(row.Attributes,', 'storedProtoContains(row.Attributes,'))
change('engine/clientdb/telemetry_store.go', lambda s: s.replace('UnmarshalProtoJSONs(', 'UnmarshalStoredProtos(').replace('bytes.Contains(row.Attributes,', 'storedProtoContains(row.Attributes,').replace('if len(row.Links) <= len("[]") {', 'if len(row.Links) <= len("[]") || emptyNativeProtoList(row.Links, storedLinks) {'))
change('core/mcp.go', lambda s: s.replace('clientdb.UnmarshalProtoJSONs(', 'clientdb.UnmarshalStoredProtos('))
change('engine/server/session_cloud_forwarder.go', lambda s: s.replace('clientdb.UnmarshalProtoJSONs(', 'clientdb.UnmarshalStoredProtos(').replace('[]byte(`"` + telemetryattrs.TelemetryCloudPublishedAttr + `"`)', '[]byte(telemetryattrs.TelemetryCloudPublishedAttr)'))


def telemetry(source):
    source = source.replace('clientdb.MarshalProtoJSONs(', 'clientdb.MarshalStoredProtos(')
    source = source.replace('protojson.Marshal(telemetry.InstrumentationScopeToPB(', 'clientdb.MarshalStoredProto(telemetry.InstrumentationScopeToPB(')
    source = source.replace('protojson.Marshal(telemetry.ResourcePtrToPB(', 'clientdb.MarshalStoredProto(telemetry.ResourcePtrToPB(')
    return source.replace('protojson.Marshal(pbMetrics)', 'clientdb.MarshalStoredProto(pbMetrics)')


change('engine/server/telemetry.go', telemetry)
change('engine/server/span_row_sharing.go', telemetry)


def spill(source):
    source, count = re.subn(r'(storeFormatVersion\s+byte\s*=\s*)1\b', r'\g<1>2', source)
    assert count == 1
    source = source.replace('\tsize := info.Size()\n', '\tsize := info.Size()\n\tlegacyFormat := false\n')
    source = source.replace('if header[0] != storeFormatVersion {', 'if !supportedStoreVersion(header[0]) {')
    marker = '\t}\n\n\tspill := &spillFile[Row]{'
    assert marker in source
    source = source.replace(marker, '\t\tlegacyFormat = header[0] != storeFormatVersion\n' + marker)
    marker = '\tif _, err := file.Seek(spill.writeOffset, io.SeekStart); err != nil {'
    assert marker in source
    source = source.replace(marker, '\t// Upgrade only after recovery succeeds, before a native row can be appended.\n\tif legacyFormat {\n\t\tif _, err := file.WriteAt([]byte{storeFormatVersion}, 0); err != nil {\n\t\t\treturn nil, fmt.Errorf("upgrade telemetry store header: %w", err)\n\t\t}\n\t}\n'+marker)
    return source


change('engine/clientdb/store_spill.go', spill)
change('engine/clientdb/dump.go', lambda s: s.replace('if header[0] != storeFormatVersion {', 'if !supportedStoreVersion(header[0]) {'))

mode = (p.parent / 'lazy-schema-candidates/mode.go').read_text().replace('package core', 'package clientdb').replace('lazySchemaCandidates', 'nativeTelemetryStorage').replace('LazySchemaCandidates', 'NativeTelemetryStorage')
(p / 'mode.go').write_text(mode)
change('cmd/engine/debug.go', lambda s: s.replace('\tm := http.NewServeMux()', '\tm := http.NewServeMux()\n\tm.HandleFunc("/debug/native-telemetry-storage", clientdb.NativeTelemetryStorageDiagnostic)'))
overlay['Replace'][str(root / 'engine/clientdb/stored_proto.go')] = str(p / 'stored_proto.go')
overlay['Replace'][str(root / 'engine/clientdb/native_telemetry_storage_mode.go')] = str(p / 'mode.go')
(p / 'engine-overlay.json').write_text(json.dumps(overlay, indent=2)+'\n')
(p / 'source-provenance.json').write_text(json.dumps(dict(base_overlay=str(base), changed=provenance), indent=2)+'\n')
print('Prepared', len(provenance), 'controlled sources; external JSON response encoding stays unchanged')
