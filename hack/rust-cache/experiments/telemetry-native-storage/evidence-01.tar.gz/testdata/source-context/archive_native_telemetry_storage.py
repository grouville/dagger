from pathlib import Path
import hashlib
import json
import shutil
import tarfile

base = Path('/tmp/rust-cache-sipsma-review')
repo = Path('/home/dagger/dagger_otra/hack/rust-cache')
report = 'NATIVE_TELEMETRY_STORAGE.md'
studies = {'telemetry-native-storage': 'Native telemetry storage: correctness, components and full Go listing cohort'}
allowed = {'.go', '.py', '.json', '.jsonl', '.log', '.pprof', '.gz', '.txt',
           '.stdout', '.stderr', '.md', '.mod', '.sum', '.dang', '.patch', '.peg',
           '.ndjson', '.sh', '.toml'}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


study=base/'telemetry-native-storage'
summary=json.loads((study/'paired/summary.json').read_text())
assert summary['pairs']==8 and summary['all_commands_succeeded'] and summary['same_rows']
restored=json.loads((study/'paired/restored-state.json').read_text())
assert restored['flags_restored'] and restored['source'] and restored['test_source'] and all(restored['configs'].values())
assert all(r['exit_code']==0 for r in json.loads((study/'listing-pipeline.json').read_text()))
assert len(json.loads((study/'actual-overlay-validation.json').read_text()))==5
assert all(r['exit_code']==0 for r in json.loads((study/'actual-overlay-validation.json').read_text()))
assert json.loads((study/'old-index-control.json').read_text())['exit_code']==1
capture=json.loads((study/'capture/result.json').read_text())
assert capture['exit_code']==0 and capture['rows']==4398 and capture['same_rows'] and capture['source_restored']
assert capture['recorder']==dict(events=1134726,dropped=0,open=0)
assert 'clientdb.marshalNativeProto' in (study/'capture/native-codec-cpu.log').read_text()
state=json.loads((study/'final-state.json').read_text())
assert not state['native-telemetry-storage']['enabled'] and not state['wcprof/enabled']['global_enabled']
assert not state['client-lifecycle'].get('sessions') and not state['client-lifecycle']['active_requests']
assert not json.loads((study/'decision.json').read_text())['native_writer_selected']

for name, title in studies.items():
    source = base / name
    out = repo / 'experiments' / name
    assert not out.exists(), out
    context = source / 'source-context'
    context.mkdir(exist_ok=True)
    mappings = []
    for overlay in sorted(source.glob('*overlay*.json')):
        document = json.loads(overlay.read_text())
        if not isinstance(document, dict) or not isinstance(document.get('Replace'), dict):
            continue
        for destination, original in sorted(document['Replace'].items()):
            original = Path(original)
            sha = digest(original)
            target = context / (sha[:16] + '-' + original.name)
            if target.exists():
                assert digest(target) == sha
            else:
                shutil.copyfile(original, target)
            mappings.append(dict(overlay=str(overlay), destination=destination,
                source=str(original), archived_source=str(target.relative_to(source)), sha256=sha))
    (context / 'OVERLAYS.json').write_text(json.dumps(mappings, indent=2)+'\n')
    copies = {
        'engine.go.mod': base / 'otel-evicted-queue/engine.go.mod',
        'engine.go.sum': base / 'otel-evicted-queue/engine.go.sum',
        'listing-protocol.py': base / 'rust-go-test-collections/measure.py',
        'local_cli_collector.py': base / 'local_cli_collector.py',
        'verify_retained_first.py': base / 'trivial-scalar-projection/verify_retained_first.py',
        'restart_owned_engine_clean.py': base / 'restart_owned_engine_clean.py',
        'archive_native_telemetry_storage.py': Path(__file__),
        'selected-go.dang': Path('/tmp/dagger-go-module-test-name-index/go.dang'),
        'selected-gomod-main.dang': Path('/tmp/dagger-go-module-test-name-index/gomod/main.dang'),
        'go-module-dagger.toml': Path('/tmp/dagger-go-module-test-name-index/dagger.toml'),
        'expected-listing.stdout': base / 'glob-literal-prefix/full-command-paired/0-before.stdout',
    }
    for target, original in copies.items():
        shutil.copyfile(original, context / target)
    runtime = base / 'dang-module-blueprint-content-key'
    for original in [runtime/'go.mod', runtime/'go.sum', *sorted((runtime/'pkg').rglob('*'))]:
        if original.is_file() and original.suffix in {'.go', '.dang', '.peg', '.mod', '.sum'}:
            target = context / 'dang-runtime' / original.relative_to(runtime)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
    if name == 'telemetry-native-storage':
        for history in sorted(base.glob('native-discovery-retained-' + name + '*')):
            assert len(list(history.glob('*.log'))) == 6
            for original in sorted(history.rglob('*')):
                if original.is_file() and original.suffix in {'.log', '.json'}:
                    target = context / history.name / original.relative_to(history)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(original, target)
    files, omitted = [], []
    for f in sorted(source.rglob('*')):
        if not f.is_file() or f.suffix not in allowed or f.name.startswith('dagger-engine'):
            continue
        if f.name == 'wcprof-complete.ndjson':
            omitted.append(dict(source=str(f), sha256=digest(f), bytes=f.stat().st_size,
                reason='Reconstructable from archived compressed recorder chunks and capture driver.'))
            continue
        files.append(dict(path='testdata/' + str(f.relative_to(source)), source=str(f),
                          bytes=f.stat().st_size, sha256=digest(f)))
    groups, group, size = [], [], 0
    for row in files:
        assert row['bytes'] < 95*1024*1024, row['path']
        if group and size + row['bytes'] > 80*1024*1024:
            groups.append(group)
            group, size = [], 0
        group.append(row)
        size += row['bytes']
    if group:
        groups.append(group)
    out.mkdir()
    archives = []
    for index, group in enumerate(groups):
        archive = out / f'evidence-{index:02d}.tar.gz'
        with tarfile.open(archive, 'w:gz', compresslevel=6) as tf:
            for row in group:
                tf.add(row['source'], arcname=row['path'], recursive=False)
        with tarfile.open(archive, 'r:gz') as tf:
            assert len(tf.getmembers()) == len(group)
            for row in group:
                member = tf.extractfile(row['path'])
                h, size = hashlib.sha256(), 0
                for chunk in iter(lambda: member.read(1024*1024), b''):
                    size += len(chunk)
                    h.update(chunk)
                assert size == row['bytes'] and h.hexdigest() == row['sha256'], row['path']
        assert archive.stat().st_size < 100*1024*1024
        archives.append(dict(path=archive.name, bytes=archive.stat().st_size,
                             sha256=digest(archive), members=len(group)))
        for row in group:
            row['archive'] = archive.name
    (out / 'MANIFEST.json').write_text(json.dumps(dict(
        archives=archives, files=files, omitted_reconstructable=omitted,
        all_attempts_retained=True, new_pr_opened=False, new_upstream_proposal=False,
        optimization_selected=False,
        engine_base='19eda924854e7f22582f3a7430272aa729cbeb5f',
        source_base='ff0b029a4d270a651b9a8c7286babc79089066e4'), indent=2)+'\n')
    (out / 'README.md').write_text('# '+title+'\n\nSee [the assessment](../../'+report+'). These archives retain exact sources and overlays, drivers, diagnostics, every test outcome and any component observations. This prototype reduces CPU and allocation in all eight pairs and improves the full listing median in its first cohort. Native writing remains disabled pending an independent-order confirmation and migration review. The engine keeps dual-format readers and outer-store v2 support; do not downgrade to a v1-only reader over these telemetry stores. No upstream-ready proposal or PR is claimed.\n\n`MANIFEST.json` records the size and SHA-256 of each independently verified archive member. Engine binaries are omitted and identified by build hash. Expanded recorder data is reconstructable from the compressed chunks.\n')
    print(json.dumps(dict(study=name, files=len(files), archives=len(archives),
                          bytes=sum(row['bytes'] for row in archives), verified=True)), flush=True)
