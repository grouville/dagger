package clientdb

import (
	"testing"

	commonpb "go.opentelemetry.io/proto/otlp/common/v1"
	resourcepb "go.opentelemetry.io/proto/otlp/resource/v1"
)

func BenchmarkStoredTelemetryCodec(b *testing.B) {
	attrs := sampleSpanAttrs()
	data, err := MarshalStoredProtos(attrs)
	if err != nil {
		b.Fatal(err)
	}
	b.Run("encode-and-call-index", func(b *testing.B) {
		b.ReportAllocs()
		for b.Loop() {
			encoded, err := MarshalStoredProtos(attrs)
			if err != nil {
				b.Fatal(err)
			}
			if digest, ok := spanCallDigest(Span{Attributes: encoded}); !ok || digest != "xxh3:0123456789abcdef" {
				b.Fatal("missing call index digest")
			}
		}
	})
	b.Run("decode-attributes", func(b *testing.B) {
		b.ReportAllocs()
		for b.Loop() {
			var values []*commonpb.KeyValue
			if err := UnmarshalStoredProtos(data, &commonpb.KeyValue{}, &values); err != nil {
				b.Fatal(err)
			}
		}
	})
	resource := &resourcepb.Resource{Attributes: []*commonpb.KeyValue{strAttr("service.name", "dagger"), strAttr("telemetry.sdk.name", "opentelemetry"), strAttr("telemetry.sdk.version", "1.43.0")}}
	b.Run("encode-resource", func(b *testing.B) {
		b.ReportAllocs()
		for b.Loop() {
			if _, err := MarshalStoredProto(resource); err != nil {
				b.Fatal(err)
			}
		}
	})
}
