package clientdb

import "os"

func init() {
	if os.Getenv("DAGGER_TEST_NATIVE_TELEMETRY") == "1" {
		nativeTelemetryStorageEnabled.Store(true)
	}
	attributeArrayDecodeEnabled.Store(true)
	batchMetadataFast.Store(true)
}
