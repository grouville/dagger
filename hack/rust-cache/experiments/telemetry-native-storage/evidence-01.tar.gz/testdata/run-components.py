from pathlib import Path
import json
import os
import re
import statistics
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
overlay=json.loads((p/'integration-test-overlay.json').read_text())
overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/engine/clientdb/native_codec_bench_test.go']=str(p/'codec_bench_test.go')
(p/'component-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
rows=[]
for pair in range(4):
    for arm in (['json','native'] if pair%2==0 else ['native','json']):
        command=[go,'test','-p=2','-count=1','-run=^$','-bench=^BenchmarkStoredTelemetryCodec$','-benchtime=250ms','-benchmem',
                 '-modfile=/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay='+str(p/'component-overlay.json'),'./engine/clientdb']
        env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',DAGGER_TEST_NATIVE_TELEMETRY='1' if arm=='native' else '0')
        log=p/f'component-{pair}-{arm}.log';start=time.monotonic()
        with log.open('w') as output:
            result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=output,stderr=subprocess.STDOUT)
        cases=[]
        for line in log.read_text().splitlines():
            match=re.match(r'^BenchmarkStoredTelemetryCodec/(.*)-8\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
            if match:cases.append(dict(name=match[1],iterations=int(match[2]),ns=float(match[3]),bytes=int(match[4]),allocations=int(match[5])))
        rows.append(dict(pair=pair,arm=arm,command=command,exit_code=result.returncode,seconds=time.monotonic()-start,cases=cases))
        (p/'component-samples.json').write_text(json.dumps(rows,indent=2)+'\n')
        print(json.dumps(dict(pair=pair,arm=arm,exit_code=result.returncode,cases=len(cases))),flush=True)
        assert result.returncode==0 and len(cases)==3,log.read_text()[-2000:]
summary={}
for name in sorted({case['name'] for row in rows for case in row['cases']}):
    values={arm:[next(case for case in row['cases'] if case['name']==name) for row in rows if row['arm']==arm] for arm in ['json','native']}
    summary[name]=dict(medians={arm:{field:statistics.median(case[field] for case in cases) for field in ['ns','bytes','allocations']} for arm,cases in values.items()},
                       faster_pairs=sum(a['ns']>b['ns'] for a,b in zip(values['json'],values['native'])))
(p/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
