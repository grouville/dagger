from pathlib import Path
import json
import subprocess
import time
import urllib.request

p=Path(__file__).parent
rows=[]


def mode(enabled):
    request=urllib.request.Request('http://127.0.0.1:16104/debug/native-telemetry-storage?enabled='+str(enabled).lower(),data=b'')
    with urllib.request.urlopen(request,timeout=20) as response:
        assert json.load(response)['enabled']==enabled


def run(label,command):
    start=time.monotonic()
    with (p/(label+'-driver.log')).open('w') as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,exit_code=result.returncode,seconds=time.monotonic()-start)
    rows.append(row)
    (p/'listing-pipeline.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==0,(p/(label+'-driver.log')).read_text()[-3000:]


assert json.loads((p/'retained-first-after.json').read_text())['exit_code']==0
try:
    mode(True)
    run('go-checks',['python3',str(p/'verify-checks.py')])
    mode(False)
    run('whole-command',['python3',str(p/'measure-listing.py'),'--output',str(p/'paired'),'--pairs','9','--languages','go'])
    mode(True)
    run('retained-after-pairs',['python3','/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py','telemetry-native-storage-after-pairs'])
finally:
    mode(False)
