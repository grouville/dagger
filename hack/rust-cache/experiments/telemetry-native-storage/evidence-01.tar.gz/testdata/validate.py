from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
assert 'ok  \tgithub.com/dagger/dagger/engine/clientdb' in (p/'clientdb-native-fixture-race.log').read_text()
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
base = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8')
selection = '^Test(LogsHandler|MetricsHandler|SessionSpanExporter|SessionLogExporter|ClientLogs|ClientRuntimeRetainsTelemetry|ControlAfterCalls|SessionExporters|CloudForwarder|CloudExportError|SessionCloudForwarder|Archive|ForwardedBatch|CloudEngineTelemetryResource|TelemetryOrigin)'
steps = [
    ('clientdb-json-fixtures', '0', './engine/clientdb', None),
    ('server-native', '1', './engine/server', selection),
    ('server-json', '0', './engine/server', selection),
    ('archive-api', '1', './engine/archive', None),
]
rows = []
for label, native, package, pattern in steps:
    command = [go, 'test', '-race', '-p=2', '-count=1', '-timeout=240s',
               '-modfile=/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
               '-overlay='+str(p/'integration-test-overlay.json')]
    if pattern:
        command.append('-run='+pattern)
    command.append(package)
    start = time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds',
            env=dict(base, DAGGER_TEST_NATIVE_TELEMETRY=native), stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, native_writer=native=='1', command=command,
               exit_code=result.returncode, seconds=time.monotonic()-start)
    rows.append(row)
    (p/'validation-pipeline.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, (p/(label+'.log')).read_text()[-5000:]
