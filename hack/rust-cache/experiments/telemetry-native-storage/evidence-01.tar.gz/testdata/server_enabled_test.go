package server

import (
	"net/http/httptest"
	"os"

	"github.com/dagger/dagger/engine/clientdb"
)

func init() {
	if os.Getenv("DAGGER_TEST_NATIVE_TELEMETRY") == "1" {
		clientdb.NativeTelemetryStorageDiagnostic(httptest.NewRecorder(), httptest.NewRequest("POST", "/?enabled=true", nil))
	}
}
