from pathlib import Path
import json
import os
import subprocess
import time

p=Path(__file__).parent
validation=json.loads((p/'validation-pipeline.json').read_text())
assert len(validation)==4 and all(row['exit_code']==0 for row in validation)
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',DAGGER_TEST_NATIVE_TELEMETRY='1')
prefix=[go,'test','-race','-p=2','-count=1','-timeout=180s','-modfile=/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod']


def run(label,command,expected=0):
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=output,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,exit_code=result.returncode,expected_exit_code=expected,seconds=time.monotonic()-start)
    print(json.dumps(row),flush=True)
    assert result.returncode==expected,(p/(label+'.log')).read_text()[-3000:]
    return row


row=run('clientdb-native-final',prefix+['-overlay='+str(p/'integration-test-overlay.json'),'./engine/clientdb'])
validation.append(row)
(p/'actual-overlay-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
overlay=json.loads((p/'integration-test-overlay.json').read_text())
for name in ['telemetry_store.go','call_index.go']:
    overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/engine/clientdb/'+name]=str(p/('before-engine__clientdb__'+name))
(p/'old-index-control-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
row=run('old-index-control',prefix+['-overlay='+str(p/'old-index-control-overlay.json'),'-run=^TestStoredProtoMixedHistoryReopensAndRebuildsIndexes$','./engine/clientdb'],1)
assert 'elements differ' in (p/'old-index-control.log').read_text().lower()
(p/'old-index-control.json').write_text(json.dumps(row,indent=2)+'\n')
run('components',['python3',str(p/'run-components.py')])
