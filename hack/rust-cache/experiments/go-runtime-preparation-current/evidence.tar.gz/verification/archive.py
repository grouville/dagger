from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
p=Path(__file__).parent;base=p.parent
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-runtime-preparation-current');out.mkdir(parents=True,exist_ok=False)
roots={'callback':base/'go-callback-caller-current','admission':base/'go-parallel-admission-current','attribution':base/'go-primitive-receiver-attribution','verification':p}
# Include the exact source snapshot used for independent patch validation.
up=base/'dang-lazy-eval-error-context/upstream-source/vito-dang-da1bed3'
with tarfile.open(p/'upstream-source.tar','w') as tar:
 for f in sorted(up.rglob('*')):
  if f.is_file() and '.git' not in f.parts and '__pycache__' not in f.parts:tar.add(f,arcname=str(f.relative_to(up)),recursive=False)
with (p/'go-module-source.tar').open('wb') as f:subprocess.run(['git','archive','--format=tar','de633b12ed2aa02e42adb698a23fcecc13faf36d'],cwd='/tmp/dagger-go-indexed-owner-facts',stdout=f,check=True)
shared=p/'shared-protocol';shared.mkdir()
for f in [base/'rust-go-test-collections/measure.py',base/'local_cli_collector.py']:(shared/f.name).write_bytes(f.read_bytes())
for root in [roots['callback'],roots['admission']]:
 for label in ['before','candidate','root-before','root-candidate']:
  d=root/('capture-'+label);events=[]
  for f in sorted(d.glob('chunk-*.ndjson.gz')):
   lines=gzip.decompress(f.read_bytes()).splitlines();header=json.loads(lines[0]);events.extend(lines[1:]);assert header['dropped_events']==0
  complete=(json.dumps(dict(header,event_count=len(events)))+'\n').encode()+b'\n'.join(events)+b'\n'
  assert complete==(d/'wcprof-complete.ndjson').read_bytes() and not header.get('open_ops')
files=[]
for prefix,root in roots.items():
 for f in sorted(root.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and '.git' not in f.parts and f.name!='wcprof-complete.ndjson':files.append((prefix+'/'+str(f.relative_to(root)),f))
manifest=[dict(path=name,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for name,f in files]
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();archive=out/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,f in files:
  info=tar.gettarinfo(str(f),arcname=name);info.mtime=0
  with f.open('rb') as source:tar.addfile(info,source)
 info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mtime=0;tar.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  payload=tar.extractfile(row['path']).read();assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
 assert tar.extractfile('manifest.json').read()==manifest_bytes
(out/'manifest.json').write_bytes(manifest_bytes)
for name in ['assessment.json','final-state.json','source-identity.json']:(out/name).write_bytes((p/name).read_bytes())
(out/'source-references.json').write_bytes((roots['callback']/'source-references.json').read_bytes())
(out/'callback-standalone.patch').write_bytes((roots['callback']/'standalone.patch').read_bytes())
metadata=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files)+1,all_member_hashes_verified=True,eight_wcprof_streams_reconstructed_losslessly=True)
(out/'archive.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata),flush=True)
