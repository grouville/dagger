from pathlib import Path
import hashlib,json,subprocess,urllib.request
p=Path(__file__).parent;base=p.parent;callback=base/'go-callback-caller-current';admission=base/'go-parallel-admission-current'
def get(route):
 with urllib.request.urlopen('http://127.0.0.1:16108/debug/'+route,timeout=15) as f:return json.load(f)
state=get('client-lifecycle');assert state['active_requests']==0 and not state.get('sessions')
plan=json.loads((base/'dang-shared-receiver-decode/engine-plan.json').read_text());flags={r:get(r)['enabled'] for r in plan['flags']};assert flags==plan['flags']
assert not get('wcprof/enabled')['global_enabled'];assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
activation=json.loads((base/'dang-shared-receiver-decode/activation.json').read_text());binaries={activation['engine']:activation['sha256'],**activation['retained_engines']}
for name,expected in binaries.items():assert subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]==expected
for study in [admission,callback]:
 for workload in ['test','source']:
  d=study/(workload+'-edit-paired');samples=json.loads((d/'samples.json').read_text());assert len(samples)==12 and all(r['exit_code']==0 and not r['cancelled'] and r['correct_names'] and r['same_full_rows'] for r in samples)
  r=json.loads((d/'restoration.json').read_text());assert r['source_restored'] and r['test_restored'] and r['config_restored']
 for label in ['before','candidate','root-before','root-candidate']:
  d=study/('capture-'+label);r=json.loads((d/'result.json').read_text());assert r['exit_code']==0 and r['same_names'] and not r['cancelled'] and not r['errors'] and r['recorder']['dropped']==0 and r['recorder']['open']==0
  r=json.loads((d/'restoration.json').read_text());assert r['source_restored'] and r['test_restored'] and r['config_restored']
units=json.loads((callback/'unit-checks.json').read_text());assert len(units)==5 and all(r['exit_code']==0 for r in units)
assert json.loads((callback/'negative-control.json').read_text())['expected_failure']
go=json.loads((callback/'checks.json').read_text());assert len(go)==9 and all(r['exit_code']==0 for r in go)
rust=json.loads((callback/'rust-pipeline/results.json').read_text());assert len(rust)==28 and all((r['exit_code']==0)==(r['expected']==0) and not r['cancelled'] for r in rust)
stats=[dict(label=r['label'],**r['native_cache_stats']) for r in rust if 'native_cache_stats' in r];assert len(stats)==4 and all(r['actions']==2 and r['hits']==2 for r in stats)
up=base/'dang-lazy-eval-error-context/upstream-source/vito-dang-da1bed3';assert (up/'pkg/dang/stdlib.go').read_bytes()==(callback/'before-upstream-stdlib.go').read_bytes()
subprocess.run(['git','apply','--check',str(callback/'standalone.patch')],cwd=up,check=True)
gofmt='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/gofmt';assert subprocess.check_output([gofmt,'-l',str(callback/'after-upstream-stdlib.go'),str(callback/'callback_caller_test.go')])==b''
identity={}
for name,path in [('go',Path('/tmp/dagger-go-indexed-owner-facts')),('rust',Path('/tmp/dagger-rust-test-collection-granularity')),('repository',Path('/tmp/dagger-go-real-repository-main'))]:
 identity[name]=dict(path=str(path),commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=path,text=True).splitlines());assert not identity[name]['status']
assert identity['go']['commit']=='de633b12ed2aa02e42adb698a23fcecc13faf36d'
(p/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
summary=dict(callback=json.loads((callback/'assessment.json').read_text()),admission=json.loads((admission/'assessment.json').read_text()),callback_selected=True,admission_selected=False)
(p/'assessment.json').write_text(json.dumps(summary,indent=2)+'\n')
(p/'final-state.json').write_text(json.dumps(dict(binaries=binaries,flags=flags,lifecycle=state,wcprof=get('wcprof/enabled'),lock_profiler=get('lock-profiler'),complete_correct_timing_commands=48,lossless_captures=8,unit_validation_steps=5,go_pipeline_checks=9,rust_pipeline_cases=28,native_cache_stats=stats,negative_control_expected_failure=True,callback_selected=True,admission_selected=False,cold_performance_unmeasured=True,rust_latency_gain_unmeasured=True,engine_cache_retained=True),indent=2)+'\n')
print(json.dumps(dict(flags_restored=True,retained_engines_unchanged=True,active_requests=state['active_requests'],correct_timing_commands=48,lossless_captures=8,unit_validation_steps=5,go_pipeline_checks=9,rust_pipeline_cases=28,native_cache_stats=stats,callback_selected=True,admission_selected=False)),flush=True)
