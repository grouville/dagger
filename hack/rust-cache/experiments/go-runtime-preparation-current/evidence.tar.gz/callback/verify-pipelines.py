from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for label,name in [('go','verify-module.py'),('rust','verify-rust.py')]:
 command=['python3',str(p/name)];tick=time.monotonic()
 with (p/(label+'-pipeline-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'pipeline-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-pipeline-driver.log')).read_text()[-5000:]);raise SystemExit(r.returncode)
