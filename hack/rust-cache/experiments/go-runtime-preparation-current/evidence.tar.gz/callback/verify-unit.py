from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;base=p.parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
up=base/'dang-lazy-eval-error-context/upstream-source/vito-dang-da1bed3';dev=Path('/tmp/dagger-filesync-snapshot-seeds')
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',DANG_BENCH_COERCED_METHOD_HOISTING='true',DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT='true',DANG_BENCH_SHARED_FUNCTION_METADATA='false')
steps=[('standalone-applies',up,['git','apply','--check',str(p/'standalone.patch')]),('upstream-before-focused',up,[go,'test','-p=2','-mod=readonly','-overlay='+str(p/'upstream-before-overlay.json'),'-count=1','-race','-timeout=120s','-run=^TestCallbackCaller','./pkg/dang']),('upstream-after-full-race',up,[go,'test','-p=2','-mod=readonly','-overlay='+str(p/'upstream-after-overlay.json'),'-count=1','-race','-timeout=120s','./pkg/dang']),('development-dang-full-race',dev,[go,'test','-p=2','-modfile='+str(base/'log-flush-buffer/engine.go.mod'),'-overlay='+str(p/'development-test-overlay.json'),'-count=1','-race','-timeout=120s','github.com/vito/dang/v2/pkg/dang']),('development-sdk-full-race',dev,[go,'test','-p=2','-modfile='+str(base/'log-flush-buffer/engine.go.mod'),'-overlay='+str(p/'development-test-overlay.json'),'-count=1','-race','-timeout=120s','./core/sdk/dang/v2'])]
rows=[]
for label,cwd,command in steps:
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,cwd=str(cwd),seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'unit-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'.log')).read_text()[-5000:]);raise SystemExit(r.returncode)
