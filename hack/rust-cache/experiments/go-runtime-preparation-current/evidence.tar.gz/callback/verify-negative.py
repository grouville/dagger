from pathlib import Path
import json,subprocess,os,time
p=Path(__file__).parent;base=p.parent;up=base/'dang-lazy-eval-error-context/upstream-source/vito-dang-da1bed3';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
command=[go,'test','-p=2','-mod=readonly','-overlay='+str(p/'upstream-negative-overlay.json'),'-count=1','-race','-timeout=120s','-run=^TestCallbackCallerKeepsCustomCallableFresh$','./pkg/dang'];tick=time.monotonic()
with (p/'negative-custom-callable.log').open('w') as out:r=subprocess.run(command,cwd=up,env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8'),stdout=out,stderr=subprocess.STDOUT)
assert r.returncode!=0 and 'mutable custom caller was shared' in (p/'negative-custom-callable.log').read_text()
result=dict(command=command,seconds=time.monotonic()-tick,exit_code=r.returncode,expected_failure=True,reason='The regression rejects unconditional sharing of a caller that custom Callable implementations can mutate.',production_sources_unchanged=True)
(p/'negative-control.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
