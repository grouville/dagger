from pathlib import Path
import json,os,subprocess
p=Path(__file__).parent;base=p.parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8')
rows=[]
for label in ['root-before','root-candidate']:
 d=p/('capture-'+label)
 with (d/'analysis.log').open('w') as out:r=subprocess.run(['python3',str(p/'analyze.py'),str(d)],stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==0
 with (d/'callback-direct-callees.json').open('w') as out,(d/'callback-direct-callees.stderr').open('w') as err:r=subprocess.run([go,'run','-p=2','-modfile='+str(base/'log-flush-buffer/engine.go.mod'),str(base/'go-primitive-receiver-attribution/profile_lines.go'),*[str(f) for f in sorted(d.glob('engine-cpu-*.pprof'))]],cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=err)
 assert r.returncode==0
 attribution=json.loads((d/'attribution.json').read_text());cpu=json.loads((d/'callback-direct-callees.json').read_text())
 row=dict(label=label,module_evaluations=attribution['function_evaluations'],sdk_requests=attribution['sdk_requests'],selected_calls=attribution['selected_calls'],cpu=cpu,dropped=attribution['dropped'],open_ops=attribution['open_ops']);rows.append(row)
 print(json.dumps(dict(label=label,module_evaluations=row['module_evaluations'],sdk_requests=row['sdk_requests'],cpu=cpu['direct_callee_cpu_seconds'])),flush=True)
(p/'root-attribution.json').write_text(json.dumps(rows,indent=2)+'\n')
