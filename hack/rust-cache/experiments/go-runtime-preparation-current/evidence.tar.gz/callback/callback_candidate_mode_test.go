package dangv2

import "github.com/vito/dang/v2/pkg/dang"

func init() { dang.SetCallbackCallerReuseDiagnostic(true) }
