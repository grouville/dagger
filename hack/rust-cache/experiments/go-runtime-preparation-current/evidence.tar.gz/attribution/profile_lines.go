package main

import (
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"github.com/google/pprof/profile"
)

type key struct {
	File string
	Line int64
}
type row struct {
	File       string  `json:"file"`
	Line       int64   `json:"line"`
	CPUSeconds float64 `json:"cpu_seconds"`
}

func main() {
	totals := map[key]int64{}
	children := map[string]int64{}
	var all, attributed int64
	for _, path := range os.Args[1:] {
		f, err := os.Open(path)
		if err != nil {
			panic(err)
		}
		p, err := profile.Parse(f)
		f.Close()
		if err != nil {
			panic(err)
		}
		cpu := -1
		for i, t := range p.SampleType {
			if t.Type == "cpu" && t.Unit == "nanoseconds" {
				cpu = i
			}
		}
		if cpu < 0 {
			panic("CPU sample type missing")
		}
		for _, sample := range p.Sample {
			value := sample.Value[cpu]
			all += value
			found := false
			previousFunction := "<self>"
			for _, loc := range sample.Location {
				for _, line := range loc.Line {
					if line.Function != nil && strings.HasSuffix(line.Function.Name, "/pkg/dang.callFunc") {
						children[previousFunction] += value
						totals[key{line.Function.Filename, line.Line}] += value
						attributed += value
						found = true
						break
					}
					if line.Function != nil {
						previousFunction = line.Function.Name
					}
				}
				if found {
					break
				}
			}
		}
	}
	rows := make([]row, 0, len(totals))
	for k, v := range totals {
		rows = append(rows, row{k.File, k.Line, float64(v) / 1e9})
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].CPUSeconds > rows[j].CPUSeconds })
	childSeconds := map[string]float64{}
	for k, v := range children {
		childSeconds[k] = float64(v) / 1e9
	}
	out := struct {
		Children    map[string]float64 `json:"direct_callee_cpu_seconds"`
		TotalCPU    float64            `json:"total_cpu_seconds"`
		CallbackCPU float64            `json:"callback_cpu_seconds"`
		Rows        []row              `json:"innermost_callfunc_lines"`
	}{childSeconds, float64(all) / 1e9, float64(attributed) / 1e9, rows}
	data, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		panic(err)
	}
	fmt.Println(string(data))
}
