# Four allocation reductions together

The candidate jointly enables prepared-schema, callback-caller-reuse, lazy-type-maps and interface-field-snapshots. It uses the selected Go module in both arms; collections and native cache keys are unchanged. The three correctness checks pass, including retained Rust histories and edited retained Go packages.

The four-pair full-command cohort measures 39.88793 -> 36.25777 seconds median, faster in only two pairs. Engine CPU medians fall 197.45912 -> 180.86493 seconds and cumulative allocation 29.64508 -> 25.84811 GB. All ten commands exit 0 with expected ordered rows; the excluded initialization pair adds one real test (4399), then measured pairs remove it (4398). Every command uses a fresh CLI and fresh source edit on the warm engine. Ordinary GC and telemetry stay enabled. Profiling is off. Cold startup is unmeasured.

A class-table compaction overlaps candidate pair 3 (1127195 -> 644368 slots). The complete-command result remains inconclusive; all observations are retained. The four switches are restored off. No independent gains may be inferred or added to earlier medians. This study adds no upstream proposal or PR.
