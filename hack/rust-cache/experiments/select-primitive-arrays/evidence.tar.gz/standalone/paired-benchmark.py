from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;repo='/tmp/dagger-select-primitive-arrays';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[]
for block in range(4):
 for arm in (['before','after'] if block%2 else ['after','before']):
  args=[go,'test','-p=2']+(['-overlay='+str(p/'before-overlay.json')] if arm=='before' else [])+['-run=^$','-bench=^BenchmarkSelectPrimitiveArray$','-benchmem','-benchtime=200ms','-count=1','./dagql']
  label=f'{block}-{arm}';tick=time.monotonic()
  with (p/(label+'.log')).open('w') as out:r=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
  assert r.returncode==0,(label,(p/(label+'.log')).read_text()[-3000:])
  cases=[]
  for length,ns,b,allocs in re.findall(r'BenchmarkSelectPrimitiveArray/(\d+)-\d+\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(p/(label+'.log')).read_text()):cases.append(dict(length=int(length),ns=float(ns),bytes=int(b),allocs=int(allocs)))
  assert len(cases)==2
  rows.append(dict(block=block,arm=arm,command=args,seconds=time.monotonic()-tick,cases=cases));(p/'paired-benchmark.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
summary={}
for length in [8,1024]:
 summary[length]={}
 for arm in ['before','after']:
  cases=[c for r in rows if r['arm']==arm for c in r['cases'] if c['length']==length];summary[length][arm]={k:statistics.median(c[k] for c in cases) for k in ['ns','bytes','allocs']}
 summary[length]['faster_pairs']=sum(next(c['ns'] for r in rows if r['arm']=='after' and r['block']==block for c in r['cases'] if c['length']==length)<next(c['ns'] for r in rows if r['arm']=='before' and r['block']==block for c in r['cases'] if c['length']==length) for block in range(4))
(p/'paired-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
