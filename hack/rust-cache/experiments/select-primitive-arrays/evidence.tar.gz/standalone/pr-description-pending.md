Internal `Server.Select` calls create a cache result for every element of a list, even when the caller only needs plain values. Native workspace globs encounter this while copying directory paths. Each element also copies the list call frame, so larger recipes make the work more expensive.

Append a copy of native string, integer, float and boolean arrays directly into slices with the same element type. Field resolution, dynamic inputs and operation leases still run. Destinations holding result identities, explicit element selections, object/custom/nullable lists and scalar conversions keep their existing behavior. The change adds ten lines and introduces no API, cache or lock.

Four alternating component pairs on Go 1.26.6, selecting a cached list field:

| List size | Before | After | Allocation before → after |
| --- | ---: | ---: | ---: |
| 8 | 34.60 µs | 3.80 µs | 22.15 → 1.84 kB |
| 1,024 | 3.786 ms | 9.128 µs | 2.65 MB → 20.17 kB |

All four pairs improve at each size. For a development Go module that discovers packages through native directories, complete dagger/dagger test listing improves **5.43 → 4.86 s** after ordinary-source edits and **8.29 → 7.86 s** after test edits, faster in all eight pairs. Engine allocation falls by **606 MB** and **613 MB**, respectively. Those commands start fresh CLIs on a warm experimental engine and include telemetry, output, flushing and session cleanup.

That broader-directory module remains slower than the currently selected module. On the selected module, listing is essentially flat at **3.95 → 3.91 s** and **6.86 → 6.85 s**, faster in only two of four pairs per workload. This is a targeted internal-selection improvement, not a claim of faster listing for every module or of improved cold starts.

The regression fails on upstream main because a three-element primitive array creates four cache entries instead of one. Tests verify values, order, duplicates, append behavior and separate destination storage across the four built-in types. Additional checks retain loadable element identities, explicit Nth selection, native Go string conversion, per-call evaluation, authored errors and session-release errors. The complete standalone and development-stack DagQL race suites pass. Thirty-two public Go checks, 28 Rust/native-cache cases and all 48 timed listings have their expected outcomes. Eight lossless wcprof captures preserve all 800 authored getters after test edits and 799 unchanged test-discovery hits.
