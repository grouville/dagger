package dagql

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var selectPrimitiveArraysEnabled atomic.Bool

func init() {
	selectPrimitiveArraysEnabled.Store(os.Getenv("DAGGER_TEST_SELECT_PRIMITIVE_ARRAYS") == "true")
}
func SelectPrimitiveArraysDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		v, e := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if e != nil {
			http.Error(w, e.Error(), 400)
			return
		}
		selectPrimitiveArraysEnabled.Store(v)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": selectPrimitiveArraysEnabled.Load()})
}
