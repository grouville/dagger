from pathlib import Path
import json,os,signal,subprocess,time,urllib.request
p=Path(__file__).parent;base=p.parent;debug='http://127.0.0.1:16118/debug/'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=15) as f:return json.load(f)
routes=['collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata','shared-receiver-decode','prepared-schema','callback-caller-reuse','interface-candidate-pruning','interface-field-snapshots','metadata-snapshot-json','parallel-client-admission','linear-map-merge','lazy-spill-buffers','read-config-before-stat','select-primitive-arrays'];flags={r:get(r)['enabled'] for r in routes}
assert not get('wcprof/enabled')['global_enabled'];assert not get('metadata-snapshot-unlocked')['enabled'];assert not get('parallel-client-admission')['enabled'];assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16290',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
repos={'before':Path('/tmp/dagger-go-generation-native-membership'),'candidate':Path('/tmp/dagger-go-generation-native-membership')}
saved={arm:(repo/'.dagger/modules/go-dev/main.dang').read_bytes() for arm,repo in repos.items()};rows=[]
def run(arm,repo,check):
 tick=time.monotonic();label=arm+'-'+check.replace(':','-')
 with (p/(label+'.log')).open('w') as out:
  process=subprocess.Popen(['python3',str(base/'local_cli_collector.py'),'check',check],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  cancelled=False
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait(timeout=60)
 row=dict(arm=arm,check=check,seconds=time.monotonic()-tick,exit_code=code,cancelled=cancelled);rows.append(row);(p/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code or cancelled:print((p/(label+'.log')).read_text()[-3000:]);raise SystemExit(code or 1)
try:
 for route in routes:get(route+'?enabled='+str(route not in ['shared-function-metadata','shared-receiver-decode','interface-field-snapshots','metadata-snapshot-json','parallel-client-admission','linear-map-merge','lazy-spill-buffers','read-config-before-stat','select-primitive-arrays']).lower(),b'')
 for arm,repo in repos.items():
  get('parallel-client-admission?enabled=false',b'')
  get('linear-map-merge?enabled=false',b'')
  get('lazy-spill-buffers?enabled=false',b'')
  get('read-config-before-stat?enabled=true',b'')
  get('select-primitive-arrays?enabled='+str(arm=='candidate').lower(),b'')
  source=repo/'.dagger/modules/go-dev/main.dang';source.write_bytes(saved[arm]+f'\n# Native sort checker freshness {arm} {time.time_ns()}\n'.encode())
  for check in ['go-dev:package-owner-index-check','go-dev:package-owner-settings-check','go-dev:collection-check','go-dev:test-snapshot-directories-check','go-dev:discovery-check','go-dev:package-layout-rebind-check','go-dev:tests-collection-check','go-dev:binary-check','go-dev:generate-check','go-dev:generation-globs-check','go-dev:selection-check','go-dev:generation-discovery-check']:run(arm,repo,check)
 for check in ['gomod-checks:own-files-check','gomod-checks:package-facts-check','gomod-checks:selection-check']:run('candidate',repos['candidate'],check)
finally:
 for arm,repo in repos.items():(repo/'.dagger/modules/go-dev/main.dang').write_bytes(saved[arm])
 for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
 (p/'checks-restoration.json').write_text(json.dumps(dict(checkers_restored=all((repo/'.dagger/modules/go-dev/main.dang').read_bytes()==saved[arm] for arm,repo in repos.items()),flags_after={r:get(r) for r in routes},lifecycle=get('client-lifecycle')),indent=2)+'\n')
