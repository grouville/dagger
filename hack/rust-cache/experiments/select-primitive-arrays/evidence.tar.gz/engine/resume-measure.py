from pathlib import Path
import json,subprocess,time,sys
p=Path(__file__).parent;steps=json.loads((p/'steps.json').read_text())
for label,script in [('rust-pipeline-with-query',p/'verify-rust.py'),('timings',p/'measure.py')]:
 tick=time.monotonic();command=[sys.executable,str(script)]
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-4500:]);raise SystemExit(r.returncode)
