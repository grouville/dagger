pub fn edited_value() -> u64 { 789 }
#[test]
fn fresh_before_repaired() { assert_eq!(edited_value(), 789); }
#[test]
fn must_fail() { assert!(edited_value() > 0); }
