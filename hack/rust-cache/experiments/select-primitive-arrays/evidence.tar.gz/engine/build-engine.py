from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',DAGGER_TEST_READ_CONFIG_BEFORE_STAT='true',DAGGER_TEST_SELECT_PRIMITIVE_ARRAYS='true',DAGGER_BENCH_INTERFACE_INDEX='true',DANG_BENCH_COERCED_METHOD_HOISTING='true',DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT='true',DANG_BENCH_SHARED_FUNCTION_METADATA='false')
args=['-p=2','-buildvcs=false','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod','-overlay='+str(p/'overlay.json')]
for label,command in [('dagql-race',[go,'test',*args,'-race','-count=1','./dagql']),('engine-build',[go,'build',*args,'-o',str(p/'dagger-engine'),'./cmd/engine'])]:
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=subprocess.STDOUT)
 record=dict(command=command,seconds=time.monotonic()-tick,exit_code=result.returncode,environment={k:env[k] for k in ['GOMAXPROCS','GOPROXY','GOSUMDB','DAGGER_TEST_READ_CONFIG_BEFORE_STAT','DAGGER_TEST_SELECT_PRIMITIVE_ARRAYS','DAGGER_BENCH_INTERFACE_INDEX','DANG_BENCH_COERCED_METHOD_HOISTING','DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT']})
 if label=='engine-build' and not result.returncode:record['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
 (p/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(label=label,**record)),flush=True)
 if result.returncode:print((p/(label+'.log')).read_text()[-3500:],flush=True);raise SystemExit(result.returncode)
