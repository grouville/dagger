from pathlib import Path
from collections import Counter
import json,subprocess,time,statistics
p=Path(__file__).parent;rows=[]
for record in json.loads((p/'capture-steps.json').read_text()):
 capture=p/('capture-'+record['label']);tick=time.monotonic()
 with (capture/'analysis.log').open('w') as out:r=subprocess.run(['python3',str(p/'analyze.py'),str(capture)],stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==0
 windows=sorted(capture.glob('engine-cpu-*.pprof'))
 for cumulative in [False,True]:
  command=['/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go','tool','pprof','-top','-nodecount=100']+(['-cum'] if cumulative else [])+[str(p/'dagger-engine'),*[str(f) for f in windows]]
  with (capture/('cpu-cumulative.txt' if cumulative else 'cpu-flat.txt')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
  assert r.returncode==0
 a=json.loads((capture/'attribution.json').read_text());assert not a['dropped'] and not a['open_ops'];f=(capture/'wcprof-complete.ndjson').open();header=json.loads(next(f));strings=header['strings'];counts=Counter()
 for ln in f:
  e=json.loads(ln)
  if e.get('e')=='op':counts[e.get('k'),strings[e.get('c',0)]]+=1
 row=dict(label=record['label'],arm=record['arm'],module=record['module'],test_edit=record['test_edit'],command_seconds=json.loads((capture/'result.json').read_text())['seconds'],function_evaluations=a['function_evaluations'],sdk_requests=a['sdk_requests'],getter=a['selected_calls']['go:GoPackages.get'],test_discovery=a['selected_calls']['go:GoPackage.tests'],string_glob_calls=counts['call','String.glob'],publication_operations=counts['internal','dagql.publishResult'],scalar_result_calls={name:n for (kind,name),n in counts.items() if kind=='call' and name.startswith(('String.','Int.','Float.','Boolean.'))},main_query=a['main_query'],dropped=a['dropped'],open=a['open_ops'],analysis_seconds=time.monotonic()-tick)
 rows.append(row);print(json.dumps(row),flush=True)
summary={}
for workload in ['test','source']:
 samples=json.loads((p/(workload+'-edit-paired/samples.json')).read_text());pairs={}
 for label,left,right in [('current-engine','before','engine'),('native-engine','typed','combined'),('native-combined-vs-current','before','combined')]:
  differences=[]
  for block in range(2,6):
   pair={r['arm']:r for r in samples if r['block']==block};differences.append(pair[left]['seconds']-pair[right]['seconds'])
  pairs[label]=dict(before=left,after=right,paired_seconds=differences,median_paired_saving=statistics.median(differences),faster_pairs=sum(v>0 for v in differences))
 summary[workload]=dict(medians=json.loads((p/(workload+'-edit-paired/summary.json')).read_text()),comparisons=pairs,commands=len(samples),all_correct=all(r['exit_code']==0 and r['correct_names'] and r['same_full_rows'] and not r['cancelled'] for r in samples))
(p/'assessment.json').write_text(json.dumps(dict(timings=summary,diagnostics=rows),indent=2)+'\n');print(json.dumps(summary),flush=True)
