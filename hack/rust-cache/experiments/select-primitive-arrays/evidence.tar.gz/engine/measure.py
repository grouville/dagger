from pathlib import Path
import subprocess,sys,time,json
p=Path(__file__).parent
rows=[]
for workload in ['source','test']:
 command=[sys.executable,str(p/f'measure-{workload}-edits.py'),'--output',str(p/(workload+'-edit-paired')),'--fixture','real','--arms','before','engine','typed','combined','--pairs','4']
 tick=time.monotonic()
 with (p/(workload+'-edit-driver.log')).open('w') as out:
  result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(workload=workload,command=command,seconds=time.monotonic()-tick,exit_code=result.returncode)
 rows.append(row);(p/'timing-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:print((p/(workload+'-edit-driver.log')).read_text()[-5000:]);raise SystemExit(result.returncode)
 print((p/(workload+'-edit-paired/summary.json')).read_text(),flush=True)
