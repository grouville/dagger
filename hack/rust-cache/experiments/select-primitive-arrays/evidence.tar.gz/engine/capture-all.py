from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for test_edit in [True,False]:
 for module in ['current','native']:
  for arm in ['before','candidate']:
   label=('test' if test_edit else 'source')+'-'+module+'-'+arm
   command=['python3',str(p/'capture.py'),'--arm',arm,'--module',module,'--output',str(p/('capture-'+label)),'--cpu-profile']+(['--edit-test-body'] if test_edit else [])
   tick=time.monotonic()
   with (p/('capture-'+label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
   row=dict(label=label,arm=arm,module=module,test_edit=test_edit,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'capture-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
   if r.returncode:print((p/('capture-'+label+'-driver.log')).read_text()[-4000:]);raise SystemExit(r.returncode)
