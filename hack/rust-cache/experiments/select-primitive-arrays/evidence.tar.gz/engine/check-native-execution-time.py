from pathlib import Path
import json,os,signal,subprocess,time,urllib.request
p=Path(__file__).parent;out=p/'native-execution-followup';out.mkdir(exist_ok=False)
repo=Path('/tmp/dagger-go-discovery-source-snapshot');source=repo/'.dagger/modules/go-dev/main.dang';saved=source.read_bytes()
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16118/debug/'+route,data=data),timeout=15) as f:return json.load(f)
flags={r:get(r)['enabled'] for r in ['collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata','shared-receiver-decode','prepared-schema','callback-caller-reuse','interface-candidate-pruning','interface-field-snapshots','metadata-snapshot-json','parallel-client-admission','linear-map-merge','lazy-spill-buffers','read-config-before-stat','select-primitive-arrays']}
assert not get('wcprof/enabled')['global_enabled']
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16290',RUST_CACHE_BENCH_CLI=str(p.parent/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(p.parent/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
needle=b'func TestRoot(t *testing.T) {}\\n"';assert saved.count(needle)==1
rows=[]
try:
 for route in flags:get(route+'?enabled='+str(route not in ['shared-function-metadata','shared-receiver-decode','interface-field-snapshots','metadata-snapshot-json','parallel-client-admission','linear-map-merge','lazy-spill-buffers','select-primitive-arrays']).lower(),b'')
 for block in range(2):
  for arm in (['after','before'] if block==0 else ['before','after']):
   get('select-primitive-arrays?enabled='+str(arm=='after').lower(),b'')
   replacement=b'func TestRoot(t *testing.T) {}\\n// fresh test build '+str(time.time_ns()).encode()+b'\\n"';source.write_bytes(saved.replace(needle,replacement))
   label=f'{block}-{arm}';tick=time.monotonic();command=['python3',str(p.parent/'local_cli_collector.py'),'check','go-dev:test-snapshot-directories-check']
   with (out/(label+'.log')).open('w') as log:
    child=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:code=child.wait(timeout=300)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGINT);code=child.wait(timeout=60)
   row=dict(block=block,arm=arm,command=command,seconds=time.monotonic()-tick,exit_code=code,fresh_test_source=True);rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
   assert code==0,(label,(out/(label+'.log')).read_text()[-3000:])
finally:
 source.write_bytes(saved)
 for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
 (out/'restoration.json').write_text(json.dumps(dict(source_restored=source.read_bytes()==saved,flags_after={r:get(r) for r in flags}),indent=2)+'\n')
