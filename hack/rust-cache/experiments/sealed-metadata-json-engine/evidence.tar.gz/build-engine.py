from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOMAXPROCS='8', GOTOOLCHAIN='local', GOWORK='off',
           DAGGER_TEST_SEALED_METADATA_JSON='on', DAGGER_TEST_PARALLEL_CLIENT_ADMISSION='on',
           DANG_BENCH_COERCED_METHOD_HOISTING='true', DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT='true',
           DANG_BENCH_SHARED_FUNCTION_METADATA='false')
args = ['-p=2', '-buildvcs=false', '-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod', '-overlay='+str(p/'overlay.json')]
steps = []
for label, command in [
    ('engine-server-race', [go, 'test', *args, '-race', '-count=1', './engine/server']),
    ('engine-build', [go, 'build', *args, '-o', str(p/'dagger-engine'), './cmd/engine']),
]:
    tick = time.monotonic()
    with (p/(label+'.log')).open('w') as out:
        result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds', env=env, stdout=out, stderr=subprocess.STDOUT)
    row = dict(command=command, seconds=time.monotonic()-tick, exit_code=result.returncode)
    if label == 'engine-build' and not result.returncode:
        row['sha256'] = hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
    (p/(label+'.json')).write_text(json.dumps(row, indent=2)+'\n')
    print(json.dumps(dict(label=label, **row)), flush=True)
    if result.returncode:
        print((p/(label+'.log')).read_text()[-3000:], flush=True)
        raise SystemExit(result.returncode)
