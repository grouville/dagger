from pathlib import Path
import argparse, gzip, hashlib, json, os, signal, subprocess, sys, threading, time

parser=argparse.ArgumentParser()
parser.add_argument('--arm',choices=['before','candidate'],required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--add-test',action='store_true')
parser.add_argument('--cpu-profile',action='store_true')
parser.add_argument('--edit-test-body',action='store_true')
options=parser.parse_args()
p=Path('/tmp/rust-cache-sipsma-review/collection-work-amplification')
sys.argv=[sys.argv[0],'--output',str(options.output)]
protocol=p.parent/'rust-go-test-collections/measure.py'
exec(protocol.read_text().split('fixtures = [f for f')[0].replace('dagger-rust-parser-state-pool-oct14','dagger-collection-metadata-json-oct19').replace(':16104',':16112').replace(':16276',':16284'))
cli=Path('/tmp/rust-cache-sipsma-review/typed-artifact-metadata/dagger')
env['_EXPERIMENTAL_DAGGER_CLI_BIN']=str(cli)
env['_EXPERIMENTAL_DAGGER_VERSION']='v1.0.0-beta.15'
env['DAGGER_DIAG_TYPED_ARTIFACT_METADATA']='true'
workspace=Path('/tmp/dagger-go-real-repository-main')
module={'before':Path('/tmp/dagger-go-indexed-owner-facts'),'candidate':Path('/tmp/dagger-go-indexed-owner-facts')}[options.arm]
command=[str(cli),'check','--module','go','--check','test','--list','--all']
if options.arm=='discovery':command=[str(cli),'api','with-session','--load-workspace-modules','python3',str(p/'query.py'),str(p/'parallel-discovery.graphql')]
saved={n:(workspace/n).read_bytes() if (workspace/n).exists() else None for n in ['dagger.toml','dagger.lock']}
edit=workspace/'dagql/types.go';original=edit.read_bytes()
test=workspace/'dagql/cache_test.go';test_original=test.read_bytes()
test_name='TestInterfaceIndexCaptureFreshness'
assert test_name.encode() not in test_original
routes=['batch-metadata','attribute-array-decode','native-telemetry-storage','response-data-projection','collection-item-content','evaluation-context','receiver-preparation','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata','shared-receiver-decode','prepared-schema','callback-caller-reuse','interface-candidate-pruning','interface-field-snapshots','metadata-snapshot-json']
flags={r:get(r)['enabled'] for r in routes}
assert not get('parallel-client-admission')['enabled']
assert not get('metadata-snapshot-unlocked')['enabled']
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
idle('capture-'+options.arm)
stop=threading.Event();chunks=[];errors=[];drain_thread=None
cpu_thread=None;cpu_windows=[]
def raw(route,timeout=30):
    with __import__('urllib.request',fromlist=['urlopen']).urlopen(debug+route,timeout=timeout) as response:return response.read()
def profile_cpu():
    while not stop.is_set():
        started=time.monotonic()
        try:
            payload=raw('pprof/profile?seconds=5',30)
            name=f'engine-cpu-{len(cpu_windows):03d}.pprof';(root/name).write_bytes(payload)
            cpu_windows.append(dict(path=name,start_seconds=started-tick,end_seconds=time.monotonic()-tick,bytes=len(payload)))
        except Exception as error:errors.append('cpu-'+repr(error));return
def dump():
    with __import__('urllib.request',fromlist=['urlopen']).urlopen(debug+'wcprof/dump',timeout=60) as response:return response.read()
def drain():
    while not stop.wait(10):
        try:
            data=dump();name=f'chunk-{len(chunks):03d}.ndjson';(root/name).write_bytes(data);chunks.append(name)
        except Exception as error:errors.append(repr(error));return
metadata_record_before=get('metadata-snapshot-json')['record']
try:
    for route in routes:mode(route,True)
    get('metadata-snapshot-json?enabled=false&record=true&reset=true',b'')
    mode('collection-item-content',True)
    mode('evaluation-context',False)
    mode('coerced-method-hoisting',True)
    mode('lazy-eval-error-context',True)
    mode('shared-function-metadata',False)
    mode('shared-receiver-decode',False)
    mode('prepared-schema',True)
    mode('callback-caller-reuse',True)
    mode('interface-candidate-pruning',True)
    mode('metadata-snapshot-json',options.arm=='candidate')
    mode('interface-field-snapshots',False)
    assert get('receiver-preparation?enabled=true&reset=true',b'')['enabled']
    settings='[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n' if options.arm!='known' else ''
    (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n'+settings)
    edit.write_bytes(original+f'\n// Collection decomposition capture {time.time_ns()}\n'.encode())
    if options.edit_test_body:
        test.write_bytes(test_original+f'\n// Native test discovery body edit {time.time_ns()}\n'.encode())
    if options.add_test:
        assert options.arm!='known'
        test.write_bytes(test_original+f'\nfunc {test_name}(t *testing.T) {{}}\n'.encode())
    metadata=dict(arm=options.arm,command=command,module=str(module),fresh_source_edit=True,add_test=options.add_test,test_body_edit=options.edit_test_body,test_name=test_name if options.add_test else None,telemetry=True,ordinary_gc=True,wcprof=True,cpu_profile=options.cpu_profile,diagnostic_not_a_latency_comparison=True,engine_sha256=subprocess.check_output(['docker','exec',record['Id'],'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0],cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),flags_before=flags)
    (root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');(root/'driver.py').write_bytes(Path(__file__).read_bytes())
    get('wcprof/enabled',b'on');initial=json.loads(dump().split(b'\n',1)[0]);assert initial['dropped_events']==0
    drain_thread=threading.Thread(target=drain);drain_thread.start()
    (root/'prepared-declarations-before.json').write_text(json.dumps(get('reusable-declarations'),indent=2)+'\n')
    before=heap();before_cpu=cpu();gc_before=get('snapshot-collection');tick=time.monotonic()
    if options.cpu_profile:
        cpu_thread=threading.Thread(target=profile_cpu);cpu_thread.start()
    with (root/'command.stdout').open('w') as out,(root/'command.stderr').open('w') as err:
        process=subprocess.Popen(command,cwd=workspace,env=env,stdout=out,stderr=err,start_new_session=True)
        cancelled=False
        try:code=process.wait(timeout=240)
        except subprocess.TimeoutExpired:
            cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait()
    (root/'metadata-snapshot-stats.json').write_text(json.dumps(get('metadata-snapshot-json'),indent=2)+'\n')
    (root/'receiver-observations.json').write_text(json.dumps(get('receiver-preparation'),indent=2)+'\n')
    (root/'prepared-declarations-after.json').write_text(json.dumps(get('reusable-declarations'),indent=2)+'\n')
    get('upstream-log-queue',b'');seconds=time.monotonic()-tick;after=heap();after_cpu=cpu()
finally:
    stop.set()
    if drain_thread is not None:drain_thread.join()
    if cpu_thread is not None:cpu_thread.join()
    (root/'engine-cpu-windows.json').write_text(json.dumps(cpu_windows,indent=2)+'\n')
    get('wcprof/enabled',b'off')
    edit.write_bytes(original);test.write_bytes(test_original)
    for name,data in saved.items():
        if data is None:(workspace/name).unlink(missing_ok=True)
        else:(workspace/name).write_bytes(data)
    for route,enabled in flags.items():mode(route,enabled)
    get('metadata-snapshot-json?enabled='+str(flags['metadata-snapshot-json']).lower()+'&record='+str(metadata_record_before).lower(),b'')
    (root/'restoration.json').write_text(json.dumps(dict(source_restored=edit.read_bytes()==original,test_restored=test.read_bytes()==test_original,config_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items()),flags_after={r:get(r) for r in routes},wcprof=get('wcprof/enabled')),indent=2)+'\n')
deadline=time.monotonic()+90
while True:
    data=dump();name=f'chunk-{len(chunks):03d}.ndjson';(root/name).write_bytes(data);chunks.append(name)
    header=json.loads(data.split(b'\n',1)[0])
    if not header.get('open_ops'):break
    assert time.monotonic()<deadline,'wcprof operations did not finish'
    time.sleep(1)
headers=[];events=[]
for name in chunks:
    data=(root/name).read_bytes();lines=data.splitlines();h=json.loads(lines[0]);headers.append(h);events.extend(lines[1:])
    assert h['epoch_unix_nano']==header['epoch_unix_nano'] and h['strings']==header['strings'][:len(h['strings'])]
    assert h['dropped_events']==0
    compressed=gzip.compress(data,mtime=0);assert gzip.decompress(compressed)==data
    (root/(name+'.gz')).write_bytes(compressed);(root/name).unlink()
combined=dict(header,event_count=len(events))
(root/'wcprof-complete.ndjson').write_bytes((json.dumps(combined)+'\n').encode()+b'\n'.join(events)+b'\n')
expected=[tuple(line.split()[1:3]) for line in (base/'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
if options.add_test:expected.append(('dagql',test_name))
output=(root/'command.stdout').read_text()
if options.arm=='discovery':
    groups=json.loads(output)['go']['diagnosticPackages'];actual=[(g['path'],name) for g in groups for name in g['tests']['keys']]
else:actual=[tuple(line.split()[1:3]) for line in output.splitlines() if line.startswith('go ')]
result=dict(arm=options.arm,seconds=seconds,exit_code=code,cancelled=cancelled,rows=len(actual),same_names=sorted(actual)==sorted(expected),added_test_seen=('dagql',test_name) in actual,engine_cpu=after_cpu-before_cpu,heap_delta={k:after[k]-before[k] for k in before},recorder=dict(events=len(events),dropped=header['dropped_events'],open=len(header.get('open_ops',[])),chunks=len(chunks)),errors=errors,gc_before=gc_before,gc_after=get('snapshot-collection'))
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['arm','seconds','exit_code','rows','same_names','recorder']}),flush=True)
assert code==0 and not cancelled and result['same_names'] and not errors
