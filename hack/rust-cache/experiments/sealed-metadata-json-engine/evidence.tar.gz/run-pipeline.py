from pathlib import Path
import json
import subprocess
import sys
import time

p = Path(__file__).parent
assert json.loads((p/'engine-build.json').read_text())['exit_code'] == 0
resume = sys.argv[1] if len(sys.argv) > 1 else None
steps = json.loads((p/'pipeline-steps.json').read_text()) if resume else []
for label, script in [('start-engine','start-engine.py'), ('go-correctness','verify-module.py'),
                      ('rust-correctness','verify-rust.py'), ('timings','measure.py'),
                      ('profiles','capture-all.py'), ('analysis','analyze-all.py'),
                      ('final-state','finalize.py')]:
    if resume:
        if label != resume:
            continue
        resume = None
    command = [sys.executable, str(p/script)]
    tick = time.monotonic()
    with (p/(label+'-driver.log')).open('w') as out:
        result = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, seconds=time.monotonic()-tick, exit_code=result.returncode)
    steps.append(row)
    (p/'pipeline-steps.json').write_text(json.dumps(steps, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        print((p/(label+'-driver.log')).read_text()[-4000:], flush=True)
        raise SystemExit(result.returncode)
