from pathlib import Path

p = Path(__file__).parent.parent/'sealed-metadata-json-engine'
for f in p.glob('*.py'):
    if f.name == 'protocol-generator.py':
        continue
    text = f.read_text().replace('/dang-metadata-snapshot-json-engine/', '/sealed-metadata-json-engine/')
    if f.name == 'finalize.py':
        text = text.replace('experiments/telemetry-recovery-reader/final-state.json', 'experiments/dang-callback-direct-call-engine/final-state.json')
        needle = "for route,expected in plan['flags'].items():assert flags[route]['enabled']==expected,(route,flags[route],expected)"
        if "assert not flags['metadata-snapshot-json']['record']" not in text:
            text = text.replace(needle, needle+"\nassert not flags['metadata-snapshot-json']['record']")
    f.write_text(text)

f = p/'capture.py'
text = f.read_text()
if 'metadata_record_before=' not in text:
    needle = 'try:\n    for route in routes:mode(route,True)\n'
    assert text.count(needle) == 1
    text = text.replace(needle,"metadata_record_before=get('metadata-snapshot-json')['record']\n"+needle+"    get('metadata-snapshot-json?enabled=false&record=true&reset=true',b'')\n")
    needle = "    (root/'receiver-observations.json').write_text(json.dumps(get('receiver-preparation'),indent=2)+'\\n')\n"
    assert needle in text
    text = text.replace(needle,"    (root/'metadata-snapshot-stats.json').write_text(json.dumps(get('metadata-snapshot-json'),indent=2)+'\\n')\n"+needle)
    needle = '    for route,enabled in flags.items():mode(route,enabled)\n'
    assert needle in text
    text = text.replace(needle,needle+"    get('metadata-snapshot-json?enabled='+str(flags['metadata-snapshot-json']).lower()+'&record='+str(metadata_record_before).lower(),b'')\n")
f.write_text(text)
for name in ['measure-test-edits.py','measure-source-edits.py']:
    f = p/name
    text = f.read_text()
    needle = "assert not get('parallel-client-admission')['enabled']"
    if "assert not get('metadata-snapshot-unlocked')['enabled']" not in text:
        text = text.replace(needle,needle+"\nassert not get('metadata-snapshot-unlocked')['enabled']")
    needle = "assert not get('metadata-snapshot-unlocked')['enabled']"
    if "assert not get('metadata-snapshot-json')['record']" not in text:
        text = text.replace(needle,needle+"\nassert not get('metadata-snapshot-json')['record']")
    f.write_text(text)
for f in p.glob('*.py'):
    compile(f.read_text(), str(f), 'exec')
