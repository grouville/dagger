from pathlib import Path
import json

study = Path(__file__).parent
p = study.parent/'sealed-metadata-json-engine'
p.mkdir()
parent = study.parent/'interface-candidate-index-engine'
repo = Path('/tmp/dagger-filesync-snapshot-seeds')
standalone = Path('/tmp/dagger-sealed-metadata-json')
overlay = json.loads((parent/'overlay.json').read_text())
replace = overlay['Replace']

key = str(repo/'engine/server/session.go')
text = Path(replace[key]).read_text()
needle = '\tmetadataSealed bool\n'
assert text.count(needle)==1
fields = '''\t// Sealed metadata is immutable. Cache its wire encoding, while every
\t// lookup still decodes an independent copy for its caller.
\tmetadataJSONOnce sync.Once
\tmetadataJSON     []byte
\tmetadataJSONErr  error
'''
(p/'session.go').write_text(text.replace(needle,needle+fields))
replace[key] = str(p/'session.go')

key = str(repo/'engine/server/client_scope.go')
text = Path(replace[key]).read_text()
candidate = (standalone/'engine/server/client_scope.go').read_text()
start = text.index('func cloneClientMetadata(')
end = text.index('// mergeClientMetadataLocked',start)
cs = candidate.index('func cloneClientMetadata(')
ce = candidate.index('// mergeClientMetadataLocked',cs)
text = text[:start]+candidate[cs:ce]+text[end:]
needle = 'func (sess *daggerSession) clientMetadataSnapshot(record *clientRecord) (*engine.ClientMetadata, error) {\n'
assert text.count(needle)==1
text = text.replace(needle,needle+'\tif metadataSnapshotJSONEnabled.Load() { return sess.clientMetadataSnapshotJSON(record) }\n')
cs = candidate.index(needle);ce = candidate.index('\nfunc (sess *daggerSession) closeNestedClientTransport',cs)
method = candidate[cs:ce].replace('clientMetadataSnapshot(record','clientMetadataSnapshotJSON(record',1)
needle = '\t\trecord.metadataJSON, record.metadataJSONErr = json.Marshal(metadata)\n'
assert method.count(needle)==1
method = method.replace(needle,needle+'\t\tif metadataSnapshotJSONRecord.Load() { metadataSnapshotJSONEncodings.Add(1); metadataSnapshotJSONBytes.Add(int64(len(record.metadataJSON))) }\n')
(p/'client_scope.go').write_text(text+'\n'+method)
replace[key] = str(p/'client_scope.go')

(p/'mode.go').write_text('''package server
import (
 "encoding/json"
 "net/http"
 "os"
 "strconv"
 "sync/atomic"
)
var metadataSnapshotJSONEnabled atomic.Bool
var metadataSnapshotJSONRecord atomic.Bool
var metadataSnapshotJSONEncodings atomic.Int64
var metadataSnapshotJSONBytes atomic.Int64
func init() { metadataSnapshotJSONEnabled.Store(os.Getenv("DAGGER_TEST_SEALED_METADATA_JSON") == "on") }
func MetadataSnapshotJSONDiagnostic(w http.ResponseWriter, r *http.Request) {
 if r.Method == http.MethodPost {
  enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
  if err != nil { http.Error(w,err.Error(),http.StatusBadRequest); return }
  metadataSnapshotJSONEnabled.Store(enabled)
  if flag := r.URL.Query().Get("record"); flag != "" {
   record, err := strconv.ParseBool(flag)
   if err != nil { http.Error(w,err.Error(),http.StatusBadRequest); return }
   metadataSnapshotJSONRecord.Store(record)
  }
  if r.URL.Query().Get("reset") == "true" { metadataSnapshotJSONEncodings.Store(0); metadataSnapshotJSONBytes.Store(0) }
 } else if r.Method != http.MethodGet { http.Error(w,"GET or POST required",http.StatusMethodNotAllowed); return }
 w.Header().Set("Content-Type","application/json")
 _ = json.NewEncoder(w).Encode(map[string]any{"enabled":metadataSnapshotJSONEnabled.Load(),"record":metadataSnapshotJSONRecord.Load(),"encodings":metadataSnapshotJSONEncodings.Load(),"encoded_bytes":metadataSnapshotJSONBytes.Load()})
}
''')
replace[str(repo/'engine/server/metadata_snapshot_json_mode.go')] = str(p/'mode.go')
key = str(repo/'cmd/engine/debug.go');text = Path(replace[key]).read_text()
needle = '\tm.HandleFunc("/debug/metadata-snapshot-unlocked", server.MetadataSnapshotUnlockedDiagnostic)\n'
assert text.count(needle)==1
(p/'engine-debug.go').write_text(text.replace(needle,needle+'\tm.HandleFunc("/debug/metadata-snapshot-json", server.MetadataSnapshotJSONDiagnostic)\n'))
replace[key] = str(p/'engine-debug.go')
(p/'metadata_json_test.go').write_bytes((standalone/'engine/server/metadata_json_test.go').read_bytes())
replace[str(repo/'engine/server/metadata_json_test.go')] = str(p/'metadata_json_test.go')
(p/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')

# Reuse the verified full-pipeline protocol, changing only the engine and toggle.
protocol = (study.parent/'dang-positional-callback/prepare-engine.py').read_text()
protocol = protocol[protocol.index("plan = json.loads((parent/'engine-plan.json').read_text())"):]
protocol = protocol.replace('dagger-collection-direct-callback-oct19','dagger-collection-metadata-json-oct19').replace('16283','16284').replace('16111','16112')
protocol = protocol.replace('callback-direct-call','metadata-snapshot-json').replace('callback_direct_call','metadata_snapshot_json')
protocol = protocol.replace('callback-direct-call-pipeline','metadata-snapshot-json-pipeline')
protocol = protocol.replace('Only concrete native callback dispatch changes. Indexed interface matching, caller reuse, getter logic, module source, telemetry and cleanup are common to both arms. The recovery-reader experiment is absent.', 'Only sealed metadata JSON reuse changes. Independent snapshots, metadata sealing, permissions, indexed matching, caller reuse, getter logic, module source, telemetry and cleanup remain. The callback-dispatch and recovery-reader experiments are absent; clone-unlocked mode stays off.')
exec(compile(protocol,str(p/'protocol-generator.py'),'exec'))
(p/'protocol-generator.py').write_text(protocol)
# Keep the seventh engine untouched as well as the six earlier engines.
text = (p/'start-engine.py').read_text()
needle = "('dagger-collection-receiver-decode-oct18','3d1c4deeef3ca394ac64302263ff1d9a30b4b6e18c740ecb5b9d55ef64a784b1'),"
sha = json.loads((study.parent/'dang-callback-direct-call-engine/engine-build.json').read_text())['sha256']
text = text.replace(needle,"('dagger-collection-direct-callback-oct19','"+sha+"'),"+needle)
(p/'start-engine.py').write_text(text)
for name in ['measure-test-edits.py','measure-source-edits.py','capture.py']:
    text = (p/name).read_text()
    needle = "assert not get('parallel-client-admission')['enabled']"
    assert needle in text
    (p/name).write_text(text.replace(needle,needle+"\nassert not get('metadata-snapshot-unlocked')['enabled']"))
print('Prepared cached sealed-metadata encoding on an eighth isolated engine; all seven existing engines retained.')

exec(compile((study/"rewrite-protocols.py").read_text(), str(study/"rewrite-protocols.py"), "exec"))
