package server

import (
	"fmt"
	"reflect"
	"strings"
	"sync"
	"testing"

	controlapi "github.com/dagger/dagger/internal/buildkit/api/services/control"
	"github.com/dagger/dagger/engine"
	"github.com/stretchr/testify/require"
)

func TestSealedMetadataConcurrentSnapshots(t *testing.T) {
	workspace := "github.com/acme/project@main"
	metadata := &engine.ClientMetadata{
		ClientID: "client", ClientSecretToken: "test-token", SessionID: "session",
		Labels: map[string]string{"branch": "main"},
		InteractiveCommand: []string{"sh", "-l"}, AllowedLLMModules: []string{"example/module"},
		UpstreamCacheImportConfig: []*controlapi.CacheOptionsEntry{{Type: "registry", Attrs: map[string]string{"ref": "example/cache"}}},
		ExtraModules: []engine.ExtraModule{{Name: "extra", Ref: "example/extra@v1"}},
		Workspace: &workspace, UseRecipeIDsByDefault: true,
	}
	session := &daggerSession{}
	record := &clientRecord{clientID: metadata.ClientID, clientMetadata: metadata, accepting: true}
	session.scopeMu.Lock()
	err := session.sealClientMetadataLocked(record)
	session.scopeMu.Unlock()
	require.NoError(t, err)
	want, err := cloneClientMetadata(record.clientMetadata)
	require.NoError(t, err)

	var wg sync.WaitGroup
	for range 64 {
		wg.Go(func() {
			got, err := session.clientMetadataSnapshot(record)
			if err != nil {
				t.Error(err)
				return
			}
			if !reflect.DeepEqual(want, got) {
				t.Error("snapshot differs from the JSON round-trip clone")
				return
			}
			got.Labels["branch"] = "changed"
			got.InteractiveCommand[0] = "changed"
			got.AllowedLLMModules[0] = "changed"
			got.UpstreamCacheImportConfig[0].Attrs["ref"] = "changed"
			got.ExtraModules[0].Ref = "changed"
			*got.Workspace = "changed"
		})
	}
	wg.Wait()
	got, err := session.clientMetadataSnapshot(record)
	require.NoError(t, err)
	require.Equal(t, want, got)
}

func BenchmarkClientMetadataSnapshot(b *testing.B) {
	for _, labels := range []int{0, 32} {
		metadata := &engine.ClientMetadata{ClientID: "client", SessionID: "session", UseRecipeIDsByDefault: true}
		if labels > 0 {
			metadata.Labels = make(map[string]string, labels)
			for i := range labels {
				metadata.Labels[fmt.Sprintf("label%d", i)] = strings.Repeat("x", 64)
			}
		}
		for _, mode := range []string{"first", "serial", "parallel"} {
			b.Run(fmt.Sprintf("%s/labels=%d", mode, labels), func(b *testing.B) {
				session := &daggerSession{}
				record := &clientRecord{clientID: metadata.ClientID, clientMetadata: metadata, metadataSealed: true}
				if _, err := session.clientMetadataSnapshot(record); err != nil {
					b.Fatal(err)
				}
				b.ReportAllocs()
				b.ResetTimer()
				if mode == "parallel" {
					b.RunParallel(func(pb *testing.PB) {
						for pb.Next() {
							got, err := session.clientMetadataSnapshot(record)
							if err != nil || !got.UseRecipeIDsByDefault || len(got.Labels) != labels {
								b.Errorf("snapshot: %v", err)
								return
							}
						}
					})
					return
				}
				for b.Loop() {
					current := record
					if mode == "first" {
						current = &clientRecord{clientID: metadata.ClientID, clientMetadata: metadata, metadataSealed: true}
					}
					got, err := session.clientMetadataSnapshot(current)
					if err != nil || !got.UseRecipeIDsByDefault || len(got.Labels) != labels {
						b.Fatalf("snapshot: %v", err)
					}
				}
			})
		}
	}
}
