from pathlib import Path
import hashlib, json, subprocess
p=Path(__file__).parent

def write(path,value):
 path.write_text(json.dumps(value,indent=2)+'\n')

def sha(data):
 return hashlib.sha256(data).hexdigest()

j=json.loads((p/'assessment.json').read_text())
j.update(selected=False,reason='The complete-command differences are small and mixed, and the source-only CPU does not fall. The added per-record encoding cache is not justified by these measurements.',conditions='Real source and test edits, fresh CLI processes, warm isolated engine. Normal telemetry, GC, final output and session cleanup included. Four balanced measured pairs per workload after both modes complete a test-layout transition.',not_established=['Cold listing on the current engine','Retained-cache restart performance','Rust compilation or collection latency','Whether encoding memoization is preferable to a smaller lock-scope change'])
checks=json.loads((p/'checks.json').read_text());assert len(checks)==18 and all(r['exit_code']==0 for r in checks)
rust=json.loads((p/'rust-pipeline/results.json').read_text());assert len(rust)==28 and all(not r['cancelled'] and (r['exit_code']==0)==(r['expected']==0) for r in rust)
j['functional_gates']={'go_commands':len(checks),'rust_native_cache_cases':len(rust),'expected_results':True,'full_exact_overlay_server_race_suite_passed':True,'independent_snapshot_mutation_test_passed_under_race':True}
j['profile_checks']=[]
for name in ['capture-before','capture-candidate','capture-root-before','capture-root-candidate','locks-before','locks-candidate']:
 a=json.loads((p/name/'attribution.json').read_text()); r=json.loads((p/name/'result.json').read_text()); assert r['exit_code']==0 and r['rows']==4398 and r['same_names'] and a['dropped']==0 and a['open_ops']==0
 selected=a['selected_calls'];row={'capture':name,'seconds':r['seconds'],'function_evaluations':a['function_evaluations'],'getters':selected['go:GoPackages.get'],'discoveries':selected['go:GoPackage.tests'],'events':a['events'],'dropped':0,'open':0}
 if name in ['capture-before','capture-candidate']:
  assert selected['go:GoPackages.get']=={'executed':800};assert selected['go:GoPackage.tests']=={'hit':799,'executed':1}
 if name.endswith('candidate'):
  row['metadata_encoding']=json.loads((p/name/'metadata-snapshot-stats.json').read_text());assert row['metadata_encoding']['encodings']==2 and row['metadata_encoding']['encoded_bytes']==2226
 j['profile_checks'].append(row)
j['lock_diagnostic']={'profile':'after minus before, Go mutex sampling fraction 10; block rate 1ms','aggregate_mutex_wait_seconds':{'before':121,'candidate':72.14},'baseline_client_metadata_snapshot_inclusive_wait_seconds':56.19,'whole_command_seconds':{n:json.loads((p/('locks-'+n)/'result.json').read_text())['seconds'] for n in ['before','candidate']},'warning':'Aggregate goroutine wait is not elapsed time. These instrumented commands are not the unprofiled paired cohort.'}
j['retained_attempts']={'exact_overlay_test':'Initial run omitted the parallel-admission test flag required by an existing virtual test. The failed log and corrected successful run are retained. Runtime admission stays disabled.','capture':'One candidate capture was rejected before CLI launch by the unchanged idle gate because host I/O pressure was high. Initial attempt, host/engine inspection, and the later successful capture are retained.'}
write(p/'assessment.json',j)
standalone=Path('/tmp/dagger-sealed-metadata-json');dest=p/'standalone';dest.mkdir(exist_ok=True)
patch=subprocess.check_output(['git','diff','--binary','--','engine/server/client_scope.go','engine/server/session.go'],cwd=standalone)
(dest/'candidate.patch').write_bytes(patch)
for f in ['engine/server/client_scope.go','engine/server/session.go','engine/server/metadata_json_test.go']:
 out=dest/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((standalone/f).read_bytes())
write(dest/'identity.json',{'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=standalone,text=True).strip(),'patch_sha256':sha(patch),'new_test_separate_from_patch':'engine/server/metadata_json_test.go','candidate_not_selected':True})
print(json.dumps({'selected':False,'functional_go':len(checks),'functional_rust':len(rust),'lossless_profiles':len(j['profile_checks'])}),flush=True)
