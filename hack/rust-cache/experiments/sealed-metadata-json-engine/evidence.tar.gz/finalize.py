from pathlib import Path
import hashlib,json,subprocess,urllib.request
p=Path(__file__).parent
previous=json.loads(Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/dang-callback-direct-call-engine/final-state.json').read_text())
def get(route):
 with urllib.request.urlopen('http://127.0.0.1:16112/debug/'+route,timeout=15) as f:return json.load(f)
binaries={}
for name,expected in previous['binaries'].items():
 binaries[name]=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
 assert binaries[name]==expected,(name,binaries[name],expected)
plan=json.loads((p/'engine-plan.json').read_text())
flags={route:get(route) for route in plan['flags']}
for route,expected in plan['flags'].items():assert flags[route]['enabled']==expected,(route,flags[route],expected)
assert not flags['metadata-snapshot-json']['record']
lifecycle=get('client-lifecycle')
assert lifecycle['active_requests']==0 and lifecycle['runtimes']==0
assert all(s['state']=='removed' for s in (lifecycle.get('sessions') or []))
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
real=Path('/tmp/dagger-go-real-repository-main')
assert subprocess.check_output(['git','status','--porcelain'],cwd=real)==b''
assert subprocess.check_output(['git','status','--porcelain'],cwd='/tmp/dagger-go-indexed-owner-facts')==b''
new_name=plan['new_engine']
new_sha=subprocess.check_output(['docker','exec',new_name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
assert new_sha==json.loads((p/'engine-build.json').read_text())['sha256']
binaries[new_name]=new_sha
volumes={}
for name in binaries:
 record=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
 volumes[name]=[dict(name=m.get('Name'),destination=m['Destination']) for m in record['Mounts'] if m['Type']=='volume']
state=dict(volumes=volumes,binaries=binaries,flags=flags,lifecycle=lifecycle,wcprof=get('wcprof/enabled'),lock_profiler=get('lock-profiler'),real_workspace_clean=True,baseline_module_clean=True,engine_cache_retained=True,engine_candidate_installed=True,new_pr_opened=False)
(p/'final-state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(dict(binaries=binaries,active_requests=lifecycle['active_requests'],runtimes=lifecycle['runtimes'],all_original_flags_restored=True,real_workspace_clean=True)),flush=True)
