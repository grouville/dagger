from pathlib import Path
import json
import shutil
import subprocess
import time

p = Path(__file__).parent
failed = p/'initial-admission-timeout'
failed.mkdir()
shutil.move(str(p/'capture-candidate'),str(failed/'capture-candidate'))
shutil.copy2(p/'capture-candidate-driver.log',failed/'capture-candidate-driver.log')
shutil.copy2(p/'capture-steps.json',failed/'capture-steps.json')
rows = json.loads((p/'capture-steps.json').read_text())
for label, arm, test_edit in [('candidate','candidate',True),('root-before','before',False),('root-candidate','candidate',False)]:
    command = ['python3',str(p/'capture.py'),'--arm',arm,'--output',str(p/('capture-'+label)),'--cpu-profile']+(['--edit-test-body'] if test_edit else [])
    tick = time.monotonic()
    with (p/('capture-'+label+'-driver.log')).open('w') as out:
        result = subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
    row = dict(label=label,arm=arm,test_edit=test_edit,command=command,seconds=time.monotonic()-tick,exit_code=result.returncode)
    rows.append(row)
    (p/'capture-steps.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if result.returncode:
        print((p/('capture-'+label+'-driver.log')).read_text()[-2500:],flush=True)
        raise SystemExit(result.returncode)
for script in ['analyze-all.py','finalize.py']:
    result = subprocess.run(['python3',str(p/script)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (p/(script+'.resume.log')).write_text(result.stdout)
    assert result.returncode==0,result.stdout[-2500:]
print('Resumed captures, attribution and final state verified.',flush=True)
