package server

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var metadataSnapshotJSONEnabled atomic.Bool
var metadataSnapshotJSONRecord atomic.Bool
var metadataSnapshotJSONEncodings atomic.Int64
var metadataSnapshotJSONBytes atomic.Int64

func init() { metadataSnapshotJSONEnabled.Store(os.Getenv("DAGGER_TEST_SEALED_METADATA_JSON") == "on") }
func MetadataSnapshotJSONDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		metadataSnapshotJSONEnabled.Store(enabled)
		if flag := r.URL.Query().Get("record"); flag != "" {
			record, err := strconv.ParseBool(flag)
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			metadataSnapshotJSONRecord.Store(record)
		}
		if r.URL.Query().Get("reset") == "true" {
			metadataSnapshotJSONEncodings.Store(0)
			metadataSnapshotJSONBytes.Store(0)
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": metadataSnapshotJSONEnabled.Load(), "record": metadataSnapshotJSONRecord.Load(), "encodings": metadataSnapshotJSONEncodings.Load(), "encoded_bytes": metadataSnapshotJSONBytes.Load()})
}
