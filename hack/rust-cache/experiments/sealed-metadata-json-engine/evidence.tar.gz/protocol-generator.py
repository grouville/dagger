plan = json.loads((parent/'engine-plan.json').read_text())
plan.update(new_engine='dagger-collection-metadata-json-oct19',ports={'runner':16284,'debug':16112},
            scenario='Only sealed metadata JSON reuse changes. Independent snapshots, metadata sealing, permissions, indexed matching, caller reuse, getter logic, module source, telemetry and cleanup remain. The callback-dispatch and recovery-reader experiments are absent; clone-unlocked mode stays off.')
plan['flags']['metadata-snapshot-json'] = False
(p/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def common(text):
    return text.replace('dagger-collection-interface-index-oct18','dagger-collection-metadata-json-oct19').replace(':16109',':16112').replace(':16281',':16284').replace('/interface-candidate-index-engine/','/dang-metadata-snapshot-json-engine/')
for name in ['verify-module.py','verify-rust.py','measure-test-edits.py','measure-source-edits.py','capture.py']:
    text = common((parent/name).read_text())
    text = text.replace("'interface-field-snapshots']", "'interface-field-snapshots','metadata-snapshot-json']")
    text = text.replace("mode('interface-candidate-pruning',arm=='combined')", "mode('interface-candidate-pruning',True)\n            mode('metadata-snapshot-json',arm=='combined')")
    text = text.replace("mode('interface-candidate-pruning',options.arm=='candidate')", "mode('interface-candidate-pruning',True)\n    mode('metadata-snapshot-json',options.arm=='candidate')")
    text = text.replace("get('interface-candidate-pruning?enabled='+str(arm=='candidate').lower(),b'')", "get('interface-candidate-pruning?enabled=true',b'')\n  get('metadata-snapshot-json?enabled='+str(arm=='candidate').lower(),b'')")
    text = text.replace('interface-candidate-index-pipeline-oct18','metadata-snapshot-json-pipeline-oct19')
    text = text.replace("indexed_interface_matching=arm=='combined'", "indexed_interface_matching=True,metadata_snapshot_json=arm=='combined'")
    if name.startswith('measure-'):
        begin = 'Complete getter-preserving listing on one isolated engine: original structural interface matching versus the indexed algorithm.'
        start = text.index(begin);end = text.index("',orders=",start)
        text = text[:start]+plan['scenario']+' Both arms initialize test addition and removal before four balanced pairs; a fresh CLI and real edit on a warm engine, with ordinary GC and final cleanup included.'+text[end:]
    (p/name).write_text(text);compile(text,str(p/name),'exec')
text = common((parent/'start-engine.py').read_text())
needle = "('dagger-collection-receiver-decode-oct18','3d1c4deeef3ca394ac64302263ff1d9a30b4b6e18c740ecb5b9d55ef64a784b1'),";assert needle in text
text = text.replace(needle,"('dagger-collection-interface-index-oct18','0df377c84e39ae7f85914fa1eb6b8eeb425c7e50454cb55db8e4742db5c8e856'),('dagger-collection-recovery-reader-oct19','620a8bb52a9cce36604a9c5089453a8eada0f50c5a6f2e7653eb073004fedaa6'),"+needle)
(p/'start-engine.py').write_text(text)
for name in ['measure.py','capture-all.py','rust-cache-query.py','analyze.py','analyze-all.py']:
    text = common((parent/name).read_text())
    if name=='analyze-all.py':text=text.replace("for arm in ['before','candidate']:","for arm in ['before','candidate','root-before','root-candidate']:")
    (p/name).write_text(text)
text = (study.parent/'telemetry-recovery-reader/finalize.py').read_text().replace(':16110',':16112').replace('experiments/interface-candidate-index-engine/final-state.json','experiments/telemetry-recovery-reader/final-state.json')
(p/'finalize.py').write_text(text)
for name in ['engine.go.mod','engine.go.sum']:(p/name).write_bytes((parent/name).read_bytes())
print('Prepared isolated engine protocols with only native callback dispatch toggled.')
