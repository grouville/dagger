from pathlib import Path
import json,os,subprocess,time,urllib.request,signal
p=Path(__file__).parent;base=p.parent;debug='http://127.0.0.1:16112/debug/'
repo=Path('/tmp/dagger-go-indexed-owner-facts');source=repo/'.dagger/modules/go-dev/main.dang';original=source.read_bytes()
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=15) as f:return json.load(f)
routes=['collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata','shared-receiver-decode','prepared-schema','callback-caller-reuse','interface-candidate-pruning','interface-field-snapshots','metadata-snapshot-json']
flags={r:get(r)['enabled'] for r in routes};assert not get('wcprof/enabled')['global_enabled']
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16284',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows=[]
try:
 for route in routes:get(route+'?enabled='+str(route not in ['shared-function-metadata','shared-receiver-decode','interface-candidate-pruning','interface-field-snapshots','metadata-snapshot-json']).lower(),b'')
 for arm in ['before','candidate']:
  get('interface-candidate-pruning?enabled=true',b'')
  get('metadata-snapshot-json?enabled='+str(arm=='candidate').lower(),b'')
  source.write_bytes(original+f'\n# Interface-index checker freshness {arm} {time.time_ns()}\n'.encode())
  for name in ['go-dev:package-owner-index-check','go-dev:package-owner-settings-check','go-dev:collection-check','go-dev:test-snapshot-directories-check','go-dev:discovery-check','go-dev:package-layout-rebind-check','go-dev:tests-collection-check','go-dev:binary-check','go-dev:generate-check']:
   tick=time.monotonic();label=arm+'-'+name.replace(':','-')
   with (p/(label+'.log')).open('w') as out:
    process=subprocess.Popen(['python3',str(base/'local_cli_collector.py'),'check',name],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
    try:code=process.wait(timeout=300)
    except subprocess.TimeoutExpired:
     os.killpg(process.pid,signal.SIGINT);code=process.wait(timeout=60)
   class Result:pass
   r=Result();r.returncode=code
   row=dict(arm=arm,check=name,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
   if r.returncode:print((p/(label+'.log')).read_text()[-3500:]);raise SystemExit(r.returncode)
finally:
 source.write_bytes(original)
 for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
 (p/'checks-restoration.json').write_text(json.dumps(dict(checker_restored=source.read_bytes()==original,flags_after={r:get(r) for r in routes},lifecycle=get('client-lifecycle')),indent=2)+'\n')
