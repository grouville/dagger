from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
p=Path(__file__).parent
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/sealed-metadata-json-engine')
out.mkdir(parents=True,exist_ok=False)
parent=p.parent/'interface-candidate-index-engine'
parent_out=out.parent/'interface-candidate-index-engine'
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def ignore(directory,names):
 return [n for n in names if n in {'__pycache__','.git','dagger-engine','reproduced-dagger-engine','wcprof-complete.ndjson','archive-driver.log'} or n.endswith('.test')]
for name in ['sealed-metadata-json','go-glob-critical-path']:
 shutil.copytree(p.parent/name,p/'antecedents'/name,ignore=ignore)
# Parent archive contains the complete checked and reproduced engine source tree.
parent_metadata=json.loads((parent_out/'archive.json').read_text())
assert sha((parent_out/'evidence.tar.gz').read_bytes())==parent_metadata['sha256']
write(p/'parent-source-archive.json',dict(path='../interface-candidate-index-engine/evidence.tar.gz',**parent_metadata))
overlay=json.loads((p/'overlay.json').read_text())['Replace']
old=json.loads((parent/'build-source-manifest.json').read_text())
source_rows=[];seen=set()
for index,row in enumerate(old):
 original=row['original'];seen.add(original);actual=Path(overlay.get(original,row['actual']));data=actual.read_bytes()
 entry=dict(original=original,actual=str(actual),bytes=len(data),sha256=sha(data))
 if entry['sha256']==row['sha256']:
  entry['parent_archived']=row['archived']
 else:
  target=p/'source-delta'/str(index)/actual.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);entry['archived']=str(target.relative_to(p))
 source_rows.append(entry)
for original,actual in overlay.items():
 if original in seen:continue
 actual=Path(actual);data=actual.read_bytes();target=p/'source-delta'/('overlay-'+str(len(source_rows)))/actual.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 source_rows.append(dict(original=original,actual=str(actual),bytes=len(data),sha256=sha(data),archived=str(target.relative_to(p))))
write(p/'build-source-manifest.json',source_rows)
modules={}
for name,repo in [('go','/tmp/dagger-go-indexed-owner-facts'),('rust','/tmp/dagger-rust-test-collection-granularity')]:
 files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');rows=[]
 for rel in filter(None,files):
  source=Path(repo)/rel
  if not source.is_file():continue
  target=p/'module-source'/name/rel;target.parent.mkdir(parents=True,exist_ok=True);data=source.read_bytes();target.write_bytes(data);rows.append(dict(path=rel,bytes=len(data),sha256=sha(data)))
 modules[name]=dict(path=repo,commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),files=rows)
write(p/'module-identities.json',modules)
reconstruction=[]
for complete in sorted(p.rglob('wcprof-complete.ndjson')):
 folder=complete.parent;events=[];chunks=sorted(folder.glob('chunk-*.ndjson.gz'));assert chunks
 for chunk in chunks:
  with gzip.open(chunk,'rb') as stream:
   header=json.loads(stream.readline());events.extend(stream.readlines())
  assert header['dropped_events']==0
 header['event_count']=len(events);rebuilt=(json.dumps(header)+'\n').encode()+b''.join(events);assert rebuilt==complete.read_bytes(),folder
 reconstruction.append(dict(capture=str(folder.relative_to(p)),chunks=[c.name for c in chunks],events=len(events),sha256=sha(rebuilt),exact_bytes_verified=True))
# The antecedent stream was excluded during copy: verify against its original.
a=p.parent/'go-glob-critical-path/source-locks';events=[];chunks=sorted(a.glob('chunk-*.ndjson.gz'))
for chunk in chunks:
 with gzip.open(chunk,'rb') as stream:header=json.loads(stream.readline());events.extend(stream.readlines())
 assert header['dropped_events']==0
header['event_count']=len(events);rebuilt=(json.dumps(header)+'\n').encode()+b''.join(events);assert rebuilt==(a/'wcprof-complete.ndjson').read_bytes()
reconstruction.append(dict(capture='antecedents/go-glob-critical-path/source-locks',chunks=[c.name for c in chunks],events=len(events),sha256=sha(rebuilt),exact_bytes_verified=True))
assert len(reconstruction)==7
write(p/'wcprof-reconstruction.json',reconstruction)
files=[f for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and '.git' not in f.parts and f.name not in {'dagger-engine','reproduced-dagger-engine','wcprof-complete.ndjson','archive-driver.log'} and f.suffix!='.test']
manifest=[dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files]
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();archive=out/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(p)));info.mtime=0
  with f.open('rb') as src:tar.addfile(info,src)
 info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mtime=0;tar.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  payload=tar.extractfile(row['path']).read();assert len(payload)==row['bytes'] and sha(payload)==row['sha256']
(out/'manifest.json').write_bytes(manifest_bytes)
for name in ['assessment.json','engine-build.json','parent-source-archive.json','build-source-manifest.json','final-state.json','wcprof-reconstruction.json']:
 (out/name).write_bytes((p/name).read_bytes())
metadata=dict(bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(files)+1,all_member_hashes_verified=True,binaries_excluded=True,lossless_streams_reconstructed=len(reconstruction),source_rows=len(source_rows),source_delta_rows=sum('archived' in x for x in source_rows))
write(out/'archive.json',metadata);print(json.dumps(metadata),flush=True)
