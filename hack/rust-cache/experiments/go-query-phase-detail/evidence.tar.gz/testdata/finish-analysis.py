from pathlib import Path
import subprocess,json,time
p=Path(__file__).parent
rows=[]
for name in ['analyze.py','analyze-forensics.py']:
 tick=time.monotonic()
 with (p/(name+'.corrected.log')).open('w') as out:r=subprocess.run(['python3',str(p/name)],stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(script=name,exit_code=r.returncode,seconds=time.monotonic()-tick));(p/'analysis-completion.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert r.returncode==0,(p/(name+'.corrected.log')).read_text()[-5000:]
