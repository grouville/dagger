from pathlib import Path
import json
import os
import subprocess

p = Path(__file__).parent / 'capture'
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
engine = str(Path(__file__).parent / 'dagger-engine')
profiles = [str(p / row['path']) for row in json.loads((p / 'engine-cpu-windows.json').read_text())]
rows = []
for label, flags, sources in [
    ('cpu-preselect', ['-cum', '-focus=preselect'], profiles),
    ('cpu-telemetry', ['-cum', '-focus=AroundFunc'], profiles),
    ('mutex-preselect', ['-cum', '-focus=preselect', '-sample_index=delay', '-base', str(p / 'engine-mutex-before.pprof')], [str(p / 'engine-mutex-after.pprof')]),
    ('cpu-result-reference', ['-cum', '-focus=resultCallRefFromResult'], profiles),
]:
    command = [go, 'tool', 'pprof', '-top', '-nodecount=50', *flags, engine, *sources]
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, env=dict(os.environ, GOTOOLCHAIN='local', GOWORK='off'))
    rows.append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0
(p / 'focus-validation.json').write_text(json.dumps(rows, indent=2) + '\n')
