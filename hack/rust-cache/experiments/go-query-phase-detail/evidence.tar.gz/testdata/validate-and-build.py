from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
baseline = json.loads((p / 'baseline-stale-assertion.json').read_text())
assert baseline['exit_code'] == baseline['expected_exit_code'] == 1
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
command = [go, 'test', '-p', '2', '-buildvcs=false', '-modfile',
           '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
           '-overlay', str(p / 'engine-overlay.json'), '-race', '-count=1', './dagql']
tick = time.monotonic()
with (p / 'dagql-race-corrected.log').open('w') as output:
    result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds', env=env,
                            stdout=output, stderr=subprocess.STDOUT)
record = dict(command=command, exit_code=result.returncode, seconds=time.monotonic()-tick,
              scope='Full DagQL race suite, using the previously maintained exact result-ID lock-label assertion.',
              initial_failure_retained='validation-initial.json', baseline_reproduction='baseline-stale-assertion.json')
(p / 'validation.json').write_text(json.dumps(record, indent=2) + '\n')
print('full DagQL race suite:', result.returncode, flush=True)
assert result.returncode == 0, (p / 'dagql-race-corrected.log').read_text()[-5000:]
with (p / 'build-driver.log').open('w') as output:
    result = subprocess.run(['python3', str(p / 'build-engine.py')], env=env,
                            stdout=output, stderr=subprocess.STDOUT)
print('retained histories and engine build:', result.returncode, flush=True)
assert result.returncode == 0, (p / 'build-driver.log').read_text()[-5000:]
