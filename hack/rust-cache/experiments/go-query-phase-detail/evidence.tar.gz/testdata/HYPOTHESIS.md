# Attribute query execution outside the existing field spans

The current selected full listing takes about 38 seconds unprofiled. A separate lossless capture places 11.44 seconds on its critical path in response execution outside recorded children, plus 5.91 waiting for the session lifecycle lock. Source inspection shows preselection precedes the field span, and operation-lease cleanup follows it.

Add request-owned child markers for AST selection parsing, field preparation, invocation, output instantiation, field resolution, operation validation, JSON response encoding and lease cleanup. Preserve arguments, callbacks, ownership, cancellation, errors and execution paths. Normal unprofiled contexts are returned unchanged by wcprof.BeginOp. Run the DagQL race suite, build the controlled engine, preserve the volume through graceful replacement, and verify all six native histories on the first calls afterward. One separately profiled fresh-edited listing must return the same 4398 ordered rows and exit successfully, with zero dropped or open operations. This is attribution, not a latency comparison.

Do not rerun rejected prepared-schema, interface, admission, telemetry or allocation configurations unchanged. Choose the next implementation change only after these markers explain the response cost.
