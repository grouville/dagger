from collections import Counter, defaultdict
from pathlib import Path
import json

p = Path(__file__).parent / 'capture'
ops = {}
children = defaultdict(list)
with (p / 'wcprof-complete.ndjson').open() as stream:
    header = json.loads(next(stream))
    names = header['strings']
    for line in stream:
        event = json.loads(line)
        if event['e'] == 'op':
            event['cls'] = names[event['c']]
            ops[event['id']] = event
            children[event.get('p', 0)].append(event)
assert header['dropped_events'] == 0 and not header.get('open_ops')
counts = Counter()
violations = []
for api in (event for event in ops.values() if event['cls'] == 'dang.apiRequest'):
    serves = [event for event in children[api['id']] if event['cls'] == 'session.serveQuery']
    admits = [event for event in children[api['id']] if event['cls'] == 'session.clientAdmission']
    counts['api'] += 1
    if len(serves) != 1 or len(admits) != 1:
        counts['non_unique_children'] += 1
        continue
    serve, admit = serves[0], admits[0]
    tests = dict(api_started_before_admission=api['s'] <= admit['s'],
                 admission_finished_before_query=admit['d'] <= serve['s'],
                 query_finished_before_api=serve['d'] <= api['d'])
    for name, passed in tests.items():
        counts[name + ('_pass' if passed else '_fail')] += 1
    if not all(tests.values()):
        violations.append(dict(api_id=api['id'], admission_id=admit['id'], serve_id=serve['id'],
                               tests=tests, api_seconds=(api['d']-api['s'])/1e9,
                               query_seconds=(serve['d']-serve['s'])/1e9,
                               backend_end_after_client_ns=serve['d']-api['d']))
result = dict(counts=dict(counts), violations=violations)
(p / 'request-boundaries.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(counts=dict(counts), violation_count=len(violations),
                     examples=violations[:8],
                     max_backend_end_after_client_ns=max((row['backend_end_after_client_ns'] for row in violations), default=0)), indent=2))
