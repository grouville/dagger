from pathlib import Path
import json
import subprocess
import time

p = Path(__file__).parent
steps = [
    ('install', ['python3', str(p / 'install-engine.py')]),
    ('capture', ['python3', str(p / 'capture.py'), '--output', str(p / 'capture'), '--pairs', '1', '--languages', 'go']),
    ('causal-analysis', ['python3', str(p / 'analyze.py')]),
    ('cpu-lock-analysis', ['python3', str(p / 'analyze-forensics.py')]),
]
rows = []
for label, command in steps:
    tick = time.monotonic()
    with (p / (label + '-driver.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic()-tick))
    (p / 'pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '-driver.log')).read_text()[-5000:]
