from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time

p = Path(__file__).parent
destination = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-batched-discovery-facts')
destination.mkdir(exist_ok=False)
for arm in ['before', 'candidate']:
    capture = p / ('capture-' + arm)
    trace = capture / 'wcprof-complete.ndjson'
    identity = dict(bytes=trace.stat().st_size, sha256=hashlib.sha256(trace.read_bytes()).hexdigest())
    (capture / 'trace-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    subprocess.run(['python3', str(p / 'assemble-traces.py'), str(capture)], check=True)

members = []
for filename in sorted(p.rglob('*')):
    if not filename.is_file() or '__pycache__' in filename.parts:
        continue
    if filename.name == 'wcprof-complete.ndjson':
        continue
    relative = filename.relative_to(p)
    data = filename.read_bytes()
    members.append(dict(path=str(relative), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
archive = destination / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as output:
    for row in members:
        output.add(p / row['path'], arcname='evidence/' + row['path'], recursive=False)
with tarfile.open(archive, 'r:*') as stored:
    entries = stored.getmembers()
    assert len(entries) == len(members)
    for row in members:
        with stored.extractfile('evidence/' + row['path']) as stream:
            assert hashlib.sha256(stream.read()).hexdigest() == row['sha256']
manifest = dict(
    created_unix=time.time(), archive=archive.name,
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    archive_bytes=archive.stat().st_size, verified_members=len(members),
    uncompressed_member_bytes=sum(row['bytes'] for row in members),
    scope='Go module-only discovery prototype. Matched complete CLI observations, all setup failures, exact source patch and file snapshots, 27 passing checks, lossless wcprof chunks and sequential CPU profiles. No engine replacement or PR.',
    inherited_engine_context='../typed-artifact-metadata/',
    traces='Each capture has exact original compressed dump chunks. Run assemble-traces.py on its directory to recreate wcprof-complete.ndjson; bytes and SHA256 are verified against trace-identity.json. Derived reports are already included.',
    members=members,
)
(destination / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
(destination / 'README.md').write_text('''# Batched Go discovery facts

See [the assessment](../../NATIVE_GO_BATCHED_DISCOVERY_FACTS.md) and [prepared PR description](../../PR_GO_BATCHED_DISCOVERY_FACTS.md). Complete edited listing improves 25.45 → 19.21 seconds median in four alternating pairs, with identical rows and successful cleanup. This is a warm development-engine comparison, not stock main. Three seconds remains unachieved.

The archive retains the exact three-file module patch and source snapshots, source identities, all ten commands (including initialization), 27 passing checks and earlier harness failures. Separate lossless wcprof captures establish 7,820 → 4,845 nested SDK requests. Sequential CPU profiles, request-shape analyses, critical paths and restored engine state are included.

Each capture keeps the original compressed dump chunks. After extraction, run `python3 evidence/assemble-traces.py evidence/capture-candidate` or replace the final path with `evidence/capture-before`. This recreates the combined trace and verifies its exact bytes and SHA256. Raw combined files are omitted from the archive to avoid duplication. MANIFEST.json verifies every included member and the archive.

The unchanged engine and CLI sources are in the preceding [typed metadata experiment](../typed-artifact-metadata/). The module commit is 0b48743446cd6121f71141598022bc69700dbf26, based on the existing ownership prototype 7568cd0. Original local paths and the local telemetry receiver require adapting for replay. Engine binaries, credentials and the retained volume are excluded. No PR is open.
''')
print(json.dumps({k:manifest[k] for k in ['archive_bytes','verified_members','uncompressed_member_bytes','archive_sha256']}), flush=True)
