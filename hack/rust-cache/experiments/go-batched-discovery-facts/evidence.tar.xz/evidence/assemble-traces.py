from pathlib import Path
import argparse
import gzip
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument('capture', type=Path)
args = parser.parse_args()
events = []
headers = []
for chunk in sorted(args.capture.glob('chunk-*.ndjson.gz')):
    lines = gzip.decompress(chunk.read_bytes()).splitlines()
    headers.append(json.loads(lines[0]))
    events.extend(lines[1:])
assert headers
header = headers[-1]
for previous in headers:
    assert previous['epoch_unix_nano'] == header['epoch_unix_nano']
    assert previous['strings'] == header['strings'][:len(previous['strings'])]
    assert previous['dropped_events'] == 0
assert not header.get('open_ops')
combined = dict(header, event_count=len(events))
data = (json.dumps(combined) + '\n').encode() + b'\n'.join(events) + b'\n'
expected = json.loads((args.capture / 'trace-identity.json').read_text())
assert len(data) == expected['bytes']
assert hashlib.sha256(data).hexdigest() == expected['sha256']
(args.capture / 'wcprof-complete.ndjson').write_bytes(data)
print(args.capture.name, len(events), 'events; exact trace identity verified')
