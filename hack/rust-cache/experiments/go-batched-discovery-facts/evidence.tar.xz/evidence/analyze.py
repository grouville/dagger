from collections import Counter, defaultdict
from pathlib import Path
import json

p=Path(__file__).parent
capture=p.parent/'typed-artifact-metadata/capture-real-combined'
ops={}
with (capture/'wcprof-complete.ndjson').open() as stream:
    header=json.loads(next(stream));strings=header['strings']
    assert header['dropped_events']==0 and not header.get('open_ops')
    for line in stream:
        event=json.loads(line)
        if event['e']=='op':
            ops[event['id']]=(event.get('p',0),strings[event['c']],event['k'],event['s'],event['d'])
requests={identifier:[] for identifier,event in ops.items() if event[1]=='dang.apiRequest'}
nearest={0:0}
def request_for(identifier):
    path=[]
    while identifier not in nearest:
        if identifier in requests:
            nearest[identifier]=identifier;break
        event=ops.get(identifier)
        if event is None:
            nearest[identifier]=0;break
        path.append(identifier);identifier=event[0]
    result=nearest[identifier]
    for item in path:nearest[item]=result
    return result
for identifier,event in ops.items():
    if event[2]=='call':
        request=request_for(identifier)
        if request:requests[request].append((event[3],event[1]))
shapes=defaultdict(list)
for identifier,fields in requests.items():
    shape=tuple(name for _,name in sorted(fields))
    shapes[shape].append(identifier)
rows=[]
for shape,ids in shapes.items():
    rows.append(dict(count=len(ids),fields=list(shape),request_ids=ids,aggregate_seconds=sum((ops[i][4]-ops[i][3])/1e9 for i in ids)))
rows.sort(key=lambda row:row['count'],reverse=True)
result=dict(scope='Exact nearest-parent association. Calls from nested SDK requests belong only to their nearest request; no payload, argument, temporal or physical-import inference. Shapes include all calls inside that request, not only its GraphQL root fields. Concurrent durations overlap and their sums are not elapsed savings.',requests=len(requests),request_shapes=len(rows),shapes=rows)
(p/'request-shapes.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(requests=len(requests),request_shapes=len(rows),top=[{k:row[k] for k in ['count','fields']} for row in rows[:16]]),indent=2))
