# Upstream plain scalar-array rendering

The previous selected Go engine was 7c989097, with a last validated complete-listing median of 35.90 seconds. The completed repeat on the replacement engine measures 40.28 seconds for the selected path and 40.72 seconds for the candidate, which is slower in three of four pairs. The candidate stays disabled; no new speedup or proposal is claimed.

Upstream aacc932b7d (Alex Suraci), present in main ff0b029a, reads Array and DynamicArrayOutput leaf elements directly. The retained engine still specializes only four typed scalar arrays. The proposed diagnostic switch applies the upstream valueEnumerable/leafValue iteration to the broader set. It retains this experimental engine's existing parent access, cancellation, session release and resource-growth checks, rather than bypassing them.

This is an adoption experiment for already upstream code, not another upstream proposal. Ordinary functions, object selections, explicit Nth/ID access, the selected data-only object-list policy and every build-cache input retain their previous path.

Both controlled arms pass the focused output, native-array, ID and resource checks. The candidate full DagQL race suite passes. An initial diagnostic build fails for a missing engine import; that failed attempt and source are preserved in initial-build-import. No live engine is replaced while preparing or building these files.

The planned component screen uses a DynamicArrayOutput and a list argument of the same length, with 1 and 1,024 values, ordinary GC and fresh processes in four alternating pairs. Fixture construction and an initial query are excluded. The timed query repeats the parent call, as the old renderer still clones the call's arguments before each item-cache lookup. Benchmark names are anchored and exactly one result is required. A component win alone does not establish a faster complete Go listing.

The completed corrected component screen has 16 successful processes, four alternating pairs per size. Both sizes improve in every pair. Median latency is 22.03 → 15.85 microseconds for one element and 279.81 → 0.295 milliseconds for 1,024. The larger case allocates 637.02 → 0.341 MB per query. This deliberately exposes copying a length-N parent argument for each of N results; it does not imply a similar ratio for a complete listing. Maximum observed host CPU and I/O pressure are 1.83% and 1.28%.

The benchmark initially omitted DynamicArrayOutput's schema element type and then supplied []string where its variable decoder expects []any. Both failed attempts and logs remain under initial-benchmark-schema, initial-benchmark-variables, components and components-fixed. Only components-final uses the corrected, smoke-checked binaries. These were fixture failures, not timing results. The functional checks were already passing and are unchanged by those benchmark corrections.

All six existing native Rust histories pass before replacement: 130/130, 1,026/1,026 and 6/6 actions, twice each. The controlled engine builds and installs successfully on the same retained volume. All ten listing commands and all six retained native histories pass after the cohort and profile. Its SHA-256 is recorded in engine-builds.json. No upstream proposal is added.

See STUDY.md for the complete matched comparison, actual-path evidence and selected-state limits. The completed capture records 385,267 events with zero dropped or open operations. It removes 105 String.dimensions publications, while the dominant discovery calls and 7,507 search-result publications remain.
