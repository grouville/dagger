# Next measured engine experiment

No implementation or performance result is claimed here.

The native SearchResult value contains only strings, integers and a list of plain SearchSubmatch values (core/search.go). Its schema registration is dagql.Fields[*core.SearchResult]{}.Install(srv) in core/schema/directory.go. The completed real-listing profile contains 7,507 SearchResult.search item publications, compared with only 105 String.dimensions item publications removed by the unsuccessful scalar-leaf adoption screen.

Check whether the actual search requests select only stored scalar fields such as filePath and matchedLines. If so, the already-tested ClassOpts.PureData projection policy may apply by explicitly declaring this native value immutable and resource-free. Verify mutation/ownership assumptions and runtime interfaces first; pointer fields alone do not prove the contract. Queries selecting submatches or IDs must retain their existing path under the present policy.

The experiment should reuse the existing generic projection mechanism, add a focused native-search field/ID regression, run relevant workspace-overlay/search correctness checks, then compare the complete ordered 4,398-row listing in alternating pairs. Use both fresh and repeated parent components with realistic argument sizes. Do not repeat the deliberately quadratic dynamic-array fixture as evidence for this different workload. Keep the upstream-leaf-arrays switch disabled in both arms.

The remaining critical path also contains 26.05 seconds inside module API requests, including backend work. Profiling the requests themselves is still required before interpreting that as transport cost. The CPU capture contains substantial GC marking and protobuf JSON encoding. Neither total may be subtracted directly from elapsed time.
