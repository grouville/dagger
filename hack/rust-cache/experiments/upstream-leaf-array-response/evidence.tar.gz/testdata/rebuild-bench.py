from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1');rows=[]
for arm in ['before','after']:
 command=[go,'test','-c','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/(arm+'-test-overlay.json')),'-o',str(p/(arm+'-fixed.test')),'./dagql']
 begin=time.monotonic()
 with (p/(arm+'-fixed-build.log')).open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(arm=arm,command=command,seconds=time.monotonic()-begin,exit_code=r.returncode,sha256=hashlib.sha256((p/(arm+'-fixed.test')).read_bytes()).hexdigest() if r.returncode==0 else None));(p/'fixed-builds.json').write_text(json.dumps(rows,indent=2)+'\n');print(arm,r.returncode,flush=True);assert r.returncode==0
