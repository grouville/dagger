from pathlib import Path
import json,os,subprocess,time,hashlib
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';modfile='/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for phase in ['race','component-build']:
 for arm in ['before','after']:
  command=[go,'test','-p','2','-buildvcs=false','-modfile',modfile,'-overlay',str(p/(arm+'-test-overlay.json'))]
  if phase=='race':
   command+=['-race','-count=1']
   if arm=='before':command+=['-v','-run','^Test(UpstreamLeafArray|PrimitiveArrayResponse)']
   command+=['./dagql']
  else:command+=['-c','-o',str(p/(arm+'.test')),'./dagql']
  begin=time.monotonic();label=arm+'-'+phase
  with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=subprocess.STDOUT)
  row=dict(label=label,command=command,seconds=time.monotonic()-begin,exit_code=r.returncode)
  if phase=='component-build' and r.returncode==0:row['sha256']=hashlib.sha256((p/(arm+'.test')).read_bytes()).hexdigest()
  rows.append(row);(p/'validation-builds.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,round(row['seconds'],3),flush=True)
  if r.returncode:print((p/(label+'.log')).read_text()[-6000:],flush=True)
  assert r.returncode==0
