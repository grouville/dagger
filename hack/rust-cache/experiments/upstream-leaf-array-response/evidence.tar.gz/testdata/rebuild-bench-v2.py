from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for arm in ['before','after']:
    command=[go,'test','-c','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/(arm+'-test-overlay.json')),'-o',str(p/(arm+'-fixed-v2.test')),'./dagql']
    begin=time.monotonic()
    with (p/(arm+'-fixed-v2-build.log')).open('w') as out:
        result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=subprocess.STDOUT)
    row=dict(arm=arm,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
    rows.append(row)
    (p/'fixed-v2-builds.json').write_text(json.dumps(rows,indent=2)+'\n')
    assert result.returncode==0
    row['sha256']=hashlib.sha256((p/(arm+'-fixed-v2.test')).read_bytes()).hexdigest()
    smoke=[str(p/(arm+'-fixed-v2.test')),'-test.run=^$','-test.bench=^BenchmarkUpstreamLeafArray$/^(1|1024)$','-test.benchtime=1x']
    with (p/(arm+'-benchmark-smoke.log')).open('w') as out:
        check=subprocess.run(smoke,env=env,stdout=out,stderr=subprocess.STDOUT)
    row['smoke_command']=smoke
    row['smoke_exit_code']=check.returncode
    (p/'fixed-v2-builds.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(arm,'build',result.returncode,'smoke',check.returncode,flush=True)
    assert check.returncode==0,(p/(arm+'-benchmark-smoke.log')).read_text()[-4000:]
