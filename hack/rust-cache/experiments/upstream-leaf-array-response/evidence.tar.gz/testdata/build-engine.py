from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
assert json.loads((p/'validation-builds.json').read_text())[1]['exit_code']==0
samples=json.loads((p/'components-final/samples.json').read_text())
assert len(samples)==16 and all(x['exit_code']==0 for x in samples)
for count in [1,1024]:
    for pair in range(4):
        before=next(x for x in samples if x['count']==count and x['pair']==pair and x['arm']=='before')
        after=next(x for x in samples if x['count']==count and x['pair']==pair and x['arm']=='after')
        assert after['metrics']['ns/op']<before['metrics']['ns/op'],(count,pair)
steps=[('retained-before',['python3','/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py','upstream-leaf-arrays-before'],None),
       ('engine-build',[go,'build','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/'engine-overlay.json'),'-o',str(p/'dagger-engine'),'./cmd/engine'],'/tmp/dagger-filesync-snapshot-seeds')]
rows=[]
for label,command,cwd in steps:
    begin=time.monotonic()
    with (p/(label+'.log')).open('w') as out:
        result=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
    if label=='engine-build' and result.returncode==0:
        row['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
    rows.append(row)
    (p/'engine-builds.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(label,result.returncode,flush=True)
    if result.returncode:print((p/(label+'.log')).read_text()[-5000:],flush=True)
    assert result.returncode==0
