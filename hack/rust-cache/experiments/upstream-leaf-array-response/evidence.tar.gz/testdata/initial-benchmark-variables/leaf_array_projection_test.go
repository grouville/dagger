package dagql

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"

	"github.com/stretchr/testify/require"
	"github.com/vektah/gqlparser/v2/ast"
)

func TestUpstreamLeafArrayNullableValuesAndIDs(t *testing.T) {
	ctx, cache, srv := scalarArrayTestServer(t)
	Fields[cacheTestQuery]{Func("echo", func(_ context.Context, _ cacheTestQuery, args struct{ Names []string }) (Array[Nullable[String]], error) {
		out := make(Array[Nullable[String]], len(args.Names))
		for i, name := range args.Names {
			if name != "" {
				out[i] = NonNull(String(name))
			}
		}
		return out, nil
	})}.Install(srv)
	got, err := srv.Query(ctx, `{echo(names:["a","","c"])}`, nil)
	require.NoError(t, err)
	encoded, err := json.Marshal(got)
	require.NoError(t, err)
	require.JSONEq(t, `{"echo":["a",null,"c"]}`, string(encoded))
	if upstreamLeafArrays.Load() {
		require.Equal(t, 1, cache.Size(), "upstream leaf rendering must not attach individual scalars")
	} else {
		require.Greater(t, cache.Size(), 1)
	}
	list, err := srv.Root().Select(ctx, srv, Selector{Field: "echo", Args: []NamedInput{{Name: "names", Value: ArrayInput[String]{"a", "", "c"}}}})
	require.NoError(t, err)
	value, err := list.NthValue(ctx, 1)
	require.NoError(t, err)
	require.NotZero(t, value.cacheSharedResult().id)
	value, present := value.DerefValue()
	require.True(t, present)
	require.Equal(t, String("a"), value.Unwrap())
}

type leafArrayHolder struct {
	Words []string `field:"true"`
}

func (*leafArrayHolder) Type() *ast.Type {
	return &ast.Type{NamedType: "LeafArrayHolder", NonNull: true}
}

func TestUpstreamLeafArrayNativeField(t *testing.T) {
	ctx, cache, srv := scalarArrayTestServer(t)
	Fields[*leafArrayHolder]{}.Install(srv)
	Fields[cacheTestQuery]{Func("holder", func(context.Context, cacheTestQuery, struct{}) (*leafArrayHolder, error) {
		return &leafArrayHolder{Words: []string{"", "<>&", "é\n\""}}, nil
	})}.Install(srv)
	got, err := srv.Query(ctx, `{holder{words}}`, nil)
	require.NoError(t, err)
	encoded, err := json.Marshal(got)
	require.NoError(t, err)
	require.JSONEq(t, `{"holder":{"words":["","<>&","é\n\""]}}`, string(encoded))
	if upstreamLeafArrays.Load() {
		require.Equal(t, 2, cache.Size(), "native DynamicArrayOutput must use the upstream path too")
	} else {
		require.Greater(t, cache.Size(), 2)
	}
}

func TestUpstreamLeafArrayAccessChecks(t *testing.T) {
	ctx, cache, srv := scalarArrayTestServer(t)
	list, err := srv.Root().Select(ctx, srv, Selector{Field: "strings"})
	require.NoError(t, err)
	values := list.Unwrap().(valueEnumerable)
	handle := cacheTestVolatileSessionResourceHandle("UPSTREAM_LEAF_ARRAY")
	require.NoError(t, cache.BindSessionResource(ctx, "test-session", "dagql-test-client", handle, "bound"))
	currentEntryTestRequireHandle(t, ctx, cache, srv, "test-session", list, handle)
	_, err = projectLeafArray(cacheTestSessionContext(ctx, "unbound"), list, values)
	require.ErrorContains(t, err, "has not bound")
	_, err = projectLeafArray(ctx, list, values)
	require.NoError(t, err)
	canceled, cancel := context.WithCancel(ctx)
	cancel()
	_, err = projectLeafArray(canceled, list, values)
	require.ErrorIs(t, err, context.Canceled)
	require.NoError(t, cache.ReleaseSession(ctx, "test-session"))
	_, err = projectLeafArray(ctx, list, values)
	require.ErrorIs(t, err, ErrCacheSessionReleased)
}

func TestUpstreamLeafArrayRechecksResourceGrowth(t *testing.T) {
	ctx, cache, srv := scalarArrayTestServer(t)
	list, err := srv.Root().Select(ctx, srv, Selector{Field: "strings"})
	require.NoError(t, err)
	other := currentEntryTestSession(ctx, cache, "other-session")
	handle := cacheTestVolatileSessionResourceHandle("UPSTREAM_LEAF_LATE_RESOURCE")
	require.NoError(t, cache.BindSessionResource(other, "other-session", "other-client", handle, "bound elsewhere"))
	copyContext := &primitiveCopyContext{Context: ctx, beforeCopy: func() {
		currentEntryTestRequireHandle(t, other, cache, srv, "other-session", list, handle)
	}}
	output, err := projectLeafArray(copyContext, list, list.Unwrap().(valueEnumerable))
	require.ErrorContains(t, err, "has not bound")
	require.Nil(t, output)
}

func BenchmarkUpstreamLeafArray(b *testing.B) {
	for _, count := range []int{1, 1024} {
		b.Run(fmt.Sprint(count), func(b *testing.B) {
			ctx := cacheTestContext(b.Context())
			cache, err := NewCache(ctx, "", nil, nil)
			require.NoError(b, err)
			b.Cleanup(func() { require.NoError(b, cache.CloseDiscardingPersistence()) })
			ctx = ContextWithCache(ctx, cache)
			srv, err := NewServer(ctx, cacheTestQuery{})
			require.NoError(b, err)
			echo := Func("echo", func(_ context.Context, _ cacheTestQuery, args struct{ Names []string }) (DynamicArrayOutput, error) {
				out := DynamicArrayOutput{Elem: String(""), Values: make([]Typed, len(args.Names))}
				for i, name := range args.Names {
					out.Values[i] = String(name)
				}
				return out, nil
			})
			echo.Spec.Type = DynamicArrayOutput{Elem: String("")}
			Fields[cacheTestQuery]{echo}.Install(srv)
			names := make([]string, count)
			for i := range names {
				names[i] = fmt.Sprintf("name-%04d", i)
			}
			query := `query($names:[String!]!){echo(names:$names)}`
			variables := map[string]any{"names": names}
			_, err = srv.Query(ctx, query, variables)
			require.NoError(b, err)
			b.ReportAllocs()
			for b.Loop() {
				got, err := srv.Query(ctx, query, variables)
				require.NoError(b, err)
				require.Len(b, got["echo"], count)
			}
		})
	}
}
