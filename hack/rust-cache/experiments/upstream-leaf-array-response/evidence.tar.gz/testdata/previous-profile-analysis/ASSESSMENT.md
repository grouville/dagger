# Remaining module API work

The selected full Go listing is 35.90 seconds median (matched control 42.24 seconds); this investigation establishes no newer speedup.

The existing completed wcprof capture records 7,820 dang.apiRequest operations and 7,845 backend session.serveQuery operations. Nested-client links correlate evaluator invocations with backend client IDs. All API intervals contain a candidate backend interval for that client, but longest-contained matching assigns 195 backend operations more than once. These correlations are exploratory and must not be used to fabricate wait edges or claim a precise transport/backend split across the full command. The raw trace is unchanged.

The largest API interval (27954) is 7.941 seconds and contains backend 28348 lasting 7.935 seconds. Re-rooting the actual backend operation identifies GomodGoMod.ownFiles. Its path contains another 5.01 seconds of nested API waits, 1.64 seconds of evaluator time and 750 ms of publication. The ownFiles implementation combines nested-root discovery, workspace globbing, filtering and sorting.

A later 3.20-second backend file-search query (189629) has about 12 ms in File.search. Query.node, module scoping, cached mirror access and publication each occupy hundreds of milliseconds. Those intervals alone do not distinguish CPU, scheduler delays or uninstrumented locks. Some early API waits include client initialization before the backend serveQuery marker; the prior admission experiments remain relevant and are not re-run unchanged.

The retained engine still uses an older scalar-leaf renderer specialized for four typed arrays. Upstream ff0b029a includes Alex Suraci's aacc932b7d, reading Array and DynamicArrayOutput values directly without per-element call-frame copies/cache entries. The current controlled experiment imports that iteration strategy while retaining the diagnostic engine's existing session-resource, cancellation and released-session checks. It is an upstream adoption screen, not a new upstream proposal.
