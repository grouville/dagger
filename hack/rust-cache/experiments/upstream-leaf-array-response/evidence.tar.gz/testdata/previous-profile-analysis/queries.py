from pathlib import Path
from collections import defaultdict,Counter
import bisect,json,subprocess,time
p=Path(__file__).parent
source=Path('/tmp/rust-cache-sipsma-review/scalar-list-projection/v3-native-preflight-capture/wcprof-complete.ndjson')
ops={};links=[]
with source.open() as f:
 header=json.loads(next(f));names=header['strings']
 for line in f:
  e=json.loads(line)
  if e.get('e')=='op':ops[e['id']]=e
  elif e.get('e')=='link' and e.get('lk')=='nested_client':links.append(e)
client_for_parent={e['p']:e['i'] for e in links}
queries=defaultdict(list)
for e in ops.values():
 if names[e['c']]=='session.serveQuery':queries[e.get('cl',0)].append(e)
for seq in queries.values():seq.sort(key=lambda e:e['s'])
starts={c:[e['s'] for e in seq] for c,seq in queries.items()}
rows=[]
for e in ops.values():
 if names[e['c']]!='dang.apiRequest':continue
 parent=e.get('p',0)
 while parent and parent not in client_for_parent:parent=ops.get(parent,{}).get('p',0)
 cid=client_for_parent.get(parent)
 candidates=[]
 if cid in queries:
  seq=queries[cid];s=starts[cid]
  begin=bisect.bisect_left(s,e['s']);end=bisect.bisect_right(s,e['d'])
  candidates=[x for x in seq[begin:end] if x['d']<=e['d']]
 backend=max(candidates,key=lambda x:x['d']-x['s']) if candidates else None
 rows.append(dict(api_op=e['id'],api_parent=e.get('p'),client=cid,seconds=(e['d']-e['s'])/1e9,backend_op=backend['id'] if backend else None,backend_seconds=(backend['d']-backend['s'])/1e9 if backend else None))
(p/'request-backend-matches.json').write_text(json.dumps(rows,indent=2)+'\n')
print('API calls',len(rows),'matched',sum(r['backend_op'] is not None for r in rows),flush=True)
for r in sorted(rows,key=lambda r:r['seconds'],reverse=True)[:12]:print(r,flush=True)
# Re-root real backend work; do not alter the recorded graph or invent wait edges.
targets=[28348]
for target in [125460,136002,189491]:
 r=next(x for x in rows if x['api_op']==target)
 if r['backend_op']:targets.append(r['backend_op'])
for id in dict.fromkeys(targets):
 command=['/tmp/rust-cache-wcprof-report-current','-view','critpath','-op',str(id),'-top','25','-depth','10','-limit','85',str(source)]
 with (p/f'backend-{id}-critical.log').open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 assert result.returncode==0
 print('analyzed backend',id,flush=True)
