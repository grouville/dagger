from pathlib import Path
from collections import Counter,defaultdict
import json
p=Path(__file__).parent
source=Path('/tmp/rust-cache-sipsma-review/scalar-list-projection/v3-native-preflight-capture/wcprof-complete.ndjson')
ops={};links=[]
with source.open() as f:
 header=json.loads(next(f));names=header['strings']
 for line in f:
  e=json.loads(line)
  if e.get('e')=='op':ops[e['id']]=e
  elif e.get('e')=='link':links.append(e)
for id in [5653,6419,7162,27954,125459,125460]:
 e=ops[id];print('target',dict(e,cls=names[e['c']],ident=names[e['i']] if e.get('i') else ''))
print('link kinds',Counter(e.get('k') for e in links))
print('nested link examples',[e for e in links if e.get('k')=='nested_client'][:3])
q=[e for e in ops.values() if names[e['c']]=='session.serveQuery']
print('backend queries',len(q),'clients',len({e.get('cl') for e in q}))
r=ops[27954]
inside=[e for e in q if e['s']>=r['s'] and e['d']<=r['d']]
print('inside long request',len(inside))
for e in sorted(inside,key=lambda e:e['d']-e['s'],reverse=True)[:12]:print('backend',e,'seconds',(e['d']-e['s'])/1e9)
(p/'initial-inspection.json').write_text(json.dumps(dict(targets=[ops[i] for i in [5653,6419,7162,27954,125459,125460]],link_kinds=dict(Counter(e.get('k') for e in links)),backend_queries=len(q),backend_clients=len({e.get('cl') for e in q}),inside_long_request=inside),indent=2)+'\n')
