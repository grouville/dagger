package dagql

func init() { upstreamLeafArrays.Store(false) }
