package dagql

func init() { upstreamLeafArrays.Store(true) }
