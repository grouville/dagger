from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
validation=json.loads((p/'validation.json').read_text())
assert len(validation)==2 and validation[0]['exit_code']!=0 and validation[1]['exit_code']==0
subprocess.run([str(Path(go).with_name('gofmt')), '-w', *[str(p / name) for name in
    ['controlled-coremod.go', 'recovered_schema_mode.go', 'debug.go', 'coremod_memo_identity_test.go']]], check=True)
rows = []
for label, pattern, enabled in [
    ('actual-overlay-race-off', '^Test(SchemaBuilder|ArtifactSchema|ModDepsForCall)', 'off'),
    ('actual-overlay-race-on', '^Test(CoreProviders|SchemaBuilder|RecoveredSchemas|ArtifactSchema|ModDepsForCall)', 'on'),
]:
    command = [go, 'test', '-p', '2', '-buildvcs=false', '-modfile',
        '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod', '-overlay',
        str(p / 'engine-overlay.json'), '-race', '-count=1', '-run', pattern, './core', './core/schema']
    start = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds',
            env=dict(env, DAGGER_TEST_RECOVERED_SCHEMA_TEMPLATES=enabled, DAGGER_TEST_CANONICAL_CORE_PROVIDERS=enabled), stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, enabled=enabled,
                     exit_code=result.returncode, seconds=time.monotonic() - start))
    (p / 'actual-overlay-validation.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]

steps = [
    ('retained-before', ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py', 'recovered-schema-stable-core-before'], None),
    ('engine-build', [go, 'build', '-p', '2', '-buildvcs=false', '-modfile',
        '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod', '-overlay',
        str(p / 'engine-overlay.json'), '-o', str(p / 'dagger-engine'), './cmd/engine'], '/tmp/dagger-filesync-snapshot-seeds'),
]
rows = []
for label, command, cwd in steps:
    start = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start)
    if label == 'engine-build' and result.returncode == 0:
        row['sha256'] = hashlib.sha256((p / 'dagger-engine').read_bytes()).hexdigest()
    rows.append(row)
    (p / 'engine-builds.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]
