package schema

import (
	"context"
	"fmt"
	"sync"

	"github.com/dagger/dagger/cmd/codegen/introspection"
	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	dagqlintrospection "github.com/dagger/dagger/dagql/introspection"
	"github.com/dagger/dagger/engine"
	"github.com/dagger/dagger/engine/slog"
)

// CoreMod is a special implementation of Mod for our core API, which is not *technically* a true module yet
// but can be treated as one in terms of dependencies. It has no dependencies itself and is currently an
// implicit dependency of every user module.
type CoreSchemaBase struct {
	base    *dagql.Server
	rootSrv core.Server
	views   map[call.View]*coreSchemaViewState
	mu      sync.Mutex
}

type coreSchemaViewState struct {
	server *dagql.Server

	typedefs         dagql.ObjectResultArray[*core.TypeDef]
	objectDefsByName map[string]dagql.ObjectResult[*core.TypeDef]
	scalarDefsByName map[string]dagql.ObjectResult[*core.TypeDef]
	enumDefsByName   map[string]dagql.ObjectResult[*core.TypeDef]
}

type CoreMod struct {
	base *CoreSchemaBase
	view call.View
}

var _ core.Mod = (*CoreMod)(nil)

func NewCoreSchemaBase(ctx context.Context, rootSrv core.Server) (*CoreSchemaBase, error) {
	base, err := dagql.NewServer(ctx, core.NewRoot(rootSrv))
	if err != nil {
		return nil, err
	}
	base.Around(core.AroundFunc)
	base.AddInstallHook(&legacyIDHook{server: base})
	coreMod := &CoreMod{}
	if err := coreMod.Install(ctx, base); err != nil {
		return nil, err
	}
	return &CoreSchemaBase{
		base:    base,
		rootSrv: rootSrv,
		views:   map[call.View]*coreSchemaViewState{},
	}, nil
}

func (base *CoreSchemaBase) CoreMod(view call.View) *CoreMod {
	return &CoreMod{
		base: base,
		view: view,
	}
}

func (base *CoreSchemaBase) Fork(ctx context.Context, root *core.Query, view call.View) (*dagql.Server, error) {
	state, err := base.viewState(ctx, view)
	if err != nil {
		return nil, err
	}
	forked, err := state.server.Fork(ctx, root)
	if err != nil {
		return nil, err
	}
	core.InstallCoreSchemaLoaders(forked)
	return forked, nil
}

// ForkForPersistedDecode returns a schema-only server for a background
// persisted decode: the already-installed base forked onto the given root,
// with the core view set and the ordinary core loaders installed. It
// deliberately bypasses viewState, which builds cache-backed type
// definitions; the native Service, Container and Module decoder classes this
// needs are already installed on the base. It installs no user module and
// builds no dynamic schema.
func (base *CoreSchemaBase) ForkForPersistedDecode(ctx context.Context, root *core.Query, view call.View) (*dagql.Server, error) {
	if base == nil {
		return nil, fmt.Errorf("fork core schema for persisted decode: no core schema base")
	}
	if root == nil {
		return nil, fmt.Errorf("fork core schema for persisted decode: no root")
	}
	forked, err := base.base.Fork(ctx, root)
	if err != nil {
		return nil, fmt.Errorf("fork core schema for persisted decode: %w", err)
	}
	forked.View = view
	core.InstallCoreSchemaLoaders(forked)
	return forked, nil
}

func (base *CoreSchemaBase) viewState(ctx context.Context, view call.View) (*coreSchemaViewState, error) {
	// The schema-only fork used by a share's persisted decode bypasses this
	// cache-backed type-definition build entirely.
	if err := engine.CheckSnapshotSharePreparation(ctx, "build core schema view"); err != nil {
		return nil, err
	}
	base.mu.Lock()
	defer base.mu.Unlock()

	if state, ok := base.views[view]; ok {
		return state, nil
	}

	srv, err := base.base.Fork(ctx, core.NewRoot(base.rootSrv))
	if err != nil {
		return nil, fmt.Errorf("fork core schema base: %w", err)
	}
	srv.View = view

	coreMod := base.CoreMod(view)
	typedefs, err := coreMod.buildTypeDefs(ctx, srv)
	if err != nil {
		return nil, err
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, fmt.Errorf("load engine cache for core typedef retention: %w", err)
	}
	for _, typedef := range typedefs {
		if typedef.Self() == nil {
			continue
		}
		if err := cache.MakeResultUnpruneable(ctx, typedef); err != nil {
			return nil, fmt.Errorf("retain core typedef %q: %w", typedef.Self().Name, err)
		}
	}
	state := &coreSchemaViewState{
		server:           srv,
		typedefs:         typedefs,
		objectDefsByName: make(map[string]dagql.ObjectResult[*core.TypeDef]),
		scalarDefsByName: make(map[string]dagql.ObjectResult[*core.TypeDef]),
		enumDefsByName:   make(map[string]dagql.ObjectResult[*core.TypeDef]),
	}
	for _, typedef := range typedefs {
		if typedef.Self() == nil {
			continue
		}
		switch typedef.Self().Kind {
		case core.TypeDefKindObject:
			state.objectDefsByName[typedef.Self().AsObject.Value.Self().Name] = typedef
		case core.TypeDefKindScalar:
			state.scalarDefsByName[typedef.Self().AsScalar.Value.Self().Name] = typedef
		case core.TypeDefKindEnum:
			state.enumDefsByName[typedef.Self().AsEnum.Value.Self().Name] = typedef
		}
	}
	base.views[view] = state
	return state, nil
}

func (m *CoreMod) Name() string {
	return core.ModuleName
}

func (m *CoreMod) Same(other core.Mod) (bool, error) {
	_, ok := other.(*CoreMod)
	return ok, nil
}

// GetSource returns an empty module source
func (m *CoreMod) GetSource() *core.ModuleSource {
	return &core.ModuleSource{}
}

func (m *CoreMod) View() (call.View, bool) {
	return m.view, true
}

func (m *CoreMod) FieldModule() (*dagql.ResultCallModule, dagql.FieldModuleProvider, error) {
	return nil, nil, nil
}

func (m *CoreMod) ModuleResult() dagql.ObjectResult[*core.Module] {
	return dagql.ObjectResult[*core.Module]{}
}

func (m *CoreMod) ForkSchema(ctx context.Context, root *core.Query, view call.View) (*dagql.Server, error) {
	if m.base == nil {
		return nil, fmt.Errorf("core schema base is nil")
	}
	return m.base.Fork(ctx, root, view)
}

func (m *CoreMod) WithView(view call.View) *CoreMod {
	return &CoreMod{
		base: m.base,
		view: view,
	}
}

func (m *CoreMod) Install(ctx context.Context, dag *dagql.Server, _ ...core.InstallOpts) error {
	// @reevaluate lets generated clients reuse the IDs of objects that don't
	// need to be reevaluated. Modules pinned to an engine version before v1.0.0
	// don't see it, so their generated clients keep fetching every ID. Module
	// views drop the prerelease (engine.APIViewVersion), so every v1.0.0
	// prerelease sees it.
	dag.InstallDirective(dagql.ReevaluateDirective.View(AfterVersion("v1.0.0-beta.17")))
	for _, schema := range []SchemaResolvers{
		&querySchema{},
		&directorySchema{},
		&fileSchema{},
		&gitSchema{},
		&containerSchema{},
		&cacheSchema{},
		&volumeSchema{},
		&secretSchema{},
		&serviceSchema{},
		&hostSchema{},
		&httpSchema{},
		&platformSchema{},
		&socketSchema{},
		&moduleSourceSchema{},
		&moduleSchema{},
		&errorSchema{},
		&engineSchema{},
		&cloudSchema{},
		&llmSchema{},
		&agentSchema{},
		&jsonvalueSchema{},
		&schemaToolsSchema{},
		&envfileSchema{},
		&addressSchema{},
		&checksSchema{},
		&generatorSchema{},
		&artifactsSchema{},
		&agentsSchema{},
		&workspaceSchema{},
	} {
		schema.Install(dag)
	}

	return installRemoteCacheFixture(dag)
}

func (m *CoreMod) ModTypeFor(ctx context.Context, typeDef *core.TypeDef, checkDirectDeps bool) (core.ModType, bool, error) {
	state, err := m.viewState(ctx)
	if err != nil {
		return nil, false, err
	}

	var modType core.ModType

	switch typeDef.Kind {
	case core.TypeDefKindString, core.TypeDefKindInteger, core.TypeDefKindFloat, core.TypeDefKindBoolean, core.TypeDefKindVoid:
		modType = &core.PrimitiveType{Def: typeDef}

	case core.TypeDefKindList:
		underlyingType, ok, err := m.ModTypeFor(ctx, typeDef.AsList.Value.Self().ElementTypeDef.Self(), checkDirectDeps)
		if err != nil {
			return nil, false, fmt.Errorf("failed to get underlying type: %w", err)
		}
		if !ok {
			return nil, false, nil
		}
		modType = &core.ListType{
			Elem:       typeDef.AsList.Value.Self().ElementTypeDef,
			Underlying: underlyingType,
		}

	case core.TypeDefKindScalar:
		_, ok := state.server.ScalarType(typeDef.AsScalar.Value.Self().Name)
		if !ok {
			return nil, false, nil
		}

		resolvedDef := state.scalarDefsByName[typeDef.AsScalar.Value.Self().Name]
		if resolvedDef.Self() == nil {
			return nil, false, fmt.Errorf("could not resolve scalar def %s", typeDef.AsScalar.Value.Self().Name)
		}

		modType = &CoreModScalar{coreMod: m, name: resolvedDef.Self().AsScalar.Value.Self().Name}

	case core.TypeDefKindObject:
		_, ok := state.server.ObjectType(typeDef.AsObject.Value.Self().Name)
		if !ok {
			return nil, false, nil
		}

		resolvedDef := state.objectDefsByName[typeDef.AsObject.Value.Self().Name]
		if resolvedDef.Self() == nil {
			return nil, false, fmt.Errorf("could not resolve object def %s", typeDef.AsObject.Value.Self().Name)
		}

		modType = &CoreModObject{coreMod: m, name: resolvedDef.Self().AsObject.Value.Self().Name}

	case core.TypeDefKindEnum:
		_, ok := state.server.ScalarType(typeDef.AsEnum.Value.Self().Name)
		if !ok {
			return nil, false, nil
		}

		resolvedDef := state.enumDefsByName[typeDef.AsEnum.Value.Self().Name]
		if resolvedDef.Self() == nil {
			return nil, false, fmt.Errorf("could not resolve enum def %s", typeDef.AsEnum.Value.Self().Name)
		}

		modType = &CoreModEnum{coreMod: m, typeDef: resolvedDef.Self().AsEnum.Value.Self()}

	case core.TypeDefKindInterface:
		// core does not yet define any interfaces
		return nil, false, nil

	default:
		return nil, false, fmt.Errorf("unexpected type def kind %s", typeDef.Kind)
	}

	if typeDef.Optional {
		innerDef, err := modType.TypeDef(ctx)
		if err != nil {
			return nil, false, fmt.Errorf("resolve core nullable inner typedef: %w", err)
		}
		if innerDef.Self().Optional {
			if err := state.server.Select(ctx, innerDef, &innerDef, dagql.Selector{
				Field: "withOptional",
				Args:  []dagql.NamedInput{{Name: "optional", Value: dagql.Boolean(false)}},
			}); err != nil {
				return nil, false, fmt.Errorf("clear optional on core nullable inner typedef: %w", err)
			}
		}
		modType = &core.NullableType{
			InnerDef: innerDef,
			Inner:    modType,
		}
	}

	return modType, true, nil
}

func (m *CoreMod) viewState(ctx context.Context) (*coreSchemaViewState, error) {
	if m.base == nil {
		return nil, fmt.Errorf("core schema base is nil")
	}
	return m.base.viewState(ctx, m.view)
}

func (m *CoreMod) TypeDefs(ctx context.Context, dag *dagql.Server) (dagql.ObjectResultArray[*core.TypeDef], error) {
	_ = dag

	state, err := m.viewState(ctx)
	if err != nil {
		return nil, err
	}
	return state.typedefs, nil
}

func buildCoreTypeDefFunctions(
	ctx context.Context,
	dag *dagql.Server,
	introspectionType *introspection.Type,
) ([]dagql.ID[*core.Function], bool, error) {
	fnIDs := make([]dagql.ID[*core.Function], 0, len(introspectionType.Fields))
	isIdable := false
	objType, _ := dag.ObjectType(introspectionType.Name)
	for _, introspectionField := range introspectionType.Fields {
		if introspectionField.Name == "id" {
			isIdable = true
			continue
		}

		rtType, ok, err := introspectionRefToTypeDef(ctx, dag, introspectionField.TypeRef, false)
		if err != nil {
			return nil, false, fmt.Errorf("failed to convert return type: %w", err)
		}
		if !ok {
			continue
		}
		rtTypeID, err := core.ResultIDInput(rtType)
		if err != nil {
			return nil, false, err
		}
		var fn dagql.ObjectResult[*core.Function]
		if err := dag.Select(ctx, dag.Root(), &fn, dagql.Selector{
			Field: "__function",
			Args: []dagql.NamedInput{
				{Name: "name", Value: dagql.String(introspectionField.Name)},
				{Name: "returnType", Value: rtTypeID},
			},
		}); err != nil {
			return nil, false, err
		}
		if introspectionField.Description != "" {
			if err := dag.Select(ctx, fn, &fn, dagql.Selector{
				Field: "withDescription",
				Args:  []dagql.NamedInput{{Name: "description", Value: dagql.String(introspectionField.Description)}},
			}); err != nil {
				return nil, false, err
			}
		}
		if introspectionField.DeprecationReason != nil {
			if err := dag.Select(ctx, fn, &fn, dagql.Selector{
				Field: "withDeprecated",
				Args:  []dagql.NamedInput{{Name: "reason", Value: core.OptString(introspectionField.DeprecationReason)}},
			}); err != nil {
				return nil, false, err
			}
		}

		for _, introspectionArg := range introspectionField.Args {
			argType, ok, err := resolveArgTypeDef(ctx, dag, introspectionArg)
			if err != nil {
				return nil, false, fmt.Errorf("failed to convert argument type for %s.%s(%s): %w", introspectionType.Name, introspectionField.Name, introspectionArg.Name, err)
			}
			if !ok {
				continue
			}
			argTypeID, err := core.ResultIDInput(argType)
			if err != nil {
				return nil, false, err
			}
			var resolvedSpec dagql.InputSpec
			if objType != nil {
				if fieldSpec, ok := objType.FieldSpec(introspectionField.Name, dag.View); ok {
					if argSpec, ok := fieldSpec.Args.Input(introspectionArg.Name, dag.View); ok {
						resolvedSpec = argSpec
					}
				}
			}
			defaultValue, err := introspectionDefaultToJSON(introspectionArg.DefaultValue, resolvedSpec)
			if err != nil {
				return nil, false, fmt.Errorf("convert default value for arg %q: %w", introspectionArg.Name, err)
			}
			var fnArg dagql.ObjectResult[*core.FunctionArg]
			if err := dag.Select(ctx, dag.Root(), &fnArg, dagql.Selector{
				Field: "__functionArgExact",
				Args: []dagql.NamedInput{
					{Name: "name", Value: dagql.String(introspectionArg.Name)},
					{Name: "typeDef", Value: argTypeID},
					{Name: "description", Value: dagql.String(introspectionArg.Description)},
					{Name: "defaultValue", Value: defaultValue},
					{Name: "deprecated", Value: core.OptString(introspectionArg.DeprecationReason)},
				},
			}); err != nil {
				return nil, false, err
			}
			fnArgID, err := core.ResultIDInput(fnArg)
			if err != nil {
				return nil, false, err
			}
			if err := dag.Select(ctx, fn, &fn, dagql.Selector{
				Field: "__withArg",
				Args:  []dagql.NamedInput{{Name: "arg", Value: fnArgID}},
			}); err != nil {
				return nil, false, err
			}
		}

		fnID, err := core.ResultIDInput(fn)
		if err != nil {
			return nil, false, err
		}
		fnIDs = append(fnIDs, fnID)
	}
	return fnIDs, isIdable, nil
}

func buildCoreObjectLikeTypeDef[T dagql.Typed](
	ctx context.Context,
	dag *dagql.Server,
	introspectionType *introspection.Type,
	baseSelector string,
	wrapSelector string,
	wrapArg string,
) (dagql.ObjectResult[*core.TypeDef], bool, error) {
	var zero dagql.ObjectResult[*core.TypeDef]
	var obj dagql.ObjectResult[T]
	if err := dag.Select(ctx, dag.Root(), &obj, dagql.Selector{
		Field: baseSelector,
		Args: []dagql.NamedInput{
			{Name: "name", Value: dagql.String(introspectionType.Name)},
			{Name: "description", Value: dagql.String(introspectionType.Description)},
		},
	}); err != nil {
		return zero, false, err
	}

	// Core names already have their final GraphQL spelling (WorkspaceSDK,
	// LLM, etc.). Module-name normalization must not change them.
	if err := dag.Select(ctx, obj, &obj, dagql.Selector{
		Field: "__withName",
		Args:  []dagql.NamedInput{{Name: "name", Value: dagql.String(introspectionType.Name)}},
	}); err != nil {
		return zero, false, err
	}

	fnIDs, isIdable, err := buildCoreTypeDefFunctions(ctx, dag, introspectionType)
	if err != nil {
		return zero, false, err
	}
	for _, fnID := range fnIDs {
		if err := dag.Select(ctx, obj, &obj, dagql.Selector{
			Field: "__withFunction",
			Args:  []dagql.NamedInput{{Name: "function", Value: fnID}},
		}); err != nil {
			return zero, false, err
		}
	}

	if !isIdable && introspectionType.Name != "Query" {
		return zero, false, nil
	}
	objID, err := core.ResultIDInput(obj)
	if err != nil {
		return zero, false, err
	}
	typeDef, err := core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
		Field: wrapSelector,
		Args:  []dagql.NamedInput{{Name: wrapArg, Value: objID}},
	})
	if err != nil {
		return zero, false, err
	}
	return typeDef, true, nil
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (m *CoreMod) buildTypeDefs(ctx context.Context, dag *dagql.Server) (dagql.ObjectResultArray[*core.TypeDef], error) {
	dagqlSchema := dagqlintrospection.WrapSchema(dag.Schema())
	schema := &introspection.Schema{}
	if queryName := dagqlSchema.QueryType().Name(); queryName != nil {
		schema.QueryType.Name = *queryName
	}
	for _, dagqlType := range dagqlSchema.Types() {
		codeGenType, err := core.DagqlToCodegenType(dagqlType)
		if err != nil {
			return nil, err
		}
		schema.Types = append(schema.Types, codeGenType)
	}
	directives, err := dagqlSchema.Directives()
	if err != nil {
		return nil, err
	}
	for _, dagqlDirective := range directives {
		dd, err := core.DagqlToCodegenDirectiveDef(dagqlDirective)
		if err != nil {
			return nil, err
		}
		schema.Directives = append(schema.Directives, dd)
	}

	typeDefs := make(dagql.ObjectResultArray[*core.TypeDef], 0, len(schema.Types))
	for _, introspectionType := range schema.Types {
		switch introspectionType.Kind {
		case introspection.TypeKindObject:
			typeDef, ok, err := buildCoreObjectLikeTypeDef[*core.ObjectTypeDef](
				ctx,
				dag,
				introspectionType,
				"__objectTypeDef",
				"__withObjectTypeDef",
				"objectTypeDef",
			)
			if err != nil {
				return nil, err
			}
			if ok {
				typeDefs = append(typeDefs, typeDef)
			}

		case introspection.TypeKindInterface:
			typeDef, ok, err := buildCoreObjectLikeTypeDef[*core.InterfaceTypeDef](
				ctx,
				dag,
				introspectionType,
				"__interfaceTypeDef",
				"__withInterfaceTypeDef",
				"interfaceTypeDef",
			)
			if err != nil {
				return nil, err
			}
			if ok {
				typeDefs = append(typeDefs, typeDef)
			}

		case introspection.TypeKindInputObject:
			var input dagql.ObjectResult[*core.InputTypeDef]
			if err := dag.Select(ctx, dag.Root(), &input, dagql.Selector{
				Field: "__inputTypeDef",
				Args:  []dagql.NamedInput{{Name: "name", Value: dagql.String(introspectionType.Name)}},
			}); err != nil {
				return nil, err
			}

			for _, introspectionField := range introspectionType.InputFields {
				fieldType, ok, err := introspectionRefToTypeDef(ctx, dag, introspectionField.TypeRef, false)
				if err != nil {
					return nil, fmt.Errorf("failed to convert return type: %w", err)
				}
				if !ok {
					continue
				}
				fieldTypeID, err := core.ResultIDInput(fieldType)
				if err != nil {
					return nil, err
				}
				var field dagql.ObjectResult[*core.FieldTypeDef]
				if err := dag.Select(ctx, dag.Root(), &field, dagql.Selector{
					Field: "__fieldTypeDefExact",
					Args: []dagql.NamedInput{
						{Name: "name", Value: dagql.String(introspectionField.Name)},
						{Name: "typeDef", Value: fieldTypeID},
						{Name: "description", Value: dagql.String(introspectionField.Description)},
						{Name: "deprecated", Value: core.OptString(introspectionField.DeprecationReason)},
					},
				}); err != nil {
					return nil, err
				}
				fieldID, err := core.ResultIDInput(field)
				if err != nil {
					return nil, err
				}
				if err := dag.Select(ctx, input, &input, dagql.Selector{
					Field: "__withField",
					Args:  []dagql.NamedInput{{Name: "field", Value: fieldID}},
				}); err != nil {
					return nil, err
				}
			}
			inputID, err := core.ResultIDInput(input)
			if err != nil {
				return nil, err
			}
			typeDef, err := core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
				Field: "__withInputTypeDef",
				Args:  []dagql.NamedInput{{Name: "inputTypeDef", Value: inputID}},
			})
			if err != nil {
				return nil, err
			}
			typeDefs = append(typeDefs, typeDef)

		case introspection.TypeKindScalar:
			var (
				typeDef dagql.ObjectResult[*core.TypeDef]
				err     error
			)
			switch introspectionType.Name {
			case string(introspection.ScalarString):
				typeDef, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
					Field: "withKind",
					Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindString}},
				})
			case string(introspection.ScalarInt):
				typeDef, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
					Field: "withKind",
					Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindInteger}},
				})
			case string(introspection.ScalarFloat):
				typeDef, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
					Field: "withKind",
					Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindFloat}},
				})
			case string(introspection.ScalarBoolean):
				typeDef, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
					Field: "withKind",
					Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindBoolean}},
				})
			case string(introspection.ScalarVoid):
				typeDef, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
					Field: "withKind",
					Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindVoid}},
				})
			default:
				typeDef, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
					Field: "withScalar",
					Args: []dagql.NamedInput{
						{Name: "name", Value: dagql.String(introspectionType.Name)},
						{Name: "description", Value: dagql.String(introspectionType.Description)},
					},
				})
			}
			if err != nil {
				return nil, err
			}
			typeDefs = append(typeDefs, typeDef)

		case introspection.TypeKindEnum:
			var enum dagql.ObjectResult[*core.EnumTypeDef]
			if err := dag.Select(ctx, dag.Root(), &enum, dagql.Selector{
				Field: "__enumTypeDef",
				Args: []dagql.NamedInput{
					{Name: "name", Value: dagql.String(introspectionType.Name)},
					{Name: "description", Value: dagql.String(introspectionType.Description)},
				},
			}); err != nil {
				return nil, err
			}

			for _, value := range introspectionType.EnumValues {
				var member dagql.ObjectResult[*core.EnumMemberTypeDef]
				if err := dag.Select(ctx, dag.Root(), &member, dagql.Selector{
					Field: "__enumMemberTypeDef",
					Args: []dagql.NamedInput{
						{Name: "name", Value: dagql.String(value.Name)},
						{Name: "value", Value: dagql.String(value.Directives.EnumValue())},
						{Name: "description", Value: dagql.String(value.Description)},
						{Name: "deprecated", Value: core.OptString(value.DeprecationReason)},
					},
				}); err != nil {
					return nil, err
				}
				memberID, err := core.ResultIDInput(member)
				if err != nil {
					return nil, err
				}
				if err := dag.Select(ctx, enum, &enum, dagql.Selector{
					Field: "__withMember",
					Args:  []dagql.NamedInput{{Name: "member", Value: memberID}},
				}); err != nil {
					return nil, err
				}
			}
			enumID, err := core.ResultIDInput(enum)
			if err != nil {
				return nil, err
			}
			typeDef, err := core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
				Field: "__withEnumTypeDef",
				Args:  []dagql.NamedInput{{Name: "enumTypeDef", Value: enumID}},
			})
			if err != nil {
				return nil, err
			}
			typeDefs = append(typeDefs, typeDef)

		default:
			return nil, fmt.Errorf("unexpected type kind %q for %q", introspectionType.Kind, introspectionType.Name)
		}
	}
	return typeDefs, nil
}

// CoreModScalar represents scalars from core (Platform, etc)
type CoreModScalar struct {
	coreMod *CoreMod
	name    string
}

var _ core.ModType = (*CoreModScalar)(nil)

func (obj *CoreModScalar) ConvertFromSDKResult(ctx context.Context, value any) (dagql.AnyResult, error) {
	state, err := obj.coreMod.viewState(ctx)
	if err != nil {
		return nil, err
	}
	s, ok := state.server.ScalarType(obj.name)
	if !ok {
		return nil, fmt.Errorf("CoreModScalar.ConvertFromSDKResult: found no scalar type")
	}

	input, err := s.DecodeInput(value)
	if err != nil {
		return nil, fmt.Errorf("CoreModScalar.ConvertFromSDKResult: failed to decode input: %w", err)
	}
	return dagql.NewResultForCurrentCall(ctx, input)
}

func (obj *CoreModScalar) ConvertToSDKInput(ctx context.Context, value dagql.Typed) (any, error) {
	state, err := obj.coreMod.viewState(ctx)
	if err != nil {
		return nil, err
	}
	s, ok := state.server.ScalarType(obj.name)
	if !ok {
		return nil, fmt.Errorf("CoreModScalar.ConvertToSDKInput: found no scalar type")
	}
	val, ok := value.(dagql.Scalar[dagql.String])
	if !ok {
		// we assume all core scalars are strings
		return nil, fmt.Errorf("CoreModScalar.ConvertToSDKInput: core scalar should be string")
	}
	return s.DecodeInput(string(val.Value))
}

func (obj *CoreModScalar) CollectContent(ctx context.Context, value dagql.AnyResult, content *core.CollectedContent) error {
	if value == nil {
		return content.CollectJSONable(nil)
	}
	return content.CollectJSONable(value.Unwrap())
}

func (obj *CoreModScalar) SourceMod() core.Mod {
	return obj.coreMod
}

func (obj *CoreModScalar) TypeDef(ctx context.Context) (dagql.ObjectResult[*core.TypeDef], error) {
	state, err := obj.coreMod.viewState(ctx)
	if err != nil {
		return dagql.ObjectResult[*core.TypeDef]{}, err
	}
	return core.SelectTypeDefWithServer(ctx, state.server, dagql.Selector{
		Field: "withScalar",
		Args: []dagql.NamedInput{
			{Name: "name", Value: dagql.String(obj.name)},
		},
	})
}

// CoreModObject represents objects from core (Container, Directory, etc.)
type CoreModObject struct {
	coreMod *CoreMod
	name    string
}

var _ core.ModType = (*CoreModObject)(nil)

func (obj *CoreModObject) ConvertFromSDKResult(ctx context.Context, value any) (dagql.AnyResult, error) {
	if value == nil {
		// TODO remove if this is OK. Why is this not handled by a wrapping Nullable instead?
		slog.ExtraDebug("CoreModObject.ConvertFromSDKResult: got nil value")
		return nil, nil
	}

	if res, ok := value.(dagql.AnyResult); ok {
		return res, nil
	}

	id, ok := value.(string)
	if !ok {
		return nil, fmt.Errorf("expected string, got %T", value)
	}
	var idp call.ID
	if err := idp.Decode(id); err != nil {
		return nil, err
	}
	if !idp.IsHandle() && idp.Type() == nil {
		return nil, fmt.Errorf("empty %s ID", obj.name)
	}

	dag, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("current dagql server: %w", err)
	}
	// Module-returned recipes are evaluated in the caller's context. Check
	// replayability before and during loading so a forged return ID cannot
	// execute client-dependent operations with the caller's authority.
	val, err := dag.LoadReplayable(ctx, &idp)
	if err != nil {
		return nil, fmt.Errorf("cannot replay module return ID: %w", err)
	}
	return val, nil
}

func (obj *CoreModObject) ConvertToSDKInput(ctx context.Context, value dagql.Typed) (any, error) {
	if value == nil {
		return nil, nil
	}
	switch x := value.(type) {
	case dagql.Input:
		return x, nil
	case dagql.AnyResult:
		id, err := x.ID()
		if err != nil {
			return nil, err
		}
		if id == nil {
			return nil, nil
		}
		return id.Encode()
	default:
		return nil, fmt.Errorf("%T.ConvertToSDKInput: unknown type %T", obj, value)
	}
}

func (obj *CoreModObject) CollectContent(ctx context.Context, value dagql.AnyResult, content *core.CollectedContent) error {
	if value == nil {
		if err := content.CollectJSONable(nil); err != nil {
			return fmt.Errorf("collect_jsonable nil core object %q: %w", obj.name, err)
		}
		return nil
	}
	switch x := value.(type) {
	case dagql.Input:
		if err := content.CollectJSONable(x); err != nil {
			return fmt.Errorf("collect_jsonable input core object %q (%T): %w", obj.name, x, err)
		}
		return nil
	case dagql.AnyResult:
		id, err := x.ID()
		if err != nil {
			return fmt.Errorf("resolve result ID core object %q (%T): %w", obj.name, x, err)
		}
		if err := content.CollectID(ctx, id, false); err != nil {
			return fmt.Errorf("collect_id core object %q (%T): %w", obj.name, x, err)
		}
		return nil
	default:
		unwrapped := value.Unwrap()
		if err := content.CollectJSONable(unwrapped); err != nil {
			return fmt.Errorf("collect_jsonable unwrapped core object %q (%T): %w", obj.name, unwrapped, err)
		}
		return nil
	}
}

func (obj *CoreModObject) SourceMod() core.Mod {
	return obj.coreMod
}

func (obj *CoreModObject) TypeDef(ctx context.Context) (dagql.ObjectResult[*core.TypeDef], error) {
	// TODO: to support matching core types against interfaces, we will need to actually fill
	// this out with the functions rather than just name
	state, err := obj.coreMod.viewState(ctx)
	if err != nil {
		return dagql.ObjectResult[*core.TypeDef]{}, err
	}
	return core.SelectTypeDefWithServer(ctx, state.server, dagql.Selector{
		Field: "withObject",
		Args: []dagql.NamedInput{
			{Name: "name", Value: dagql.String(obj.name)},
		},
	})
}

type CoreModEnum struct {
	coreMod *CoreMod
	typeDef *core.EnumTypeDef
}

var _ core.ModType = (*CoreModEnum)(nil)

func (enum *CoreModEnum) ConvertFromSDKResult(ctx context.Context, value any) (dagql.AnyResult, error) {
	if enum, ok := value.(*core.ModuleEnum); ok {
		value = enum.Name
	}
	state, err := enum.coreMod.viewState(ctx)
	if err != nil {
		return nil, err
	}
	s, ok := state.server.ScalarType(enum.typeDef.Name)
	if !ok {
		return nil, fmt.Errorf("CoreModEnum.ConvertFromSDKResult: found no enum type")
	}

	input, err := s.DecodeInput(value)
	if err != nil {
		return nil, fmt.Errorf("CoreModEnum.ConvertFromSDKResult: failed to decode input: %w", err)
	}
	return dagql.NewResultForCurrentCall(ctx, input)
}

func (enum *CoreModEnum) ConvertToSDKInput(ctx context.Context, value dagql.Typed) (any, error) {
	var input any = value
	if enum, ok := value.(*core.ModuleEnum); ok {
		input = enum.Name
	}
	state, err := enum.coreMod.viewState(ctx)
	if err != nil {
		return nil, err
	}
	s, ok := state.server.ScalarType(enum.typeDef.Name)
	if !ok {
		return nil, fmt.Errorf("CoreModEnum.ConvertToSDKInput: found no enum type")
	}
	return s.DecodeInput(input)
}

func (enum *CoreModEnum) CollectContent(ctx context.Context, value dagql.AnyResult, content *core.CollectedContent) error {
	if value == nil {
		return content.CollectJSONable(nil)
	}
	return content.CollectJSONable(value.Unwrap())
}

func (enum *CoreModEnum) SourceMod() core.Mod {
	return enum.coreMod
}

func (enum *CoreModEnum) TypeDef(ctx context.Context) (dagql.ObjectResult[*core.TypeDef], error) {
	var sourceMap dagql.Optional[dagql.ID[*core.SourceMap]]
	var err error
	if enum.typeDef.SourceMap.Valid {
		sourceMap, err = core.OptionalResultIDInput(enum.typeDef.SourceMap.Value)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, err
		}
	}
	state, err := enum.coreMod.viewState(ctx)
	if err != nil {
		return dagql.ObjectResult[*core.TypeDef]{}, err
	}
	return core.SelectTypeDefWithServer(ctx, state.server, dagql.Selector{
		Field: "withEnum",
		Args: []dagql.NamedInput{
			{Name: "name", Value: dagql.String(enum.typeDef.OriginalName)},
			{Name: "description", Value: dagql.String(enum.typeDef.Description)},
			{Name: "sourceMap", Value: sourceMap},
			{Name: "sourceModuleName", Value: core.OptSourceModuleName(enum.typeDef.SourceModuleName)},
		},
	})
}

func maybeOptional(ctx context.Context, dag *dagql.Server, inst dagql.ObjectResult[*core.TypeDef], nonNull bool) (dagql.ObjectResult[*core.TypeDef], error) {
	if nonNull {
		return inst, nil
	}
	if err := dag.Select(ctx, inst, &inst, dagql.Selector{
		Field: "withOptional",
		Args:  []dagql.NamedInput{{Name: "optional", Value: dagql.Boolean(true)}},
	}); err != nil {
		return inst, fmt.Errorf("make typedef optional: %w", err)
	}
	return inst, nil
}

// resolveArgTypeDef converts an introspection arg's TypeRef into a TypeDef,
// also handling the unified ID scalar via @expectedType directives.
func resolveArgTypeDef(ctx context.Context, dag *dagql.Server, arg introspection.InputValue) (dagql.ObjectResult[*core.TypeDef], bool, error) {
	argType, ok, err := introspectionRefToTypeDef(ctx, dag, arg.TypeRef, false)
	if err != nil || !ok {
		return argType, ok, err
	}

	if expectedName := arg.Directives.ExpectedType(); expectedName != "" {
		resolved, changed, err := resolveIDScalar(ctx, dag, argType, expectedName)
		if err != nil || changed {
			return resolved, changed, err
		}
	}

	return argType, true, nil
}

func resolveIDScalar(ctx context.Context, dag *dagql.Server, typeDef dagql.ObjectResult[*core.TypeDef], expectedName string) (dagql.ObjectResult[*core.TypeDef], bool, error) {
	self := typeDef.Self()
	switch self.Kind {
	case core.TypeDefKindScalar:
		if !self.AsScalar.Valid {
			return typeDef, false, nil
		}
		scalar := self.AsScalar.Value.Self()
		if scalar.OriginalName != "ID" && scalar.Name != "ID" {
			return typeDef, false, nil
		}

		field := "withObject"
		if _, ok := dag.InterfaceType(expectedName); ok {
			field = "withInterface"
		}
		// expectedName comes from the @expectedType directive and is an
		// already-final (possibly module-namespaced) type name; preserve it
		// verbatim rather than collapsing the separator via strcase.ToCamel.
		inst, err := core.SelectReferenceTypeDefWithServer(ctx, dag, field, "name", expectedName)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, !self.Optional)
		return inst, true, err

	case core.TypeDefKindList:
		if !self.AsList.Valid {
			return typeDef, false, nil
		}
		elem, changed, err := resolveIDScalar(ctx, dag, self.AsList.Value.Self().ElementTypeDef, expectedName)
		if err != nil || !changed {
			return typeDef, changed, err
		}
		elemID, err := core.ResultIDInput(elem)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err := core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
			Field: "withListOf",
			Args:  []dagql.NamedInput{{Name: "elementType", Value: elemID}},
		})
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, !self.Optional)
		return inst, true, err
	}

	return typeDef, false, nil
}

func introspectionRefToTypeDef(ctx context.Context, dag *dagql.Server, introspectionType *introspection.TypeRef, nonNull bool) (dagql.ObjectResult[*core.TypeDef], bool, error) {
	switch introspectionType.Kind {
	case introspection.TypeKindNonNull:
		return introspectionRefToTypeDef(ctx, dag, introspectionType.OfType, true)

	case introspection.TypeKindScalar:
		var (
			inst dagql.ObjectResult[*core.TypeDef]
			err  error
		)
		switch introspectionType.Name {
		case string(introspection.ScalarString):
			inst, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
				Field: "withKind",
				Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindString}},
			})
		case string(introspection.ScalarInt):
			inst, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
				Field: "withKind",
				Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindInteger}},
			})
		case string(introspection.ScalarFloat):
			inst, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
				Field: "withKind",
				Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindFloat}},
			})
		case string(introspection.ScalarBoolean):
			inst, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
				Field: "withKind",
				Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindBoolean}},
			})
		case string(introspection.ScalarVoid):
			inst, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
				Field: "withKind",
				Args:  []dagql.NamedInput{{Name: "kind", Value: core.TypeDefKindVoid}},
			})
		default:
			// introspectionType.Name is an already-final (possibly module-namespaced)
			// GraphQL type name; preserve it verbatim. A bare withScalar would run it
			// back through strcase.ToCamel, collapsing the namespace separator.
			inst, err = core.SelectReferenceTypeDefWithServer(ctx, dag, "withScalar", "name", introspectionType.Name)
		}
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, nonNull)
		return inst, true, err

	case introspection.TypeKindEnum:
		// Preserve the already-final type name verbatim; see the scalar case above.
		inst, err := core.SelectReferenceTypeDefWithServer(ctx, dag, "withEnum", "name", introspectionType.Name)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, nonNull)
		return inst, true, err

	case introspection.TypeKindList:
		elementTypeDef, ok, err := introspectionRefToTypeDef(ctx, dag, introspectionType.OfType, false)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, fmt.Errorf("failed to convert list element type: %w", err)
		}
		if !ok {
			return dagql.ObjectResult[*core.TypeDef]{}, false, nil
		}
		elementTypeDefID, err := core.ResultIDInput(elementTypeDef)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err := core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
			Field: "withListOf",
			Args:  []dagql.NamedInput{{Name: "elementType", Value: elementTypeDefID}},
		})
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, nonNull)
		return inst, true, err

	case introspection.TypeKindObject:
		// Preserve the already-final type name verbatim; see the scalar case above.
		inst, err := core.SelectReferenceTypeDefWithServer(ctx, dag, "withObject", "name", introspectionType.Name)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, nonNull)
		return inst, true, err

	case introspection.TypeKindInterface:
		// Preserve the already-final type name verbatim; see the scalar case above.
		inst, err := core.SelectReferenceTypeDefWithServer(ctx, dag, "withInterface", "name", introspectionType.Name)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, nonNull)
		return inst, true, err

	case introspection.TypeKindInputObject:
		var inst dagql.ObjectResult[*core.TypeDef]
		var input dagql.ObjectResult[*core.InputTypeDef]
		if err := dag.Select(ctx, dag.Root(), &input, dagql.Selector{
			Field: "__inputTypeDef",
			Args:  []dagql.NamedInput{{Name: "name", Value: dagql.String(introspectionType.Name)}},
		}); err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inputID, err := core.ResultIDInput(input)
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = core.SelectTypeDefWithServer(ctx, dag, dagql.Selector{
			Field: "__withInputTypeDef",
			Args:  []dagql.NamedInput{{Name: "inputTypeDef", Value: inputID}},
		})
		if err != nil {
			return dagql.ObjectResult[*core.TypeDef]{}, false, err
		}
		inst, err = maybeOptional(ctx, dag, inst, nonNull)
		return inst, true, err

	default:
		return dagql.ObjectResult[*core.TypeDef]{}, false, fmt.Errorf("unexpected type kind %q for %q", introspectionType.Kind, introspectionType.Name)
	}
}
