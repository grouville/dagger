from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
subprocess.run([str(Path(go).with_name('gofmt')), '-w', str(p / 'after-coremod.go'),
                str(p / 'coremod_memo_identity_test.go')], check=True)
rows = []
for label, arm, pattern, packages in [
    ('regression-before', 'before', '^TestCoreProvidersReuseSchemaMemo$', ['./core/schema']),
    ('core-schema-after', 'after', '^Test(CoreProviders|SchemaBuilder|RecoveredSchemas|ArtifactSchema|ModDepsForCall|.*CoreSchema.*|.*CoreMod.*)', ['./core', './core/schema']),
]:
    command = [go, 'test', '-p', '2', '-buildvcs=false', '-overlay', str(p / (arm + '-overlay.json')),
               '-race', '-count=1', '-run', pattern, *packages]
    start = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd='/tmp/dagger-recovered-schema-templates', env=env,
                                stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, arm=arm, command=command, exit_code=result.returncode, seconds=time.monotonic() - start))
    (p / 'validation.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    if arm == 'before':
        assert result.returncode != 0
        assert 'the same base and API view describe the same core schema' in (p / (label + '.log')).read_text()
    else:
        assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]
