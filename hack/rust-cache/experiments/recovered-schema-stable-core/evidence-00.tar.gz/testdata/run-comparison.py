from pathlib import Path
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
module_study = p.parent / 'go-stored-library-root'
rows = []


def mode(route, enabled):
    request = urllib.request.Request('http://127.0.0.1:16104/debug/' + route + '?enabled=' + str(enabled).lower(), data=b'')
    with urllib.request.urlopen(request, timeout=30) as response:
        assert json.load(response)['enabled'] == enabled


for label, command in [
    ('install', ['python3', str(p / 'install-engine.py')]),
    ('verify-and-profile', ['python3', str(p / 'verify-and-profile.py')]),
    ('fixed-comparison', ['python3', str(module_study / 'measure-stable-core.py'), '--output',
                          str(module_study / 'paired-stable-core'), '--pairs', '5', '--languages', 'go']),
]:
    start = time.monotonic()
    with (p / (label + '-driver.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start))
    (p / 'pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '-driver.log')).read_text()[-6000:]

try:
    for route in ['recovered-schema-templates', 'canonical-core-providers']:
        mode(route, True)
    command = ['python3', str(p.parent / 'trivial-scalar-projection/verify_retained_first.py'),
               'recovered-schema-stable-core-after-cohort']
    start = time.monotonic()
    with (p / 'retained-after-cohort.log').open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    (p / 'retained-after-cohort.json').write_text(json.dumps(dict(command=command,
        exit_code=result.returncode, seconds=time.monotonic() - start), indent=2) + '\n')
    assert result.returncode == 0, (p / 'retained-after-cohort.log').read_text()[-5000:]
finally:
    for route in ['recovered-schema-templates', 'canonical-core-providers']:
        mode(route, False)
