from pathlib import Path
import json
import shutil
import subprocess
import time
import urllib.request

p = Path(__file__).parent
module_study = p.parent / 'go-stored-library-root'
debug = 'http://127.0.0.1:16104/debug/'


def get(route, data=None):
    with urllib.request.urlopen(urllib.request.Request(debug + route, data=data), timeout=30) as response:
        return json.load(response)


def mode(enabled):
    assert get('recovered-schema-templates?enabled=' + str(enabled).lower(), b'')['enabled'] == enabled
    assert get('canonical-core-providers?enabled=' + str(enabled).lower(), b'')['enabled'] == enabled


activation = json.loads((p / 'activation.json').read_text())
retained = json.loads((p / 'retained-first-after.json').read_text())
assert activation['same_mounts'] and retained['exit_code'] == 0
assert retained['controls_during']['recovered-schema-templates']['enabled']
assert retained['controls_during']['canonical-core-providers']['enabled']
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == dict(mutex_fraction=0, block_profile_rate_ns=0)
assert not get('metadata-snapshot-unlocked')['enabled']
assert not get('upstream-log-queue')['enabled']
assert not get('recovered-schema-templates')['enabled']

original = module_study / 'engine8e-module-correctness'
assert not original.exists()
original.mkdir()
for source in [module_study / name for name in ['check-plan.json', 'correctness.json', 'correctness-restoration.json']]:
    shutil.copyfile(source, original / source.name)
for source in module_study.glob('go-dev-*.log'):
    shutil.copyfile(source, original / source.name)

rows = []
try:
    mode(True)
    for label, command, output_dir in [
        ('module-checks', ['python3', str(module_study / 'verify.py')], p),
        ('profile', ['python3', str(module_study / 'capture-stable-core.py'), '--output',
                     str(module_study / 'capture-stable-core'), '--pairs', '1', '--languages', 'go'], module_study),
        ('causal-analysis', ['python3', str(module_study / 'analyze-stable-core.py')], module_study),
        ('work-reduction', ['python3', str(module_study / 'analyze-work-stable-core.py')], module_study),
    ]:
        start = time.monotonic()
        with (output_dir / (label + '-driver.log')).open('w') as output:
            result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
        rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start))
        (p / 'profile-pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(label, result.returncode, flush=True)
        assert result.returncode == 0, (output_dir / (label + '-driver.log')).read_text()[-5000:]
finally:
    mode(False)
    (p / 'profile-restored-state.json').write_text(json.dumps(dict(
        recovered_schema_templates=get('recovered-schema-templates'),
        canonical_core_providers=get('canonical-core-providers'),
        metadata=get('metadata-snapshot-unlocked'), logging=get('upstream-log-queue'),
        profiling=get('wcprof/enabled'), locks=get('lock-profiler')), indent=2) + '\n')
