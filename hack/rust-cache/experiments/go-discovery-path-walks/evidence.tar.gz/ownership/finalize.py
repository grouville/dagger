from pathlib import Path
import hashlib,json,subprocess,urllib.request
p=Path(__file__).parent
previous=json.loads(Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-runtime-preparation-current/final-state.json').read_text())
def get(route):
 with urllib.request.urlopen('http://127.0.0.1:16108/debug/'+route,timeout=15) as f:return json.load(f)
binaries={}
for name,expected in previous['binaries'].items():
 binaries[name]=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
 assert binaries[name]==expected,(name,binaries[name],expected)
flags={route:get(route) for route in previous['flags']}
for route,expected in previous['flags'].items():
 assert flags[route]['enabled']==(expected if isinstance(expected,bool) else expected['enabled']),(route,flags[route],expected)
lifecycle=get('client-lifecycle')
assert lifecycle['active_requests']==0 and lifecycle['runtimes']==0
assert all(s['state']=='removed' for s in (lifecycle.get('sessions') or []))
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
real=Path('/tmp/dagger-go-real-repository-main')
assert subprocess.check_output(['git','status','--porcelain'],cwd=real)==b''
assert subprocess.check_output(['git','status','--porcelain'],cwd='/tmp/dagger-go-indexed-owner-facts')==b''
plan=json.loads((p/'plan.json').read_text())
assert hashlib.sha256(Path('/tmp/dagger-go-ownership-single-pass/gomod/main.dang').read_bytes()).hexdigest()==plan['production_sha256']
state=dict(binaries=binaries,flags=flags,lifecycle=lifecycle,wcprof=get('wcprof/enabled'),lock_profiler=get('lock-profiler'),real_workspace_clean=True,baseline_module_clean=True,production_hash_matches_checked_and_timed_source=True,engine_cache_retained=True,cold_performance_unmeasured=True,rust_latency_gain_unmeasured=True,new_pr_opened=False)
(p/'final-state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(dict(binaries=binaries,active_requests=lifecycle['active_requests'],runtimes=lifecycle['runtimes'],all_original_flags_restored=True,real_workspace_clean=True,baseline_module_clean=True)),flush=True)
