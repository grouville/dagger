from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
p=Path(__file__).parent
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-discovery-path-walks')
out.mkdir(parents=True,exist_ok=False)
roots={'headers':p.parent/'go-batched-module-headers','ownership':p}
count=0
for root in roots.values():
 for d in sorted(root.glob('capture-*')):
  if not d.is_dir():continue
  chunks=sorted(d.glob('chunk-*.ndjson.gz'));events=[]
  for f in chunks:
   lines=gzip.decompress(f.read_bytes()).splitlines();header=json.loads(lines[0]);events.extend(lines[1:]);assert header['dropped_events']==0
  complete=(json.dumps(dict(header,event_count=len(events)))+'\n').encode()+b'\n'.join(events)+b'\n'
  assert complete==(d/'wcprof-complete.ndjson').read_bytes()
  assert not header.get('open_ops');count+=1
with (p/'baseline-module.tar').open('wb') as f:subprocess.run(['git','archive','--format=tar','de633b12ed2aa02e42adb698a23fcecc13faf36d'],cwd='/tmp/dagger-go-indexed-owner-facts',stdout=f,check=True)
files=[]
for label,root in roots.items():
 for f in sorted(root.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and f.name!='wcprof-complete.ndjson':files.append((label+'/'+str(f.relative_to(root)),f))
manifest=[dict(path=name,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for name,f in files]
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();archive=out/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,f in files:
  info=tar.gettarinfo(str(f),arcname=name);info.mtime=0
  with f.open('rb') as source:tar.addfile(info,source)
 info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mtime=0;tar.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  payload=tar.extractfile(row['path']).read();assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
 assert tar.extractfile('manifest.json').read()==manifest_bytes
(out/'manifest.json').write_bytes(manifest_bytes)
for label,root in roots.items():
 for name in ['assessment.json','plan.json','candidate.patch']:(out/(label+'-'+name)).write_bytes((root/name).read_bytes())
(out/'final-state.json').write_bytes((p/'final-state.json').read_bytes())
metadata=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files)+1,all_member_hashes_verified=True,losslessly_reconstructed_wcprof_streams=count)
(out/'archive.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata),flush=True)
