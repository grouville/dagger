package core

import (
	"context"
	"fmt"
	"sync"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
)

// The index belongs to one immutable collection value. Subsets receive a new
// index; decoding rebuilds it. It retains neither a client nor a context.
type collectionStoredIndex struct {
	mu     sync.Mutex
	ready  bool
	keys   map[string]bool
	values map[string]any
}

func (index *collectionStoredIndex) lookup(ctx context.Context, obj *ModuleObject, members *CollectionMembers, key string) (any, error) {
	index.mu.Lock()
	defer index.mu.Unlock()
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if !index.ready {
		keys, err := obj.collectionKeys(ctx)
		if err != nil {
			return nil, err
		}
		selected := make(map[string]bool, len(keys))
		for _, key := range keys {
			selected[key.text] = true
		}
		values, err := obj.storedCollectionValues(ctx, members)
		if err != nil {
			return nil, err
		}
		index.keys, index.values, index.ready = selected, values, true
	}
	if !index.keys[key] {
		return nil, fmt.Errorf("collection %q does not contain key %q in the current subset", obj.TypeDef.Name, key)
	}
	value, found := index.values[key]
	if !found {
		return nil, fmt.Errorf("collection %q has no stored value for key %q", obj.TypeDef.Name, key)
	}
	return value, nil
}

func (obj *ModuleObject) storedCollectionValues(ctx context.Context, members *CollectionMembers) (map[string]any, error) {
	stored := members.Get.Stored
	rows, err := collectionSliceValues(obj.Fields[stored.Field.OriginalName])
	if err != nil {
		return nil, fmt.Errorf("collection %q stored entries: %w", obj.TypeDef.Name, err)
	}
	keyType := members.Get.KeyType.Self().ToInput()
	var enumType ModType
	if members.Get.KeyType.Self().Kind == TypeDefKindEnum {
		var found bool
		enumType, found, err = NewUserMod(obj.Module).ModTypeFor(ctx, members.Get.KeyType.Self(), true)
		if err != nil || !found {
			return nil, fmt.Errorf("collection stored enum key type not found: %w", err)
		}
	}
	values := make(map[string]any, len(rows))
	for i, row := range rows {
		fields, err := storedEntryFields(ctx, obj, stored, row)
		if err != nil {
			return nil, fmt.Errorf("stored entry %d: %w", i, err)
		}
		rawKey := fields[stored.Key.OriginalName]
		if rawKey == nil {
			return nil, fmt.Errorf("stored entry %d has a null key", i)
		}
		input, err := keyType.Decoder().DecodeInput(rawKey)
		if enumType != nil {
			converted, convertErr := enumType.ConvertFromSDKResult(ctx, rawKey)
			err = convertErr
			if err == nil {
				var ok bool
				input, ok = converted.Unwrap().(dagql.Input)
				if !ok {
					return nil, fmt.Errorf("stored enum key %T is not an input", converted.Unwrap())
				}
			}
		}
		if err != nil {
			return nil, fmt.Errorf("stored entry %d key: %w", i, err)
		}
		key, err := collectionKeyFromInput(input)
		if err != nil {
			return nil, err
		}
		if _, found := values[key.text]; found {
			return nil, fmt.Errorf("collection %q has duplicate stored key %q", obj.TypeDef.Name, key.text)
		}
		value := fields[stored.Value.OriginalName]
		if value == nil {
			return nil, fmt.Errorf("stored entry %d has a null value", i)
		}
		values[key.text] = value
	}
	return values, nil
}

func storedEntryFields(ctx context.Context, obj *ModuleObject, stored *CollectionStoredGetter, row any) (map[string]any, error) {
	switch row := row.(type) {
	case map[string]any:
		return row, nil
	case *ModuleObject:
		return row.Fields, nil
	case dagql.AnyResult:
		if value, ok := dagql.UnwrapAs[*ModuleObject](row); ok {
			return value.Fields, nil
		}
	case string:
		entryType := stored.Field.TypeDef.Self().AsList.Value.Self().ElementTypeDef.Self()
		typ, found, err := NewUserMod(obj.Module).ModTypeFor(ctx, entryType, true)
		if err != nil || !found {
			return nil, fmt.Errorf("stored entry type not found: %w", err)
		}
		entry, err := typ.ConvertFromSDKResult(ctx, row)
		if err != nil {
			return nil, err
		}
		if value, ok := dagql.UnwrapAs[*ModuleObject](entry); ok {
			return value.Fields, nil
		}
	}
	return nil, fmt.Errorf("expected a stored entry object, got %T", row)
}

func (obj *ModuleObject) storedCollectionGet(ctx context.Context, members *CollectionMembers, moduleID *dagql.ResultCallModule, provider dagql.FieldModuleProvider) (dagql.Field[*ModuleObject], error) {
	valueType, found, err := NewUserMod(obj.Module).ModTypeFor(ctx, members.Get.ReturnType.Self(), true)
	if err != nil {
		return dagql.Field[*ModuleObject]{}, fmt.Errorf("stored collection value type not found: %w", err)
	}
	if !found {
		return dagql.Field[*ModuleObject]{}, fmt.Errorf("stored collection value type %s not found in module %s", members.Get.ReturnType.Self().ToType(), obj.Module.Self().Name())
	}
	return dagql.Field[*ModuleObject]{
		Spec: &dagql.FieldSpec{
			Name: "get", Description: members.Get.Description, Type: members.Get.ReturnType.Self().ToTyped(), Module: moduleID, ModuleProvider: provider,
			Args: dagql.NewInputSpecs(dagql.InputSpec{Name: "key", Type: members.Get.KeyType.Self().ToInput()}),
		},
		Func: func(ctx context.Context, self dagql.ObjectResult[*ModuleObject], args map[string]dagql.Input, _ call.View) (dagql.AnyResult, error) {
			key, err := collectionKeyFromInput(args["key"])
			if err != nil {
				return nil, err
			}
			if self.Self().collectionItems == nil {
				return nil, fmt.Errorf("stored collection has not been initialized")
			}
			raw, err := self.Self().collectionItems.lookup(ctx, self.Self(), members, key.text)
			if err != nil {
				return nil, err
			}
			value, err := valueType.ConvertFromSDKResult(ctx, raw)
			if err != nil {
				return nil, err
			}
			if _, moduleObject := valueType.(*ModuleObjectType); moduleObject && collectionGetterContentEnabled.Load() {
				current := dagql.CurrentCall(ctx)
				if current == nil || current.Module == nil {
					return nil, fmt.Errorf("stored collection getter has no module provenance")
				}
				scope := &dagql.ResultCall{Kind: dagql.ResultCallKindSynthetic, SyntheticOp: "collection-item-content", Type: dagql.NewResultCallType(value.Type()), Module: current.Module, View: current.View}
				digest, err := scope.ContentPreferredDigest(ctx)
				if err != nil {
					return nil, err
				}
				content := NewCollectedContent()
				if err := content.CollectJSONable(digest); err != nil {
					return nil, err
				}
				if err := valueType.CollectContent(ctx, value, content); err != nil {
					return nil, err
				}
				return value.WithContentDigestAny(ctx, content.Digest())
			}
			return value, nil
		},
	}, nil
}
