package core

import (
	"context"
	"fmt"
	"sync"
	"testing"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	"github.com/stretchr/testify/require"
)

func storedCollectionFixture(t *testing.T, f *moduleOwnershipTest, ctx context.Context, variant, childName string) (func(string, []any, []any) dagql.ObjectResult[*ModuleObject], *collectionContentRuntime) {
	t.Helper()
	mod := f.module(ctx, "packages", moduleOwnershipModuleOpts{variant: variant})
	runtime := &collectionContentRuntime{moduleOwnershipRuntime: f.runtime}
	mod.Self().Source.Value.Self().SDKImpl = runtime
	parent := mod.Self().ObjectDefs[0].Self().AsObject.Value.Self().Clone()
	childType := moduleOwnershipTypeDef(t, f.dag, childName, false)
	child := childType.Self().AsObject.Value.Self()
	stringType := parent.Functions[0].Self().ReturnType
	keyList := newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-key-list", &ListTypeDef{ElementTypeDef: stringType})
	keysType := newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-keys-type", (&TypeDef{}).WithListOf(keyList))
	entry := NewObjectTypeDef(childName+"Entry", "", nil)
	entry.Fields = dagql.ObjectResultArray[*FieldTypeDef]{
		newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-key", NewFieldTypeDef("key", stringType, "", nil)),
		newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-value", NewFieldTypeDef("value", childType, "", nil)),
	}
	entryDef := newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-entry-def", entry)
	entryType := newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-entry-type", (&TypeDef{}).WithObjectTypeDef(entryDef))
	entriesList := newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-entries-list", &ListTypeDef{ElementTypeDef: entryType})
	entriesType := newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-entries-type", (&TypeDef{}).WithListOf(entriesList))
	parent.Fields = append(parent.Fields,
		newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-keys-field", NewFieldTypeDef("keys", keysType, "", nil)),
		newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-entries-field", NewFieldTypeDef("entries", entriesType, "", nil)),
	)
	parent.Functions = parent.Functions[:1]
	parent.Collection = &CollectionConfig{Enabled: true, Get: "entries"}
	parentDef := newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-parent-def", parent)
	mod.Self().ObjectDefs[0] = newTypeDefDetachedResult(t, f.dag, "stored-"+variant+"-"+childName+"-parent-type", (&TypeDef{}).WithObjectTypeDef(parentDef))
	mod.Self().ObjectDefs = append(mod.Self().ObjectDefs, childType, entryType)
	f.install(ctx, f.dag, mod)
	require.NoError(t, (&ModuleObject{Module: mod, TypeDef: child}).Install(ctx, f.dag))
	makeValue := func(version string, keys, entries []any) dagql.ObjectResult[*ModuleObject] {
		t.Helper()
		obj := &ModuleObject{Module: mod, TypeDef: parent, Fields: map[string]any{"keys": keys, "entries": entries, "message": version}}
		frame := moduleObjectTestSyntheticCall("stored-"+variant+"-"+childName+"-"+version, obj)
		detached, err := dagql.NewObjectResultForCall(obj, f.dag, frame)
		require.NoError(t, err)
		attached, err := f.cache.GetOrInitCall(ctx, "stored-"+variant+"-"+childName+"-items", f.dag, &dagql.CallRequest{ResultCall: frame}, dagql.ValueFunc(detached))
		require.NoError(t, err)
		return attached.(dagql.ObjectResult[*ModuleObject])
	}
	return makeValue, runtime
}

func storedEntry(key, value string) any {
	return map[string]any{"key": key, "value": map[string]any{"message": value}}
}

func storedGet(ctx context.Context, dag *dagql.Server, collection dagql.ObjectResult[*ModuleObject], key string) (dagql.ObjectResult[*ModuleObject], error) {
	var result dagql.ObjectResult[*ModuleObject]
	err := dag.Select(ctx, collection, &result, dagql.Selector{Field: "get", View: dag.View, Args: []dagql.NamedInput{{Name: "key", Value: dagql.String(key)}}})
	return result, err
}

func TestStoredCollectionLookupAndSubset(t *testing.T) {
	f := newModuleOwnershipTest(t)
	ctx := f.session("stored-lookup")
	makeValue, runtime := storedCollectionFixture(t, f, ctx, "", "Package")
	keys, entries := []any{}, []any{}
	for i := range 32 {
		keys = append(keys, fmt.Sprint(i))
		entries = append([]any{storedEntry(fmt.Sprint(i), fmt.Sprintf("value-%d", i))}, entries...)
	}
	parent := makeValue("first", keys, entries)
	var group sync.WaitGroup
	errors := make(chan error, 32)
	for i := range 32 {
		group.Go(func() {
			value, err := storedGet(ctx, f.dag, parent, fmt.Sprint(i))
			if err != nil {
				errors <- err
			} else if value.Self().Fields["message"] != fmt.Sprintf("value-%d", i) {
				errors <- fmt.Errorf("stored key %d selected the wrong entry", i)
			}
		})
	}
	group.Wait()
	close(errors)
	for err := range errors {
		t.Error(err)
	}
	var subset dagql.ObjectResult[*ModuleObject]
	require.NoError(t, f.dag.Select(ctx, parent, &subset, dagql.Selector{Field: "subset", Args: []dagql.NamedInput{{Name: "keys", Value: dagql.DynamicArrayInput{Elem: dagql.String(""), Values: []dagql.Input{dagql.String("2"), dagql.String("0")}}}}}))
	got, err := storedGet(ctx, f.dag, subset, "2")
	require.NoError(t, err)
	require.Equal(t, "value-2", got.Self().Fields["message"])
	_, err = storedGet(ctx, f.dag, subset, "1")
	require.ErrorContains(t, err, "current subset")
	require.EqualValues(t, 0, runtime.gets.Load(), "stored lookup must never invoke the SDK getter")
}

func TestStoredCollectionContentReuse(t *testing.T) {
	f := newModuleOwnershipTest(t)
	ctx := f.session("stored-content")
	makeValue, runtime := storedCollectionFixture(t, f, ctx, "", "Package")
	read := func(version, message string) {
		t.Helper()
		parent := makeValue(version, []any{"a"}, []any{storedEntry("a", message)})
		value, err := storedGet(ctx, f.dag, parent, "a")
		require.NoError(t, err)
		var result string
		require.NoError(t, f.dag.Select(ctx, value, &result, dagql.Selector{Field: "check", Args: []dagql.NamedInput{{Name: "label", Value: dagql.String("read")}}}))
		require.Equal(t, message, result)
	}
	read("first", "stable")
	read("second", "stable")
	require.EqualValues(t, 1, runtime.reads.Load(), "unchanged item must retain its downstream hit")
	read("third", "changed")
	require.EqualValues(t, 2, runtime.reads.Load())
	require.EqualValues(t, 0, runtime.gets.Load())
}

func TestStoredCollectionContentScope(t *testing.T) {
	f := newModuleOwnershipTest(t)
	ctx := f.session("stored-scope")
	var previous string
	for _, scene := range []struct {
		variant, childName, view string
		scoped                   bool
	}{{"first", "Package", "", false}, {"second", "Package", "", false}, {"second", "OtherPackage", "", false}, {"second", "OtherPackage", "other-view", false}, {"second", "OtherPackage", "other-view", true}} {
		dag := newCoreDagqlServerForTest(t, f.root)
		installModuleOwnershipTestClasses(dag)
		installTypeDefTestClasses(dag)
		dag.View = call.View(scene.view)
		f.dag = dag
		f.root.Server.(*moduleObjectTestServer).dag = dag
		makeValue, _ := storedCollectionFixture(t, f, ctx, scene.variant, scene.childName)
		if scene.scoped {
			object, ok := dag.ObjectType("Packages")
			require.True(t, ok)
			class := object.(dagql.Class[*ModuleObject])
			field, ok := class.Field("get", dag.View)
			require.True(t, ok)
			spec := *field.Spec
			spec.ViewFilter = dagql.ExactView(scene.view)
			field.Spec = &spec
			class.Extend(spec, func(ctx context.Context, self dagql.AnyResult, args map[string]dagql.Input) (dagql.AnyResult, error) {
				return field.Func(ctx, self.(dagql.ObjectResult[*ModuleObject]), args, dag.View)
			})
		}
		value, err := storedGet(ctx, dag, makeValue("scope", []any{"a"}, []any{storedEntry("a", "same")}), "a")
		require.NoError(t, err)
		frame, err := value.ResultCall()
		require.NoError(t, err)
		require.NotEmpty(t, frame.ContentDigest())
		current := frame.ContentDigest().String()
		t.Logf("variant=%s type=%s serverView=%s resultView=%s digest=%s", scene.variant, scene.childName, scene.view, frame.View, current)
		if scene.view != "" && !scene.scoped {
			require.Equal(t, previous, current, "global fields retain reuse across unrelated views")
		} else {
			require.NotEqual(t, previous, current, "item identity retains implementation, return type and effective view")
		}
		previous = current
	}
}
