from pathlib import Path
import hashlib
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
plan = json.loads((p / "engine-plan.json").read_text())
steps = json.loads((p / "engine-build-steps.json").read_text())
assert len(steps) == 3 and all(row["exit_code"] == 0 for row in steps)
binary = p / "dagger-engine"
sha = hashlib.sha256(binary.read_bytes()).hexdigest()
assert sha == steps[-1]["sha256"]
name = plan["new_engine"]
assert not subprocess.check_output(["docker", "ps", "-aq", "--filter", "name=^/" + name + "$"], text=True).strip()
assert name not in subprocess.check_output(["docker", "volume", "ls", "--format", "{{.Name}}"], text=True).splitlines()
container = subprocess.check_output([
    "docker", "create", "--name", name, "--label", "codex.task=native-collection-items",
    "--privileged", "-p", "127.0.0.1:16279:1234", "-p", "127.0.0.1:16107:6060",
    "--mount", "type=volume,source=" + name + ",target=/var/lib/dagger",
    plan["image"], *plan["command"],
], text=True).strip()
subprocess.run(["docker", "cp", str(binary), name + ":/usr/local/bin/dagger-engine"], check=True)
seed = p.parent / "go-cold-listing/filesync-snapshot-seeds-mode"
subprocess.run(["docker", "cp", str(seed), name + ":/tmp/filesync-snapshot-seeds-mode"], check=True)
subprocess.run(["docker", "start", name], check=True)
debug = "http://127.0.0.1:16107/debug/"
def get(route, data=None):
    with urllib.request.urlopen(urllib.request.Request(debug + route, data=data), timeout=10) as response:
        return json.load(response)
deadline = time.monotonic() + 90
while True:
    try:
        assert not get("wcprof/enabled")["global_enabled"]
        break
    except OSError:
        assert time.monotonic() < deadline
        time.sleep(.1)
for route, enabled in plan["flags"].items():
    assert get(route + "?enabled=" + str(enabled).lower(), b"")["enabled"] == enabled
actual = subprocess.check_output(["docker", "exec", name, "sha256sum", "/usr/local/bin/dagger-engine"], text=True).split()[0]
assert actual == sha
retained = {}
for other, expected in [
    ("dagger-collection-content-oct18", "053e9d5db9959b04259d48b8fc635721cfc7375652b43953010f767f7bf16118"),
    ("dagger-rust-parser-state-pool-oct14", "1a514c536c6bf10d2463faab2d4e4329f187dd4c0af5f46aba1cbe91460e2fb7"),
]:
    actual = subprocess.check_output(["docker", "exec", other, "sha256sum", "/usr/local/bin/dagger-engine"], text=True).split()[0]
    assert actual == expected
    retained[other] = actual
record = dict(engine=name, container_id=container, sha256=sha, volume=name, new_empty_volume=True,
              flags={r: get(r)["enabled"] for r in plan["flags"]}, retained_engines=retained)
(p / "activation.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(dict(engine=name, sha256=sha, ready=True, retained_engines_unchanged=True)), flush=True)
