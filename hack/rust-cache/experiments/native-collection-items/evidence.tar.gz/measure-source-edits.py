from pathlib import Path
import argparse, hashlib, json, os, signal, statistics, subprocess, sys, time

parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--fixture',choices=['known','real'],required=True)
parser.add_argument('--arms',nargs='+',choices=['before','engine','typed','combined'],default=['before','engine','typed','combined'])
parser.add_argument('--pairs',type=int,default=4)
options=parser.parse_args()
p=Path('/tmp/rust-cache-sipsma-review/typed-artifact-metadata')
sys.argv=[sys.argv[0],'--output',str(options.output),'--pairs',str(options.pairs)]
protocol=p.parent/'rust-go-test-collections/measure.py'
exec(protocol.read_text().split('fixtures = [f for f')[0].replace('dagger-rust-parser-state-pool-oct14','dagger-collection-native-items-oct18').replace(':16104',':16107').replace(':16276',':16279'))
cli=p/'dagger'
env['_EXPERIMENTAL_DAGGER_CLI_BIN']=str(cli)
env['_EXPERIMENTAL_DAGGER_VERSION']='v1.0.0-beta.15'
workspace=Path('/tmp/dagger-go-real-repository-main')
module=Path('/tmp/dagger-go-module-test-name-index') if options.fixture=='real' else p.parent/'collection-work-amplification/known-collections'
arms={'before':(True,True),'combined':(True,True)}
modules={'before':Path('/tmp/dagger-go-snapshot-test-directories'),'combined':Path('/tmp/dagger-go-native-collection-items')}
assert options.fixture=='real' and options.arms==['before','combined']
order_base=['before','engine','combined','typed'] if len(options.arms)==4 else options.arms
assert set(order_base)==set(options.arms)
orders=[order_base,order_base[::-1]]
for block in range(options.pairs):
    if len(order_base)==4:
        balanced=[['before','engine','combined','typed'],['engine','typed','before','combined'],['typed','combined','engine','before'],['combined','before','typed','engine']]
        order=balanced[block%4]
    else:order=order_base if block%2 else order_base[::-1]
    orders.append(order)
saved={n:(workspace/n).read_bytes() if (workspace/n).exists() else None for n in ['dagger.toml','dagger.lock']}
edit=workspace/'dagql/types.go';original=edit.read_bytes()
test=workspace/'dagql/cache_test.go';test_original=test.read_bytes()
test_name='TestSnapshotTestDirectoriesSourceFreshness'
assert test_name.encode() not in test_original
routes=['batch-metadata','attribute-array-decode','native-telemetry-storage','response-data-projection','collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata']
flags={r:get(r)['enabled'] for r in routes}
assert not get('wcprof/enabled')['global_enabled']
assert not get('evaluation-context')['enabled']
assert not get('receiver-preparation')['enabled']
assert not get('known-input-ids')['enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
assert get('collection-expansion-limit')['limit']==0
assert not get('queued-log-flush-buffer')['enabled']
assert not get('recovered-schema-templates')['enabled']
assert not get('canonical-core-providers')['enabled']
expected=[tuple(line.split()[1:3]) for line in (base/'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
build=json.loads((p/'build-steps.json').read_text())
engine_sha=subprocess.check_output(['docker','exec',record['Id'],'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
assert engine_sha==next(r['sha256'] for r in json.loads(Path('/tmp/rust-cache-sipsma-review/native-collection-items/engine-build-steps.json').read_text()) if r['label']=='engine-build')
assert hashlib.sha256(cli.read_bytes()).hexdigest()==next(r['sha256'] for r in build if r['label']=='cli-build')
metadata=dict(fixture=options.fixture,modules={k:str(v) for k,v in modules.items()},scope='Complete CLI comparison on real source edits, including exit, session cleanup and final log flush. Same engine binary and CLI, with typed artifact metadata, immutable response projection, getter content identity and the two Dang fixes common. Both arms use the same engine with stored-get support and the nested-list type fix. Only the Go module changes: the candidate constructs keyed native items while owners are already known; the baseline uses its normal function getter. Snapshot-derived test directories are common. Both arms complete the initialization test-layout transition before measured pairs. Shared function metadata, source-marker sharing and native sorting are excluded. Fresh CLI and ordinary-source edit every invocation; test-file comments also change in the test-edit cohort. Original retained Rust-cache engine and volume untouched.',orders=orders,arms=arms,initialization_blocks=[0,1],pairs=options.pairs,engine_sha256=engine_sha,cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),telemetry=True,ordinary_gc=True,wcprof=False,cpu_profile=False,source_hash=hashlib.sha256(original).hexdigest(),source_test_hash=hashlib.sha256(test_original).hexdigest(),flags_before=flags)
(root/'driver.py').write_bytes(Path(__file__).read_bytes());(root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
rows=[];first_rows={}
try:
    for route in ['batch-metadata','attribute-array-decode','native-telemetry-storage']:mode(route,True)
    for block,order in enumerate(orders):
        add_test=options.fixture=='real' and block==0
        block_test=test_original+(f'\nfunc {test_name}(t *testing.T) {{}}\n'.encode() if add_test else b'')
        block_expected=sorted(expected+([('dagql',test_name)] if add_test else []))
        for arm in order:
            label=f'{block}-{arm}';projection,typed=arms[arm];module=modules[arm]
            mode('response-data-projection',projection)
            mode('collection-item-content',True)
            mode('coerced-method-hoisting',True)
            mode('lazy-eval-error-context',True)
            mode('shared-function-metadata',False)
            run_env=dict(env,DAGGER_DIAG_TYPED_ARTIFACT_METADATA=str(typed).lower())
            edit.write_bytes(original+f'\n// Native Go test discovery experiment {time.time_ns()}\n'.encode())
            test.write_bytes(block_test)
            settings='[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n' if options.fixture=='real' else ''
            (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n'+settings)
            idle(label)
            before=heap();before_cpu=cpu();before_pressure=pressure();gc_before=get('snapshot-collection');tick=time.monotonic()
            command=[str(cli),'check','--module','go','--check','test','--list','--all']
            timed=['/usr/bin/time','-f','{"user_seconds":%U,"system_seconds":%S,"max_rss_kib":%M}','-o',str(root/(label+'-cli-resources.json')),'--',*command]
            with (root/(label+'.stdout')).open('w') as out,(root/(label+'.stderr')).open('w') as err:
                process=subprocess.Popen(timed,cwd=workspace,env=run_env,stdout=out,stderr=err,start_new_session=True)
                cancelled=False
                try:code=process.wait(timeout=240)
                except subprocess.TimeoutExpired:
                    cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait()
            cli_seconds=time.monotonic()-tick;get('upstream-log-queue',b'');seconds=time.monotonic()-tick
            after=heap();after_cpu=cpu();after_pressure=pressure();output=(root/(label+'.stdout')).read_text()
            lines=[line for line in output.splitlines() if line.startswith('go ')]
            names=[tuple(line.split()[1:3]) for line in lines]
            first_rows.setdefault(block,lines)
            row=dict(label=label,block=block,arm=arm,warmup=block<2,command=command,seconds=seconds,cli_seconds=cli_seconds,exit_code=code,cancelled=cancelled,rows=len(names),correct_names=names==block_expected,same_full_rows=lines==first_rows[block],generic_projection=projection,typed_metadata=typed,collection_item_content=True,coerced_method_hoisting=True,lazy_error_context=True,shared_function_metadata=False,snapshot_test_directories=True,native_stored_items=arm=='combined',engine_cpu=after_cpu-before_cpu,heap_delta={k:after[k]-before[k] for k in before},gc_before=gc_before,gc_after=get('snapshot-collection'),pressure={k:(after_pressure[k]-before_pressure[k])/(seconds*1e6) for k in before_pressure},cli_resources=json.loads((root/(label+'-cli-resources.json')).read_text().splitlines()[-1]))
            rows.append(row);(root/'samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['label','seconds','rows','exit_code','correct_names','same_full_rows','engine_cpu']}),flush=True)
            assert code==0 and not cancelled and row['correct_names'] and row['same_full_rows'],(label,'failed or listing differs')
    summary={arm:dict(median_seconds=statistics.median(r['seconds'] for r in rows if r['arm']==arm and not r['warmup']),median_engine_cpu=statistics.median(r['engine_cpu'] for r in rows if r['arm']==arm and not r['warmup']),median_allocated_bytes=statistics.median(r['heap_delta']['TotalAlloc'] for r in rows if r['arm']==arm and not r['warmup']),commands=sum(r['arm']==arm and not r['warmup'] for r in rows)) for arm in options.arms}
    (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
finally:
    edit.write_bytes(original);test.write_bytes(test_original)
    for name,data in saved.items():
        if data is None:(workspace/name).unlink(missing_ok=True)
        else:(workspace/name).write_bytes(data)
    for route,enabled in flags.items():mode(route,enabled)
    (root/'restoration.json').write_text(json.dumps(dict(source_restored=edit.read_bytes()==original,test_restored=test.read_bytes()==test_original,config_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items()),flags_after={r:get(r) for r in routes},lifecycle=get('client-lifecycle')),indent=2)+'\n')
