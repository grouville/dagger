from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
w = Path('/tmp/dagger-cache-small-id-sets')
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOWORK='off', GOTOOLCHAIN='local', GOMAXPROCS='8')
assert (p/'after-race.log').read_text().startswith('ok ')
rows = []
commands = [('before-check', ['-race', '-run=^TestCacheIDSetMatchesTreeSet$', '-overlay='+str(p/'before-overlay.json')])]
for pair, order in enumerate([['before', 'after'], ['after', 'before']]):
    for arm in order:
        commands.append((f'micro-{pair}-{arm}', ['-run=^$', '-bench=^BenchmarkCacheIDSet$', '-benchtime=150ms', '-benchmem', '-cpu=8', '-overlay='+str(p/(arm+'-overlay.json'))]))
for label, flags in commands:
    command = [go, 'test', '-p=2', '-count=1', '-timeout=240s', *flags, './dagql']
    start = time.monotonic()
    log = p/(label+'.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=w, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic()-start)
    rows.append(row)
    (p/'micro-commands.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, log.read_text()[-5000:]
