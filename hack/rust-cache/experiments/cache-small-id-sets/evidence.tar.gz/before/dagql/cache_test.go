package dagql

import (
	"context"
	"errors"
	"fmt"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"testing/synctest"
	"time"

	"github.com/containerd/containerd/v2/core/leases"
	"github.com/dagger/dagger/engine"
	snapshots "github.com/dagger/dagger/engine/snapshots"
	"github.com/dagger/dagger/engine/telemetryattrs"
	telemetry "github.com/dagger/otel-go"
	set "github.com/hashicorp/go-set/v3"
	"github.com/opencontainers/go-digest"
	"github.com/stretchr/testify/require"
	"github.com/vektah/gqlparser/v2/ast"
	"go.opentelemetry.io/otel/codes"
	sdklog "go.opentelemetry.io/otel/sdk/log"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/trace"
	"golang.org/x/sync/errgroup"
	"gotest.tools/v3/assert"
	is "gotest.tools/v3/assert/cmp"

	"github.com/dagger/dagger/dagql/call"
)

type cacheTestOnReleaseInt struct {
	Int
	onRelease func(context.Context) error
}

type cacheTestLeaseProvider struct {
	nextLeaseID atomic.Int32
	releases    atomic.Int32
	resourcesMu sync.Mutex
	resources   map[string][]leases.Resource
}

func (p *cacheTestLeaseProvider) WithOperationLease(ctx context.Context) (context.Context, func(context.Context) error, error) {
	return snapshots.WithLazyLease(ctx, p, func(l *leases.Lease) error {
		l.ID = fmt.Sprintf("shared-%d", p.nextLeaseID.Add(1))
		return nil
	})
}

func (p *cacheTestLeaseProvider) Create(_ context.Context, opts ...leases.Opt) (leases.Lease, error) {
	l := leases.Lease{}
	for _, opt := range opts {
		if err := opt(&l); err != nil {
			return leases.Lease{}, err
		}
	}
	return l, nil
}

func (p *cacheTestLeaseProvider) Delete(_ context.Context, _ leases.Lease, _ ...leases.DeleteOpt) error {
	p.releases.Add(1)
	return nil
}

func (p *cacheTestLeaseProvider) List(context.Context, ...string) ([]leases.Lease, error) {
	return nil, nil
}

func (p *cacheTestLeaseProvider) AddResource(_ context.Context, lease leases.Lease, resource leases.Resource) error {
	p.resourcesMu.Lock()
	defer p.resourcesMu.Unlock()
	if p.resources == nil {
		p.resources = map[string][]leases.Resource{}
	}
	p.resources[lease.ID] = append(p.resources[lease.ID], resource)
	return nil
}

func (p *cacheTestLeaseProvider) DeleteResource(context.Context, leases.Lease, leases.Resource) error {
	return nil
}

func (p *cacheTestLeaseProvider) ListResources(_ context.Context, lease leases.Lease) ([]leases.Resource, error) {
	p.resourcesMu.Lock()
	defer p.resourcesMu.Unlock()
	return append([]leases.Resource(nil), p.resources[lease.ID]...), nil
}

type cacheTestLeaseCheckedInt struct {
	Int
	onAttach func(context.Context) error
}

func (v cacheTestLeaseCheckedInt) AttachDependencyResults(
	ctx context.Context,
	_ AnyResult,
	_ func(AnyResult) (AnyResult, error),
) ([]AnyResult, error) {
	if v.onAttach == nil {
		return nil, nil
	}
	return nil, v.onAttach(ctx)
}

func (v cacheTestOnReleaseInt) OnRelease(ctx context.Context) error {
	if v.onRelease == nil {
		return nil
	}
	return v.onRelease(ctx)
}

type cacheTestOpaqueValue struct {
	value     string
	onRelease func(context.Context) error
}

func (v cacheTestOpaqueValue) OnRelease(ctx context.Context) error {
	if v.onRelease == nil {
		return nil
	}
	return v.onRelease(ctx)
}

type cacheTestSizedInt struct {
	Int
	sizeByIdentity       map[string]int64
	sizeSourceByIdentity map[string]*atomic.Int64
	usageIdentities      []string
	sizeCalls            *atomic.Int32
	sizeMayChange        bool
}

func (v cacheTestSizedInt) CacheUsageSize(_ context.Context, _ CacheUsageSizeProvider, identity string) (int64, bool, error) {
	if v.sizeCalls != nil {
		v.sizeCalls.Add(1)
	}
	if v.sizeSourceByIdentity != nil {
		sizeSource, ok := v.sizeSourceByIdentity[identity]
		if !ok || sizeSource == nil {
			return 0, false, nil
		}
		return sizeSource.Load(), true, nil
	}
	sizeBytes, ok := v.sizeByIdentity[identity]
	if !ok {
		return 0, false, nil
	}
	return sizeBytes, true, nil
}

func (v cacheTestSizedInt) CacheUsageIdentities() []string {
	return append([]string(nil), v.usageIdentities...)
}

func (v cacheTestSizedInt) CacheUsageMayChange() bool {
	return v.sizeMayChange
}

type cacheTestOwnedDepsInt struct {
	Int
	ownedResults []AnyResult
}

type cacheTestSpanExporter struct {
	mu    sync.Mutex
	spans []sdktrace.ReadOnlySpan
}

func (e *cacheTestSpanExporter) ExportSpans(_ context.Context, spans []sdktrace.ReadOnlySpan) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	e.spans = append(e.spans, spans...)
	return nil
}

func (*cacheTestSpanExporter) Shutdown(context.Context) error { return nil }
func (*cacheTestSpanExporter) ForceFlush(context.Context) error {
	return nil
}

type cacheTestLogExporter struct {
	mu   sync.Mutex
	logs []sdklog.Record
}

func (e *cacheTestLogExporter) Export(_ context.Context, logs []sdklog.Record) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	e.logs = append(e.logs, logs...)
	return nil
}

func (*cacheTestLogExporter) Shutdown(context.Context) error { return nil }
func (*cacheTestLogExporter) ForceFlush(context.Context) error {
	return nil
}

func (v *cacheTestOwnedDepsInt) AttachDependencyResults(
	ctx context.Context,
	_ AnyResult,
	attach func(AnyResult) (AnyResult, error),
) ([]AnyResult, error) {
	if v == nil {
		return nil, nil
	}
	attached := make([]AnyResult, 0, len(v.ownedResults))
	for i, dep := range v.ownedResults {
		if dep == nil {
			continue
		}
		attachedDep, err := attach(dep)
		if err != nil {
			return nil, err
		}
		v.ownedResults[i] = attachedDep
		attached = append(attached, attachedDep)
	}
	return attached, nil
}

func cacheTestUnwrapInt(t *testing.T, res AnyResult) int {
	t.Helper()
	v, ok := UnwrapAs[Int](res)
	assert.Assert(t, ok, "expected Int result, got %T", res)
	return int(v)
}

func cacheTestSharedResultEntryID(res AnyResult) string {
	shared := res.cacheSharedResult()
	if shared == nil || shared.id == 0 {
		return ""
	}
	return fmt.Sprintf("dagql.result.%d", shared.id)
}

type cacheTestQuery struct{}

func (cacheTestQuery) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Query",
		NonNull:   true,
	}
}

type cacheTestObject struct {
	Value             int
	onRelease         func(context.Context) error
	lazyEval          LazyEvalFunc
	dependencyResults []AnyResult
	snapshotLinks     []PersistedSnapshotRefLink
}

func (obj *cacheTestObject) PersistedSnapshotRefLinks() []PersistedSnapshotRefLink {
	if obj == nil {
		return nil
	}
	return obj.snapshotLinks
}

type noopTypeResolver struct{}

func (noopTypeResolver) ObjectType(string) (ObjectType, bool) {
	return nil, false
}

func (noopTypeResolver) ScalarType(string) (ScalarType, bool) {
	return nil, false
}

func TestCacheRejectsNilTypeResolver(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	key := cacheTestIntCall("nil-type-resolver")

	_, err = c.GetOrInitCall(ctx, "test-session", nil, &CallRequest{ResultCall: key}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(key, 1), nil
	})
	assert.Assert(t, err != nil)
	assert.ErrorContains(t, err, "type resolver is nil")

	_, _, err = c.lookupCacheForDigests(ctx, "test-session", nil, digest.FromString("nil-type-resolver"), nil)
	assert.Assert(t, err != nil)
	assert.ErrorContains(t, err, "type resolver is nil")

	_, err = c.AttachResult(ctx, "test-session", nil, cacheTestDetachedResult(key, NewInt(1)))
	assert.Assert(t, err != nil)
	assert.ErrorContains(t, err, "type resolver is nil")
}

func TestCacheRejectsEmptySessionIDForOwningEntrypoints(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := cacheTestIntCall("empty-session-id")

	_, err = c.GetOrInitCall(ctx, "", noopTypeResolver{}, &CallRequest{ResultCall: key}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(key, 1), nil
	})
	assert.Assert(t, err != nil)
	assert.ErrorContains(t, err, "empty session ID")

	_, err = c.AttachResult(ctx, "", noopTypeResolver{}, cacheTestDetachedResult(key, NewInt(1)))
	assert.Assert(t, err != nil)
	assert.ErrorContains(t, err, "empty session ID")

	_, err = c.GetOrInitArbitrary(ctx, "", "empty-session-id", func(context.Context) (any, error) {
		return "value", nil
	})
	assert.Assert(t, err != nil)
	assert.ErrorContains(t, err, "empty session ID")
}

func TestSharedCallUsesOneClientScopeLeaseForAllWaiters(t *testing.T) {
	t.Parallel()

	var acquired atomic.Int32
	var released atomic.Int32
	rootLease := engine.NewClientLifecycleLease(
		engine.ClientLeaseRequest,
		"request",
		func() {},
		func(kind engine.ClientLeaseKind, ownerID string) (*engine.ClientLifecycleLease, error) {
			assert.Equal(t, kind, engine.ClientLeaseSharedWork)
			assert.Assert(t, strings.HasPrefix(ownerID, "call/"))
			acquired.Add(1)
			return engine.NewClientLifecycleLease(kind, ownerID, func() { released.Add(1) }, nil), nil
		},
	)
	scope, err := engine.NewClientScope(&engine.ClientMetadata{SessionID: "session", ClientID: "client"}, rootLease)
	assert.NilError(t, err)
	ctx, err := engine.ContextWithClientScope(cacheTestContext(t.Context()), scope)
	assert.NilError(t, err)
	cache, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cache)

	frame := cacheTestIntCall("leased-singleflight")
	req := &CallRequest{ResultCall: frame, ConcurrencyKey: "leased-singleflight"}
	started := make(chan struct{})
	release := make(chan struct{})
	var executions atomic.Int32
	call := func() (AnyResult, error) {
		return cache.GetOrInitCall(ctx, "session", noopTypeResolver{}, req, func(context.Context) (AnyResult, error) {
			if executions.Add(1) == 1 {
				close(started)
			}
			<-release
			return cacheTestIntResult(frame, 1), nil
		})
	}

	results := make(chan error, 2)
	go func() { _, err := call(); results <- err }()
	<-started
	go func() { _, err := call(); results <- err }()
	require.Eventually(t, func() bool {
		cache.callsMu.Lock()
		defer cache.callsMu.Unlock()
		for _, ongoing := range cache.ongoingCalls {
			if ongoing.waiters == 2 {
				return true
			}
		}
		return false
	}, time.Second, time.Millisecond)
	require.Equal(t, int32(1), acquired.Load())
	close(release)
	assert.NilError(t, <-results)
	assert.NilError(t, <-results)
	assert.Equal(t, executions.Load(), int32(1))
	require.Eventually(t, func() bool { return released.Load() == 1 }, time.Second, time.Millisecond)
}

func TestSharedCallReleasesLeaseWhenLastWaiterCancelsAfterCompletion(t *testing.T) {
	t.Parallel()

	var released atomic.Int32
	rootLease := engine.NewClientLifecycleLease(
		engine.ClientLeaseRequest,
		"request",
		func() {},
		func(kind engine.ClientLeaseKind, ownerID string) (*engine.ClientLifecycleLease, error) {
			return engine.NewClientLifecycleLease(kind, ownerID, func() { released.Add(1) }, nil), nil
		},
	)
	scope, err := engine.NewClientScope(&engine.ClientMetadata{SessionID: "session", ClientID: "client"}, rootLease)
	assert.NilError(t, err)
	baseCtx, err := engine.ContextWithClientScope(cacheTestContext(t.Context()), scope)
	assert.NilError(t, err)
	cache, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	baseCtx = ContextWithCache(baseCtx, cache)
	ctx, cancel := context.WithCancelCause(baseCtx)
	defer cancel(nil)

	// The callback finishes successfully while its only waiter is still
	// admitted, so it delegates publication and lease release to the waiters.
	// That waiter is then canceled before it observes completion, which is what
	// happens to every in-flight call of a query whose client disconnects.
	waiterDone := make(chan struct{})
	cache.testAfterCallbackWaiterCheck = func() {
		cancel(errors.New("client disconnected"))
		<-waiterDone
	}

	frame := cacheTestIntCall("orphaned-completion")
	req := &CallRequest{ResultCall: frame, ConcurrencyKey: "orphaned-completion"}
	_, err = cache.GetOrInitCall(ctx, "session", noopTypeResolver{}, req, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(frame, 1), nil
	})
	close(waiterDone)
	assert.ErrorContains(t, err, "client disconnected")
	require.Eventually(t, func() bool { return released.Load() == 1 }, time.Second, time.Millisecond,
		"shared-work lease orphaned: the callback saw a waiter and the waiter left without publishing")
}

func TestAttachResultAllowsAlreadyAttachedResultWithoutFrame(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	key := cacheTestIntCall("attached-without-frame")

	res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: key}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(key, 42), nil
	})
	assert.NilError(t, err)

	shared := res.cacheSharedResult()
	assert.Assert(t, shared != nil)
	assert.Assert(t, shared.id != 0)

	shared.storeResultCall(nil)

	attached, err := c.AttachResult(ctx, "test-session", noopTypeResolver{}, res)
	assert.NilError(t, err)
	assert.Equal(t, attached, res)
}

func TestCaptureSessionLazySpanContextFirstWriterWinsAndRelease(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	ctx := ContextWithCache(baseCtx, cacheIface)
	c := cacheIface

	reqCall := cacheTestIntCall("telemetry-span-owner")
	spanCtxA := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{1},
		SpanID:  trace.SpanID{1},
	})
	ctxA := trace.ContextWithSpanContext(ctx, spanCtxA)
	resA, err := c.GetOrInitCall(ctxA, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: reqCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(reqCall, 1), nil
	})
	assert.NilError(t, err)

	spanCtxB := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{2},
		SpanID:  trace.SpanID{2},
	})
	ctxB := trace.ContextWithSpanContext(ctx, spanCtxB)
	resB, err := c.GetOrInitCall(ctxB, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: reqCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(reqCall, 2), nil
	})
	assert.NilError(t, err)

	sharedA := resA.cacheSharedResult()
	sharedB := resB.cacheSharedResult()
	assert.Assert(t, sharedA != nil)
	assert.Assert(t, sharedB != nil)
	assert.Equal(t, sharedA.id, sharedB.id)

	gotSpanCtx, ok := c.sessionLazySpanContext("test-session", sharedA.id)
	assert.Assert(t, ok)
	assert.Equal(t, gotSpanCtx.TraceID(), spanCtxA.TraceID())
	assert.Equal(t, gotSpanCtx.SpanID(), spanCtxA.SpanID())

	cacheTestReleaseSession(t, c, ctx)
	_, ok = c.sessionLazySpanContext("test-session", sharedA.id)
	assert.Assert(t, !ok)
}

func TestSessionResultInstallSpanContextsSorted(t *testing.T) {
	t.Parallel()

	c := &Cache{}
	spanCtxB := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{2},
		SpanID:  trace.SpanID{2},
	})
	spanCtxA := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{1},
		SpanID:  trace.SpanID{1},
	})

	c.recordSessionResultInstallSpanLocked("test-session", 1, spanCtxB, false)
	c.recordSessionResultInstallSpanLocked("test-session", 1, spanCtxA, false)
	c.recordSessionResultInstallSpanLocked("test-session", 1, spanCtxB, false)

	got := c.sessionResultInstallSpanContexts("test-session", 1)
	assert.DeepEqual(t, got, []trace.SpanContext{spanCtxA, spanCtxB})
}

// Install-span lookups walk dep edges upward: a result sees its own direct
// install spans plus closure-owning (module API call return) install spans of
// results that transitively depend on it. Non-owning installs on ancestors
// (plain chained API calls) must not propagate downward.
func TestInstallSpanLookupWalksClosureOwnersUpward(t *testing.T) {
	t.Parallel()

	ctx := t.Context()
	c := &Cache{resultsByID: map[sharedResultID]*sharedResult{}}
	moduleReturn := &sharedResult{id: 1}
	chained := &sharedResult{id: 2}
	leaf := &sharedResult{id: 3}
	c.resultsByID[moduleReturn.id] = moduleReturn
	c.resultsByID[chained.id] = chained
	c.resultsByID[leaf.id] = leaf

	c.egraphMu.Lock()
	moduleErr := c.addExplicitDependencyLocked(ctx, moduleReturn, chained, "test")
	chainErr := c.addExplicitDependencyLocked(ctx, chained, leaf, "test")
	moduleReturnAncestors := c.installAncestorIDsLocked(moduleReturn.id)
	leafAncestors := c.installAncestorIDsLocked(leaf.id)
	c.egraphMu.Unlock()
	assert.NilError(t, moduleErr)
	assert.NilError(t, chainErr)

	assert.DeepEqual(t, moduleReturnAncestors, []sharedResultID(nil))
	assert.DeepEqual(t, leafAncestors, []sharedResultID{chained.id, moduleReturn.id})

	moduleSpanCtx := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{1},
		SpanID:  trace.SpanID{1},
	})
	chainedSpanCtx := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{2},
		SpanID:  trace.SpanID{2},
	})
	leafSpanCtx := trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{3},
		SpanID:  trace.SpanID{3},
	})

	// The module API call returned moduleReturn: closure-owning install.
	c.recordSessionResultInstallSpanLocked("test-session", moduleReturn.id, moduleSpanCtx, true)
	// chained was returned by a plain API call: direct install only.
	c.recordSessionResultInstallSpanLocked("test-session", chained.id, chainedSpanCtx, false)
	// leaf was returned by a plain API call too.
	c.recordSessionResultInstallSpanLocked("test-session", leaf.id, leafSpanCtx, false)

	// leaf sees its own install plus the module span via closure ownership,
	// but not the chained result's plain install.
	assert.DeepEqual(t,
		c.sessionResultInstallSpanContexts("test-session", leaf.id),
		[]trace.SpanContext{moduleSpanCtx, leafSpanCtx})

	// chained likewise sees itself plus the module span.
	assert.DeepEqual(t,
		c.sessionResultInstallSpanContexts("test-session", chained.id),
		[]trace.SpanContext{moduleSpanCtx, chainedSpanCtx})

	// moduleReturn has no ancestors; it sees only its own install.
	assert.DeepEqual(t,
		c.sessionResultInstallSpanContexts("test-session", moduleReturn.id),
		[]trace.SpanContext{moduleSpanCtx})
}

func TestEvaluateLazyUsesOriginalSpanForLogsAndNestedSpans(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	ctx := ContextWithCache(baseCtx, cacheIface)
	c := cacheIface
	srv := cacheTestServer(t)

	spanExporter := &cacheTestSpanExporter{}
	tracerProvider := sdktrace.NewTracerProvider(sdktrace.WithSyncer(spanExporter))
	defer tracerProvider.Shutdown(t.Context())

	logExporter := &cacheTestLogExporter{}
	loggerProvider := sdklog.NewLoggerProvider(sdklog.WithProcessor(sdklog.NewSimpleProcessor(logExporter)))
	defer loggerProvider.Shutdown(t.Context())

	ctx = telemetry.WithLoggerProvider(ctx, loggerProvider)

	originalCtx, originalSpan := tracerProvider.Tracer("dagger.io/test").Start(ctx, "original")
	reqCall := &ResultCall{
		Type: NewResultCallType(&ast.Type{
			NamedType: "CacheTestObject",
			NonNull:   true,
		}),
		Field: "lazyResume",
	}
	res, err := c.GetOrInitCall(originalCtx, "test-session", srv, &CallRequest{ResultCall: reqCall}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResultWithValue(t, srv, reqCall, &cacheTestObject{
			Value: 1,
			lazyEval: func(ctx context.Context) error {
				stdio := telemetry.SpanStdio(ctx, InstrumentationLibrary)
				fmt.Fprint(stdio.Stdout, "hello from lazy")
				assert.NilError(t, stdio.Close())

				_, childSpan := Tracer(ctx).Start(ctx, "lazy child")
				childSpan.End()
				return nil
			},
		}), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, HasPendingLazyEvaluation(res))

	triggerCtx, triggerSpan := tracerProvider.Tracer("dagger.io/test").Start(ctx, "trigger")
	assert.NilError(t, c.Evaluate(triggerCtx, res))
	triggerSpan.End()
	originalSpan.End()

	assert.NilError(t, tracerProvider.ForceFlush(t.Context()))
	assert.NilError(t, loggerProvider.ForceFlush(t.Context()))

	originalSpanID := originalSpan.SpanContext().SpanID()

	logExporter.mu.Lock()
	logs := append([]sdklog.Record(nil), logExporter.logs...)
	logExporter.mu.Unlock()
	assert.Assert(t, len(logs) > 0, "expected lazy evaluation to emit logs")
	assert.Equal(t, logs[0].SpanID(), originalSpanID)

	spanExporter.mu.Lock()
	spans := append([]sdktrace.ReadOnlySpan(nil), spanExporter.spans...)
	spanExporter.mu.Unlock()

	var sawResume bool
	var sawChild bool
	for _, span := range spans {
		switch span.Name() {
		case "lazy child":
			sawChild = true
			assert.Equal(t, span.Parent().SpanID(), originalSpanID)
		case "resume lazyResume":
			sawResume = true
			assert.Equal(t, span.Parent().SpanID(), triggerSpan.SpanContext().SpanID())
			assert.Equal(t, len(span.Links()), 1)
			assert.Equal(t, span.Links()[0].SpanContext.SpanID(), originalSpanID)
		}
	}
	assert.Assert(t, sawChild, "expected nested lazy child span to be recorded")
	assert.Assert(t, sawResume, "expected hidden resume span to be recorded")
}

// When a lazy callback fails only because a prerequisite result's evaluation
// failed, the callback's own resume span must be marked blocked
// (dagger.io/dag.blocked) so the UI returns the owning API spans to pending.
// The prerequisite's own resume span carries the real failure unmarked.
func TestEvaluateLazyPrerequisiteFailureMarksResumeBlocked(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	ctx := ContextWithCache(baseCtx, cacheIface)
	c := cacheIface
	srv := cacheTestServer(t)

	spanExporter := &cacheTestSpanExporter{}
	tracerProvider := sdktrace.NewTracerProvider(sdktrace.WithSyncer(spanExporter))
	defer tracerProvider.Shutdown(t.Context())

	originalCtx, originalSpan := tracerProvider.Tracer("dagger.io/test").Start(ctx, "original")

	depErr := errors.New("dep exploded")
	depCall := &ResultCall{
		Type: NewResultCallType(&ast.Type{
			NamedType: "CacheTestObject",
			NonNull:   true,
		}),
		Field: "lazyDep",
	}
	depRes, err := c.GetOrInitCall(originalCtx, "test-session", srv, &CallRequest{ResultCall: depCall}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResultWithValue(t, srv, depCall, &cacheTestObject{
			Value: 1,
			lazyEval: func(context.Context) error {
				return depErr
			},
		}), nil
	})
	assert.NilError(t, err)

	tipCall := &ResultCall{
		Type: NewResultCallType(&ast.Type{
			NamedType: "CacheTestObject",
			NonNull:   true,
		}),
		Field: "lazyTip",
	}
	tipRes, err := c.GetOrInitCall(originalCtx, "test-session", srv, &CallRequest{ResultCall: tipCall}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResultWithValue(t, srv, tipCall, &cacheTestObject{
			Value: 2,
			lazyEval: func(ctx context.Context) error {
				return c.Evaluate(ctx, depRes)
			},
		}), nil
	})
	assert.NilError(t, err)

	triggerCtx, triggerSpan := tracerProvider.Tracer("dagger.io/test").Start(ctx, "trigger")
	evalErr := c.Evaluate(triggerCtx, tipRes)
	assert.Assert(t, evalErr != nil)
	assert.ErrorContains(t, evalErr, "dep exploded")
	triggerSpan.End()
	originalSpan.End()

	assert.NilError(t, tracerProvider.ForceFlush(t.Context()))

	spanExporter.mu.Lock()
	spans := append([]sdktrace.ReadOnlySpan(nil), spanExporter.spans...)
	spanExporter.mu.Unlock()

	spanBlocked := func(span sdktrace.ReadOnlySpan) bool {
		for _, attr := range span.Attributes() {
			if string(attr.Key) == telemetryattrs.DagBlockedAttr {
				return attr.Value.AsBool()
			}
		}
		return false
	}

	var sawTipResume, sawDepResume bool
	for _, span := range spans {
		switch span.Name() {
		case "resume lazyTip":
			sawTipResume = true
			assert.Equal(t, span.Status().Code, codes.Error)
			assert.Assert(t, spanBlocked(span), "tip resume span should be marked blocked")
		case "resume lazyDep":
			sawDepResume = true
			assert.Equal(t, span.Status().Code, codes.Error)
			assert.Assert(t, !spanBlocked(span), "dep resume span carries the real failure and must not be blocked")
			assert.Equal(t, span.Status().Description, "dep exploded")
		}
	}
	assert.Assert(t, sawTipResume, "expected tip resume span to be recorded")
	assert.Assert(t, sawDepResume, "expected dep resume span to be recorded")
}

// A lazy callback that fails its own work (no prerequisite involved) must not
// be classified as blocked, even when other evaluations happened earlier.
func TestEvaluateLazyOwnFailureNotMarkedBlocked(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	ctx := ContextWithCache(baseCtx, cacheIface)
	c := cacheIface
	srv := cacheTestServer(t)

	spanExporter := &cacheTestSpanExporter{}
	tracerProvider := sdktrace.NewTracerProvider(sdktrace.WithSyncer(spanExporter))
	defer tracerProvider.Shutdown(t.Context())

	originalCtx, originalSpan := tracerProvider.Tracer("dagger.io/test").Start(ctx, "original")

	depCall := &ResultCall{
		Type: NewResultCallType(&ast.Type{
			NamedType: "CacheTestObject",
			NonNull:   true,
		}),
		Field: "okDep",
	}
	depRes, err := c.GetOrInitCall(originalCtx, "test-session", srv, &CallRequest{ResultCall: depCall}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResultWithValue(t, srv, depCall, &cacheTestObject{
			Value: 1,
			lazyEval: func(context.Context) error {
				return nil
			},
		}), nil
	})
	assert.NilError(t, err)

	tipCall := &ResultCall{
		Type: NewResultCallType(&ast.Type{
			NamedType: "CacheTestObject",
			NonNull:   true,
		}),
		Field: "ownFailTip",
	}
	tipRes, err := c.GetOrInitCall(originalCtx, "test-session", srv, &CallRequest{ResultCall: tipCall}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResultWithValue(t, srv, tipCall, &cacheTestObject{
			Value: 2,
			lazyEval: func(ctx context.Context) error {
				if err := c.Evaluate(ctx, depRes); err != nil {
					return err
				}
				return errors.New("my own work failed")
			},
		}), nil
	})
	assert.NilError(t, err)

	triggerCtx, triggerSpan := tracerProvider.Tracer("dagger.io/test").Start(ctx, "trigger")
	evalErr := c.Evaluate(triggerCtx, tipRes)
	assert.Assert(t, evalErr != nil)
	assert.ErrorContains(t, evalErr, "my own work failed")
	triggerSpan.End()
	originalSpan.End()

	assert.NilError(t, tracerProvider.ForceFlush(t.Context()))

	spanExporter.mu.Lock()
	spans := append([]sdktrace.ReadOnlySpan(nil), spanExporter.spans...)
	spanExporter.mu.Unlock()

	var sawTipResume bool
	for _, span := range spans {
		if span.Name() != "resume ownFailTip" {
			continue
		}
		sawTipResume = true
		assert.Equal(t, span.Status().Code, codes.Error)
		for _, attr := range span.Attributes() {
			assert.Assert(t, string(attr.Key) != telemetryattrs.DagBlockedAttr,
				"own failure must not be marked blocked")
		}
	}
	assert.Assert(t, sawTipResume, "expected tip resume span to be recorded")
}

func (*cacheTestObject) Type() *ast.Type {
	return &ast.Type{
		NamedType: "CacheTestObject",
		NonNull:   true,
	}
}

func (obj *cacheTestObject) OnRelease(ctx context.Context) error {
	if obj.onRelease == nil {
		return nil
	}
	return obj.onRelease(ctx)
}

func (obj *cacheTestObject) LazyEvalFunc() LazyEvalFunc {
	if obj == nil {
		return nil
	}
	return obj.lazyEval
}

func (obj *cacheTestObject) AttachDependencyResults(
	_ context.Context,
	_ AnyResult,
	attach func(AnyResult) (AnyResult, error),
) ([]AnyResult, error) {
	if obj == nil {
		return nil, nil
	}
	deps := make([]AnyResult, 0, len(obj.dependencyResults))
	for i, dep := range obj.dependencyResults {
		if dep == nil {
			continue
		}
		attachedDep, err := attach(dep)
		if err != nil {
			return nil, err
		}
		obj.dependencyResults[i] = attachedDep
		deps = append(deps, attachedDep)
	}
	return deps, nil
}

func cacheTestServer(t *testing.T) *Server {
	t.Helper()
	srv := newDagqlServerForTest(t, cacheTestQuery{})
	Fields[*cacheTestObject]{
		Func("value", func(_ context.Context, self *cacheTestObject, _ struct{}) (Int, error) {
			return NewInt(self.Value), nil
		}),
	}.Install(srv)
	return srv
}

func cacheTestContext(ctx context.Context) context.Context {
	return engine.ContextWithClientMetadata(ctx, &engine.ClientMetadata{
		ClientID:  "dagql-test-client",
		SessionID: "test-session",
	})
}

func cacheTestSessionID(t *testing.T, ctx context.Context) string {
	t.Helper()
	clientMetadata, err := engine.ClientMetadataFromContext(ctx)
	assert.NilError(t, err)
	assert.Assert(t, clientMetadata.SessionID != "")
	return clientMetadata.SessionID
}

func cacheTestReleaseSession(t *testing.T, cache *Cache, ctx context.Context) {
	t.Helper()
	assert.NilError(t, cache.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
}

func cacheTestObjectResolverServer(t *testing.T, marker int) *Server {
	t.Helper()
	srv := cacheTestServer(t)
	Fields[cacheTestQuery]{
		NodeFunc("obj", func(ctx context.Context, _ ObjectResult[cacheTestQuery], _ struct{}) (Result[*cacheTestObject], error) {
			return NewResultForCurrentCall(ctx, &cacheTestObject{Value: 0})
		}),
	}.Install(srv)
	Fields[*cacheTestObject]{
		Func("marker", func(_ context.Context, _ *cacheTestObject, _ struct{}) (Int, error) {
			return NewInt(marker), nil
		}).DoNotCache("test marker must execute against the current server class"),
	}.Install(srv)
	return srv
}

func cacheTestObjectResult(
	t *testing.T,
	srv *Server,
	frame *ResultCall,
	value int,
	onRelease func(context.Context) error,
) ObjectResult[*cacheTestObject] {
	t.Helper()
	res, err := NewObjectResultForCall(&cacheTestObject{
		Value:     value,
		onRelease: onRelease,
	}, srv, frame)
	assert.NilError(t, err)
	return res
}

func cacheTestObjectResultWithValue(
	t *testing.T,
	srv *Server,
	frame *ResultCall,
	obj *cacheTestObject,
) ObjectResult[*cacheTestObject] {
	t.Helper()
	res, err := NewObjectResultForCall(obj, srv, frame)
	assert.NilError(t, err)
	return res
}

const cacheTestVolatileValueSentinel = "dagql.cache-test.volatile-value"

func cacheTestVolatileSessionResourceHandle(slot string) SessionResourceHandle {
	return SessionResourceHandle(digest.FromString("cache-test volatile session resource: " + slot).String())
}

func cacheTestSessionResourceLeaf(ctx context.Context, handle SessionResourceHandle) (Result[String], error) {
	leaf, err := NewResultForCall(NewString("volatile"), &ResultCall{
		Kind:        ResultCallKindSynthetic,
		Type:        NewResultCallType(NewString("").Type()),
		SyntheticOp: "cache-test.volatile-session-resource",
		Args: []*ResultCallArg{{
			Name: "handle",
			Value: &ResultCallLiteral{
				Kind:        ResultCallLiteralKindString,
				StringValue: string(handle),
			},
		}},
	})
	if err != nil {
		return Result[String]{}, err
	}
	leaf, err = leaf.WithContentDigest(ctx, digest.Digest(handle))
	if err != nil {
		return Result[String]{}, err
	}
	return leaf.WithSessionResourceHandle(ctx, handle)
}

func cacheTestStringResultCallArg(t *testing.T, frame *ResultCall, name string) string {
	t.Helper()
	for _, arg := range frame.Args {
		if arg == nil || arg.Name != name {
			continue
		}
		assert.Assert(t, arg.Value != nil, "expected arg %q to have a value", name)
		assert.Equal(t, ResultCallLiteralKindString, arg.Value.Kind)
		return arg.Value.StringValue
	}
	t.Fatalf("expected result call arg %q", name)
	return ""
}

func cacheTestSessionResourceSetContains(handles *set.TreeSet[SessionResourceHandle], handle SessionResourceHandle) bool {
	if handles == nil {
		return false
	}
	for candidate := range handles.Items() {
		if candidate == handle {
			return true
		}
	}
	return false
}

func TestCacheVolatileSessionResourceInvariants(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	ctx := ContextWithCache(baseCtx, c)
	srv := cacheTestServer(t)

	type volatileArgs struct {
		Slot  String `name:"slot"`
		Value String `name:"value"`
	}

	var calls atomic.Int32
	Fields[cacheTestQuery]{
		NodeFuncWithDynamicInputs(
			"volatileSessionParent",
			func(ctx context.Context, _ ObjectResult[cacheTestQuery], args volatileArgs) (Result[*cacheTestObject], error) {
				if got := string(args.Value); got != cacheTestVolatileValueSentinel {
					return Result[*cacheTestObject]{}, fmt.Errorf("resolver saw unrewritten volatile value %q", got)
				}
				leaf, err := cacheTestSessionResourceLeaf(ctx, cacheTestVolatileSessionResourceHandle(string(args.Slot)))
				if err != nil {
					return Result[*cacheTestObject]{}, err
				}
				return NewResultForCurrentCall(ctx, &cacheTestObject{
					Value:             int(calls.Add(1)),
					dependencyResults: []AnyResult{leaf},
				})
			},
			func(ctx context.Context, _ ObjectResult[cacheTestQuery], args volatileArgs, req *CallRequest) error {
				cache, err := EngineCache(ctx)
				if err != nil {
					return err
				}
				clientMetadata, err := engine.ClientMetadataFromContext(ctx)
				if err != nil {
					return err
				}
				handle := cacheTestVolatileSessionResourceHandle(string(args.Slot))
				if err := cache.BindSessionResource(ctx, clientMetadata.SessionID, clientMetadata.ClientID, handle, string(args.Value)); err != nil {
					return err
				}
				return req.SetArgInput(ctx, "value", NewString(cacheTestVolatileValueSentinel), false)
			},
		),
	}.Install(srv)

	const slot = "CI_JOB_ID"
	handle := cacheTestVolatileSessionResourceHandle(slot)
	selectVolatile := func(ctx context.Context, value string) ObjectResult[*cacheTestObject] {
		t.Helper()
		var res ObjectResult[*cacheTestObject]
		err := srv.Select(ctx, srv.Root(), &res, Selector{
			Field: "volatileSessionParent",
			Args: []NamedInput{
				{Name: "slot", Value: NewString(slot)},
				{Name: "value", Value: NewString(value)},
			},
		})
		assert.NilError(t, err)
		return res
	}

	first := selectVolatile(ctx, "first")
	assert.Assert(t, !first.HitCache())
	assert.Equal(t, 1, first.Self().Value)
	assert.Equal(t, int32(1), calls.Load())

	firstCall, err := first.ResultCall()
	assert.NilError(t, err)
	assert.Equal(t, slot, cacheTestStringResultCallArg(t, firstCall, "slot"))
	assert.Equal(t, cacheTestVolatileValueSentinel, cacheTestStringResultCallArg(t, firstCall, "value"))

	firstShared := first.cacheSharedResult()
	assert.Assert(t, firstShared != nil)
	assert.Assert(t, firstShared.id != 0)
	c.egraphMu.Lock()
	parentRequiresHandle := cacheTestSessionResourceSetContains(firstShared.requiredSessionResources, handle)
	var leafShared *sharedResult
	for depID := range firstShared.deps {
		dep := c.resultsByID[depID]
		if dep != nil && dep.sessionResourceHandle == handle {
			leafShared = dep
			break
		}
	}
	leafRequiresHandle := leafShared != nil && cacheTestSessionResourceSetContains(leafShared.requiredSessionResources, handle)
	leafHandle := SessionResourceHandle("")
	if leafShared != nil {
		leafHandle = leafShared.sessionResourceHandle
	}
	c.egraphMu.Unlock()
	assert.Assert(t, parentRequiresHandle)
	assert.Assert(t, leafShared != nil, "expected volatile session resource leaf dependency")
	assert.Equal(t, handle, leafHandle)
	assert.Assert(t, leafRequiresHandle)

	second := selectVolatile(ctx, "second")
	assert.Assert(t, second.HitCache())
	assert.Equal(t, firstShared.id, second.cacheSharedResult().id)
	assert.Equal(t, 1, second.Self().Value)
	assert.Equal(t, int32(1), calls.Load())
	resolved, err := c.ResolveSessionResource(ctx, "test-session", "dagql-test-client", handle)
	assert.NilError(t, err)
	assert.Equal(t, "second", resolved)

	boundCtx := engine.ContextWithClientMetadata(t.Context(), &engine.ClientMetadata{
		ClientID:  "volatile-bound-client",
		SessionID: "volatile-bound-session",
	})
	boundCtx = ContextWithCache(boundCtx, c)
	extraHandle := cacheTestVolatileSessionResourceHandle("EXTRA_VOLATILE")
	assert.NilError(t, c.BindSessionResource(boundCtx, "volatile-bound-session", "volatile-bound-client", handle, "bound"))
	assert.NilError(t, c.BindSessionResource(boundCtx, "volatile-bound-session", "volatile-bound-client", extraHandle, "extra"))
	boundHit, hit, err := c.lookupCallRequest(boundCtx, "volatile-bound-session", srv, &CallRequest{ResultCall: firstCall.clone()})
	assert.NilError(t, err)
	assert.Assert(t, hit)
	assert.Assert(t, boundHit.HitCache())
	assert.Equal(t, firstShared.id, boundHit.cacheSharedResult().id)

	unboundCtx := engine.ContextWithClientMetadata(t.Context(), &engine.ClientMetadata{
		ClientID:  "volatile-unbound-client",
		SessionID: "volatile-unbound-session",
	})
	unboundCtx = ContextWithCache(unboundCtx, c)
	var unboundInitCalls int
	unbound, err := c.GetOrInitCall(unboundCtx, "volatile-unbound-session", srv, &CallRequest{ResultCall: firstCall.clone()}, func(ctx context.Context) (AnyResult, error) {
		unboundInitCalls++
		return NewObjectResultForCurrentCall(ctx, srv, &cacheTestObject{Value: 99})
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, unboundInitCalls)
	assert.Assert(t, !unbound.HitCache())
	unboundObj, ok := unbound.(ObjectResult[*cacheTestObject])
	assert.Assert(t, ok, "expected unbound miss to return cacheTestObject, got %T", unbound)
	assert.Equal(t, 99, unboundObj.Self().Value)

	assert.NilError(t, c.ReleaseSession(ctx, "test-session"))
	assert.NilError(t, c.ReleaseSession(boundCtx, "volatile-bound-session"))
	assert.NilError(t, c.ReleaseSession(unboundCtx, "volatile-unbound-session"))
}

// TestCacheVolatileConcurrentSessionsDivergentValues verifies that two sessions
// with different volatile values for the same slot both get correct results.
// Session A binds handle→"alpha", session B binds handle→"beta". Both look up
// the same broad cache key. Each session's resolved resource must reflect its
// own binding, not the other's.
func TestCacheVolatileConcurrentSessionsDivergentValues(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	ctx := ContextWithCache(baseCtx, c)
	srv := cacheTestServer(t)

	type volatileArgs struct {
		Slot  String `name:"slot"`
		Value String `name:"value"`
	}

	var calls atomic.Int32
	Fields[cacheTestQuery]{
		NodeFuncWithDynamicInputs(
			"volatileConcurrentParent",
			func(ctx context.Context, _ ObjectResult[cacheTestQuery], args volatileArgs) (Result[*cacheTestObject], error) {
				if got := string(args.Value); got != cacheTestVolatileValueSentinel {
					return Result[*cacheTestObject]{}, fmt.Errorf("resolver saw unrewritten volatile value %q", got)
				}
				leaf, err := cacheTestSessionResourceLeaf(ctx, cacheTestVolatileSessionResourceHandle(string(args.Slot)))
				if err != nil {
					return Result[*cacheTestObject]{}, err
				}
				return NewResultForCurrentCall(ctx, &cacheTestObject{
					Value:             int(calls.Add(1)),
					dependencyResults: []AnyResult{leaf},
				})
			},
			func(ctx context.Context, _ ObjectResult[cacheTestQuery], args volatileArgs, req *CallRequest) error {
				cache, err := EngineCache(ctx)
				if err != nil {
					return err
				}
				clientMetadata, err := engine.ClientMetadataFromContext(ctx)
				if err != nil {
					return err
				}
				handle := cacheTestVolatileSessionResourceHandle(string(args.Slot))
				if err := cache.BindSessionResource(ctx, clientMetadata.SessionID, clientMetadata.ClientID, handle, string(args.Value)); err != nil {
					return err
				}
				return req.SetArgInput(ctx, "value", NewString(cacheTestVolatileValueSentinel), false)
			},
		),
	}.Install(srv)

	const slot = "CONCURRENT_SLOT"
	handle := cacheTestVolatileSessionResourceHandle(slot)

	selectVolatile := func(ctx context.Context, value string) ObjectResult[*cacheTestObject] {
		t.Helper()
		var res ObjectResult[*cacheTestObject]
		err := srv.Select(ctx, srv.Root(), &res, Selector{
			Field: "volatileConcurrentParent",
			Args: []NamedInput{
				{Name: "slot", Value: NewString(slot)},
				{Name: "value", Value: NewString(value)},
			},
		})
		assert.NilError(t, err)
		return res
	}

	// Session A: bind "alpha"
	sessionACtx := engine.ContextWithClientMetadata(t.Context(), &engine.ClientMetadata{
		ClientID:  "client-a",
		SessionID: "session-a",
	})
	sessionACtx = ContextWithCache(sessionACtx, c)
	assert.NilError(t, c.BindSessionResource(sessionACtx, "session-a", "client-a", handle, "alpha"))

	// Prime cache from default session
	first := selectVolatile(ctx, "alpha")
	assert.Assert(t, !first.HitCache())
	assert.Equal(t, int32(1), calls.Load())

	// Session B: bind "beta", same slot
	sessionBCtx := engine.ContextWithClientMetadata(t.Context(), &engine.ClientMetadata{
		ClientID:  "client-b",
		SessionID: "session-b",
	})
	sessionBCtx = ContextWithCache(sessionBCtx, c)
	assert.NilError(t, c.BindSessionResource(sessionBCtx, "session-b", "client-b", handle, "beta"))

	// Both sessions look up the same broad cache key
	hitA, hitAOk, err := c.lookupCallRequest(sessionACtx, "session-a", srv, &CallRequest{
		ResultCall: func() *ResultCall {
			rc, err := first.ResultCall()
			assert.NilError(t, err)
			return rc.clone()
		}(),
	})
	assert.NilError(t, err)
	assert.Assert(t, hitAOk, "session A should hit cache")
	assert.Assert(t, hitA.HitCache())

	hitB, hitBOk, err := c.lookupCallRequest(sessionBCtx, "session-b", srv, &CallRequest{
		ResultCall: func() *ResultCall {
			rc, err := first.ResultCall()
			assert.NilError(t, err)
			return rc.clone()
		}(),
	})
	assert.NilError(t, err)
	assert.Assert(t, hitBOk, "session B should hit cache")
	assert.Assert(t, hitB.HitCache())

	// Verify each session resolves its own volatile value
	resolvedA, err := c.ResolveSessionResource(sessionACtx, "session-a", "client-a", handle)
	assert.NilError(t, err)
	assert.Equal(t, "alpha", resolvedA)

	resolvedB, err := c.ResolveSessionResource(sessionBCtx, "session-b", "client-b", handle)
	assert.NilError(t, err)
	assert.Equal(t, "beta", resolvedB)

	// Resolver should NOT have been called again — both are cache hits
	assert.Equal(t, int32(1), calls.Load())

	assert.NilError(t, c.ReleaseSession(ctx, "test-session"))
	assert.NilError(t, c.ReleaseSession(sessionACtx, "session-a"))
	assert.NilError(t, c.ReleaseSession(sessionBCtx, "session-b"))
}

// TestCacheVolatileNestedWithNonVolatile verifies that a volatile exec followed
// by a non-volatile exec produces correct cache behavior: changing only the
// volatile value should reuse the volatile exec but still run the non-volatile
// exec if its non-volatile inputs changed.
func TestCacheVolatileNestedWithNonVolatile(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	ctx := ContextWithCache(baseCtx, c)
	srv := cacheTestServer(t)

	type volatileArgs struct {
		Slot  String `name:"slot"`
		Value String `name:"value"`
	}

	var volatileCalls atomic.Int32
	Fields[cacheTestQuery]{
		NodeFuncWithDynamicInputs(
			"volatileNestedParent",
			func(ctx context.Context, _ ObjectResult[cacheTestQuery], args volatileArgs) (Result[*cacheTestObject], error) {
				if got := string(args.Value); got != cacheTestVolatileValueSentinel {
					return Result[*cacheTestObject]{}, fmt.Errorf("resolver saw unrewritten volatile value %q", got)
				}
				leaf, err := cacheTestSessionResourceLeaf(ctx, cacheTestVolatileSessionResourceHandle(string(args.Slot)))
				if err != nil {
					return Result[*cacheTestObject]{}, err
				}
				return NewResultForCurrentCall(ctx, &cacheTestObject{
					Value:             int(volatileCalls.Add(1)),
					dependencyResults: []AnyResult{leaf},
				})
			},
			func(ctx context.Context, _ ObjectResult[cacheTestQuery], args volatileArgs, req *CallRequest) error {
				cache, err := EngineCache(ctx)
				if err != nil {
					return err
				}
				clientMetadata, err := engine.ClientMetadataFromContext(ctx)
				if err != nil {
					return err
				}
				handle := cacheTestVolatileSessionResourceHandle(string(args.Slot))
				if err := cache.BindSessionResource(ctx, clientMetadata.SessionID, clientMetadata.ClientID, handle, string(args.Value)); err != nil {
					return err
				}
				return req.SetArgInput(ctx, "value", NewString(cacheTestVolatileValueSentinel), false)
			},
		),
	}.Install(srv)

	type regularArgs struct {
		Marker String `name:"marker"`
	}
	var regularCalls atomic.Int32
	Fields[*cacheTestObject]{
		NodeFunc("regularChild", func(ctx context.Context, self ObjectResult[*cacheTestObject], args regularArgs) (Result[*cacheTestObject], error) {
			return NewResultForCurrentCall(ctx, &cacheTestObject{
				Value: int(regularCalls.Add(1)),
			})
		}),
	}.Install(srv)

	const slot = "NESTED_SLOT"

	selectChain := func(ctx context.Context, volatileValue, marker string) ObjectResult[*cacheTestObject] {
		t.Helper()
		var parent ObjectResult[*cacheTestObject]
		err := srv.Select(ctx, srv.Root(), &parent, Selector{
			Field: "volatileNestedParent",
			Args: []NamedInput{
				{Name: "slot", Value: NewString(slot)},
				{Name: "value", Value: NewString(volatileValue)},
			},
		})
		assert.NilError(t, err)
		var child ObjectResult[*cacheTestObject]
		err = srv.Select(ctx, parent, &child, Selector{
			Field: "regularChild",
			Args: []NamedInput{
				{Name: "marker", Value: NewString(marker)},
			},
		})
		assert.NilError(t, err)
		return child
	}

	// First call: volatile=v1, marker=m1
	first := selectChain(ctx, "v1", "m1")
	assert.Assert(t, !first.HitCache())
	assert.Equal(t, int32(1), volatileCalls.Load())
	assert.Equal(t, int32(1), regularCalls.Load())

	// Same volatile, same marker → full cache hit
	second := selectChain(ctx, "v1", "m1")
	assert.Assert(t, second.HitCache())
	assert.Equal(t, int32(1), volatileCalls.Load())
	assert.Equal(t, int32(1), regularCalls.Load())

	// Different volatile, same marker → volatile exec hits cache, regular child
	// also hits cache because its non-volatile inputs (marker) didn't change
	third := selectChain(ctx, "v2", "m1")
	assert.Assert(t, third.HitCache())
	assert.Equal(t, int32(1), volatileCalls.Load())
	assert.Equal(t, int32(1), regularCalls.Load())

	// Different volatile AND different marker → volatile exec hits cache,
	// regular child misses because marker changed
	fourth := selectChain(ctx, "v3", "m2")
	assert.Assert(t, !fourth.HitCache())
	assert.Equal(t, int32(1), volatileCalls.Load())
	assert.Equal(t, int32(2), regularCalls.Load())

	assert.NilError(t, c.ReleaseSession(ctx, "test-session"))
}

func TestCacheConcurrent(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	keyCall := cacheTestIntCall("42")
	initialized := map[int]bool{}
	var initMu sync.Mutex
	const totalCallers = 100
	const concurrencyKey = "42"

	firstCallEntered := make(chan struct{})
	unblockFirstCall := make(chan struct{})

	callConcKeys := callConcurrencyKeys{
		callKey:        cacheTestCallDigest(keyCall).String(),
		concurrencyKey: concurrencyKey,
	}

	wg := new(sync.WaitGroup)
	wg.Add(1)
	go func() {
		defer wg.Done()
		res, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
			ResultCall:     keyCall,
			ConcurrencyKey: concurrencyKey,
		}, func(_ context.Context) (AnyResult, error) {
			initMu.Lock()
			initialized[0] = true
			initMu.Unlock()
			close(firstCallEntered)
			<-unblockFirstCall
			return cacheTestIntResult(keyCall, 0), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, cacheTestUnwrapInt(t, res))
	}()

	select {
	case <-firstCallEntered:
	case <-time.After(3 * time.Second):
		t.Fatal("timed out waiting for first caller to enter init callback")
	}

	for i := 1; i < totalCallers; i++ {
		wg.Add(1)
		i := i
		go func() {
			defer wg.Done()
			res, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     keyCall,
				ConcurrencyKey: concurrencyKey,
			}, func(_ context.Context) (AnyResult, error) {
				initMu.Lock()
				initialized[i] = true
				initMu.Unlock()
				return cacheTestIntResult(keyCall, i), nil
			})
			assert.NilError(t, err)
			assert.Equal(t, 0, cacheTestUnwrapInt(t, res))
		}()
	}

	waiterCountReached := false
	waiterPollDeadline := time.Now().Add(3 * time.Second)
	lastObservedWaiters := -1
	for time.Now().Before(waiterPollDeadline) {
		c.callsMu.Lock()
		oc := c.ongoingCalls[callConcKeys]
		if oc != nil {
			lastObservedWaiters = oc.waiters
		}
		c.callsMu.Unlock()

		if oc != nil && lastObservedWaiters == totalCallers {
			waiterCountReached = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	assert.Assert(t, waiterCountReached, "expected %d waiters, last observed %d", totalCallers, lastObservedWaiters)

	close(unblockFirstCall)

	ongoingCleared := false
	clearPollDeadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(clearPollDeadline) {
		c.callsMu.Lock()
		_, exists := c.ongoingCalls[callConcKeys]
		c.callsMu.Unlock()
		if !exists {
			ongoingCleared = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	assert.Assert(t, ongoingCleared, "ongoing call was not cleared")

	wg.Wait()

	initMu.Lock()
	defer initMu.Unlock()
	assert.Assert(t, is.Len(initialized, 1))
	assert.Assert(t, initialized[0])
	assert.Equal(t, 1, cacheIface.Size())
}

func TestCacheEvaluate(t *testing.T) {
	t.Parallel()

	newEvalEnv := func(t *testing.T) (context.Context, *Cache, *Server) {
		t.Helper()
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		ctx = ContextWithCache(ctx, cacheIface)
		srv := cacheTestServer(t)
		return ctx, cacheIface, srv
	}

	t.Run("singleflight", func(t *testing.T) {
		t.Parallel()
		ctx, c, srv := newEvalEnv(t)

		frame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-singleflight",
		}

		var evalCalls atomic.Int32
		started := make(chan struct{})
		release := make(chan struct{})
		var startOnce sync.Once

		resAny, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: frame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, frame, &cacheTestObject{
				Value: 1,
				lazyEval: func(context.Context) error {
					evalCalls.Add(1)
					startOnce.Do(func() {
						close(started)
					})
					<-release
					return nil
				},
			}), nil
		})
		assert.NilError(t, err)
		res := resAny.(ObjectResult[*cacheTestObject])

		group := new(errgroup.Group)
		for range 8 {
			group.Go(func() error {
				return c.Evaluate(ctx, res)
			})
		}

		select {
		case <-started:
		case <-time.After(3 * time.Second):
			t.Fatal("timed out waiting for lazy evaluation to start")
		}
		close(release)
		assert.NilError(t, group.Wait())
		assert.Equal(t, int32(1), evalCalls.Load())

		assert.NilError(t, c.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
	})

	t.Run("reacquires dedicated lease instead of reusing request lease", func(t *testing.T) {
		t.Parallel()
		ctx := cacheTestContext(t.Context())
		leaseProvider := &cacheTestLeaseProvider{}
		ctx = ContextWithOperationLeaseProvider(ctx, leaseProvider)
		ctx = leases.WithLease(ctx, "request-1")
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		ctx = ContextWithCache(ctx, cacheIface)
		srv := cacheTestServer(t)

		frame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-shared-lease",
		}

		var seenLease string
		resAny, err := cacheIface.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: frame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, frame, &cacheTestObject{
				Value: 1,
				lazyEval: func(ctx context.Context) error {
					var err error
					ctx, err = snapshots.EnsureLease(ctx)
					if err != nil {
						return err
					}
					leaseID, ok := leases.FromContext(ctx)
					if !ok || leaseID == "" {
						return fmt.Errorf("lazy evaluation missing operation lease")
					}
					if leaseID == "request-1" {
						return fmt.Errorf("lazy evaluation reused request lease %q", leaseID)
					}
					if !strings.HasPrefix(leaseID, "shared-") {
						return fmt.Errorf("lazy evaluation did not use shared lease: %q", leaseID)
					}
					seenLease = leaseID
					return nil
				},
			}), nil
		})
		assert.NilError(t, err)

		assert.NilError(t, cacheIface.Evaluate(ctx, resAny))
		assert.Assert(t, strings.HasPrefix(seenLease, "shared-"))
		assert.Assert(t, leaseProvider.nextLeaseID.Load() > 0)
		assert.Equal(t, leaseProvider.nextLeaseID.Load(), leaseProvider.releases.Load())

		assert.NilError(t, cacheIface.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
	})

	t.Run("lazy evaluation without lease-sensitive work does not acquire lease", func(t *testing.T) {
		t.Parallel()
		ctx := cacheTestContext(t.Context())
		leaseProvider := &cacheTestLeaseProvider{}
		ctx = ContextWithOperationLeaseProvider(ctx, leaseProvider)
		ctx = leases.WithLease(ctx, "request-1")
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		ctx = ContextWithCache(ctx, cacheIface)
		srv := cacheTestServer(t)

		frame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-no-lease",
		}

		resAny, err := cacheIface.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: frame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, frame, &cacheTestObject{
				Value: 1,
				lazyEval: func(ctx context.Context) error {
					if leaseID, ok := leases.FromContext(ctx); ok && leaseID != "" {
						return fmt.Errorf("lazy evaluation unexpectedly had operation lease %q", leaseID)
					}
					return nil
				},
			}), nil
		})
		assert.NilError(t, err)

		assert.NilError(t, cacheIface.Evaluate(ctx, resAny))
		assert.Equal(t, int32(0), leaseProvider.nextLeaseID.Load())
		assert.Equal(t, int32(0), leaseProvider.releases.Load())
		assert.NilError(t, cacheIface.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
	})

	t.Run("declared dependency", func(t *testing.T) {
		t.Parallel()
		ctx, c, srv := newEvalEnv(t)

		childFrame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-child",
		}
		var childCalls atomic.Int32
		childAny, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: childFrame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, childFrame, &cacheTestObject{
				Value: 2,
				lazyEval: func(context.Context) error {
					childCalls.Add(1)
					return nil
				},
			}), nil
		})
		assert.NilError(t, err)
		child := childAny.(ObjectResult[*cacheTestObject])

		parentFrame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-parent",
		}
		parentAny, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: parentFrame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, parentFrame, &cacheTestObject{
				Value:             1,
				dependencyResults: []AnyResult{child},
				lazyEval: func(ctx context.Context) error {
					cache, err := EngineCache(ctx)
					assert.NilError(t, err)
					return cache.Evaluate(ctx, child)
				},
			}), nil
		})
		assert.NilError(t, err)
		parent := parentAny.(ObjectResult[*cacheTestObject])

		assert.NilError(t, c.Evaluate(ctx, parent))
		assert.Equal(t, int32(1), childCalls.Load())

		assert.NilError(t, c.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
	})

	t.Run("parallel multi-result", func(t *testing.T) {
		t.Parallel()
		ctx, c, srv := newEvalEnv(t)

		var running atomic.Int32
		started := make(chan struct{}, 2)
		release := make(chan struct{})
		newLazy := func(field string) ObjectResult[*cacheTestObject] {
			frame := &ResultCall{
				Kind:  ResultCallKindField,
				Type:  NewResultCallType((&cacheTestObject{}).Type()),
				Field: field,
			}
			resAny, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: frame}, func(context.Context) (AnyResult, error) {
				return cacheTestObjectResultWithValue(t, srv, frame, &cacheTestObject{
					Value: 1,
					lazyEval: func(context.Context) error {
						if running.Add(1) == 2 {
							started <- struct{}{}
						}
						started <- struct{}{}
						<-release
						running.Add(-1)
						return nil
					},
				}), nil
			})
			assert.NilError(t, err)
			return resAny.(ObjectResult[*cacheTestObject])
		}

		a := newLazy("lazy-parallel-a")
		b := newLazy("lazy-parallel-b")

		errCh := make(chan error, 1)
		go func() {
			errCh <- c.Evaluate(ctx, a, b)
		}()

		select {
		case <-started:
		case <-time.After(3 * time.Second):
			t.Fatal("timed out waiting for first parallel lazy callback")
		}
		select {
		case <-started:
		case <-time.After(3 * time.Second):
			t.Fatal("timed out waiting for second parallel lazy callback")
		}

		close(release)
		assert.NilError(t, <-errCh)
		assert.NilError(t, c.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
	})

	t.Run("non dependency allowed while attached", func(t *testing.T) {
		t.Parallel()
		ctx, c, srv := newEvalEnv(t)

		childFrame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-undeclared-child",
		}
		var childCalls atomic.Int32
		childAny, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: childFrame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, childFrame, &cacheTestObject{
				Value: 2,
				lazyEval: func(context.Context) error {
					childCalls.Add(1)
					return nil
				},
			}), nil
		})
		assert.NilError(t, err)
		child := childAny.(ObjectResult[*cacheTestObject])

		parentFrame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-undeclared-parent",
		}
		parentAny, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: parentFrame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, parentFrame, &cacheTestObject{
				Value: 1,
				lazyEval: func(ctx context.Context) error {
					cache, err := EngineCache(ctx)
					assert.NilError(t, err)
					return cache.Evaluate(ctx, child)
				},
			}), nil
		})
		assert.NilError(t, err)
		parent := parentAny.(ObjectResult[*cacheTestObject])

		assert.NilError(t, c.Evaluate(ctx, parent))
		assert.Equal(t, int32(1), childCalls.Load())

		assert.NilError(t, c.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
	})

	t.Run("recursive", func(t *testing.T) {
		t.Parallel()
		ctx, c, srv := newEvalEnv(t)

		frame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-recursive",
		}
		var self AnyResult
		resAny, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{ResultCall: frame}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, frame, &cacheTestObject{
				Value: 1,
				lazyEval: func(ctx context.Context) error {
					cache, err := EngineCache(ctx)
					assert.NilError(t, err)
					return cache.Evaluate(ctx, self)
				},
			}), nil
		})
		assert.NilError(t, err)
		self = resAny

		err = c.Evaluate(ctx, resAny)
		assert.Assert(t, err != nil)
		assert.ErrorContains(t, err, "recursive lazy evaluation detected")

		assert.NilError(t, c.ReleaseSession(ctx, cacheTestSessionID(t, ctx)))
	})

	t.Run("rejects do-not-cache lazy result", func(t *testing.T) {
		t.Parallel()
		ctx, c, srv := newEvalEnv(t)

		frame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-do-not-cache",
		}

		_, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{
			ResultCall: frame,
			DoNotCache: true,
		}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, frame, &cacheTestObject{
				Value: 1,
				lazyEval: func(context.Context) error {
					return nil
				},
			}), nil
		})
		assert.Assert(t, err != nil)
		assert.ErrorContains(t, err, "cannot be lazy")
	})

	t.Run("allows already attached lazy result from do-not-cache field", func(t *testing.T) {
		t.Parallel()
		ctx, c, srv := newEvalEnv(t)

		lazyFrame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "lazy-parent",
		}
		attachedLazy, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{
			ResultCall: lazyFrame,
		}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResultWithValue(t, srv, lazyFrame, &cacheTestObject{
				Value: 1,
				lazyEval: func(context.Context) error {
					return nil
				},
			}), nil
		})
		assert.NilError(t, err)

		frame := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: "do-not-cache-parent",
		}
		res, err := c.GetOrInitCall(ctx, cacheTestSessionID(t, ctx), srv, &CallRequest{
			ResultCall: frame,
			DoNotCache: true,
		}, func(context.Context) (AnyResult, error) {
			return attachedLazy, nil
		})
		assert.NilError(t, err)
		assert.Equal(t, res.cacheSharedResult().id, attachedLazy.cacheSharedResult().id)
	})
}

func TestCacheErrors(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)

	keyCall := cacheTestIntCall("42")

	myErr := errors.New("nope")
	_, err = cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(_ context.Context) (AnyResult, error) {
		return nil, myErr
	})
	assert.Assert(t, is.ErrorIs(err, myErr))

	otherErr := errors.New("nope 2")
	_, err = cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(_ context.Context) (AnyResult, error) {
		return nil, otherErr
	})
	assert.Assert(t, is.ErrorIs(err, otherErr))

	res, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(_ context.Context) (AnyResult, error) {
		return cacheTestIntResult(keyCall, 1), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, cacheTestUnwrapInt(t, res))

	res, err = cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(_ context.Context) (AnyResult, error) {
		return nil, errors.New("ignored")
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, cacheTestUnwrapInt(t, res))
}

func TestCacheRecursiveCall(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)

	key1Call := cacheTestIntCall("1")

	// recursive calls that are guaranteed to result in deadlock should error out
	_, err = cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: key1Call}, func(ctx context.Context) (AnyResult, error) {
		_, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: key1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(cacheTestIntCall("2"), 2), nil
		})
		return nil, err
	})
	assert.Assert(t, is.ErrorIs(err, ErrCacheRecursiveCall))

	// verify same cache can be called recursively with different keys
	key10Call := cacheTestIntCall("10")
	key11Call := cacheTestIntCall("11")
	v, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: key10Call}, func(ctx context.Context) (AnyResult, error) {
		res, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: key11Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(key11Call, 12), nil
		})
		if err != nil {
			return nil, err
		}
		return cacheTestIntResult(key10Call, cacheTestUnwrapInt(t, res)), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 12, cacheTestUnwrapInt(t, v))
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func TestCacheContextCancel(t *testing.T) {
	t.Run("cancels after all are canceled", func(t *testing.T) {
		t.Parallel()
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)

		keyCall := cacheTestIntCall("1")
		ctx1, cancel1 := context.WithCancel(ctx)
		ctx2, cancel2 := context.WithCancel(ctx)
		ctx3, cancel3 := context.WithCancel(ctx)

		errCh1 := make(chan error, 1)
		started1 := make(chan struct{})
		go func() {
			defer close(errCh1)
			_, err := cacheIface.GetOrInitCall(ctx1, "test-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     keyCall,
				ConcurrencyKey: "1",
			}, func(ctx context.Context) (AnyResult, error) {
				close(started1)
				<-ctx.Done()
				return nil, fmt.Errorf("oh no 1")
			})
			errCh1 <- err
		}()
		select {
		case <-started1:
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for started1")
		}

		errCh2 := make(chan error, 1)
		go func() {
			defer close(errCh2)
			_, err := cacheIface.GetOrInitCall(ctx2, "test-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     keyCall,
				ConcurrencyKey: "1",
			}, func(ctx context.Context) (AnyResult, error) {
				<-ctx.Done()
				return nil, fmt.Errorf("oh no 2")
			})
			errCh2 <- err
		}()

		errCh3 := make(chan error, 1)
		go func() {
			defer close(errCh3)
			_, err := cacheIface.GetOrInitCall(ctx3, "test-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     keyCall,
				ConcurrencyKey: "1",
			}, func(context.Context) (AnyResult, error) {
				return nil, fmt.Errorf("oh no 3")
			})
			errCh3 <- err
		}()

		cancel2()
		select {
		case err := <-errCh2:
			assert.Assert(t, is.ErrorIs(err, context.Canceled))
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for errCh2")
		}
		select {
		case err := <-errCh1:
			t.Fatal("unexpected error from 1st client", err)
		case err := <-errCh3:
			t.Fatal("unexpected error from 3rd client", err)
		default:
		}

		cancel3()
		select {
		case err := <-errCh3:
			assert.Assert(t, is.ErrorIs(err, context.Canceled))
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for errCh3")
		}
		select {
		case err := <-errCh1:
			t.Fatal("unexpected error from 1st client", err)
		default:
		}

		cancel1()
		select {
		case err := <-errCh1:
			assert.Assert(t, is.ErrorIs(err, context.Canceled))
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for errCh1")
		}
	})

	t.Run("succeeds if others are canceled", func(t *testing.T) {
		t.Parallel()
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)

		keyCall := cacheTestIntCall("1")
		ctx1, cancel1 := context.WithCancel(ctx)
		t.Cleanup(cancel1)
		ctx2, cancel2 := context.WithCancel(ctx)

		resCh1 := make(chan AnyResult, 1)
		errCh1 := make(chan error, 1)
		started1 := make(chan struct{})
		stop1 := make(chan struct{})
		go func() {
			defer close(resCh1)
			defer close(errCh1)
			res, err := cacheIface.GetOrInitCall(ctx1, "test-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     keyCall,
				ConcurrencyKey: "1",
			}, func(context.Context) (AnyResult, error) {
				close(started1)
				<-stop1
				return cacheTestIntResult(keyCall, 0), nil
			})
			resCh1 <- res
			errCh1 <- err
		}()
		select {
		case <-started1:
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for started1")
		}

		errCh2 := make(chan error, 1)
		go func() {
			defer close(errCh2)
			_, err := cacheIface.GetOrInitCall(ctx2, "test-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     keyCall,
				ConcurrencyKey: "1",
			}, func(context.Context) (AnyResult, error) {
				return nil, fmt.Errorf("unexpected initializer call")
			})
			errCh2 <- err
		}()

		cancel2()
		select {
		case err := <-errCh2:
			assert.Assert(t, is.ErrorIs(err, context.Canceled))
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for errCh2")
		}

		close(stop1)
		select {
		case res := <-resCh1:
			assert.Equal(t, 0, cacheTestUnwrapInt(t, res))
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for resCh1")
		}
		select {
		case err := <-errCh1:
			assert.NilError(t, err)
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for errCh1")
		}
	})

	t.Run("shared call keeps dedicated lease across completion", func(t *testing.T) {
		t.Parallel()
		baseCtx := cacheTestContext(t.Context())
		leaseProvider := &cacheTestLeaseProvider{}
		baseCtx = ContextWithOperationLeaseProvider(baseCtx, leaseProvider)
		cacheIface, err := NewCache(baseCtx, "", nil, nil)
		assert.NilError(t, err)

		reqCall := cacheTestIntCall("shared-lease")
		callConcKeys := callConcurrencyKeys{
			callKey:        cacheTestCallDigest(reqCall).String(),
			concurrencyKey: "shared-lease",
		}

		ctx1Base := engine.ContextWithClientMetadata(leases.WithLease(baseCtx, "request-1"), &engine.ClientMetadata{
			ClientID:  "request-1-client",
			SessionID: "request-1-session",
		})
		ctx1, cancel1 := context.WithCancel(ctx1Base)
		t.Cleanup(cancel1)
		ctx2 := engine.ContextWithClientMetadata(leases.WithLease(baseCtx, "request-2"), &engine.ClientMetadata{
			ClientID:  "request-2-client",
			SessionID: "request-2-session",
		})

		started := make(chan struct{})
		allowReturn := make(chan struct{})
		errCh1 := make(chan error, 1)
		go func() {
			_, err := cacheIface.GetOrInitCall(ctx1, "request-1-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     reqCall,
				ConcurrencyKey: "shared-lease",
			}, func(ctx context.Context) (AnyResult, error) {
				var err error
				ctx, err = snapshots.EnsureLease(ctx)
				if err != nil {
					return nil, err
				}
				leaseID, ok := leases.FromContext(ctx)
				if !ok || leaseID == "" {
					return nil, fmt.Errorf("shared call missing operation lease")
				}
				if leaseID == "request-1" || leaseID == "request-2" {
					return nil, fmt.Errorf("shared call reused request lease %q", leaseID)
				}
				close(started)
				<-allowReturn
				return cacheTestDetachedResult(reqCall, cacheTestLeaseCheckedInt{
					Int: NewInt(1),
					onAttach: func(ctx context.Context) error {
						var err error
						ctx, err = snapshots.EnsureLease(ctx)
						if err != nil {
							return err
						}
						attachLeaseID, ok := leases.FromContext(ctx)
						if !ok || attachLeaseID == "" {
							return fmt.Errorf("attach dependency results missing operation lease")
						}
						if attachLeaseID != leaseID {
							return fmt.Errorf("attach dependency results lease mismatch: got %q want %q", attachLeaseID, leaseID)
						}
						if attachLeaseID == "request-1" || attachLeaseID == "request-2" {
							return fmt.Errorf("attach dependency results reused request lease %q", attachLeaseID)
						}
						return nil
					},
				}), nil
			})
			errCh1 <- err
		}()

		select {
		case <-started:
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for shared call start")
		}

		errCh2 := make(chan error, 1)
		resCh2 := make(chan AnyResult, 1)
		go func() {
			res, err := cacheIface.GetOrInitCall(ctx2, "request-2-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     reqCall,
				ConcurrencyKey: "shared-lease",
			}, func(context.Context) (AnyResult, error) {
				return nil, fmt.Errorf("unexpected initializer call")
			})
			resCh2 <- res
			errCh2 <- err
		}()

		waiterJoined := false
		waiterDeadline := time.Now().Add(5 * time.Second)
		for time.Now().Before(waiterDeadline) {
			cacheIface.callsMu.Lock()
			oc := cacheIface.ongoingCalls[callConcKeys]
			waiters := 0
			if oc != nil {
				waiters = oc.waiters
			}
			cacheIface.callsMu.Unlock()
			if waiters == 2 {
				waiterJoined = true
				break
			}
			time.Sleep(5 * time.Millisecond)
		}
		assert.Assert(t, waiterJoined, "expected second waiter to join shared call")

		cancel1()
		select {
		case err := <-errCh1:
			assert.Assert(t, is.ErrorIs(err, context.Canceled))
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for first waiter cancellation")
		}

		close(allowReturn)
		select {
		case err := <-errCh2:
			assert.NilError(t, err)
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for second waiter result")
		}
		select {
		case <-resCh2:
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for second waiter value")
		}

		assert.Equal(t, int32(1), leaseProvider.nextLeaseID.Load())
		assert.Equal(t, int32(1), leaseProvider.releases.Load())
	})

	t.Run("last waiter canceled fn returns value still releases", func(t *testing.T) {
		t.Parallel()
		// TODO: Re-enable this test once we define and implement the intended
		// last-waiter cleanup semantics for canceled waiters when fn later returns.
		t.Skip("TODO: re-enable after last-waiter canceled cleanup semantics are decided")
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)

		keyCall := cacheTestIntCall("cancel-last-waiter-release")
		ctx1, cancel1 := context.WithCancel(ctx)
		defer cancel1()

		started := make(chan struct{})
		allowReturn := make(chan struct{})
		released := make(chan struct{})

		errCh := make(chan error, 1)
		go func() {
			_, err := cacheIface.GetOrInitCall(ctx1, "test-session", noopTypeResolver{}, &CallRequest{
				ResultCall:     keyCall,
				ConcurrencyKey: "1",
			}, func(context.Context) (AnyResult, error) {
				close(started)
				<-allowReturn
				return cacheTestIntResultWithOnRelease(keyCall, 1, func(context.Context) error {
					close(released)
					return nil
				}), nil
			})
			errCh <- err
		}()

		select {
		case <-started:
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for call start")
		}

		cancel1()
		select {
		case err := <-errCh:
			assert.Assert(t, is.ErrorIs(err, context.Canceled))
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for canceled wait return")
		}

		close(allowReturn)
		select {
		case <-released:
		case <-time.After(5 * time.Second):
			t.Fatal("expected release after call returns with no waiters")
		}
	})
}

func TestSkipDedupe(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)

	keyCall := cacheTestIntCall("1")
	var eg errgroup.Group

	valCh1 := make(chan int, 1)
	started1 := make(chan struct{})
	stop1 := make(chan struct{})
	eg.Go(func() error {
		_, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
			defer close(valCh1)
			close(started1)
			valCh1 <- 1
			<-stop1
			return cacheTestIntResult(keyCall, 1), nil
		})
		return err
	})

	valCh2 := make(chan int, 1)
	started2 := make(chan struct{})
	stop2 := make(chan struct{})
	eg.Go(func() error {
		_, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
			defer close(valCh2)
			close(started2)
			valCh2 <- 2
			<-stop2
			return cacheTestIntResult(keyCall, 2), nil
		})
		return err
	})

	select {
	case <-started1:
	case <-time.After(10 * time.Second):
		t.Fatal("timed out waiting for started1")
	}
	select {
	case <-started2:
	case <-time.After(10 * time.Second):
		t.Fatal("timed out waiting for started2")
	}

	close(stop1)
	close(stop2)

	select {
	case val := <-valCh1:
		assert.Equal(t, 1, val)
	case <-time.After(10 * time.Second):
		t.Fatal("timed out waiting for valCh1")
	}
	select {
	case val := <-valCh2:
		assert.Equal(t, 2, val)
	case <-time.After(10 * time.Second):
		t.Fatal("timed out waiting for valCh2")
	}

	assert.NilError(t, eg.Wait())
}

func TestCacheNilKeyIDRejected(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)

	_, err = cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{}}, func(context.Context) (AnyResult, error) {
		return nil, fmt.Errorf("unexpected initializer call")
	})
	assert.ErrorContains(t, err, "missing field")
}

func TestCacheDifferentConcurrencyKeysDoNotDedupe(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)

	keyCall := cacheTestIntCall("different-concurrency")
	release := make(chan struct{})
	startedA := make(chan struct{})
	startedB := make(chan struct{})
	errCh := make(chan error, 2)
	var initCalls atomic.Int32

	go func() {
		_, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
			ResultCall:     keyCall,
			ConcurrencyKey: "a",
		}, func(context.Context) (AnyResult, error) {
			initCalls.Add(1)
			close(startedA)
			<-release
			return cacheTestIntResult(keyCall, 1), nil
		})
		errCh <- err
	}()
	go func() {
		_, err := cacheIface.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
			ResultCall:     keyCall,
			ConcurrencyKey: "b",
		}, func(context.Context) (AnyResult, error) {
			initCalls.Add(1)
			close(startedB)
			<-release
			return cacheTestIntResult(keyCall, 2), nil
		})
		errCh <- err
	}()

	select {
	case <-startedA:
	case <-time.After(5 * time.Second):
		t.Fatal("timed out waiting for startedA")
	}
	select {
	case <-startedB:
	case <-time.After(5 * time.Second):
		t.Fatal("timed out waiting for startedB")
	}

	close(release)
	assert.NilError(t, <-errCh)
	assert.NilError(t, <-errCh)
	assert.Equal(t, int32(2), initCalls.Load())
}

func TestCacheNilResultIsCached(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	keyCall := cacheTestIntCall("nil-result")
	initCalls := 0

	res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
		initCalls++
		return nil, nil
	})
	assert.NilError(t, err)
	assert.Assert(t, res != nil)
	assert.Assert(t, res.Unwrap() == nil)

	res, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
		initCalls++
		return cacheTestIntResult(keyCall, 42), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, res != nil)
	assert.Assert(t, res.Unwrap() == nil)
	assert.Equal(t, 1, initCalls)
	assert.Equal(t, 1, c.Size())
}

// An expired entry that a session still owns stays in the cache when another
// entry of its class is collected and takes the class's last terms with it:
// the e-graph resets only when no entry is left.
func TestCacheExpiredHeldEntrySurvivesReset(t *testing.T) {
	t.Parallel()
	ctx, cancel := context.WithTimeout(cacheTestContext(t.Context()), 30*time.Second)
	defer cancel()
	c, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, c)
	frame := cacheTestIntCall("expired-held-survives-reset")

	held, err := c.GetOrInitCall(ctx, "holder", noopTypeResolver{}, &CallRequest{ResultCall: frame, TTL: 1}, ValueFunc(cacheTestIntResult(frame, 1)))
	assert.NilError(t, err)
	heldID := held.cacheSharedResult().id
	// Wait out the one-second TTL: the held entry expires.
	time.Sleep(time.Until(time.Unix(held.cacheSharedResult().expiresAtUnix, 0)))

	// Another session misses on the expired entry, computes the recipe again
	// and ends. Its entry is collected, and the class's terms with it, since
	// the class's only other entry has expired.
	again, err := c.GetOrInitCall(ctx, "other", noopTypeResolver{}, &CallRequest{ResultCall: frame.clone()}, ValueFunc(cacheTestIntResult(frame, 2)))
	assert.NilError(t, err)
	assert.Assert(t, again.cacheSharedResult().id != heldID, "a second entry of the recipe")
	assert.NilError(t, c.ReleaseSession(ctx, "other"))

	c.egraphMu.RLock()
	registered := c.resultsByID[heldID] == held.cacheSharedResult()
	c.egraphMu.RUnlock()
	assert.Assert(t, registered, "the holding session still owns the entry")
	_, err = c.ResultCallByResultID(ctx, "holder", uint64(heldID))
	assert.NilError(t, err)
	assert.NilError(t, c.ReleaseSession(ctx, "holder"))
	assert.Equal(t, 0, c.Size())
}

func TestEquivalencySetCacheHits(t *testing.T) {
	t.Parallel()

	// Basic case: equivalent upstream outputs enable a single downstream cache hit
	// even when the downstream recipes are distinct.
	t.Run("basic", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		ctx = ContextWithCache(ctx, cacheIface)
		c := cacheIface

		sharedEq := call.ExtraDigest{
			Digest: digest.FromString("shared-eq-basic"),
			Label:  "eq-shared",
		}
		noiseA := call.ExtraDigest{
			Digest: digest.FromString("basic-noise-a"),
			Label:  "noise-a",
		}
		noiseB := call.ExtraDigest{
			Digest: digest.FromString("basic-noise-b"),
			Label:  "noise-b",
		}
		f1OutCall := cacheTestIntCall("content-f-1", sharedEq, noiseA)
		f2OutCall := cacheTestIntCall("content-f-2", sharedEq, noiseB)

		fInitCalls := 0
		f1Call := cacheTestIntCall("content-f-1")
		f2Call := cacheTestIntCall("content-f-2")
		f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f1Call}, func(context.Context) (AnyResult, error) {
			fInitCalls++
			return cacheTestIntResult(f1OutCall, 11), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f1Res.HitCache())

		f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f2Call}, func(context.Context) (AnyResult, error) {
			fInitCalls++
			return cacheTestIntResult(f2OutCall, 22), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f2Res.HitCache())
		assert.Equal(t, 2, fInitCalls)
		assert.Assert(t, cacheTestMustRecipeID(t, ctx, f1Res).Digest() != cacheTestMustRecipeID(t, ctx, f2Res).Digest())

		g1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "content-g",
			Receiver: &ResultCallRef{ResultID: uint64(f1Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(111)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !g1Res.HitCache())

		g2InitCalls := 0
		g2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "content-g",
			Receiver: &ResultCallRef{ResultID: uint64(f2Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			g2InitCalls++
			return cacheTestPlainResult(NewInt(222)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, g2InitCalls)
		assert.Assert(t, g2Res.HitCache())
		assert.Equal(t, 111, cacheTestUnwrapInt(t, g2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, g1Res), cacheTestMustEncodeID(t, g2Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Deeper chain: equivalence learned at f-level should enable hits at g-level,
	// which then propagate to h-level and i-level for distinct downstream recipes.
	t.Run("deep_chain", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		sharedEq := call.ExtraDigest{
			Digest: digest.FromString("deep-shared-eq"),
			Label:  "eq-shared",
		}
		noiseA := call.ExtraDigest{
			Digest: digest.FromString("deep-noise-a"),
			Label:  "noise-a",
		}
		noiseB := call.ExtraDigest{
			Digest: digest.FromString("deep-noise-b"),
			Label:  "noise-b",
		}
		f1Call := cacheTestIntCall("deep-f-1")
		f2Call := cacheTestIntCall("deep-f-2")
		f1OutCall := cacheTestIntCall("deep-f-1", sharedEq, noiseA)
		f2OutCall := cacheTestIntCall("deep-f-2", sharedEq, noiseB)

		fInitCalls := 0
		f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f1Call}, func(context.Context) (AnyResult, error) {
			fInitCalls++
			return cacheTestIntResult(f1OutCall, 21), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f1Res.HitCache())
		f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f2Call}, func(context.Context) (AnyResult, error) {
			fInitCalls++
			return cacheTestIntResult(f2OutCall, 22), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f2Res.HitCache())
		assert.Equal(t, 2, fInitCalls)

		g1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "deep-g",
			Receiver: &ResultCallRef{ResultID: uint64(f1Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(121)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !g1Res.HitCache())

		h1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "deep-h",
			Receiver: &ResultCallRef{ResultID: uint64(g1Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(221)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !h1Res.HitCache())

		i1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "deep-i",
			Receiver: &ResultCallRef{ResultID: uint64(h1Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(321)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !i1Res.HitCache())

		g2InitCalls := 0
		g2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "deep-g",
			Receiver: &ResultCallRef{ResultID: uint64(f2Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			g2InitCalls++
			return cacheTestPlainResult(NewInt(122)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, g2InitCalls)
		assert.Assert(t, g2Res.HitCache())
		assert.Equal(t, 121, cacheTestUnwrapInt(t, g2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, g1Res), cacheTestMustEncodeID(t, g2Res))

		h2InitCalls := 0
		h2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "deep-h",
			Receiver: &ResultCallRef{ResultID: uint64(g2Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			h2InitCalls++
			return cacheTestPlainResult(NewInt(222)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, h2InitCalls)
		assert.Assert(t, h2Res.HitCache())
		assert.Equal(t, 221, cacheTestUnwrapInt(t, h2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, h1Res), cacheTestMustEncodeID(t, h2Res))

		i2InitCalls := 0
		i2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "deep-i",
			Receiver: &ResultCallRef{ResultID: uint64(h2Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			i2InitCalls++
			return cacheTestPlainResult(NewInt(322)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, i2InitCalls)
		assert.Assert(t, i2Res.HitCache())
		assert.Equal(t, 321, cacheTestUnwrapInt(t, i2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, i1Res), cacheTestMustEncodeID(t, i2Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Late equivalence with noisy metadata: distinct recipes miss until h-level
	// outputs publish overlapping extra digests; once learned, downstream
	// i-level lookups should hit even with non-overlapping extras elsewhere.
	t.Run("late_extra_digests_at_h", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		f1Only := call.ExtraDigest{Digest: digest.FromString("late-f1-only"), Label: "f1-only"}
		f2Only := call.ExtraDigest{Digest: digest.FromString("late-f2-only"), Label: "f2-only"}
		g1Only := call.ExtraDigest{Digest: digest.FromString("late-g1-only"), Label: "g1-only"}
		g2Only := call.ExtraDigest{Digest: digest.FromString("late-g2-only"), Label: "g2-only"}
		sharedA := call.ExtraDigest{Digest: digest.FromString("late-shared-a"), Label: "shared-a"}
		sharedB := call.ExtraDigest{Digest: digest.FromString("late-shared-b"), Label: "shared-b"}
		h1Only := call.ExtraDigest{Digest: digest.FromString("late-h1-only"), Label: "h1-only"}
		h2Only := call.ExtraDigest{Digest: digest.FromString("late-h2-only"), Label: "h2-only"}

		f1Call := cacheTestIntCall("late-f-1")
		f2Call := cacheTestIntCall("late-f-2")
		f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(cacheTestIntCall("late-f-1", f1Only), 41), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f1Res.HitCache())

		g1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "late-g",
			Receiver: &ResultCallRef{ResultID: uint64(f1Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(&ResultCall{
				Kind:         ResultCallKindField,
				Type:         NewResultCallType(Int(0).Type()),
				Field:        "late-g",
				Receiver:     &ResultCallRef{ResultID: uint64(f1Res.cacheSharedResult().id)},
				ExtraDigests: []call.ExtraDigest{g1Only},
			}, 141), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !g1Res.HitCache())

		h1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "late-h",
			Receiver: &ResultCallRef{ResultID: uint64(g1Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(&ResultCall{
				Kind:         ResultCallKindField,
				Type:         NewResultCallType(Int(0).Type()),
				Field:        "late-h",
				Receiver:     &ResultCallRef{ResultID: uint64(g1Res.cacheSharedResult().id)},
				ExtraDigests: []call.ExtraDigest{sharedA, sharedB, h1Only},
			}, 241), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !h1Res.HitCache())

		i1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "late-i",
			Receiver: &ResultCallRef{ResultID: uint64(h1Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(341)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !i1Res.HitCache())

		f2InitCalls := 0
		f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f2Call}, func(context.Context) (AnyResult, error) {
			f2InitCalls++
			return cacheTestIntResult(cacheTestIntCall("late-f-2", f2Only), 42), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 1, f2InitCalls)
		assert.Assert(t, !f2Res.HitCache())

		g2InitCalls := 0
		g2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "late-g",
			Receiver: &ResultCallRef{ResultID: uint64(f2Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			g2InitCalls++
			return cacheTestIntResult(&ResultCall{
				Kind:         ResultCallKindField,
				Type:         NewResultCallType(Int(0).Type()),
				Field:        "late-g",
				Receiver:     &ResultCallRef{ResultID: uint64(f2Res.cacheSharedResult().id)},
				ExtraDigests: []call.ExtraDigest{g2Only},
			}, 142), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 1, g2InitCalls)
		assert.Assert(t, !g2Res.HitCache())

		h2InitCalls := 0
		h2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "late-h",
			Receiver: &ResultCallRef{ResultID: uint64(g2Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			h2InitCalls++
			return cacheTestIntResult(&ResultCall{
				Kind:         ResultCallKindField,
				Type:         NewResultCallType(Int(0).Type()),
				Field:        "late-h",
				Receiver:     &ResultCallRef{ResultID: uint64(g2Res.cacheSharedResult().id)},
				ExtraDigests: []call.ExtraDigest{sharedA, sharedB, h2Only},
			}, 242), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 1, h2InitCalls)
		assert.Assert(t, !h2Res.HitCache())

		i2InitCalls := 0
		i2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
			Kind:     ResultCallKindField,
			Type:     NewResultCallType(Int(0).Type()),
			Field:    "late-i",
			Receiver: &ResultCallRef{ResultID: uint64(h2Res.cacheSharedResult().id)},
		}}, func(context.Context) (AnyResult, error) {
			i2InitCalls++
			return cacheTestPlainResult(NewInt(342)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, i2InitCalls)
		assert.Assert(t, i2Res.HitCache())
		assert.Equal(t, 341, cacheTestUnwrapInt(t, i2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, i1Res), cacheTestMustEncodeID(t, i2Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Multi-input case: downstream z(x,y) should hit across distinct recipes once
	// both input lanes are equivalent (x1~x2 and y1~y2) via shared extra digests.
	// Basically, same as earlier tests but with multiple inputs.
	t.Run("multi_input_all_inputs_equivalent_hit", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		xShared := call.ExtraDigest{Digest: digest.FromString("multi-x-shared"), Label: "x-shared"}
		xNoise1 := call.ExtraDigest{Digest: digest.FromString("multi-x-noise-1"), Label: "x-noise-1"}
		xNoise2 := call.ExtraDigest{Digest: digest.FromString("multi-x-noise-2"), Label: "x-noise-2"}
		yShared := call.ExtraDigest{Digest: digest.FromString("multi-y-shared"), Label: "y-shared"}
		yNoise1 := call.ExtraDigest{Digest: digest.FromString("multi-y-noise-1"), Label: "y-noise-1"}
		yNoise2 := call.ExtraDigest{Digest: digest.FromString("multi-y-noise-2"), Label: "y-noise-2"}

		x1Call := cacheTestIntCall("multi-x-1")
		x2Call := cacheTestIntCall("multi-x-2")
		y1Call := cacheTestIntCall("multi-y-1")
		y2Call := cacheTestIntCall("multi-y-2")
		x1OutCall := cacheTestIntCall("multi-x-1", xShared, xNoise1)
		x2OutCall := cacheTestIntCall("multi-x-2", xShared, xNoise2)
		y1OutCall := cacheTestIntCall("multi-y-1", yShared, yNoise1)
		y2OutCall := cacheTestIntCall("multi-y-2", yShared, yNoise2)

		x1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: x1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(x1OutCall, 11), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !x1Res.HitCache())
		x2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: x2Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(x2OutCall, 12), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !x2Res.HitCache())

		y1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: y1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(y1OutCall, 21), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !y1Res.HitCache())
		y2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: y2Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(y2OutCall, 22), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !y2Res.HitCache())

		zReq := func(xRes, yRes AnyResult) *CallRequest {
			xShared := xRes.cacheSharedResult()
			yShared := yRes.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:  ResultCallKindField,
					Type:  NewResultCallType(Int(0).Type()),
					Field: "multi-z",
					Args: []*ResultCallArg{
						{Name: "x", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(xShared.id)}}},
						{Name: "y", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(yShared.id)}}},
					},
				},
			}
		}

		z1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, zReq(x1Res, y1Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(501)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !z1Res.HitCache())

		z2InitCalls := 0
		z2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, zReq(x2Res, y2Res), func(context.Context) (AnyResult, error) {
			z2InitCalls++
			return cacheTestPlainResult(NewInt(502)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, z2InitCalls)
		assert.Assert(t, z2Res.HitCache())
		assert.Equal(t, 501, cacheTestUnwrapInt(t, z2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, z1Res), cacheTestMustEncodeID(t, z2Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Multi-input miss case: if only one input lane is equivalent (x1~x2) but
	// the other lane is not (y1 !~ y2), z(x,y) must miss and execute.
	t.Run("multi_input_partial_equivalence_miss", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		xShared := call.ExtraDigest{Digest: digest.FromString("multi-partial-x-shared"), Label: "x-shared"}
		xNoise1 := call.ExtraDigest{Digest: digest.FromString("multi-partial-x-noise-1"), Label: "x-noise-1"}
		xNoise2 := call.ExtraDigest{Digest: digest.FromString("multi-partial-x-noise-2"), Label: "x-noise-2"}
		yOnly1 := call.ExtraDigest{Digest: digest.FromString("multi-partial-y-only-1"), Label: "y-only-1"}
		yOnly2 := call.ExtraDigest{Digest: digest.FromString("multi-partial-y-only-2"), Label: "y-only-2"}

		x1Call := cacheTestIntCall("multi-partial-x-1")
		x2Call := cacheTestIntCall("multi-partial-x-2")
		y1Call := cacheTestIntCall("multi-partial-y-1")
		y2Call := cacheTestIntCall("multi-partial-y-2")
		x1OutCall := cacheTestIntCall("multi-partial-x-1", xShared, xNoise1)
		x2OutCall := cacheTestIntCall("multi-partial-x-2", xShared, xNoise2)
		y1OutCall := cacheTestIntCall("multi-partial-y-1", yOnly1)
		y2OutCall := cacheTestIntCall("multi-partial-y-2", yOnly2)

		x1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: x1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(x1OutCall, 31), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !x1Res.HitCache())
		x2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: x2Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(x2OutCall, 32), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !x2Res.HitCache())

		y1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: y1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(y1OutCall, 41), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !y1Res.HitCache())
		y2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: y2Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(y2OutCall, 42), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !y2Res.HitCache())

		zReq := func(xRes, yRes AnyResult) *CallRequest {
			xShared := xRes.cacheSharedResult()
			yShared := yRes.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:  ResultCallKindField,
					Type:  NewResultCallType(Int(0).Type()),
					Field: "multi-partial-z",
					Args: []*ResultCallArg{
						{Name: "x", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(xShared.id)}}},
						{Name: "y", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(yShared.id)}}},
					},
				},
			}
		}

		z1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, zReq(x1Res, y1Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(701)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !z1Res.HitCache())

		z2InitCalls := 0
		z2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, zReq(x2Res, y2Res), func(context.Context) (AnyResult, error) {
			z2InitCalls++
			return cacheTestPlainResult(NewInt(702)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 1, z2InitCalls)
		assert.Assert(t, !z2Res.HitCache())
		assert.Equal(t, 702, cacheTestUnwrapInt(t, z2Res))
		assert.Assert(t, cacheTestMustEncodeID(t, z2Res) != cacheTestMustEncodeID(t, z1Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Transitive bridge case: f1 and f3 do not share a direct digest, but f2
	// links both sides (A on f1/f2 and B on f2/f3), so equivalence should merge
	// transitively. After caching g(f1), a lookup of g(f3) should hit while still
	// returning g3Key as the request-facing ID digest.
	t.Run("transitive_extra_digest_merge_bridge_hit", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		bridgeA := call.ExtraDigest{Digest: digest.FromString("bridge-a"), Label: "bridge-a"}
		bridgeB := call.ExtraDigest{Digest: digest.FromString("bridge-b"), Label: "bridge-b"}
		noise1 := call.ExtraDigest{Digest: digest.FromString("bridge-noise-1"), Label: "noise-1"}
		noise2 := call.ExtraDigest{Digest: digest.FromString("bridge-noise-2"), Label: "noise-2"}
		noise3 := call.ExtraDigest{Digest: digest.FromString("bridge-noise-3"), Label: "noise-3"}

		f1Call := cacheTestIntCall("bridge-f-1")
		f2Call := cacheTestIntCall("bridge-f-2")
		f3Call := cacheTestIntCall("bridge-f-3")
		f1OutCall := cacheTestIntCall("bridge-f-1", bridgeA, noise1)
		f2OutCall := cacheTestIntCall("bridge-f-2", bridgeA, bridgeB, noise2)
		f3OutCall := cacheTestIntCall("bridge-f-3", bridgeB, noise3)

		f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(f1OutCall, 101), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f1Res.HitCache())
		f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f2Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(f2OutCall, 102), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f2Res.HitCache())
		f3Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f3Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(f3OutCall, 103), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f3Res.HitCache())

		gReq := func(parent AnyResult) *CallRequest {
			parentShared := parent.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:     ResultCallKindField,
					Type:     NewResultCallType(Int(0).Type()),
					Field:    "bridge-g",
					Receiver: &ResultCallRef{ResultID: uint64(parentShared.id)},
				},
			}
		}

		g1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, gReq(f1Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(901)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !g1Res.HitCache())

		g3InitCalls := 0
		g3Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, gReq(f3Res), func(context.Context) (AnyResult, error) {
			g3InitCalls++
			return cacheTestPlainResult(NewInt(903)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, g3InitCalls)
		assert.Assert(t, g3Res.HitCache())
		assert.Equal(t, 901, cacheTestUnwrapInt(t, g3Res))
		assert.Equal(t, cacheTestMustEncodeID(t, g1Res), cacheTestMustEncodeID(t, g3Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Negative bridge case: f1 and f2 overlap on A, but f3 only overlaps with B
	// and f2 does not carry B, so there is no bridge from f1 to f3.
	// We still expect g(f2) to hit from g(f1), while g(f3) must remain a miss.
	t.Run("transitive_bridge_no_bridge_no_hit", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		bridgeA := call.ExtraDigest{Digest: digest.FromString("nobridge-a"), Label: "bridge-a"}
		bridgeB := call.ExtraDigest{Digest: digest.FromString("nobridge-b"), Label: "bridge-b"}
		other := call.ExtraDigest{Digest: digest.FromString("nobridge-other"), Label: "other"}
		noise1 := call.ExtraDigest{Digest: digest.FromString("nobridge-noise-1"), Label: "noise-1"}
		noise2 := call.ExtraDigest{Digest: digest.FromString("nobridge-noise-2"), Label: "noise-2"}
		noise3 := call.ExtraDigest{Digest: digest.FromString("nobridge-noise-3"), Label: "noise-3"}

		f1Call := cacheTestIntCall("nobridge-f-1")
		f2Call := cacheTestIntCall("nobridge-f-2")
		f3Call := cacheTestIntCall("nobridge-f-3")
		f1OutCall := cacheTestIntCall("nobridge-f-1", bridgeA, noise1)
		f2OutCall := cacheTestIntCall("nobridge-f-2", bridgeA, other, noise2)
		f3OutCall := cacheTestIntCall("nobridge-f-3", bridgeB, noise3)

		f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(f1OutCall, 111), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f1Res.HitCache())
		f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f2Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(f2OutCall, 112), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f2Res.HitCache())
		f3Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f3Call}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(f3OutCall, 113), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f3Res.HitCache())

		gReq := func(parent AnyResult) *CallRequest {
			parentShared := parent.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:     ResultCallKindField,
					Type:     NewResultCallType(Int(0).Type()),
					Field:    "nobridge-g",
					Receiver: &ResultCallRef{ResultID: uint64(parentShared.id)},
				},
			}
		}

		g1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, gReq(f1Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(911)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !g1Res.HitCache())

		g2InitCalls := 0
		g2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, gReq(f2Res), func(context.Context) (AnyResult, error) {
			g2InitCalls++
			return cacheTestPlainResult(NewInt(912)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, g2InitCalls)
		assert.Assert(t, g2Res.HitCache())
		assert.Equal(t, 911, cacheTestUnwrapInt(t, g2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, g1Res), cacheTestMustEncodeID(t, g2Res))

		g3InitCalls := 0
		g3Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, gReq(f3Res), func(context.Context) (AnyResult, error) {
			g3InitCalls++
			return cacheTestPlainResult(NewInt(913)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 1, g3InitCalls)
		assert.Assert(t, !g3Res.HitCache())
		assert.Equal(t, 913, cacheTestUnwrapInt(t, g3Res))
		assert.Assert(t, cacheTestMustEncodeID(t, g3Res) != cacheTestMustEncodeID(t, g1Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Fanout/fanin repair case:
	//
	//   branch 1 (seeded first):
	//     f1 -> left1
	//       \-> right1
	//     join1(left1,right1)
	//
	//   branch 2 (different recipe):
	//     f2 -> left2
	//       \-> right2
	//     join2(left2,right2)
	//
	//   equivalence digest introduced later:
	//     f1 ~ f2   (shared extra digest)
	//
	// Expected repair/propagation:
	//   left1 ~ left2
	//   right1 ~ right2
	//   => join1(left1,right1) ~ join2(left2,right2)
	t.Run("fanout_fanin_join_hit_after_repair", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		shared := call.ExtraDigest{Digest: digest.FromString("fanout-shared"), Label: "fanout-shared"}
		noise1 := call.ExtraDigest{Digest: digest.FromString("fanout-noise-1"), Label: "noise-1"}
		noise2 := call.ExtraDigest{Digest: digest.FromString("fanout-noise-2"), Label: "noise-2"}

		rootReq := func(field string, extras ...call.ExtraDigest) *CallRequest {
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:         ResultCallKindField,
					Type:         NewResultCallType(Int(0).Type()),
					Field:        field,
					ExtraDigests: slices.Clone(extras),
				},
			}
		}

		f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-f-1"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(101)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f1Res.HitCache())
		f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-f-2"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(102)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f2Res.HitCache())

		unaryReq := func(parent AnyResult, field string) *CallRequest {
			parentShared := parent.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:     ResultCallKindField,
					Type:     NewResultCallType(Int(0).Type()),
					Field:    field,
					Receiver: &ResultCallRef{ResultID: uint64(parentShared.id)},
				},
			}
		}
		joinReq := func(left, right AnyResult) *CallRequest {
			leftShared := left.cacheSharedResult()
			rightShared := right.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:  ResultCallKindField,
					Type:  NewResultCallType(Int(0).Type()),
					Field: "fanout-join",
					Args: []*ResultCallArg{
						{Name: "left", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(leftShared.id)}}},
						{Name: "right", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(rightShared.id)}}},
					},
				},
			}
		}

		left1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f1Res, "fanout-left"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(1001)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !left1Res.HitCache())
		right1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f1Res, "fanout-right"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(1002)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !right1Res.HitCache())
		join1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, joinReq(left1Res, right1Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(1101)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !join1Res.HitCache())

		f1AliasInitCalls := 0
		f1AliasRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-f-1", shared, noise1), func(context.Context) (AnyResult, error) {
			f1AliasInitCalls++
			return cacheTestPlainResult(NewInt(1911)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, f1AliasInitCalls)
		assert.Assert(t, f1AliasRes.HitCache())
		assert.Equal(t, 101, cacheTestUnwrapInt(t, f1AliasRes))

		f2AliasInitCalls := 0
		f2AliasRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-f-2", shared, noise2), func(context.Context) (AnyResult, error) {
			f2AliasInitCalls++
			return cacheTestPlainResult(NewInt(1912)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, f2AliasInitCalls)
		assert.Assert(t, f2AliasRes.HitCache())
		assert.Equal(t, 102, cacheTestUnwrapInt(t, f2AliasRes))

		left2InitCalls := 0
		left2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f2Res, "fanout-left"), func(context.Context) (AnyResult, error) {
			left2InitCalls++
			return cacheTestPlainResult(NewInt(2001)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, left2InitCalls)
		assert.Assert(t, left2Res.HitCache())
		assert.Equal(t, 1001, cacheTestUnwrapInt(t, left2Res))

		right2InitCalls := 0
		right2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f2Res, "fanout-right"), func(context.Context) (AnyResult, error) {
			right2InitCalls++
			return cacheTestPlainResult(NewInt(2002)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, right2InitCalls)
		assert.Assert(t, right2Res.HitCache())
		assert.Equal(t, 1002, cacheTestUnwrapInt(t, right2Res))

		join2InitCalls := 0
		join2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, joinReq(left2Res, right2Res), func(context.Context) (AnyResult, error) {
			join2InitCalls++
			return cacheTestPlainResult(NewInt(2101)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, join2InitCalls)
		assert.Assert(t, join2Res.HitCache())
		assert.Equal(t, 1101, cacheTestUnwrapInt(t, join2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, join1Res), cacheTestMustEncodeID(t, join2Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	t.Run("fanout_fanin_late_merge_enables_downstream_join_input_hit", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		shared := call.ExtraDigest{Digest: digest.FromString("fanout-late-shared"), Label: "fanout-shared"}
		noise1 := call.ExtraDigest{Digest: digest.FromString("fanout-late-noise-1"), Label: "noise-1"}
		noise2 := call.ExtraDigest{Digest: digest.FromString("fanout-late-noise-2"), Label: "noise-2"}

		rootReq := func(field string, extras ...call.ExtraDigest) *CallRequest {
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:         ResultCallKindField,
					Type:         NewResultCallType(Int(0).Type()),
					Field:        field,
					ExtraDigests: slices.Clone(extras),
				},
			}
		}

		f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-late-f-1"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(301)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f1Res.HitCache())
		f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-late-f-2"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(302)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !f2Res.HitCache())

		unaryReq := func(parent AnyResult, field string) *CallRequest {
			parentShared := parent.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:     ResultCallKindField,
					Type:     NewResultCallType(Int(0).Type()),
					Field:    field,
					Receiver: &ResultCallRef{ResultID: uint64(parentShared.id)},
				},
			}
		}
		joinReq := func(left, right AnyResult) *CallRequest {
			leftShared := left.cacheSharedResult()
			rightShared := right.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:  ResultCallKindField,
					Type:  NewResultCallType(Int(0).Type()),
					Field: "fanout-late-join",
					Args: []*ResultCallArg{
						{Name: "left", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(leftShared.id)}}},
						{Name: "right", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(rightShared.id)}}},
					},
				},
			}
		}
		topReq := func(join AnyResult) *CallRequest {
			joinShared := join.cacheSharedResult()
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:  ResultCallKindField,
					Type:  NewResultCallType(Int(0).Type()),
					Field: "fanout-late-top",
					Args: []*ResultCallArg{
						{Name: "join", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(joinShared.id)}}},
					},
				},
			}
		}

		left1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f1Res, "fanout-late-left"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(3001)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !left1Res.HitCache())
		right1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f1Res, "fanout-late-right"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(3002)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !right1Res.HitCache())
		join1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, joinReq(left1Res, right1Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(3101)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !join1Res.HitCache())

		left2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f2Res, "fanout-late-left"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(4001)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !left2Res.HitCache())
		right2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, unaryReq(f2Res, "fanout-late-right"), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(4002)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !right2Res.HitCache())
		join2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, joinReq(left2Res, right2Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(4101)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !join2Res.HitCache())

		f1AliasInitCalls := 0
		f1AliasRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-late-f-1", shared, noise1), func(context.Context) (AnyResult, error) {
			f1AliasInitCalls++
			return cacheTestPlainResult(NewInt(3911)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, f1AliasInitCalls)
		assert.Assert(t, f1AliasRes.HitCache())
		assert.Equal(t, 301, cacheTestUnwrapInt(t, f1AliasRes))

		f2AliasInitCalls := 0
		f2AliasRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, rootReq("fanout-late-f-2", shared, noise2), func(context.Context) (AnyResult, error) {
			f2AliasInitCalls++
			return cacheTestPlainResult(NewInt(3912)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, f2AliasInitCalls)
		assert.Assert(t, f2AliasRes.HitCache())
		assert.Equal(t, 302, cacheTestUnwrapInt(t, f2AliasRes))

		top1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, topReq(join1Res), func(context.Context) (AnyResult, error) {
			return cacheTestPlainResult(NewInt(5101)), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !top1Res.HitCache())

		top2InitCalls := 0
		top2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, topReq(join2Res), func(context.Context) (AnyResult, error) {
			top2InitCalls++
			return cacheTestPlainResult(NewInt(5201)), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, top2InitCalls)
		assert.Assert(t, top2Res.HitCache())
		assert.Equal(t, 5101, cacheTestUnwrapInt(t, top2Res))
		assert.Equal(t, cacheTestMustEncodeID(t, top1Res), cacheTestMustEncodeID(t, top2Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Congruence merge onto an already repaired root:
	//
	//   s(f1) -> f1      (s returns its receiver)
	//   s(f2) -> q
	//   u(q)  -> o3,  w(o3) -> o5
	//   u(f1) -> o4
	//
	//   equivalence digest introduced later:
	//     f1 ~ f2   (shared extra digest)
	//
	// Expected repair/propagation:
	//   s(f1) ~ s(f2)  => f1 ~ q, merged into the root already being repaired
	//   u(q) ~ u(f1)   => o3 ~ o4
	//   => w(o4) hits w(o3)
	t.Run("congruence_merge_onto_repaired_root", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		c, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)

		shared := call.ExtraDigest{Digest: digest.FromString("repaired-root-shared"), Label: "repaired-root-shared"}
		rootReq := func(field string, extras ...call.ExtraDigest) *CallRequest {
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:         ResultCallKindField,
					Type:         NewResultCallType(Int(0).Type()),
					Field:        field,
					ExtraDigests: slices.Clone(extras),
				},
			}
		}
		unaryReq := func(parent AnyResult, field string) *CallRequest {
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:     ResultCallKindField,
					Type:     NewResultCallType(Int(0).Type()),
					Field:    field,
					Receiver: &ResultCallRef{ResultID: uint64(parent.cacheSharedResult().id)},
				},
			}
		}
		publish := func(req *CallRequest, fn func() AnyResult) (AnyResult, int) {
			initCalls := 0
			res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, req, func(context.Context) (AnyResult, error) {
				initCalls++
				return fn(), nil
			})
			assert.NilError(t, err)
			return res, initCalls
		}
		intResult := func(v int) func() AnyResult {
			return func() AnyResult { return cacheTestPlainResult(NewInt(v)) }
		}

		f1Res, _ := publish(rootReq("repaired-root-f-1"), intResult(101))
		f2Res, _ := publish(rootReq("repaired-root-f-2"), intResult(102))
		_, _ = publish(unaryReq(f1Res, "repaired-root-s"), func() AnyResult { return f1Res })
		qRes, _ := publish(unaryReq(f2Res, "repaired-root-s"), intResult(202))
		o3Res, _ := publish(unaryReq(qRes, "repaired-root-u"), intResult(303))
		o5Res, _ := publish(unaryReq(o3Res, "repaired-root-w"), intResult(505))
		o4Res, initCalls := publish(unaryReq(f1Res, "repaired-root-u"), intResult(304))
		assert.Equal(t, 1, initCalls)

		f1AliasRes, initCalls := publish(rootReq("repaired-root-f-1", shared), intResult(1911))
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, f1AliasRes.HitCache())
		f2AliasRes, initCalls := publish(rootReq("repaired-root-f-2", shared), intResult(1912))
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, f2AliasRes.HitCache())

		w4Res, initCalls := publish(unaryReq(o4Res, "repaired-root-w"), intResult(9999))
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, w4Res.HitCache())
		assert.Equal(t, 505, cacheTestUnwrapInt(t, w4Res))
		assert.Equal(t, cacheTestMustEncodeID(t, o5Res), cacheTestMustEncodeID(t, w4Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	// Cascaded merge onto an already repaired root, two levels down:
	//
	//   s(f1) -> p,   v(p) -> f1   (v returns an existing result)
	//   s(f2) -> r,   v(r) -> q
	//   u(q)  -> o3,  w(o3) -> o5
	//   u(f1) -> o4
	//
	//   equivalence digest introduced later:
	//     f1 ~ f2   (shared extra digest)
	//
	// Expected repair/propagation:
	//   s(f1) ~ s(f2)  => p ~ r
	//   v(p) ~ v(r)    => f1 ~ q, merged into the root repaired two steps earlier
	//   u(q) ~ u(f1)   => o3 ~ o4
	//   => w(o4) hits w(o3)
	t.Run("cascaded_merge_onto_repaired_root", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		c, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)

		shared := call.ExtraDigest{Digest: digest.FromString("repaired-cascade-shared"), Label: "repaired-cascade-shared"}
		rootReq := func(field string, extras ...call.ExtraDigest) *CallRequest {
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:         ResultCallKindField,
					Type:         NewResultCallType(Int(0).Type()),
					Field:        field,
					ExtraDigests: slices.Clone(extras),
				},
			}
		}
		unaryReq := func(parent AnyResult, field string) *CallRequest {
			return &CallRequest{
				ResultCall: &ResultCall{
					Kind:     ResultCallKindField,
					Type:     NewResultCallType(Int(0).Type()),
					Field:    field,
					Receiver: &ResultCallRef{ResultID: uint64(parent.cacheSharedResult().id)},
				},
			}
		}
		publish := func(req *CallRequest, fn func() AnyResult) (AnyResult, int) {
			initCalls := 0
			res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, req, func(context.Context) (AnyResult, error) {
				initCalls++
				return fn(), nil
			})
			assert.NilError(t, err)
			return res, initCalls
		}
		intResult := func(v int) func() AnyResult {
			return func() AnyResult { return cacheTestPlainResult(NewInt(v)) }
		}

		f1Res, _ := publish(rootReq("repaired-cascade-f-1"), intResult(101))
		f2Res, _ := publish(rootReq("repaired-cascade-f-2"), intResult(102))
		pRes, _ := publish(unaryReq(f1Res, "repaired-cascade-s"), intResult(201))
		rRes, _ := publish(unaryReq(f2Res, "repaired-cascade-s"), intResult(202))
		_, _ = publish(unaryReq(pRes, "repaired-cascade-v"), func() AnyResult { return f1Res })
		qRes, _ := publish(unaryReq(rRes, "repaired-cascade-v"), intResult(402))
		o3Res, _ := publish(unaryReq(qRes, "repaired-cascade-u"), intResult(303))
		o5Res, _ := publish(unaryReq(o3Res, "repaired-cascade-w"), intResult(505))
		o4Res, initCalls := publish(unaryReq(f1Res, "repaired-cascade-u"), intResult(304))
		assert.Equal(t, 1, initCalls)

		f1AliasRes, initCalls := publish(rootReq("repaired-cascade-f-1", shared), intResult(1911))
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, f1AliasRes.HitCache())
		f2AliasRes, initCalls := publish(rootReq("repaired-cascade-f-2", shared), intResult(1912))
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, f2AliasRes.HitCache())

		w4Res, initCalls := publish(unaryReq(o4Res, "repaired-cascade-w"), intResult(9999))
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, w4Res.HitCache())
		assert.Equal(t, 505, cacheTestUnwrapInt(t, w4Res))
		assert.Equal(t, cacheTestMustEncodeID(t, o5Res), cacheTestMustEncodeID(t, w4Res))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})
}

func TestDirectDigestLookupHitsWithoutTermIndex(t *testing.T) {
	t.Run("exact_recipe_digest_hit_without_term_index", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		requestID := call.New().Append(Int(0).Type(), "direct-recipe-request")
		requestCall := cacheTestIntCall("direct-recipe-request")
		outputCall := cacheTestIntCall("direct-recipe-output")
		outputID := call.New().Append(Int(0).Type(), "direct-recipe-output")
		assert.Assert(t, requestID.Digest() != outputID.Digest())

		firstRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(outputCall, 51), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !firstRes.HitCache())

		c.egraphMu.Lock()
		c.inputEqClassToTerms = make(map[eqClassID]map[egraphTermID]struct{})
		c.outputEqClassToTerms = make(map[eqClassID]map[egraphTermID]struct{})
		c.egraphTerms = make(map[egraphTermID]*egraphTerm)
		c.egraphTermsByTermDigest = make(map[string]*set.TreeSet[egraphTermID])
		c.resultOutputEqClasses = make(map[sharedResultID]map[eqClassID]struct{})
		c.outputEqClassResults = make(map[eqClassID]map[sharedResultID]struct{})
		c.termInputProvenance = make(map[egraphTermID][]egraphInputProvenanceKind)
		c.egraphMu.Unlock()

		initCalls := 0
		hitRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
			initCalls++
			return cacheTestIntResult(requestCall, 52), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, hitRes.HitCache())
		assert.Equal(t, 51, cacheTestUnwrapInt(t, hitRes))
		assert.Equal(t, cacheTestMustEncodeID(t, firstRes), cacheTestMustEncodeID(t, hitRes))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	t.Run("extra_digest_hit_without_term_index", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		shared := call.ExtraDigest{
			Digest: digest.FromString("direct-extra-hit-shared"),
			Label:  "shared",
		}
		storedRequestID := call.New().Append(Int(0).Type(), "direct-extra-stored")
		storedRequestCall := cacheTestIntCall("direct-extra-stored")
		storedOutputCall := cacheTestIntCall("direct-extra-stored", shared)
		lookupID := call.New().Append(Int(0).Type(), "direct-extra-lookup").With(call.WithExtraDigest(shared))
		lookupCall := cacheTestIntCall("direct-extra-lookup", shared)
		assert.Assert(t, storedRequestID.Digest() != lookupID.Digest())

		firstRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: storedRequestCall}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(storedOutputCall, 71), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !firstRes.HitCache())

		c.egraphMu.Lock()
		c.inputEqClassToTerms = make(map[eqClassID]map[egraphTermID]struct{})
		c.outputEqClassToTerms = make(map[eqClassID]map[egraphTermID]struct{})
		c.egraphTerms = make(map[egraphTermID]*egraphTerm)
		c.egraphTermsByTermDigest = make(map[string]*set.TreeSet[egraphTermID])
		c.resultOutputEqClasses = make(map[sharedResultID]map[eqClassID]struct{})
		c.outputEqClassResults = make(map[eqClassID]map[sharedResultID]struct{})
		c.termInputProvenance = make(map[egraphTermID][]egraphInputProvenanceKind)
		c.egraphMu.Unlock()

		initCalls := 0
		hitRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: lookupCall}, func(context.Context) (AnyResult, error) {
			initCalls++
			return cacheTestIntResult(lookupCall, 72), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, initCalls)
		assert.Assert(t, hitRes.HitCache())
		assert.Equal(t, 71, cacheTestUnwrapInt(t, hitRes))
		assert.Equal(t, cacheTestMustEncodeID(t, firstRes), cacheTestMustEncodeID(t, hitRes))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})
}

func TestIndexResultDigestsUsesExplicitRequestAndResponseIDs(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	requestExtra := call.ExtraDigest{
		Digest: digest.FromString("index-explicit-request-extra"),
		Label:  "request-extra",
	}
	responseExtra := call.ExtraDigest{
		Digest: digest.FromString("index-explicit-response-extra"),
		Label:  "response-extra",
	}
	requestCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(Int(0).Type()),
		Field: "index-explicit-request",
		ExtraDigests: []call.ExtraDigest{
			requestExtra,
		},
	}
	responseCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(Int(0).Type()),
		Field: "index-explicit-response",
		ExtraDigests: []call.ExtraDigest{
			responseExtra,
		},
	}

	res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
		return NewResultForCall(NewInt(42), responseCall)
	})
	assert.NilError(t, err)
	shared := res.cacheSharedResult()
	assert.Assert(t, shared != nil)

	requestDigest, err := requestCall.deriveRecipeDigest(c)
	assert.NilError(t, err)
	responseDigest, err := responseCall.deriveRecipeDigest(c)
	assert.NilError(t, err)
	for _, dig := range []digest.Digest{
		requestDigest,
		requestExtra.Digest,
		responseDigest,
		responseExtra.Digest,
	} {
		postings := c.egraphResultsByDigest[dig.String()]
		ok := postings != nil && postings.Contains(shared.id)
		assert.Assert(t, ok, "expected posting for digest %s", dig)
	}

	cacheTestReleaseSession(t, c, ctx)
}

func TestStructuralHitCanReuseResultFromSameOutputEqClass(t *testing.T) {
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	shared := call.ExtraDigest{
		Digest: digest.FromString("shared-output-eq-class"),
		Label:  "shared",
	}

	t1Key := call.New().Append(Int(0).Type(), "output-eq-term-1")
	t1Call := cacheTestIntCall("output-eq-term-1")
	t2Key := call.New().Append(Int(0).Type(), "output-eq-term-2")
	t2Call := cacheTestIntCall("output-eq-term-2")
	assert.Assert(t, t1Key.Digest() != t2Key.Digest())

	t1OutCall := cacheTestIntCall("output-eq-out-1", shared)
	t2OutCall := cacheTestIntCall("output-eq-out-2", shared)

	t1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: t1Call}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(t1OutCall, 11), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !t1Res.HitCache())

	t2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: t2Call}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(t2OutCall, 22), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !t2Res.HitCache())

	initCalls := 0
	hitRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: t1Call}, func(context.Context) (AnyResult, error) {
		initCalls++
		return cacheTestIntResult(t1Call, 33), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, initCalls)
	assert.Assert(t, hitRes.HitCache())
	assert.Equal(t, 11, cacheTestUnwrapInt(t, hitRes))
	assert.Equal(t, cacheTestMustEncodeID(t, t1Res), cacheTestMustEncodeID(t, hitRes))

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestTeachCallEquivalentToResult(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	parentCall := cacheTestIntCall("teach-parent")
	parentRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: parentCall}, func(context.Context) (AnyResult, error) {
		return cacheTestPlainResult(NewInt(42)), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !parentRes.HitCache())

	parentShared := parentRes.cacheSharedResult()
	assert.Assert(t, parentShared != nil)

	childCall := &ResultCall{
		Kind:     ResultCallKindField,
		Type:     NewResultCallType(Int(0).Type()),
		Field:    "teach-child",
		Receiver: &ResultCallRef{ResultID: uint64(parentShared.id)},
	}

	assert.NilError(t, c.TeachCallEquivalentToResult(ctx, "test-session", childCall, parentRes))

	childInitCalls := 0
	childRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: childCall.clone()}, func(context.Context) (AnyResult, error) {
		childInitCalls++
		return cacheTestPlainResult(NewInt(99)), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, childInitCalls)
	assert.Assert(t, childRes.HitCache())
	assert.Equal(t, 42, cacheTestUnwrapInt(t, childRes))
	assert.Equal(t, cacheTestMustEncodeID(t, parentRes), cacheTestMustEncodeID(t, childRes))

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestPendingResultCallRefRecipeID(t *testing.T) {
	t.Parallel()

	parentCall := cacheTestIntCall("pending-parent")
	childCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(Int(0).Type()),
		Field: "pending-child",
		Receiver: &ResultCallRef{
			Call: parentCall.clone(),
		},
	}

	parentRecipeID, err := parentCall.recipeID(t.Context(), nil)
	assert.NilError(t, err)
	childRecipeID, err := childCall.recipeID(t.Context(), nil)
	assert.NilError(t, err)
	assert.Assert(t, childRecipeID.Receiver() != nil)
	assert.Equal(t, parentRecipeID.Digest(), childRecipeID.Receiver().Digest())
}

func TestAttachResultNormalizesPendingResultCallRef(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	parentCall := cacheTestIntCall("normalize-parent")
	parentRes, err := NewResultForCall(NewInt(1), parentCall)
	assert.NilError(t, err)
	attachedParent, err := c.AttachResult(ctx, "test-session", noopTypeResolver{}, parentRes)
	assert.NilError(t, err)

	childCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(Int(0).Type()),
		Field: "normalize-child",
		Receiver: &ResultCallRef{
			Call: parentCall.clone(),
		},
	}
	childRes, err := NewResultForCall(NewInt(2), childCall)
	assert.NilError(t, err)
	attachedChild, err := c.AttachResult(ctx, "test-session", noopTypeResolver{}, childRes)
	assert.NilError(t, err)

	parentShared := attachedParent.cacheSharedResult()
	childShared := attachedChild.cacheSharedResult()
	assert.Assert(t, parentShared != nil && parentShared.id != 0)
	assert.Assert(t, childShared != nil && childShared.id != 0)
	assert.Assert(t, childShared.resultCall != nil)
	assert.Assert(t, childShared.resultCall.Receiver != nil)
	assert.Equal(t, uint64(parentShared.id), childShared.resultCall.Receiver.ResultID)
	assert.Assert(t, childShared.resultCall.Receiver.Call == nil)

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestObjectResultResultCallAndReceiver(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	srv := cacheTestServer(t)

	objType := (&cacheTestObject{}).Type()

	parentFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Field: "parent",
		Type:  NewResultCallType(objType),
	}
	parentRes := cacheTestObjectResult(t, srv, parentFrame, 11, nil)
	attachedParentAny, err := cacheIface.AttachResult(ctx, "test-session", srv, parentRes)
	assert.NilError(t, err)
	attachedParent := attachedParentAny.(ObjectResult[*cacheTestObject])

	parentID, err := attachedParent.ID()
	assert.NilError(t, err)

	childFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Field: "child",
		Type:  NewResultCallType(objType),
		Receiver: &ResultCallRef{
			ResultID: parentID.EngineResultID(),
		},
	}
	childRes := cacheTestObjectResult(t, srv, childFrame, 22, nil)
	attachedChildAny, err := cacheIface.AttachResult(ctx, "test-session", srv, childRes)
	assert.NilError(t, err)
	attachedChild := attachedChildAny.(ObjectResult[*cacheTestObject])

	childCall, err := attachedChild.ResultCall()
	assert.NilError(t, err)
	assert.Equal(t, "child", childCall.Field)
	assert.Equal(t, parentID.EngineResultID(), childCall.Receiver.ResultID)

	receiver, err := attachedChild.Receiver(ctx, srv)
	assert.NilError(t, err)
	assert.Assert(t, receiver != nil)

	receiverObj := receiver.(ObjectResult[*cacheTestObject])
	assert.Equal(t, 11, receiverObj.Self().Value)

	receiverCall, err := receiverObj.ResultCall()
	assert.NilError(t, err)
	assert.Equal(t, "parent", receiverCall.Field)
}

func TestCacheHitRewrapsObjectResultForCurrentServer(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)

	srvA := cacheTestObjectResolverServer(t, 1)
	srvB := cacheTestObjectResolverServer(t, 2)
	ctxA := srvToContext(ctx, srvA)
	ctxB := srvToContext(ctx, srvB)

	objAAny, err := srvA.Root().Select(ctxA, srvA, Selector{Field: "obj"})
	assert.NilError(t, err)
	objA := objAAny.(ObjectResult[*cacheTestObject])
	assert.Assert(t, !objA.HitCache())
	markerAAny, err := objA.Select(ctxA, srvA, Selector{Field: "marker"})
	assert.NilError(t, err)
	assert.Equal(t, 1, cacheTestUnwrapInt(t, markerAAny))

	objBAny, err := srvB.Root().Select(ctxB, srvB, Selector{Field: "obj"})
	assert.NilError(t, err)
	objB := objBAny.(ObjectResult[*cacheTestObject])
	assert.Assert(t, objB.HitCache())
	markerBAny, err := objB.Select(ctxB, srvB, Selector{Field: "marker"})
	assert.NilError(t, err)
	assert.Equal(t, 2, cacheTestUnwrapInt(t, markerBAny))

	cacheTestReleaseSession(t, cacheIface, ctxA)
}

func TestClassNewRewrapsObjectResult(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	srvA := cacheTestObjectResolverServer(t, 1)
	srvB := cacheTestObjectResolverServer(t, 2)
	ctxA := srvToContext(ctx, srvA)
	ctxB := srvToContext(ctx, srvB)

	original, err := srvA.Root().Select(ctxA, srvA, Selector{Field: "obj"})
	assert.NilError(t, err)
	shared := original.cacheSharedResult()
	originalFrame := shared.loadResultCall()
	originalRecipe := cacheTestMustRecipeID(t, ctxA, original).Digest()
	originalClass, ok := shared.objClass.load(original.Type().Name())
	assert.Assert(t, ok)
	originalField, ok := originalClass.(Class[*cacheTestObject]).Field("marker", "")
	assert.Assert(t, ok)
	class, ok := srvB.ObjectType(original.Type().Name())
	assert.Assert(t, ok)
	rewrapped, err := class.New(original)
	assert.NilError(t, err)
	assert.Assert(t, rewrapped.cacheSharedResult() == shared)
	assert.Assert(t, shared.loadResultCall() == originalFrame)
	assert.Equal(t, originalRecipe, cacheTestMustRecipeID(t, ctxB, rewrapped).Digest())
	assert.Equal(t, original.HitCache(), rewrapped.HitCache())
	sharedClass, ok := shared.objClass.load(original.Type().Name())
	assert.Assert(t, ok)
	sharedField, ok := sharedClass.(Class[*cacheTestObject]).Field("marker", "")
	assert.Assert(t, ok)
	assert.Assert(t, sharedField.Spec == originalField.Spec)
	marker, err := rewrapped.Select(ctxB, srvB, Selector{Field: "marker"})
	assert.NilError(t, err)
	assert.Equal(t, 2, cacheTestUnwrapInt(t, marker))

	// Rewrapping changes only this object's class, not its attached value or
	// the original wrapper's dispatch behavior.
	originalID, err := original.ID()
	assert.NilError(t, err)
	rewrappedID, err := rewrapped.ID()
	assert.NilError(t, err)
	assert.Equal(t, originalID.EngineResultID(), rewrappedID.EngineResultID())
	marker, err = original.(AnyObjectResult).Select(ctxA, srvA, Selector{Field: "marker"})
	assert.NilError(t, err)
	assert.Equal(t, 1, cacheTestUnwrapInt(t, marker))

	// A subsequent cache read still chooses its own server's class. With no
	// matching class in the reader, reconstruction uses the original class.
	for _, tc := range []struct {
		srv  *Server
		want int
	}{{srvA, 1}, {srvB, 2}, {newDagqlServerForTest(t, cacheTestQuery{}), 1}} {
		loaded, err := tc.srv.Load(ctx, originalID)
		assert.NilError(t, err)
		assert.Assert(t, loaded.cacheSharedResult() == shared)
		marker, err := loaded.Select(ctx, tc.srv, Selector{Field: "marker"})
		assert.NilError(t, err)
		assert.Equal(t, tc.want, cacheTestUnwrapInt(t, marker))
	}
	cacheTestReleaseSession(t, cacheIface, ctxA)
}

// TestClassNewRewrapPreservesModuleCacheIsolation checks that rebinding keeps
// receiver identity and ownership intact. The selected field's module provenance
// must distinguish implementations while repeated calls still hit the cache.
func TestClassNewRewrapPreservesModuleCacheIsolation(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cache, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cache)
	srvA := cacheTestObjectResolverServer(t, 1)
	srvB := cacheTestObjectResolverServer(t, 2)
	ctx = srvToContext(ctx, srvA)
	var releases atomic.Int32
	Fields[cacheTestQuery]{
		NodeFunc("trackedObj", func(ctx context.Context, _ ObjectResult[cacheTestQuery], _ struct{}) (Result[*cacheTestObject], error) {
			return NewResultForCurrentCall(ctx, &cacheTestObject{onRelease: func(context.Context) error {
				releases.Add(1)
				return nil
			}})
		}),
	}.Install(srvA)
	var calls [2]int
	for i, srv := range []*Server{srvA, srvB} {
		moduleCall := cacheTestIntCall(fmt.Sprintf("module-%d", i))
		module, err := cache.GetOrInitCall(ctx, "test-session", srv, &CallRequest{ResultCall: moduleCall}, func(ctx context.Context) (AnyResult, error) {
			return NewResultForCurrentCall(ctx, NewInt(i))
		})
		assert.NilError(t, err)
		moduleRef, err := resultCallRefFromResult(ctx, module)
		assert.NilError(t, err)
		field := Func("cachedMarker", func(context.Context, *cacheTestObject, struct{}) (Int, error) {
			calls[i]++
			return NewInt(i + 1), nil
		})
		// Keep display metadata identical: the implementation result itself is
		// the discriminating input, just as for reloaded user modules.
		field.Spec.Module = &ResultCallModule{ResultRef: moduleRef, Name: "tools"}
		Fields[*cacheTestObject]{field}.Install(srv)
	}
	original, err := srvA.Root().Select(ctx, srvA, Selector{Field: "trackedObj"})
	assert.NilError(t, err)
	class, ok := srvB.ObjectType(original.Type().Name())
	assert.Assert(t, ok)
	rewrapped, err := class.New(original)
	assert.NilError(t, err)
	assert.Assert(t, original.cacheSharedResult() == rewrapped.cacheSharedResult())
	var resultIDs [2]uint64
	for round := range 2 {
		for i, obj := range []AnyObjectResult{original.(AnyObjectResult), rewrapped} {
			// Deliberately dispatch both through A: the wrapper's selected
			// field must supply B's provenance even in an older caller schema.
			res, err := obj.Select(ctx, srvA, Selector{Field: "cachedMarker"})
			assert.NilError(t, err)
			assert.Equal(t, i+1, cacheTestUnwrapInt(t, res))
			assert.Equal(t, round > 0, res.HitCache())
			id, err := res.ID()
			assert.NilError(t, err)
			if round == 0 {
				resultIDs[i] = id.EngineResultID()
			} else {
				assert.Equal(t, resultIDs[i], id.EngineResultID())
			}
		}
	}
	assert.Assert(t, resultIDs[0] != resultIDs[1])
	assert.Equal(t, 1, calls[0])
	assert.Equal(t, 1, calls[1])

	// Attaching the rebound wrapper to another session must claim the same
	// resource, keep it alive after the first session exits, and release once.
	attached, err := cache.AttachResult(ctx, "rewrap-session", srvB, rewrapped)
	assert.NilError(t, err)
	assert.Assert(t, attached.cacheSharedResult() == original.cacheSharedResult())
	cacheTestReleaseSession(t, cache, ctx)
	assert.Equal(t, int32(0), releases.Load())
	otherCtx := engine.ContextWithClientMetadata(ctx, &engine.ClientMetadata{
		ClientID: "rewrap-client", SessionID: "rewrap-session",
	})
	id, err := attached.ID()
	assert.NilError(t, err)
	loaded, err := srvB.Load(otherCtx, id)
	assert.NilError(t, err)
	assert.Assert(t, loaded.cacheSharedResult() == original.cacheSharedResult())
	cacheTestReleaseSession(t, cache, otherCtx)
	assert.Equal(t, int32(1), releases.Load())
}

func TestInputSpecsInputsFromResultCallArgs(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())

	specs := NewInputSpecs(
		InputSpec{Name: "msg", Type: String("")},
		InputSpec{Name: "count", Type: Int(0), Default: NewInt(7)},
	)
	args := []*ResultCallArg{
		{
			Name:  "msg",
			Value: &ResultCallLiteral{Kind: ResultCallLiteralKindString, StringValue: "hello"},
		},
	}

	inputs, err := specs.InputsFromResultCallArgs(ctx, args, "")
	assert.NilError(t, err)

	msg := inputs["msg"].(String)
	count := inputs["count"].(Int)
	assert.Equal(t, "hello", msg.String())
	assert.Equal(t, 7, count.Int())
}

func TestResultContentPreferredDigestUsesContentDigest(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	srv := cacheTestServer(t)

	contentDig := digest.FromString("service-content")
	objType := (&cacheTestObject{}).Type()
	frame := &ResultCall{
		Kind:         ResultCallKindField,
		Field:        "service",
		Type:         NewResultCallType(objType),
		ExtraDigests: []call.ExtraDigest{{Label: call.ExtraDigestLabelContent, Digest: contentDig}},
	}
	res := cacheTestObjectResult(t, srv, frame, 33, nil)
	attachedAny, err := cacheIface.AttachResult(ctx, "test-session", srv, res)
	assert.NilError(t, err)
	attached := attachedAny.(ObjectResult[*cacheTestObject])

	got, err := attached.ContentPreferredDigest(ctx)
	assert.NilError(t, err)
	assert.Equal(t, contentDig.String(), got.String())

	recipeID, err := attached.RecipeID(ctx)
	assert.NilError(t, err)
	assert.Equal(t, contentDig.String(), recipeID.ContentDigest().String())
}

func TestLookupCacheForIDExtraDigestFallback(t *testing.T) {
	t.Parallel()

	t.Run("hit_on_exact_output_digest_match", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		ctx = ContextWithCache(ctx, cacheIface)
		c := cacheIface

		shared := call.ExtraDigest{
			Digest: digest.FromString("fallback-extra-shared"),
			Label:  "shared",
		}

		sourceKey := call.New().Append(Int(0).Type(), "_contextDirectory")
		sourceCall := cacheTestIntCall("_contextDirectory")
		sourceRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: sourceCall}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(&ResultCall{
				Kind:         ResultCallKindField,
				Type:         NewResultCallType(Int(0).Type()),
				Field:        "_contextDirectory",
				ExtraDigests: []call.ExtraDigest{shared},
			}, 71), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !sourceRes.HitCache())

		requestKey := sourceKey.With(
			call.WithArgs(call.NewArgument("variant", call.NewLiteralInt(1), false)),
			call.WithExtraDigest(shared),
		)
		requestCall := &ResultCall{
			Kind:         ResultCallKindField,
			Type:         NewResultCallType(Int(0).Type()),
			Field:        "_contextDirectory",
			ExtraDigests: []call.ExtraDigest{shared},
			Args: []*ResultCallArg{{
				Name:  "variant",
				Value: &ResultCallLiteral{Kind: ResultCallLiteralKindInt, IntValue: 1},
			}},
		}
		assert.Assert(t, sourceKey.Digest() != requestKey.Digest())

		requestInitCalls := 0
		requestRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
			requestInitCalls++
			return cacheTestIntResult(requestCall, 999), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 0, requestInitCalls)
		assert.Assert(t, requestRes.HitCache())
		assert.Equal(t, 71, cacheTestUnwrapInt(t, requestRes))
		assert.Equal(t, cacheTestMustEncodeID(t, sourceRes), cacheTestMustEncodeID(t, requestRes))
		foundShared := false
		for _, extra := range cacheTestMustRecipeID(t, ctx, requestRes).ExtraDigests() {
			if extra.Digest == shared.Digest && extra.Label == shared.Label {
				foundShared = true
				break
			}
		}
		assert.Assert(t, foundShared)

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})

	t.Run("miss_without_exact_output_digest_match", func(t *testing.T) {
		ctx := cacheTestContext(t.Context())
		cacheIface, err := NewCache(ctx, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface

		sourceExtra := call.ExtraDigest{
			Digest: digest.FromString("fallback-extra-source"),
			Label:  "source",
		}
		requestExtra := call.ExtraDigest{
			Digest: digest.FromString("fallback-extra-request"),
			Label:  "request",
		}

		sourceCall := cacheTestIntCall("fallback-miss-source")
		sourceRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: sourceCall}, func(context.Context) (AnyResult, error) {
			return cacheTestIntResult(cacheTestIntCall("fallback-miss-source", sourceExtra), 81), nil
		})
		assert.NilError(t, err)
		assert.Assert(t, !sourceRes.HitCache())

		requestCall := cacheTestIntCall("fallback-miss-request", requestExtra)
		requestInitCalls := 0
		requestRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
			requestInitCalls++
			return cacheTestIntResult(requestCall, 82), nil
		})
		assert.NilError(t, err)
		assert.Equal(t, 1, requestInitCalls)
		assert.Assert(t, !requestRes.HitCache())
		assert.Equal(t, 82, cacheTestUnwrapInt(t, requestRes))

		cacheTestReleaseSession(t, c, ctx)
		assert.Equal(t, 0, c.Size())
	})
}

func TestHitTeachesReturnedRequestIDToCache(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	shared := call.ExtraDigest{
		Digest: digest.FromString("teach-hit-request-id-shared"),
		Label:  "eq-shared",
	}

	parentACall := cacheTestIntCall("teach-hit-parent-a")
	parentBCall := cacheTestIntCall("teach-hit-parent-b")
	parentAOutCall := cacheTestIntCall("teach-hit-parent-a", shared)
	parentBOutCall := cacheTestIntCall("teach-hit-parent-b", shared)

	parentARes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: parentACall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(parentAOutCall, 1), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !parentARes.HitCache())

	parentBRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: parentBCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(parentBOutCall, 2), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !parentBRes.HitCache())

	childARes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
		Kind:     ResultCallKindField,
		Type:     NewResultCallType(Int(0).Type()),
		Field:    "teach-hit-child",
		Receiver: &ResultCallRef{ResultID: uint64(parentARes.cacheSharedResult().id)},
	}}, func(context.Context) (AnyResult, error) {
		return cacheTestPlainResult(NewInt(1001)), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !childARes.HitCache())

	childBReq := &CallRequest{ResultCall: &ResultCall{
		Kind:     ResultCallKindField,
		Type:     NewResultCallType(Int(0).Type()),
		Field:    "teach-hit-child",
		Receiver: &ResultCallRef{ResultID: uint64(parentBRes.cacheSharedResult().id)},
	}}
	childBInitCalls := 0
	childBRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, childBReq, func(context.Context) (AnyResult, error) {
		childBInitCalls++
		return cacheTestPlainResult(NewInt(1002)), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, childBInitCalls)
	assert.Assert(t, childBRes.HitCache())
	assert.Equal(t, cacheTestMustEncodeID(t, childARes), cacheTestMustEncodeID(t, childBRes))

	childBDigest, err := childBReq.deriveRecipeDigest(c)
	assert.NilError(t, err)
	resolvedChildB, hit, err := c.lookupCacheForDigests(ctx, "test-session", noopTypeResolver{}, childBDigest, childBReq.ExtraDigests)
	assert.NilError(t, err)
	assert.Assert(t, hit)
	assert.Equal(t, childBRes.cacheSharedResult().id, resolvedChildB.cacheSharedResult().id)

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestExtraDigestLabelIsolation(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	sharedBytes := digest.FromString("label-isolation-shared-bytes")
	sharedA := call.ExtraDigest{Digest: sharedBytes, Label: "label-a"}
	sharedB := call.ExtraDigest{Digest: sharedBytes, Label: "label-b"}
	noiseA := call.ExtraDigest{Digest: digest.FromString("label-isolation-noise-a"), Label: "noise-a"}
	noiseB := call.ExtraDigest{Digest: digest.FromString("label-isolation-noise-b"), Label: "noise-b"}
	contentA := digest.FromString("label-isolation-content-a")
	contentB := digest.FromString("label-isolation-content-b")

	f1Key := call.New().Append(Int(0).Type(), "label-isolation-f-1")
	f2Key := call.New().Append(Int(0).Type(), "label-isolation-f-2")
	f1Call := cacheTestIntCall("label-isolation-f-1")
	f2Call := cacheTestIntCall("label-isolation-f-2")
	assert.Assert(t, f1Key.Digest() != f2Key.Digest())

	// Labels differ for the shared digest bytes, while content digests are also
	// present and intentionally different. This verifies label-only differences
	// are informational and do not block equivalence/hits.
	f1Out := f1Key.
		With(call.WithContentDigest(contentA)).
		With(call.WithExtraDigest(sharedA)).
		With(call.WithExtraDigest(noiseA))
	f2Out := f2Key.
		With(call.WithContentDigest(contentB)).
		With(call.WithExtraDigest(sharedB)).
		With(call.WithExtraDigest(noiseB))
	assert.Assert(t, contentA != contentB)
	assert.Equal(t, contentA.String(), f1Out.ContentDigest().String())
	assert.Equal(t, contentB.String(), f2Out.ContentDigest().String())
	f1HasLabelA := false
	f1HasLabelB := false
	for _, extra := range f1Out.ExtraDigests() {
		if extra.Digest != sharedBytes {
			continue
		}
		if extra.Label == sharedA.Label {
			f1HasLabelA = true
		}
		if extra.Label == sharedB.Label {
			f1HasLabelB = true
		}
	}
	f2HasLabelA := false
	f2HasLabelB := false
	for _, extra := range f2Out.ExtraDigests() {
		if extra.Digest != sharedBytes {
			continue
		}
		if extra.Label == sharedA.Label {
			f2HasLabelA = true
		}
		if extra.Label == sharedB.Label {
			f2HasLabelB = true
		}
	}
	assert.Assert(t, f1HasLabelA)
	assert.Assert(t, f2HasLabelB)
	assert.Assert(t, !f1HasLabelB)
	assert.Assert(t, !f2HasLabelA)

	f1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f1Call}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(&ResultCall{
			Kind:         ResultCallKindField,
			Type:         NewResultCallType(Int(0).Type()),
			Field:        "label-isolation-f-1",
			ExtraDigests: []call.ExtraDigest{sharedA, noiseA},
		}, 501).(Result[Int]).WithContentDigest(ctx, contentA)
	})
	assert.NilError(t, err)
	assert.Assert(t, !f1Res.HitCache())

	f2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: f2Call}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(&ResultCall{
			Kind:         ResultCallKindField,
			Type:         NewResultCallType(Int(0).Type()),
			Field:        "label-isolation-f-2",
			ExtraDigests: []call.ExtraDigest{sharedB, noiseB},
		}, 502).(Result[Int]).WithContentDigest(ctx, contentB)
	})
	assert.NilError(t, err)
	assert.Assert(t, !f2Res.HitCache())

	g1Key := f1Key.Append(Int(0).Type(), "label-isolation-g")
	g2Key := f2Key.Append(Int(0).Type(), "label-isolation-g")
	assert.Assert(t, g1Key.Digest() != g2Key.Digest())

	g1Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
		Kind:     ResultCallKindField,
		Type:     NewResultCallType(Int(0).Type()),
		Field:    "label-isolation-g",
		Receiver: &ResultCallRef{ResultID: uint64(f1Res.cacheSharedResult().id)},
	}}, func(context.Context) (AnyResult, error) {
		return cacheTestPlainResult(NewInt(601)), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !g1Res.HitCache())

	g2InitCalls := 0
	g2Res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
		Kind:     ResultCallKindField,
		Type:     NewResultCallType(Int(0).Type()),
		Field:    "label-isolation-g",
		Receiver: &ResultCallRef{ResultID: uint64(f2Res.cacheSharedResult().id)},
	}}, func(context.Context) (AnyResult, error) {
		g2InitCalls++
		return cacheTestPlainResult(NewInt(602)), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, g2InitCalls)
	assert.Assert(t, g2Res.HitCache())
	assert.Equal(t, 601, cacheTestUnwrapInt(t, g2Res))
	assert.Equal(t, cacheTestMustEncodeID(t, g1Res), cacheTestMustEncodeID(t, g2Res))

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
	assert.Equal(t, 0, len(c.egraphTerms))
	assert.Equal(t, 0, len(c.egraphDigestToClass))
}

func TestCacheHitReturnIDGetsContentDigestFromEqClassMetadata(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	contentDigest := digest.FromString("hit-return-id-content-digest")
	requestCall := cacheTestIntCall("hit-return-id-request")
	outputCall := cacheTestIntCall("hit-return-id-output")

	res1, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(outputCall, 77).(Result[Int]).WithContentDigest(ctx, contentDigest)
	})
	assert.NilError(t, err)
	assert.Equal(t, contentDigest.String(), cacheTestMustRecipeID(t, ctx, res1).ContentDigest().String())

	shared := res1.cacheSharedResult()
	assert.Assert(t, shared != nil)
	initCalls := 0
	res2, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
		initCalls++
		return cacheTestIntResult(requestCall, 88), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, initCalls)
	assert.Assert(t, res2.HitCache())
	assert.Equal(t, contentDigest.String(), cacheTestMustRecipeID(t, ctx, res2).ContentDigest().String())

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestCacheFreshReturnIDGetsContentDigestFromEqClassMetadata(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	contentDigest := digest.FromString("fresh-return-id-content-digest")
	sourceCall := cacheTestIntCall("fresh-return-id-source")
	sourceOutCall := cacheTestIntCall("fresh-return-id-output")

	sourceRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: sourceCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(sourceOutCall, 91).(Result[Int]).WithContentDigest(ctx, contentDigest)
	})
	assert.NilError(t, err)
	shared := sourceRes.cacheSharedResult()
	assert.Assert(t, shared != nil)

	requestCall := cacheTestIntCall("fresh-return-id-request")
	wrappedRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
		return Result[Typed]{
			shared: shared,
		}, nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !wrappedRes.HitCache())
	assert.Equal(t, contentDigest.String(), cacheTestMustRecipeID(t, ctx, wrappedRes).ContentDigest().String())

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestCacheTeachContentDigestPreservesAttachment(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	reqCall := cacheTestIntCall("teach-content-digest")
	res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: reqCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(reqCall, 123), nil
	})
	assert.NilError(t, err)

	beforeID := cacheTestMustID(t, res)
	contentDigest := digest.FromString("teach-content-digest")
	assert.NilError(t, c.TeachContentDigest(ctx, res, contentDigest))

	afterID := cacheTestMustID(t, res)
	assert.Equal(t, beforeID.EngineResultID(), afterID.EngineResultID())
	assert.Equal(t, contentDigest.String(), cacheTestMustRecipeID(t, ctx, res).ContentDigest().String())

	shared := res.cacheSharedResult()
	assert.Assert(t, shared != nil)
	c.egraphMu.RLock()
	ok := c.egraphResultsByDigest[contentDigest.String()].Contains(shared.id)
	c.egraphMu.RUnlock()
	assert.Assert(t, ok)

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestCacheTeachContentDigestWithResultRefs(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, cacheIface)
	c := cacheIface

	depCall := cacheTestIntCall("teach-content-digest-dep")
	depRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: depCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(depCall, 11), nil
	})
	assert.NilError(t, err)

	rootCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(Int(0).Type()),
		Field: "teach-content-digest-root",
		Args: []*ResultCallArg{
			{
				Name: "dep",
				Value: &ResultCallLiteral{
					Kind: ResultCallLiteralKindResultRef,
					ResultRef: &ResultCallRef{
						ResultID: uint64(depRes.cacheSharedResult().id),
					},
				},
			},
		},
	}
	rootRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: rootCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(rootCall, 22), nil
	})
	assert.NilError(t, err)

	contentDigest := digest.FromString("teach-content-digest-with-result-refs")
	assert.NilError(t, c.TeachContentDigest(ctx, rootRes, contentDigest))
	assert.Equal(t, contentDigest.String(), cacheTestMustRecipeID(t, ctx, rootRes).ContentDigest().String())

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestDerefValueForNullables(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		value    Typed
		expected int
	}{
		{
			name: "dynamic-nullable",
			value: DynamicNullable{
				Elem:  NewInt(0),
				Value: NewInt(21),
				Valid: true,
			},
			expected: 21,
		},
		{
			name: "nullable-generic",
			value: Nullable[Int]{
				Value: NewInt(42),
				Valid: true,
			},
			expected: 42,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			call := &ResultCall{
				Kind:  ResultCallKindField,
				Type:  NewResultCallType(tc.value.Type()),
				Field: tc.name,
			}
			outer := cacheTestDetachedResult(call, tc.value)

			deref, ok := outer.DerefValue()
			assert.Assert(t, ok)
			assert.Equal(t, tc.expected, cacheTestUnwrapInt(t, deref))
		})
	}
}

func TestCacheDoNotCacheNormalizesNestedHitMetadata(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	innerCall := cacheTestIntCall("inner")
	innerRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: innerCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(innerCall, 9), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !innerRes.HitCache())

	outerCall := cacheTestIntCall("outer")
	outerRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall: outerCall,
		DoNotCache: true,
	}, func(ctx context.Context) (AnyResult, error) {
		nested, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: innerCall}, func(context.Context) (AnyResult, error) {
			return nil, fmt.Errorf("unexpected nested initializer call")
		})
		if err != nil {
			return nil, err
		}
		assert.Assert(t, nested.HitCache())
		return nested, nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !outerRes.HitCache())
	assert.Equal(t, 9, cacheTestUnwrapInt(t, outerRes))
	assert.Equal(t, 1, c.Size())
}

func TestCacheDoNotCachePreservesConcreteObjectType(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	c, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	ctx = ContextWithCache(ctx, c)
	srv := cacheTestServer(t)
	Fields[cacheTestQuery]{
		Func("value", func(context.Context, cacheTestQuery, struct{}) (Int, error) {
			return NewInt(17), nil
		}),
	}.Install(srv)
	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(&ast.Type{NamedType: "Node", NonNull: true}),
		Field: "uncached-node",
	}
	res, err := c.GetOrInitCall(ctx, "test-session", srv, &CallRequest{
		ResultCall: frame,
		DoNotCache: true,
	}, func(ctx context.Context) (AnyResult, error) {
		return NewObjectResultForCurrentCall(ctx, srv, cacheTestQuery{})
	})
	assert.NilError(t, err)
	assert.Equal(t, "Node", frame.Type.NamedType)
	resultCall, err := res.ResultCall()
	assert.NilError(t, err)
	assert.Equal(t, "Query", resultCall.Type.NamedType)
	obj, ok := res.(ObjectResult[cacheTestQuery])
	assert.Assert(t, ok)
	value, err := obj.Select(ctx, srv, Selector{Field: "value"})
	assert.NilError(t, err)
	assert.Equal(t, 17, cacheTestUnwrapInt(t, value))
}

func TestCacheDoNotCachePreservesAttachedReturnedObject(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)

	objectCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "attached-object",
	}
	innerAny, err := c.GetOrInitCall(ctx, "test-session", srv, &CallRequest{ResultCall: objectCall}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, objectCall, 17, nil), nil
	})
	assert.NilError(t, err)
	innerRes, ok := innerAny.(ObjectResult[*cacheTestObject])
	assert.Assert(t, ok)
	innerID, err := innerRes.ID()
	assert.NilError(t, err)

	outerCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "donotcache-object",
	}
	outerAny, err := c.GetOrInitCall(ctx, "test-session", srv, &CallRequest{
		ResultCall: outerCall,
		DoNotCache: true,
	}, func(context.Context) (AnyResult, error) {
		return innerRes, nil
	})
	assert.NilError(t, err)

	outerRes, ok := outerAny.(ObjectResult[*cacheTestObject])
	assert.Assert(t, ok)
	assert.Assert(t, !outerRes.HitCache())

	outerID, err := outerRes.ID()
	assert.NilError(t, err)
	assert.Equal(t, innerID.EngineResultID(), outerID.EngineResultID())
	assert.Equal(t, 1, c.Size())
}

func TestCacheSecondaryIndexesCleanedOnRelease(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	storageID := call.New().Append(Int(0).Type(), "storage-key")
	storageCall := cacheTestIntCall("storage-key")
	resultDigest := digest.FromString("result-digest")
	resultContent := digest.FromString("result-content")

	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: storageCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(&ResultCall{
			Kind:         ResultCallKindField,
			Type:         NewResultCallType(Int(0).Type()),
			Field:        "storage-key",
			ExtraDigests: []call.ExtraDigest{{Digest: resultDigest}},
		}, 44).(Result[Int]).WithContentDigest(ctx, resultContent)
	})
	assert.NilError(t, err)

	storageKey := storageID.Digest().String()
	resultOutputEq := resultContent.String()
	assert.Assert(t, storageKey != resultOutputEq)
	assert.Equal(t, 1, len(c.resultOutputEqClasses))
	assert.Assert(t, len(c.egraphTerms) > 0)
	assert.Assert(t, c.Size() > 0)

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, len(c.ongoingCalls))
	assert.Equal(t, 0, len(c.resultOutputEqClasses))
	assert.Equal(t, 0, len(c.egraphTerms))
	assert.Equal(t, 0, len(c.resultOutputEqClasses))
}

func TestCacheReleaseRemovesRecordedDigestPostingAfterOutputClassMerge(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	ctxA := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "release-eq-class-a",
		SessionID: "release-eq-class-a",
	})
	ctxB := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "release-eq-class-b",
		SessionID: "release-eq-class-b",
	})
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	requestCall := cacheTestIntCall("release-eq-class-request")
	outputCall := cacheTestIntCall("release-eq-class-output")
	keeperCall := cacheTestIntCall("release-eq-class-keeper")
	foreignDigest := digest.FromString("release-eq-class-foreign")

	res, err := c.GetOrInitCall(ctxA, "release-eq-class-a", noopTypeResolver{}, &CallRequest{ResultCall: requestCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(outputCall, 44), nil
	})
	assert.NilError(t, err)
	_, err = c.GetOrInitCall(ctxB, "release-eq-class-b", noopTypeResolver{}, &CallRequest{ResultCall: keeperCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(keeperCall, 55), nil
	})
	assert.NilError(t, err)

	shared := res.cacheSharedResult()
	assert.Assert(t, shared != nil)

	c.egraphMu.Lock()
	outputEqClasses := c.outputEqClassesForResultLocked(shared.id)
	outputClassCount := len(outputEqClasses)

	var outputEqID eqClassID
	for eqID := range outputEqClasses {
		outputEqID = eqID
		break
	}
	initialOutputEqID := outputEqID

	foreignEqID := c.ensureEqClassForDigestLocked(ctxA, foreignDigest.String())
	outputEqID = c.mergeEqClassesLocked(ctxA, outputEqID, foreignEqID)
	digestsPresent := c.eqClassToDigests[outputEqID] != nil
	_, ok := c.eqClassToDigests[outputEqID][foreignDigest.String()]

	// Removal covers production-recorded exact postings and broad imported
	// postings, not arbitrary white-box mutations that bypass bookkeeping.
	c.addResultDigestPostingLocked(shared.id, foreignDigest.String(), resultDigestPostingExact)
	c.egraphMu.Unlock()
	assert.Assert(t, outputClassCount > 0)
	assert.Assert(t, initialOutputEqID != 0)
	assert.Assert(t, outputEqID != 0)
	assert.Assert(t, digestsPresent)
	assert.Assert(t, ok)

	assert.NilError(t, c.ReleaseSession(ctxA, "release-eq-class-a"))

	c.egraphMu.RLock()
	_, ok = c.egraphResultsByDigest[foreignDigest.String()]
	c.egraphMu.RUnlock()
	assert.Assert(t, !ok)
	assert.Equal(t, 1, c.Size())

	assert.NilError(t, c.ReleaseSession(ctxB, "release-eq-class-b"))
	assert.Equal(t, 0, c.Size())
}

func TestCacheArrayResultRoundTrip(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	keyCall := cacheTestIntCall("array-result")
	res1, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
		return cacheTestDetachedResult(&ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType(NewIntArray[int]().Type()),
			Field: "array-result",
		}, NewIntArray(1, 2, 3)), nil
	})
	assert.NilError(t, err)
	enum1, ok := res1.Unwrap().(Enumerable)
	assert.Assert(t, ok)
	assert.Equal(t, 3, enum1.Len())
	nth2, err := enum1.Nth(2)
	assert.NilError(t, err)
	v2, ok := nth2.(Int)
	assert.Assert(t, ok)
	assert.Equal(t, 2, int(v2))

	res2, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
		return nil, fmt.Errorf("unexpected initializer call")
	})
	assert.NilError(t, err)
	assert.Assert(t, res2.HitCache())
	enum2, ok := res2.Unwrap().(Enumerable)
	assert.Assert(t, ok)
	assert.Equal(t, 3, enum2.Len())

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.Size())
}

func TestCacheArrayResultsRetainChildResultsAcrossProducerSessionRelease(t *testing.T) {
	t.Parallel()

	run := func(t *testing.T, field string, arrayType Typed, initParent func(*ResultCall, ObjectResult[*cacheTestObject], ObjectResult[*cacheTestObject]) AnyResult) {
		t.Helper()

		baseCtx := t.Context()
		ctxA := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
			ClientID:  field + "-owner-client",
			SessionID: field + "-owner-session",
		})
		ctxB := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
			ClientID:  field + "-consumer-client",
			SessionID: field + "-consumer-session",
		})

		cacheIface, err := NewCache(ctxA, "", nil, nil)
		assert.NilError(t, err)
		c := cacheIface
		ctxA = ContextWithCache(ctxA, c)
		ctxB = ContextWithCache(ctxB, c)
		srv := cacheTestServer(t)

		child1Call := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: field + "-child-1",
		}
		child2Call := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType((&cacheTestObject{}).Type()),
			Field: field + "-child-2",
		}
		arrayCall := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType(arrayType.Type()),
			Field: field,
		}

		child1Any, err := c.GetOrInitCall(ctxA, field+"-owner-session", srv, &CallRequest{ResultCall: child1Call}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResult(t, srv, child1Call, 1, nil), nil
		})
		assert.NilError(t, err)
		child1 := child1Any.(ObjectResult[*cacheTestObject])
		child1Shared := child1.cacheSharedResult()
		assert.Assert(t, child1Shared != nil)
		assert.Assert(t, child1Shared.id != 0)

		child2Any, err := c.GetOrInitCall(ctxA, field+"-owner-session", srv, &CallRequest{ResultCall: child2Call}, func(context.Context) (AnyResult, error) {
			return cacheTestObjectResult(t, srv, child2Call, 2, nil), nil
		})
		assert.NilError(t, err)
		child2 := child2Any.(ObjectResult[*cacheTestObject])

		parentAny, err := c.GetOrInitCall(ctxA, field+"-owner-session", srv, &CallRequest{ResultCall: arrayCall}, func(context.Context) (AnyResult, error) {
			return initParent(arrayCall, child1, child2), nil
		})
		assert.NilError(t, err)
		parentShared := parentAny.cacheSharedResult()
		assert.Assert(t, parentShared != nil)
		assert.Assert(t, parentShared.id != 0)

		hitAny, err := c.GetOrInitCall(ctxB, field+"-consumer-session", srv, &CallRequest{ResultCall: arrayCall}, func(context.Context) (AnyResult, error) {
			return nil, fmt.Errorf("unexpected initializer call")
		})
		assert.NilError(t, err)
		assert.Assert(t, hitAny.HitCache())

		enum, ok := hitAny.Unwrap().(Enumerable)
		assert.Assert(t, ok)
		firstAny, err := enum.NthValue(1, nil)
		assert.NilError(t, err)
		firstChild := firstAny.(ObjectResult[*cacheTestObject])
		_, err = firstChild.ResultCall()
		assert.NilError(t, err)

		assert.NilError(t, c.ReleaseSession(ctxA, field+"-owner-session"))

		c.egraphMu.RLock()
		parentStillLive := c.resultsByID[parentShared.id] != nil
		childStillLive := c.resultsByID[child1Shared.id] != nil
		c.egraphMu.RUnlock()
		assert.Assert(t, parentStillLive)
		assert.Assert(t, childStillLive)

		childCall, err := firstChild.ResultCall()
		assert.NilError(t, err)
		assert.Assert(t, childCall != nil)

		firstID, err := firstChild.ID()
		assert.NilError(t, err)
		reloadedAny, err := srv.Load(ctxB, firstID)
		assert.NilError(t, err)
		reloaded, ok := reloadedAny.(ObjectResult[*cacheTestObject])
		assert.Assert(t, ok)
		assert.Equal(t, 1, reloaded.Self().Value)

		assert.NilError(t, c.ReleaseSession(ctxB, field+"-consumer-session"))
		assert.Equal(t, 0, c.Size())
	}

	t.Run("ObjectResultArray", func(t *testing.T) {
		run(t, "object-array-result", ObjectResultArray[*cacheTestObject]{}, func(arrayCall *ResultCall, child1, child2 ObjectResult[*cacheTestObject]) AnyResult {
			return cacheTestDetachedResult(arrayCall, ObjectResultArray[*cacheTestObject]{child1, child2})
		})
	})

	t.Run("DynamicResultArrayOutput", func(t *testing.T) {
		run(t, "dynamic-result-array", DynamicResultArrayOutput{Elem: &cacheTestObject{}}, func(arrayCall *ResultCall, child1, child2 ObjectResult[*cacheTestObject]) AnyResult {
			return cacheTestDetachedResult(arrayCall, DynamicResultArrayOutput{
				Elem:   &cacheTestObject{},
				Values: []AnyResult{child1, child2},
			})
		})
	})
}

func TestCacheArrayResultStressDoesNotReturnHitWithoutCallFrame(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)

	seedCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "stress-array-seed-client",
		SessionID: "stress-array-seed-session",
	})
	seedCtx = ContextWithCache(seedCtx, c)
	seedCtx = srvToContext(seedCtx, srv)

	child1Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-array-child-1",
	}
	child2Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-array-child-2",
	}
	arrayCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(ObjectResultArray[*cacheTestObject]{}.Type()),
		Field: "stress-array-parent",
	}

	child1Any, err := c.GetOrInitCall(seedCtx, "stress-array-seed-session", srv, &CallRequest{ResultCall: child1Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child1Call, 1, nil), nil
	})
	assert.NilError(t, err)
	child1 := child1Any.(ObjectResult[*cacheTestObject])

	child2Any, err := c.GetOrInitCall(seedCtx, "stress-array-seed-session", srv, &CallRequest{ResultCall: child2Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child2Call, 2, nil), nil
	})
	assert.NilError(t, err)
	child2 := child2Any.(ObjectResult[*cacheTestObject])

	newSessionCtx := func(worker, iter int) context.Context {
		ctx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
			ClientID:  fmt.Sprintf("stress-array-client-%d-%d", worker, iter),
			SessionID: fmt.Sprintf("stress-array-session-%d-%d", worker, iter),
		})
		ctx = ContextWithCache(ctx, c)
		ctx = srvToContext(ctx, srv)
		return ctx
	}

	buildArray := func(ctx context.Context, sessionID string) (AnyResult, error) {
		return c.GetOrInitCall(ctx, sessionID, srv, &CallRequest{ResultCall: arrayCall}, func(context.Context) (AnyResult, error) {
			return cacheTestDetachedResult(arrayCall, ObjectResultArray[*cacheTestObject]{child1, child2}), nil
		})
	}

	const (
		workers           = 24
		attemptsPerWorker = 1000
	)
	isTargetFailure := func(err error) bool {
		if err == nil {
			return false
		}
		return strings.Contains(err.Error(), "without call frame") ||
			strings.Contains(err.Error(), "has no call frame")
	}

	const ownerSessionID = "stress-array-owner-session"
	errConsumerInit := errors.New("stress consumer should only hit cache")

	ownerCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "stress-array-owner-client",
		SessionID: ownerSessionID,
	})
	ownerCtx = ContextWithCache(ownerCtx, c)
	ownerCtx = srvToContext(ownerCtx, srv)

	_, err = buildArray(ownerCtx, ownerSessionID)
	assert.NilError(t, err)

	start := make(chan struct{})
	stopProducer := make(chan struct{})
	producerDone := make(chan struct{})
	producerErrCh := make(chan error, 1)
	var attempts atomic.Int64
	var hitCount atomic.Int64
	var failure atomic.Pointer[string]

	go func() {
		defer close(producerDone)
		<-start
		for iter := 0; ; iter++ {
			select {
			case <-stopProducer:
				return
			default:
			}

			producerSessionID := fmt.Sprintf("stress-array-producer-session-%d", iter)
			producerCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
				ClientID:  fmt.Sprintf("stress-array-producer-client-%d", iter),
				SessionID: producerSessionID,
			})
			producerCtx = ContextWithCache(producerCtx, c)
			producerCtx = srvToContext(producerCtx, srv)
			if _, err := buildArray(producerCtx, producerSessionID); err != nil {
				producerErrCh <- err
				return
			}
			time.Sleep(50 * time.Microsecond)
			if err := c.ReleaseSession(producerCtx, producerSessionID); err != nil {
				producerErrCh <- err
				return
			}
		}
	}()

	eg, egCtx := errgroup.WithContext(baseCtx)
	for worker := 0; worker < workers; worker++ {
		worker := worker
		eg.Go(func() error {
			<-start
			for iter := 0; iter < attemptsPerWorker; iter++ {
				if egCtx.Err() != nil {
					return egCtx.Err()
				}

				ctx := newSessionCtx(worker, iter)
				clientMD, err := engine.ClientMetadataFromContext(ctx)
				if err != nil {
					return err
				}

				res, err := c.GetOrInitCall(ctx, clientMD.SessionID, srv, &CallRequest{ResultCall: arrayCall}, func(context.Context) (AnyResult, error) {
					return nil, errConsumerInit
				})
				attempts.Add(1)
				if err != nil {
					if errors.Is(err, errConsumerInit) {
						continue
					}
					return err
				}
				if res.HitCache() {
					hitCount.Add(1)
				}

				if _, err := res.ResultCall(); err != nil {
					if isTargetFailure(err) {
						msg := fmt.Sprintf("result call failure on worker=%d iter=%d hit=%v: %v", worker, iter, res.HitCache(), err)
						failure.Store(&msg)
						return fmt.Errorf("%s", msg)
					}
					return err
				}

				nth, err := res.NthValue(ctx, 1)
				if err != nil {
					if isTargetFailure(err) {
						msg := fmt.Sprintf("nth failure on worker=%d iter=%d hit=%v: %v", worker, iter, res.HitCache(), err)
						failure.Store(&msg)
						return fmt.Errorf("%s", msg)
					}
					return err
				}
				if nth == nil {
					return fmt.Errorf("worker=%d iter=%d: nil nth result", worker, iter)
				}
				if _, err := nth.ResultCall(); err != nil {
					if isTargetFailure(err) {
						msg := fmt.Sprintf("nth result call failure on worker=%d iter=%d hit=%v: %v", worker, iter, res.HitCache(), err)
						failure.Store(&msg)
						return fmt.Errorf("%s", msg)
					}
					return err
				}

				if err := c.ReleaseSession(ctx, clientMD.SessionID); err != nil {
					return err
				}
			}
			return nil
		})
	}
	close(start)

	err = eg.Wait()
	close(stopProducer)
	<-producerDone
	select {
	case producerErr := <-producerErrCh:
		err = errors.Join(err, producerErr)
	default:
	}
	assert.NilError(t, c.ReleaseSession(ownerCtx, ownerSessionID))
	assert.NilError(t, c.ReleaseSession(seedCtx, "stress-array-seed-session"))
	if msg := failure.Load(); msg != nil {
		t.Fatalf("reproduced array hit call-frame race after %d attempts and %d hits: %s", attempts.Load(), hitCount.Load(), *msg)
	}
	assert.NilError(t, err)
	t.Logf("completed %d attempts and %d cache hits without reproducing the array hit call-frame race", attempts.Load(), hitCount.Load())
}

func TestCacheArrayResultStressDoesNotRaceExplicitDependencyAttachment(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)

	seedCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "stress-attach-seed-client",
		SessionID: "stress-attach-seed-session",
	})
	seedCtx = ContextWithCache(seedCtx, c)
	seedCtx = srvToContext(seedCtx, srv)

	child1Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-attach-child-1",
	}
	child2Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-attach-child-2",
	}
	arrayCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(ObjectResultArray[*cacheTestObject]{}.Type()),
		Field: "stress-attach-parent",
	}

	child1Any, err := c.GetOrInitCall(seedCtx, "stress-attach-seed-session", srv, &CallRequest{ResultCall: child1Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child1Call, 1, nil), nil
	})
	assert.NilError(t, err)
	child1 := child1Any.(ObjectResult[*cacheTestObject])

	child2Any, err := c.GetOrInitCall(seedCtx, "stress-attach-seed-session", srv, &CallRequest{ResultCall: child2Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child2Call, 2, nil), nil
	})
	assert.NilError(t, err)
	child2 := child2Any.(ObjectResult[*cacheTestObject])

	buildArray := func(ctx context.Context, sessionID string) (AnyResult, error) {
		return c.GetOrInitCall(ctx, sessionID, srv, &CallRequest{ResultCall: arrayCall}, func(context.Context) (AnyResult, error) {
			return cacheTestDetachedResult(arrayCall, ObjectResultArray[*cacheTestObject]{child1, child2}), nil
		})
	}

	const (
		workers             = 24
		attemptsPerWorker   = 400
		targetFailureSubstr = "add explicit dependency: parent result"
	)

	newSessionCtx := func(worker, iter int) context.Context {
		ctx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
			ClientID:  fmt.Sprintf("stress-attach-client-%d-%d", worker, iter),
			SessionID: fmt.Sprintf("stress-attach-session-%d-%d", worker, iter),
		})
		ctx = ContextWithCache(ctx, c)
		ctx = srvToContext(ctx, srv)
		return ctx
	}

	start := make(chan struct{})
	var attempts atomic.Int64
	var hitCount atomic.Int64
	var failure atomic.Pointer[string]

	eg, egCtx := errgroup.WithContext(baseCtx)
	for worker := 0; worker < workers; worker++ {
		worker := worker
		eg.Go(func() error {
			<-start
			for iter := 0; iter < attemptsPerWorker; iter++ {
				if egCtx.Err() != nil {
					return egCtx.Err()
				}

				ctx := newSessionCtx(worker, iter)
				clientMD, err := engine.ClientMetadataFromContext(ctx)
				if err != nil {
					return err
				}

				res, err := buildArray(ctx, clientMD.SessionID)
				attempts.Add(1)
				if err != nil {
					if strings.Contains(err.Error(), targetFailureSubstr) {
						msg := fmt.Sprintf("explicit dependency attachment failure on worker=%d iter=%d: %v", worker, iter, err)
						failure.Store(&msg)
						return fmt.Errorf("%s", msg)
					}
					return err
				}
				if res.HitCache() {
					hitCount.Add(1)
				}

				if err := c.ReleaseSession(ctx, clientMD.SessionID); err != nil {
					return err
				}
			}
			return nil
		})
	}
	close(start)

	err = eg.Wait()
	assert.NilError(t, c.ReleaseSession(seedCtx, "stress-attach-seed-session"))
	if msg := failure.Load(); msg != nil {
		t.Fatalf("reproduced explicit dependency attachment race after %d attempts and %d cache hits: %s", attempts.Load(), hitCount.Load(), *msg)
	}
	assert.NilError(t, err)
	t.Logf("completed %d attempts and %d cache hits without reproducing the explicit dependency attachment race", attempts.Load(), hitCount.Load())
}

func TestCacheMixedSessionWaitersCancelDoNotLeak(t *testing.T) {
	t.Parallel()
	synctest.Test(t, testCacheMixedSessionWaitersCancelDoNotLeak)
}

func testCacheMixedSessionWaitersCancelDoNotLeak(t *testing.T) {
	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)

	seedCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "stress-mixed-seed-client",
		SessionID: "stress-mixed-seed-session",
	})
	seedCtx = ContextWithCache(seedCtx, c)
	seedCtx = srvToContext(seedCtx, srv)

	child1Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-mixed-child-1",
	}
	child2Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-mixed-child-2",
	}

	child1Any, err := c.GetOrInitCall(seedCtx, "stress-mixed-seed-session", srv, &CallRequest{ResultCall: child1Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child1Call, 1, nil), nil
	})
	assert.NilError(t, err)
	child1 := child1Any.(ObjectResult[*cacheTestObject])

	child2Any, err := c.GetOrInitCall(seedCtx, "stress-mixed-seed-session", srv, &CallRequest{ResultCall: child2Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child2Call, 2, nil), nil
	})
	assert.NilError(t, err)
	child2 := child2Any.(ObjectResult[*cacheTestObject])

	child1Shared := child1.cacheSharedResult()
	child2Shared := child2.cacheSharedResult()
	assert.Assert(t, child1Shared != nil && child1Shared.id != 0)
	assert.Assert(t, child2Shared != nil && child2Shared.id != 0)

	const (
		attempts          = 100
		waitersPerAttempt = 18
		earlyCanceled     = 6
		racingCanceled    = 6
		concurrencyKey    = "stress-mixed-shared"
	)

	type waiterSpec struct {
		waitCtx    context.Context
		releaseCtx context.Context
		cancel     context.CancelFunc
		sessionID  string
	}

	type waiterOutcome struct {
		res AnyResult
		err error
	}

	for attempt := 0; attempt < attempts; attempt++ {
		parentCall := &ResultCall{
			Kind:  ResultCallKindField,
			Type:  NewResultCallType(ObjectResultArray[*cacheTestObject]{}.Type()),
			Field: fmt.Sprintf("stress-mixed-parent-%d", attempt),
		}
		callConcKeys := callConcurrencyKeys{
			callKey:        cacheTestCallDigest(parentCall).String(),
			concurrencyKey: concurrencyKey,
		}

		waiterSpecs := make([]waiterSpec, waitersPerAttempt)
		waiterOutcomes := make([]waiterOutcome, waitersPerAttempt)
		waiterDone := make([]chan struct{}, waitersPerAttempt)
		initStarted := make(chan struct{})
		unblockInit := make(chan struct{})
		var unblockInitOnce sync.Once
		releaseInit := func() { unblockInitOnce.Do(func() { close(unblockInit) }) }
		defer releaseInit()
		var initStartedOnce sync.Once
		var initCalls atomic.Int32
		var wg sync.WaitGroup

		for i := 0; i < waitersPerAttempt; i++ {
			sessionID := fmt.Sprintf("stress-mixed-session-%d-%d", attempt, i)
			sessionCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
				ClientID:  fmt.Sprintf("stress-mixed-client-%d-%d", attempt, i),
				SessionID: sessionID,
			})
			sessionCtx = ContextWithCache(sessionCtx, c)
			sessionCtx = srvToContext(sessionCtx, srv)
			waitCtx, cancel := context.WithCancel(sessionCtx)
			waiterSpecs[i] = waiterSpec{
				waitCtx:    waitCtx,
				releaseCtx: sessionCtx,
				cancel:     cancel,
				sessionID:  sessionID,
			}

			waiterDone[i] = make(chan struct{})
			wg.Add(1)
			go func(i int) {
				defer wg.Done()
				defer close(waiterDone[i])
				res, err := c.GetOrInitCall(waiterSpecs[i].waitCtx, waiterSpecs[i].sessionID, srv, &CallRequest{
					ResultCall:     parentCall,
					ConcurrencyKey: concurrencyKey,
				}, func(context.Context) (AnyResult, error) {
					initCalls.Add(1)
					initStartedOnce.Do(func() { close(initStarted) })
					<-unblockInit
					return cacheTestDetachedResult(parentCall, ObjectResultArray[*cacheTestObject]{child1, child2}), nil
				})
				waiterOutcomes[i] = waiterOutcome{
					res: res,
					err: err,
				}
			}(i)
		}

		select {
		case <-initStarted:
		case <-time.After(5 * time.Second):
			t.Fatalf("attempt %d: timed out waiting for init start", attempt)
		}

		// The initializer is blocked; wait until every caller has joined and
		// is waiting for completion or cancellation before inspecting its count.
		synctest.Wait()
		c.callsMu.Lock()
		oc := c.ongoingCalls[callConcKeys]
		lastObservedWaiters := -1
		if oc != nil {
			lastObservedWaiters = oc.waiters
		}
		c.callsMu.Unlock()
		assert.Equal(t, waitersPerAttempt, lastObservedWaiters, "attempt %d: expected all waiters to join", attempt)

		for i := 0; i < earlyCanceled; i++ {
			waiterSpecs[i].cancel()
		}
		// A canceled context alone does not make cancellation win Cache.wait's
		// select once the result is ready. Join these returns while the
		// initializer is still blocked, preserving strict early cancellation.
		for i := 0; i < earlyCanceled; i++ {
			select {
			case <-waiterDone[i]:
			case <-time.After(5 * time.Second):
				t.Fatalf("attempt %d waiter %d: timed out waiting for early cancellation", attempt, i)
			}
		}
		for i := earlyCanceled; i < earlyCanceled+racingCanceled; i++ {
			go waiterSpecs[i].cancel()
		}
		releaseInit()

		wg.Wait()
		assert.Equal(t, int32(1), initCalls.Load(), "attempt %d: expected exactly one initializer", attempt)

		earlyCanceledCount := 0
		racingCanceledCount := 0
		successCount := 0
		for i, outcome := range waiterOutcomes {
			switch {
			case i < earlyCanceled:
				assert.Assert(t, is.ErrorIs(outcome.err, context.Canceled), "attempt %d waiter %d: expected context canceled, got %v", attempt, i, outcome.err)
				earlyCanceledCount++
			case i < earlyCanceled+racingCanceled:
				if outcome.err != nil {
					assert.Assert(t, is.ErrorIs(outcome.err, context.Canceled), "attempt %d waiter %d: expected nil or context canceled, got %v", attempt, i, outcome.err)
					racingCanceledCount++
					continue
				}
				assert.Assert(t, outcome.res != nil, "attempt %d waiter %d: expected result on success", attempt, i)
				_, err := outcome.res.ResultCall()
				assert.NilError(t, err, "attempt %d waiter %d: result call", attempt, i)
				nth, err := outcome.res.NthValue(waiterSpecs[i].releaseCtx, 1)
				assert.NilError(t, err, "attempt %d waiter %d: nth value", attempt, i)
				assert.Assert(t, nth != nil, "attempt %d waiter %d: nil nth result", attempt, i)
				_, err = nth.ResultCall()
				assert.NilError(t, err, "attempt %d waiter %d: nth result call", attempt, i)
				successCount++
			default:
				assert.NilError(t, outcome.err, "attempt %d waiter %d: expected success", attempt, i)
				assert.Assert(t, outcome.res != nil, "attempt %d waiter %d: expected result on success", attempt, i)
				_, err := outcome.res.ResultCall()
				assert.NilError(t, err, "attempt %d waiter %d: result call", attempt, i)
				nth, err := outcome.res.NthValue(waiterSpecs[i].releaseCtx, 1)
				assert.NilError(t, err, "attempt %d waiter %d: nth value", attempt, i)
				assert.Assert(t, nth != nil, "attempt %d waiter %d: nil nth result", attempt, i)
				_, err = nth.ResultCall()
				assert.NilError(t, err, "attempt %d waiter %d: nth result call", attempt, i)
				successCount++
			}
		}
		assert.Equal(t, earlyCanceled, earlyCanceledCount, "attempt %d: expected all early canceled waiters to return canceled", attempt)
		assert.Assert(t, successCount >= waitersPerAttempt-earlyCanceled-racingCanceled, "attempt %d: expected at least uncanceled waiters to succeed, got %d", attempt, successCount)

		for _, spec := range waiterSpecs {
			assert.NilError(t, c.ReleaseSession(spec.releaseCtx, spec.sessionID), "attempt %d release session %s", attempt, spec.sessionID)
			spec.cancel()
		}

		c.callsMu.Lock()
		_, ongoingStillPresent := c.ongoingCalls[callConcKeys]
		ongoingCallsCount := len(c.ongoingCalls)
		c.callsMu.Unlock()
		assert.Assert(t, !ongoingStillPresent, "attempt %d: ongoing call still present", attempt)
		assert.Equal(t, 0, ongoingCallsCount, "attempt %d: unexpected ongoing call count", attempt)

		c.sessionMu.Lock()
		remainingSessionCount := len(c.sessionResultIDsBySession)
		seedResults := c.sessionResultIDsBySession["stress-mixed-seed-session"]
		c.sessionMu.Unlock()
		assert.Equal(t, 1, remainingSessionCount, "attempt %d: expected only seed session to remain", attempt)
		assert.Assert(t, seedResults != nil)
		assert.Equal(t, 2, len(seedResults), "attempt %d: expected seed session to retain only child results", attempt)

		c.egraphMu.RLock()
		resultCount := len(c.resultsByID)
		child1StillPresent := c.resultsByID[child1Shared.id] != nil
		child2StillPresent := c.resultsByID[child2Shared.id] != nil
		c.egraphMu.RUnlock()
		assert.Equal(t, 2, resultCount, "attempt %d: expected only child results to remain", attempt)
		assert.Assert(t, child1StillPresent, "attempt %d: child1 missing after waiter releases", attempt)
		assert.Assert(t, child2StillPresent, "attempt %d: child2 missing after waiter releases", attempt)
	}

	assert.NilError(t, c.ReleaseSession(seedCtx, "stress-mixed-seed-session"))

	c.callsMu.Lock()
	remainingOngoingCalls := len(c.ongoingCalls)
	c.callsMu.Unlock()
	c.sessionMu.Lock()
	remainingSessionCount := len(c.sessionResultIDsBySession)
	c.sessionMu.Unlock()
	c.egraphMu.RLock()
	remainingResults := len(c.resultsByID)
	c.egraphMu.RUnlock()

	assert.Equal(t, 0, remainingOngoingCalls)
	assert.Equal(t, 0, remainingSessionCount)
	assert.Equal(t, 0, remainingResults)
	assert.Equal(t, 0, c.Size())
}

func TestCacheLoadResultByResultIDDoesNotReturnHitWithoutCallFrame(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)

	seedCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "stress-load-by-id-seed-client",
		SessionID: "stress-load-by-id-seed-session",
	})
	seedCtx = ContextWithCache(seedCtx, c)
	seedCtx = srvToContext(seedCtx, srv)

	child1Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-load-by-id-child-1",
	}
	child2Call := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "stress-load-by-id-child-2",
	}
	arrayCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(ObjectResultArray[*cacheTestObject]{}.Type()),
		Field: "stress-load-by-id-parent",
	}

	child1Any, err := c.GetOrInitCall(seedCtx, "stress-load-by-id-seed-session", srv, &CallRequest{ResultCall: child1Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child1Call, 1, nil), nil
	})
	assert.NilError(t, err)
	child1 := child1Any.(ObjectResult[*cacheTestObject])

	child2Any, err := c.GetOrInitCall(seedCtx, "stress-load-by-id-seed-session", srv, &CallRequest{ResultCall: child2Call}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, child2Call, 2, nil), nil
	})
	assert.NilError(t, err)
	child2 := child2Any.(ObjectResult[*cacheTestObject])

	newSessionCtx := func(worker, iter int) context.Context {
		ctx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
			ClientID:  fmt.Sprintf("stress-load-by-id-client-%d-%d", worker, iter),
			SessionID: fmt.Sprintf("stress-load-by-id-session-%d-%d", worker, iter),
		})
		ctx = ContextWithCache(ctx, c)
		ctx = srvToContext(ctx, srv)
		return ctx
	}

	buildArray := func(ctx context.Context, sessionID string) (AnyResult, error) {
		return c.GetOrInitCall(ctx, sessionID, srv, &CallRequest{ResultCall: arrayCall}, func(context.Context) (AnyResult, error) {
			return cacheTestDetachedResult(arrayCall, ObjectResultArray[*cacheTestObject]{child1, child2}), nil
		})
	}

	const (
		workers           = 24
		attemptsPerWorker = 1000
	)
	isTargetFailure := func(err error) bool {
		if err == nil {
			return false
		}
		return strings.Contains(err.Error(), "without call frame") ||
			strings.Contains(err.Error(), "has no call frame")
	}

	const ownerSessionID = "stress-load-by-id-owner-session"
	ownerCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "stress-load-by-id-owner-client",
		SessionID: ownerSessionID,
	})
	ownerCtx = ContextWithCache(ownerCtx, c)
	ownerCtx = srvToContext(ownerCtx, srv)

	ownerRes, err := buildArray(ownerCtx, ownerSessionID)
	assert.NilError(t, err)
	ownerShared := ownerRes.cacheSharedResult()
	assert.Assert(t, ownerShared != nil && ownerShared.id != 0)

	var currentResultID atomic.Uint64
	currentResultID.Store(uint64(ownerShared.id))

	start := make(chan struct{})
	stopOwner := make(chan struct{})
	ownerDone := make(chan struct{})
	ownerErrCh := make(chan error, 1)
	var attempts atomic.Int64
	var loadCount atomic.Int64
	var failure atomic.Pointer[string]

	go func() {
		defer close(ownerDone)
		<-start
		for iter := 0; ; iter++ {
			select {
			case <-stopOwner:
				return
			default:
			}

			producerSessionID := fmt.Sprintf("stress-load-by-id-owner-session-%d", iter)
			producerCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
				ClientID:  fmt.Sprintf("stress-load-by-id-owner-client-%d", iter),
				SessionID: producerSessionID,
			})
			producerCtx = ContextWithCache(producerCtx, c)
			producerCtx = srvToContext(producerCtx, srv)
			res, err := buildArray(producerCtx, producerSessionID)
			if err != nil {
				ownerErrCh <- err
				return
			}
			shared := res.cacheSharedResult()
			if shared == nil || shared.id == 0 {
				ownerErrCh <- fmt.Errorf("owner result missing shared result id")
				return
			}
			currentResultID.Store(uint64(shared.id))

			time.Sleep(50 * time.Microsecond)

			if err := c.ReleaseSession(producerCtx, producerSessionID); err != nil {
				ownerErrCh <- err
				return
			}
		}
	}()

	eg, egCtx := errgroup.WithContext(baseCtx)
	for worker := 0; worker < workers; worker++ {
		worker := worker
		eg.Go(func() error {
			<-start
			for iter := 0; iter < attemptsPerWorker; iter++ {
				if egCtx.Err() != nil {
					return egCtx.Err()
				}

				resultID := currentResultID.Load()
				if resultID == 0 {
					continue
				}

				ctx := newSessionCtx(worker, iter)
				clientMD, err := engine.ClientMetadataFromContext(ctx)
				if err != nil {
					return err
				}

				res, err := c.LoadResultByResultID(ctx, clientMD.SessionID, srv, resultID)
				attempts.Add(1)
				if err != nil {
					if strings.Contains(err.Error(), "missing shared result") {
						continue
					}
					return err
				}
				loadCount.Add(1)

				if _, err := res.ResultCall(); err != nil {
					if isTargetFailure(err) {
						msg := fmt.Sprintf("result call failure on worker=%d iter=%d resultID=%d: %v", worker, iter, resultID, err)
						failure.Store(&msg)
						return fmt.Errorf("%s", msg)
					}
					return err
				}

				nth, err := res.NthValue(ctx, 1)
				if err != nil {
					if isTargetFailure(err) {
						msg := fmt.Sprintf("nth failure on worker=%d iter=%d resultID=%d: %v", worker, iter, resultID, err)
						failure.Store(&msg)
						return fmt.Errorf("%s", msg)
					}
					return err
				}
				if nth == nil {
					return fmt.Errorf("worker=%d iter=%d: nil nth result", worker, iter)
				}
				if _, err := nth.ResultCall(); err != nil {
					if isTargetFailure(err) {
						msg := fmt.Sprintf("nth result call failure on worker=%d iter=%d resultID=%d: %v", worker, iter, resultID, err)
						failure.Store(&msg)
						return fmt.Errorf("%s", msg)
					}
					return err
				}

				if err := c.ReleaseSession(ctx, clientMD.SessionID); err != nil {
					return err
				}
			}
			return nil
		})
	}
	close(start)

	err = eg.Wait()
	close(stopOwner)
	<-ownerDone
	select {
	case ownerErr := <-ownerErrCh:
		err = errors.Join(err, ownerErr)
	default:
	}
	assert.NilError(t, c.ReleaseSession(ownerCtx, ownerSessionID))
	assert.NilError(t, c.ReleaseSession(seedCtx, "stress-load-by-id-seed-session"))
	if msg := failure.Load(); msg != nil {
		t.Fatalf("reproduced LoadResultByResultID call-frame race after %d attempts and %d loads: %s", attempts.Load(), loadCount.Load(), *msg)
	}
	assert.NilError(t, err)
	t.Logf("completed %d attempts and %d successful loads without reproducing the LoadResultByResultID call-frame race", attempts.Load(), loadCount.Load())
}

func TestCacheObjectResultRoundTripAndRelease(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)

	keyCall := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "object-result",
	}
	var releaseCalls atomic.Int32

	res1, err := c.GetOrInitCall(ctx, "test-session", srv, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
		return cacheTestObjectResult(t, srv, keyCall, 42, func(context.Context) error {
			releaseCalls.Add(1)
			return nil
		}), nil
	})
	assert.NilError(t, err)
	obj1, ok := res1.(ObjectResult[*cacheTestObject])
	assert.Assert(t, ok)
	assert.Equal(t, 42, obj1.Self().Value)
	assert.Assert(t, !obj1.HitCache())

	res2, err := c.GetOrInitCall(ctx, "test-session", srv, &CallRequest{ResultCall: keyCall}, func(context.Context) (AnyResult, error) {
		return nil, fmt.Errorf("unexpected initializer call")
	})
	assert.NilError(t, err)
	obj2, ok := res2.(ObjectResult[*cacheTestObject])
	assert.Assert(t, ok)
	assert.Equal(t, 42, obj2.Self().Value)
	assert.Assert(t, obj2.HitCache())

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, int32(1), releaseCalls.Load())
	assert.Equal(t, 0, c.Size())
}

func TestCacheTTLWithDBUsesStorageAndCallIndexes(t *testing.T) {
	t.Parallel()
	ctx := engine.ContextWithClientMetadata(t.Context(), &engine.ClientMetadata{
		ClientID:  "cache-test-client",
		SessionID: "cache-test-session",
	})
	dbPath := filepath.Join(t.TempDir(), "cache.db")

	cacheIface, err := NewCache(ctx, dbPath, nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	keyCall := cacheTestIntCall("ttl-key")
	initCalls := 0

	_, err = c.GetOrInitCall(ctx, "cache-test-session", noopTypeResolver{}, &CallRequest{
		ResultCall: keyCall,
		TTL:        60,
	}, func(context.Context) (AnyResult, error) {
		initCalls++
		return cacheTestIntResult(keyCall, 5), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, initCalls)

	res2, err := c.GetOrInitCall(ctx, "cache-test-session", noopTypeResolver{}, &CallRequest{
		ResultCall: keyCall,
		TTL:        60,
	}, func(context.Context) (AnyResult, error) {
		initCalls++
		return cacheTestIntResult(keyCall, 6), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, initCalls)
	assert.Assert(t, res2.HitCache())
	assert.Equal(t, 1, len(c.resultOutputEqClasses))

	cacheTestReleaseSession(t, c, ctx)
	// Persist-safe only affects DB metadata persistence; in-memory cache entries are
	// released when refs drain.
	assert.Equal(t, 0, len(c.resultOutputEqClasses))
	assert.Equal(t, 0, c.Size())
}

func TestCachePersistableRetainedAcrossSessionClose(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	base := cacheIface

	key := cacheTestIntCall("persistable-across-session-close")
	ctxSessionA := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "persistable-client-a",
		SessionID: "persistable-session-a",
	})
	ctxSessionB := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "persistable-client-b",
		SessionID: "persistable-session-b",
	})

	initCallsA := 0
	resA, err := base.GetOrInitCall(ctxSessionA, "persistable-session-a", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		initCallsA++
		return cacheTestIntResult(key, 41), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, initCallsA)
	assert.Assert(t, !resA.HitCache())
	assert.Equal(t, 1, base.EntryStats().RetainedCalls)

	assert.NilError(t, base.ReleaseSession(ctxSessionA, "persistable-session-a"))
	assert.Equal(t, 1, base.EntryStats().RetainedCalls)
	assert.Equal(t, 1, base.Size())

	initCallsB := 0
	resB, err := base.GetOrInitCall(ctxSessionB, "persistable-session-b", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		initCallsB++
		return cacheTestIntResult(key, 99), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, initCallsB)
	assert.Assert(t, resB.HitCache())
	assert.Equal(t, 41, cacheTestUnwrapInt(t, resB))

	assert.NilError(t, base.ReleaseSession(ctxSessionB, "persistable-session-b"))
	assert.Equal(t, 1, base.EntryStats().RetainedCalls)
	assert.Equal(t, 1, base.Size())
}

func TestCacheLatePersistableJoinCommitsBeforeHandoffRelease(t *testing.T) {
	for _, tc := range []struct {
		name                string
		lateWaiters         int
		canceledFinalWaiter bool
	}{
		{
			name:        "successful final waiter",
			lateWaiters: 2,
		},
		{
			name:                "canceled final waiter",
			lateWaiters:         1,
			canceledFinalWaiter: true,
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			unwrapValue := func(res AnyResult) int {
				t.Helper()
				value, ok := UnwrapAs[cacheTestLeaseCheckedInt](res)
				assert.Assert(t, ok, "expected cacheTestLeaseCheckedInt result, got %T", res)
				return int(value.Int)
			}

			ctx := cacheTestContext(t.Context())
			cacheIface, err := NewCache(ctx, "", nil, nil)
			assert.NilError(t, err)
			c := cacheIface

			const (
				sessionID      = "late-persistable-session"
				concurrencyKey = "late-persistable-concurrency"
			)
			key := cacheTestIntCall("late-persistable-commit")
			callConcKeys := callConcurrencyKeys{
				callKey:        cacheTestCallDigest(key).String(),
				concurrencyKey: concurrencyKey,
			}

			publicationReachedAttachment := make(chan struct{})
			allowPublicationToFinish := make(chan struct{})
			leaderResCh := make(chan AnyResult, 1)
			leaderErrCh := make(chan error, 1)
			go func() {
				res, err := c.GetOrInitCall(ctx, sessionID, noopTypeResolver{}, &CallRequest{
					ResultCall:     key,
					ConcurrencyKey: concurrencyKey,
					TTL:            60,
				}, func(context.Context) (AnyResult, error) {
					return cacheTestDetachedResult(key, cacheTestLeaseCheckedInt{
						Int: NewInt(42),
						onAttach: func(context.Context) error {
							close(publicationReachedAttachment)
							<-allowPublicationToFinish
							return nil
						},
					}), nil
				})
				leaderResCh <- res
				leaderErrCh <- err
			}()

			select {
			case <-publicationReachedAttachment:
			case <-time.After(5 * time.Second):
				t.Fatal("timed out waiting for publication to reach dependency attachment")
			}

			// Simulate requests whose e-graph lookup missed before indexing but
			// whose callsMu admission happens while publication is attaching. Keep
			// their waiter slots outstanding so the leader cannot release the
			// publication handoff before the test selects the final waiter.
			c.callsMu.Lock()
			oc := c.ongoingCalls[callConcKeys]
			expectedExpiry := time.Now().Unix() + 3600
			if oc != nil {
				oc.isPersistable.Store(true)
				oc.waiters += tc.lateWaiters
				oc.persistedEdgeExpiresAtUnix = expectedExpiry
			}
			c.callsMu.Unlock()
			assert.Assert(t, oc != nil)

			close(allowPublicationToFinish)
			var leaderRes AnyResult
			select {
			case leaderRes = <-leaderResCh:
			case <-time.After(5 * time.Second):
				t.Fatal("timed out waiting for leader result")
			}
			select {
			case err := <-leaderErrCh:
				assert.NilError(t, err)
			case <-time.After(5 * time.Second):
				t.Fatal("timed out waiting for leader error")
			}
			assert.Equal(t, 42, unwrapValue(leaderRes))

			c.callsMu.Lock()
			needsPersistedEdge, waiters := oc.needsPersistedEdge, oc.waiters
			_, ongoing := c.ongoingCalls[callConcKeys]
			c.callsMu.Unlock()
			assert.Assert(t, needsPersistedEdge)
			assert.Equal(t, tc.lateWaiters, waiters)
			assert.Assert(t, !ongoing)

			if tc.canceledFinalWaiter {
				// Leave only the handoff owner. If persistence happened after the
				// decrement, this final cancellation would collect the result.
				assert.NilError(t, c.ReleaseSession(ctx, sessionID))

				// Publication is complete and no goroutine reads waitCh anymore.
				// Replace the closed channel so wait deterministically selects the
				// canceled path for the synthetic final waiter.
				oc.waitCh = make(chan struct{})
				canceledCtx, cancel := context.WithCancel(ctx)
				cancel()
				_, err := c.wait(canceledCtx, sessionID, noopTypeResolver{}, oc, &CallRequest{
					ResultCall:     key,
					ConcurrencyKey: concurrencyKey,
					IsPersistable:  true,
				}, true)
				assert.ErrorIs(t, err, context.Canceled)
			} else {
				for range tc.lateWaiters {
					res, err := c.wait(ctx, sessionID, noopTypeResolver{}, oc, &CallRequest{
						ResultCall:     key,
						ConcurrencyKey: concurrencyKey,
						IsPersistable:  true,
					}, true)
					assert.NilError(t, err)
					assert.Equal(t, 42, unwrapValue(res))
				}
				assert.NilError(t, c.ReleaseSession(ctx, sessionID))
			}

			shared := leaderRes.cacheSharedResult()
			c.egraphMu.RLock()
			edge, found := c.persistedEdgesByResult[shared.id]
			live := c.resultsByID[shared.id] == shared
			ownershipCount := shared.incomingOwnershipCount
			c.egraphMu.RUnlock()
			assert.Assert(t, found)
			assert.Equal(t, expectedExpiry, edge.expiresAtUnix)
			assert.Assert(t, live)
			assert.Equal(t, int64(1), ownershipCount)
			assert.Equal(t, 1, c.EntryStats().RetainedCalls)
			assert.Equal(t, 1, c.Size())
		})
	}
}

func TestOngoingCallPersistableIntentConcurrentAccess(t *testing.T) {
	t.Parallel()

	oc := &ongoingCall{}
	start := make(chan struct{})
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		<-start
		for range 10_000 {
			oc.isPersistable.Store(true)
		}
	}()
	go func() {
		defer wg.Done()
		<-start
		for range 10_000 {
			_ = oc.isPersistable.Load()
		}
	}()
	close(start)
	wg.Wait()
	assert.Assert(t, oc.isPersistable.Load())
}

func TestCacheNonPersistableDropsWhenRefsDrain(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := cacheTestIntCall("non-persistable-drops")
	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: false,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(key, 7), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, c.EntryStats().RetainedCalls)
	assert.Equal(t, 1, len(c.resultOutputEqClasses))

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 0, c.EntryStats().RetainedCalls)
	assert.Equal(t, 0, len(c.resultOutputEqClasses))
	assert.Equal(t, 0, c.Size())
}

func TestCachePersistableHitUpgradesExistingResultToRetained(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := cacheTestIntCall("persistable-hit-upgrade")
	initCalls := 0

	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: false,
	}, func(context.Context) (AnyResult, error) {
		initCalls++
		return cacheTestIntResult(key, 17), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, initCalls)
	assert.Equal(t, 0, c.EntryStats().RetainedCalls)

	resB, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		initCalls++
		return cacheTestIntResult(key, 99), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, initCalls)
	assert.Assert(t, resB.HitCache())
	assert.Equal(t, 17, cacheTestUnwrapInt(t, resB))
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)

	cacheTestReleaseSession(t, c, ctx)
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)
	assert.Equal(t, 1, len(c.resultOutputEqClasses))

	initCallsAfter := 0
	resC, err := c.GetOrInitCall(ctx, "persistable-hit-after-release", noopTypeResolver{}, &CallRequest{
		ResultCall: key,
	}, func(context.Context) (AnyResult, error) {
		initCallsAfter++
		return cacheTestIntResult(key, 123), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, initCallsAfter)
	assert.Assert(t, resC.HitCache())
	assert.Equal(t, 17, cacheTestUnwrapInt(t, resC))
	assert.NilError(t, c.ReleaseSession(ctx, "persistable-hit-after-release"))
}

func TestCacheMakeResultUnpruneableRetainsAcrossSessionClose(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	ctxSessionA := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "unpruneable-client-a",
		SessionID: "unpruneable-session-a",
	})
	ctxSessionB := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "unpruneable-client-b",
		SessionID: "unpruneable-session-b",
	})
	key := cacheTestIntCall("make-result-unpruneable")

	initCallsA := 0
	resA, err := c.GetOrInitCall(ctxSessionA, "unpruneable-session-a", noopTypeResolver{}, &CallRequest{
		ResultCall: key,
	}, func(context.Context) (AnyResult, error) {
		initCallsA++
		return cacheTestIntResult(key, 55), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 1, initCallsA)
	assert.Equal(t, 0, c.EntryStats().RetainedCalls)

	assert.NilError(t, c.MakeResultUnpruneable(ctxSessionA, resA))
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)

	assert.NilError(t, c.ReleaseSession(ctxSessionA, "unpruneable-session-a"))
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)
	assert.Equal(t, 1, c.Size())

	initCallsB := 0
	resB, err := c.GetOrInitCall(ctxSessionB, "unpruneable-session-b", noopTypeResolver{}, &CallRequest{
		ResultCall: key,
	}, func(context.Context) (AnyResult, error) {
		initCallsB++
		return cacheTestIntResult(key, 99), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, initCallsB)
	assert.Assert(t, resB.HitCache())
	assert.Equal(t, 55, cacheTestUnwrapInt(t, resB))

	assert.NilError(t, c.ReleaseSession(ctxSessionB, "unpruneable-session-b"))
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)
}

func TestCacheMakeResultUnpruneableSkipsPrune(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := cacheTestIntCall("make-result-unpruneable-skip-prune")
	res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall: key,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(key, 77), nil
	})
	assert.NilError(t, err)
	assert.NilError(t, c.MakeResultUnpruneable(ctx, res))
	cacheTestReleaseSession(t, c, ctx)

	report, err := c.Prune(ctx, []CachePrunePolicy{{All: true}})
	assert.NilError(t, err)
	assert.Equal(t, 0, len(report.Entries))
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)
	assert.Equal(t, 1, c.Size())

	c.egraphMu.RLock()
	edge := c.persistedEdgesByResult[res.cacheSharedResult().id]
	c.egraphMu.RUnlock()
	assert.Assert(t, edge.unpruneable)
	assert.Equal(t, int64(0), edge.expiresAtUnix)
}

func TestCacheMakeResultUnpruneableClearsPersistedExpiry(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := cacheTestIntCall("make-result-unpruneable-clear-expiry")
	res, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: true,
		TTL:           60,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(key, 88), nil
	})
	assert.NilError(t, err)
	assert.NilError(t, c.MakeResultUnpruneable(ctx, res))

	shared := res.cacheSharedResult()
	assert.Assert(t, shared != nil)

	c.egraphMu.RLock()
	edge := c.persistedEdgesByResult[shared.id]
	resExpiry := shared.expiresAtUnix
	c.egraphMu.RUnlock()
	assert.Assert(t, edge.unpruneable)
	assert.Equal(t, int64(0), edge.expiresAtUnix)
	assert.Equal(t, int64(0), resExpiry)
}

func TestCacheUsageEntriesAllReportsSessionAndRetainedState(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	ctxSession := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "usage-retained-client",
		SessionID: "usage-retained-session",
	})
	key := cacheTestIntCall("usage-retained-persisted")

	res, err := c.GetOrInitCall(ctxSession, "usage-retained-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(key, 123), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !res.HitCache())

	entries := c.UsageEntriesAll(baseCtx)
	assert.Equal(t, 1, len(entries))
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)
	assert.Assert(t, entries[0].ActivelyUsed)
	assert.Assert(t, entries[0].CreatedTimeUnixNano > 0)
	assert.Assert(t, entries[0].MostRecentUseTimeUnixNano > 0)

	assert.NilError(t, c.ReleaseSession(ctxSession, "usage-retained-session"))

	entries = c.UsageEntriesAll(baseCtx)
	assert.Equal(t, 1, len(entries))
	assert.Equal(t, 1, c.EntryStats().RetainedCalls)
	assert.Assert(t, !entries[0].ActivelyUsed)
	assert.Assert(t, entries[0].MostRecentUseTimeUnixNano >= entries[0].CreatedTimeUnixNano)
}

func TestCacheUsageEntriesAllDedupesByUsageIdentity(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	sizeCalls := &atomic.Int32{}
	const dedupeIdentity = "snapshot://shared-identity"

	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    cacheTestIntCall("usage-dedupe-a"),
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(cacheTestIntCall("usage-dedupe-a"), 1, 512, dedupeIdentity, sizeCalls), nil
	})
	assert.NilError(t, err)
	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    cacheTestIntCall("usage-dedupe-b"),
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(cacheTestIntCall("usage-dedupe-b"), 2, 512, dedupeIdentity, sizeCalls), nil
	})
	assert.NilError(t, err)

	cacheTestReleaseSession(t, c, ctx)

	entries := c.UsageEntriesAll(ctx)
	assert.Equal(t, 2, len(entries))
	assert.Equal(t, int32(1), sizeCalls.Load())

	var totalBytes int64
	var nonZeroEntries int
	for _, ent := range entries {
		totalBytes += ent.SizeBytes
		if ent.SizeBytes > 0 {
			nonZeroEntries++
		}
	}
	assert.Equal(t, int64(512), totalBytes)
	assert.Equal(t, 1, nonZeroEntries)
}

func TestCacheUsageEntriesAllSumsOwnedUsageIdentities(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	sizeCalls := &atomic.Int32{}

	keyA := cacheTestIntCall("usage-multi-a")
	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    keyA,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return NewResultForCall(cacheTestSizedInt{
			Int:             NewInt(1),
			sizeByIdentity:  map[string]int64{"snapshot://a": 10, "snapshot://b": 20},
			usageIdentities: []string{"snapshot://a", "snapshot://b"},
			sizeCalls:       sizeCalls,
		}, keyA)
	})
	assert.NilError(t, err)

	keyB := cacheTestIntCall("usage-multi-b")
	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    keyB,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return NewResultForCall(cacheTestSizedInt{
			Int:             NewInt(2),
			sizeByIdentity:  map[string]int64{"snapshot://b": 20, "snapshot://c": 40},
			usageIdentities: []string{"snapshot://b", "snapshot://c"},
			sizeCalls:       sizeCalls,
		}, keyB)
	})
	assert.NilError(t, err)

	cacheTestReleaseSession(t, c, ctx)

	entries := c.UsageEntriesAll(ctx)
	assert.Equal(t, 2, len(entries))
	assert.Equal(t, int32(3), sizeCalls.Load())

	sizes := make([]int64, 0, len(entries))
	var totalBytes int64
	for _, ent := range entries {
		totalBytes += ent.SizeBytes
		sizes = append(sizes, ent.SizeBytes)
	}
	slices.Sort(sizes)
	assert.DeepEqual(t, sizes, []int64{30, 40})
	assert.Equal(t, int64(70), totalBytes)
}

func TestCacheUsageEntriesAllMutableUsageRemeasuresAfterSizeChange(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	sizeCalls := &atomic.Int32{}
	sizeSource := &atomic.Int64{}
	sizeSource.Store(100)
	key := cacheTestIntCall("usage-mutable-refresh")

	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    key,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestMutableSizedIntResult(key, 1, sizeSource, "snapshot://mutable-refresh", sizeCalls), nil
	})
	assert.NilError(t, err)

	cacheTestReleaseSession(t, c, ctx)

	entries1 := c.UsageEntriesAll(ctx)
	assert.Equal(t, 1, len(entries1))
	assert.Equal(t, int64(100), entries1[0].SizeBytes)
	assert.Equal(t, int32(1), sizeCalls.Load())

	sizeSource.Store(200)
	entries2 := c.UsageEntriesAll(ctx)
	assert.Equal(t, 1, len(entries2))
	assert.Equal(t, int64(200), entries2[0].SizeBytes)
	assert.Equal(t, int32(2), sizeCalls.Load())
}

func TestCachePruneKeepDuration(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	oldKey := cacheTestIntCall("prune-keep-duration-old")
	oldRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    oldKey,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(oldKey, 1, 50, "snapshot://prune-keep-duration-old", nil), nil
	})
	assert.NilError(t, err)

	newKey := cacheTestIntCall("prune-keep-duration-new")
	newRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    newKey,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(newKey, 2, 50, "snapshot://prune-keep-duration-new", nil), nil
	})
	assert.NilError(t, err)

	cacheTestReleaseSession(t, c, ctx)

	oldShared := oldRes.cacheSharedResult()
	newShared := newRes.cacheSharedResult()
	assert.Assert(t, oldShared != nil)
	assert.Assert(t, newShared != nil)

	now := time.Now()
	c.egraphMu.Lock()
	oldShared.lastUsedAtUnixNano = now.Add(-2 * time.Hour).UnixNano()
	oldShared.createdAtUnixNano = oldShared.lastUsedAtUnixNano
	newShared.lastUsedAtUnixNano = now.UnixNano()
	newShared.createdAtUnixNano = newShared.lastUsedAtUnixNano
	c.egraphMu.Unlock()

	report, err := c.Prune(ctx, []CachePrunePolicy{{
		All:          true,
		KeepDuration: time.Hour,
	}})
	assert.NilError(t, err)
	assert.Equal(t, 1, len(report.Entries))
	assert.Equal(t, cacheTestSharedResultEntryID(oldRes), report.Entries[0].ID)

	c.egraphMu.RLock()
	_, oldStillPresent := c.resultsByID[oldShared.id]
	_, newStillPresent := c.resultsByID[newShared.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, !oldStillPresent)
	assert.Assert(t, newStillPresent)
}

func TestCachePruneThresholdTargetSpace(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	keys := []*ResultCall{
		cacheTestIntCall("prune-threshold-1"),
		cacheTestIntCall("prune-threshold-2"),
		cacheTestIntCall("prune-threshold-3"),
	}
	results := make([]AnyResult, 0, len(keys))
	for i, key := range keys {
		keyCopy := key
		valueCopy := i + 1
		identityCopy := fmt.Sprintf("snapshot://prune-threshold-%d", i+1)
		res, getErr := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
			ResultCall:    keyCopy,
			IsPersistable: true,
		}, func(context.Context) (AnyResult, error) {
			return cacheTestSizedIntResult(keyCopy, valueCopy, 100, identityCopy, nil), nil
		})
		assert.NilError(t, getErr)
		results = append(results, res)
	}

	cacheTestReleaseSession(t, c, ctx)

	now := time.Now()
	for _, res := range results {
		assert.Assert(t, res.cacheSharedResult() != nil)
	}
	c.egraphMu.Lock()
	for i, res := range results {
		shared := res.cacheSharedResult()
		ts := now.Add(time.Duration(-3+i) * time.Hour).UnixNano()
		shared.lastUsedAtUnixNano = ts
		shared.createdAtUnixNano = ts
	}
	c.egraphMu.Unlock()

	report, err := c.Prune(ctx, []CachePrunePolicy{{
		All:          true,
		MaxUsedSpace: 250,
		TargetSpace:  100,
	}})
	assert.NilError(t, err)
	assert.Equal(t, 2, len(report.Entries))
	assert.Equal(t, int64(200), report.ReclaimedBytes)
	assert.Equal(t, cacheTestSharedResultEntryID(results[0]), report.Entries[0].ID)
	assert.Equal(t, cacheTestSharedResultEntryID(results[1]), report.Entries[1].ID)
}

func TestCachePruneMinFreeSpaceUsesCurrentFreeSpace(t *testing.T) {
	t.Parallel()

	target, triggered := pruneTargetBytes(CachePrunePolicy{
		MinFreeSpace:     200,
		CurrentFreeSpace: 150,
	}, 50)
	assert.Assert(t, triggered)
	assert.Equal(t, int64(50), target)

	target, triggered = pruneTargetBytes(CachePrunePolicy{
		MinFreeSpace:     200,
		CurrentFreeSpace: 250,
	}, 50)
	assert.Assert(t, !triggered)
	assert.Equal(t, int64(0), target)
}

func TestCachePruneSessionOwnedEntriesAreNeverPruned(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	ctxInUse := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "prune-in-use-client",
		SessionID: "prune-in-use-session",
	})
	inUseKey := cacheTestIntCall("prune-in-use")
	inUseRes, err := c.GetOrInitCall(ctxInUse, "prune-in-use-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    inUseKey,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(inUseKey, 1, 60, "snapshot://prune-in-use", nil), nil
	})
	assert.NilError(t, err)

	ctxPrunable := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "prune-prunable-client",
		SessionID: "prune-prunable-session",
	})
	prunableKey := cacheTestIntCall("prune-prunable")
	prunableRes, err := c.GetOrInitCall(ctxPrunable, "prune-prunable-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    prunableKey,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(prunableKey, 2, 60, "snapshot://prune-prunable", nil), nil
	})
	assert.NilError(t, err)

	assert.NilError(t, c.ReleaseSession(ctxPrunable, "prune-prunable-session"))

	report, err := c.Prune(baseCtx, []CachePrunePolicy{{All: true}})
	assert.NilError(t, err)
	assert.Equal(t, 1, len(report.Entries))
	assert.Equal(t, cacheTestSharedResultEntryID(prunableRes), report.Entries[0].ID)

	c.egraphMu.RLock()
	_, inUsePresent := c.resultsByID[inUseRes.cacheSharedResult().id]
	_, prunablePresent := c.resultsByID[prunableRes.cacheSharedResult().id]
	c.egraphMu.RUnlock()
	assert.Assert(t, inUsePresent)
	assert.Assert(t, !prunablePresent)
}

func TestCacheDoNotCacheRejectsOnReleaser(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())

	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := cacheTestIntCall("do-not-cache-onrelease")
	_, err = c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall: key,
		DoNotCache: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResultWithOnRelease(key, 1, func(context.Context) error {
			return nil
		}), nil
	})
	assert.ErrorContains(t, err, "cannot implement OnReleaser")
}

func TestCachePruneOrderedSimulationKeepsZeroDeltaPrerequisites(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	baseCall := cacheTestIntCall("prune-ordered-base")
	baseRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    baseCall,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(baseCall, 1, 100, "snapshot://prune-ordered-base", nil), nil
	})
	assert.NilError(t, err)

	rootACall := cacheTestIntCall("prune-ordered-root-a")
	rootARes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    rootACall,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(rootACall, 2, 10, "snapshot://prune-ordered-root-a", nil), nil
	})
	assert.NilError(t, err)
	assert.NilError(t, c.AddExplicitDependency(ctx, rootARes, baseRes, "test_prune_ordered_root_a"))

	rootBCall := cacheTestIntCall("prune-ordered-root-b")
	rootBRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{
		ResultCall:    rootBCall,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(rootBCall, 3, 10, "snapshot://prune-ordered-root-b", nil), nil
	})
	assert.NilError(t, err)
	assert.NilError(t, c.AddExplicitDependency(ctx, rootBRes, baseRes, "test_prune_ordered_root_b"))

	cacheTestReleaseSession(t, c, ctx)

	now := time.Now().Add(-2 * time.Hour).UnixNano()
	c.egraphMu.Lock()
	baseRes.cacheSharedResult().lastUsedAtUnixNano = now
	baseRes.cacheSharedResult().createdAtUnixNano = now
	rootARes.cacheSharedResult().lastUsedAtUnixNano = now
	rootARes.cacheSharedResult().createdAtUnixNano = now
	rootBRes.cacheSharedResult().lastUsedAtUnixNano = now
	rootBRes.cacheSharedResult().createdAtUnixNano = now
	c.egraphMu.Unlock()

	report, err := c.Prune(ctx, []CachePrunePolicy{{All: true}})
	assert.NilError(t, err)
	assert.Equal(t, 3, len(report.Entries))
	assert.Equal(t, cacheTestSharedResultEntryID(baseRes), report.Entries[0].ID)
	assert.Equal(t, int64(0), report.Entries[0].SizeBytes)
	assert.Equal(t, cacheTestSharedResultEntryID(rootARes), report.Entries[1].ID)
	assert.Equal(t, int64(10), report.Entries[1].SizeBytes)
	assert.Equal(t, cacheTestSharedResultEntryID(rootBRes), report.Entries[2].ID)
	assert.Equal(t, int64(110), report.Entries[2].SizeBytes)
	assert.Equal(t, int64(120), report.ReclaimedBytes)
}

func TestCompactEqClassesSkipsWhenBelowThreshold(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	c.egraphMu.Lock()
	c.initEgraphLocked()
	a := c.ensureEqClassForDigestLocked(ctx, "compact-threshold-a")
	b := c.ensureEqClassForDigestLocked(ctx, "compact-threshold-b")
	c1 := c.ensureEqClassForDigestLocked(ctx, "compact-threshold-c")
	_ = c.ensureEqClassForDigestLocked(ctx, "compact-threshold-dead-1")
	_ = c.ensureEqClassForDigestLocked(ctx, "compact-threshold-dead-2")
	c.resultsByID = map[sharedResultID]*sharedResult{
		1: {id: 1, self: Int(1), hasValue: true, resultCall: cacheTestIntCall("compact-threshold-a")},
		2: {id: 2, self: Int(2), hasValue: true, resultCall: cacheTestIntCall("compact-threshold-b")},
		3: {id: 3, self: Int(3), hasValue: true, resultCall: cacheTestIntCall("compact-threshold-c")},
	}
	c.addResultOutputEqClassLocked(1, a)
	c.addResultOutputEqClassLocked(2, b)
	c.addResultOutputEqClassLocked(3, c1)
	compacted, oldSlots, newSlots := c.compactEqClassesLocked(false)
	forced, forcedOldSlots, forcedNewSlots := c.compactEqClassesLocked(true)
	c.egraphMu.Unlock()

	assert.Assert(t, !compacted)
	assert.Equal(t, 5, oldSlots)
	assert.Equal(t, 3, newSlots)
	assert.Assert(t, forced)
	assert.Equal(t, 5, forcedOldSlots)
	assert.Equal(t, 3, forcedNewSlots)
	assert.Equal(t, 4, len(c.egraphParents))
}

func TestCachePruneCompactsEqClassesAndPreservesLookup(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	ctxActive := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "prune-compact-active",
		SessionID: "prune-compact-active",
	})
	ctxPrunable := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "prune-compact-prunable",
		SessionID: "prune-compact-prunable",
	})
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	activeKey := cacheTestIntCall("prune-compact-active")
	activeRes, err := c.GetOrInitCall(ctxActive, "prune-compact-active", noopTypeResolver{}, &CallRequest{
		ResultCall: activeKey,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(activeKey, 11), nil
	})
	assert.NilError(t, err)
	activeShared := activeRes.cacheSharedResult()
	assert.Assert(t, activeShared != nil)

	prunableKey := cacheTestIntCall("prune-compact-prunable")
	prunableRes, err := c.GetOrInitCall(ctxPrunable, "prune-compact-prunable", noopTypeResolver{}, &CallRequest{
		ResultCall:    prunableKey,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(prunableKey, 22, 10, "snapshot://prune-compact-prunable", nil), nil
	})
	assert.NilError(t, err)
	prunableShared := prunableRes.cacheSharedResult()
	assert.Assert(t, prunableShared != nil)

	assert.NilError(t, c.ReleaseSession(ctxPrunable, "prune-compact-prunable"))
	c.egraphMu.Lock()
	originalSlots := len(c.egraphParents)
	_ = c.ensureEqClassForDigestLocked(baseCtx, "prune-compact-dead-1")
	_ = c.ensureEqClassForDigestLocked(baseCtx, "prune-compact-dead-2")
	_ = c.ensureEqClassForDigestLocked(baseCtx, "prune-compact-dead-3")
	_ = c.ensureEqClassForDigestLocked(baseCtx, "prune-compact-dead-4")
	bloatedSlots := len(c.egraphParents)
	c.egraphMu.Unlock()
	assert.Assert(t, bloatedSlots > originalSlots)

	report, err := c.Prune(baseCtx, []CachePrunePolicy{{All: true}})
	assert.NilError(t, err)
	assert.Equal(t, 1, len(report.Entries))
	assert.Equal(t, cacheTestSharedResultEntryID(prunableRes), report.Entries[0].ID)

	c.egraphMu.RLock()
	compactedSlots := len(c.egraphParents)
	_, activePresent := c.resultsByID[activeShared.id]
	_, prunablePresent := c.resultsByID[prunableShared.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, compactedSlots < bloatedSlots)
	assert.Assert(t, compactedSlots >= 2)
	assert.Assert(t, activePresent)
	assert.Assert(t, !prunablePresent)

	hitCount := 0
	hitRes, err := c.GetOrInitCall(ctxActive, "prune-compact-active", noopTypeResolver{}, &CallRequest{ResultCall: activeKey}, func(context.Context) (AnyResult, error) {
		hitCount++
		return cacheTestIntResult(activeKey, 99), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, hitCount)
	assert.Assert(t, hitRes.HitCache())
	assert.Equal(t, 11, cacheTestUnwrapInt(t, hitRes))

	cacheTestReleaseSession(t, c, ctxActive)
}

func TestCachePruneProtectsExactDependencyOfActiveResult(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	ctxActive := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "prune-exact-active",
		SessionID: "prune-exact-active",
	})
	ctxDep := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "prune-exact-dep",
		SessionID: "prune-exact-dep",
	})
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	activeCall := cacheTestIntCall("prune-exact-active-root")
	depCall := cacheTestIntCall("prune-exact-active-dep")

	activeRes, err := c.GetOrInitCall(ctxActive, "prune-exact-active", noopTypeResolver{}, &CallRequest{
		ResultCall: activeCall,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(activeCall, 1, 10, "snapshot://prune-exact-active-root", nil), nil
	})
	assert.NilError(t, err)
	depRes, err := c.GetOrInitCall(ctxDep, "prune-exact-dep", noopTypeResolver{}, &CallRequest{
		ResultCall:    depCall,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		return cacheTestSizedIntResult(depCall, 2, 20, "snapshot://prune-exact-active-dep", nil), nil
	})
	assert.NilError(t, err)
	depShared := depRes.cacheSharedResult()
	assert.Assert(t, depShared != nil)

	assert.NilError(t, c.AddExplicitDependency(ctxActive, activeRes, depRes, "test_prune_exact_dependency"))
	assert.NilError(t, c.ReleaseSession(ctxDep, "prune-exact-dep"))

	report, err := c.Prune(baseCtx, []CachePrunePolicy{{All: true}})
	assert.NilError(t, err)
	assert.Equal(t, 0, len(report.Entries))

	c.egraphMu.RLock()
	_, activePresent := c.resultsByID[activeRes.cacheSharedResult().id]
	_, depPresent := c.resultsByID[depShared.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, activePresent)
	assert.Assert(t, depPresent)

	assert.NilError(t, c.ReleaseSession(ctxActive, "prune-exact-active"))

	report, err = c.Prune(baseCtx, []CachePrunePolicy{{All: true}})
	assert.NilError(t, err)
	assert.Equal(t, 1, len(report.Entries))
	assert.Equal(t, cacheTestSharedResultEntryID(depRes), report.Entries[0].ID)
}

func TestCachePruneDoesNotProtectTermProvenanceOnlyResultFromActiveResult(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	root := &sharedResult{
		id:       1,
		self:     cacheTestSizedInt{Int: Int(1), sizeByIdentity: map[string]int64{"snapshot://prune-structural-root": 10}, usageIdentities: []string{"snapshot://prune-structural-root"}},
		hasValue: true,
		resultCall: &ResultCall{
			Kind:        ResultCallKindSynthetic,
			SyntheticOp: "root",
			Type:        NewResultCallType(Int(0).Type()),
		},
		incomingOwnershipCount: 1,
	}
	provenanceOnly := &sharedResult{
		id:       2,
		self:     cacheTestSizedInt{Int: Int(2), sizeByIdentity: map[string]int64{"snapshot://prune-structural-provenance-only": 20}, usageIdentities: []string{"snapshot://prune-structural-provenance-only"}},
		hasValue: true,
		resultCall: &ResultCall{
			Kind:        ResultCallKindSynthetic,
			SyntheticOp: "provenanceOnly",
			Type:        NewResultCallType(Int(0).Type()),
		},
		incomingOwnershipCount: 1,
	}

	c.egraphMu.Lock()
	c.initEgraphLocked()
	c.resultsByID = map[sharedResultID]*sharedResult{
		root.id:           root,
		provenanceOnly.id: provenanceOnly,
	}

	rootEq := c.ensureEqClassForDigestLocked(baseCtx, "prune-structural-root")
	provenanceEq := c.ensureEqClassForDigestLocked(baseCtx, "prune-structural-provenance-only")
	c.addResultOutputEqClassLocked(root.id, rootEq)
	c.addResultOutputEqClassLocked(provenanceOnly.id, provenanceEq)
	c.persistedEdgesByResult = map[sharedResultID]persistedEdge{
		provenanceOnly.id: {
			resultID:          provenanceOnly.id,
			createdAtUnixNano: time.Now().UnixNano(),
		},
	}

	termID := egraphTermID(1)
	c.egraphTerms[termID] = newEgraphTerm(termID, digest.FromString("prune-structural-root-term"), []eqClassID{provenanceEq}, rootEq)
	c.outputEqClassToTerms[rootEq] = map[egraphTermID]struct{}{termID: {}}
	c.termInputProvenance[termID] = []egraphInputProvenanceKind{egraphInputProvenanceKindResult}
	c.egraphMu.Unlock()
	c.sessionMu.Lock()
	c.sessionResultIDsBySession = map[string]map[sharedResultID]struct{}{
		"prune-structural-active": {root.id: {}},
	}
	c.sessionMu.Unlock()

	report, err := c.Prune(baseCtx, []CachePrunePolicy{{All: true}})
	assert.NilError(t, err)
	assert.Equal(t, 1, len(report.Entries))
	assert.Equal(t, "dagql.result.2", report.Entries[0].ID)

	c.egraphMu.RLock()
	_, rootPresent := c.resultsByID[root.id]
	_, provenancePresent := c.resultsByID[provenanceOnly.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, rootPresent)
	assert.Assert(t, !provenancePresent)
}

func TestCacheAttachDependencyResults(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	ctxParent := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "attach-owned-parent",
		SessionID: "attach-owned-parent",
	})
	ctxLookup := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "attach-owned-lookup",
		SessionID: "attach-owned-lookup",
	})
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	parentCall := cacheTestIntCall("parent-with-additional-output")
	childCall := cacheTestIntCall("child-additional-output")
	parentRes, err := c.GetOrInitCall(ctxParent, "attach-owned-parent", noopTypeResolver{}, &CallRequest{
		ResultCall:    parentCall,
		IsPersistable: true,
	}, func(context.Context) (AnyResult, error) {
		child := cacheTestSizedIntResult(
			childCall,
			2,
			128,
			"snapshot://cache-additional-output",
			nil,
		)
		return cacheTestDetachedResult(parentCall, &cacheTestOwnedDepsInt{
			Int:          NewInt(1),
			ownedResults: []AnyResult{child},
		}), nil
	})
	assert.NilError(t, err)
	parentShared := parentRes.cacheSharedResult()
	assert.Assert(t, parentShared != nil)

	childInitCalls := 0
	childRes, err := c.GetOrInitCall(ctxParent, "attach-owned-parent", noopTypeResolver{}, &CallRequest{ResultCall: childCall}, func(context.Context) (AnyResult, error) {
		childInitCalls++
		return cacheTestIntResult(childCall, 99), nil
	})
	assert.NilError(t, err)
	assert.Equal(t, 0, childInitCalls)
	assert.Assert(t, childRes.HitCache())
	childVal, ok := UnwrapAs[cacheTestSizedInt](childRes)
	assert.Assert(t, ok)
	assert.Equal(t, int64(2), int64(childVal.Int))

	childShared := childRes.cacheSharedResult()
	assert.Assert(t, childShared != nil)

	c.egraphMu.RLock()
	cachedParent := c.resultsByID[parentShared.id]
	cachedChild := c.resultsByID[childShared.id]
	parentDependsOnChild := false
	childIncomingOwnershipCount := int64(0)
	if cachedParent != nil {
		_, parentDependsOnChild = cachedParent.deps[childShared.id]
	}
	if cachedChild != nil {
		childIncomingOwnershipCount = cachedChild.incomingOwnershipCount
	}
	c.egraphMu.RUnlock()

	assert.Assert(t, cachedParent != nil)
	assert.Assert(t, cachedChild != nil)
	assert.Assert(t, parentDependsOnChild)
	assert.Equal(t, int64(2), childIncomingOwnershipCount)

	assert.NilError(t, c.ReleaseSession(ctxParent, "attach-owned-parent"))

	c.egraphMu.RLock()
	_, parentStillPresent := c.resultsByID[parentShared.id]
	_, childStillPresent := c.resultsByID[childShared.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, parentStillPresent)
	assert.Assert(t, childStillPresent)

	childRes, err = c.GetOrInitCall(ctxLookup, "attach-owned-lookup", noopTypeResolver{}, &CallRequest{ResultCall: childCall}, func(context.Context) (AnyResult, error) {
		childInitCalls++
		return cacheTestIntResult(childCall, 99), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, childRes.HitCache())
}

func TestCacheAttachDependencyResultsAlreadyAttachedChild(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	ctxChild := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "attached-child-owner",
		SessionID: "attached-child-owner",
	})
	ctxParent := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "attached-child-parent",
		SessionID: "attached-child-parent",
	})
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	childCall := cacheTestIntCall("child-already-attached")
	attachedChild, err := c.GetOrInitCall(ctxChild, "attached-child-owner", noopTypeResolver{}, &CallRequest{ResultCall: childCall}, ValueFunc(cacheTestIntResult(childCall, 2)))
	assert.NilError(t, err)
	childShared := attachedChild.cacheSharedResult()
	assert.Assert(t, childShared != nil)

	parentCall := cacheTestIntCall("parent-already-attached-child")
	parentRes, err := c.GetOrInitCall(ctxParent, "attached-child-parent", noopTypeResolver{}, &CallRequest{ResultCall: parentCall}, func(context.Context) (AnyResult, error) {
		return cacheTestDetachedResult(parentCall, &cacheTestOwnedDepsInt{
			Int:          NewInt(1),
			ownedResults: []AnyResult{attachedChild},
		}), nil
	})
	assert.NilError(t, err)
	parentShared := parentRes.cacheSharedResult()
	assert.Assert(t, parentShared != nil)

	assert.NilError(t, c.ReleaseSession(ctxChild, "attached-child-owner"))

	c.egraphMu.RLock()
	heldChild := c.resultsByID[childShared.id]
	heldParent := c.resultsByID[parentShared.id]
	parentDependsOnChild := false
	if heldParent != nil {
		_, parentDependsOnChild = heldParent.deps[childShared.id]
	}
	c.egraphMu.RUnlock()
	assert.Assert(t, heldChild != nil)
	assert.Assert(t, heldParent != nil)
	assert.Assert(t, parentDependsOnChild)

	assert.NilError(t, c.ReleaseSession(ctxParent, "attached-child-parent"))

	c.egraphMu.RLock()
	removedChild := c.resultsByID[childShared.id]
	removedParent := c.resultsByID[parentShared.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, removedChild == nil)
	assert.Assert(t, removedParent == nil)
}

func TestCacheAddExplicitDependency(t *testing.T) {
	t.Parallel()
	baseCtx := t.Context()
	ctxParent := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "explicit-dep-parent",
		SessionID: "explicit-dep-parent",
	})
	ctxChild := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "explicit-dep-child",
		SessionID: "explicit-dep-child",
	})
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	parentCall := cacheTestIntCall("parent-explicit-dependency")
	childCall := cacheTestIntCall("child-explicit-dependency")

	parentRes, err := c.GetOrInitCall(ctxParent, "explicit-dep-parent", noopTypeResolver{}, &CallRequest{ResultCall: parentCall}, ValueFunc(cacheTestIntResult(parentCall, 1)))
	assert.NilError(t, err)
	childRes, err := c.GetOrInitCall(ctxChild, "explicit-dep-child", noopTypeResolver{}, &CallRequest{ResultCall: childCall}, ValueFunc(cacheTestIntResult(childCall, 2)))
	assert.NilError(t, err)

	parentShared := parentRes.cacheSharedResult()
	childShared := childRes.cacheSharedResult()
	assert.Assert(t, parentShared != nil)
	assert.Assert(t, childShared != nil)

	assert.NilError(t, c.AddExplicitDependency(ctxParent, parentRes, childRes, "test_explicit_dependency"))

	c.egraphMu.RLock()
	cachedParent := c.resultsByID[parentShared.id]
	parentDependsOnChild := false
	childIncomingOwnershipCount := int64(0)
	if cachedParent != nil {
		_, parentDependsOnChild = cachedParent.deps[childShared.id]
	}
	if cachedChild := c.resultsByID[childShared.id]; cachedChild != nil {
		childIncomingOwnershipCount = cachedChild.incomingOwnershipCount
	}
	c.egraphMu.RUnlock()

	assert.Assert(t, cachedParent != nil)
	assert.Assert(t, parentDependsOnChild)
	assert.Equal(t, int64(2), childIncomingOwnershipCount)

	assert.NilError(t, c.ReleaseSession(ctxChild, "explicit-dep-child"))

	c.egraphMu.RLock()
	_, childStillPresent := c.resultsByID[childShared.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, childStillPresent)

	assert.NilError(t, c.ReleaseSession(ctxParent, "explicit-dep-parent"))

	c.egraphMu.RLock()
	_, childStillPresent = c.resultsByID[childShared.id]
	c.egraphMu.RUnlock()
	assert.Assert(t, !childStillPresent)
}

func TestCacheResultCallDerivedFromRequestID(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())

	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	childCall := cacheTestIntCall("frameChild")
	childRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: childCall}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(childCall, 7), nil
	})
	assert.NilError(t, err)
	childShared := childRes.cacheSharedResult()
	assert.Assert(t, childShared != nil)
	assert.Assert(t, childShared.id != 0)

	parentRes, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(Int(0).Type()),
		Field: "frameParent",
		Args: []*ResultCallArg{
			{Name: "child", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindResultRef, ResultRef: &ResultCallRef{ResultID: uint64(childShared.id)}}},
			{Name: "payload", Value: &ResultCallLiteral{Kind: ResultCallLiteralKindDigestedString, DigestedStringValue: "same", DigestedStringDigest: digest.FromString("frame-payload")}},
		},
	}}, func(context.Context) (AnyResult, error) {
		return cacheTestPlainResult(NewInt(8)), nil
	})
	assert.NilError(t, err)
	parentShared := parentRes.cacheSharedResult()
	assert.Assert(t, parentShared != nil)
	assert.Assert(t, parentShared.resultCall != nil)

	frame := parentShared.resultCall
	assert.Equal(t, ResultCallKindField, frame.Kind)
	assert.Equal(t, "frameParent", frame.Field)
	assert.Assert(t, frame.Type != nil)
	assert.Equal(t, "Int", frame.Type.NamedType)
	assert.Equal(t, 2, len(frame.Args))
	assert.Equal(t, "child", frame.Args[0].Name)
	assert.Assert(t, frame.Args[0].Value != nil)
	assert.Equal(t, ResultCallLiteralKindResultRef, frame.Args[0].Value.Kind)
	assert.Assert(t, frame.Args[0].Value.ResultRef != nil)
	assert.Equal(t, uint64(childShared.id), frame.Args[0].Value.ResultRef.ResultID)
	assert.Equal(t, "payload", frame.Args[1].Name)
	assert.Assert(t, frame.Args[1].Value != nil)
	assert.Equal(t, ResultCallLiteralKindDigestedString, frame.Args[1].Value.Kind)
	assert.Equal(t, "same", frame.Args[1].Value.DigestedStringValue)
	assert.Equal(t, digest.FromString("frame-payload"), frame.Args[1].Value.DigestedStringDigest)
}

func TestCacheResultCallFirstWriterWins(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())

	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	id := cacheTestIntCall("frame-first-writer")
	firstFrame := &ResultCall{
		Kind:        ResultCallKindSynthetic,
		SyntheticOp: "first",
		Type:        NewResultCallType(Int(0).Type()),
	}
	secondFrame := &ResultCall{
		Kind:        ResultCallKindSynthetic,
		SyntheticOp: "second",
		Type:        NewResultCallType(Int(0).Type()),
	}

	first, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: id}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(firstFrame, 1), nil
	})
	assert.NilError(t, err)
	firstShared := first.cacheSharedResult()
	assert.Assert(t, firstShared != nil)
	assert.Assert(t, firstShared.resultCall != nil)
	assert.Equal(t, "first", firstShared.resultCall.SyntheticOp)

	second, err := c.GetOrInitCall(ctx, "test-session", noopTypeResolver{}, &CallRequest{ResultCall: id}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(secondFrame, 2), nil
	})
	assert.NilError(t, err)
	assert.Assert(t, second.HitCache())

	secondShared := second.cacheSharedResult()
	assert.Assert(t, secondShared != nil)
	assert.Assert(t, secondShared.resultCall != nil)
	assert.Equal(t, "first", secondShared.resultCall.SyntheticOp)
}

func TestCacheArbitraryCallbackUsesOneClientScopeLease(t *testing.T) {
	t.Parallel()

	var acquired atomic.Int32
	var released atomic.Int32
	rootLease := engine.NewClientLifecycleLease(
		engine.ClientLeaseRequest,
		"request",
		func() {},
		func(kind engine.ClientLeaseKind, ownerID string) (*engine.ClientLifecycleLease, error) {
			if kind != engine.ClientLeaseSharedWork {
				return nil, fmt.Errorf("arbitrary callback lease kind = %q", kind)
			}
			if ownerID != "arbitrary/arbitrary-client-scope" {
				return nil, fmt.Errorf("arbitrary callback lease owner = %q", ownerID)
			}
			acquired.Add(1)
			return engine.NewClientLifecycleLease(kind, ownerID, func() { released.Add(1) }, nil), nil
		},
	)
	scope, err := engine.NewClientScope(&engine.ClientMetadata{
		SessionID: "test-session",
		ClientID:  "test-client",
	}, rootLease)
	require.NoError(t, err)
	ctx, err := engine.ContextWithClientScope(cacheTestContext(t.Context()), scope)
	require.NoError(t, err)

	cache, err := NewCache(ctx, "", nil, nil)
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, cache.ReleaseSession(ctx, "test-session")) })

	const key = "arbitrary-client-scope"
	started := make(chan struct{})
	unblock := make(chan struct{})
	var executions atomic.Int32
	initializer := func(callbackCtx context.Context) (any, error) {
		execution := executions.Add(1)
		if execution == 1 {
			close(started)
		}
		<-unblock
		if execution != 1 {
			return nil, fmt.Errorf("initializer executed %d times", execution)
		}
		callbackScope, ok := engine.ClientScopeFromContext(callbackCtx)
		if !ok {
			return nil, errors.New("initializer callback missing client scope")
		}
		if callbackScope.Lease().Kind() != engine.ClientLeaseSharedWork {
			return nil, fmt.Errorf("initializer callback lease kind = %q", callbackScope.Lease().Kind())
		}
		return "value", nil
	}

	type arbitraryCallResult struct {
		res ArbitraryCachedResult
		err error
	}
	results := make(chan arbitraryCallResult, 2)
	call := func() {
		res, err := cache.GetOrInitArbitrary(ctx, "test-session", key, initializer)
		results <- arbitraryCallResult{res: res, err: err}
	}
	go call()
	<-started
	go call()

	require.Eventually(t, func() bool {
		cache.callsMu.Lock()
		defer cache.callsMu.Unlock()
		ongoing := cache.ongoingArbitraryCalls[key]
		return ongoing != nil && ongoing.waiters == 2
	}, time.Second, time.Millisecond)
	require.Equal(t, int32(1), acquired.Load())
	require.Zero(t, released.Load())

	close(unblock)
	for range 2 {
		result := <-results
		require.NoError(t, result.err)
		require.Equal(t, "value", result.res.Value())
	}
	require.Equal(t, int32(1), executions.Load())
	// Lease release is ordered before waitCh closes, so every returning waiter
	// deterministically observes the callback's terminal lifecycle transition.
	require.Equal(t, int32(1), released.Load())

	cache.callsMu.Lock()
	completed := cache.completedArbitraryCalls[key]
	_, ongoing := cache.ongoingArbitraryCalls[key]
	cache.callsMu.Unlock()
	require.NotNil(t, completed)
	require.Nil(t, completed.cancel, "completed result must not retain the detached callback context")
	require.False(t, ongoing)
}

func TestCacheArbitraryCallbackCancelsAfterLastWaiter(t *testing.T) {
	t.Parallel()

	var acquired atomic.Int32
	var released atomic.Int32
	rootLease := engine.NewClientLifecycleLease(
		engine.ClientLeaseRequest,
		"request",
		func() {},
		func(kind engine.ClientLeaseKind, ownerID string) (*engine.ClientLifecycleLease, error) {
			acquired.Add(1)
			return engine.NewClientLifecycleLease(kind, ownerID, func() { released.Add(1) }, nil), nil
		},
	)
	scope, err := engine.NewClientScope(&engine.ClientMetadata{
		SessionID: "test-session",
		ClientID:  "test-client",
	}, rootLease)
	require.NoError(t, err)
	baseCtx, err := engine.ContextWithClientScope(cacheTestContext(t.Context()), scope)
	require.NoError(t, err)
	firstCtx, cancelFirst := context.WithCancel(baseCtx)
	defer cancelFirst()
	secondCtx, cancelSecond := context.WithCancel(baseCtx)
	defer cancelSecond()

	cache, err := NewCache(baseCtx, "", nil, nil)
	require.NoError(t, err)

	const key = "arbitrary-last-waiter-cancel"
	started := make(chan struct{})
	callbackDone := make(chan struct{})
	initializer := func(ctx context.Context) (any, error) { //nolint:unparam // signature fixed by GetOrInitArbitrary
		close(started)
		<-ctx.Done()
		close(callbackDone)
		return nil, context.Cause(ctx)
	}

	results := make(chan error, 2)
	go func() {
		_, err := cache.GetOrInitArbitrary(firstCtx, "test-session", key, initializer)
		results <- err
	}()
	<-started
	go func() {
		_, err := cache.GetOrInitArbitrary(secondCtx, "test-session", key, initializer)
		results <- err
	}()
	require.Eventually(t, func() bool {
		cache.callsMu.Lock()
		defer cache.callsMu.Unlock()
		ongoing := cache.ongoingArbitraryCalls[key]
		return ongoing != nil && ongoing.waiters == 2
	}, time.Second, time.Millisecond)
	require.Equal(t, int32(1), acquired.Load())

	cancelFirst()
	require.ErrorIs(t, <-results, context.Canceled)
	select {
	case <-callbackDone:
		t.Fatal("shared callback canceled before its last waiter left")
	default:
	}
	require.Zero(t, released.Load())

	cancelSecond()
	require.ErrorIs(t, <-results, context.Canceled)
	select {
	case <-callbackDone:
	case <-time.After(time.Second):
		t.Fatal("shared callback was not canceled after its last waiter left")
	}
	require.Eventually(t, func() bool { return released.Load() == 1 }, time.Second, time.Millisecond)
}

func TestCacheArbitraryRoundTripAndRelease(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())

	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := "arbitrary-round-trip"
	var releaseCalls atomic.Int32
	initCalls := 0

	res1, err := c.GetOrInitArbitrary(ctx, "test-session", key, func(context.Context) (any, error) {
		initCalls++
		return cacheTestOpaqueValue{
			value: "hello",
			onRelease: func(context.Context) error {
				releaseCalls.Add(1)
				return nil
			},
		}, nil
	})
	assert.NilError(t, err)
	assert.Assert(t, !res1.HitCache())
	v1, ok := res1.Value().(cacheTestOpaqueValue)
	assert.Assert(t, ok)
	assert.Equal(t, "hello", v1.value)

	res2, err := c.GetOrInitArbitrary(ctx, "test-session", key, func(context.Context) (any, error) {
		initCalls++
		return cacheTestOpaqueValue{value: "ignored"}, nil
	})
	assert.NilError(t, err)
	assert.Assert(t, res2.HitCache())
	v2, ok := res2.Value().(cacheTestOpaqueValue)
	assert.Assert(t, ok)
	assert.Equal(t, "hello", v2.value)
	assert.Equal(t, 1, initCalls)
	assert.Equal(t, 1, c.Size())

	assert.Assert(t, res1.Value() != nil)
	assert.Assert(t, res2.Value() != nil)
	assert.NilError(t, c.ReleaseSession(ctx, "test-session"))
	assert.Equal(t, int32(1), releaseCalls.Load())
	assert.Equal(t, 0, c.Size())
}

func TestCacheArbitraryConcurrent(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())

	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := "arbitrary-concurrent"
	initialized := map[int]bool{}
	var initMu sync.Mutex
	const totalCallers = 100

	firstCallEntered := make(chan struct{})
	unblockFirstCall := make(chan struct{})

	wg := new(sync.WaitGroup)
	wg.Add(1)
	go func() {
		defer wg.Done()
		res, err := c.GetOrInitArbitrary(ctx, "test-session", key, func(context.Context) (any, error) {
			initMu.Lock()
			initialized[0] = true
			initMu.Unlock()
			close(firstCallEntered)
			<-unblockFirstCall
			return "value", nil
		})
		assert.NilError(t, err)
		assert.Equal(t, "value", res.Value())
	}()

	select {
	case <-firstCallEntered:
	case <-time.After(3 * time.Second):
		t.Fatal("timed out waiting for first caller to enter init callback")
	}

	for i := 1; i < totalCallers; i++ {
		wg.Add(1)
		i := i
		go func() {
			defer wg.Done()
			res, err := c.GetOrInitArbitrary(ctx, "test-session", key, func(context.Context) (any, error) {
				initMu.Lock()
				initialized[i] = true
				initMu.Unlock()
				return "value", nil
			})
			assert.NilError(t, err)
			assert.Equal(t, "value", res.Value())
		}()
	}

	waiterCountReached := false
	waiterPollDeadline := time.Now().Add(3 * time.Second)
	lastObservedWaiters := -1
	for time.Now().Before(waiterPollDeadline) {
		c.callsMu.Lock()
		oc := c.ongoingArbitraryCalls[key]
		if oc != nil {
			lastObservedWaiters = oc.waiters
		}
		c.callsMu.Unlock()

		if oc != nil && lastObservedWaiters == totalCallers {
			waiterCountReached = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	assert.Assert(t, waiterCountReached, "expected %d waiters, last observed %d", totalCallers, lastObservedWaiters)

	close(unblockFirstCall)

	ongoingCleared := false
	clearPollDeadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(clearPollDeadline) {
		c.callsMu.Lock()
		_, exists := c.ongoingArbitraryCalls[key]
		c.callsMu.Unlock()
		if !exists {
			ongoingCleared = true
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	assert.Assert(t, ongoingCleared, "ongoing arbitrary call was not cleared")

	wg.Wait()

	initMu.Lock()
	defer initMu.Unlock()
	assert.Assert(t, is.Len(initialized, 1))
	assert.Assert(t, initialized[0])
	assert.Equal(t, 1, c.Size())
	assert.NilError(t, c.ReleaseSession(ctx, "test-session"))
	assert.Equal(t, 0, c.Size())
}

func TestCacheArbitraryRecursiveCall(t *testing.T) {
	t.Parallel()
	ctx := cacheTestContext(t.Context())

	cacheIface, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface

	key := "arbitrary-recursive"
	_, err = c.GetOrInitArbitrary(ctx, "test-session", key, func(ctx context.Context) (any, error) {
		_, err := c.GetOrInitArbitrary(ctx, "test-session", key, func(context.Context) (any, error) {
			return "should-not-run", nil
		})
		return nil, err
	})
	assert.Assert(t, is.ErrorIs(err, ErrCacheRecursiveCall))
}

func TestResolveSessionResourceCandidatesOrdering(t *testing.T) {
	ctx := t.Context()
	cache, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)

	const sessionID = "test-session"
	const preferredClientID = "preferred-client"
	const latestClientID = "latest-client"
	handle := SessionResourceHandle("test-resource")

	assert.NilError(t, cache.BindSessionResource(ctx, sessionID, "alpha-client", handle, "alpha"))
	assert.NilError(t, cache.BindSessionResource(ctx, sessionID, preferredClientID, handle, "preferred"))
	assert.NilError(t, cache.BindSessionResource(ctx, sessionID, latestClientID, handle, "latest"))

	resolved, err := cache.ResolveSessionResource(ctx, sessionID, preferredClientID, handle)
	assert.NilError(t, err)
	assert.Equal(t, resolved, "preferred")

	candidates, err := cache.ResolveSessionResourceCandidates(ctx, sessionID, preferredClientID, handle)
	assert.NilError(t, err)
	assert.Assert(t, is.Len(candidates, 3))
	assert.Equal(t, candidates[0].ClientID, preferredClientID)
	assert.Equal(t, candidates[0].Value, "preferred")
	assert.Equal(t, candidates[1].ClientID, latestClientID)
	assert.Equal(t, candidates[1].Value, "latest")
	assert.Equal(t, candidates[2].ClientID, "alpha-client")
	assert.Equal(t, candidates[2].Value, "alpha")
}

// The lookup resource filter reads the session's handle set after dropping
// sessionMu, and readers run it concurrently under the egraphMu read lock
// (part tasks and demands), so binding a handle must not modify a set the
// filter may be reading.
func TestCacheResourceFilterRacesHandleBinding(t *testing.T) {
	ctx := cacheTestContext(t.Context())
	c, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	assert.NilError(t, c.BindSessionResource(ctx, "s", "client", "h0", "v"))
	res := &sharedResult{requiredSessionResources: set.NewTreeSet(compareSessionResourceHandles)}
	res.requiredSessionResources.Insert("h0")

	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := range 2000 {
			assert.Check(t, c.BindSessionResource(ctx, "s", "client", SessionResourceHandle(fmt.Sprintf("h%d", i+1)), "v"))
		}
	}()
	for range 4 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for range 2000 {
				c.egraphMu.RLock()
				ok := c.sessionSatisfiesResourceRequirementsLocked("s", res)
				c.egraphMu.RUnlock()
				assert.Check(t, ok)
			}
		}()
	}
	wg.Wait()
}

// resolvePath recovers a panic raised inside a cache critical section into a
// call error and the engine keeps serving, so the panic must not leave
// egraphMu held behind it.
func TestCacheResultIDLookupPanicReleasesLock(t *testing.T) {
	t.Parallel()

	ctx := cacheTestContext(t.Context())
	c, err := NewCache(ctx, "", nil, nil)
	assert.NilError(t, err)
	srv := cacheTestServer(t)

	frame := cacheTestIntCall("lookup-panic")
	res, err := c.GetOrInitCall(ctx, "producer", srv, &CallRequest{ResultCall: frame}, func(context.Context) (AnyResult, error) {
		return cacheTestIntResult(frame, 1), nil
	})
	assert.NilError(t, err)
	resultID := uint64(res.cacheSharedResult().id)

	c.testInResultIDLookup = func(*sharedResult) {
		panic("cache-test panic in result ID lookup")
	}
	recovered := func() (r any) {
		defer func() { r = recover() }()
		_, _ = c.LoadResultByResultID(ctx, "panicked", srv, resultID)
		return nil
	}()
	assert.Equal(t, recovered, "cache-test panic in result ID lookup")
	c.testInResultIDLookup = nil

	loaded := make(chan error, 1)
	go func() {
		_, err := c.LoadResultByResultID(ctx, "after-panic", srv, resultID)
		loaded <- err
	}()
	select {
	case err := <-loaded:
		assert.NilError(t, err)
	case <-time.After(10 * time.Second):
		t.Fatal("result ID lookup still blocked 10s after a recovered panic in an earlier lookup")
	}

	assert.NilError(t, c.ReleaseSession(ctx, "after-panic"))
	assert.NilError(t, c.ReleaseSession(ctx, "producer"))
}

func TestCacheAddExplicitDependencyAcceptsSessionResourceDepsAndRecomputesAncestors(t *testing.T) {
	t.Parallel()

	baseCtx := cacheTestContext(t.Context())
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	ctx := ContextWithCache(baseCtx, c)
	srv := cacheTestServer(t)
	handle := cacheTestVolatileSessionResourceHandle("LATE_DEP")

	type slotArgs struct {
		Slot String `name:"slot"`
	}
	Fields[cacheTestQuery]{
		NodeFunc("resourceRequiringParent", func(ctx context.Context, _ ObjectResult[cacheTestQuery], _ struct{}) (Result[*cacheTestObject], error) {
			leaf, err := cacheTestSessionResourceLeaf(ctx, handle)
			if err != nil {
				return Result[*cacheTestObject]{}, err
			}
			return NewResultForCurrentCall(ctx, &cacheTestObject{
				Value:             1,
				dependencyResults: []AnyResult{leaf},
			})
		}),
		NodeFunc("plain", func(ctx context.Context, _ ObjectResult[cacheTestQuery], args slotArgs) (Result[*cacheTestObject], error) {
			return NewResultForCurrentCall(ctx, &cacheTestObject{Value: 2})
		}),
		NodeFunc("wrap", func(ctx context.Context, _ ObjectResult[cacheTestQuery], args slotArgs) (Result[*cacheTestObject], error) {
			var inner Result[*cacheTestObject]
			if err := srv.Select(ctx, srv.Root(), &inner, Selector{
				Field: "plain",
				Args:  []NamedInput{{Name: "slot", Value: args.Slot}},
			}); err != nil {
				return Result[*cacheTestObject]{}, err
			}
			return NewResultForCurrentCall(ctx, &cacheTestObject{
				Value:             3,
				dependencyResults: []AnyResult{inner},
			})
		}),
	}.Install(srv)
	assert.NilError(t, c.BindSessionResource(ctx, "test-session", "dagql-test-client", handle, "bound"))

	sel := func(field, slot string) Result[*cacheTestObject] {
		t.Helper()
		var res Result[*cacheTestObject]
		selector := Selector{Field: field}
		if slot != "" {
			selector.Args = []NamedInput{{Name: "slot", Value: NewString(slot)}}
		}
		assert.NilError(t, srv.Select(ctx, srv.Root(), &res, selector))
		return res
	}

	resourceRequiring := sel("resourceRequiringParent", "")
	middle := sel("plain", "a")
	plainDep := sel("plain", "b")
	top := sel("wrap", "a")
	topShared := top.cacheSharedResult()
	assert.Assert(t, topShared != nil && topShared.id != 0)
	middleShared := middle.cacheSharedResult()
	assert.Assert(t, middleShared != nil && middleShared.id != 0)
	assertCacheRequiredSessionResourcesExact(t, c)

	c.egraphMu.RLock()
	middleGenBefore := middleShared.requiredSessionResourcesGen.Load()
	topGenBefore := topShared.requiredSessionResourcesGen.Load()
	topRequiresBefore := cacheTestSessionResourceSetContains(topShared.requiredSessionResources, handle)
	c.egraphMu.RUnlock()
	assert.Assert(t, !topRequiresBefore)

	// The late dep on the already-published middle result must land, grow
	// middle's stored required set, and cascade to its ancestor: top depends
	// on middle, middle now depends on the requirement-carrying parent, so
	// both stored sets must grow to {handle} and both requirement
	// generations must move.
	assert.NilError(t, c.AddExplicitDependency(ctx, middle, resourceRequiring, "test_late_dep"))

	resourceRequiringShared := resourceRequiring.cacheSharedResult()
	assert.Assert(t, resourceRequiringShared != nil && resourceRequiringShared.id != 0)
	c.egraphMu.RLock()
	_, edgeAdded := middleShared.deps[resourceRequiringShared.id]
	middleRequired := cacheTestSessionResourceSetContains(middleShared.requiredSessionResources, handle)
	topRequired := cacheTestSessionResourceSetContains(topShared.requiredSessionResources, handle)
	middleGenAfter := middleShared.requiredSessionResourcesGen.Load()
	topGenAfter := topShared.requiredSessionResourcesGen.Load()
	c.egraphMu.RUnlock()
	assert.Assert(t, edgeAdded, "accepted dep must record the retention edge")
	assert.Assert(t, middleRequired)
	assert.Assert(t, topRequired, "ancestor stored set went stale after a late explicit dependency")
	assert.Assert(t, middleGenAfter > middleGenBefore, "growth must bump the parent's requirement generation")
	assert.Assert(t, topGenAfter > topGenBefore, "growth must bump the ancestor's requirement generation")
	assertCacheRequiredSessionResourcesExact(t, c)

	// A requirement-free dep must not bump the parent's generation: the
	// stored set does not change, so serve fast paths stay valid.
	assert.NilError(t, c.AddExplicitDependency(ctx, middle, plainDep, "test_retention_dep"))
	plainDepShared := plainDep.cacheSharedResult()
	assert.Assert(t, plainDepShared != nil && plainDepShared.id != 0)
	c.egraphMu.RLock()
	_, retained := middleShared.deps[plainDepShared.id]
	middleGenFinal := middleShared.requiredSessionResourcesGen.Load()
	c.egraphMu.RUnlock()
	assert.Assert(t, retained, "requirement-free retention edge must be recorded")
	assert.Equal(t, middleGenAfter, middleGenFinal, "an unchanged stored set must not bump the generation")
	assertCacheRequiredSessionResourcesExact(t, c)

	// A session that never bound the handle is refused a fresh ID load of
	// the grown ancestor: new selections read the grown stored set.
	otherCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "latedep-other-client",
		SessionID: "latedep-other",
	})
	otherCtx = ContextWithCache(otherCtx, c)
	_, err = c.LoadResultByResultID(otherCtx, "latedep-other", srv, uint64(topShared.id))
	assert.ErrorContains(t, err, "has not bound the session resources this result requires")

	// The binding session still loads it.
	loaded, err := c.LoadResultByResultID(ctx, "test-session", srv, uint64(topShared.id))
	assert.NilError(t, err)
	loadedShared := loaded.cacheSharedResult()
	assert.Assert(t, loadedShared != nil && loadedShared.id == topShared.id)

	assert.NilError(t, c.ReleaseSession(otherCtx, "latedep-other"))
	cacheTestReleaseSession(t, c, ctx)
}

// cacheTestBlockingAttachObj holds its dependency attachment open until the
// test releases it, so a second session can select the published result while
// its required set is still growing.
type cacheTestBlockingAttachObj struct {
	Value         int
	leaf          AnyResult
	attachErr     error
	selfID        uint64
	attachStarted chan struct{}
	attachRelease chan struct{}
}

func (*cacheTestBlockingAttachObj) Type() *ast.Type {
	return &ast.Type{
		NamedType: "CacheTestBlockingAttachObj",
		NonNull:   true,
	}
}

func (obj *cacheTestBlockingAttachObj) AttachDependencyResults(
	_ context.Context,
	self AnyResult,
	attach func(AnyResult) (AnyResult, error),
) ([]AnyResult, error) {
	if shared := self.cacheSharedResult(); shared != nil {
		obj.selfID = uint64(shared.id)
	}
	close(obj.attachStarted)
	<-obj.attachRelease
	if obj.attachErr != nil {
		return nil, obj.attachErr
	}
	if obj.leaf == nil {
		return nil, nil
	}
	attached, err := attach(obj.leaf)
	if err != nil {
		return nil, err
	}
	obj.leaf = attached
	return []AnyResult{attached}, nil
}

func TestCacheHitRechecksSessionResourcesAfterAttachBarrier(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)
	handle := cacheTestVolatileSessionResourceHandle("HIT_GROWTH")

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "hitgrow-a-client",
		SessionID: "hitgrow-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "hitgrow-b-client",
		SessionID: "hitgrow-b",
	})
	bCtx = ContextWithCache(bCtx, c)
	assert.NilError(t, c.BindSessionResource(aCtx, "hitgrow-a", "hitgrow-a-client", handle, "bound"))

	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestBlockingAttachObj{}).Type()),
		Field: "hit-growth-parent",
	}
	obj := &cacheTestBlockingAttachObj{
		Value:         1,
		attachStarted: make(chan struct{}),
		attachRelease: make(chan struct{}),
	}

	type callOutcome struct {
		res AnyResult
		err error
	}
	aDone := make(chan callOutcome, 1)
	go func() {
		res, err := c.GetOrInitCall(aCtx, "hitgrow-a", srv, &CallRequest{ResultCall: frame}, func(ctx context.Context) (AnyResult, error) {
			leaf, err := cacheTestSessionResourceLeaf(ctx, handle)
			if err != nil {
				return nil, err
			}
			obj.leaf = leaf
			res, err := NewResultForCall(obj, frame)
			if err != nil {
				return nil, err
			}
			return res, nil
		})
		aDone <- callOutcome{res: res, err: err}
	}()

	// Attachment has started, so the result is indexed and lookup-visible
	// with an empty required set, and the attach barrier is open.
	<-obj.attachStarted
	parentID := sharedResultID(obj.selfID)
	assert.Assert(t, parentID != 0)

	var bInitCalls atomic.Int32
	bDone := make(chan callOutcome, 1)
	go func() {
		res, err := c.GetOrInitCall(bCtx, "hitgrow-b", srv, &CallRequest{ResultCall: frame.clone()}, func(ctx context.Context) (AnyResult, error) {
			bInitCalls.Add(1)
			res, err := NewResultForCall(&cacheTestBlockingAttachObj{
				Value:         99,
				attachStarted: make(chan struct{}),
				attachRelease: func() chan struct{} { ch := make(chan struct{}); close(ch); return ch }(),
				leaf:          nil,
			}, frame.clone())
			if err != nil {
				return nil, err
			}
			return res, nil
		})
		bDone <- callOutcome{res: res, err: err}
	}()

	// B's lookup must select the parent before the required set grows; the
	// recorded session edge proves the selection happened.
	deadline := time.Now().Add(10 * time.Second)
	for {
		c.sessionMu.Lock()
		_, selected := c.sessionResultIDsBySession["hitgrow-b"][parentID]
		c.sessionMu.Unlock()
		if selected {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("timed out waiting for session B to select the still-attaching parent")
		}
		time.Sleep(time.Millisecond)
	}

	// Let attachment finish: the resource-requiring leaf lands and the parent's required
	// set grows to {handle} before the barrier opens for B.
	close(obj.attachRelease)

	aOut := <-aDone
	assert.NilError(t, aOut.err)
	aShared := aOut.res.cacheSharedResult()
	assert.Assert(t, aShared != nil && aShared.id == parentID)

	bOut := <-bDone
	assert.NilError(t, bOut.err)
	assert.Equal(t, int32(1), bInitCalls.Load(),
		"session B must fall through to the singleflight instead of being served the grown result")
	bShared := bOut.res.cacheSharedResult()
	assert.Assert(t, bShared != nil && bShared.id != 0)
	assert.Assert(t, bShared.id != parentID,
		"session B was served a result requiring a handle it never bound")

	c.egraphMu.RLock()
	parentRequires := cacheTestSessionResourceSetContains(aShared.requiredSessionResources, handle)
	c.egraphMu.RUnlock()
	assert.Assert(t, parentRequires)
	assertCacheRequiredSessionResourcesExact(t, c)

	assert.NilError(t, c.ReleaseSession(aCtx, "hitgrow-a"))
	assert.NilError(t, c.ReleaseSession(bCtx, "hitgrow-b"))
}

func TestCacheLoadResultByResultIDRechecksAfterAttachBarrier(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)
	handle := cacheTestVolatileSessionResourceHandle("LOAD_GROWTH")

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "loadgrow-a-client",
		SessionID: "loadgrow-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "loadgrow-b-client",
		SessionID: "loadgrow-b",
	})
	bCtx = ContextWithCache(bCtx, c)
	assert.NilError(t, c.BindSessionResource(aCtx, "loadgrow-a", "loadgrow-a-client", handle, "bound"))

	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestBlockingAttachObj{}).Type()),
		Field: "load-growth-parent",
	}
	obj := &cacheTestBlockingAttachObj{
		Value:         1,
		attachStarted: make(chan struct{}),
		attachRelease: make(chan struct{}),
	}

	type callOutcome struct {
		res AnyResult
		err error
	}
	aDone := make(chan callOutcome, 1)
	go func() {
		res, err := c.GetOrInitCall(aCtx, "loadgrow-a", srv, &CallRequest{ResultCall: frame}, func(ctx context.Context) (AnyResult, error) {
			leaf, err := cacheTestSessionResourceLeaf(ctx, handle)
			if err != nil {
				return nil, err
			}
			obj.leaf = leaf
			res, err := NewResultForCall(obj, frame)
			if err != nil {
				return nil, err
			}
			return res, nil
		})
		aDone <- callOutcome{res: res, err: err}
	}()

	<-obj.attachStarted
	parentID := sharedResultID(obj.selfID)
	assert.Assert(t, parentID != 0)

	bDone := make(chan callOutcome, 1)
	go func() {
		res, err := c.LoadResultByResultID(bCtx, "loadgrow-b", srv, uint64(parentID))
		bDone <- callOutcome{res: res, err: err}
	}()

	// The resource pre-check in sharedResultByResultID passes while the required
	// set is still empty and records the session edge; the load then parks at
	// the attach barrier.
	deadline := time.Now().Add(10 * time.Second)
	for {
		c.sessionMu.Lock()
		_, selected := c.sessionResultIDsBySession["loadgrow-b"][parentID]
		c.sessionMu.Unlock()
		if selected {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("timed out waiting for session B's load to pass the resource pre-check")
		}
		time.Sleep(time.Millisecond)
	}

	close(obj.attachRelease)

	aOut := <-aDone
	assert.NilError(t, aOut.err)

	bOut := <-bDone
	assert.Assert(t, bOut.err != nil,
		"session B's load must be refused once the required set grew past its bound set")
	assert.ErrorContains(t, bOut.err, "has not bound the session resources this result requires")

	assertCacheRequiredSessionResourcesExact(t, c)
	assert.NilError(t, c.ReleaseSession(aCtx, "loadgrow-a"))
	assert.NilError(t, c.ReleaseSession(bCtx, "loadgrow-b"))
}

func TestCacheLoadResultByResultIDIgnoresUncleanCanonicalSiblings(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)
	contentDig := digest.FromString("cache-test canonical clean attachment")

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "canon-a-client",
		SessionID: "canon-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	loaderCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "canon-loader-client",
		SessionID: "canon-loader",
	})
	loaderCtx = ContextWithCache(loaderCtx, c)

	// The sibling registers first (lower result ID, so the canonicalization
	// iterates it before the exact result) and holds its attachment open.
	attachFailure := errors.New("cache-test sibling attachment failure")
	sibling := &cacheTestBlockingAttachObj{
		Value:         1,
		attachErr:     attachFailure,
		attachStarted: make(chan struct{}),
		attachRelease: make(chan struct{}),
	}
	siblingFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestBlockingAttachObj{}).Type()),
		Field: "canon-sibling",
	}
	type callOutcome struct {
		res AnyResult
		err error
	}
	siblingDone := make(chan callOutcome, 1)
	go func() {
		res, err := c.GetOrInitCall(aCtx, "canon-a", srv, &CallRequest{ResultCall: siblingFrame}, func(ctx context.Context) (AnyResult, error) {
			res, err := NewResultForCall(sibling, siblingFrame)
			if err != nil {
				return nil, err
			}
			return res.WithContentDigest(ctx, contentDig)
		})
		siblingDone <- callOutcome{res: res, err: err}
	}()
	<-sibling.attachStarted
	siblingID := sharedResultID(sibling.selfID)
	assert.Assert(t, siblingID != 0)

	// The exact result shares the sibling's content digest and settles
	// cleanly. It cannot adopt the sibling at publication because adoption
	// already requires clean attachment.
	exactFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "canon-exact",
	}
	exactRes, err := c.GetOrInitCall(aCtx, "canon-a", srv, &CallRequest{ResultCall: exactFrame}, func(ctx context.Context) (AnyResult, error) {
		res, err := NewResultForCall(&cacheTestObject{Value: 2}, exactFrame)
		if err != nil {
			return nil, err
		}
		return res.WithContentDigest(ctx, contentDig)
	})
	assert.NilError(t, err)
	exactShared := exactRes.cacheSharedResult()
	assert.Assert(t, exactShared != nil && exactShared.id != 0)
	assert.Assert(t, siblingID < exactShared.id, "sibling must sort before the exact result")

	// While the sibling's attachment is still open, an ID load of the exact
	// result must not be redirected onto the sibling's barrier: it must be
	// served from the settled exact result immediately.
	loaded, err := c.LoadResultByResultID(loaderCtx, "canon-loader", srv, uint64(exactShared.id))
	assert.NilError(t, err)
	loadedShared := loaded.cacheSharedResult()
	assert.Assert(t, loadedShared != nil)
	assert.Equal(t, exactShared.id, loadedShared.id,
		"ID load must resolve to the exact result, not an unclean canonical sibling")

	// Cleanup: fail the sibling's attachment and collect its call error.
	close(sibling.attachRelease)
	siblingOut := <-siblingDone
	assert.ErrorContains(t, siblingOut.err, attachFailure.Error())

	assert.NilError(t, c.ReleaseSession(aCtx, "canon-a"))
	assert.NilError(t, c.ReleaseSession(loaderCtx, "canon-loader"))
}

func TestCacheDigestLookupRechecksSessionResourcesAfterAttachBarrier(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	srv := cacheTestServer(t)
	handle := cacheTestVolatileSessionResourceHandle("DIGEST_GROWTH")

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "diggrow-a-client",
		SessionID: "diggrow-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "diggrow-b-client",
		SessionID: "diggrow-b",
	})
	bCtx = ContextWithCache(bCtx, c)
	assert.NilError(t, c.BindSessionResource(aCtx, "diggrow-a", "diggrow-a-client", handle, "bound"))

	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestBlockingAttachObj{}).Type()),
		Field: "digest-growth-parent",
	}
	obj := &cacheTestBlockingAttachObj{
		Value:         1,
		attachStarted: make(chan struct{}),
		attachRelease: make(chan struct{}),
	}

	type callOutcome struct {
		res AnyResult
		hit bool
		err error
	}
	aDone := make(chan error, 1)
	go func() {
		_, err := c.GetOrInitCall(aCtx, "diggrow-a", srv, &CallRequest{ResultCall: frame}, func(ctx context.Context) (AnyResult, error) {
			leaf, err := cacheTestSessionResourceLeaf(ctx, handle)
			if err != nil {
				return nil, err
			}
			obj.leaf = leaf
			res, err := NewResultForCall(obj, frame)
			if err != nil {
				return nil, err
			}
			return res, nil
		})
		aDone <- err
	}()

	<-obj.attachStarted
	parentID := sharedResultID(obj.selfID)
	assert.Assert(t, parentID != 0)

	bDone := make(chan callOutcome, 1)
	go func() {
		res, hit, err := c.lookupCacheForDigests(bCtx, "diggrow-b", srv, cacheTestCallDigest(frame), nil)
		bDone <- callOutcome{res: res, hit: hit, err: err}
	}()

	deadline := time.Now().Add(10 * time.Second)
	for {
		c.sessionMu.Lock()
		_, selected := c.sessionResultIDsBySession["diggrow-b"][parentID]
		c.sessionMu.Unlock()
		if selected {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("timed out waiting for session B's digest lookup to select the still-attaching parent")
		}
		time.Sleep(time.Millisecond)
	}

	close(obj.attachRelease)
	assert.NilError(t, <-aDone)

	bOut := <-bDone
	assert.NilError(t, bOut.err)
	assert.Assert(t, !bOut.hit,
		"the digest lookup must convert the stale hit into a miss after the required set grew")
	assert.Assert(t, bOut.res == nil)

	assertCacheRequiredSessionResourcesExact(t, c)
	assert.NilError(t, c.ReleaseSession(aCtx, "diggrow-a"))
	assert.NilError(t, c.ReleaseSession(bCtx, "diggrow-b"))
}

// cacheTestLateGrowthFixture publishes a settled parent result and an
// attached requirement-carrying dep for session A (which binds the handle),
// and installs the serve re-validation hook so a test can park one serve of
// the parent between its selection critical section and its serve-time
// re-check. Callers land the late retention edge while the serve is parked.
type cacheTestLateGrowthFixture struct {
	cache       *Cache
	srv         *Server
	handle      SessionResourceHandle
	frame       *ResultCall
	parent      AnyResult
	parentID    sharedResultID
	dep         AnyResult
	aCtx        context.Context
	bCtx        context.Context
	hookReached chan struct{}
	hookRelease chan struct{}
}

func newCacheTestLateGrowthFixture(t *testing.T, slot string) *cacheTestLateGrowthFixture {
	t.Helper()
	baseCtx := t.Context()
	c, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	srv := cacheTestServer(t)
	handle := cacheTestVolatileSessionResourceHandle(slot)

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  slot + "-a-client",
		SessionID: slot + "-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  slot + "-b-client",
		SessionID: slot + "-b",
	})
	bCtx = ContextWithCache(bCtx, c)
	assert.NilError(t, c.BindSessionResource(aCtx, slot+"-a", slot+"-a-client", handle, "bound"))

	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: slot + "-parent",
	}
	parent, err := c.GetOrInitCall(aCtx, slot+"-a", srv, &CallRequest{ResultCall: frame}, func(ctx context.Context) (AnyResult, error) {
		return NewResultForCall(&cacheTestObject{Value: 1}, frame)
	})
	assert.NilError(t, err)
	parentShared := parent.cacheSharedResult()
	assert.Assert(t, parentShared != nil && parentShared.id != 0)

	leaf, err := cacheTestSessionResourceLeaf(aCtx, handle)
	assert.NilError(t, err)
	dep, err := c.AttachResult(aCtx, slot+"-a", srv, leaf)
	assert.NilError(t, err)
	depShared := dep.cacheSharedResult()
	assert.Assert(t, depShared != nil && depShared.id != 0)

	f := &cacheTestLateGrowthFixture{
		cache:       c,
		srv:         srv,
		handle:      handle,
		frame:       frame,
		parent:      parent,
		parentID:    parentShared.id,
		dep:         dep,
		aCtx:        aCtx,
		bCtx:        bCtx,
		hookReached: make(chan struct{}),
		hookRelease: make(chan struct{}),
	}
	var hookOnce sync.Once
	c.testBeforeServeRequirementRecheck = func(res *sharedResult) {
		if res.id != f.parentID {
			return
		}
		hookOnce.Do(func() {
			close(f.hookReached)
			<-f.hookRelease
		})
	}
	return f
}

// landLateDep waits for a serve of the parent to park at the re-validation
// hook, lands the requirement-carrying retention edge, and unparks the
// serve. The parked serve captured its requirement generation before the
// growth, so the re-validation must run the full locked re-check.
func (f *cacheTestLateGrowthFixture) landLateDep(t *testing.T) {
	t.Helper()
	select {
	case <-f.hookReached:
	case <-time.After(10 * time.Second):
		t.Fatal("timed out waiting for the parked serve to reach the re-validation hook")
	}
	assert.NilError(t, f.cache.AddExplicitDependency(f.aCtx, f.parent, f.dep, "test_late_dep"))
	close(f.hookRelease)
}

func (f *cacheTestLateGrowthFixture) assertParentRequiresHandle(t *testing.T) {
	t.Helper()
	parentShared := f.parent.cacheSharedResult()
	f.cache.egraphMu.RLock()
	parentRequires := cacheTestSessionResourceSetContains(parentShared.requiredSessionResources, f.handle)
	f.cache.egraphMu.RUnlock()
	assert.Assert(t, parentRequires)
	assertCacheRequiredSessionResourcesExact(t, f.cache)
}

func (f *cacheTestLateGrowthFixture) releaseSessions(t *testing.T, slot string) {
	t.Helper()
	assert.NilError(t, f.cache.ReleaseSession(f.aCtx, slot+"-a"))
	assert.NilError(t, f.cache.ReleaseSession(f.bCtx, slot+"-b"))
}

func TestCacheHitRechecksSessionResourcesAfterLateExplicitDependency(t *testing.T) {
	t.Parallel()

	const slot = "lategrowhit"
	f := newCacheTestLateGrowthFixture(t, slot)

	type callOutcome struct {
		res AnyResult
		err error
	}
	var bInitCalls atomic.Int32
	bDone := make(chan callOutcome, 1)
	go func() {
		res, err := f.cache.GetOrInitCall(f.bCtx, slot+"-b", f.srv, &CallRequest{ResultCall: f.frame.clone()}, func(ctx context.Context) (AnyResult, error) {
			bInitCalls.Add(1)
			return NewResultForCall(&cacheTestObject{Value: 99}, f.frame.clone())
		})
		bDone <- callOutcome{res: res, err: err}
	}()

	// B's lookup selects the settled parent while its required set is still
	// empty and parks at the re-validation hook; the retention edge then
	// grows the set before the serve resumes.
	f.landLateDep(t)

	bOut := <-bDone
	assert.NilError(t, bOut.err)
	assert.Equal(t, int32(1), bInitCalls.Load(),
		"session B must fall through to the singleflight instead of being served the grown result")
	bShared := bOut.res.cacheSharedResult()
	assert.Assert(t, bShared != nil && bShared.id != 0)
	assert.Assert(t, bShared.id != f.parentID,
		"session B was served a result requiring a handle it never bound")

	f.assertParentRequiresHandle(t)
	f.releaseSessions(t, slot)
}

func TestCacheLoadResultByResultIDRechecksAfterLateExplicitDependency(t *testing.T) {
	t.Parallel()

	const slot = "lategrowload"
	f := newCacheTestLateGrowthFixture(t, slot)

	type callOutcome struct {
		res AnyResult
		err error
	}
	bDone := make(chan callOutcome, 1)
	go func() {
		res, err := f.cache.LoadResultByResultID(f.bCtx, slot+"-b", f.srv, uint64(f.parentID))
		bDone <- callOutcome{res: res, err: err}
	}()

	// The requirement pre-check in sharedResultByResultID passes while the
	// required set is still empty; the load parks at the re-validation hook
	// and the retention edge grows the set before the serve resumes.
	f.landLateDep(t)

	bOut := <-bDone
	assert.Assert(t, bOut.err != nil,
		"session B's load must be refused once the required set grew past its bound set")
	assert.ErrorContains(t, bOut.err, "has not bound the session resources this result requires")

	f.assertParentRequiresHandle(t)
	f.releaseSessions(t, slot)
}

func TestCacheDigestLookupRechecksSessionResourcesAfterLateExplicitDependency(t *testing.T) {
	t.Parallel()

	const slot = "lategrowdig"
	f := newCacheTestLateGrowthFixture(t, slot)

	type callOutcome struct {
		res AnyResult
		hit bool
		err error
	}
	bDone := make(chan callOutcome, 1)
	go func() {
		res, hit, err := f.cache.lookupCacheForDigests(f.bCtx, slot+"-b", f.srv, cacheTestCallDigest(f.frame), nil)
		bDone <- callOutcome{res: res, hit: hit, err: err}
	}()

	f.landLateDep(t)

	bOut := <-bDone
	assert.NilError(t, bOut.err)
	assert.Assert(t, !bOut.hit,
		"the digest lookup must convert the stale hit into a miss after the required set grew")
	assert.Assert(t, bOut.res == nil)

	f.assertParentRequiresHandle(t)
	f.releaseSessions(t, slot)
}

// cacheTestProducerReleaseWindow drives session A's publication into the
// producer-release window: A's call publishes a result whose dependency
// attachment is parked (cacheTestBlockingAttachObj holding a plain child),
// the test waits for session B's serve to select the result and park at the
// attach barrier, releases session A, and then unparks the attachment,
// whose child claim is refused because A is released. The returned outcome
// channel carries A's call error.
type cacheTestProducerReleaseWindow struct {
	cache    *Cache
	srv      *Server
	frame    *ResultCall
	obj      *cacheTestBlockingAttachObj
	parentID sharedResultID
	aCtx     context.Context
	bCtx     context.Context
	aDone    chan error
}

func newCacheTestProducerReleaseWindow(t *testing.T, slot string) *cacheTestProducerReleaseWindow {
	t.Helper()
	baseCtx := t.Context()
	c, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	srv := cacheTestServer(t)

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  slot + "-a-client",
		SessionID: slot + "-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  slot + "-b-client",
		SessionID: slot + "-b",
	})
	bCtx = ContextWithCache(bCtx, c)

	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestBlockingAttachObj{}).Type()),
		Field: slot + "-parent",
	}
	child, err := NewResultForCall(NewString("child-value"), &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType(NewString("").Type()),
		Field: slot + "-child",
	})
	assert.NilError(t, err)
	obj := &cacheTestBlockingAttachObj{
		Value:         1,
		leaf:          child,
		attachStarted: make(chan struct{}),
		attachRelease: make(chan struct{}),
	}

	w := &cacheTestProducerReleaseWindow{
		cache: c, srv: srv, frame: frame, obj: obj,
		aCtx: aCtx, bCtx: bCtx,
		aDone: make(chan error, 1),
	}
	go func() {
		_, err := c.GetOrInitCall(aCtx, slot+"-a", srv, &CallRequest{ResultCall: frame}, func(ctx context.Context) (AnyResult, error) {
			return NewResultForCall(obj, frame)
		})
		w.aDone <- err
	}()
	<-obj.attachStarted
	w.parentID = sharedResultID(obj.selfID)
	assert.Assert(t, w.parentID != 0)
	return w
}

// releaseProducerAndUnpark waits for session B to have selected the parked
// parent (the recorded session edge proves the selection), releases session
// A while attachment is still parked, and then unparks the attachment so
// its child claim runs against the released session.
func (w *cacheTestProducerReleaseWindow) releaseProducerAndUnpark(t *testing.T, slot string) {
	t.Helper()
	deadline := time.Now().Add(10 * time.Second)
	for {
		w.cache.sessionMu.Lock()
		_, selected := w.cache.sessionResultIDsBySession[slot+"-b"][w.parentID]
		w.cache.sessionMu.Unlock()
		if selected {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("timed out waiting for session B to select the still-attaching parent")
		}
		time.Sleep(time.Millisecond)
	}
	assert.NilError(t, w.cache.ReleaseSession(w.aCtx, slot+"-a"))
	close(w.obj.attachRelease)
}

// assertProducerKeptAttachmentError asserts session A's own call failed with
// the claim refusal and that the classified barrier form did not leak into
// the producer's error.
func (w *cacheTestProducerReleaseWindow) assertProducerKeptAttachmentError(t *testing.T) {
	t.Helper()
	aErr := <-w.aDone
	assert.Assert(t, aErr != nil, "the producing session's call must fail with the attachment error")
	assert.Assert(t, errors.Is(aErr, ErrCacheSessionReleased))
	assert.Assert(t, !errors.Is(aErr, errAttachRefusedByProducerRelease),
		"the classified barrier form must not replace the producer's own error")
}

func TestCacheHitConvertsToMissWhenProducerReleaseFailsAttachment(t *testing.T) {
	t.Parallel()

	const slot = "attrelhit"
	w := newCacheTestProducerReleaseWindow(t, slot)

	type callOutcome struct {
		res AnyResult
		err error
	}
	var bInitCalls atomic.Int32
	bDone := make(chan callOutcome, 1)
	go func() {
		res, err := w.cache.GetOrInitCall(w.bCtx, slot+"-b", w.srv, &CallRequest{ResultCall: w.frame.clone()}, func(ctx context.Context) (AnyResult, error) {
			bInitCalls.Add(1)
			return NewResultForCall(&cacheTestBlockingAttachObj{
				Value:         99,
				attachStarted: make(chan struct{}),
				attachRelease: func() chan struct{} { ch := make(chan struct{}); close(ch); return ch }(),
			}, w.frame.clone())
		})
		bDone <- callOutcome{res: res, err: err}
	}()

	w.releaseProducerAndUnpark(t, slot)
	w.assertProducerKeptAttachmentError(t)

	bOut := <-bDone
	assert.NilError(t, bOut.err,
		"an innocent parked reader must not surface the producer's release as its own failure")
	assert.Equal(t, int32(1), bInitCalls.Load(),
		"session B must fall through to the singleflight and execute its own call")
	bShared := bOut.res.cacheSharedResult()
	assert.Assert(t, bShared != nil && bShared.id != 0)
	assert.Assert(t, bShared.id != w.parentID)

	assert.NilError(t, w.cache.ReleaseSession(w.bCtx, slot+"-b"))
}

func TestCacheDigestLookupConvertsToMissWhenProducerReleaseFailsAttachment(t *testing.T) {
	t.Parallel()

	const slot = "attreldig"
	w := newCacheTestProducerReleaseWindow(t, slot)

	type callOutcome struct {
		res AnyResult
		hit bool
		err error
	}
	bDone := make(chan callOutcome, 1)
	go func() {
		res, hit, err := w.cache.lookupCacheForDigests(w.bCtx, slot+"-b", w.srv, cacheTestCallDigest(w.frame), nil)
		bDone <- callOutcome{res: res, hit: hit, err: err}
	}()

	w.releaseProducerAndUnpark(t, slot)
	w.assertProducerKeptAttachmentError(t)

	bOut := <-bDone
	assert.NilError(t, bOut.err)
	assert.Assert(t, !bOut.hit,
		"the digest lookup must convert the parked hit into a miss after the producer-release attachment failure")
	assert.Assert(t, bOut.res == nil)

	assert.NilError(t, w.cache.ReleaseSession(w.bCtx, slot+"-b"))
}

func TestCacheLoadResultByResultIDStillFailsWhenProducerReleaseFailsAttachment(t *testing.T) {
	t.Parallel()

	const slot = "attrelload"
	w := newCacheTestProducerReleaseWindow(t, slot)

	type callOutcome struct {
		res AnyResult
		err error
	}
	bDone := make(chan callOutcome, 1)
	go func() {
		res, err := w.cache.LoadResultByResultID(w.bCtx, slot+"-b", w.srv, uint64(w.parentID))
		bDone <- callOutcome{res: res, err: err}
	}()

	w.releaseProducerAndUnpark(t, slot)
	w.assertProducerKeptAttachmentError(t)

	// A by-ID load names one exact result and has no call to re-execute, so
	// it keeps propagating the attachment error; the classified form stays
	// visible in the chain for callers that want to distinguish it.
	bOut := <-bDone
	assert.Assert(t, bOut.err != nil)
	assert.Assert(t, errors.Is(bOut.err, errAttachRefusedByProducerRelease))

	assert.NilError(t, w.cache.ReleaseSession(w.bCtx, slot+"-b"))
}

func TestCacheHitKeepsGenuineAttachmentFailure(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	c, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	srv := cacheTestServer(t)

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "attrelctl-a-client",
		SessionID: "attrelctl-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "attrelctl-b-client",
		SessionID: "attrelctl-b",
	})
	bCtx = ContextWithCache(bCtx, c)

	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestBlockingAttachObj{}).Type()),
		Field: "attrelctl-parent",
	}
	genuineErr := errors.New("cache-test genuine attachment failure")
	obj := &cacheTestBlockingAttachObj{
		Value:         1,
		attachErr:     genuineErr,
		attachStarted: make(chan struct{}),
		attachRelease: make(chan struct{}),
	}

	aDone := make(chan error, 1)
	go func() {
		_, err := c.GetOrInitCall(aCtx, "attrelctl-a", srv, &CallRequest{ResultCall: frame}, func(ctx context.Context) (AnyResult, error) {
			return NewResultForCall(obj, frame)
		})
		aDone <- err
	}()
	<-obj.attachStarted
	parentID := sharedResultID(obj.selfID)
	assert.Assert(t, parentID != 0)

	type callOutcome struct {
		res AnyResult
		err error
	}
	var bInitCalls atomic.Int32
	bDone := make(chan callOutcome, 1)
	go func() {
		res, err := c.GetOrInitCall(bCtx, "attrelctl-b", srv, &CallRequest{ResultCall: frame.clone()}, func(ctx context.Context) (AnyResult, error) {
			bInitCalls.Add(1)
			return NewResultForCall(&cacheTestObject{Value: 99}, frame.clone())
		})
		bDone <- callOutcome{res: res, err: err}
	}()

	deadline := time.Now().Add(10 * time.Second)
	for {
		c.sessionMu.Lock()
		_, selected := c.sessionResultIDsBySession["attrelctl-b"][parentID]
		c.sessionMu.Unlock()
		if selected {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("timed out waiting for session B to select the still-attaching parent")
		}
		time.Sleep(time.Millisecond)
	}
	// Both sessions stay live: this failure is the attachment hook's own.
	close(obj.attachRelease)

	aErr := <-aDone
	assert.ErrorContains(t, aErr, genuineErr.Error())

	bOut := <-bDone
	assert.Assert(t, bOut.err != nil,
		"a genuine attachment failure must keep propagating to parked readers")
	assert.ErrorContains(t, bOut.err, genuineErr.Error())
	assert.Assert(t, !errors.Is(bOut.err, errAttachRefusedByProducerRelease))
	assert.Equal(t, int32(0), bInitCalls.Load(),
		"a genuine failure must not convert the reader to a miss")

	assert.NilError(t, c.ReleaseSession(aCtx, "attrelctl-a"))
	assert.NilError(t, c.ReleaseSession(bCtx, "attrelctl-b"))
}

func TestCachePublicationRollsBackWhenStructuralDepMissing(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	c, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	srv := cacheTestServer(t)

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "rollback-a-client",
		SessionID: "rollback-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "rollback-b-client",
		SessionID: "rollback-b",
	})
	bCtx = ContextWithCache(bCtx, c)

	// Session A publishes the result the failing structural ref will point
	// at; session B publishes the one whose partial dependency edge must be
	// unwound.
	deadFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "rollback-dead-ref",
	}
	deadRes, err := c.GetOrInitCall(aCtx, "rollback-a", srv, &CallRequest{ResultCall: deadFrame}, func(ctx context.Context) (AnyResult, error) {
		return NewResultForCall(&cacheTestObject{Value: 1}, deadFrame)
	})
	assert.NilError(t, err)
	deadShared := deadRes.cacheSharedResult()
	assert.Assert(t, deadShared != nil && deadShared.id != 0)

	liveFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "rollback-live-dep",
	}
	liveRes, err := c.GetOrInitCall(bCtx, "rollback-b", srv, &CallRequest{ResultCall: liveFrame}, func(ctx context.Context) (AnyResult, error) {
		return NewResultForCall(&cacheTestObject{Value: 2}, liveFrame)
	})
	assert.NilError(t, err)
	liveShared := liveRes.cacheSharedResult()
	assert.Assert(t, liveShared != nil && liveShared.id != 0)

	// The value's frame references the live dep first (receiver) and the
	// doomed one second (arg), so the publication adds the live dep's edge
	// before the missing-ref failure and the rollback must unwind it.
	valueFrame := &ResultCall{
		Kind:     ResultCallKindField,
		Type:     NewResultCallType((&cacheTestObject{}).Type()),
		Field:    "rollback-parent",
		Receiver: &ResultCallRef{ResultID: uint64(liveShared.id), shared: liveShared},
		Args: []*ResultCallArg{{
			Name: "doomed",
			Value: &ResultCallLiteral{
				Kind:      ResultCallLiteralKindResultRef,
				ResultRef: &ResultCallRef{ResultID: uint64(deadShared.id), shared: deadShared},
			},
		}},
	}
	reqFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "rollback-request",
	}

	// The doomed ref's target is collected inside the window between the
	// pre-lock digest derivations (which read the target's still-present
	// frame through the ref's fast-path pointer) and the indexing critical
	// section, where the dependency pass finds it missing.
	var (
		hookOnce      sync.Once
		resultsBefore int
		liveOwnBefore int64
	)
	c.testBeforePublicationIndex = func(oc *ongoingCall) {
		hookOnce.Do(func() {
			assert.NilError(t, c.ReleaseSession(aCtx, "rollback-a"))
			c.egraphMu.RLock()
			_, stillRegistered := c.resultsByID[deadShared.id]
			resultsBefore = len(c.resultsByID)
			liveOwnBefore = liveShared.incomingOwnershipCount
			c.egraphMu.RUnlock()
			assert.Assert(t, !stillRegistered, "the doomed ref's target must be collected before indexing")
		})
	}

	var initCalls atomic.Int32
	runOnce := func() error {
		_, err := c.GetOrInitCall(bCtx, "rollback-b", srv, &CallRequest{ResultCall: reqFrame.clone()}, func(ctx context.Context) (AnyResult, error) {
			initCalls.Add(1)
			return NewResultForCall(&cacheTestObject{Value: 3}, valueFrame.clone())
		})
		return err
	}

	err = runOnce()
	assert.Assert(t, err != nil, "the publication must fail loudly on the missing structural ref")
	assert.ErrorContains(t, err, "missing cached result")

	// The rollback must leave no trace of the partial publication: no new
	// registered record and the live dep's ownership back to its session
	// edge alone.
	c.egraphMu.RLock()
	resultsAfter := len(c.resultsByID)
	liveOwnAfter := liveShared.incomingOwnershipCount
	c.egraphMu.RUnlock()
	assert.Equal(t, resultsBefore, resultsAfter,
		"the failed publication must not leave a registered record behind")
	assert.Equal(t, liveOwnBefore, liveOwnAfter,
		"the partial dependency edge must be unwound")

	// A repeat of the same call must execute again - nothing selectable was
	// left behind to serve as a stale hit. It fails earlier than the first
	// attempt (the collected target's frame is gone, so the value's digest
	// derivation refuses the dead ref), but it fails loudly after
	// re-executing.
	err = runOnce()
	assert.Assert(t, err != nil)
	assert.Equal(t, int32(2), initCalls.Load(),
		"the repeated call must re-execute rather than hit a stranded record")

	assert.NilError(t, c.ReleaseSession(bCtx, "rollback-b"))
}

func TestCacheAttachmentClaimPinsTargetAgainstForeignRelease(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	c, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	srv := cacheTestServer(t)

	aCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "pin-a-client",
		SessionID: "pin-a",
	})
	aCtx = ContextWithCache(aCtx, c)
	bCtx := engine.ContextWithClientMetadata(baseCtx, &engine.ClientMetadata{
		ClientID:  "pin-b-client",
		SessionID: "pin-b",
	})
	bCtx = ContextWithCache(bCtx, c)

	// Session A publishes the child; session B claims it at acquisition, as
	// every production acquisition path does.
	childFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "pin-child",
	}
	child, err := c.GetOrInitCall(aCtx, "pin-a", srv, &CallRequest{ResultCall: childFrame}, func(ctx context.Context) (AnyResult, error) {
		return NewResultForCall(&cacheTestObject{Value: 7}, childFrame)
	})
	assert.NilError(t, err)
	childShared := child.cacheSharedResult()
	assert.Assert(t, childShared != nil && childShared.id != 0)
	childID := childShared.id
	bHeld, err := c.LoadResultByResultID(bCtx, "pin-b", srv, uint64(childID))
	assert.NilError(t, err)
	assert.Assert(t, bHeld.cacheSharedResult().id == childID)

	// B's publication embeds the child and parks mid-attachment; A releases
	// while it is parked. B's claim pins the child, so A's release must not
	// collect it and the attachment must complete against the original
	// record.
	parentFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestBlockingAttachObj{}).Type()),
		Field: "pin-parent",
	}
	obj := &cacheTestBlockingAttachObj{
		Value:         1,
		leaf:          child,
		attachStarted: make(chan struct{}),
		attachRelease: make(chan struct{}),
	}
	bDone := make(chan error, 1)
	var bRes AnyResult
	go func() {
		res, err := c.GetOrInitCall(bCtx, "pin-b", srv, &CallRequest{ResultCall: parentFrame}, func(ctx context.Context) (AnyResult, error) {
			return NewResultForCall(obj, parentFrame)
		})
		bRes = res
		bDone <- err
	}()
	<-obj.attachStarted
	assert.NilError(t, c.ReleaseSession(aCtx, "pin-a"))

	c.egraphMu.RLock()
	_, stillRegistered := c.resultsByID[childID]
	c.egraphMu.RUnlock()
	assert.Assert(t, stillRegistered, "session B's claim must pin the child across session A's release")

	close(obj.attachRelease)
	assert.NilError(t, <-bDone)
	bShared := bRes.cacheSharedResult()
	assert.Assert(t, bShared != nil && bShared.id != 0)
	c.egraphMu.RLock()
	_, childRetained := bShared.deps[childID]
	c.egraphMu.RUnlock()
	assert.Assert(t, childRetained, "the attachment must retain the original pinned child")

	assert.NilError(t, c.ReleaseSession(bCtx, "pin-b"))
}

func TestCacheWithSessionResourceHandleRefusesAttachedMutation(t *testing.T) {
	t.Parallel()

	baseCtx := t.Context()
	cacheIface, err := NewCache(baseCtx, "", nil, nil)
	assert.NilError(t, err)
	c := cacheIface
	ctx := ContextWithCache(cacheTestContext(baseCtx), c)
	srv := cacheTestServer(t)
	handle := cacheTestVolatileSessionResourceHandle("ATTACHED_MUTATION")

	frame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "attached-mutation-target",
	}
	res, err := c.GetOrInitCall(ctx, "test-session", srv, &CallRequest{ResultCall: frame}, func(ctx context.Context) (AnyResult, error) {
		return NewResultForCall(&cacheTestObject{Value: 1}, frame)
	})
	assert.NilError(t, err)
	shared := res.cacheSharedResult()
	assert.Assert(t, shared != nil && shared.id != 0)

	stamper, ok := res.(interface {
		WithSessionResourceHandleAny(context.Context, SessionResourceHandle) (AnyResult, error)
	})
	assert.Assert(t, ok, "result %T does not support session resource handles", res)

	// A semantic handle change on an attached result must be refused and
	// must leave the stored requirement set untouched.
	_, err = stamper.WithSessionResourceHandleAny(ctx, handle)
	assert.ErrorContains(t, err, "already attached; its session-resource handle cannot change")

	c.egraphMu.RLock()
	stillEmpty := shared.requiredSessionResources == nil || shared.requiredSessionResources.Empty()
	unchangedHandle := shared.sessionResourceHandle == ""
	c.egraphMu.RUnlock()
	assert.Assert(t, stillEmpty, "refused mutation must not grow the stored requirement set")
	assert.Assert(t, unchangedHandle)
	assertCacheRequiredSessionResourcesExact(t, c)

	// The identical value is a no-op: stamp a detached leaf, attach it, and
	// re-apply the same handle.
	leafFrame := &ResultCall{
		Kind:  ResultCallKindField,
		Type:  NewResultCallType((&cacheTestObject{}).Type()),
		Field: "attached-mutation-leaf",
	}
	leafRes, err := c.GetOrInitCall(ctx, "test-session", srv, &CallRequest{ResultCall: leafFrame}, func(ctx context.Context) (AnyResult, error) {
		res, err := NewResultForCall(&cacheTestObject{Value: 2}, leafFrame)
		if err != nil {
			return nil, err
		}
		return res.WithSessionResourceHandle(ctx, handle)
	})
	assert.NilError(t, err)
	leafStamper, ok := leafRes.(interface {
		WithSessionResourceHandleAny(context.Context, SessionResourceHandle) (AnyResult, error)
	})
	assert.Assert(t, ok, "result %T does not support session resource handles", leafRes)
	same, err := leafStamper.WithSessionResourceHandleAny(ctx, handle)
	assert.NilError(t, err)
	assert.Equal(t, leafRes.cacheSharedResult().id, same.cacheSharedResult().id)

	cacheTestReleaseSession(t, c, ctx)

	// The release collected the leaf (its only owner released), so even the
	// identical re-stamp must report the collection: the registration guard
	// still runs before the no-op.
	_, err = leafStamper.WithSessionResourceHandleAny(ctx, handle)
	assert.ErrorContains(t, err, "was already collected")
}
