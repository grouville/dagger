package dagql

import (
	"fmt"
	"testing"
)

var cacheIDSetBenchmarkSink any
var cacheIDSumBenchmarkSink sharedResultID

func BenchmarkCacheIDSet(b *testing.B) {
	for _, count := range []int{0, 1, 2, 8, 128} {
		b.Run(fmt.Sprint(count), func(b *testing.B) {
			b.Run("build", func(b *testing.B) {
				b.ReportAllocs()
				for range b.N {
					ids := newSharedResultIDSet()
					for i := range count {
						ids.Insert(sharedResultID(i))
					}
					cacheIDSetBenchmarkSink = ids
				}
			})
			b.Run("read", func(b *testing.B) {
				ids := newSharedResultIDSet()
				for i := range count {
					ids.Insert(sharedResultID(i))
				}
				b.ReportAllocs()
				b.ResetTimer()
				var sum sharedResultID
				for range b.N {
					for id := range ids.Items() {
						sum += id
					}
				}
				cacheIDSumBenchmarkSink = sum
			})
		})
	}
	b.Run("alternate-1-2", func(b *testing.B) {
		ids := newSharedResultIDSet()
		ids.Insert(0)
		ids.Insert(1)
		b.ReportAllocs()
		b.ResetTimer()
		for range b.N {
			ids.Remove(1)
			ids.Insert(1)
		}
		cacheIDSetBenchmarkSink = ids
	})
}
