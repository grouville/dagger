package dagql

import (
	"cmp"
	"math/rand/v2"
	"slices"
	"testing"

	set "github.com/hashicorp/go-set/v3"
	"gotest.tools/v3/assert"
)

func TestCacheIDSetMatchesTreeSet(t *testing.T) {
	actual := newSharedResultIDSet()
	expected := set.NewTreeSet(cmp.Compare[sharedResultID])
	check := func() {
		t.Helper()
		assert.Equal(t, actual.Empty(), expected.Empty())
		assert.Equal(t, actual.Size(), expected.Size())
		assert.DeepEqual(t, slices.Collect(actual.Items()), slices.Collect(expected.Items()))
		for id := range sharedResultID(65) {
			assert.Equal(t, actual.Contains(id), expected.Contains(id))
		}
		// Breaking after one item must stop iteration and keep the set intact.
		for first := range actual.Items() {
			assert.Equal(t, first, slices.Collect(expected.Items())[0])
			break
		}
	}
	check()
	for _, id := range []sharedResultID{0, 0, 4, 2, 1, 64, 63} {
		assert.Equal(t, actual.Insert(id), expected.Insert(id))
		check()
	}
	for _, id := range []sharedResultID{4, 4, 64, 2, 1, 63, 0} {
		assert.Equal(t, actual.Remove(id), expected.Remove(id))
		check()
	}
	random := rand.New(rand.NewPCG(19, 71))
	for range 2000 {
		id := sharedResultID(random.Uint64N(65))
		if random.UintN(3) == 0 {
			assert.Equal(t, actual.Remove(id), expected.Remove(id))
		} else {
			assert.Equal(t, actual.Insert(id), expected.Insert(id))
		}
		check()
	}
	for id := range sharedResultID(65) {
		assert.Equal(t, actual.Remove(id), expected.Remove(id))
		check()
	}
}
