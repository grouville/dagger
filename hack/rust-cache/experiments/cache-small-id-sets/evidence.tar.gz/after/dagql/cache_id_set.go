package dagql

import (
	"cmp"
	"iter"

	set "github.com/hashicorp/go-set/v3"
)

// cacheIDSet keeps the first ID inline and allocates a tree only when a
// second distinct ID is inserted. Iteration retains the tree's sorted order.
// After promotion, removal uses the tree normally; it frees removed nodes
// without repeatedly rebuilding the tree when membership alternates at one.
type cacheIDSet[T ~uint64] struct {
	first   T
	present bool
	tree    *set.TreeSet[T]
}

func (s *cacheIDSet[T]) Insert(id T) bool {
	if s.tree != nil {
		return s.tree.Insert(id)
	}
	if !s.present {
		s.first, s.present = id, true
		return true
	}
	if s.first == id {
		return false
	}
	s.tree = set.NewTreeSet(cmp.Compare[T])
	s.tree.Insert(s.first)
	s.tree.Insert(id)
	s.present = false
	s.first = 0
	return true
}

func (s *cacheIDSet[T]) Remove(id T) bool {
	if s.tree != nil {
		return s.tree.Remove(id)
	}
	if !s.present || s.first != id {
		return false
	}
	s.first, s.present = 0, false
	return true
}

func (s *cacheIDSet[T]) Contains(id T) bool {
	if s.tree != nil {
		return s.tree.Contains(id)
	}
	return s.present && s.first == id
}

func (s *cacheIDSet[T]) Size() int {
	if s.tree != nil {
		return s.tree.Size()
	}
	if s.present {
		return 1
	}
	return 0
}

func (s *cacheIDSet[T]) Empty() bool {
	return s.Size() == 0
}

func (s *cacheIDSet[T]) Items() iter.Seq[T] {
	return func(yield func(T) bool) {
		if s.tree != nil {
			s.tree.Items()(yield)
		} else if s.present {
			yield(s.first)
		}
	}
}
