from pathlib import Path
import json
import os
import subprocess
import time

root = '/tmp/dagger-native-telemetry-storage'
out = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8')
steps = [
    ('remaining-server-readers', ['-race', '-run=^Test(TracesHandlerToleratesMissingResource|CloudPublishedRow)$', './engine/server']),
    ('inspection-readers', ['-race', '-run=^Test(CallPayloadRecordsExcludedFromLLMLogs|CaptureLogLinesIsolatesProducers|InternalSpanFilterSubtreeBounds|ReadLogs|RenderReadLogs|LoadTrace|ImportedTraceCannotOverrideLive)', './core']),
]
rows = []
for label, flags in steps:
    command = [go, 'test', '-p=2', '-count=1', '-timeout=240s', *flags]
    start = time.monotonic()
    with (out / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic()-start)
    rows.append(row)
    (out / 'reader-validation.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, (out / (label + '.log')).read_text()[-4000:]

for index in range(4):
    order = ['JSON', 'native'] if index % 2 == 0 else ['native', 'JSON']
    for arm in order:
        label = f'component-{index+1}-{arm}'
        command = [go, 'test', '-p=2', '-run=^$', '-bench=^BenchmarkStoredProtoAttributes$/^'+arm+'$/', '-benchtime=250ms', '-count=1', './engine/clientdb']
        start = time.monotonic()
        with (out / (label+'.log')).open('w') as log:
            result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic()-start)
        rows.append(row)
        (out / 'reader-validation.json').write_text(json.dumps(rows, indent=2)+'\n')
        print(json.dumps(row), flush=True)
        assert result.returncode == 0, (out / (label+'.log')).read_text()[-4000:]
