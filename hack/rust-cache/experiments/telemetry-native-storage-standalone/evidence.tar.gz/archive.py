from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

study = Path(__file__).parent
work = Path('/tmp/dagger-native-telemetry-storage')
dest = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/telemetry-native-storage-standalone')
base = 'ff0b029a4d270a651b9a8c7286babc79089066e4'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=work)

for name in ('validation.json', 'reader-validation.json'):
    rows = json.loads((study / name).read_text())
    assert rows and all(row['exit_code'] == row.get('expected_exit_code', 0) for row in rows)
assert len(json.loads((study / 'reader-validation.json').read_text())) == 10
assert not git('status', '--porcelain').strip(), 'Commit the final patch before archiving'
commit = git('rev-parse', 'HEAD').decode().strip()
paths = git('diff', '--name-only', base, 'HEAD').decode().splitlines()
context = study / 'source-context'
for path in paths:
    for version, data in (('after', (work / path).read_bytes()),):
        target = context / version / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    old = subprocess.run(['git', 'show', base+':'+path], cwd=work, capture_output=True)
    if old.returncode == 0:
        target = context / 'before' / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(old.stdout)
(study / 'standalone.patch').write_bytes(git('diff', base, 'HEAD'))
(study / 'review.json').write_text(json.dumps(dict(base=base, commit=commit,
    branch='perf/native-telemetry-storage', files=paths,
    migration='Recover v1, write and sync v2 header before permitting native appends',
    benchmark_scope='Component checks on main plus patch. Full-command cohorts used the controlled engine documented in NATIVE_TELEMETRY_STORAGE.md.',
    engine_replaced=False, pr_opened=False), indent=2)+'\n')
dest.mkdir(parents=True, exist_ok=True)
archive = dest / 'evidence.tar.gz'
members = []
with tarfile.open(archive, 'w:gz', compresslevel=6) as out:
    for source in sorted(study.rglob('*')):
        if not source.is_file() or '__pycache__' in source.parts:
            continue
        data = source.read_bytes()
        name = source.relative_to(study).as_posix()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        out.addfile(info, io.BytesIO(data))
        members.append(dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(archive, 'r:gz') as inp:
    for record in members:
        data = inp.extractfile(record['path']).read()
        assert len(data) == record['size']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
manifest = dict(base=base, commit=commit, archive=archive.name,
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=members)
(dest / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(commit=commit, files=len(paths), members=len(members), archive_bytes=archive.stat().st_size)))
