package server

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
	"unicode/utf8"

	"github.com/dagger/dagger/analytics"
	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/core/gitref"
	"github.com/dagger/dagger/core/modules"
	"github.com/dagger/dagger/core/workspace"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call/callpbv1"
	"github.com/dagger/dagger/engine"
	"github.com/dagger/dagger/engine/clientdb"
	"github.com/dagger/dagger/engine/engineutil"
	enginetel "github.com/dagger/dagger/engine/telemetry"
	"github.com/dagger/dagger/engine/telemetryattrs"
	controlapi "github.com/dagger/dagger/internal/buildkit/api/services/control"
	bkgw "github.com/dagger/dagger/internal/buildkit/frontend/gateway/client"
	"github.com/dagger/dagger/internal/buildkit/util/flightcontrol"
	telemetry "github.com/dagger/otel-go"
	"github.com/opencontainers/go-digest"
	"github.com/stretchr/testify/require"
	"github.com/vito/go-sse/sse"
	"go.opentelemetry.io/otel/attribute"
	otellog "go.opentelemetry.io/otel/log"
	sdklog "go.opentelemetry.io/otel/sdk/log"
	sdkmetric "go.opentelemetry.io/otel/sdk/metric"
	"go.opentelemetry.io/otel/sdk/metric/metricdata"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/trace"
	collogspb "go.opentelemetry.io/proto/otlp/collector/logs/v1"
	otlpcommonv1 "go.opentelemetry.io/proto/otlp/common/v1"
	otlplogsv1 "go.opentelemetry.io/proto/otlp/logs/v1"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

func installTestClientRecords(sess *daggerSession) {
	if sess.clientRecords == nil {
		sess.clientRecords = make(map[string]*clientRecord, len(sess.clientRuntimes))
	}
	for id, runtime := range sess.clientRuntimes {
		if runtime == nil || runtime.clientRecord == nil {
			continue
		}
		runtime.daggerSession = sess
		sess.clientRecords[id] = runtime.clientRecord
	}
}

func newNestedTransportTestFixture(t *testing.T) (*Server, *daggerSession, *clientRuntime, context.Context, engine.ClientScope) {
	t.Helper()
	parent := &clientRuntime{clientRecord: &clientRecord{
		clientID:       "parent",
		clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "parent", ClientSecretToken: "parent-token"},
		metadataSealed: true,
		accepting:      true},
		state:           clientStateInitialized,
		lifecycleLeases: make(map[uint64]clientLifecycleLeaseRecord)}
	sess := &daggerSession{
		sessionID:          "session",
		mainClientCallerID: parent.clientID,
		clientRuntimes:     map[string]*clientRuntime{parent.clientID: parent},
	}
	parent.daggerSession = sess
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)
	transport, err := sess.acquireRootClientScope(parent, engine.ClientLeaseTransport, "parent")
	require.NoError(t, err)
	parent.transportLease = transport.Lease()
	requestScope, err := sess.acquireRootClientScope(parent, engine.ClientLeaseRequest, "POST /query")
	require.NoError(t, err)
	ctx, err := engine.ContextWithClientScope(context.Background(), requestScope)
	require.NoError(t, err)
	return &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}, sess, parent, ctx, requestScope
}

func nestedTransportTestMetadata(clientID string) *engine.ClientMetadata {
	return &engine.ClientMetadata{
		SessionID:         "session",
		ClientID:          clientID,
		ClientSecretToken: clientID + "-token",
		ClientVersion:     engine.Version,
	}
}

func mergeClientMetadataForTest(sess *daggerSession, client *clientRuntime, metadata *engine.ClientMetadata) error {
	sess.scopeMu.Lock()
	defer sess.scopeMu.Unlock()
	return sess.mergeClientMetadataLocked(client.clientRecord, metadata)
}

func sealClientMetadataForTest(sess *daggerSession, client *clientRuntime) error {
	sess.scopeMu.Lock()
	defer sess.scopeMu.Unlock()
	return sess.sealClientMetadataLocked(client.clientRecord)
}

func TestNestedTransportRegistrationIsStrictUniqueAndPermanent(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	metadata := nestedTransportTestMetadata("child")

	transport, err := srv.RegisterNestedClientTransport(ctx, metadata, parent.clientID)
	require.NoError(t, err)
	sess.clientMu.RLock()
	child := sess.clientRuntimes[metadata.ClientID]
	sess.clientMu.RUnlock()
	require.NotNil(t, child)
	require.Equal(t, clientStateUninitialized, child.state)
	require.Equal(t, []string{parent.clientID}, child.parentClientIDs)
	require.Same(t, transport, child.nestedTransport)

	_, err = srv.RegisterNestedClientTransport(ctx, metadata, parent.clientID)
	require.ErrorContains(t, err, "already registered")

	transport.Close()
	transport.Close()
	require.True(t, transport.Closed())
	accepting, _, childLeases := sess.clientLifecycleSnapshot(child)
	require.False(t, accepting)
	require.Empty(t, childLeases, "double close must release transport ownership exactly once")
	require.Equal(t, clientStateReclaimed, child.state)
	sess.clientMu.RLock()
	_, runtimeRetained := sess.clientRuntimes[metadata.ClientID]
	_, recordRetained := sess.clientRecords[metadata.ClientID]
	sess.clientMu.RUnlock()
	require.False(t, runtimeRetained, "idle close must reclaim the child runtime")
	require.True(t, recordRetained, "quiescence must keep the session-long identity record")
	debug := srv.ClientLifecycleDebugSnapshot()
	require.Equal(t, 2, debug.Records)
	require.Equal(t, 1, debug.Runtimes)
	require.Equal(t, "quiescent", debug.Sessions[0].Clients[0].RuntimeState)
	require.NotNil(t, debug.Sessions[0].Clients[0].ClosedAt)
	require.NotNil(t, debug.Sessions[0].Clients[0].QuiescentAt)

	_, err = srv.RegisterNestedClientTransport(ctx, metadata, parent.clientID)
	require.ErrorContains(t, err, "permanently closed")

	recorder := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, engine.QueryEndpoint, strings.NewReader(`{"query":"{version}"}`))
	srv.ServeHTTPToNestedClient(recorder, req, transport, metadata, parent.clientID, false, nil, nil)
	require.Equal(t, http.StatusGone, recorder.Code)
	require.Equal(t, clientStateReclaimed, child.state, "close before first request must leave a permanent record tombstone")

	telemetryRecorder := httptest.NewRecorder()
	srv.ServeHTTPToNestedClient(
		telemetryRecorder,
		httptest.NewRequest(http.MethodGet, "/v1/traces", nil),
		transport,
		metadata,
		parent.clientID,
		false,
		nil,
		nil,
	)
	require.Equal(t, http.StatusGone, telemetryRecorder.Code, "a terminal transport must not make SSE clients retry")

	// The child's serialized quiescent transition releases the exact child edge
	// it cloned from the parent.
	_, _, parentLeases := sess.clientLifecycleSnapshot(parent)
	for _, lease := range parentLeases {
		require.NotEqual(t, engine.ClientLeaseChild, lease.kind)
	}
}

func TestNestedTransportRegistrationBindsExactExecAttachables(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()

	bootstrapMetadata := nestedTransportTestMetadata("bootstrap")
	bootstrap, err := srv.RegisterNestedClientTransport(ctx, bootstrapMetadata, parent.clientID)
	require.NoError(t, err)
	defer bootstrap.Close()

	logicalMetadata := nestedTransportTestMetadata("logical")
	logicalMetadata.ClientSecretToken = bootstrapMetadata.ClientSecretToken
	logical, err := srv.RegisterNestedClientTransportForExec(ctx, logicalMetadata, parent.clientID, bootstrapMetadata.ClientID)
	require.NoError(t, err)
	defer logical.Close()

	sess.clientMu.RLock()
	logicalRecord := sess.clientRecords[logicalMetadata.ClientID]
	sess.clientMu.RUnlock()
	require.Equal(t, bootstrapMetadata.ClientID, logicalRecord.attachablesClientID)

	bootstrapCaller := &sessionAttachableCaller{
		ctx:       context.Background(),
		supported: map[string]struct{}{},
	}
	sess.attachables = newSessionAttachableManager()
	sess.attachables.callers[bootstrapMetadata.ClientID] = bootstrapCaller
	caller, err := srv.clientAttachableCaller(ctx, sess.sessionID, logicalMetadata.ClientID, true)
	require.NoError(t, err)
	require.Same(t, bootstrapCaller, caller)

	missing := nestedTransportTestMetadata("missing-carrier")
	_, err = srv.RegisterNestedClientTransportForExec(ctx, missing, parent.clientID, "absent")
	require.ErrorContains(t, err, `attachables client "absent" not found`)

	wrongSecret := nestedTransportTestMetadata("wrong-secret")
	_, err = srv.RegisterNestedClientTransportForExec(ctx, wrongSecret, parent.clientID, bootstrapMetadata.ClientID)
	require.ErrorContains(t, err, "different secret token")
}

func TestNestedTransportRegistrationWaitsForExpectedAttachables(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	sess.attachables = newSessionAttachableManager()

	// The exec's session helper starts alongside its command, so a logical
	// client can register before the helper has connected.
	bootstrapMetadata := nestedTransportTestMetadata("bootstrap")
	_, done := sess.attachables.Expect(bootstrapMetadata.ClientID)
	defer done()
	logicalMetadata := nestedTransportTestMetadata("logical")
	logicalMetadata.ClientSecretToken = bootstrapMetadata.ClientSecretToken
	type result struct {
		transport *engine.NestedClientTransport
		err       error
	}
	registered := make(chan result, 1)
	go func() {
		transport, err := srv.RegisterNestedClientTransportForExec(ctx, logicalMetadata, parent.clientID, bootstrapMetadata.ClientID)
		registered <- result{transport, err}
	}()
	waitForAttachablesWaiter(t, sess.attachables, bootstrapMetadata.ClientID)

	bootstrap, err := srv.RegisterNestedClientTransport(ctx, bootstrapMetadata, parent.clientID)
	require.NoError(t, err)
	defer bootstrap.Close()
	sess.attachables.mu.Lock()
	sess.attachables.callers[bootstrapMetadata.ClientID] = &sessionAttachableCaller{ctx: context.Background(), supported: map[string]struct{}{}}
	sess.attachables.wakeWaitersLocked(bootstrapMetadata.ClientID)
	sess.attachables.mu.Unlock()

	got := <-registered
	require.NoError(t, got.err)
	defer got.transport.Close()

	// A helper that fails fails the waiting registration.
	failedMetadata := nestedTransportTestMetadata("failed-bootstrap")
	fail, failedDone := sess.attachables.Expect(failedMetadata.ClientID)
	defer failedDone()
	orphan := nestedTransportTestMetadata("orphan")
	orphan.ClientSecretToken = failedMetadata.ClientSecretToken
	failed := make(chan error, 1)
	go func() {
		_, err := srv.RegisterNestedClientTransportForExec(ctx, orphan, parent.clientID, failedMetadata.ClientID)
		failed <- err
	}()
	waitForAttachablesWaiter(t, sess.attachables, failedMetadata.ClientID)
	fail(errors.New("the Dagger session helper in this container exited with status 1"))
	require.ErrorContains(t, <-failed, "exited with status 1")
}

// waitForAttachablesWaiter waits until something waits for clientID's
// attachables.
func waitForAttachablesWaiter(t *testing.T, m *sessionAttachableManager, clientID string) {
	t.Helper()
	require.Eventually(t, func() bool {
		m.mu.Lock()
		defer m.mu.Unlock()
		return len(m.waiters[clientID]) > 0
	}, 5*time.Second, time.Millisecond)
}

func TestNestedTransportRegistrationRequiresExactHeldParentScope(t *testing.T) {
	t.Parallel()

	srv, _, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	metadata := nestedTransportTestMetadata("child")

	_, err := srv.RegisterNestedClientTransport(context.Background(), metadata, parent.clientID)
	require.ErrorContains(t, err, "requires a held parent client scope")

	_, err = srv.RegisterNestedClientTransport(ctx, metadata, "other")
	require.ErrorContains(t, err, "does not match")

	otherSessionMetadata := *metadata
	otherSessionMetadata.SessionID = "other-session"
	_, err = srv.RegisterNestedClientTransport(ctx, &otherSessionMetadata, parent.clientID)
	require.ErrorContains(t, err, "does not match")

	fakeLease := engine.NewClientLifecycleLease(engine.ClientLeaseRequest, "fake", func() {}, func(kind engine.ClientLeaseKind, ownerID string) (*engine.ClientLifecycleLease, error) {
		return engine.NewClientLifecycleLease(kind, ownerID, func() {}, nil), nil
	})
	fakeScope, err := engine.NewClientScope(parent.clientMetadata, fakeLease)
	require.NoError(t, err)
	fakeCtx, err := engine.ContextWithClientScope(context.Background(), fakeScope)
	require.NoError(t, err)
	_, err = srv.RegisterNestedClientTransport(fakeCtx, metadata, parent.clientID)
	require.ErrorContains(t, err, "does not belong to the current session")

	requestScope.Lease().Release()
	_, err = srv.RegisterNestedClientTransport(ctx, metadata, parent.clientID)
	require.ErrorContains(t, err, "does not belong to the current session")

	// Equal string IDs from a replaced session record are still stale: the
	// session authority token must match by identity.
	_, _, _, staleCtx, staleScope := newNestedTransportTestFixture(t) //nolint:dogsled // fixture returns every handle; only the stale scope matters here
	defer staleScope.Lease().Release()
	freshSrv, _, freshParent, _, freshScope := newNestedTransportTestFixture(t)
	defer freshScope.Lease().Release()
	_, err = freshSrv.RegisterNestedClientTransport(staleCtx, metadata, freshParent.clientID)
	require.ErrorContains(t, err, "does not belong to the current session")
}

func TestNestedTransportRegistrationDoesNotTakeLifecycleLock(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, _ := newNestedTransportTestFixture(t)

	// removeDaggerSession holds lifecycleMu for its whole duration while it
	// waits for client scope leases. A registration that blocked on it could
	// be the exec cleanup that owns one of those leases.
	sess.lifecycleMu.Lock()
	defer sess.lifecycleMu.Unlock()

	done := make(chan error, 1)
	go func() {
		_, err := srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("child"), parent.clientID)
		done <- err
	}()
	select {
	case err := <-done:
		require.NoError(t, err)
	case <-time.After(5 * time.Second):
		t.Fatal("nested registration blocked on the session lifecycle lock")
	}
}

func TestNestedTransportRegistrationRacesSessionTeardown(t *testing.T) {
	t.Parallel()

	for range 100 {
		srv, sess, parent, ctx, parentRequest := newNestedTransportTestFixture(t)

		start := make(chan struct{})
		var wg sync.WaitGroup
		var registered *engine.NestedClientTransport
		var registerErr error
		wg.Add(2)
		go func() {
			defer wg.Done()
			<-start
			registered, registerErr = srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("child"), parent.clientID)
		}()
		go func() {
			defer wg.Done()
			<-start
			sess.markSessionRemoved()
			sess.beginClientScopeTeardown()
		}()
		close(start)
		wg.Wait()

		if registerErr == nil {
			// A registration that won the race was published before teardown
			// snapshotted the runtimes, so teardown must have observed it.
			require.NotNil(t, registered)
			require.True(t, registered.Closed(), "teardown must close the proxy-owned handle of a registered child")
			sess.scopeMu.Lock()
			child := sess.clientRuntimes["child"]
			require.NotNil(t, child)
			require.False(t, child.accepting, "teardown must close a child registered before it began")
			require.Nil(t, child.transportLease, "teardown must release the child's transport lease")
			require.Nil(t, child.parentClientScopeLease, "teardown must release the child's parent lease")
			sess.scopeMu.Unlock()
		}

		// Whichever side won, teardown's lease barrier must be able to complete
		// once the parent's own request finishes: no transport or child lease
		// may be stranded on an unpublished or unobserved runtime.
		parentRequest.Lease().Release()
		drainCtx, cancel := context.WithTimeout(t.Context(), 5*time.Second)
		require.NoError(t, sess.waitForClientScopeDrain(drainCtx), "registration racing teardown stranded a lease")
		cancel()
	}
}

func TestHeldParentScopeDelegatesWhileParentClosing(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	sess.closeClientScope(parent)

	transport, err := srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("child"), parent.clientID)
	require.NoError(t, err, "already accepted work must remain a delegation capability during parent close")
	transport.Close()
}

func TestClosedClientWaitsForAcceptedBootstrapRequest(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	metadata := nestedTransportTestMetadata("child")
	transport, err := srv.RegisterNestedClientTransport(ctx, metadata, parent.clientID)
	require.NoError(t, err)
	child := sess.clientRuntimes[metadata.ClientID]

	_, cleanup, err := srv.getOrInitClient(context.Background(), &ClientInitOpts{
		ClientMetadata:  metadata,
		NestedTransport: transport,
		ParentClientID:  parent.clientID,
		BootstrapOnly:   true,
	})
	require.NoError(t, err)

	transport.Close()
	sess.clientMu.RLock()
	require.Same(t, child, sess.clientRuntimes[child.clientID],
		"an accepted bootstrap request must retain the closed runtime")
	sess.clientMu.RUnlock()
	_, _, leases := sess.clientLifecycleSnapshot(child)
	require.Equal(t, []clientLifecycleLeaseRecord{{kind: engine.ClientLeaseRequest, ownerID: "client connection"}}, leases)

	require.NoError(t, cleanup())
	require.NoError(t, cleanup(), "connection cleanup must be idempotent")
	sess.clientMu.RLock()
	_, runtimeRetained := sess.clientRuntimes[child.clientID]
	record := sess.clientRecords[child.clientID]
	sess.clientMu.RUnlock()
	require.False(t, runtimeRetained)
	require.NotNil(t, record)
	sess.scopeMu.Lock()
	require.False(t, record.quiescentAt.IsZero())
	sess.scopeMu.Unlock()
	child.stateMu.RLock()
	require.Zero(t, child.activeCount, "idempotent cleanup must decrement the request count once")
	child.stateMu.RUnlock()
}

func TestClientInitializationDoesNotHoldScopeLock(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	srv.clientDBs = clientdb.NewDBs(t.TempDir())
	sess.telemetryPubSub = NewPubSub(srv)
	t.Cleanup(func() { require.NoError(t, srv.clientDBs.Close()) })
	metadata := nestedTransportTestMetadata("child")
	transport, err := srv.RegisterNestedClientTransport(ctx, metadata, parent.clientID)
	require.NoError(t, err)
	child := sess.clientRuntimes[metadata.ClientID]

	// Stop first initialization at the core-schema boundary. initializeClientRuntime
	// holds stateMu there, giving the test a deterministic signal that it has
	// crossed request admission and reached slow DagQL/schema work.
	sess.engineUtilClient = new(engineutil.Client)
	srv.coreSchemaBaseMu.Lock()
	coreSchemaLocked := true
	defer func() {
		if coreSchemaLocked {
			srv.coreSchemaBaseMu.Unlock()
		}
	}()

	initCtx, cancelInit := context.WithCancel(context.Background())
	defer cancelInit()
	initDone := make(chan error, 1)
	go func() {
		_, _, err := srv.getOrInitClient(initCtx, &ClientInitOpts{
			ClientMetadata:  metadata,
			NestedTransport: transport,
			ParentClientID:  parent.clientID,
		})
		initDone <- err
	}()

	// Admission briefly holds both locks before releasing scopeMu for slow
	// initialization. Observe stateMu while holding scopeMu so we cannot mistake
	// that admission window for the blocked schema boundary. The regression held
	// scopeMu across schema construction, so it can never satisfy this condition.
	require.Eventually(t, func() bool {
		if !sess.scopeMu.TryLock() {
			return false
		}
		defer sess.scopeMu.Unlock()
		if child.stateMu.TryLock() {
			child.stateMu.Unlock()
			return false
		}
		return true
	}, time.Second, time.Millisecond, "slow client initialization retained scopeMu")

	// Closing reachability during initialization must not reclaim the runtime:
	// the provisional request lease owns it until initialization returns.
	transport.Close()
	sess.clientMu.RLock()
	require.Same(t, child, sess.clientRuntimes[child.clientID])
	sess.clientMu.RUnlock()
	_, _, leases := sess.clientLifecycleSnapshot(child)
	require.Equal(t, []clientLifecycleLeaseRecord{{kind: engine.ClientLeaseRequest, ownerID: "client connection"}}, leases)

	cancelInit()
	srv.coreSchemaBaseMu.Unlock()
	coreSchemaLocked = false
	require.Error(t, <-initDone)
	require.Eventually(t, func() bool {
		sess.clientMu.RLock()
		defer sess.clientMu.RUnlock()
		_, retained := sess.clientRuntimes[child.clientID]
		return !retained
	}, time.Second, time.Millisecond, "failed initialization did not release its provisional request lease")
	require.Equal(t, clientdb.OpenStats{}, srv.clientDBs.OpenStats(),
		"failed initialization must release its telemetry store reference")
}

func TestChildQuiescenceReleasesClosingParent(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	sess.closeClientScope(parent)
	childTransport, err := srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("child"), parent.clientID)
	require.NoError(t, err, "the already accepted request may delegate while its parent closes")

	requestScope.Lease().Release()
	sess.clientMu.RLock()
	_, parentRetained := sess.clientRuntimes[parent.clientID]
	sess.clientMu.RUnlock()
	require.True(t, parentRetained, "the live child lease must retain its closing parent")
	_, _, parentLeases := sess.clientLifecycleSnapshot(parent)
	require.Equal(t, []clientLifecycleLeaseRecord{{kind: engine.ClientLeaseChild, ownerID: "child"}}, parentLeases)

	childTransport.Close()
	sess.clientMu.RLock()
	_, childRetained := sess.clientRuntimes["child"]
	_, parentRetained = sess.clientRuntimes[parent.clientID]
	_, childRecordRetained := sess.clientRecords["child"]
	_, parentRecordRetained := sess.clientRecords[parent.clientID]
	sess.clientMu.RUnlock()
	require.False(t, childRetained)
	require.False(t, parentRetained, "the child's quiescent transition must wake parent reclamation")
	require.True(t, childRecordRetained)
	require.True(t, parentRecordRetained)
}

func TestNestedShutdownClosesRegisteredTransportIdempotently(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	transport, err := srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("child"), parent.clientID)
	require.NoError(t, err)
	child := sess.clientRuntimes["child"]
	sess.scopeMu.Lock()
	shutdownLease := sess.newClientLifecycleLeaseLocked(child, engine.ClientLeaseRequest, "POST /shutdown")
	sess.scopeMu.Unlock()

	recorder := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, engine.ShutdownEndpoint, nil)
	require.NoError(t, srv.serveShutdown(recorder, req, child))
	require.True(t, transport.Closed())
	transport.Close()
	accepting, _, leases := sess.clientLifecycleSnapshot(child)
	require.False(t, accepting)
	require.Equal(t, []clientLifecycleLeaseRecord{{kind: engine.ClientLeaseRequest, ownerID: "POST /shutdown"}}, leases)
	shutdownLease.Release()
	sess.clientMu.RLock()
	_, retained := sess.clientRuntimes[child.clientID]
	sess.clientMu.RUnlock()
	require.False(t, retained, "the accepted shutdown request must be the final owner")

	retry := httptest.NewRecorder()
	srv.ServeHTTPToNestedClient(
		retry,
		httptest.NewRequest(http.MethodPost, engine.ShutdownEndpoint, nil),
		transport,
		nestedTransportTestMetadata("child"),
		parent.clientID,
		false,
		nil,
		nil,
	)
	require.Equal(t, http.StatusNoContent, retry.Code)
}

func TestNestedTransportCloseRacesAdmissionSerialization(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	transport, err := srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("child"), parent.clientID)
	require.NoError(t, err)
	child := sess.clientRuntimes["child"]

	started := make(chan struct{})
	release := make(chan struct{})
	admitted := make(chan struct{})
	go func() {
		sess.scopeMu.Lock()
		close(started)
		<-release
		if child.accepting {
			child.metadataSealed = true
		}
		sess.scopeMu.Unlock()
		close(admitted)
	}()
	<-started
	closed := make(chan struct{})
	go func() {
		transport.Close()
		close(closed)
	}()
	deadline := time.NewTimer(10 * time.Second)
	ticker := time.NewTicker(time.Millisecond)
	for !transport.Closed() {
		select {
		case <-deadline.C:
			ticker.Stop()
			close(release)
			<-admitted
			<-closed
			t.Fatal("transport close did not publish its proxy-side marker")
		case <-ticker.C:
		}
	}
	deadline.Stop()
	ticker.Stop()
	select {
	case <-closed:
		close(release)
		<-admitted
		t.Fatal("transport close crossed in-progress request-admission serialization")
	default:
	}
	close(release)
	<-admitted
	<-closed
	accepting, _, _ := sess.clientLifecycleSnapshot(child)
	require.False(t, accepting)

	// Run the opposite deterministic ordering: close wins before initialization.
	second, err := srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("second"), parent.clientID)
	require.NoError(t, err)
	secondChild := sess.clientRuntimes["second"]
	second.Close()
	sess.scopeMu.Lock()
	if secondChild.accepting {
		secondChild.metadataSealed = true
	}
	sess.scopeMu.Unlock()
	require.Equal(t, clientStateReclaimed, secondChild.state)
}

func TestNestedBootstrapRequestsMergeBeforeSeal(t *testing.T) {
	t.Parallel()

	srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
	defer requestScope.Lease().Release()
	registration := nestedTransportTestMetadata("child")
	transport, err := srv.RegisterNestedClientTransport(ctx, registration, parent.clientID)
	require.NoError(t, err)
	child := sess.clientRuntimes[registration.ClientID]

	attachables := *registration
	attachables.AllowedLLMModules = []string{"github.com/acme/mod"}
	_, cleanup, err := srv.getOrInitClient(context.Background(), &ClientInitOpts{
		ClientMetadata:  &attachables,
		NestedTransport: transport,
		ParentClientID:  parent.clientID,
		BootstrapOnly:   true,
	})
	require.NoError(t, err)
	require.NoError(t, cleanup())
	require.Equal(t, clientStateUninitialized, child.state)
	require.False(t, sess.clientMetadataSealed(child.clientRecord))

	init := attachables
	init.Workspace = stringPtr("github.com/acme/workspace@main")
	_, cleanup, err = srv.getOrInitClient(context.Background(), &ClientInitOpts{
		ClientMetadata:  &init,
		NestedTransport: transport,
		ParentClientID:  parent.clientID,
		BootstrapOnly:   true,
	})
	require.NoError(t, err)
	require.NoError(t, cleanup())

	conflict := init
	conflict.Workspace = stringPtr("github.com/acme/other@main")
	_, _, err = srv.getOrInitClient(context.Background(), &ClientInitOpts{
		ClientMetadata:  &conflict,
		NestedTransport: transport,
		ParentClientID:  parent.clientID,
		BootstrapOnly:   true,
	})
	require.ErrorContains(t, err, "Workspace")

	require.NoError(t, sealClientMetadataForTest(sess, child))
	sealed, err := sess.clientMetadataSnapshot(child.clientRecord)
	require.NoError(t, err)
	require.Equal(t, attachables.AllowedLLMModules, sealed.AllowedLLMModules)
	require.Equal(t, *init.Workspace, *sealed.Workspace)

	_, cleanup, err = srv.getOrInitClient(context.Background(), &ClientInitOpts{
		ClientMetadata:  sealed,
		NestedTransport: transport,
		ParentClientID:  parent.clientID,
		BootstrapOnly:   true,
	})
	require.NoError(t, err, "identical bootstrap replay after seal must be accepted")
	require.NoError(t, cleanup())

	transport.Close()
	_, _, err = srv.getOrInitClient(context.Background(), &ClientInitOpts{
		ClientMetadata:  sealed,
		NestedTransport: transport,
		ParentClientID:  parent.clientID,
		BootstrapOnly:   true,
	})
	require.ErrorContains(t, err, "closed")
}

func TestClientMetadataBootstrapOrderReplayAndConflict(t *testing.T) {
	t.Parallel()

	type contribution struct {
		name string
		md   *engine.ClientMetadata
	}
	identity := func() *engine.ClientMetadata {
		return &engine.ClientMetadata{
			SessionID:         "session",
			ClientID:          "client",
			ClientSecretToken: "token",
		}
	}
	registration := identity()
	attachables := identity()
	attachables.AllowedLLMModules = []string{"github.com/acme/mod"}
	init := identity()
	init.Workspace = stringPtr("github.com/acme/workspace@main")
	query := identity()
	query.ExtraModules = []engine.ExtraModule{{Ref: "github.com/acme/extra@v1", Name: "extra", Entrypoint: true}}
	contributions := []contribution{{"attachables", attachables}, {"init", init}, {"first-request", query}}
	orders := [][]int{
		{0, 1, 2},
		{0, 2, 1},
		{1, 0, 2},
		{1, 2, 0},
		{2, 0, 1},
		{2, 1, 0},
	}

	for _, order := range orders {
		names := []string{contributions[order[0]].name, contributions[order[1]].name, contributions[order[2]].name}
		t.Run(strings.Join(names, "-"), func(t *testing.T) {
			client := &clientRuntime{clientRecord: &clientRecord{clientID: "client", accepting: true}}
			sess := &daggerSession{}
			require.NoError(t, mergeClientMetadataForTest(sess, client, registration))
			for _, index := range order {
				require.NoError(t, mergeClientMetadataForTest(sess, client, contributions[index].md))
			}
			require.NoError(t, sealClientMetadataForTest(sess, client))

			sealed, err := sess.clientMetadataSnapshot(client.clientRecord)
			require.NoError(t, err)
			require.Equal(t, attachables.AllowedLLMModules, sealed.AllowedLLMModules)
			require.Equal(t, *init.Workspace, *sealed.Workspace)
			require.Equal(t, query.ExtraModules, sealed.ExtraModules)

			// A complete identical replay is accepted after seal.
			require.NoError(t, mergeClientMetadataForTest(sess, client, sealed))

			completion := identity()
			completion.WorkspaceEnv = stringPtr("ci")
			require.ErrorContains(t, mergeClientMetadataForTest(sess, client, completion), "sealed")

			conflict := identity()
			conflict.Workspace = stringPtr("github.com/acme/other@main")
			require.ErrorContains(t, mergeClientMetadataForTest(sess, client, conflict), "Workspace")
		})
	}

	client := &clientRuntime{clientRecord: &clientRecord{clientID: "client", accepting: true}}
	sess := &daggerSession{}
	first := identity()
	first.ClientVersion = "v1.0.0"
	require.NoError(t, mergeClientMetadataForTest(sess, client, first))
	require.NoError(t, mergeClientMetadataForTest(sess, client, first), "identical replay before seal must be accepted")
	conflict := identity()
	conflict.ClientVersion = "v2.0.0"
	require.ErrorContains(t, mergeClientMetadataForTest(sess, client, conflict), "ClientVersion")
}

func TestClientMetadataBootstrapDeepCloneAndScopeSnapshot(t *testing.T) {
	t.Parallel()

	workspace := "github.com/acme/workspace@main"
	workspaceEnv := "ci"
	input := &engine.ClientMetadata{
		SessionID:          "session",
		ClientID:           "client",
		ClientSecretToken:  "token",
		Labels:             map[string]string{"branch": "main"},
		InteractiveCommand: []string{"sh", "-l"},
		AllowedLLMModules:  []string{"github.com/acme/mod"},
		UpstreamCacheImportConfig: []*controlapi.CacheOptionsEntry{{
			Type:  "registry",
			Attrs: map[string]string{"ref": "registry.example/acme/cache"},
		}},
		ExtraModules:          []engine.ExtraModule{{Ref: "github.com/acme/extra@v1", Name: "extra"}},
		Workspace:             &workspace,
		WorkspaceEnv:          &workspaceEnv,
		UseRecipeIDsByDefault: true,
	}
	client := &clientRuntime{clientRecord: &clientRecord{clientID: input.ClientID, accepting: true}}
	sess := &daggerSession{}
	require.NoError(t, mergeClientMetadataForTest(sess, client, input))

	input.Labels["branch"] = "mutated"
	input.InteractiveCommand[0] = "mutated"
	input.AllowedLLMModules[0] = "mutated"
	input.UpstreamCacheImportConfig[0].Attrs["ref"] = "mutated"
	input.ExtraModules[0].Ref = "mutated"
	*input.Workspace = "mutated"
	*input.WorkspaceEnv = "mutated"

	require.NoError(t, sealClientMetadataForTest(sess, client))
	lookup, err := sess.clientMetadataSnapshot(client.clientRecord)
	require.NoError(t, err)
	lookup.Labels["branch"] = "lookup-mutated"
	lookup.ExtraModules[0].Ref = "lookup-mutated"
	lookupAgain, err := sess.clientMetadataSnapshot(client.clientRecord)
	require.NoError(t, err)
	require.Equal(t, "main", lookupAgain.Labels["branch"])
	require.Equal(t, "github.com/acme/extra@v1", lookupAgain.ExtraModules[0].Ref)

	lease := engine.NewClientLifecycleLease(engine.ClientLeaseRequest, "test", func() {}, nil)
	scope, err := engine.NewClientScope(client.clientMetadata, lease)
	require.NoError(t, err)
	first, err := scope.Metadata()
	require.NoError(t, err)
	require.Equal(t, "main", first.Labels["branch"])
	require.Equal(t, "sh", first.InteractiveCommand[0])
	require.Equal(t, "github.com/acme/mod", first.AllowedLLMModules[0])
	require.Equal(t, "registry.example/acme/cache", first.UpstreamCacheImportConfig[0].Attrs["ref"])
	require.Equal(t, "github.com/acme/extra@v1", first.ExtraModules[0].Ref)
	require.Equal(t, "github.com/acme/workspace@main", *first.Workspace)
	require.Equal(t, "ci", *first.WorkspaceEnv)
	require.True(t, first.UseRecipeIDsByDefault)

	first.Labels["branch"] = "lookup-mutated"
	first.ExtraModules[0].Ref = "lookup-mutated"
	second, err := scope.Metadata()
	require.NoError(t, err)
	require.Equal(t, "main", second.Labels["branch"])
	require.Equal(t, "github.com/acme/extra@v1", second.ExtraModules[0].Ref)
	lease.Release()
}

func TestClientMetadataSealRacesTransportClose(t *testing.T) {
	t.Parallel()

	for range 100 {
		srv, sess, parent, ctx, requestScope := newNestedTransportTestFixture(t)
		metadata := nestedTransportTestMetadata("child")
		transport, err := srv.RegisterNestedClientTransport(ctx, metadata, parent.clientID)
		require.NoError(t, err)
		child := sess.clientRuntimes[metadata.ClientID]

		start := make(chan struct{})
		sealErr := make(chan error, 1)
		var wg sync.WaitGroup
		wg.Add(2)
		go func() {
			defer wg.Done()
			<-start
			sess.scopeMu.Lock()
			defer sess.scopeMu.Unlock()
			if !child.accepting || transport.Closed() {
				return
			}
			if err := sess.mergeClientMetadataLocked(child.clientRecord, metadata); err != nil {
				sealErr <- err
				return
			}
			if err := sess.sealClientMetadataLocked(child.clientRecord); err != nil {
				sealErr <- err
			}
		}()
		go func() {
			defer wg.Done()
			<-start
			transport.Close()
		}()
		close(start)
		wg.Wait()
		select {
		case err := <-sealErr:
			require.ErrorContains(t, err, "closed")
		default:
		}

		accepting, _, leases := sess.clientLifecycleSnapshot(child)
		require.False(t, accepting)
		require.Empty(t, leases)
		if sess.clientMetadataSealed(child.clientRecord) {
			_, err := sess.clientMetadataSnapshot(child.clientRecord)
			require.NoError(t, err)
		}
		requestScope.Lease().Release()
	}
}

func TestSessionAttachablesLabelsAllowQueryAndShutdownAdmission(t *testing.T) {
	t.Parallel()

	metadata := &engine.ClientMetadata{
		SessionID:         "session",
		ClientID:          "client",
		ClientSecretToken: "token",
		Labels:            map[string]string{"dagger.io/sdk.name": "go"},
	}
	recordMetadata, err := cloneClientMetadata(metadata)
	require.NoError(t, err)

	analyticsLabels := sessionAnalyticsLabels(metadata, "test-engine").AsMap()
	require.Equal(t, "test-engine", analyticsLabels["dagger.io/engine"])
	require.Contains(t, analyticsLabels, "dagger.io/server.version")
	require.Equal(t, map[string]string{"dagger.io/sdk.name": "go"}, metadata.Labels,
		"session analytics labels must not mutate request metadata")

	record := &clientRecord{
		clientID:       metadata.ClientID,
		clientMetadata: recordMetadata,
		metadataSealed: true,
		accepting:      true,
	}
	runtime := &clientRuntime{
		clientRecord:    record,
		state:           clientStateInitialized,
		lifecycleLeases: map[uint64]clientLifecycleLeaseRecord{},
	}
	sess := &daggerSession{
		sessionID:          metadata.SessionID,
		mainClientCallerID: "main",
		clientRecords:      map[string]*clientRecord{metadata.ClientID: record},
		clientRuntimes:     map[string]*clientRuntime{metadata.ClientID: runtime},
	}
	record.daggerSession = sess
	sess.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{metadata.SessionID: sess}}

	for _, request := range []struct {
		name          string
		bootstrapOnly bool
	}{
		{name: "query", bootstrapOnly: false},
		{name: "shutdown", bootstrapOnly: true},
	} {
		t.Run(request.name, func(t *testing.T) {
			client, cleanup, err := srv.getOrInitClient(context.Background(), &ClientInitOpts{
				ClientMetadata: metadata,
				RootClient:     true,
				BootstrapOnly:  request.bootstrapOnly,
			})
			require.NoError(t, err)
			require.Same(t, runtime, client)
			require.NoError(t, cleanup())
		})
	}
}

func TestClientRecordLookupsAreIndependentFromExecutableRuntime(t *testing.T) {
	t.Parallel()

	root := &clientRecord{
		clientID:        "root",
		clientMetadata:  &engine.ClientMetadata{SessionID: "session", ClientID: "root", Labels: map[string]string{"kind": "record"}},
		metadataSealed:  true,
		accepting:       true,
		parentClientIDs: nil,
	}
	child := &clientRecord{
		clientID:        "child",
		clientMetadata:  &engine.ClientMetadata{SessionID: "session", ClientID: "child"},
		metadataSealed:  true,
		accepting:       true,
		parentClientIDs: []string{"root"},
	}
	sess := &daggerSession{
		sessionID: "session",
		clientRecords: map[string]*clientRecord{
			root.clientID:  root,
			child.clientID: child,
		},
		clientRuntimes: map[string]*clientRuntime{},
	}
	root.daggerSession = sess
	child.daggerSession = sess
	sess.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}

	ctx := engine.ContextWithClientMetadata(context.Background(), child.clientMetadata)
	metadata, err := srv.SpecificClientMetadata(ctx, root.clientID)
	require.NoError(t, err)
	require.Equal(t, "record", metadata.Labels["kind"])
	route, err := sess.telemetryRouteOriginClientID(child.clientID)
	require.NoError(t, err)
	require.Equal(t, []string{"child", "root"}, route)

	_, err = sess.clientRuntimeForRecord(child)
	require.ErrorContains(t, err, "not retained")
	_, err = srv.executableClientFromContext(ctx)
	require.ErrorContains(t, err, "requires a client scope")

	runtime := &clientRuntime{
		clientRecord:    child,
		state:           clientStateInitialized,
		lifecycleLeases: map[uint64]clientLifecycleLeaseRecord{},
	}
	sess.clientMu.Lock()
	sess.clientRuntimes[child.clientID] = runtime
	sess.clientMu.Unlock()

	_, err = srv.executableClientFromContext(ctx)
	require.ErrorContains(t, err, "requires a client scope",
		"metadata identity alone must not authorize executable runtime access")
	scope, err := sess.acquireRootClientScope(runtime, engine.ClientLeaseRequest, "test")
	require.NoError(t, err)
	scopeCtx, err := engine.ContextWithClientScope(context.Background(), scope)
	require.NoError(t, err)
	got, err := srv.executableClientFromContext(scopeCtx)
	require.NoError(t, err)
	require.Same(t, runtime, got)
	scope.Lease().Release()

	_, _, leases := sess.clientLifecycleSnapshot(runtime)
	require.Empty(t, leases)
	sess.clientMu.RLock()
	retained := sess.clientRuntimes[child.clientID]
	sess.clientMu.RUnlock()
	require.Same(t, runtime, retained, "an open transport keeps its runtime reachable even with no request leases")
	sess.closeClientScope(runtime)
	sess.clientMu.RLock()
	_, retainedAfterClose := sess.clientRuntimes[child.clientID]
	sess.clientMu.RUnlock()
	require.False(t, retainedAfterClose, "closing a zero-lease runtime must reclaim it")
	require.Contains(t, sess.clientRecords, child.clientID)
}

func TestWorkspaceHostAccessDoesNotRequireOwnerRuntime(t *testing.T) {
	t.Parallel()

	owner := &clientRecord{
		clientID: "owner",
		clientMetadata: &engine.ClientMetadata{
			SessionID: "session",
			ClientID:  "owner",
			Labels:    map[string]string{"source": "record"},
		},
		metadataSealed: true,
		accepting:      true,
	}
	callerRecord := &clientRecord{
		clientID: "caller",
		clientMetadata: &engine.ClientMetadata{
			SessionID: "session",
			ClientID:  "caller",
		},
		metadataSealed: true,
		accepting:      true,
	}
	callerRuntime := &clientRuntime{
		clientRecord:    callerRecord,
		state:           clientStateInitialized,
		lifecycleLeases: map[uint64]clientLifecycleLeaseRecord{},
	}
	ownerAttachable := &sessionAttachableCaller{
		ctx:       context.Background(),
		supported: map[string]struct{}{},
	}
	attachables := newSessionAttachableManager()
	attachables.callers[owner.clientID] = ownerAttachable
	sess := &daggerSession{
		sessionID:   "session",
		attachables: attachables,
		clientRecords: map[string]*clientRecord{
			owner.clientID:        owner,
			callerRecord.clientID: callerRecord,
		},
		clientRuntimes: map[string]*clientRuntime{
			callerRecord.clientID: callerRuntime,
		},
	}
	owner.daggerSession = sess
	callerRecord.daggerSession = sess
	sess.getClientCaller = func(ctx context.Context, id string) (engineutil.SessionCaller, error) {
		return sess.attachables.Wait(ctx, id)
	}
	sess.engineUtilClient = &engineutil.Client{Opts: &engineutil.Opts{
		GetClientCaller:      sess.getClientCaller,
		GetHostServiceCaller: sess.resolveHostServiceCaller,
	}}
	sess.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}

	scope, err := sess.acquireRootClientScope(callerRuntime, engine.ClientLeaseRequest, "workspace access")
	require.NoError(t, err)
	defer scope.Lease().Release()
	callerCtx, err := engine.ContextWithClientScope(context.Background(), scope)
	require.NoError(t, err)

	workspaceCtx, gateway, err := srv.workspaceOwnerAccess(callerCtx, sess, &core.Workspace{ClientID: owner.clientID})
	require.NoError(t, err)
	require.Same(t, sess.engineUtilClient, gateway)
	require.NotContains(t, sess.clientRuntimes, owner.clientID,
		"workspace owner access must not require a retained owner runtime")

	ownerMetadata, err := engine.ClientMetadataFromContext(workspaceCtx)
	require.NoError(t, err)
	require.Equal(t, owner.clientID, ownerMetadata.ClientID)
	ownerMetadata.Labels["source"] = "mutated"

	caller, err := gateway.GetSessionCaller(workspaceCtx)
	require.NoError(t, err)
	require.Same(t, ownerAttachable, caller,
		"session gateway must route from immutable owner metadata to the owner attachable")

	queryGateway, err := srv.Engine(workspaceCtx)
	require.NoError(t, err)
	require.Same(t, gateway, queryGateway,
		"workspace Query.Engine paths must use the session-owned gateway")
	caller, err = queryGateway.GetSessionCaller(workspaceCtx)
	require.NoError(t, err)
	require.Same(t, ownerAttachable, caller)

	workspaceCtx, _, err = srv.workspaceOwnerAccess(callerCtx, sess, &core.Workspace{ClientID: owner.clientID})
	require.NoError(t, err)
	ownerMetadata, err = engine.ClientMetadataFromContext(workspaceCtx)
	require.NoError(t, err)
	require.Equal(t, "record", ownerMetadata.Labels["source"],
		"workspace access must clone immutable owner metadata")
}

func TestWorkspaceRuntimeFromContextSelectsOnlyScopedClientOrAncestor(t *testing.T) {
	t.Parallel()

	newRuntime := func(clientID string, parents ...string) *clientRuntime {
		return &clientRuntime{
			clientRecord: &clientRecord{
				clientID:        clientID,
				clientMetadata:  &engine.ClientMetadata{SessionID: "session", ClientID: clientID},
				metadataSealed:  true,
				accepting:       true,
				parentClientIDs: parents,
			},
			state:           clientStateInitialized,
			lifecycleLeases: map[uint64]clientLifecycleLeaseRecord{},
		}
	}
	root := newRuntime("root")
	child := newRuntime("child", "root")
	sibling := newRuntime("sibling", "root")
	sess := &daggerSession{
		sessionID: "session",
		clientRuntimes: map[string]*clientRuntime{
			root.clientID: root, child.clientID: child, sibling.clientID: sibling,
		},
	}
	for _, runtime := range sess.clientRuntimes {
		runtime.daggerSession = sess
	}
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}

	scope, err := sess.acquireRootClientScope(child, engine.ClientLeaseRequest, "workspace schema")
	require.NoError(t, err)
	defer scope.Lease().Release()
	ctx, err := engine.ContextWithClientScope(context.Background(), scope)
	require.NoError(t, err)

	got, err := srv.workspaceRuntimeFromContext(ctx)
	require.NoError(t, err)
	require.Same(t, child, got)

	ancestorCtx := engine.ContextWithClientMetadata(ctx, root.clientMetadata)
	got, err = srv.workspaceRuntimeFromContext(ancestorCtx)
	require.NoError(t, err)
	require.Same(t, root, got,
		"workspace schema operations must use the validated owner ancestor")

	siblingCtx := engine.ContextWithClientMetadata(ctx, sibling.clientMetadata)
	_, err = srv.workspaceRuntimeFromContext(siblingCtx)
	require.ErrorContains(t, err, "is not the executable client")

	wrongSession := *root.clientMetadata
	wrongSession.SessionID = "other"
	_, err = srv.workspaceRuntimeFromContext(engine.ContextWithClientMetadata(ctx, &wrongSession))
	require.ErrorContains(t, err, "does not match executable scope session")
}

func TestClientScopeRequiresSealedMetadata(t *testing.T) {
	t.Parallel()

	client := &clientRuntime{clientRecord: &clientRecord{
		clientID:       "client",
		clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "client", ClientSecretToken: "token"},
		accepting:      true},
		lifecycleLeases: make(map[uint64]clientLifecycleLeaseRecord)}
	sess := &daggerSession{
		sessionID:      "session",
		clientRuntimes: map[string]*clientRuntime{client.clientID: client},
	}
	client.daggerSession = sess
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)
	_, err := sess.acquireRootClientScope(client, engine.ClientLeaseRequest, "before-seal")
	require.ErrorContains(t, err, "not sealed")

	require.NoError(t, sealClientMetadataForTest(sess, client))
	scope, err := sess.acquireRootClientScope(client, engine.ClientLeaseRequest, "after-seal")
	require.NoError(t, err)
	scope.Lease().Release()
}

func TestClientLifecycleScopesSerializeCloseCloneAndRelease(t *testing.T) {
	t.Parallel()

	client := &clientRuntime{clientRecord: &clientRecord{
		clientID:       "client",
		clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "client", Labels: map[string]string{"scope": "sealed"}},
		metadataSealed: true,
		accepting:      true},
		state:           clientStateInitialized,
		dagqlRoot:       &core.Query{},
		workspace:       &core.Workspace{},
		failedModules:   map[string]error{"old": errors.New("old")},
		lifecycleLeases: make(map[uint64]clientLifecycleLeaseRecord)}
	sess := &daggerSession{
		sessionID:          "session",
		mainClientCallerID: client.clientID,
		clientRuntimes:     map[string]*clientRuntime{client.clientID: client},
	}
	client.daggerSession = sess
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)

	transportScope, err := sess.acquireRootClientScope(client, engine.ClientLeaseTransport, "proxy")
	require.NoError(t, err)
	client.transportLease = transportScope.Lease()
	requestScope, err := sess.acquireRootClientScope(client, engine.ClientLeaseRequest, "POST /query")
	require.NoError(t, err)

	sess.closeClientScope(client)
	_, err = sess.acquireRootClientScope(client, engine.ClientLeaseRequest, "late root")
	require.ErrorContains(t, err, "closed")

	// The accepted request remains a strict capability while reachability is
	// closing and may still delegate terminal/background work.
	agentScope, err := requestScope.Clone(engine.ClientLeaseAgent, "agent-1")
	require.NoError(t, err)
	tombstoneScope, err := requestScope.Clone(engine.ClientLeaseAgentTombstone, "agent-tombstone-1")
	require.NoError(t, err)
	serviceScope, err := requestScope.Clone(engine.ClientLeaseService, "service-1")
	require.NoError(t, err)
	sharedScope, err := requestScope.Clone(engine.ClientLeaseSharedWork, "call-1")
	require.NoError(t, err)

	srv := &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}
	snapshot := srv.ClientLifecycleDebugSnapshot()
	require.Equal(t, []LifecycleRetentionReason{
		{Kind: "agent", OwnerID: "agent-1", Count: 1},
		{Kind: "agent-tombstone", OwnerID: "agent-tombstone-1", Count: 1},
		{Kind: "request", OwnerID: "POST /query", Count: 1},
		{Kind: "service", OwnerID: "service-1", Count: 1},
		{Kind: "shared-work", OwnerID: "call-1", Count: 1},
	}, snapshot.LeaseCounts)
	require.Equal(t, 1, snapshot.ActiveRequests)

	var wg sync.WaitGroup
	for range 64 {
		wg.Add(5)
		go func() {
			defer wg.Done()
			requestScope.Lease().Release()
		}()
		go func() {
			defer wg.Done()
			agentScope.Lease().Release()
		}()
		go func() {
			defer wg.Done()
			tombstoneScope.Lease().Release()
		}()
		go func() {
			defer wg.Done()
			serviceScope.Lease().Release()
		}()
		go func() {
			defer wg.Done()
			sharedScope.Lease().Release()
		}()
	}
	wg.Wait()
	require.Empty(t, srv.ClientLifecycleDebugSnapshot().LeaseCounts)
	sess.clientMu.RLock()
	_, runtimeRetained := sess.clientRuntimes[client.clientID]
	_, recordRetained := sess.clientRecords[client.clientID]
	sess.clientMu.RUnlock()
	require.False(t, runtimeRetained)
	require.True(t, recordRetained)
	require.Equal(t, clientStateReclaimed, client.state)
	require.Nil(t, client.dagqlRoot, "reclamation must clear execution graph roots from stale lease shells")
	require.Nil(t, client.workspace)
	require.Nil(t, client.failedModules)
	_, err = requestScope.Clone(engine.ClientLeaseChild, "late-child")
	require.ErrorContains(t, err, "not held")
}

func TestClientLifecycleScopesRaceSessionTeardown(t *testing.T) {
	t.Parallel()

	client := &clientRuntime{clientRecord: &clientRecord{
		clientID:       "client",
		clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "client"},
		metadataSealed: true,
		accepting:      true},
		state:           clientStateInitialized,
		lifecycleLeases: make(map[uint64]clientLifecycleLeaseRecord)}
	sess := &daggerSession{
		sessionID:      "session",
		clientRuntimes: map[string]*clientRuntime{client.clientID: client},
	}
	client.daggerSession = sess
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)
	transport, err := sess.acquireRootClientScope(client, engine.ClientLeaseTransport, "proxy")
	require.NoError(t, err)
	client.transportLease = transport.Lease()
	source, err := sess.acquireRootClientScope(client, engine.ClientLeaseRequest, "request")
	require.NoError(t, err)

	start := make(chan struct{})
	var wg sync.WaitGroup
	for i := range 64 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			<-start
			clone, err := source.Clone(engine.ClientLeaseChild, fmt.Sprintf("child-%d", i))
			if err == nil {
				clone.Lease().Release()
			}
		}()
	}
	wg.Add(1)
	go func() {
		defer wg.Done()
		<-start
		sess.markSessionRemoved()
		sess.beginClientScopeTeardown()
	}()
	close(start)
	wg.Wait()
	source.Lease().Release()

	_, err = sess.acquireRootClientScope(client, engine.ClientLeaseRequest, "late")
	require.ErrorContains(t, err, "session")
	_, _, leases := sess.clientLifecycleSnapshot(client)
	require.Empty(t, leases)
}

func TestClientLifecycleScopeDrainWaitsForTerminalRelease(t *testing.T) {
	t.Parallel()

	client := &clientRuntime{clientRecord: &clientRecord{
		clientID:       "client",
		clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "client"},
		metadataSealed: true,
		accepting:      true},
		state:           clientStateInitialized,
		lifecycleLeases: make(map[uint64]clientLifecycleLeaseRecord)}
	sess := &daggerSession{
		sessionID:      "session",
		clientRuntimes: map[string]*clientRuntime{client.clientID: client},
	}
	client.daggerSession = sess
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)

	transport, err := sess.acquireRootClientScope(client, engine.ClientLeaseTransport, "proxy")
	require.NoError(t, err)
	client.transportLease = transport.Lease()
	request, err := sess.acquireRootClientScope(client, engine.ClientLeaseRequest, "request")
	require.NoError(t, err)

	sess.markSessionRemoved()
	sess.beginClientScopeTeardown()

	canceledCtx, cancel := context.WithCancel(t.Context())
	cancel()
	require.ErrorIs(t, sess.waitForClientScopeDrain(canceledCtx), context.Canceled)

	waitDone := make(chan error, 1)
	go func() { waitDone <- sess.waitForClientScopeDrain(t.Context()) }()
	select {
	case err := <-waitDone:
		t.Fatalf("scope drain returned before the request lease: %v", err)
	default:
	}

	request.Lease().Release()
	require.NoError(t, <-waitDone)
	_, _, leases := sess.clientLifecycleSnapshot(client)
	require.Empty(t, leases)
}

func TestClientRuntimeReclamationRacesCloseLeasesChildAndTeardown(t *testing.T) {
	t.Parallel()

	for range 100 {
		srv, sess, parent, ctx, parentRequest := newNestedTransportTestFixture(t)
		childTransport, err := srv.RegisterNestedClientTransport(ctx, nestedTransportTestMetadata("child"), parent.clientID)
		require.NoError(t, err)
		child := sess.clientRuntimes["child"]

		sess.scopeMu.Lock()
		childRequest := sess.newClientLifecycleLeaseLocked(child, engine.ClientLeaseRequest, "request")
		childService := sess.newClientLifecycleLeaseLocked(child, engine.ClientLeaseService, "service")
		childShared := sess.newClientLifecycleLeaseLocked(child, engine.ClientLeaseSharedWork, "shared")
		sess.scopeMu.Unlock()

		start := make(chan struct{})
		var wg sync.WaitGroup
		for _, action := range []func(){
			func() { childTransport.Close() },
			func() { sess.closeClientScope(parent) },
			func() { parentRequest.Lease().Release() },
			func() { childRequest.Release() },
			func() { childService.Release() },
			func() { childShared.Release() },
			func() {
				sess.lifecycleMu.Lock()
				if sess.state.Load() == sessionStateInitialized {
					sess.markSessionRemoved()
					sess.beginClientScopeTeardown()
				}
				sess.lifecycleMu.Unlock()
			},
		} {
			wg.Add(1)
			go func() {
				defer wg.Done()
				<-start
				action()
			}()
		}
		close(start)
		wg.Wait()

		sess.scopeMu.Lock()
		quiescentBeforeRepeat := map[*clientRuntime]time.Time{
			parent: parent.quiescentAt,
			child:  child.quiescentAt,
		}
		sess.scopeMu.Unlock()

		// Repeat every idempotent edge after the race. No lease may remain and a
		// runtime that won live-session reclamation must have exactly one stable
		// quiescent timestamp; teardown is allowed to retain runtime shells until
		// the session object itself is dropped.
		childTransport.Close()
		sess.closeClientScope(parent)
		parentRequest.Lease().Release()
		childRequest.Release()
		childService.Release()
		childShared.Release()
		sess.beginClientScopeTeardown()

		for _, runtime := range []*clientRuntime{parent, child} {
			_, _, leases := sess.clientLifecycleSnapshot(runtime)
			require.Empty(t, leases)
			sess.scopeMu.Lock()
			quiescentAt := runtime.quiescentAt
			sess.scopeMu.Unlock()
			if !quiescentAt.IsZero() {
				require.Equal(t, quiescentBeforeRepeat[runtime], quiescentAt,
					"idempotent cleanup must not repeat the quiescent transition")
				runtime.stateMu.RLock()
				require.Equal(t, clientStateReclaimed, runtime.state)
				runtime.stateMu.RUnlock()
			}
		}
		require.Contains(t, sess.clientRecords, parent.clientID)
		require.Contains(t, sess.clientRecords, child.clientID)
	}
}

type blockingMetricExporter struct {
	started chan struct{}
	release chan struct{}
	once    sync.Once
}

func (exp *blockingMetricExporter) Export(context.Context, *metricdata.ResourceMetrics) error {
	exp.once.Do(func() { close(exp.started) })
	<-exp.release
	return nil
}

func (*blockingMetricExporter) Temporality(sdkmetric.InstrumentKind) metricdata.Temporality {
	return metricdata.DeltaTemporality
}

func (*blockingMetricExporter) Aggregation(sdkmetric.InstrumentKind) sdkmetric.Aggregation {
	return sdkmetric.AggregationDefault{}
}

func (*blockingMetricExporter) ForceFlush(context.Context) error { return nil }
func (*blockingMetricExporter) Shutdown(context.Context) error   { return nil }

func TestClientRuntimeReclamationDrainsMetricsBeforeUnpublish(t *testing.T) {
	t.Parallel()

	record := &clientRecord{clientID: "child", accepting: false}
	client := &clientRuntime{
		clientRecord:    record,
		state:           clientStateInitialized,
		lifecycleLeases: make(map[uint64]clientLifecycleLeaseRecord),
		telemetryDebug:  LifecycleTelemetryCounts{MeterProviders: 1, ConfiguredMetricReaders: 1},
	}
	sess := &daggerSession{
		sessionID:      "session",
		clientRecords:  map[string]*clientRecord{record.clientID: record},
		clientRuntimes: map[string]*clientRuntime{record.clientID: client},
	}
	record.daggerSession = sess
	sess.state.Store(sessionStateInitialized)

	exporter := &blockingMetricExporter{
		started: make(chan struct{}),
		release: make(chan struct{}),
	}
	client.meterProvider = sdkmetric.NewMeterProvider(sdkmetric.WithReader(
		sdkmetric.NewPeriodicReader(exporter, sdkmetric.WithInterval(time.Hour)),
	))
	gauge, err := client.meterProvider.Meter("test").Int64Gauge("test.reclamation")
	require.NoError(t, err)
	gauge.Record(t.Context(), 1)

	sess.scopeMu.Lock()
	lease := sess.newClientLifecycleLeaseLocked(client, engine.ClientLeaseSharedWork, "metric-producer")
	sess.scopeMu.Unlock()

	reclaimed := make(chan struct{})
	go func() {
		lease.Release()
		close(reclaimed)
	}()
	<-exporter.started

	sess.clientMu.RLock()
	require.Same(t, client, sess.clientRuntimes[client.clientID],
		"runtime must stay published until its metric provider drains")
	sess.clientMu.RUnlock()
	require.True(t, client.reclaiming)
	require.True(t, record.quiescentAt.IsZero())

	flushed := make(chan error, 1)
	go func() { flushed <- sess.FlushTelemetry(t.Context(), "concurrent reclamation") }()
	select {
	case err := <-flushed:
		t.Fatalf("session flush bypassed the client metric drain: %v", err)
	case <-time.After(20 * time.Millisecond):
	}

	close(exporter.release)
	require.NoError(t, <-flushed)
	<-reclaimed
	sess.clientMu.RLock()
	_, retained := sess.clientRuntimes[client.clientID]
	sess.clientMu.RUnlock()
	require.False(t, retained)
	require.False(t, record.quiescentAt.IsZero())
	require.Nil(t, client.meterProvider)
	require.Zero(t, client.telemetryDebug.MeterProviders)
	require.Zero(t, client.telemetryDebug.ConfiguredMetricReaders)
}

func TestClientLifecycleDebugSnapshotReportsClosedRuntimeRetention(t *testing.T) {
	t.Parallel()

	closedAt := time.Now().Add(-time.Minute).Round(0)
	parent := &clientRuntime{clientRecord: &clientRecord{
		clientID:   "parent",
		shutdownAt: closedAt},
		state:          clientStateInitialized,
		activeCount:    2,
		telemetryDebug: LifecycleTelemetryCounts{MeterProviders: 1, ConfiguredMetricReaders: 1}}
	child := &clientRuntime{clientRecord: &clientRecord{
		clientID:        "child",
		parentClientIDs: []string{"parent"}},
		state:          clientStateInitialized,
		telemetryDebug: LifecycleTelemetryCounts{MeterProviders: 1, ConfiguredMetricReaders: 1}}
	sess := &daggerSession{
		sessionID: "session",
		clientRuntimes: map[string]*clientRuntime{
			parent.clientID: parent,
			child.clientID:  child,
		},
		telemetryDebug: LifecycleTelemetryCounts{
			TracerProviders:          1,
			LoggerProviders:          1,
			ConfiguredSpanProcessors: 4,
			ConfiguredLogProcessors:  3,
			ConfiguredSpanQueueSlots: enginetel.LargeSpanQueueSize,
			ConfiguredLogQueueSlots:  enginetel.LogQueueSize,
		},
	}
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}

	snapshot := srv.ClientLifecycleDebugSnapshot()
	require.Equal(t, 2, snapshot.Records)
	require.Equal(t, 2, snapshot.Runtimes)
	require.Equal(t, 1, snapshot.ClosedRuntimes)
	require.Equal(t, 2, snapshot.ActiveRequests)
	require.NotNil(t, snapshot.OldestClosedRuntime)
	require.Equal(t, closedAt, *snapshot.OldestClosedRuntime)
	require.Equal(t, 1, snapshot.Providers.TracerProviders)
	require.Equal(t, 2, snapshot.Providers.MeterProviders)
	require.Equal(t, 2, snapshot.Providers.ConfiguredMetricReaders)
	require.Equal(t, 4, snapshot.Providers.ConfiguredSpanProcessors)
	require.False(t, snapshot.Providers.QueueOccupancyMeasured)

	require.Len(t, snapshot.Sessions, 1)
	require.Equal(t, []string{"child", "parent"}, []string{
		snapshot.Sessions[0].Clients[0].ClientID,
		snapshot.Sessions[0].Clients[1].ClientID,
	})
	gotParent := snapshot.Sessions[0].Clients[1]
	require.Equal(t, "shutdown-signaled", gotParent.RecordState)
	require.Equal(t, "closed-retained", gotParent.RuntimeState)
	require.Equal(t, 1, gotParent.Telemetry.MeterProviders)
	require.Equal(t, 1, gotParent.Telemetry.ConfiguredMetricReaders)
	require.False(t, gotParent.MetadataSealed)
	require.ElementsMatch(t, []string{"lifecycle-transition", "request"}, []string{
		gotParent.RetentionReasons[0].Kind,
		gotParent.RetentionReasons[1].Kind,
	})
}

func TestClientAncestryAndTelemetryRouteOrdering(t *testing.T) {
	t.Parallel()

	root := &clientRuntime{clientRecord: &clientRecord{clientID: "root"}}
	parent := &clientRuntime{clientRecord: &clientRecord{clientID: "parent", parentClientIDs: []string{"root"}}}
	child := &clientRuntime{clientRecord: &clientRecord{clientID: "child", parentClientIDs: []string{"root", "parent"}}}
	sess := &daggerSession{clientRuntimes: map[string]*clientRuntime{
		root.clientID:   root,
		parent.clientID: parent,
		child.clientID:  child,
	}}
	for _, client := range sess.clientRuntimes {
		client.daggerSession = sess
	}
	installTestClientRecords(sess)

	ancestors, err := sess.ancestorRuntimes(child.clientRecord)
	require.NoError(t, err)
	require.Equal(t, []string{"root", "parent"}, []string{ancestors[0].clientID, ancestors[1].clientID})

	route, err := sess.telemetryRouteClientIDs(child.clientRecord)
	require.NoError(t, err)
	require.Equal(t, []string{"child", "root", "parent"}, route,
		"telemetry must preserve origin-first, root-to-direct-parent fan-out")

	delivery, err := sess.telemetryDeliveryClientIDs(child.clientRecord)
	require.NoError(t, err)
	require.Equal(t, []string{"root", "parent", "child"}, delivery,
		"call-payload claims retain their historical ancestor-first ordering")

	route[1] = "mutated"
	require.Equal(t, []string{"root", "parent"}, child.parentClientIDs,
		"returned routes must not alias immutable client ancestry")
}

func TestTelemetryRoutesClientsAndAncestorsExactlyOnce(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	srv := &Server{clientDBs: dbs, wcprofSpanCount: newWcprofSpanCounter()}
	srv.telemetryPubSub = NewPubSub(srv)

	root := &clientRuntime{clientRecord: &clientRecord{clientID: "root", clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "root"}}}
	parent := &clientRuntime{clientRecord: &clientRecord{clientID: "parent", parentClientIDs: []string{"root"}, clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "parent"}}}
	child := &clientRuntime{clientRecord: &clientRecord{clientID: "child", parentClientIDs: []string{"root", "parent"}, clientMetadata: &engine.ClientMetadata{SessionID: "session", ClientID: "child"}, shutdownCh: make(chan struct{})}}
	sess := &daggerSession{
		sessionID:          "session",
		mainClientCallerID: root.clientID,
		clientRuntimes: map[string]*clientRuntime{
			root.clientID: root, parent.clientID: parent, child.clientID: child,
		},
		telemetryPubSub: srv.telemetryPubSub,
	}
	for _, client := range sess.clientRuntimes {
		client.daggerSession = sess
	}
	installTestClientRecords(sess)
	srv.initializeSessionTelemetry(sess, nil)
	for _, client := range sess.clientRuntimes {
		srv.initializeClientMetrics(client)
	}
	t.Cleanup(func() { require.NoError(t, sess.shutdownTelemetry(context.Background())) })

	emit := func(client *clientRuntime, name string, detached bool) trace.SpanID {
		ctx := engine.ContextWithClientMetadata(context.Background(), client.clientMetadata)
		ctx = telemetry.WithLoggerProvider(ctx, sess.loggerProvider)
		if detached {
			lease := engine.NewClientLifecycleLease(engine.ClientLeaseRequest, "test", nil, nil)
			scope, err := engine.NewClientScope(client.clientMetadata, lease)
			require.NoError(t, err)
			ctx, err = engine.ContextWithClientScope(ctx, scope)
			require.NoError(t, err)
			ctx = engine.ContextWithClientMetadata(ctx, parent.clientMetadata)
			lease.Release() // Origin identity remains valid for final telemetry.
			ctx = context.WithoutCancel(ctx)
			client.closeShutdownOnce.Do(func() { close(client.shutdownCh) })
		}
		_, span := sess.tracerProvider.Tracer("test").Start(ctx, name)
		spanID := span.SpanContext().SpanID()
		// Export the live snapshot separately so both updates exercise routing.
		require.NoError(t, sess.tracerProvider.ForceFlush(ctx))
		span.End()
		rec := otellog.Record{}
		rec.SetTimestamp(time.Now())
		rec.SetBody(otellog.StringValue(name))
		telemetry.Logger(ctx, "test").Emit(ctx, rec)
		workGauge, err := client.meterProvider.Meter("test").Int64Gauge("test.client.work")
		require.NoError(t, err)
		workGauge.Record(ctx, 1)
		return spanID
	}

	rootSpanID := emit(root, "root-work", false)
	childSpanID := emit(child, "detached-child-work", true)
	require.NoError(t, sess.FlushTelemetry(t.Context(), "test"))

	load := func(clientID string) ([]clientdb.Span, []clientdb.Log, []clientdb.Metric) {
		db, err := dbs.Open(t.Context(), clientID)
		require.NoError(t, err)
		defer db.Close()
		spans, err := db.Read().SelectSpansSince(t.Context(), clientdb.SelectSpansSinceParams{Limit: 100})
		require.NoError(t, err)
		logs, err := db.Read().SelectLogsSince(t.Context(), clientdb.SelectLogsSinceParams{Limit: 100})
		require.NoError(t, err)
		metrics, err := db.Read().SelectMetricsSince(t.Context(), clientdb.SelectMetricsSinceParams{Limit: 100})
		require.NoError(t, err)
		return spans, logs, metrics
	}
	countSpan := func(spans []clientdb.Span, id trace.SpanID) int {
		count := 0
		for _, span := range spans {
			if span.SpanID == id.String() {
				count++
			}
		}
		return count
	}

	originAttr := func(attrsJSON []byte) string {
		var attrs []*otlpcommonv1.KeyValue
		require.NoError(t, clientdb.UnmarshalProtoJSONs(attrsJSON, &otlpcommonv1.KeyValue{}, &attrs))
		for _, attr := range attrs {
			if attr.Key == telemetryattrs.TelemetryOriginClientIDAttr {
				return attr.Value.GetStringValue()
			}
		}
		return ""
	}
	metricPointCount := func(rows []clientdb.Metric) int {
		count := 0
		for _, resourceMetricsPB := range clientdb.MetricsToPB(rows) {
			resourceMetrics, err := telemetry.ResourceMetricsFromPB(resourceMetricsPB)
			require.NoError(t, err)
			for _, scopeMetrics := range resourceMetrics.ScopeMetrics {
				for _, metrics := range scopeMetrics.Metrics {
					gauge, ok := metrics.Data.(metricdata.Gauge[int64])
					require.True(t, ok, "unexpected metric aggregation %T", metrics.Data)
					count += len(gauge.DataPoints)
				}
			}
		}
		return count
	}

	rootSpans, rootLogs, rootMetrics := load("root")
	parentSpans, parentLogs, parentMetrics := load("parent")
	childSpans, childLogs, childMetrics := load("child")
	// The explicit flush keeps start and end snapshots in separate batches.
	// Each must reach each visibility target once, without duplicate delivery.
	require.Equal(t, 2, countSpan(rootSpans, rootSpanID))
	require.Equal(t, 2, countSpan(rootSpans, childSpanID))
	require.Equal(t, 2, countSpan(parentSpans, childSpanID))
	require.Equal(t, 2, countSpan(childSpans, childSpanID))
	require.Zero(t, countSpan(parentSpans, rootSpanID))
	require.Zero(t, countSpan(childSpans, rootSpanID))
	require.Len(t, rootLogs, 2)
	require.Len(t, parentLogs, 1)
	require.Len(t, childLogs, 1)
	require.Equal(t, 2, metricPointCount(rootMetrics))
	require.Equal(t, 1, metricPointCount(parentMetrics))
	require.Equal(t, 1, metricPointCount(childMetrics))
	for _, span := range append(append(rootSpans, parentSpans...), childSpans...) {
		require.Empty(t, originAttr(span.Attributes), "routing-only span origin must not be persisted")
	}
	for _, row := range append(append(rootLogs, parentLogs...), childLogs...) {
		require.Empty(t, originAttr(row.Attributes), "routing-only log origin must not be persisted")
	}

	// Incoming OTLP/cloud telemetry has no emission context. Its authenticated
	// client record, not a payload attribute, selects the route.
	require.NoError(t, (originSpanExporter{origin: "parent", next: sess.spanExporter}).ExportSpans(
		t.Context(), []sdktrace.ReadOnlySpan{childSpans[0].ReadOnly()}))
	incomingLog := sdklog.Record{}
	incomingLog.AddAttributes(otellog.String(telemetryattrs.TelemetryOriginClientIDAttr, "child"))
	require.NoError(t, (originLogExporter{origin: "parent", next: sess.logExporter}).Export(
		t.Context(), []sdklog.Record{incomingLog}))
	incomingMetrics := &metricdata.ResourceMetrics{ScopeMetrics: []metricdata.ScopeMetrics{{
		Metrics: []metricdata.Metrics{{
			Name: "incoming",
			Data: metricdata.Gauge[int64]{DataPoints: []metricdata.DataPoint[int64]{{
				Attributes: attribute.NewSet(attribute.String(telemetryattrs.TelemetryOriginClientIDAttr, "child")),
				Value:      1,
			}}},
		}},
	}}}
	require.NoError(t, (clientMetricExporter{record: parent.clientRecord, ps: srv.telemetryPubSub}).Export(t.Context(), incomingMetrics))
	rootSpans, rootLogs, rootMetrics = load("root")
	parentSpans, parentLogs, parentMetrics = load("parent")
	childSpans, childLogs, childMetrics = load("child")
	require.Equal(t, 3, countSpan(rootSpans, childSpanID))
	require.Equal(t, 3, countSpan(parentSpans, childSpanID))
	require.Equal(t, 2, countSpan(childSpans, childSpanID))
	require.Len(t, rootLogs, 3)
	require.Len(t, parentLogs, 2)
	require.Len(t, childLogs, 1)
	require.Equal(t, 3, metricPointCount(rootMetrics))
	require.Equal(t, 2, metricPointCount(parentMetrics))
	require.Equal(t, 1, metricPointCount(childMetrics))
	require.Empty(t, originAttr(rootLogs[len(rootLogs)-1].Attributes))

	require.Equal(t, 0, dbs.OpenStats().Stores, "exports and reads must release DB handles")

	srv.daggerSessions = map[string]*daggerSession{sess.sessionID: sess}
	sess.state.Store(sessionStateInitialized)
	snapshot := srv.ClientLifecycleDebugSnapshot()
	require.Equal(t, 1, snapshot.Providers.TracerProviders)
	require.Equal(t, 1, snapshot.Providers.LoggerProviders)
	require.Equal(t, 3, snapshot.Providers.MeterProviders)
	require.Equal(t, 3, snapshot.Providers.ConfiguredMetricReaders)
	require.Equal(t, enginetel.LargeSpanQueueSize, snapshot.Providers.ConfiguredSpanQueueSlots)
	require.Equal(t, enginetel.LogQueueSize, snapshot.Providers.ConfiguredLogQueueSlots)
	for _, clientSnapshot := range snapshot.Sessions[0].Clients {
		require.Equal(t, 1, clientSnapshot.Telemetry.MeterProviders)
		require.Equal(t, 1, clientSnapshot.Telemetry.ConfiguredMetricReaders)
	}
}

func TestClientRegistrationRequiresValidExplicitAncestry(t *testing.T) {
	t.Parallel()

	root := &clientRuntime{clientRecord: &clientRecord{clientID: "root"}}
	otherRoot := &clientRuntime{clientRecord: &clientRecord{clientID: "other-root"}}
	child := &clientRuntime{clientRecord: &clientRecord{clientID: "child", parentClientIDs: []string{"root"}}}
	sess := &daggerSession{clientRuntimes: map[string]*clientRuntime{
		root.clientID:      root,
		otherRoot.clientID: otherRoot,
		child.clientID:     child,
	}}
	installTestClientRecords(sess)

	parentIDs, err := sess.parentClientIDsForRegistration("new-root", "", true)
	require.NoError(t, err)
	require.Empty(t, parentIDs)

	_, err = sess.parentClientIDsForRegistration("implicit-root", "", false)
	require.ErrorContains(t, err, "missing parent client ID")

	_, err = sess.parentClientIDsForRegistration("nested", "missing", false)
	require.ErrorContains(t, err, `parent client "missing" not found`)

	_, err = sess.parentClientIDsForRegistration("cycle", "cycle", false)
	require.ErrorContains(t, err, "ancestry cycle")

	_, err = sess.parentClientIDsForRegistration("child", "other-root", false)
	require.ErrorContains(t, err, "different parent ancestry")

	_, err = sess.parentClientIDsForRegistration("child", "", true)
	require.ErrorContains(t, err, "different parent ancestry")
}

func TestClientRegistrationRejectsInvalidParentRoute(t *testing.T) {
	t.Parallel()

	root := &clientRuntime{clientRecord: &clientRecord{clientID: "root"}}
	broken := &clientRuntime{clientRecord: &clientRecord{clientID: "broken", parentClientIDs: []string{"missing"}}}
	sess := &daggerSession{clientRuntimes: map[string]*clientRuntime{
		root.clientID:   root,
		broken.clientID: broken,
	}}
	installTestClientRecords(sess)

	_, err := sess.parentClientIDsForRegistration("child", "broken", false)
	require.ErrorContains(t, err, `ancestor client "missing" not found`)

	broken.parentClientIDs = []string{"root", "root"}
	_, err = sess.parentClientIDsForRegistration("child", "broken", false)
	require.ErrorContains(t, err, "reaches \"root\" more than once")
}

func TestLifecycleDebugAndRouteLookupConcurrentClientMutation(t *testing.T) {
	t.Parallel()

	root := &clientRuntime{clientRecord: &clientRecord{clientID: "root"}, state: clientStateInitialized}
	sess := &daggerSession{
		sessionID:          "session",
		mainClientCallerID: root.clientID,
		clientRuntimes:     map[string]*clientRuntime{root.clientID: root},
	}
	root.daggerSession = sess
	installTestClientRecords(sess)
	sess.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}

	ctx, cancel := context.WithCancel(context.Background())
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			select {
			case <-ctx.Done():
				return
			default:
			}
			child := &clientRuntime{clientRecord: &clientRecord{
				clientID:        "transient",
				daggerSession:   sess,
				parentClientIDs: []string{root.clientID}},
				state: clientStateInitialized}
			sess.clientMu.Lock()
			sess.clientRecords[child.clientID] = child.clientRecord
			sess.clientRuntimes[child.clientID] = child
			sess.clientMu.Unlock()
			_, _ = sess.telemetryRouteClientIDs(child.clientRecord)
			sess.clientMu.Lock()
			delete(sess.clientRecords, child.clientID)
			delete(sess.clientRuntimes, child.clientID)
			sess.clientMu.Unlock()
		}
	}()

	for range 1000 {
		snapshot := srv.ClientLifecycleDebugSnapshot()
		require.Len(t, snapshot.Sessions, 1)
		got, err := srv.clientRecordFromIDs(sess.sessionID, root.clientID)
		require.NoError(t, err)
		route, err := sess.telemetryRouteClientIDs(got)
		require.NoError(t, err)
		require.Equal(t, []string{root.clientID}, route)
	}
	cancel()
	wg.Wait()
}

type fakeSessionCaller struct {
	id   string
	conn *grpc.ClientConn
}

func TestLogRecordRowPreservesBytesBody(t *testing.T) {
	payload := []byte{0, 1, 2, 0xff}
	var record sdklog.Record
	record.SetBody(otellog.BytesValue(payload))

	row, err := logRecordRow(&record)
	require.NoError(t, err)

	var body otlpcommonv1.AnyValue
	require.NoError(t, proto.Unmarshal(row.Body, &body))
	require.Equal(t, payload, body.GetBytesValue())
}

// A record carrying invalid UTF-8 must not sink its batch. The LLM HTTP span
// logs its request body cut at a byte limit, which can split a character;
// protobuf refuses such a string, and the failed batch used to take the
// records exported beside it -- the agent's prompt, emitted just before the
// request -- down with it.
func TestTelemetryExportKeepsBatchWithInvalidUTF8(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	ps := &PubSub{srv: &Server{clientDBs: dbs}}

	cut := "request body — truncated"[:len("request body ")+1] // mid em dash
	require.False(t, utf8.ValidString(cut))
	records := []sdklog.Record{
		scopedLogRecord(t, "test", otellog.StringValue("the user's prompt")),
		scopedLogRecord(t, "test", otellog.StringValue(cut)),
		scopedLogRecord(t, "test",
			otellog.MapValue(otellog.String("nested", cut), otellog.Slice("list", otellog.StringValue(cut))),
			otellog.String(cut, cut)),
	}
	require.NoError(t, ps.Logs("client").Export(t.Context(), records))

	db, err := dbs.Open(t.Context(), "client")
	require.NoError(t, err)
	defer db.Close()
	rows, err := db.SelectLogsSince(t.Context(), clientdb.SelectLogsSinceParams{ID: 0, Limit: 10})
	require.NoError(t, err)
	require.Len(t, rows, len(records))

	var body otlpcommonv1.AnyValue
	require.NoError(t, proto.Unmarshal(rows[0].Body, &body))
	require.Equal(t, "the user's prompt", body.GetStringValue())
	require.NoError(t, proto.Unmarshal(rows[1].Body, &body))
	require.Equal(t, "request body \uFFFD", body.GetStringValue())
	require.NoError(t, proto.Unmarshal(rows[2].Body, &body))
	for _, kv := range body.GetKvlistValue().GetValues() {
		switch kv.GetKey() {
		case "nested":
			require.Equal(t, "request body \uFFFD", kv.GetValue().GetStringValue())
		case "list":
			require.Equal(t, "request body \uFFFD", kv.GetValue().GetArrayValue().GetValues()[0].GetStringValue())
		default:
			t.Fatalf("unexpected key %q", kv.GetKey())
		}
	}
}

// validUTF8LogValue must hand back valid values as they were.
func TestValidUTF8LogValueKeepsValidValues(t *testing.T) {
	for _, v := range []otellog.Value{
		otellog.StringValue("plain — fine"),
		otellog.SliceValue(otellog.StringValue("a"), otellog.IntValue(1)),
		otellog.MapValue(otellog.String("k", "v")),
		otellog.BytesValue([]byte{0xff}),
	} {
		require.True(t, validUTF8LogValue(v).Equal(v), "%v", v)
	}
}

func TestTelemetryExportReleasesClientDBHandle(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	ps := &PubSub{srv: &Server{clientDBs: dbs}}

	records := []sdklog.Record{{}}
	require.NoError(t, ps.Logs("client").Export(t.Context(), records))
	stats := dbs.OpenStats()
	require.Zero(t, stats.Stores)
	require.Zero(t, stats.Streams)
	require.Zero(t, stats.Refs)
}

func (caller *fakeSessionCaller) Supports(string) bool {
	return false
}

func (caller *fakeSessionCaller) Conn() *grpc.ClientConn {
	return caller.conn
}

func TestTelemetryStreamFramesBatchesAndDrain(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	srv := &Server{clientDBs: dbs}
	ps := &PubSub{srv: srv}
	sess := &daggerSession{telemetryPubSub: ps}
	shutdownCh := make(chan struct{})
	close(shutdownCh)
	record := &clientRecord{
		daggerSession: sess,
		clientID:      "client",
		shutdownCh:    shutdownCh,
	}

	req := httptest.NewRequest(http.MethodGet, "/v1/logs", nil)
	req.Header.Set("Accept", enginetel.LiveContentType)
	req.Header.Set(enginetel.LiveCursorHeader, "4")
	resp := httptest.NewRecorder()
	err := ps.streamHandler(resp, req, record, func(_ context.Context, _ *clientdb.DB, since int64, _ int) (int64, proto.Message, int, error) {
		switch since {
		case 4, 5:
			next := since + 1
			return next, &collogspb.ExportLogsServiceRequest{
				ResourceLogs: []*otlplogsv1.ResourceLogs{{SchemaUrl: fmt.Sprintf("batch-%d", next)}},
			}, 1, nil
		default:
			return since, nil, 0, nil
		}
	})
	require.NoError(t, err)
	require.Equal(t, http.StatusOK, resp.Code)
	require.Equal(t, enginetel.LiveContentType, resp.Header().Get("Content-Type"))
	require.True(t, resp.Flushed)

	kind, cursor, payload, err := enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameHello, kind)
	require.Equal(t, int64(4), cursor, "hello frame carries the resume cursor")
	require.Nil(t, payload)

	for _, expectedCursor := range []int64{5, 6} {
		kind, cursor, payload, err := enginetel.ReadLiveFrame(resp.Body)
		require.NoError(t, err)
		require.Equal(t, enginetel.LiveFrameData, kind)
		require.Equal(t, expectedCursor, cursor)
		require.NotEmpty(t, payload)
		require.NotEqual(t, byte('{'), payload[0], "payload must be binary protobuf, not protojson")
		var batch collogspb.ExportLogsServiceRequest
		require.NoError(t, proto.Unmarshal(payload, &batch))
		require.Equal(t, fmt.Sprintf("batch-%d", expectedCursor), batch.ResourceLogs[0].SchemaUrl)
	}
	kind, cursor, payload, err = enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameTerminal, kind)
	require.Equal(t, int64(6), cursor)
	require.Nil(t, payload)
	require.Empty(t, resp.Body.Bytes())
}

func TestTelemetryStreamRejectsInvalidCursorAsBadRequest(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	ps := &PubSub{srv: &Server{clientDBs: dbs}}
	record := &clientRecord{
		daggerSession: &daggerSession{telemetryPubSub: ps},
		clientID:      "client",
		shutdownCh:    make(chan struct{}),
	}

	for _, cursor := range []string{"abc", "-1"} {
		req := httptest.NewRequest(http.MethodGet, "/v1/logs", nil)
		req.Header.Set("Accept", enginetel.LiveContentType)
		req.Header.Set(enginetel.LiveCursorHeader, cursor)
		resp := httptest.NewRecorder()
		fetched := false
		err := ps.streamHandler(resp, req, record, func(context.Context, *clientdb.DB, int64, int) (int64, proto.Message, int, error) {
			fetched = true
			return 0, nil, 0, nil
		})
		require.Error(t, err)
		require.False(t, fetched)
		// A malformed cursor never resolves on retry, so it must not be
		// reported as a 500 that the client treats as transient.
		var httpErr httpError
		require.ErrorAs(t, err, &httpErr)
		require.Equal(t, http.StatusBadRequest, httpErr.code)
	}
}

func TestTelemetryStreamDefaultsToLegacySSE(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	ps := &PubSub{srv: &Server{clientDBs: dbs}}
	shutdownCh := make(chan struct{})
	close(shutdownCh)
	record := &clientRecord{
		daggerSession: &daggerSession{telemetryPubSub: ps},
		clientID:      "client",
		shutdownCh:    shutdownCh,
	}

	rawBody := []byte{0, 1, 2, 0xff}
	req := httptest.NewRequest(http.MethodGet, "/v1/logs", nil)
	req.Header.Set(enginetel.LegacyLiveCursorHeader, "4")
	resp := httptest.NewRecorder()
	err := ps.streamHandler(resp, req, record, func(_ context.Context, _ *clientdb.DB, since int64, _ int) (int64, proto.Message, int, error) {
		if since != 4 {
			return since, nil, 0, nil
		}
		return 5, &collogspb.ExportLogsServiceRequest{
			ResourceLogs: []*otlplogsv1.ResourceLogs{{
				ScopeLogs: []*otlplogsv1.ScopeLogs{{
					LogRecords: []*otlplogsv1.LogRecord{{
						Body: &otlpcommonv1.AnyValue{Value: &otlpcommonv1.AnyValue_BytesValue{BytesValue: rawBody}},
					}},
				}},
			}},
		}, 1, nil
	})
	require.NoError(t, err)
	require.Equal(t, http.StatusOK, resp.Code)
	require.Equal(t, enginetel.LegacyLiveContentType, resp.Header().Get("Content-Type"))
	require.Equal(t, "keep-alive", resp.Header().Get("Connection"))
	require.True(t, resp.Flushed)

	reader := sse.NewReadCloser(io.NopCloser(resp.Body))
	event, err := reader.Next()
	require.NoError(t, err)
	require.Equal(t, "subscribed", event.Name)

	event, err = reader.Next()
	require.NoError(t, err)
	require.Equal(t, "logs", event.Name)
	require.Equal(t, "5", event.ID)
	var batch collogspb.ExportLogsServiceRequest
	require.NoError(t, protojson.Unmarshal(event.Data, &batch))
	require.Equal(t, rawBody, batch.ResourceLogs[0].ScopeLogs[0].LogRecords[0].Body.GetBytesValue())

	_, err = reader.Next()
	require.ErrorIs(t, err, io.EOF)
}

func TestTelemetryStreamSplitsOversizedBatchesAndProgresses(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	ps := &PubSub{srv: &Server{clientDBs: dbs}}
	shutdownCh := make(chan struct{})
	close(shutdownCh)
	record := &clientRecord{
		daggerSession: &daggerSession{telemetryPubSub: ps},
		clientID:      "client",
		shutdownCh:    shutdownCh,
	}

	batch := func(since int64, rows int) *collogspb.ExportLogsServiceRequest {
		logs := make([]*otlplogsv1.ResourceLogs, rows)
		for i := range logs {
			logs[i] = &otlplogsv1.ResourceLogs{
				SchemaUrl: fmt.Sprintf("row-%d-%s", since+int64(i)+1, strings.Repeat("x", 80)),
			}
		}
		return &collogspb.ExportLogsServiceRequest{ResourceLogs: logs}
	}
	maxPayloadSize := proto.Size(batch(0, 2))
	require.Greater(t, proto.Size(batch(0, 4)), maxPayloadSize)

	type fetchCall struct {
		since int64
		limit int
	}
	var calls []fetchCall
	fetcher := func(_ context.Context, _ *clientdb.DB, since int64, limit int) (int64, proto.Message, int, error) {
		calls = append(calls, fetchCall{since: since, limit: limit})
		remaining := 4 - int(since)
		if remaining == 0 {
			return since, nil, 0, nil
		}
		rows := min(limit, remaining)
		return since + int64(rows), batch(since, rows), rows, nil
	}

	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/v1/logs", nil)
	req.Header.Set("Accept", enginetel.LiveContentType)
	err := ps.streamHandlerWithPayloadLimit(
		resp,
		req,
		record,
		fetcher,
		maxPayloadSize,
	)
	require.NoError(t, err)
	require.Equal(t, []fetchCall{
		{since: 0, limit: otlpBatchSize},
		{since: 0, limit: 2},
		{since: 2, limit: otlpBatchSize},
		{since: 4, limit: otlpBatchSize},
		{since: 4, limit: otlpBatchSize},
	}, calls)

	kind, cursor, payload, err := enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameHello, kind)
	require.Equal(t, int64(0), cursor)
	require.Nil(t, payload)
	for _, expectedCursor := range []int64{2, 4} {
		kind, cursor, payload, err := enginetel.ReadLiveFrame(resp.Body)
		require.NoError(t, err)
		require.Equal(t, enginetel.LiveFrameData, kind)
		require.Equal(t, expectedCursor, cursor)
		require.LessOrEqual(t, len(payload), maxPayloadSize)
	}
	kind, cursor, payload, err = enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameTerminal, kind)
	require.Equal(t, int64(4), cursor)
	require.Nil(t, payload)
}

func TestTelemetryStreamSkipsSingleOversizedRow(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	ps := &PubSub{srv: &Server{clientDBs: dbs}}
	shutdownCh := make(chan struct{})
	close(shutdownCh)
	record := &clientRecord{
		daggerSession: &daggerSession{telemetryPubSub: ps},
		clientID:      "client",
		shutdownCh:    shutdownCh,
	}

	small := &collogspb.ExportLogsServiceRequest{
		ResourceLogs: []*otlplogsv1.ResourceLogs{{SchemaUrl: "small"}},
	}
	maxPayloadSize := proto.Size(small)
	var fetches []int64
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/v1/logs", nil)
	req.Header.Set("Accept", enginetel.LiveContentType)
	err := ps.streamHandlerWithPayloadLimit(
		resp,
		req,
		record,
		func(_ context.Context, _ *clientdb.DB, since int64, _ int) (int64, proto.Message, int, error) {
			fetches = append(fetches, since)
			switch since {
			case 0:
				// Row 1 can never fit in a frame; it stays in the DB, so the
				// stream must get past it rather than end on it.
				return 1, &collogspb.ExportLogsServiceRequest{
					ResourceLogs: []*otlplogsv1.ResourceLogs{{SchemaUrl: strings.Repeat("x", 100)}},
				}, 1, nil
			case 1:
				return 2, small, 1, nil
			default:
				return since, nil, 0, nil
			}
		},
		maxPayloadSize,
	)
	require.NoError(t, err)
	require.Equal(t, []int64{0, 1, 2, 2}, fetches, "an oversized row must be skipped, not refetched or fatal")

	kind, cursor, payload, err := enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameHello, kind)
	require.Equal(t, int64(0), cursor)
	require.Nil(t, payload)

	// The skipped row is announced as an empty frame so the client's cursor
	// moves past it and the terminal cursor check still holds.
	kind, cursor, payload, err = enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameData, kind)
	require.Equal(t, int64(1), cursor)
	require.Empty(t, payload)

	kind, cursor, payload, err = enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameData, kind)
	require.Equal(t, int64(2), cursor)
	var batch collogspb.ExportLogsServiceRequest
	require.NoError(t, proto.Unmarshal(payload, &batch))
	require.Equal(t, "small", batch.ResourceLogs[0].SchemaUrl)

	kind, cursor, payload, err = enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameTerminal, kind)
	require.Equal(t, int64(2), cursor)
	require.Nil(t, payload)
	require.Empty(t, resp.Body.Bytes())
}

// A fetch failure is usually transient and leaves the cursor valid, so the
// stream must end without a terminal error frame: the client then reconnects
// at its cursor instead of giving up on the signal for the rest of the run.
func TestTelemetryStreamInterruptsOnFetchError(t *testing.T) {
	dbs := clientdb.NewDBs(t.TempDir())
	ps := &PubSub{srv: &Server{clientDBs: dbs}}
	record := &clientRecord{
		daggerSession: &daggerSession{telemetryPubSub: ps},
		clientID:      "client",
		shutdownCh:    make(chan struct{}),
	}

	fetches := 0
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/v1/logs", nil)
	req.Header.Set("Accept", enginetel.LiveContentType)
	req.Header.Set(enginetel.LiveCursorHeader, "3")
	err := ps.streamHandler(resp, req, record, func(_ context.Context, _ *clientdb.DB, since int64, _ int) (int64, proto.Message, int, error) {
		fetches++
		if since == 3 {
			return 4, &collogspb.ExportLogsServiceRequest{
				ResourceLogs: []*otlplogsv1.ResourceLogs{{SchemaUrl: "batch-4"}},
			}, 1, nil
		}
		return 0, nil, 0, errors.New("database is locked")
	})
	require.NoError(t, err, "a committed stream must not surface an error for httpHandlerFunc to write into the body")
	require.Equal(t, http.StatusOK, resp.Code)
	require.Equal(t, 2, fetches)

	kind, cursor, _, err := enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameHello, kind)
	require.Equal(t, int64(3), cursor)

	kind, cursor, _, err = enginetel.ReadLiveFrame(resp.Body)
	require.NoError(t, err)
	require.Equal(t, enginetel.LiveFrameData, kind)
	require.Equal(t, int64(4), cursor)

	// No DTX1 (or terminal) frame: the connection just ends mid-stream, which
	// the client's ReadLiveFrame surfaces as a plain EOF and reconnects on.
	require.Empty(t, resp.Body.Bytes())
}

func TestActiveClientIDsConcurrentSessionClientMutation(t *testing.T) {
	t.Parallel()

	// Regression test: activeClientIDs must read sess.clientRecords under clientMu.
	// Without the lock, ranging the map while another goroutine writes it is a
	// fatal "concurrent map iteration and map write" (caught here under -race).
	sess := &daggerSession{
		clientRecords: map[string]*clientRecord{
			"client-a": {clientID: "client-a"},
		},
	}
	sess.state.Store(sessionStateInitialized)
	srv := &Server{
		daggerSessions: map[string]*daggerSession{
			"session-a": sess,
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	var wg sync.WaitGroup
	t.Cleanup(func() {
		cancel()
		wg.Wait()
	})

	started := make(chan struct{})
	wg.Add(1)
	go func() {
		defer wg.Done()
		close(started)

		for {
			select {
			case <-ctx.Done():
				return
			default:
			}

			sess.clientMu.Lock()
			sess.clientRecords["transient"] = &clientRecord{clientID: "transient"}
			delete(sess.clientRecords, "transient")
			sess.clientMu.Unlock()
		}
	}()
	<-started

	for i := 0; i < 1000; i++ {
		require.True(t, srv.activeClientIDs()["client-a"])
	}
}

func TestClientRecordFromIDsConcurrentSessionInitialization(t *testing.T) {
	t.Parallel()

	// Regression test: clientRecordFromIDs must read sess.state (atomically) and
	// sess.clientRecords (under clientMu) while another goroutine mutates them during
	// session initialization. Without that discipline this is a data race (caught
	// here under -race).
	sess := &daggerSession{}
	sess.state.Store(sessionStateUninitialized)
	srv := &Server{
		daggerSessions: map[string]*daggerSession{
			"session-a": sess,
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	var wg sync.WaitGroup
	t.Cleanup(func() {
		cancel()
		wg.Wait()
	})

	started := make(chan struct{})
	wg.Add(1)
	go func() {
		defer wg.Done()
		close(started)

		for {
			select {
			case <-ctx.Done():
				return
			default:
			}

			_, _ = srv.clientRecordFromIDs("session-a", "client-a")
		}
	}()
	<-started

	for i := 0; i < 1000; i++ {
		sess.clientMu.Lock()
		sess.clientRecords = map[string]*clientRecord{
			"client-a": {clientID: "client-a"},
		}
		sess.clientMu.Unlock()
		sess.state.Store(sessionStateInitialized)
		sess.state.Store(sessionStateUninitialized)
		sess.clientMu.Lock()
		sess.clientRecords = nil
		sess.clientMu.Unlock()
	}

	record := &clientRecord{clientID: "client-a", daggerSession: sess}
	sess.clientMu.Lock()
	sess.clientRecords = map[string]*clientRecord{
		record.clientID: record,
	}
	sess.clientMu.Unlock()
	sess.state.Store(sessionStateInitialized)

	got, err := srv.clientRecordFromIDs("session-a", record.clientID)
	require.NoError(t, err)
	require.Same(t, record, got)
}

func TestClientsDoesNotBlockWhileSessionLifecycleLocked(t *testing.T) {
	t.Parallel()

	// Regression for the >15s active-clients stall (Discord: "Session lock might
	// be causing unwanted session shutdowns"): Clients() must never acquire a
	// session's lifecycleMu. A session stuck initializing or tearing down holds
	// lifecycleMu for a long time (teardown has a 60s safeguard), but that must
	// not stall the active-clients API the cloud keepalive polls.
	live := &daggerSession{sessionID: "live", mainClientCallerID: "main-live"}
	live.state.Store(sessionStateInitialized)
	busy := &daggerSession{sessionID: "busy", mainClientCallerID: "main-busy"}
	busy.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{
		"live": live,
		"busy": busy,
	}}

	// Simulate an in-progress init/teardown holding busy's lifecycleMu.
	busy.lifecycleMu.Lock()
	defer busy.lifecycleMu.Unlock()

	done := make(chan []string, 1)
	go func() { done <- srv.Clients() }()

	select {
	case clients := <-done:
		require.ElementsMatch(t, []string{"main-live", "main-busy"}, clients)
	case <-time.After(10 * time.Second):
		t.Fatal("Clients() blocked while a session's lifecycleMu was held")
	}
}

func TestActiveClientIDsDoesNotBlockWhileSessionLifecycleLocked(t *testing.T) {
	t.Parallel()

	// activeClientIDs() (the client-DB GC ticker) must also never acquire a
	// session's lifecycleMu, for the same reason as Clients().
	live := &daggerSession{
		sessionID:     "live",
		clientRecords: map[string]*clientRecord{"c-live": {clientID: "c-live"}},
	}
	live.state.Store(sessionStateInitialized)
	busy := &daggerSession{
		sessionID:     "busy",
		clientRecords: map[string]*clientRecord{"c-busy": {clientID: "c-busy"}},
	}
	busy.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{
		"live": live,
		"busy": busy,
	}}

	busy.lifecycleMu.Lock()
	defer busy.lifecycleMu.Unlock()

	done := make(chan map[string]bool, 1)
	go func() { done <- srv.activeClientIDs() }()

	select {
	case keep := <-done:
		require.True(t, keep["c-live"], "expected live session's client to be kept")
		require.True(t, keep["c-busy"], "expected initialized busy session's client to be kept")
	case <-time.After(10 * time.Second):
		t.Fatal("activeClientIDs() blocked while a session's lifecycleMu was held")
	}
}

func TestGetOrInitClientReturnsFastForRemovedTombstone(t *testing.T) {
	t.Parallel()

	// A session mid-teardown holds lifecycleMu and is marked removed (a tombstone
	// left in the registry until cleanup completes). A same-id getOrInitClient
	// must bail immediately via the lock-free removed pre-check rather than block
	// on lifecycleMu for the (possibly ~60s) teardown.
	tombstone := &daggerSession{sessionID: "s", mainClientCallerID: "m"}
	tombstone.state.Store(sessionStateRemoved)
	srv := &Server{daggerSessions: map[string]*daggerSession{"s": tombstone}}

	// Hold lifecycleMu to simulate an in-progress teardown.
	tombstone.lifecycleMu.Lock()
	defer tombstone.lifecycleMu.Unlock()

	done := make(chan error, 1)
	go func() {
		_, _, err := srv.getOrInitClient(context.Background(), &ClientInitOpts{
			ClientMetadata: &engine.ClientMetadata{
				SessionID:         "s",
				ClientID:          "m",
				ClientSecretToken: "token",
			},
		})
		done <- err
	}()

	select {
	case err := <-done:
		var retryable flightcontrol.RetryableError
		require.ErrorAs(t, err, &retryable, "removed tombstone should yield a retryable error")
	case <-time.After(10 * time.Second):
		t.Fatal("getOrInitClient blocked on lifecycleMu for a removed tombstone")
	}
}

func TestClientRecordFromIDsStateGating(t *testing.T) {
	t.Parallel()

	// clientRecordFromIDs gates on the session's atomic lifecycle state without
	// ever taking lifecycleMu, and never returns a record whose session is not
	// usable.
	client := &clientRuntime{clientRecord: &clientRecord{clientID: "c"}}
	sess := &daggerSession{
		sessionID:      "s",
		clientRecords:  map[string]*clientRecord{"c": client.clientRecord},
		clientRuntimes: map[string]*clientRuntime{"c": client},
	}
	client.daggerSession = sess
	srv := &Server{daggerSessions: map[string]*daggerSession{"s": sess}}

	// uninitialized: not yet usable.
	sess.state.Store(sessionStateUninitialized)
	_, err := srv.clientRecordFromIDs("s", "c")
	require.ErrorContains(t, err, "not initialized")

	// removed: retryable not-found (session is tearing down).
	sess.state.Store(sessionStateRemoved)
	_, err = srv.clientRecordFromIDs("s", "c")
	var retryable flightcontrol.RetryableError
	require.ErrorAs(t, err, &retryable)

	// initialized: returns the client.
	sess.state.Store(sessionStateInitialized)
	got, err := srv.clientRecordFromIDs("s", "c")
	require.NoError(t, err)
	require.Same(t, client.clientRecord, got)
}

func TestSessionLifecycleObserverConcurrency(t *testing.T) {
	t.Parallel()

	// Stress the observer paths (Clients/activeClientIDs/clientRecordFromIDs) against
	// concurrent session churn. The churners exercise the observer-visible state
	// the way the real lifecycle does — registry writes under daggerSessionsMu,
	// the clients map under clientMu, the lifecycle state via the atomic, and a
	// pointer-conditional deleteSession on teardown — but deliberately do NOT take
	// lifecycleMu, since the whole point of the redesign is that observers don't
	// depend on it. Run under -race to catch data races; the observers must also
	// never block (completing while churn runs is the liveness assertion).
	srv := &Server{daggerSessions: map[string]*daggerSession{}}

	const (
		churners         = 4
		cyclesPerChurner = 1000
	)
	var wg sync.WaitGroup
	for i := range churners {
		wg.Add(1)
		go func(n int) {
			defer wg.Done()
			id := fmt.Sprintf("s%d", n)
			for range cyclesPerChurner {
				sess := &daggerSession{
					sessionID:          id,
					mainClientCallerID: "m" + id,
					clientRecords:      map[string]*clientRecord{},
					clientRuntimes:     map[string]*clientRuntime{},
				}
				// publish, then populate clients, then flip to initialized last.
				srv.daggerSessionsMu.Lock()
				srv.daggerSessions[id] = sess
				srv.daggerSessionsMu.Unlock()
				sess.clientMu.Lock()
				record := &clientRecord{clientID: "c", daggerSession: sess}
				sess.clientRecords[record.clientID] = record
				sess.clientRuntimes[record.clientID] = &clientRuntime{clientRecord: record}
				sess.clientMu.Unlock()
				sess.state.Store(sessionStateInitialized)

				// teardown: removed first, then pointer-conditional delete.
				sess.state.Store(sessionStateRemoved)
				srv.deleteSession(sess)
			}
		}(i)
	}

	churnDone := make(chan struct{})
	go func() {
		wg.Wait()
		close(churnDone)
	}()

	// Hammer the observers concurrently until every churner has finished its
	// fixed workload, so the race window is exercised deterministically rather
	// than depending on scheduler timing.
	for {
		select {
		case <-churnDone:
			return
		default:
		}
		_ = srv.Clients()
		_ = srv.activeClientIDs()
		_, _ = srv.clientRecordFromIDs("s0", "c")
	}
}

// newTeardownTestServer builds a Server with just enough real state for
// removeDaggerSession to run: an empty in-memory dagql cache, a live wcprof
// counter, and a stubbed GC callback (scheduled via time.AfterFunc at the end
// of teardown).
func newTeardownTestServer(t *testing.T) *Server {
	t.Helper()
	cache, err := dagql.NewCache(context.Background(), "", nil, nil)
	require.NoError(t, err)
	return &Server{
		daggerSessions:     map[string]*daggerSession{},
		releasedSessionIDs: map[string]struct{}{},
		engineCache:        cache,
		wcprofSpanCount:    newWcprofSpanCounter(),
		throttledSessionGC: func() {},
	}
}

type cleanupSpanMetricExporter struct {
	ctx      context.Context
	tracer   trace.Tracer
	exported chan<- struct{}
}

func (exp cleanupSpanMetricExporter) Export(context.Context, *metricdata.ResourceMetrics) error {
	if exp.exported != nil {
		select {
		case exp.exported <- struct{}{}:
		default:
		}
	}
	return nil
}
func (cleanupSpanMetricExporter) ForceFlush(context.Context) error { return nil }
func (exp cleanupSpanMetricExporter) Shutdown(context.Context) error {
	_, span := exp.tracer.Start(exp.ctx, "metric cleanup telemetry")
	span.End()
	return nil
}
func (cleanupSpanMetricExporter) Temporality(sdkmetric.InstrumentKind) metricdata.Temporality {
	return metricdata.DeltaTemporality
}
func (cleanupSpanMetricExporter) Aggregation(sdkmetric.InstrumentKind) sdkmetric.Aggregation {
	return sdkmetric.AggregationDefault{}
}

func TestSessionTeardownFlushesTraceTelemetryAfterMetricShutdown(t *testing.T) {
	srv := newTeardownTestServer(t)
	srv.clientDBs = clientdb.NewDBs(t.TempDir())
	srv.telemetryPubSub = NewPubSub(srv)

	md := &engine.ClientMetadata{SessionID: "session", ClientID: "main"}
	client := &clientRuntime{clientRecord: &clientRecord{clientID: "main", clientMetadata: md, shutdownCh: make(chan struct{})}}
	sess := &daggerSession{
		sessionID:          md.SessionID,
		mainClientCallerID: md.ClientID,
		clientRuntimes:     map[string]*clientRuntime{client.clientID: client},
		services:           core.NewServices(),
		analytics:          analytics.New(analytics.Config{DoNotTrack: true}),
		containers:         map[bkgw.Container]struct{}{},
		shutdownCh:         make(chan struct{}),
		telemetryPubSub:    srv.telemetryPubSub,
	}
	client.daggerSession = sess
	installTestClientRecords(sess)
	require.NoError(t, client.retainTelemetryDB(t.Context()))
	require.Equal(t, 1, srv.clientDBs.OpenStats().Refs)
	sess.dagqlCond = sync.NewCond(&sess.dagqlMu)
	sess.closingCtx, sess.cancelClosing = context.WithCancelCause(context.Background())
	srv.initializeSessionTelemetry(sess, nil)

	cleanupCtx := engine.ContextWithClientMetadata(context.Background(), md)
	exported := make(chan struct{}, 1)
	exporter := cleanupSpanMetricExporter{
		ctx:      cleanupCtx,
		tracer:   sess.tracerProvider.Tracer("test"),
		exported: exported,
	}
	client.meterProvider = sdkmetric.NewMeterProvider(sdkmetric.WithReader(
		sdkmetric.NewPeriodicReader(exporter, sdkmetric.WithInterval(time.Hour)),
	))
	gauge, err := client.meterProvider.Meter("test").Int64Gauge("cleanup.metric")
	require.NoError(t, err)
	gauge.Record(cleanupCtx, 1)
	sess.schemaBuilderMemo.Store(core.NewSchemaBuilderMemo())

	require.NoError(t, srv.removeDaggerSession(t.Context(), sess))
	require.Nil(t, sess.schemaBuilderMemo.Load(), "the session's schema memo is dropped with it")
	require.Nil(t, client.telemetryDB)
	require.Equal(t, clientdb.OpenStats{}, srv.clientDBs.OpenStats())
	select {
	case <-exported:
	default:
		t.Fatal("final session telemetry barrier did not flush metrics")
	}
	db, err := srv.clientDBs.Open(t.Context(), client.clientID)
	require.NoError(t, err)
	defer db.Close()
	spans, err := db.Read().SelectSpansSince(t.Context(), clientdb.SelectSpansSinceParams{Limit: 100})
	require.NoError(t, err)
	var liveSnapshots, completedSnapshots int
	for _, span := range spans {
		if span.Name == "metric cleanup telemetry" {
			if span.EndTime.Valid {
				completedSnapshots++
			} else {
				liveSnapshots++
			}
		}
	}
	require.Equal(t, 1, completedSnapshots,
		"the completed cleanup span must pass the final session flush")
	// The live snapshot may be coalesced with the completed one in the same batch.
	require.LessOrEqual(t, liveSnapshots, 1)
}

// newTeardownTestSession publishes an initialized session whose main client
// has the given number of active connections. dagqlInFlight starts at 1 so
// teardown deterministically blocks in the in-flight drain until
// releaseTeardownDrain is called.
func newTeardownTestSession(srv *Server, sessionID, mainClientID string, activeCount int) (*daggerSession, *clientRuntime) {
	client := &clientRuntime{clientRecord: &clientRecord{
		clientID: mainClientID},
		activeCount: activeCount}
	sess := &daggerSession{
		sessionID:          sessionID,
		mainClientCallerID: mainClientID,
		clientRuntimes:     map[string]*clientRuntime{mainClientID: client},
		services:           core.NewServices(),
		analytics:          analytics.New(analytics.Config{DoNotTrack: true}),
		shutdownCh:         make(chan struct{}),
	}
	client.daggerSession = sess
	installTestClientRecords(sess)
	sess.dagqlCond = sync.NewCond(&sess.dagqlMu)
	sess.dagqlInFlight = 1
	sess.closingCtx, sess.cancelClosing = context.WithCancelCause(context.Background())
	sess.state.Store(sessionStateInitialized)

	srv.daggerSessionsMu.Lock()
	srv.daggerSessions[sessionID] = sess
	srv.daggerSessionsMu.Unlock()
	return sess, client
}

func releaseTeardownDrain(sess *daggerSession) {
	sess.dagqlMu.Lock()
	sess.dagqlInFlight = 0
	sess.dagqlCond.Broadcast()
	sess.dagqlMu.Unlock()
}

func sessionInRegistry(srv *Server, sessionID string) bool {
	srv.daggerSessionsMu.RLock()
	defer srv.daggerSessionsMu.RUnlock()
	_, ok := srv.daggerSessions[sessionID]
	return ok
}

func sessionIDReleased(srv *Server, sessionID string) bool {
	srv.daggerSessionsMu.RLock()
	defer srv.daggerSessionsMu.RUnlock()
	_, ok := srv.releasedSessionIDs[sessionID]
	return ok
}

// newStrandedTeardownSession builds a teardown-capable session whose main
// client holds one lease that the test controls, standing in for a producer
// that never reaches its terminal transition.
func newStrandedTeardownSession(t *testing.T, srv *Server, sessionID string) (*daggerSession, engine.ClientScope) {
	t.Helper()
	md := &engine.ClientMetadata{SessionID: sessionID, ClientID: "main"}
	client := &clientRuntime{
		clientRecord: &clientRecord{
			clientID:       md.ClientID,
			clientMetadata: md,
			metadataSealed: true,
			accepting:      true,
			shutdownCh:     make(chan struct{}),
		},
		state:           clientStateInitialized,
		lifecycleLeases: make(map[uint64]clientLifecycleLeaseRecord),
	}
	sess := &daggerSession{
		sessionID:          md.SessionID,
		mainClientCallerID: md.ClientID,
		clientRuntimes:     map[string]*clientRuntime{client.clientID: client},
		services:           core.NewServices(),
		analytics:          analytics.New(analytics.Config{DoNotTrack: true}),
		containers:         map[bkgw.Container]struct{}{},
		shutdownCh:         make(chan struct{}),
		telemetryPubSub:    srv.telemetryPubSub,
	}
	client.daggerSession = sess
	installTestClientRecords(sess)
	sess.dagqlCond = sync.NewCond(&sess.dagqlMu)
	sess.closingCtx, sess.cancelClosing = context.WithCancelCause(context.Background())
	sess.state.Store(sessionStateInitialized)
	srv.initializeSessionTelemetry(sess, nil)

	stranded, err := sess.acquireRootClientScope(client, engine.ClientLeaseSharedWork, "stuck callback")
	require.NoError(t, err)
	return sess, stranded
}

func TestSessionTeardownHonorsCallerDeadlineForStrandedLease(t *testing.T) {
	srv := newTeardownTestServer(t)
	srv.clientDBs = clientdb.NewDBs(t.TempDir())
	srv.telemetryPubSub = NewPubSub(srv)

	// Engine graceful stop passes a deadline. A producer that never releases
	// must not hold the engine past it.
	bounded, stranded := newStrandedTeardownSession(t, srv, "bounded")
	deadlineCtx, cancel := context.WithTimeout(t.Context(), 500*time.Millisecond)
	defer cancel()
	done := make(chan error, 1)
	go func() { done <- srv.removeDaggerSession(deadlineCtx, bounded) }()
	select {
	case err := <-done:
		require.ErrorContains(t, err, "wait for client scopes")
	case <-time.After(10 * time.Second):
		t.Fatal("teardown ignored the caller's deadline while a lease was stranded")
	}
	stranded.Lease().Release()

	// A reap passes no deadline and must keep waiting for the producer.
	unbounded, stranded := newStrandedTeardownSession(t, srv, "unbounded")
	done = make(chan error, 1)
	go func() { done <- srv.removeDaggerSession(context.Background(), unbounded) }()
	select {
	case err := <-done:
		t.Fatalf("teardown returned before the stranded lease released: %v", err)
	case <-time.After(300 * time.Millisecond):
	}
	stranded.Lease().Release()
	select {
	case err := <-done:
		require.NoError(t, err)
	case <-time.After(10 * time.Second):
		t.Fatal("teardown did not complete after the stranded lease released")
	}
}

func TestMainClientLastDisconnectDoesNotBlockOnTeardown(t *testing.T) {
	t.Parallel()

	// Regression for the client-side `shutdown: ... context deadline exceeded`
	// timeout: the main client's last connection cleanup runs in the request
	// handler before the /shutdown response is flushed, so it must only
	// SCHEDULE teardown, never run it. Teardown here is deterministically
	// blocked in the in-flight dagql drain; the cleanup must return anyway.
	srv := newTeardownTestServer(t)
	sess, client := newTeardownTestSession(srv, "s", "m", 1)

	done := make(chan error, 1)
	go func() {
		srv.releaseClientConnection(context.Background(), sess, client)
		done <- nil
	}()
	select {
	case err := <-done:
		require.NoError(t, err)
	case <-time.After(10 * time.Second):
		t.Fatal("last-connection cleanup blocked on session teardown")
	}

	// The background reap marks the session removed (tombstone) but stays
	// blocked in the drain, so the registry entry must survive for now.
	require.Eventually(t, func() bool {
		return sess.state.Load() == sessionStateRemoved
	}, 10*time.Second, 10*time.Millisecond, "background teardown never started")
	require.True(t, sessionInRegistry(srv, "s"), "tombstone dropped before teardown finished")

	releaseTeardownDrain(sess)

	require.Eventually(t, func() bool {
		return !sessionInRegistry(srv, "s")
	}, 10*time.Second, 10*time.Millisecond, "session never finished background teardown")
	require.True(t, sessionIDReleased(srv, "s"))
	select {
	case <-sess.shutdownCh:
	case <-time.After(10 * time.Second):
		t.Fatal("session shutdownCh never closed by background teardown")
	}
}

func TestSameIDConnectDuringBackgroundTeardownGetsRetryable(t *testing.T) {
	t.Parallel()

	// While a background reap is mid-teardown (removed tombstone in the
	// registry, lifecycleMu held), a same-id getOrInitClient must bail out
	// fast with a retryable error instead of blocking on the teardown.
	srv := newTeardownTestServer(t)
	sess, client := newTeardownTestSession(srv, "s", "m", 1)

	srv.releaseClientConnection(context.Background(), sess, client)
	require.Eventually(t, func() bool {
		return sess.state.Load() == sessionStateRemoved
	}, 10*time.Second, 10*time.Millisecond)

	done := make(chan error, 1)
	go func() {
		_, _, err := srv.getOrInitClient(context.Background(), &ClientInitOpts{
			ClientMetadata: &engine.ClientMetadata{
				SessionID:         "s",
				ClientID:          "m",
				ClientSecretToken: "token",
			},
		})
		done <- err
	}()
	select {
	case err := <-done:
		var retryable flightcontrol.RetryableError
		require.ErrorAs(t, err, &retryable)
	case <-time.After(10 * time.Second):
		t.Fatal("same-id getOrInitClient blocked on background teardown")
	}
	require.False(t, sessionIDReleased(srv, "s"), "session ID retired before teardown completed")

	releaseTeardownDrain(sess)
	require.Eventually(t, func() bool {
		return !sessionInRegistry(srv, "s") && sessionIDReleased(srv, "s")
	}, 10*time.Second, 10*time.Millisecond)

	_, _, err := srv.getOrInitClient(context.Background(), &ClientInitOpts{
		ClientMetadata: &engine.ClientMetadata{
			SessionID:         "s",
			ClientID:          "m",
			ClientSecretToken: "token",
		},
	})
	require.ErrorContains(t, err, "already used and released")
	var retryable flightcontrol.RetryableError
	require.False(t, errors.As(err, &retryable))
}

func TestReapAbandonedWhenMainClientReconnects(t *testing.T) {
	t.Parallel()

	// A new main-client connection can land between the last disconnect and
	// the scheduled reap running. The reap re-checks activeCount under
	// lifecycleMu and must leave the now-live session alone.
	srv := newTeardownTestServer(t)
	sess, client := newTeardownTestSession(srv, "s", "m", 1)

	// Simulate the reconnect winning the race: activeCount is back above zero
	// by the time the reap runs.
	client.stateMu.Lock()
	client.activeCount = 1
	client.stateMu.Unlock()

	srv.reapDaggerSession(context.Background(), sess, client)

	require.Equal(t, sessionStateInitialized, sess.state.Load())
	require.True(t, sessionInRegistry(srv, "s"))
	require.False(t, sessionIDReleased(srv, "s"))
	select {
	case <-sess.shutdownCh:
		t.Fatal("reap tore down a session with a live main client")
	default:
	}
}

func TestFailedSessionInitializationCanRetrySameID(t *testing.T) {
	t.Parallel()

	srv := &Server{
		daggerSessions:     map[string]*daggerSession{},
		releasedSessionIDs: map[string]struct{}{},
	}
	srv.daggerSessionsMu.Lock()
	failed, created, err := srv.getOrCreateSessionLocked("s", "m")
	srv.daggerSessionsMu.Unlock()
	require.NoError(t, err)
	require.True(t, created)

	// This is the getOrInitClient failed-initialization cleanup: publish removed,
	// release lifecycleMu, then delete without retiring the ID.
	failed.state.Store(sessionStateRemoved)
	failed.lifecycleMu.Unlock()
	srv.deleteSession(failed)
	require.False(t, sessionIDReleased(srv, "s"))

	srv.daggerSessionsMu.Lock()
	retry, created, err := srv.getOrCreateSessionLocked("s", "m")
	srv.daggerSessionsMu.Unlock()
	require.NoError(t, err)
	require.True(t, created)
	require.NotSame(t, failed, retry)
	retry.lifecycleMu.Unlock()
	srv.deleteSession(retry)
}

func TestConcurrentReapsSingleTeardown(t *testing.T) {
	t.Parallel()

	// Duplicate reaps can be scheduled (disconnect, reconnect, disconnect).
	// Whichever acquires lifecycleMu first tears down; the loser must observe
	// the removed state and no-op (double teardown would double-close
	// shutdownCh and panic).
	srv := newTeardownTestServer(t)
	sess, client := newTeardownTestSession(srv, "s", "m", 0)

	var wg sync.WaitGroup
	for range 2 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			srv.reapDaggerSession(context.Background(), sess, client)
		}()
	}

	require.Eventually(t, func() bool {
		return sess.state.Load() == sessionStateRemoved
	}, 10*time.Second, 10*time.Millisecond)
	releaseTeardownDrain(sess)
	wg.Wait()

	require.False(t, sessionInRegistry(srv, "s"))
	select {
	case <-sess.shutdownCh:
	default:
		t.Fatal("session shutdownCh not closed after teardown")
	}
}

func TestPendingLegacyModule(t *testing.T) {
	t.Parallel()

	ws := &workspace.Workspace{Root: "/repo", Cwd: "."}
	resolveLocalRef := func(_ *workspace.Workspace, relPath string) string {
		return "/resolved/" + relPath
	}

	t.Run("preserves remote pin", func(t *testing.T) {
		t.Parallel()

		mod := pendingLegacyModule(
			ws,
			resolveLocalRef,
			"go",
			"github.com/acme/go-toolchain@main",
			"abc123",
			false,
			map[string]any{"foo": "bar"},
			[]*modules.ModuleConfigArgument{{
				Argument:    "config",
				DefaultPath: "./custom-config.txt",
			}},
		)

		require.Equal(t, "github.com/acme/go-toolchain@main", mod.Ref)
		require.Equal(t, "abc123", mod.RefPin)
		require.Equal(t, "go", mod.Name)
		require.False(t, mod.Entrypoint)
		require.True(t, mod.LegacyDefaultPath)
		require.Equal(t, "/resolved/.", mod.DefaultPathContextSourceRef)
		require.Equal(t, map[string]any{"foo": "bar"}, mod.ConfigDefaults)
		require.Len(t, mod.ArgCustomizations, 1)
		require.Equal(t, "./custom-config.txt", mod.ArgCustomizations[0].DefaultPath)
	})

	t.Run("resolves local refs without ref pin", func(t *testing.T) {
		t.Parallel()

		mod := pendingLegacyModule(
			ws,
			resolveLocalRef,
			"blueprint",
			"../blueprint",
			"",
			true,
			nil,
			nil,
		)

		require.Equal(t, "/resolved/../blueprint", mod.Ref)
		require.Empty(t, mod.RefPin)
		require.Equal(t, "blueprint", mod.Name)
		require.True(t, mod.Entrypoint)
		require.True(t, mod.LegacyDefaultPath)
		require.Equal(t, "/resolved/.", mod.DefaultPathContextSourceRef)
		require.Nil(t, mod.ConfigDefaults)
	})
}

func TestFilterPendingWorkspaceModulesForRootFields(t *testing.T) {
	t.Parallel()

	mods := []pendingModule{
		{Kind: moduleLoadKindAmbient, Name: "foo", Entrypoint: false},
		{Kind: moduleLoadKindAmbient, Name: "bar-baz", Entrypoint: true},
		{Kind: moduleLoadKindAmbient, Name: "local", Entrypoint: true},
	}

	t.Run("constructor match loads only matching module", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"foo"})
		require.Equal(t, []pendingModule{mods[0]}, filtered)
	})

	t.Run("unknown root field with multiple entrypoints loads all", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"doThing"})
		require.Equal(t, mods, filtered)
	})

	t.Run("unknown root field with one entrypoint loads entrypoint", func(t *testing.T) {
		t.Parallel()

		oneEntrypoint := []pendingModule{mods[0], mods[1]}
		filtered := filterPendingWorkspaceModulesForRootFields(oneEntrypoint, nil, nil, []string{"doThing"})
		require.Equal(t, []pendingModule{mods[1]}, filtered)
	})

	t.Run("unknown root field skips entrypoint already recorded as failed", func(t *testing.T) {
		t.Parallel()

		oneEntrypoint := []pendingModule{mods[0], mods[1]}
		failed := map[string]error{"bar-baz": errors.New("boom")}
		filtered := filterPendingWorkspaceModulesForRootFields(oneEntrypoint, nil, failed, []string{"doThing"})
		require.Empty(t, filtered)
	})

	t.Run("named root field still selects a failed module", func(t *testing.T) {
		t.Parallel()

		failed := map[string]error{"foo": errors.New("boom")}
		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, failed, []string{"foo"})
		require.Equal(t, []pendingModule{mods[0]}, filtered)
	})

	t.Run("introspection loads all", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"__schema"})
		require.Equal(t, mods, filtered)
	})

	t.Run("current typedefs loads all", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"currentTypeDefs"})
		require.Equal(t, mods, filtered)
	})

	t.Run("current module loads all", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"currentModule"})
		require.Equal(t, mods, filtered)
	})

	t.Run("core-only query loads none", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"container", "version"})
		require.Empty(t, filtered)
	})

	t.Run("current workspace loads none (resolvers load on demand)", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"currentWorkspace"})
		require.Empty(t, filtered)
	})

	t.Run("already-served root field loads none", func(t *testing.T) {
		t.Parallel()

		served := map[string]struct{}{"my-mod": {}}
		filtered := filterPendingWorkspaceModulesForRootFields(mods, served, nil, []string{"myMod"})
		require.Empty(t, filtered)
	})

	t.Run("served field combined with pending field loads only pending", func(t *testing.T) {
		t.Parallel()

		served := map[string]struct{}{"my-mod": {}}
		filtered := filterPendingWorkspaceModulesForRootFields(mods, served, nil, []string{"myMod", "foo"})
		require.Equal(t, []pendingModule{mods[0]}, filtered)
	})

	t.Run("env loads all (resolver snapshots served deps)", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"env"})
		require.Equal(t, mods, filtered)
	})

	t.Run("unrecognized loadFromID field loads all", func(t *testing.T) {
		t.Parallel()

		// The type name in load<Type>FromID needn't embed the module name, so
		// only a full load can guarantee the field exists.
		filtered := filterPendingWorkspaceModulesForRootFields(mods, nil, nil, []string{"loadSomethingFromID"})
		require.Equal(t, mods, filtered)
	})
}

func TestFilterPendingWorkspaceModulesForScopedRootFields(t *testing.T) {
	t.Parallel()

	foo := pendingModule{Kind: moduleLoadKindAmbient, Name: "foo"}
	barBaz := pendingModule{Kind: moduleLoadKindAmbient, Name: "barBaz"}
	entry := pendingModule{Kind: moduleLoadKindAmbient, Name: "entry", Entrypoint: true}
	mods := []pendingModule{foo, barBaz, entry}

	t.Run("no scope delegates to root-field demand", func(t *testing.T) {
		t.Parallel()

		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, nil, nil, []string{"currentTypeDefs"}, "", false)
		require.False(t, applied)
		require.Equal(t, mods, selected)
	})

	t.Run("scoped typedefs loads target plus entrypoint", func(t *testing.T) {
		t.Parallel()

		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, nil, nil, []string{"currentTypeDefs"}, "foo", false)
		require.True(t, applied)
		require.Equal(t, []pendingModule{foo, entry}, selected)
	})

	t.Run("kebab-case token matches declared module name", func(t *testing.T) {
		t.Parallel()

		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, nil, nil, []string{"currentTypeDefs"}, "bar-baz", false)
		require.True(t, applied)
		require.Equal(t, []pendingModule{barBaz, entry}, selected)
	})

	t.Run("unknown token loads pending entrypoint alone", func(t *testing.T) {
		t.Parallel()

		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, nil, nil, []string{"currentTypeDefs"}, "greet", false)
		require.True(t, applied)
		require.Equal(t, []pendingModule{entry}, selected)
	})

	t.Run("unknown token without entrypoint loads all", func(t *testing.T) {
		t.Parallel()

		noEntry := []pendingModule{foo, barBaz}
		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(noEntry, nil, nil, []string{"currentTypeDefs"}, "greet", false)
		require.True(t, applied)
		require.Equal(t, noEntry, selected)
	})

	t.Run("another full-schema field loads all without consuming", func(t *testing.T) {
		t.Parallel()

		for _, field := range []string{"env", "__schema", "currentModule"} {
			selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, nil, nil, []string{"currentTypeDefs", field}, "foo", false)
			require.False(t, applied, field)
			require.Equal(t, mods, selected, field)
		}
	})

	t.Run("no typedefs field delegates without consuming", func(t *testing.T) {
		t.Parallel()

		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, nil, nil, []string{"foo"}, "barBaz", false)
		require.False(t, applied)
		require.Equal(t, []pendingModule{foo}, selected)
	})

	t.Run("typedefs plus module field unions both demands", func(t *testing.T) {
		t.Parallel()

		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, nil, nil, []string{"currentTypeDefs", "foo"}, "bar-baz", false)
		require.True(t, applied)
		require.Equal(t, []pendingModule{foo, barBaz, entry}, selected)
	})

	t.Run("served target contributes nothing to load", func(t *testing.T) {
		t.Parallel()

		served := map[string]struct{}{"my-mod": {}}
		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(mods, served, nil, []string{"currentTypeDefs"}, "myMod", false)
		require.True(t, applied)
		require.Equal(t, []pendingModule{entry}, selected)
	})

	t.Run("unknown token with served entrypoint loads no siblings", func(t *testing.T) {
		t.Parallel()

		// A prior selective request may have loaded the entrypoint without
		// consuming the scope. The later typedefs request is then already
		// satisfied by that served entrypoint and must not fall back to every
		// still-pending workspace module.
		served := map[string]struct{}{"entry": {}}
		pending := []pendingModule{foo, barBaz}
		selected, applied := filterPendingWorkspaceModulesForScopedRootFields(pending, served, nil, []string{"currentTypeDefs"}, "greet", true)
		require.True(t, applied)
		require.Empty(t, selected)
	})
}

func TestEnsureRequestModulesLoadedSkipsAutomaticWorkspaceModules(t *testing.T) {
	for _, md := range []*engine.ClientMetadata{
		{},
		{LoadWorkspaceModules: true, SkipWorkspaceModules: true},
	} {
		client := &clientRuntime{
			clientRecord:         &clientRecord{clientMetadata: md},
			pendingWorkspaceLoad: true,
			pendingModules:       []pendingModule{{Kind: moduleLoadKindAmbient, Name: "unloaded"}},
		}
		req := httptest.NewRequest(http.MethodPost, engine.QueryEndpoint, strings.NewReader(`{"query":"{ __schema { types { name } } }"}`))
		req.Header.Set("Content-Type", "application/json")
		err := (&Server{}).ensureRequestModulesLoaded(context.Background(), client, req)
		require.NoError(t, err)
		require.Len(t, client.pendingModules, 1)
		require.Equal(t, "unloaded", client.pendingModules[0].Name)
	}
}

func TestEnsureRequestModulesLoadedConsumesScopeBeforeUnlock(t *testing.T) {
	client := &clientRuntime{clientRecord: &clientRecord{
		clientID: "client",
		clientMetadata: &engine.ClientMetadata{
			LoadWorkspaceModules: true,
			WorkspaceModuleScope: "good",
		}},
		pendingWorkspaceLoad: true,
		pendingModules: []pendingModule{
			{Kind: moduleLoadKindAmbient, Name: "bad"},
		},
		servedWorkspaceModuleNames: map[string]struct{}{"good": {}}}
	req := httptest.NewRequest(http.MethodPost, engine.QueryEndpoint, strings.NewReader(`{"query":"{ currentTypeDefs { name } }"}`))
	req.Header.Set("Content-Type", "application/json")

	postLoad := make(chan struct{})
	resume := make(chan struct{})
	var resumeOnce sync.Once
	release := func() { resumeOnce.Do(func() { close(resume) }) }
	t.Cleanup(release)

	loadDone := make(chan error, 1)
	go func() {
		loadDone <- (&Server{}).ensureRequestModulesLoadedWithPostLoad(context.Background(), client, req, func() {
			close(postLoad)
			<-resume
		})
	}()

	select {
	case <-postLoad:
	case <-time.After(10 * time.Second):
		t.Fatal("module loading did not return")
	}

	client.modulesMu.Lock()
	observedScope := client.pendingWorkspaceModuleScopeLocked()
	client.modulesMu.Unlock()

	release()
	require.Empty(t, observedScope, "the one-shot scope was visible after the successful load released modulesMu")
	select {
	case err := <-loadDone:
		require.NoError(t, err)
	case <-time.After(10 * time.Second):
		t.Fatal("request module loading did not finish")
	}
}

func TestWithRequestTelemetrySuppression(t *testing.T) {
	t.Parallel()

	req := httptest.NewRequest(http.MethodPost, engine.QueryEndpoint, nil)
	ctx, suppressed := withRequestTelemetrySuppression(context.Background(), req)
	require.False(t, suppressed)
	require.False(t, dagql.IsSkipped(ctx))

	req.Header.Set(engine.SuppressTelemetryHeader, "false")
	ctx, suppressed = withRequestTelemetrySuppression(context.Background(), req)
	require.False(t, suppressed)
	require.False(t, dagql.IsSkipped(ctx))

	req.Header.Set(engine.SuppressTelemetryHeader, "true")
	ctx, suppressed = withRequestTelemetrySuppression(context.Background(), req)
	require.True(t, suppressed)
	require.True(t, dagql.IsSkipped(ctx), "the suppressed request's context must carry the dagql skip flag so core.AroundFunc emits nothing")
}

// TestCallPayloadDeliveryStore pins the claim scoping that keeps call-payload
// telemetry per delivery target: a digest claimed by one client's emission
// must NOT count as seen for a client outside that emission's delivery domain
// (the AGENT_QA P0 — a nested `dagger agent` attaching to a long-running
// session could never rebuild worker IDs, because the session-wide claim was
// spent before its DB existed).
func TestCallPayloadDeliveryStore(t *testing.T) {
	t.Parallel()

	sess := &daggerSession{}
	storeA := &callPayloadDeliveryStore{session: sess, targets: []string{"clientA"}}
	require.True(t, storeA.ClaimCallPayload("xxh3:abc"))
	require.False(t, storeA.ClaimCallPayload("xxh3:abc"),
		"a claim must be spent at the producer, before anything is persisted")
	require.Equal(t, []string{"clientA"}, sess.takeCallPayloadForWrite("xxh3:abc", storeA.targets))
	sess.settleCallPayload("xxh3:abc", storeA.targets, true, false)
	require.False(t, storeA.ClaimCallPayload("xxh3:abc"))
	require.Empty(t, sess.callPayloadMissingTargets("xxh3:abc", storeA.targets))

	storeB := &callPayloadDeliveryStore{session: sess, targets: []string{"clientB"}}
	require.True(t, storeB.ClaimCallPayload("xxh3:abc"),
		"a digest claimed by another client's emission must stay needed for a late client")

	storeMod := &callPayloadDeliveryStore{session: sess, targets: []string{"clientA", "modClient"}}
	require.True(t, storeMod.ClaimCallPayload("xxh3:abc"),
		"an emission must not be skipped while any route target still needs it")
	require.Equal(t, []string{"modClient"},
		sess.takeCallPayloadForWrite("xxh3:abc", storeMod.targets),
		"only the missing target must be written")
	require.False(t, storeMod.ClaimCallPayload("xxh3:abc"))
}

// A failed write releases its targets so the record's retry — or any later
// closure walk — can deliver them, while a target another export is writing
// or has delivered is never handed out twice.
func TestCallPayloadWriteOwnershipAndRelease(t *testing.T) {
	t.Parallel()

	sess := &daggerSession{}
	route := []string{"parent", "child"}
	store := &callPayloadDeliveryStore{session: sess, targets: route}
	require.True(t, store.ClaimCallPayload("xxh3:abc"))

	require.Equal(t, route, sess.takeCallPayloadForWrite("xxh3:abc", route))
	require.Empty(t, sess.takeCallPayloadForWrite("xxh3:abc", route),
		"a target being written must not be handed to a concurrent export")
	require.False(t, store.ClaimCallPayload("xxh3:abc"),
		"a target being written is still claimed for the producer")

	sess.settleCallPayload("xxh3:abc", []string{"parent"}, true, false)
	sess.settleCallPayload("xxh3:abc", []string{"child"}, false, false)
	require.Equal(t, []string{"child"}, sess.callPayloadMissingTargets("xxh3:abc", route))
	require.True(t, store.ClaimCallPayload("xxh3:abc"),
		"a released target must be claimable by a later walk")
	require.Equal(t, []string{"child"}, sess.takeCallPayloadForWrite("xxh3:abc", route),
		"a retry must write only the released target")
}

// Closure coverage lets a payload walk stop at a digest whose whole closure an
// earlier walk claimed. It is per target like the claims themselves, and any
// released claim voids it: the released frame may sit inside any covered
// closure, and only a full walk would reach it again.
func TestCallPayloadClosureCoverage(t *testing.T) {
	t.Parallel()

	sess := &daggerSession{}
	store := &callPayloadDeliveryStore{session: sess, targets: []string{"parent", "child"}}
	require.False(t, store.CallPayloadClosureCovered("xxh3:abc"))

	epoch := store.CallPayloadReleaseEpoch()
	require.True(t, store.ClaimCallPayload("xxh3:abc"))
	require.True(t, store.CoverCallPayloadClosures([]string{"xxh3:abc", "xxh3:def"}, epoch))
	require.True(t, store.CallPayloadClosureCovered("xxh3:abc"))
	require.True(t, store.CallPayloadClosureCovered("xxh3:def"))

	sibling := &callPayloadDeliveryStore{session: sess, targets: []string{"parent", "sibling"}}
	require.False(t, sibling.CallPayloadClosureCovered("xxh3:abc"),
		"coverage for one route must not satisfy a target that never received the closure")

	require.Equal(t, store.targets, sess.takeCallPayloadForWrite("xxh3:abc", store.targets))
	sess.settleCallPayload("xxh3:abc", []string{"parent"}, true, false)
	require.True(t, store.CallPayloadClosureCovered("xxh3:def"),
		"a delivered write must not void coverage")
	sess.settleCallPayload("xxh3:abc", []string{"child"}, false, false)
	require.False(t, store.CallPayloadClosureCovered("xxh3:def"),
		"a released claim must void every covered closure")

	require.False(t, store.CoverCallPayloadClosures([]string{"xxh3:def"}, epoch),
		"a walk that started before a release must learn it raced one")
	require.False(t, store.CallPayloadClosureCovered("xxh3:def"),
		"a walk that started before a release must not record coverage")
}

// startRepair asks, as a failed root claim does, whether a replay of root
// must walk its closure for a lost payload.
func (s *callPayloadDeliveryStore) startRepair(root string) bool {
	s.session.callPayloadMu.Lock()
	defer s.session.callPayloadMu.Unlock()
	return s.session.startCallPayloadRepairLocked(root, s.targets)
}

// Only a failed final export attempt loses a payload: a failure the exporter
// retries does not. A pending loss makes each already claimed root on its
// route walk once, until something claims or takes the payload again, and a
// pair lost a second time is not repaired again.
func TestCallPayloadLossRepair(t *testing.T) {
	t.Parallel()

	sess := &daggerSession{}
	store := &callPayloadDeliveryStore{session: sess, targets: []string{"parent", "child"}}
	sibling := &callPayloadDeliveryStore{session: sess, targets: []string{"parent", "sibling"}}
	lose := func(digest, target string) {
		t.Helper()
		require.Equal(t, []string{target}, sess.takeCallPayloadForWrite(digest, []string{target}))
		sess.settleCallPayload(digest, []string{target}, false, true)
	}

	require.True(t, store.ClaimCallPayload("xxh3:abc"))
	require.Equal(t, store.targets, sess.takeCallPayloadForWrite("xxh3:abc", store.targets))
	sess.settleCallPayload("xxh3:abc", []string{"parent"}, true, true)
	sess.settleCallPayload("xxh3:abc", []string{"child"}, false, false)
	require.False(t, store.startRepair("xxh3:root"),
		"neither a delivered write nor a failure the exporter retries loses the payload")

	lose("xxh3:abc", "child")
	require.EqualValues(t, 1, sess.callPayloadLostCount)
	require.False(t, sibling.startRepair("xxh3:root"),
		"a loss on another route's target must not make this route walk")
	require.True(t, store.startRepair("xxh3:root"))
	require.False(t, store.startRepair("xxh3:root"), "a root walks once per loss")
	require.True(t, store.startRepair("xxh3:other"))

	epoch := store.CallPayloadReleaseEpoch()
	require.True(t, store.ClaimCallPayload("xxh3:covered"))
	require.True(t, store.CoverCallPayloadClosures([]string{"xxh3:covered"}, epoch))
	require.False(t, store.startRepair("xxh3:covered"),
		"a root covered since the loss reaches nothing still lost")

	claimed, repair := store.ClaimCallPayloadRoot("xxh3:replayed")
	require.True(t, claimed)
	require.False(t, repair, "a root this call claims needs no repair")
	claimed, repair = store.ClaimCallPayloadRoot("xxh3:replayed")
	require.False(t, claimed)
	require.True(t, repair, "a failed root claim decides the repair")
	claimed, repair = store.ClaimCallPayloadRoot("xxh3:replayed")
	require.False(t, claimed)
	require.False(t, repair, "once per loss")

	lose("xxh3:def", "child")
	require.True(t, store.startRepair("xxh3:root"), "a new loss lets every root walk again")

	require.True(t, store.ClaimCallPayload("xxh3:abc"), "the lost target can be claimed again")
	require.Equal(t, []string{"child"}, sess.takeCallPayloadForWrite("xxh3:def", []string{"child"}),
		"an exporter can take the lost target too")
	require.Zero(t, sess.callPayloadLostCount, "claiming or taking a lost target settles its loss")
	require.Empty(t, sess.callPayloadLostTargets)
	require.False(t, store.startRepair("xxh3:fresh"))

	sess.settleCallPayload("xxh3:def", []string{"child"}, false, true)
	require.EqualValues(t, 1, sess.callPayloadLostCount,
		"a copy that was no repair spends no repair, so losing it again is repairable")
	require.True(t, store.startRepair("xxh3:fresh"))

	control := controlPayloadKeyPrefix + "abc"
	lose(control, "child")
	require.EqualValues(t, 1, sess.callPayloadLostCount,
		"no recipe walk can re-emit a control record, so losing one must not make walks repair")
}

// A payload gets at most one repair copy per target, even while other losses
// keep repair walks running: once a repair walk claimed it, later repair
// walks are refused it, though an ordinary walk may still claim it.
func TestCallPayloadRepairCopiesEachPayloadOnce(t *testing.T) {
	t.Parallel()

	sess := &daggerSession{}
	store := &callPayloadDeliveryStore{session: sess, targets: []string{"client"}}
	lose := func(digest string) {
		t.Helper()
		require.Equal(t, store.targets, sess.takeCallPayloadForWrite(digest, store.targets))
		sess.settleCallPayload(digest, store.targets, false, true)
	}
	for _, digest := range []string{"xxh3:a", "xxh3:b"} {
		require.True(t, store.ClaimCallPayload(digest))
		lose(digest)
	}
	require.EqualValues(t, 2, sess.callPayloadLostCount)

	// Replaying R1 repairs a; that copy is lost too.
	require.True(t, store.startRepair("xxh3:r1"))
	claimed, refused := store.ClaimCallPayloadForRepair("xxh3:a")
	require.True(t, claimed)
	require.False(t, refused)
	lose("xxh3:a")
	require.EqualValues(t, 1, sess.callPayloadLostCount, "only b is still pending")

	// b keeps repair walks running; R2 reaches a but not b.
	require.True(t, store.startRepair("xxh3:r2"))
	claimed, refused = store.ClaimCallPayloadForRepair("xxh3:a")
	require.False(t, claimed, "a already had its repair copy")
	require.True(t, refused)
	claimed, refused = store.ClaimCallPayloadForRepair("xxh3:b")
	require.True(t, claimed)
	require.False(t, refused)
	require.Zero(t, sess.callPayloadLostCount)

	require.True(t, store.ClaimCallPayload("xxh3:a"),
		"an ordinary walk still claims it, as it would without repair")
}

// A repair walk claims only pending losses, and each claim spends its pair
// for good, so every repair copy spends at least one pair. A pair released by
// a failure that was not final is left to its own export's retry, and a pair
// whose repair is spent is left alone even when a repair copy for another
// target on the route reaches it.
func TestCallPayloadRepairClaimsOnlyPendingLosses(t *testing.T) {
	t.Parallel()

	sess := &daggerSession{}
	route := []string{"child", "parent"}
	store := &callPayloadDeliveryStore{session: sess, targets: route}
	fail := func(digest string, targets []string, final bool) {
		t.Helper()
		require.Equal(t, targets, sess.takeCallPayloadForWrite(digest, targets))
		sess.settleCallPayload(digest, targets, false, final)
	}

	require.True(t, store.ClaimCallPayload("xxh3:retried"))
	fail("xxh3:retried", route, false)
	claimed, refused := store.ClaimCallPayloadForRepair("xxh3:retried")
	require.False(t, claimed, "a failure that was not final is its export's to retry")
	require.True(t, refused)

	// a is lost for both targets; parent's repair copy is lost too.
	require.True(t, store.ClaimCallPayload("xxh3:a"))
	fail("xxh3:a", route, true)
	require.EqualValues(t, 2, sess.callPayloadLostCount)
	parentOnly := &callPayloadDeliveryStore{session: sess, targets: []string{"parent"}}
	claimed, refused = parentOnly.ClaimCallPayloadForRepair("xxh3:a")
	require.True(t, claimed)
	require.False(t, refused)
	fail("xxh3:a", []string{"parent"}, true)
	require.EqualValues(t, 1, sess.callPayloadLostCount, "parent's repair is spent")

	claimed, refused = store.ClaimCallPayloadForRepair("xxh3:a")
	require.True(t, claimed, "child's loss is still pending")
	require.True(t, refused, "parent's spent repair is left unclaimed")
	require.Zero(t, sess.callPayloadLostCount)
	// The exporter writes the copy to every route target still missing it,
	// parent included; that write failing spends nothing new.
	fail("xxh3:a", route, true)
	require.Zero(t, sess.callPayloadLostCount, "every pair of a has spent its repair")
	claimed, refused = store.ClaimCallPayloadForRepair("xxh3:a")
	require.False(t, claimed)
	require.True(t, refused)
	require.Equal(t, route, sess.claimCallPayload("xxh3:a", route),
		"an ordinary walk still claims it, as it would without repair")
}

func TestCallPayloadClaimsConcurrentOverlappingRoutes(t *testing.T) {
	t.Parallel()

	sess := &daggerSession{}
	routes := [][]string{{"parent", "childA"}, {"parent", "childB"}}
	start := make(chan struct{})
	results := make(chan []string, len(routes))
	var ready sync.WaitGroup
	ready.Add(len(routes))
	for _, route := range routes {
		go func() {
			ready.Done()
			<-start
			results <- sess.claimCallPayload("xxh3:overlap", route)
		}()
	}
	ready.Wait()
	close(start)

	counts := map[string]int{}
	for range routes {
		for _, target := range <-results {
			counts[target]++
		}
	}
	require.Equal(t, map[string]int{"parent": 1, "childA": 1, "childB": 1}, counts,
		"overlapping claims must atomically assign each target exactly once")
	require.Empty(t, sess.claimCallPayload("xxh3:overlap", []string{"parent", "childA", "childB"}))
}

type callPayloadRecordCapture struct {
	records []sdklog.Record
}

func (capture *callPayloadRecordCapture) Export(_ context.Context, records []sdklog.Record) error {
	for _, record := range records {
		capture.records = append(capture.records, record.Clone())
	}
	return nil
}

func (*callPayloadRecordCapture) ForceFlush(context.Context) error { return nil }
func (*callPayloadRecordCapture) Shutdown(context.Context) error   { return nil }

func scopedLogRecord(t *testing.T, scope string, body otellog.Value, attrs ...otellog.KeyValue) sdklog.Record {
	t.Helper()

	capture := new(callPayloadRecordCapture)
	provider := sdklog.NewLoggerProvider(sdklog.WithProcessor(sdklog.NewSimpleProcessor(capture)))
	record := otellog.Record{}
	record.SetTimestamp(time.Now())
	record.SetBody(body)
	record.AddAttributes(attrs...)
	ctx := trace.ContextWithSpanContext(t.Context(), trace.NewSpanContext(trace.SpanContextConfig{
		TraceID: trace.TraceID{1},
		SpanID:  trace.SpanID{1},
	}))
	provider.Logger(scope).Emit(ctx, record)
	require.NoError(t, provider.Shutdown(context.Background()))
	require.Len(t, capture.records, 1)
	return capture.records[0]
}

func serverCallPayload(t *testing.T, field, value string) ([]byte, string) {
	t.Helper()

	callPB := &callpbv1.Call{
		Field: field,
		Type:  &callpbv1.Type{NamedType: "Thing"},
		Args: []*callpbv1.Argument{{
			Name:  "value",
			Value: &callpbv1.Literal{Value: &callpbv1.Literal_String_{String_: value}},
		}},
	}
	callPB.Digest = digest.FromString(callPB.String()).String()
	payload, err := (proto.MarshalOptions{Deterministic: true}).Marshal(callPB)
	require.NoError(t, err)
	return payload, callPB.Digest
}

func TestClassifyCallPayloadRecord(t *testing.T) {
	payload, digest := serverCallPayload(t, "original", "value")
	digestless := &callpbv1.Call{Field: "embedded"}
	digestlessPayload, err := proto.Marshal(digestless)
	require.NoError(t, err)

	callType := otellog.String(telemetry.ContentTypeAttr, telemetryattrs.CallPayloadContentType)
	for _, test := range []struct {
		name       string
		scope      string
		body       otellog.Value
		attrs      []otellog.KeyValue
		payload    bool
		wantDigest string
		wantError  string
	}{
		{
			name:       "call content type and bytes body",
			scope:      "test.core",
			body:       otellog.BytesValue(payload),
			attrs:      []otellog.KeyValue{callType},
			payload:    true,
			wantDigest: digest,
		},
		{
			// The producer stamps the digest as an attribute so the export hot
			// path never has to decode a body.
			name:  "digest attribute skips body decode",
			scope: "test.core",
			body:  otellog.BytesValue([]byte{0xff}),
			attrs: []otellog.KeyValue{callType,
				otellog.String(telemetryattrs.CallPayloadDigestAttr, "xxh3:stamped")},
			payload:    true,
			wantDigest: "xxh3:stamped",
		},
		{
			name:  "digest attribute of the wrong kind falls back to the body",
			scope: "test.core",
			body:  otellog.BytesValue(payload),
			attrs: []otellog.KeyValue{callType,
				otellog.Int(telemetryattrs.CallPayloadDigestAttr, 1)},
			payload:    true,
			wantDigest: digest,
		},
		{
			name:  "other content type",
			scope: "test.core",
			body:  otellog.BytesValue(payload),
			attrs: []otellog.KeyValue{otellog.String(telemetry.ContentTypeAttr, "application/json")},
		},
		{
			name:      "wrong body kind",
			scope:     "test.core",
			body:      otellog.StringValue(string(payload)),
			attrs:     []otellog.KeyValue{callType},
			payload:   true,
			wantError: "body must be bytes",
		},
		{
			name:      "malformed protobuf",
			scope:     "test.core",
			body:      otellog.BytesValue([]byte{0xff}),
			attrs:     []otellog.KeyValue{callType},
			payload:   true,
			wantError: "decode call payload",
		},
		{
			name:      "missing embedded digest",
			scope:     "test.core",
			body:      otellog.BytesValue(digestlessPayload),
			attrs:     []otellog.KeyValue{callType},
			payload:   true,
			wantError: "missing embedded digest",
		},
		{
			name:    "ordinary log",
			scope:   "test.log",
			body:    otellog.StringValue("hello"),
			payload: false,
		},
	} {
		t.Run(test.name, func(t *testing.T) {
			record := scopedLogRecord(t, test.scope, test.body, test.attrs...)
			gotDigest, gotPayload, err := classifyCallPayloadRecord(record)
			require.Equal(t, test.payload, gotPayload)
			require.Equal(t, test.wantDigest, gotDigest)
			if test.wantError == "" {
				require.NoError(t, err)
			} else {
				require.ErrorContains(t, err, test.wantError)
			}
		})
	}
}

func TestClassifyCallPayloadRecordReadsEmbeddedAddress(t *testing.T) {
	original, originalDigest := serverCallPayload(t, "lookup", "original")
	tampered, tamperedDigest := serverCallPayload(t, "lookup", "tampered")
	require.NotEqual(t, originalDigest, tamperedDigest)

	for _, test := range []struct {
		body []byte
		want string
	}{
		{body: original, want: originalDigest},
		{body: tampered, want: tamperedDigest},
	} {
		record := scopedLogRecord(t,
			"test.core",
			otellog.BytesValue(test.body),
			otellog.String(telemetry.ContentTypeAttr, telemetryattrs.CallPayloadContentType),
		)
		got, payload, err := classifyCallPayloadRecord(record)
		require.NoError(t, err)
		require.True(t, payload)
		require.Equal(t, test.want, got)
	}
}

func TestWithoutLogOriginPreservesCallPayloadRecord(t *testing.T) {
	payload, _ := serverCallPayload(t, "lookup", "value")
	record := scopedLogRecord(t,
		"test.core",
		otellog.BytesValue(payload),
		otellog.String(telemetryattrs.TelemetryOriginClientIDAttr, "origin"),
		otellog.String(telemetry.ContentTypeAttr, telemetryattrs.CallPayloadContentType),
		otellog.String("test.keep", "value"),
	)

	clean := withoutLogOrigin(record)
	require.Equal(t, otellog.KindBytes, clean.Body().Kind())
	require.Equal(t, payload, clean.Body().AsBytes())
	attrs := map[string]otellog.Value{}
	clean.WalkAttributes(func(attr otellog.KeyValue) bool {
		attrs[attr.Key] = attr.Value
		return true
	})
	require.NotContains(t, attrs, telemetryattrs.TelemetryOriginClientIDAttr)
	require.Equal(t, telemetryattrs.CallPayloadContentType, attrs[telemetry.ContentTypeAttr].AsString())
	require.Equal(t, "value", attrs["test.keep"].AsString())
}

func TestSessionLogExporterRoutesCallPayloadOnlyToMissingTargets(t *testing.T) {
	t.Parallel()

	dbs := clientdb.NewDBs(t.TempDir())
	srv := &Server{clientDBs: dbs}
	srv.telemetryPubSub = NewPubSub(srv)
	sess := &daggerSession{clientRecords: map[string]*clientRecord{}}
	parent := &clientRecord{daggerSession: sess, clientID: "parent"}
	child := &clientRecord{daggerSession: sess, clientID: "child", parentClientIDs: []string{"parent"}}
	sess.clientRecords[parent.clientID] = parent
	sess.clientRecords[child.clientID] = child
	exporter := sessionLogExporter{sess: sess, ps: srv.telemetryPubSub}

	original, originalDigest := serverCallPayload(t, "lookup", "original")
	tampered, tamperedDigest := serverCallPayload(t, "lookup", "tampered")
	require.NotEqual(t, originalDigest, tamperedDigest)

	payloadRecord := func(origin string, body []byte) sdklog.Record {
		return scopedLogRecord(t,
			"test.core",
			otellog.BytesValue(body),
			otellog.String(telemetryattrs.TelemetryOriginClientIDAttr, origin),
			otellog.String(telemetry.ContentTypeAttr, telemetryattrs.CallPayloadContentType),
			otellog.String("test.keep", "value"),
		)
	}

	digestless := &callpbv1.Call{Field: "invalid"}
	digestlessPayload, err := proto.Marshal(digestless)
	require.NoError(t, err)

	// The parent receives the original first. The same payload from the child
	// then fills only the child gap, while the tampered payload is independently
	// addressed and delivered to both. The invalid reserved record in the middle
	// is consumed without aborting either valid record in the mixed batch.
	require.NoError(t, exporter.Export(t.Context(), []sdklog.Record{
		payloadRecord("parent", original),
		payloadRecord("child", digestlessPayload),
		payloadRecord("child", original),
		payloadRecord("child", original),
		payloadRecord("child", tampered),
	}))

	load := func(target string) []clientdb.Log {
		db, err := dbs.Open(t.Context(), target)
		require.NoError(t, err)
		defer db.Close()
		logs, err := db.Read().SelectLogsSince(t.Context(), clientdb.SelectLogsSinceParams{Limit: 100})
		require.NoError(t, err)
		return logs
	}
	parentLogs := load("parent")
	childLogs := load("child")
	require.Len(t, parentLogs, 2)
	require.Len(t, childLogs, 2)

	for _, rows := range [][]clientdb.Log{parentLogs, childLogs} {
		seenBodies := map[string]bool{}
		for _, row := range rows {
			var attrs []*otlpcommonv1.KeyValue
			require.NoError(t, clientdb.UnmarshalProtoJSONs(row.Attributes, &otlpcommonv1.KeyValue{}, &attrs))
			var hasPayload, hasExtra bool
			for _, attr := range attrs {
				require.NotEqual(t, telemetryattrs.TelemetryOriginClientIDAttr, attr.Key,
					"routing-only origin must not be persisted or streamed")
				hasPayload = hasPayload || attr.Key == telemetry.ContentTypeAttr && attr.Value.GetStringValue() == telemetryattrs.CallPayloadContentType
				hasExtra = hasExtra || attr.Key == "test.keep" && attr.Value.GetStringValue() == "value"
			}
			require.True(t, hasPayload, "routing must preserve the call payload marker")
			require.True(t, hasExtra, "routing must strip only the origin attribute")

			var body otlpcommonv1.AnyValue
			require.NoError(t, proto.Unmarshal(row.Body, &body))
			seenBodies[string(body.GetBytesValue())] = true
		}
		require.Equal(t, map[string]bool{string(original): true, string(tampered): true}, seenBodies)

		resourceLogs := clientdb.LogsToPB(rows)
		require.Len(t, resourceLogs, 1)
		require.Len(t, resourceLogs[0].ScopeLogs, 1)
		scopeLogs := resourceLogs[0].ScopeLogs[0]
		require.Equal(t, "test.core", scopeLogs.Scope.Name)
		require.Len(t, scopeLogs.LogRecords, 2)
		for _, record := range scopeLogs.LogRecords {
			require.Contains(t, [][]byte{original, tampered}, record.Body.GetBytesValue(),
				"byte bodies must survive client DB to binary OTLP reconstruction")
		}
	}
}

func TestFilterPendingWorkspaceModulesBySelectorInclude(t *testing.T) {
	t.Parallel()

	mods := []pendingModule{
		{Kind: moduleLoadKindAmbient, Name: "go-sdk"},
		{Kind: moduleLoadKindAmbient, Name: "rust-sdk"},
		{Kind: moduleLoadKindAmbient, Name: "php-sdk"},
	}

	t.Run("module:generator selects only that module", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"go-sdk:generate"})
		require.Equal(t, []pendingModule{mods[0]}, filtered)
	})

	t.Run("module:item works for checks and services too", func(t *testing.T) {
		t.Parallel()

		// The module-name resolution is identical across generate/check/up: the
		// segment before ':' is the module name regardless of the item kind.
		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"rust-sdk:lint", "php-sdk:web"})
		require.Equal(t, []pendingModule{mods[1], mods[2]}, filtered)
	})

	t.Run("bare module name selects only that module", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"go-sdk"})
		require.Equal(t, []pendingModule{mods[0]}, filtered)
	})

	t.Run("multiple patterns select each named module", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"go-sdk", "php-sdk:api"})
		require.Equal(t, []pendingModule{mods[0], mods[2]}, filtered)
	})

	t.Run("bare token not matching a module selects all", func(t *testing.T) {
		t.Parallel()

		// e.g. an item served by the entrypoint module.
		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"generate"})
		require.Equal(t, mods, filtered)
	})

	t.Run("module:item not matching a module selects all", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"typo-sdk:generate"})
		require.Equal(t, mods, filtered)
	})

	t.Run("empty include selects all", func(t *testing.T) {
		t.Parallel()

		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, nil)
		require.Equal(t, mods, filtered)
	})

	t.Run("already-served module is recognized and selects nothing", func(t *testing.T) {
		t.Parallel()

		// A re-evaluated selector (e.g. loading a GeneratorGroup from its ID
		// on a later request) names a module that already loaded; it must not
		// fall back to loading everything.
		served := map[string]struct{}{"dang-sdk": {}}
		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, served, []string{"dang-sdk"})
		require.Empty(t, filtered)
	})

	t.Run("served and pending patterns select only the pending module", func(t *testing.T) {
		t.Parallel()

		served := map[string]struct{}{"dang-sdk": {}}
		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, served, []string{"dang-sdk:generate", "go-sdk"})
		require.Equal(t, []pendingModule{mods[0]}, filtered)
	})

	t.Run("camelCase pattern selects the kebab-case module", func(t *testing.T) {
		t.Parallel()

		// Name matching is kebab-normalized on both sides, like the include
		// matchers the selector resolvers use (ModTreePath.Glob/CliCase).
		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"goSdk:generate"})
		require.Equal(t, []pendingModule{mods[0]}, filtered)
	})

	t.Run("kebab-case pattern selects the camelCase module", func(t *testing.T) {
		t.Parallel()

		// The CLI presents module commands in kebab-case, so a module declared
		// as "myMod" (or "mod1", which kebab-cases to "mod-1") is targeted by
		// its kebab-case name.
		camelMods := []pendingModule{
			{Kind: moduleLoadKindAmbient, Name: "myMod"},
			{Kind: moduleLoadKindAmbient, Name: "mod1"},
			{Kind: moduleLoadKindAmbient, Name: "other"},
		}
		filtered := filterPendingWorkspaceModulesBySelectorInclude(camelMods, nil, []string{"my-mod", "mod-1:generate"})
		require.Equal(t, []pendingModule{camelMods[0], camelMods[1]}, filtered)
	})

	t.Run("glob pattern selects all", func(t *testing.T) {
		t.Parallel()

		// Glob metacharacters survive normalization and never equal a module
		// name, so glob patterns conservatively load everything.
		filtered := filterPendingWorkspaceModulesBySelectorInclude(mods, nil, []string{"go-*"})
		require.Equal(t, mods, filtered)
	})
}

func TestWorkspaceConfigPendingModules(t *testing.T) {
	t.Parallel()

	ws := &workspace.Workspace{
		Root:       "/repo",
		Cwd:        ".",
		ConfigFile: workspace.ConfigFileName,
		LockFile:   filepath.Join(workspace.LockDirName, workspace.LockFileName),
	}
	resolveLocalRef := func(_ *workspace.Workspace, relPath string) string {
		return filepath.Join("/resolved", relPath)
	}

	pending := workspaceConfigPendingModules(ws, &workspace.Config{
		DefaultsFromDotEnv: true,
		Modules: map[string]workspace.ModuleEntry{
			"zeta": {
				Source:     "github.com/acme/zeta@main",
				Entrypoint: true,
				Settings:   map[string]any{"message": "hello"},
			},
			"alpha": {
				Source:            "modules/alpha",
				LegacyDefaultPath: true,
			},
			// A dot past the first path segment is still a workspace path, not
			// a git host.
			"beta": {
				Source: "ci/.dagger/beta",
			},
		},
	}, resolveLocalRef)
	require.Len(t, pending, 3)

	require.Equal(t, "alpha", pending[0].Name)
	require.Equal(t, "/resolved/modules/alpha", pending[0].Ref)
	require.Empty(t, pending[0].RefPin)
	require.False(t, pending[0].Entrypoint)
	require.True(t, pending[0].DisableFindUp)
	require.True(t, pending[0].LegacyDefaultPath)
	require.Equal(t, "/resolved", pending[0].DefaultPathContextSourceRef)
	require.True(t, pending[0].DefaultsFromDotEnv)

	require.Equal(t, "beta", pending[1].Name)
	require.Equal(t, "/resolved/ci/.dagger/beta", pending[1].Ref)
	require.Equal(t, "ci/.dagger/beta", pending[1].WorkspaceDir)

	require.Equal(t, "zeta", pending[2].Name)
	require.Equal(t, "github.com/acme/zeta@main", pending[2].Ref)
	require.Empty(t, pending[2].RefPin)
	require.True(t, pending[2].Entrypoint)
	require.True(t, pending[2].DisableFindUp)
	require.False(t, pending[2].LegacyDefaultPath)
	require.Empty(t, pending[2].DefaultPathContextSourceRef)
	require.True(t, pending[2].DefaultsFromDotEnv)
	require.Equal(t, map[string]any{"message": "hello"}, pending[2].ConfigDefaults)
}

// TestModuleResolutionFromSubdirectory verifies that module source paths from
// dagger.json are resolved relative to the config file location, not the
// client's working directory. When a client connects from sdk/go/, a module
// with source "modules/changelog" should resolve to /repo/modules/changelog,
// not /repo/sdk/go/modules/changelog.
func TestModuleResolutionFromSubdirectory(t *testing.T) {
	t.Parallel()

	// Filesystem layout:
	//   /repo/.git                  (git root)
	//   /repo/dagger.json           (config declaring a module)
	//   /repo/sdk/go/               (client CWD)

	existingFiles := map[string]bool{
		"/repo/.git":        true,
		"/repo/dagger.json": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	// The "toolchains" field is the current config mechanism for declaring
	// workspace modules in dagger.json.
	daggerJSON := `{
		"name": "myproject",
		"toolchains": [
			{"name": "changelog", "source": "modules/changelog"}
		]
	}`

	readFile := func(_ context.Context, path string) ([]byte, error) {
		if filepath.Clean(path) == "/repo/dagger.json" {
			return []byte(daggerJSON), nil
		}
		return nil, os.ErrNotExist
	}

	resolveLocalRef := func(ws *workspace.Workspace, relPath string) string {
		return filepath.Join(ws.Root, relPath)
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{
			LoadWorkspaceModules: true,
		}},
		pendingWorkspaceLoad: true}

	srv := &Server{}
	err := srv.detectAndLoadWorkspace(ctx, client,
		statFS,
		readFile,
		"/repo/sdk/go", // CWD is a subdirectory
		resolveLocalRef,
		nil,
		true, // isLocal
	)
	require.NoError(t, err)
	require.Equal(t, "sdk/go", client.workspace.Cwd)

	// Module source must resolve relative to dagger.json (/repo),
	// not relative to CWD (/repo/sdk/go).
	require.Len(t, client.pendingModules, 1)
	require.Equal(t, "/repo/modules/changelog", client.pendingModules[0].Ref)
	require.Equal(t, "changelog", client.pendingModules[0].Name)
}

func TestDetectAndLoadWorkspaceIgnoresCompatFallbackWhenConfigExists(t *testing.T) {
	t.Parallel()

	existingFiles := map[string]bool{
		"/repo/.git":                      true,
		"/repo/dagger.toml":               true,
		"/repo/mymod/dagger.json":         true,
		"/repo/modules/local":             true,
		"/repo/modules/local/dagger.json": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	readFile := func(_ context.Context, path string) ([]byte, error) {
		switch filepath.Clean(path) {
		case "/repo/dagger.toml":
			return []byte(`[modules.dev]
source = "github.com/acme/dev@main"
entrypoint = true

[modules.local]
source = "modules/local"
`), nil
		case "/repo/mymod/dagger.json":
			return []byte(`{"name":"mymod","sdk":{"source":"go"}}`), nil
		default:
			return nil, os.ErrNotExist
		}
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{
			LoadWorkspaceModules: true,
		}},
		pendingWorkspaceLoad: true}

	srv := &Server{}
	err := srv.detectAndLoadWorkspace(ctx, client,
		statFS,
		readFile,
		"/repo/mymod",
		func(ws *workspace.Workspace, relPath string) string {
			return filepath.Join(ws.Root, relPath)
		},
		nil,
		true,
	)
	require.NoError(t, err)
	require.Equal(t, "mymod", client.workspace.Cwd)
	require.Equal(t, workspace.ConfigFileName, client.workspace.ConfigFile)

	require.Len(t, client.pendingModules, 2)
	require.Equal(t, moduleLoadKindAmbient, client.pendingModules[0].Kind)
	require.Equal(t, "dev", client.pendingModules[0].Name)
	require.Equal(t, "github.com/acme/dev@main", client.pendingModules[0].Ref)
	require.True(t, client.pendingModules[0].Entrypoint)

	require.Equal(t, moduleLoadKindAmbient, client.pendingModules[1].Kind)
	require.Equal(t, "local", client.pendingModules[1].Name)
	require.Equal(t, "/repo/modules/local", client.pendingModules[1].Ref)
	require.False(t, client.pendingModules[1].Entrypoint)
}

func TestDetectAndLoadWorkspaceLoadsPlainModuleCompatWithoutConfig(t *testing.T) {
	t.Parallel()

	existingFiles := map[string]bool{
		"/repo/.git":              true,
		"/repo/mymod/dagger.json": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	readFile := func(_ context.Context, path string) ([]byte, error) {
		if filepath.Clean(path) == "/repo/mymod/dagger.json" {
			return []byte(`{"name":"mymod","sdk":{"source":"go"}}`), nil
		}
		return nil, os.ErrNotExist
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{
			LoadWorkspaceModules: true,
		}},
		pendingWorkspaceLoad: true}

	srv := &Server{}
	err := srv.detectAndLoadWorkspace(ctx, client,
		statFS,
		readFile,
		"/repo/mymod",
		func(ws *workspace.Workspace, relPath string) string {
			return filepath.Join(ws.Root, relPath)
		},
		nil,
		true,
	)
	require.NoError(t, err)
	require.Empty(t, client.workspace.ConfigFile)
	require.Len(t, client.pendingModules, 1)
	require.Equal(t, moduleLoadKindAmbient, client.pendingModules[0].Kind)
	require.Equal(t, "mymod", client.pendingModules[0].Name)
	require.Equal(t, "/repo/mymod", client.pendingModules[0].Ref)
	require.True(t, client.pendingModules[0].Entrypoint)
}

func TestDetectAndLoadWorkspaceKeepsCompatFallbackForExplicitExtraModule(t *testing.T) {
	t.Parallel()

	existingFiles := map[string]bool{
		"/repo/.git":        true,
		"/repo/dagger.json": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	readFile := func(_ context.Context, path string) ([]byte, error) {
		if filepath.Clean(path) == "/repo/dagger.json" {
			return []byte(`{"name":"ambient","toolchains":[{"name":"tool","source":"./tool"}]}`), nil
		}
		return nil, os.ErrNotExist
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	extra := []engine.ExtraModule{{
		Ref:        "/repo/explicit",
		Entrypoint: true,
	}}
	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{
			ExtraModules: extra,
		}},
		pendingWorkspaceLoad: true,
		pendingExtraModules:  extra}

	srv := &Server{}
	err := srv.detectAndLoadWorkspace(ctx, client,
		statFS,
		readFile,
		"/repo",
		func(ws *workspace.Workspace, relPath string) string {
			return filepath.Join(ws.Root, relPath)
		},
		nil,
		true,
	)
	require.NoError(t, err)
	require.NotNil(t, client.workspace)
	require.NotNil(t, client.workspace.CompatWorkspace())
	require.Len(t, client.pendingModules, 1)
	require.Equal(t, "tool", client.pendingModules[0].Name)
	require.Equal(t, extra, client.pendingExtraModules)
}

func TestDetectAndLoadWorkspaceCreatesRootlessWorkspaceWithoutInferringModule(t *testing.T) {
	t.Parallel()

	existingFiles := map[string]bool{
		"/tmp/mymod/dagger.json": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	readFile := func(_ context.Context, path string) ([]byte, error) {
		if filepath.Clean(path) == "/tmp/mymod/dagger.json" {
			return []byte(`{"name":"mymod"}`), nil
		}
		return nil, os.ErrNotExist
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{
			LoadWorkspaceModules: true,
		}},
		pendingWorkspaceLoad: true}

	srv := &Server{}
	err := srv.detectAndLoadWorkspace(ctx, client,
		statFS,
		readFile,
		"/tmp/mymod",
		func(ws *workspace.Workspace, relPath string) string {
			return filepath.Join(ws.Root, relPath)
		},
		nil,
		true,
	)
	require.NoError(t, err)
	require.NotNil(t, client.workspace)
	require.Equal(t, "/tmp/mymod", client.workspace.HostPath())
	_, ok := client.workspace.Source().(*core.WorkspaceSourceRootlessLocal)
	require.True(t, ok)
	require.Empty(t, client.pendingModules)
}

func TestRemoteWorkspaceCwdUsesDetectionStart(t *testing.T) {
	t.Parallel()

	existingFiles := map[string]bool{
		"dagger.toml": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	readFile := func(_ context.Context, path string) ([]byte, error) {
		if filepath.Clean(path) == "dagger.toml" {
			return []byte("# workspace\n"), nil
		}
		return nil, os.ErrNotExist
	}

	resolveLocalRef := func(ws *workspace.Workspace, relPath string) string {
		subPath := filepath.Join(ws.Root, relPath)
		return core.GitRefString("github.com/acme/repo", subPath, "main")
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{}},
		pendingWorkspaceLoad: true}

	srv := &Server{}
	err := srv.detectAndLoadWorkspaceWithRootfs(ctx, client,
		statFS,
		readFile,
		"subdir",
		resolveLocalRef,
		func(ws *workspace.Workspace) string {
			return remoteWorkspaceAddress("github.com/acme/repo", ws.Cwd, "main")
		},
		false,
		dagql.ObjectResult[*core.Directory]{},
		nil,
		nil,
		"",
	)
	require.NoError(t, err)
	require.Equal(t, "subdir", client.workspace.Cwd)
	require.Equal(t, "github.com/acme/repo/subdir@main", client.workspace.Address)
	require.Equal(t, workspace.ConfigFileName, client.workspace.ConfigFile)
}

func TestRemoteWorkspaceLoadsPlainModuleCompatFromCWD(t *testing.T) {
	t.Parallel()

	existingFiles := map[string]bool{
		"subdir/dagger.json": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	readFile := func(_ context.Context, path string) ([]byte, error) {
		if filepath.Clean(path) == "subdir/dagger.json" {
			return []byte(`{"name":"remote-mod","sdk":{"source":"go"}}`), nil
		}
		return nil, os.ErrNotExist
	}

	resolveLocalRef := func(ws *workspace.Workspace, relPath string) string {
		subPath := filepath.Join(ws.Root, relPath)
		return core.GitRefString("github.com/acme/repo", subPath, "main")
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{
			LoadWorkspaceModules: true,
		}},
		pendingWorkspaceLoad: true}

	srv := &Server{}
	err := srv.detectAndLoadWorkspaceWithRootfs(ctx, client,
		statFS,
		readFile,
		"subdir/child",
		resolveLocalRef,
		func(ws *workspace.Workspace) string {
			return remoteWorkspaceAddress("github.com/acme/repo", ws.Cwd, "main")
		},
		false,
		dagql.ObjectResult[*core.Directory]{},
		nil,
		nil,
		"",
	)
	require.NoError(t, err)
	require.Equal(t, filepath.Join("subdir", "child"), client.workspace.Cwd)
	require.Len(t, client.pendingModules, 1)
	require.Equal(t, moduleLoadKindAmbient, client.pendingModules[0].Kind)
	require.Equal(t, "remote-mod", client.pendingModules[0].Name)
	require.Equal(t, core.GitRefString("github.com/acme/repo", "subdir", "main"), client.pendingModules[0].Ref)
	require.True(t, client.pendingModules[0].Entrypoint)
}

func TestDetectAndLoadWorkspaceDiscoversModulesWithoutAutomaticLoading(t *testing.T) {
	t.Parallel()

	existingFiles := map[string]bool{
		"/repo/.git":        true,
		"/repo/dagger.json": true,
	}

	statFS := core.StatFSFunc(func(_ context.Context, path string) (string, *core.Stat, error) {
		path = filepath.Clean(path)
		if existingFiles[path] {
			return filepath.Dir(path), &core.Stat{
				Name: filepath.Base(path),
			}, nil
		}
		return "", nil, os.ErrNotExist
	})

	readFile := func(_ context.Context, path string) ([]byte, error) {
		if filepath.Clean(path) == "/repo/dagger.json" {
			return []byte(`{"name":"myproject","toolchains":[{"name":"changelog","source":"modules/changelog"}]}`), nil
		}
		return nil, os.ErrNotExist
	}

	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "test-client",
	})

	client := &clientRuntime{clientRecord: &clientRecord{
		clientMetadata: &engine.ClientMetadata{}},
		pendingWorkspaceLoad: true}

	srv := &Server{}
	err := srv.detectAndLoadWorkspace(ctx, client,
		statFS,
		readFile,
		"/repo/sdk/go",
		func(ws *workspace.Workspace, relPath string) string {
			return filepath.Join(ws.Root, relPath)
		},
		nil,
		true,
	)
	require.NoError(t, err)
	require.NotNil(t, client.workspace)
	require.NotNil(t, client.workspace.CompatWorkspace())
	require.Len(t, client.pendingModules, 1)
	require.Equal(t, "changelog", client.pendingModules[0].Name)
}

func TestIsSameModuleReference(t *testing.T) {
	t.Parallel()

	local := func(contextPath, rootSubpath, sourceSubpath string) *core.ModuleSource {
		return &core.ModuleSource{
			Kind:              core.ModuleSourceKindLocal,
			Local:             &core.LocalModuleSource{ContextDirectoryPath: contextPath},
			SourceRootSubpath: rootSubpath,
			SourceSubpath:     sourceSubpath,
		}
	}

	t.Run("same local source root and pin", func(t *testing.T) {
		t.Parallel()
		a := local("/work/mod", ".", ".")
		b := local("/work/mod", ".", ".")
		require.True(t, isSameModuleReference(a, b))
	})

	t.Run("different local source", func(t *testing.T) {
		t.Parallel()
		a := local("/work/mod-a", ".", ".")
		b := local("/work/mod-b", ".", ".")
		require.False(t, isSameModuleReference(a, b))
	})

	t.Run("same module through different local refs", func(t *testing.T) {
		t.Parallel()
		// a points at the workspace root where dagger.json has sourceSubpath
		// ".dagger/modules/dagger-dev". b points directly at that module dir.
		a := local("/root/src/dagger", ".", ".dagger/modules/dagger-dev")
		b := local("/root/src/dagger/.dagger/modules/dagger-dev", ".", ".")
		require.True(t, isSameModuleReference(a, b))
	})
}

func TestEnsureWorkspaceLoadedInheritsParentWorkspace(t *testing.T) {
	t.Parallel()

	srv := &Server{}
	bound := &core.Workspace{
		ClientID: "parent-client",
	}

	parent := &clientRuntime{clientRecord: &clientRecord{
		clientID: "parent-client"},
		workspace: bound}
	child := &clientRuntime{clientRecord: &clientRecord{
		clientID:        "child-client",
		parentClientIDs: []string{parent.clientID}}}
	sess := &daggerSession{clientRuntimes: map[string]*clientRuntime{
		parent.clientID: parent,
		child.clientID:  child,
	}}
	parent.daggerSession = sess
	child.daggerSession = sess
	installTestClientRecords(sess)

	require.NoError(t, srv.ensureWorkspaceLoaded(context.Background(), child))
	require.Same(t, bound, child.workspace)
}

func TestEnsureWorkspaceLoadedKeepsExistingWorkspaceBinding(t *testing.T) {
	t.Parallel()

	srv := &Server{}
	existing := &core.Workspace{
		ClientID: "child-client",
	}
	parentBound := &core.Workspace{
		ClientID: "parent-client",
	}

	parent := &clientRuntime{clientRecord: &clientRecord{
		clientID: "parent-client"},
		workspace: parentBound}
	child := &clientRuntime{clientRecord: &clientRecord{
		clientID:        "child-client",
		parentClientIDs: []string{parent.clientID}},
		workspace: existing}

	require.NoError(t, srv.ensureWorkspaceLoaded(context.Background(), child))
	require.Same(t, existing, child.workspace)
}

func TestSpecificClientAttachableConnRejectsInertClient(t *testing.T) {
	t.Parallel()

	parentConn := &grpc.ClientConn{}
	parentCaller := &sessionAttachableCaller{
		ctx:       context.Background(),
		conn:      parentConn,
		supported: map[string]struct{}{},
	}
	parent := &clientRecord{clientID: "parent"}
	child := &clientRecord{
		clientID:                 "child",
		hostServiceProxyClientID: parent.clientID,
		parentClientIDs:          []string{parent.clientID},
		inertAttachables:         true,
	}
	attachables := newSessionAttachableManager()
	attachables.callers[parent.clientID] = parentCaller
	sess := &daggerSession{
		sessionID:   "session",
		attachables: attachables,
		clientRecords: map[string]*clientRecord{
			parent.clientID: parent,
			child.clientID:  child,
		},
	}
	parent.daggerSession = sess
	child.daggerSession = sess
	sess.state.Store(sessionStateInitialized)
	srv := &Server{daggerSessions: map[string]*daggerSession{sess.sessionID: sess}}

	for _, ifAvailable := range []bool{false, true} {
		ctx := engine.ContextWithClientMetadata(t.Context(), &engine.ClientMetadata{
			SessionID: sess.sessionID,
			ClientID:  child.clientID,
		})
		conn, ok, err := srv.SpecificClientAttachableConn(ctx, child.clientID, core.SpecificClientAttachableConnOpts{
			IfAvailable: ifAvailable,
		})
		require.Error(t, err)
		require.Equal(t, codes.PermissionDenied, status.Code(err))
		require.ErrorContains(t, err, "SDK client access to host session attachables is denied")
		require.False(t, ok)
		require.Nil(t, conn)
		require.NotSame(t, parentConn, conn)
	}

	for _, ifAvailable := range []bool{false, true} {
		t.Run(fmt.Sprintf("direct caller ifAvailable=%t", ifAvailable), func(t *testing.T) {
			// CallerStatFS reaches this gateway directly, rather than going
			// through SpecificClientAttachableConn. An inert client must be
			// rejected here too, not wait for attachables that will never exist.
			ctx, cancel := context.WithTimeout(t.Context(), 100*time.Millisecond)
			defer cancel()
			caller, err := srv.clientAttachableCaller(ctx, sess.sessionID, child.clientID, ifAvailable)
			require.Equal(t, codes.PermissionDenied, status.Code(err))
			require.Nil(t, caller)
		})
	}

	caller, err := sess.resolveHostServiceCaller(t.Context(), child.clientID)
	require.Error(t, err)
	require.Equal(t, codes.PermissionDenied, status.Code(err))
	require.Nil(t, caller)
}

func TestResolveHostServiceCallerFallsBackToParentRecordWithoutRuntime(t *testing.T) {
	t.Parallel()

	parentCaller := &fakeSessionCaller{id: "parent"}
	parent := &clientRecord{clientID: "parent"}
	child := &clientRecord{
		clientID:                 "child",
		hostServiceProxyClientID: "parent",
		parentClientIDs:          []string{parent.clientID},
	}
	sess := &daggerSession{
		attachables: newSessionAttachableManager(),
		clientRecords: map[string]*clientRecord{
			parent.clientID: parent,
			child.clientID:  child,
		},
		clientRuntimes: map[string]*clientRuntime{},
	}
	parent.daggerSession = sess
	child.daggerSession = sess
	sess.getClientCaller = func(_ context.Context, id string) (engineutil.SessionCaller, error) {
		require.Equal(t, "parent", id)
		return parentCaller, nil
	}

	caller, err := sess.resolveHostServiceCaller(context.Background(), "child")
	require.NoError(t, err)
	require.Same(t, parentCaller, caller)
	require.Empty(t, sess.clientRuntimes, "host proxy routing must use records, not retained runtimes")
}

func TestResolveHostServiceCallerPrefersCurrentClientAttachable(t *testing.T) {
	t.Parallel()

	currentCaller := &sessionAttachableCaller{
		ctx:       context.Background(),
		supported: map[string]struct{}{},
	}
	attachables := newSessionAttachableManager()
	attachables.callers["child"] = currentCaller

	parent := &clientRecord{clientID: "parent"}
	child := &clientRecord{
		clientID:                 "child",
		hostServiceProxyClientID: "parent",
		parentClientIDs:          []string{parent.clientID},
	}
	sess := &daggerSession{
		attachables: attachables,
		clientRecords: map[string]*clientRecord{
			parent.clientID: parent,
			child.clientID:  child,
		},
	}
	sess.getClientCaller = func(context.Context, string) (engineutil.SessionCaller, error) {
		t.Fatal("unexpected parent fallback")
		return nil, nil
	}

	caller, err := sess.resolveHostServiceCaller(context.Background(), "child")
	require.NoError(t, err)
	require.Same(t, currentCaller, caller)
}

func TestResolveHostServiceCallerUsesBlockingLookupForOtherClients(t *testing.T) {
	t.Parallel()

	otherCaller := &fakeSessionCaller{id: "other"}
	sess := &daggerSession{}
	sess.getClientCaller = func(_ context.Context, id string) (engineutil.SessionCaller, error) {
		require.Equal(t, "other", id)
		return otherCaller, nil
	}

	caller, err := sess.resolveHostServiceCaller(context.Background(), "other")
	require.NoError(t, err)
	require.Same(t, otherCaller, caller)
}

func TestClientAttachableWaitRouting(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		name       string
		proxyID    string
		registered bool
		clientID   string
		wantWaitID string
	}{
		{"synthetic nested client without attachables", "parent", false, "child", "parent"},
		{"synthetic nested client that registered attachables", "parent", true, "child", ""},
		{"client with its own session waits", "", false, "child", "child"},
		{"another client still waits", "parent", false, "other", "other"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			attachables := newSessionAttachableManager()
			registeredCaller := &sessionAttachableCaller{
				ctx:       context.Background(),
				supported: map[string]struct{}{},
			}
			if tc.registered {
				attachables.callers["child"] = registeredCaller
			}
			sess := &daggerSession{
				attachables: attachables,
				clientRecords: map[string]*clientRecord{
					"parent": {clientID: "parent"},
					"child": {
						clientID:                 "child",
						hostServiceProxyClientID: tc.proxyID,
						parentClientIDs:          []string{"parent"},
					},
					"other": {clientID: "other"},
				},
			}
			var waitedFor []string
			waitCaller := &fakeSessionCaller{id: tc.wantWaitID}
			sess.getClientCaller = func(_ context.Context, id string) (engineutil.SessionCaller, error) {
				waitedFor = append(waitedFor, id)
				return waitCaller, nil
			}
			caller, err := sess.resolveHostServiceCaller(t.Context(), tc.clientID)
			require.NoError(t, err)
			if tc.wantWaitID == "" {
				require.Empty(t, waitedFor)
				require.Same(t, registeredCaller, caller)
			} else {
				require.Equal(t, []string{tc.wantWaitID}, waitedFor)
				require.Same(t, waitCaller, caller)
			}
		})
	}
}

func TestWorkspaceBindingMode(t *testing.T) {
	t.Parallel()

	t.Run("declared workspace takes precedence", func(t *testing.T) {
		t.Parallel()

		client := &clientRuntime{clientRecord: &clientRecord{
			clientMetadata: &engine.ClientMetadata{
				Workspace: stringPtr("github.com/dagger/dagger@main"),
			}},
			pendingWorkspaceLoad: false}

		mode, workspaceRef := workspaceBindingMode(client)
		require.Equal(t, workspaceBindingDeclared, mode)
		require.Equal(t, "github.com/dagger/dagger@main", workspaceRef)
	})

	t.Run("non-module defaults to host detection", func(t *testing.T) {
		t.Parallel()

		client := &clientRuntime{clientRecord: &clientRecord{
			clientMetadata: &engine.ClientMetadata{}},
			pendingWorkspaceLoad: true}

		mode, workspaceRef := workspaceBindingMode(client)
		require.Equal(t, workspaceBindingDetectHost, mode)
		require.Equal(t, "", workspaceRef)
	})

	t.Run("module defaults to inheritance", func(t *testing.T) {
		t.Parallel()

		client := &clientRuntime{clientRecord: &clientRecord{
			clientMetadata: &engine.ClientMetadata{}},
			pendingWorkspaceLoad: false}

		mode, workspaceRef := workspaceBindingMode(client)
		require.Equal(t, workspaceBindingInherit, mode)
		require.Equal(t, "", workspaceRef)
	})
}

func TestBuildCoreWorkspaceIncludesConfigState(t *testing.T) {
	t.Parallel()

	srv := &Server{}
	ctx := engine.ContextWithClientMetadata(context.Background(), &engine.ClientMetadata{
		ClientID: "main-client",
	})

	t.Run("workspace with config", func(t *testing.T) {
		t.Parallel()

		ws, err := srv.buildCoreWorkspace(ctx, &workspace.Workspace{
			Root:       "/repo",
			HasGitRoot: true,
			Cwd:        filepath.Join("services", "payment", "src"),
			ConfigFile: filepath.Join("services", "payment", workspace.ConfigFileName),
			LockFile:   filepath.Join("services", "payment", workspace.LockDirName, workspace.LockFileName),
		}, true, dagql.ObjectResult[*core.Directory]{}, nil, "")
		require.NoError(t, err)
		require.Equal(t, "file:///repo/services/payment/src", ws.Address)
		require.Equal(t, filepath.Join("services", "payment", "src"), ws.Cwd)
		require.Equal(t, filepath.Join("services", "payment", workspace.ConfigFileName), ws.ConfigFile)
		require.Equal(t, filepath.Join("services", "payment", workspace.LockDirName, workspace.LockFileName), ws.LockFile)
		require.Equal(t, "/repo", ws.HostPath())
	})

	t.Run("workspace without config", func(t *testing.T) {
		t.Parallel()

		ws, err := srv.buildCoreWorkspace(ctx, &workspace.Workspace{
			Root:       "/repo",
			HasGitRoot: true,
			Cwd:        ".",
			LockFile:   filepath.Join(workspace.LockDirName, workspace.LockFileName),
		}, true, dagql.ObjectResult[*core.Directory]{}, nil, "")
		require.NoError(t, err)
		require.Empty(t, ws.ConfigFile)
		require.Equal(t, filepath.Join(workspace.LockDirName, workspace.LockFileName), ws.LockFile)
	})

	t.Run("local boundary without Git is rootless", func(t *testing.T) {
		t.Parallel()

		ws, err := srv.buildCoreWorkspace(ctx, &workspace.Workspace{
			Root:     "/repo",
			Cwd:      ".",
			LockFile: workspace.LockFileName,
		}, true, dagql.ObjectResult[*core.Directory]{}, nil, "")
		require.NoError(t, err)
		require.Equal(t, "/repo", ws.HostPath())
		_, ok := ws.Source().(*core.WorkspaceSourceRootlessLocal)
		require.True(t, ok)
		_, err = ws.ExportHostPath()
		require.ErrorContains(t, err, "requires a local Git workspace")
	})
}

func TestNestedClientMetadataForRequest(t *testing.T) {
	t.Parallel()

	baseMetadata := func() *engine.ClientMetadata {
		return &engine.ClientMetadata{
			ClientID:          "nested-client",
			ClientSecretToken: "secret",
			SessionID:         "session",
			ClientHostname:    "nested-host",
			ClientStableID:    "stable",
			ClientVersion:     "",
			Labels: map[string]string{
				"ignored": "true",
			},
			SSHAuthSocketPath: "/tmp/ssh.sock",
			AllowedLLMModules: []string{"parent"},
			ExtraModules: []engine.ExtraModule{{
				Ref: "github.com/dagger/base-extra",
			}},
			LoadWorkspaceModules:  true,
			EagerRuntime:          true,
			Workspace:             stringPtr("github.com/dagger/base@main"),
			WorkspaceEnv:          stringPtr("parent-ci"),
			WorkspaceModuleScope:  "parent-scope",
			UseRecipeIDsByDefault: true,
		}
	}

	t.Run("inherits live nested client identity and policy without forwarded metadata", func(t *testing.T) {
		t.Parallel()

		base := baseMetadata()
		md := nestedClientMetadataForRequest(http.Header{}, base)

		require.Equal(t, "nested-client", md.ClientID)
		require.Equal(t, "secret", md.ClientSecretToken)
		require.Equal(t, "session", md.SessionID)
		require.Equal(t, "nested-host", md.ClientHostname)
		require.Equal(t, "stable", md.ClientStableID)
		require.Equal(t, engine.Version, md.ClientVersion)
		require.Empty(t, md.Labels)
		require.Equal(t, "/tmp/ssh.sock", md.SSHAuthSocketPath)
		require.Equal(t, []string{"parent"}, md.AllowedLLMModules)
		require.Empty(t, md.ExtraModules)
		require.False(t, md.LoadWorkspaceModules)
		require.False(t, md.EagerRuntime)
		require.Nil(t, md.Workspace)
		require.Nil(t, md.WorkspaceEnv)
		require.Empty(t, md.WorkspaceModuleScope)
		require.True(t, md.UseRecipeIDsByDefault)

		base.AllowedLLMModules[0] = "mutated"
		require.Equal(t, []string{"parent"}, md.AllowedLLMModules)
	})

	t.Run("overlays request-scoped forwarded metadata", func(t *testing.T) {
		t.Parallel()

		workspaceRef := "github.com/dagger/dagger@main"
		workspaceEnv := "ci"
		forwarded := engine.ClientMetadata{
			ClientID:          "forwarded-client",
			ClientSecretToken: "forwarded-secret",
			SessionID:         "forwarded-session",
			ClientHostname:    "forwarded-host",
			ClientStableID:    "forwarded-stable",
			ClientVersion:     "v-test",
			Labels: map[string]string{
				"forwarded": "ignored",
			},
			SSHAuthSocketPath: "/tmp/forwarded-ssh.sock",
			AllowedLLMModules: []string{"child"},
			ExtraModules: []engine.ExtraModule{{
				Ref:        "github.com/dagger/mod",
				Entrypoint: true,
			}},
			LoadWorkspaceModules:           true,
			EagerRuntime:                   true,
			SuppressCompatWorkspaceWarning: true,
			Workspace:                      &workspaceRef,
			WorkspaceEnv:                   &workspaceEnv,
			WorkspaceModuleScope:           "good-mod",
		}

		md := nestedClientMetadataForRequest(forwarded.AppendToHTTPHeaders(http.Header{}), baseMetadata())

		require.Equal(t, "nested-client", md.ClientID)
		require.Equal(t, "secret", md.ClientSecretToken)
		require.Equal(t, "session", md.SessionID)
		require.Equal(t, "nested-host", md.ClientHostname)
		require.Equal(t, "stable", md.ClientStableID)
		require.Equal(t, "/tmp/ssh.sock", md.SSHAuthSocketPath)
		require.Empty(t, md.Labels)

		require.Equal(t, "v-test", md.ClientVersion)
		require.Equal(t, []string{"child"}, md.AllowedLLMModules)
		require.True(t, md.LoadWorkspaceModules)
		require.True(t, md.EagerRuntime)
		require.True(t, md.SuppressCompatWorkspaceWarning)
		require.Equal(t, "github.com/dagger/dagger@main", *md.Workspace)
		require.Equal(t, "ci", *md.WorkspaceEnv)
		require.Equal(t, "good-mod", md.WorkspaceModuleScope)
		require.Equal(t, []engine.ExtraModule{{
			Ref:        "github.com/dagger/mod",
			Entrypoint: true,
		}}, md.ExtraModules)
		require.True(t, md.UseRecipeIDsByDefault)
	})

	t.Run("does not accept internal recipe ID default from forwarded metadata", func(t *testing.T) {
		t.Parallel()

		base := baseMetadata()
		base.UseRecipeIDsByDefault = false
		forwarded := engine.ClientMetadata{
			ClientVersion:         "v-test",
			UseRecipeIDsByDefault: true,
		}

		md := nestedClientMetadataForRequest(forwarded.AppendToHTTPHeaders(http.Header{}), base)

		require.False(t, md.UseRecipeIDsByDefault)
	})
}

func TestLocalWorkspaceAddress(t *testing.T) {
	t.Parallel()

	require.Equal(t, "file:///repo", localWorkspaceAddress("/repo", "."))
	require.Equal(t, "file:///repo/services/payment", localWorkspaceAddress("/repo", "services/payment"))
}

func TestRemoteWorkspaceAddress(t *testing.T) {
	t.Parallel()

	require.Equal(t, "https://github.com/dagger/dagger@main", remoteWorkspaceAddress("https://github.com/dagger/dagger", ".", "main"))
	require.Equal(t, "https://github.com/dagger/dagger/services/payment@main", remoteWorkspaceAddress("https://github.com/dagger/dagger", "services/payment", "main"))
}

func TestParseWorkspaceRemoteRef(t *testing.T) {
	t.Parallel()

	t.Run("supports address fragment ref at repository root", func(t *testing.T) {
		t.Parallel()

		for _, address := range []string{
			"https://github.com/dagger/dagger#main",
			"https://github.com/dagger/dagger#main:.",
		} {
			ref, err := parseWorkspaceRemoteRef(context.Background(), address)
			require.NoError(t, err)
			require.Equal(t, "https://github.com/dagger/dagger", ref.cloneRef)
			require.Equal(t, "main", ref.version)
			require.Equal(t, ".", ref.workspaceSubdir)
			require.Equal(t, gitref.GitRefSelector, ref.selector)
		}
	})

	t.Run("supports address fragment ref and subdir", func(t *testing.T) {
		t.Parallel()

		ref, err := parseWorkspaceRemoteRef(context.Background(), "https://github.com/dagger/dagger#main:toolchains/changelog")
		require.NoError(t, err)
		require.Equal(t, "https://github.com/dagger/dagger", ref.cloneRef)
		require.Equal(t, "main", ref.version)
		require.Equal(t, "toolchains/changelog", ref.workspaceSubdir)
		require.Equal(t, gitref.GitRefSelector, ref.selector)
	})

	t.Run("supports legacy at-ref syntax", func(t *testing.T) {
		t.Parallel()

		ref, err := parseWorkspaceRemoteRef(context.Background(), "github.com/dagger/dagger/toolchains/changelog@main")
		require.NoError(t, err)
		require.Equal(t, "main", ref.version)
		require.Equal(t, "toolchains/changelog", ref.workspaceSubdir)
		require.Equal(t, gitref.ModuleVersionSelector, ref.selector)
	})

	t.Run("preserves legacy https at-ref syntax", func(t *testing.T) {
		t.Parallel()

		ref, err := parseWorkspaceRemoteRef(context.Background(), "https://github.com/dagger/dagger@main")
		require.NoError(t, err)
		require.Equal(t, "main", ref.version)
		require.Equal(t, ".", ref.workspaceSubdir)
		require.Equal(t, gitref.ModuleVersionSelector, ref.selector)
	})

	t.Run("resolves legacy vanity ref", func(t *testing.T) {
		t.Parallel()

		ref, err := parseWorkspaceRemoteRefWithResolver(
			context.Background(),
			"dagger.io/go@main",
			func(_ context.Context, got string) (string, error) {
				require.Equal(t, "dagger.io/go@main", got)
				return "https://github.com/dagger/dagger/sdk/go@main", nil
			},
		)
		require.NoError(t, err)
		require.Equal(t, "https://github.com/dagger/dagger", ref.cloneRef)
		require.Equal(t, "main", ref.version)
		require.Equal(t, "sdk/go", ref.workspaceSubdir)
	})

	t.Run("resolves fragment clone ref and preserves subdir", func(t *testing.T) {
		t.Parallel()

		ref, err := parseWorkspaceRemoteRefWithResolver(
			context.Background(),
			"https://github.com/dagger/python#main:docs",
			func(_ context.Context, got string) (string, error) {
				require.Equal(t, "https://github.com/dagger/python", got)
				return "https://github.com/dagger/dagger/sdk/go", nil
			},
		)
		require.NoError(t, err)
		require.Equal(t, "https://github.com/dagger/dagger", ref.cloneRef)
		require.Equal(t, "main", ref.version)
		require.Equal(t, "sdk/go/docs", ref.workspaceSubdir)
		require.Equal(t, gitref.GitRefSelector, ref.selector)
	})

	for _, invalid := range []string{
		"github.com/dagger/python/ruff#main",
		"https://github.com/dagger/python/ruff#main",
		"https://github.com/dagger/python#main:",
		"github.com/dagger/python@main:ruff",
		"https://github.com/dagger/python@main:ruff",
		"github.com/dagger/python#main:ruff",
	} {
		t.Run("rejects "+invalid, func(t *testing.T) {
			t.Parallel()
			_, err := parseWorkspaceRemoteRef(context.Background(), invalid)
			require.Error(t, err)
		})
	}
}

func TestWorkspaceGitRefSelectorSemverSemantics(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		name                   string
		selector               gitref.SelectorType
		supportsVersionQueries bool
		wantField              string
	}{
		{name: "at selector uses semver query", selector: gitref.ModuleVersionSelector, supportsVersionQueries: true, wantField: "latest"},
		{name: "old client uses literal git ref", selector: gitref.ModuleVersionSelector, supportsVersionQueries: false, wantField: "ref"},
		{name: "fragment selector uses literal git ref", selector: gitref.GitRefSelector, supportsVersionQueries: true, wantField: "ref"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			selector := workspaceGitRefSelector(workspaceRemoteRef{
				version:         "v1.2",
				workspaceSubdir: "ruff",
				selector:        tc.selector,
			}, tc.supportsVersionQueries)
			require.Equal(t, tc.wantField, selector.Field)
			if tc.wantField == "latest" {
				require.Equal(t, "version", selector.Args[0].Name)
				require.Equal(t, "tagPrefix", selector.Args[1].Name)
			}
		})
	}
}

func TestGatherModuleLoadRequests(t *testing.T) {
	t.Parallel()

	loads := gatherModuleLoadRequests(
		[]pendingModule{
			{Kind: moduleLoadKindAmbient, Ref: "github.com/acme/a", Name: "a"},
			{Kind: moduleLoadKindAmbient, Ref: "github.com/acme/b", Name: "b"},
		},
		[]engine.ExtraModule{
			{Ref: "github.com/acme/extra1", Name: "extra1", Entrypoint: true},
			{Ref: "github.com/acme/extra2", Name: "extra2"},
		},
	)

	require.Len(t, loads, 4)
	require.Equal(t, moduleLoadKindAmbient, loads[0].mod.Kind)
	require.Equal(t, moduleLoadKindAmbient, loads[1].mod.Kind)
	require.Equal(t, moduleLoadKindExtra, loads[2].mod.Kind)
	require.Equal(t, moduleLoadKindExtra, loads[3].mod.Kind)

	require.Equal(t, "github.com/acme/a", loads[0].mod.Ref)
	require.Equal(t, "github.com/acme/b", loads[1].mod.Ref)
	require.Equal(t, "github.com/acme/extra1", loads[2].mod.Ref)
	require.Equal(t, "github.com/acme/extra2", loads[3].mod.Ref)
	require.True(t, loads[2].mod.Entrypoint)
}

func TestModuleLoadParallelism(t *testing.T) {
	t.Parallel()

	require.Equal(t, 1, moduleLoadParallelism(0))
	require.Equal(t, 1, moduleLoadParallelism(1))
	require.Equal(t, 3, moduleLoadParallelism(3))
	require.Equal(t, maxParallelModuleResolves, moduleLoadParallelism(maxParallelModuleResolves+4))
}

func TestModuleLoadErr(t *testing.T) {
	t.Parallel()

	err := errors.New("boom")

	normal := moduleLoadErr(moduleLoadRequest{mod: pendingModule{Ref: "github.com/acme/mod"}}, err)
	require.ErrorContains(t, normal, `loading module "github.com/acme/mod": boom`)

	extra := moduleLoadErr(moduleLoadRequest{
		mod: pendingModule{
			Kind: moduleLoadKindExtra,
			Ref:  "github.com/acme/extra",
		},
	}, err)
	require.ErrorContains(t, extra, `loading extra module "github.com/acme/extra": boom`)
}

func TestDedupeResolvedModuleLoads(t *testing.T) {
	t.Parallel()

	loads := []moduleLoadRequest{
		{
			mod: pendingModule{
				Kind:       moduleLoadKindAmbient,
				Ref:        "github.com/acme/app",
				Name:       "app",
				Entrypoint: false,
			},
		},
		{
			mod: pendingModule{
				Kind:       moduleLoadKindExtra,
				Ref:        "github.com/acme/app",
				Name:       "app",
				Entrypoint: true,
			},
		},
		{
			mod: pendingModule{
				Kind:       moduleLoadKindAmbient,
				Ref:        "github.com/acme/other",
				Name:       "other",
				Entrypoint: false,
			},
		},
	}
	resolved := []resolvedModuleLoad{
		{primary: sessionTestModuleResult(t, "app"), primaryEntrypoint: false},
		{primary: sessionTestModuleResult(t, "app"), primaryEntrypoint: true},
		{primary: sessionTestModuleResult(t, "other"), primaryEntrypoint: false},
	}

	dedupLoads, dedupResolved := dedupeResolvedModuleLoads(loads, resolved)
	require.Len(t, dedupLoads, 2)

	require.Equal(t, moduleLoadKindExtra, dedupLoads[0].mod.Kind)
	require.True(t, dedupResolved[0].primaryEntrypoint)

	require.Equal(t, moduleLoadKindAmbient, dedupLoads[1].mod.Kind)
	require.False(t, dedupResolved[1].primaryEntrypoint)
}

// dagger/dagger#14013
func TestDedupeResolvedModuleLoadsKeepsSameSourceUnderDifferentNames(t *testing.T) {
	t.Parallel()

	const cloneRef = "github.com/acme/rust"
	const commit = "deadbeef"

	loads := []moduleLoadRequest{
		{mod: pendingModule{Kind: moduleLoadKindAmbient, Ref: cloneRef, Name: "msrv"}},
		{mod: pendingModule{Kind: moduleLoadKindAmbient, Ref: cloneRef, Name: "rust"}},
	}
	resolved := []resolvedModuleLoad{
		{primary: sessionTestModuleResultWithGitSource(t, "msrv", cloneRef, commit)},
		{primary: sessionTestModuleResultWithGitSource(t, "rust", cloneRef, commit)},
	}

	dedupLoads, dedupResolved := dedupeResolvedModuleLoads(loads, resolved)
	require.Len(t, dedupLoads, 2)
	require.Equal(t, "msrv", dedupLoads[0].mod.Name)
	require.Equal(t, "rust", dedupLoads[1].mod.Name)
	require.Len(t, dedupResolved, 2)
}

func TestResolvedModuleLoadIdentity(t *testing.T) {
	t.Parallel()

	const cloneRef = "github.com/acme/rust"
	const commit = "deadbeef"

	rust := resolvedModuleLoadIdentity(sessionTestModuleResultWithGitSource(t, "rust", cloneRef, commit))
	msrv := resolvedModuleLoadIdentity(sessionTestModuleResultWithGitSource(t, "msrv", cloneRef, commit))
	require.NotEqual(t, rust, msrv, "same source under different names must be distinct instances")

	other := resolvedModuleLoadIdentity(sessionTestModuleResultWithGitSource(t, "rust", "github.com/acme/other", commit))
	require.NotEqual(t, rust, other)

	// Spelling variants are one CLI command name, so one instance.
	kebab := resolvedModuleLoadIdentity(sessionTestModuleResultWithGitSource(t, "my-mod", cloneRef, commit))
	camel := resolvedModuleLoadIdentity(sessionTestModuleResultWithGitSource(t, "myMod", cloneRef, commit))
	require.Equal(t, kebab, camel)
}

func TestArbitrateSameSourceEntrypointNominations(t *testing.T) {
	t.Parallel()

	const cloneRef = "github.com/acme/app"
	const commit = "deadbeef"

	sameSourceTwice := func(canonicalDefaults, realDefaults map[string]any) ([]moduleLoadRequest, []resolvedModuleLoad) {
		loads := []moduleLoadRequest{
			{mod: pendingModule{Kind: moduleLoadKindAmbient, Ref: cloneRef, Name: "canonical", Entrypoint: true, ConfigDefaults: canonicalDefaults}},
			{mod: pendingModule{Kind: moduleLoadKindAmbient, Ref: cloneRef, Name: "real", Entrypoint: true, ConfigDefaults: realDefaults}},
		}
		resolved := []resolvedModuleLoad{
			{primary: sessionTestModuleResultWithGitSource(t, "canonical", cloneRef, commit), primaryEntrypoint: true},
			{primary: sessionTestModuleResultWithGitSource(t, "real", cloneRef, commit), primaryEntrypoint: true},
		}
		return loads, resolved
	}

	t.Run("same settings under two names collapse to one nomination", func(t *testing.T) {
		t.Parallel()

		loads, resolved := sameSourceTwice(nil, nil)
		require.NoError(t, arbitrateResolvedModuleLoads(loads, resolved))
		require.True(t, resolved[0].primaryEntrypoint)
		require.False(t, resolved[1].primaryEntrypoint)
	})

	t.Run("different settings under two names stay a conflict", func(t *testing.T) {
		t.Parallel()

		loads, resolved := sameSourceTwice(
			map[string]any{"version": "1.98"},
			map[string]any{"version": "1.97"},
		)
		err := arbitrateResolvedModuleLoads(loads, resolved)
		require.EqualError(t, err, "invalid workspace configuration: multiple distinct ambient entrypoint modules: canonical, real")
	})
}

func TestArbitrateResolvedModuleLoads(t *testing.T) {
	t.Parallel()

	t.Run("extra beats ambient", func(t *testing.T) {
		t.Parallel()

		loads := []moduleLoadRequest{
			{mod: pendingModule{Kind: moduleLoadKindAmbient, Ref: "github.com/acme/app", Name: "app", Entrypoint: true}},
			{mod: pendingModule{Kind: moduleLoadKindExtra, Ref: "github.com/acme/extra", Name: "extra", Entrypoint: true}},
		}
		resolved := []resolvedModuleLoad{
			{primary: sessionTestModuleResult(t, "app"), primaryEntrypoint: true},
			{primary: sessionTestModuleResult(t, "extra"), primaryEntrypoint: true},
		}

		err := arbitrateResolvedModuleLoads(loads, resolved)
		require.NoError(t, err)
		require.False(t, resolved[0].primaryEntrypoint)
		require.True(t, resolved[1].primaryEntrypoint)
	})

	t.Run("multiple ambient entrypoints are invalid", func(t *testing.T) {
		t.Parallel()

		loads := []moduleLoadRequest{
			{mod: pendingModule{Kind: moduleLoadKindAmbient, Ref: "github.com/acme/app", Name: "app", Entrypoint: true}},
			{mod: pendingModule{Kind: moduleLoadKindAmbient, Ref: "github.com/acme/other", Name: "other", Entrypoint: true}},
		}
		resolved := []resolvedModuleLoad{
			{primary: sessionTestModuleResult(t, "app"), primaryEntrypoint: true},
			{primary: sessionTestModuleResult(t, "other"), primaryEntrypoint: true},
		}

		err := arbitrateResolvedModuleLoads(loads, resolved)
		require.EqualError(t, err, "invalid workspace configuration: multiple distinct ambient entrypoint modules: app, other")
	})

	t.Run("multiple extra entrypoints are invalid", func(t *testing.T) {
		t.Parallel()

		loads := []moduleLoadRequest{
			{mod: pendingModule{Kind: moduleLoadKindExtra, Ref: "github.com/acme/extra1", Name: "extra1", Entrypoint: true}},
			{mod: pendingModule{Kind: moduleLoadKindExtra, Ref: "github.com/acme/extra2", Name: "extra2", Entrypoint: true}},
		}
		resolved := []resolvedModuleLoad{
			{primary: sessionTestModuleResult(t, "extra1"), primaryEntrypoint: true},
			{primary: sessionTestModuleResult(t, "extra2"), primaryEntrypoint: true},
		}

		err := arbitrateResolvedModuleLoads(loads, resolved)
		require.EqualError(t, err, "invalid extra-module request: multiple distinct extra-module entrypoints: extra1, extra2")
	})
}

func TestNormalizeWorkspaceRemoteSubdir(t *testing.T) {
	t.Parallel()

	t.Run("empty becomes dot", func(t *testing.T) {
		t.Parallel()
		got, err := normalizeWorkspaceRemoteSubdir("")
		require.NoError(t, err)
		require.Equal(t, ".", got)
	})

	t.Run("absolute gets normalized to relative", func(t *testing.T) {
		t.Parallel()
		got, err := normalizeWorkspaceRemoteSubdir("/toolchains/changelog")
		require.NoError(t, err)
		require.Equal(t, "toolchains/changelog", got)
	})

	t.Run("rejects escaping paths", func(t *testing.T) {
		t.Parallel()
		_, err := normalizeWorkspaceRemoteSubdir("../outside")
		require.ErrorContains(t, err, "outside repository")
	})
}

func TestReadWorkspaceLockStateReadsLegacyLockFallback(t *testing.T) {
	t.Parallel()

	legacy := workspace.NewLock()
	require.NoError(t, legacy.SetLookup("", "oci-sha", []any{"alpine:latest"}, "sha256:deadbeef"))
	legacyBytes, err := legacy.Marshal()
	require.NoError(t, err)

	ws := &core.Workspace{
		ConfigFile: "dagger.toml",
		LockFile:   "dagger.lock",
	}
	ws.SetHostPath("/repo")

	lock, err := readWorkspaceLockState(t.Context(), &fakeWorkspaceLockStateReader{
		files: map[string][]byte{
			filepath.Join("/repo", ".dagger", "lock"): legacyBytes,
		},
	}, ws)
	require.NoError(t, err)

	got, ok := lock.GetLookup("", "oci-sha", []any{"alpine:latest"})
	require.True(t, ok)
	require.Equal(t, "sha256:deadbeef", got)
}

func TestReadWorkspaceLockStateDoesNotWriteInvalidLock(t *testing.T) {
	t.Parallel()

	ws := &core.Workspace{
		ConfigFile: "dagger.toml",
		LockFile:   "dagger.lock",
	}
	ws.SetHostPath("/repo")
	lockPath := filepath.Join("/repo", "dagger.lock")
	lockContents := []byte(`[["version","1"]]`)
	reader := &fakeWorkspaceLockStateReader{
		files: map[string][]byte{
			lockPath: lockContents,
		},
	}

	lock, err := readWorkspaceLockState(t.Context(), reader, ws)
	require.NoError(t, err)
	require.Empty(t, lock.Entries())
	require.Contains(t, reader.files, lockPath)
	require.Equal(t, lockContents, reader.files[lockPath])
}

type fakeWorkspaceLockStateReader struct {
	files map[string][]byte
}

func (r fakeWorkspaceLockStateReader) ReadCallerHostFile(_ context.Context, path string) ([]byte, error) {
	if data, ok := r.files[path]; ok {
		return data, nil
	}
	return nil, os.ErrNotExist
}

func stringPtr(v string) *string {
	return &v
}

func sessionTestModuleResult(t *testing.T, name string) dagql.ObjectResult[*core.Module] {
	t.Helper()

	dag, err := dagql.NewServer(t.Context(), &core.Module{})
	require.NoError(t, err)
	res, err := dagql.NewObjectResultForCall(
		&core.Module{NameField: name},
		dag,
		&dagql.ResultCall{SyntheticOp: "session-test-module-" + name},
	)
	require.NoError(t, err)
	return res
}

func sessionTestModuleResultWithGitSource(t *testing.T, name, cloneRef, commit string) dagql.ObjectResult[*core.Module] {
	t.Helper()

	dag, err := dagql.NewServer(t.Context(), &core.Module{})
	require.NoError(t, err)
	dag.InstallObject(dagql.NewClass(dag, dagql.ClassOpts[*core.ModuleSource]{Typed: &core.ModuleSource{}}))
	src, err := dagql.NewObjectResultForCall(
		&core.ModuleSource{
			Kind: core.ModuleSourceKindGit,
			Git: &core.GitModuleSource{
				CloneRef: cloneRef,
				Commit:   commit,
			},
			SourceRootSubpath: ".",
		},
		dag,
		&dagql.ResultCall{SyntheticOp: "session-test-module-source-" + name},
	)
	require.NoError(t, err)
	res, err := dagql.NewObjectResultForCall(
		&core.Module{
			NameField: name,
			Source:    dagql.NonNull(src),
		},
		dag,
		&dagql.ResultCall{SyntheticOp: "session-test-module-" + name},
	)
	require.NoError(t, err)
	return res
}

func TestIsCoreRootFieldCoversEveryCoreQueryField(t *testing.T) {
	t.Parallel()

	// A core Query field that neither list claims looks like an unknown field
	// to filterPendingWorkspaceModulesForRootFields, which then guesses it
	// might be an entrypoint function and loads the entrypoint for it.
	// `node` is the one core field deliberately left out: what it demands is
	// knowable only from its id, which this layer does not read, so it keeps
	// the conservative guess.
	for _, field := range []string{
		"blob",
		"currentNode",
		"engineVolume",
		"schema",
		"sshfsVolume",
	} {
		require.True(t, isCoreRootField(field), field)
	}
	require.False(t, isCoreRootField("node"))
	// `id` is core on Query, but a module function named `id` is rejected by
	// name, and that error needs the module loaded to be produced at all.
	require.False(t, isCoreRootField("id"))
}

func TestHTTPHandlerFuncLabelsGraphQLErrorsJSON(t *testing.T) {
	handler := httpHandlerFunc(func(http.ResponseWriter, *http.Request, struct{}) error {
		return gqlErr(errors.New("loading modules: boom"), http.StatusInternalServerError)
	}, struct{}{})
	for _, http2 := range []bool{false, true} {
		t.Run(fmt.Sprintf("http2=%t", http2), func(t *testing.T) {
			srv := httptest.NewUnstartedServer(handler)
			if http2 {
				srv.EnableHTTP2 = true
				srv.StartTLS()
			} else {
				srv.Start()
			}
			defer srv.Close()
			resp, err := srv.Client().Get(srv.URL)
			require.NoError(t, err)
			defer resp.Body.Close()
			require.Equal(t, http2, resp.ProtoMajor == 2)
			require.Equal(t, "application/json", resp.Header.Get("Content-Type"))
			var body struct {
				Errors []struct {
					Message string `json:"message"`
				} `json:"errors"`
			}
			require.NoError(t, json.NewDecoder(resp.Body).Decode(&body))
			require.Len(t, body.Errors, 1)
			require.Equal(t, "loading modules: boom", body.Errors[0].Message)
		})
	}
}
