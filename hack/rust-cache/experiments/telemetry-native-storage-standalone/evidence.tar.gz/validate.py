from pathlib import Path
import json
import os
import subprocess
import time

p=Path(__file__).parent
root='/tmp/dagger-native-telemetry-storage'
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8')
server='^Test(LogsHandler|MetricsHandler|SessionSpanExporter|SessionLogExporter|ClientLogs|ClientRuntimeRetainsTelemetry|ControlAfterCalls|SessionExporters|CloudForwarder|CloudExportError|SessionCloudForwarder|Archive|ForwardedBatch|CloudEngineTelemetryResource|TelemetryOrigin)'
steps=[
    ('clientdb-final',['-race','-run=^Test','./engine/clientdb'],0),
    ('server-race',['-race','-run='+server,'./engine/server'],0),
    ('archive-race',['-race','./engine/archive'],0),
    ('affected-build',['-run=^$','./core','./cmd/dagger','./cmd/engine'],0),
    ('missing-sync-control',['-race','-overlay='+str(p/'missing-sync-overlay.json'),'-run=^TestStoreUpgradeMakesVersionDurableBeforeAppend$','./engine/clientdb'],1),
    ('legacy-frame-index-control',['-race','-overlay='+str(p/'legacy-frame-index-overlay.json'),'-run=^TestStoredProtoMixedHistoryReopensAndRebuildsIndexes$','./engine/clientdb'],1),
]
rows=[]
for label,flags,expected in steps:
    command=[go,'test','-p=2','-count=1','-timeout=240s',*flags]
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,exit_code=result.returncode,expected_exit_code=expected,
             expectation_met=result.returncode==expected,seconds=time.monotonic()-start)
    rows.append(row)
    (p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==expected,(p/(label+'.log')).read_text()[-4000:]
    if label=='missing-sync-control':
        assert 'Not equal' in (p/(label+'.log')).read_text()
    if label=='legacy-frame-index-control':
        text=(p/(label+'.log')).read_text()
        assert 'expected: "new"' in text and 'actual  : "old"' in text,text[-2000:]
