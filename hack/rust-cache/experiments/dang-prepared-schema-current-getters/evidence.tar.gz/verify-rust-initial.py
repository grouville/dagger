from pathlib import Path
import os,subprocess,json,time,urllib.request,shutil
p=Path(__file__).parent;base=p.parent;root=p/'rust-pipeline';root.mkdir(exist_ok=False)
fixture=root/'fixture';fixture.mkdir();template=base/'rust-go-test-collections/fixtures/rust-1'
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(template/name,fixture/name)
(fixture/'Cargo.toml').write_text('[workspace]\nmembers = ["pkg_000", "pkg_001"]\nresolver = "2"\n')
for pkg in ['pkg_000','pkg_001']:
 (fixture/pkg/'src').mkdir(parents=True)
 text=(template/'pkg_000/Cargo.toml').read_text().replace('pkg_000',pkg)
 (fixture/pkg/'Cargo.toml').write_text(text)
lock=(fixture/'Cargo.lock').read_text();(fixture/'Cargo.lock').write_text(lock+'\n[[package]]\nname = "pkg_001"\nversion = "0.1.0"\n')
(fixture/'dagger.toml').write_text('[modules.rust]\nsource = "/tmp/dagger-rust-test-collection-granularity"\n[modules.rust.settings]\nimage = "rust:1.77-bookworm@sha256:83101f6985c93e1e6501b3375de188ee3d2cbb89968bcc91611591f9f447bd42"\nlocked = true\nnativeCache = true\ncacheKey = "schema-reuse-pipeline-oct18"\n')
query=root/'cache-stats.graphql';query.write_text('query { rust { forPackages(names: ["pkg_000"]) { nativeTest { hits actions } } } }\n')
source=fixture/'pkg_000/src/lib.rs';other=fixture/'pkg_001/src/lib.rs'
invalid='pub fn invalid() -> u64 { "excluded crate" }\n'
valid='#[test]\nfn other_package() { assert_eq!(2 + 2, 4); }\n'
def program(tag,value,fail=True):
 return f'pub fn edited_value() -> u64 {{ {value} }}\n#[test]\nfn fresh_{tag}() {{ assert_eq!(edited_value(), {value}); }}\n#[test]\nfn must_fail() {{ '+('panic!("pipeline-required-failure-'+tag+'");' if fail else 'assert!(edited_value() > 0);')+' }\n'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16108/debug/'+route,data=data),timeout=10) as f:return json.load(f)
routes=['collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-receiver-decode','prepared-schema'];flags={r:get(r)['enabled'] for r in routes}
assert not get('wcprof/enabled')['global_enabled']
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16280',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
prefix=['python3',str(base/'local_cli_collector.py')];rows=[]
selection='dag://?check=rust/packages/tests/test&rust-package=pkg_000'
def run(label,arguments,expected=0,diagnostic=None):
 command=prefix+arguments;tick=time.monotonic()
 with (root/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=fixture,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 text=(root/(label+'.log')).read_text(errors='replace');row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode,expected=expected,diagnostic=diagnostic);rows.append(row)
 (root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert (r.returncode==0)==(expected==0),(label,text[-3500:])
 if diagnostic:assert diagnostic in text,(label,'expected diagnostic missing',text[-3500:])
 return text
try:
 for route in routes:get(route+'?enabled='+str(route not in ['shared-receiver-decode','prepared-schema']).lower(),b'')
 for arm in ['before','candidate']:
  get('prepared-schema?enabled='+str(arm=='candidate').lower(),b'')
  other.write_text(invalid)
  first=program(arm+'_a',123);second=program(arm+'_b',456)
  for tag,contents in [(arm+'_a',first),(arm+'_b',second),(arm+'_a_restored',first)]:
   source.write_text(contents)
   name=arm+'_a' if tag.endswith('restored') else tag
   listing=run(tag+'-list',['check',selection,'--list'])
   assert 'fresh_'+name in listing and 'must_fail' in listing,(tag,'missing current tests')
   stale=arm+'_b' if name.endswith('_a') else arm+'_a'
   assert 'fresh_'+stale not in listing,(tag,'stale test discovered')
   run(tag+'-selected-pass',['check',selection+'&rust-test=src/lib.rs::fresh_'+name])
   run(tag+'-selected-fail',['check',selection+'&rust-test=src/lib.rs::must_fail'],1,'pipeline-required-failure-'+name)
  for repeat in range(2):
   output=run(arm+f'-native-cache-{repeat}',['api','with-session','--load-workspace-modules','python3',str(base/'collection-work-amplification/query.py'),str(query)])
   payload=next(json.loads(line) for line in output.splitlines() if line.startswith('{"rust"'))
   stats=payload['rust']['forPackages']['nativeTest'];assert stats['actions']>0 and 0<=stats['hits']<=stats['actions']
   if repeat==1:assert stats['hits']==stats['actions'],('native cache failed to recover',stats)
   rows[-1]['native_cache_stats']=stats;(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
  run(arm+'-all-reports-invalid',['check','rust:packages/tests/test'],1,'mismatched types')
  other.write_text(valid);source.write_text(program(arm+'_repaired',789,False))
  run(arm+'-all-repaired',['check','rust:packages/tests/test'])
  run(arm+'-workspace-api',['api','call','rust','test','--source','.'])
finally:
 for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
 (root/'final-state.json').write_text(json.dumps(dict(flags_after={r:get(r) for r in routes},lifecycle=get('client-lifecycle'),original_fixtures_untouched=True),indent=2)+'\n')
