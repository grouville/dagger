from pathlib import Path
import json,os,subprocess,time,urllib.request
p=Path(__file__).parent;base=p.parent;root=p/'module-edits';root.mkdir(exist_ok=False)
fixture=root/'fixture';fixture.mkdir();(fixture/'module').mkdir();subprocess.run(['git','init','--quiet',str(fixture)],check=True)
(fixture/'dagger.toml').write_text('[modules.probe]\nsource = "module"\n')
(fixture/'module/dagger-module.toml').write_text('name = "probe"\nengineVersion = "v1.0.0-0"\n[runtime]\nsource = "dang"\n')
source=fixture/'module/main.dang'
a='''type Probe {
  run(value: Int!): Int! {
    if (value == 0) { raise "module-a-failure" }
    Nested(value: value).answer()
  }
}
type Nested {
  value: Int!
  let computed: Int! = value * 2
  answer(): Int! { computed }
}
'''
b=a.replace('module-a-failure','module-b-failure').replace('value * 2','value * 3')
c='''type Probe {
  run(value: String!): String! { value + "-schema-c" }
}
'''
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16108/debug/'+route,data=data),timeout=10) as f:return json.load(f)
previous=get('prepared-schema')['enabled'];assert not get('wcprof/enabled')['global_enabled']
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16280',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows=[]
def run(label,value,expected=None,error=None):
 command=['python3',str(base/'local_cli_collector.py'),'api','call','probe','run','--value',str(value)];tick=time.monotonic()
 with (root/(label+'.log')).open('w') as out:result=subprocess.run(command,cwd=fixture,env=env,stdout=out,stderr=subprocess.STDOUT)
 text=(root/(label+'.log')).read_text(errors='replace')
 row=dict(label=label,value=value,expected_value=expected,expected_error=error,exit_code=result.returncode,seconds=time.monotonic()-tick);rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if error:assert result.returncode!=0 and error in text,(label,text[-2500:])
 else:assert result.returncode==0 and any(line.strip().strip('"')==str(expected) for line in text.splitlines()),(label,text[-2500:])
try:
 for arm,seed in [('before',4),('candidate',14)]:
  get('prepared-schema?enabled='+str(arm=='candidate').lower(),b'')
  source.write_text(a)
  run(arm+'-a-first',seed,seed*2);run(arm+'-a-fresh-argument',seed+1,(seed+1)*2);run(arm+'-a-error',0,error='module-a-failure')
  source.write_text(b)
  run(arm+'-b-edited-initializer',seed,seed*3);run(arm+'-b-error',0,error='module-b-failure')
  source.write_text(c)
  run(arm+'-c-edited-schema','current','current-schema-c')
  source.write_text(a)
  run(arm+'-a-restored',seed,seed*2);run(arm+'-a-restored-fresh-argument',seed+2,(seed+2)*2);run(arm+'-a-restored-error',0,error='module-a-failure')
finally:
 get('prepared-schema?enabled='+str(previous).lower(),b'')
 (root/'final-state.json').write_text(json.dumps(dict(prepared_schema=get('prepared-schema'),lifecycle=get('client-lifecycle')),indent=2)+'\n')
