from pathlib import Path
p=Path(__file__).parent;old=p.parent/'dang-shared-receiver-decode'
s=(old/'capture.py').read_text().replace("'shared-receiver-decode']","'shared-receiver-decode','prepared-schema']")
s=s.replace("mode('shared-receiver-decode',options.arm=='candidate')","mode('shared-receiver-decode',False)\n    mode('prepared-schema',options.arm=='candidate')")
s=s.replace("    before=heap();before_cpu=cpu();gc_before=get('snapshot-collection');tick=time.monotonic()","    (root/'prepared-declarations-before.json').write_text(json.dumps(get('reusable-declarations'),indent=2)+'\\n')\n    before=heap();before_cpu=cpu();gc_before=get('snapshot-collection');tick=time.monotonic()")
s=s.replace("    (root/'receiver-decode-state.json').write_text(json.dumps(get('shared-receiver-decode'),indent=2)+'\\n')","    (root/'prepared-declarations-after.json').write_text(json.dumps(get('reusable-declarations'),indent=2)+'\\n')")
(p/'capture.py').write_text(s)
for script in ['profile.py','analyze.py','analyze-all.py']:(p/script).write_bytes((old/script).read_bytes())
s=(old/'verify-module.py').read_text().replace("'shared-receiver-decode']","'shared-receiver-decode','prepared-schema']")
s=s.replace("str(route!='shared-function-metadata')","str(route not in ['shared-function-metadata','shared-receiver-decode'])")
(p/'verify-module.py').write_text(s)
