from pathlib import Path
import json,hashlib,subprocess,tarfile,gzip,io,shutil,time
p=Path(__file__).parent;out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/dang-prepared-schema-current-getters');out.mkdir()
with (p/'rust-module-source.tar').open('wb') as target:subprocess.run(['git','archive','--format=tar','HEAD'],cwd='/tmp/dagger-rust-test-collection-granularity',stdout=target,check=True)
streams={}
for relative in ['capture-before','capture-candidate','allocation-study/capture']:
 capture=p/relative;events=[]
 for chunk in sorted(capture.glob('chunk-*.ndjson.gz')):
  lines=gzip.decompress(chunk.read_bytes()).splitlines();header=json.loads(lines[0]);assert header['dropped_events']==0;events.extend(lines[1:])
 assert not header.get('open_ops')
 reconstructed=(json.dumps(dict(header,event_count=len(events)))+'\n').encode()+b'\n'.join(events)+b'\n'
 if (capture/'wcprof-complete.ndjson').exists():assert reconstructed==(capture/'wcprof-complete.ndjson').read_bytes()
 streams[relative]=dict(bytes=len(reconstructed),sha256=hashlib.sha256(reconstructed).hexdigest(),events=len(events),lossless=True)
files=[f for f in p.rglob('*') if f.is_file() and '.git' not in f.parts and '__pycache__' not in f.parts and f.name not in ['dagger-engine','wcprof-complete.ndjson','evidence.tar.gz']]
manifest=dict(status='development-stack candidate; prepared-schema flag restored to disabled',treatment='Only prepared schema reuse; authored function getters, separate clients, initialization, cache keys, telemetry and cleanup preserved.',existing_engine_source=dict(commit='334a0c56bf6229b0ad54feaa83275f7613dd2caf',artifact='hack/rust-cache/experiments/shared-receiver-decode/evidence.tar.gz',sha256='0b7ea3ecb13f2e07175a996726afcb02cd4fc03829ebfead43b2b2eedcd2390a',note='Full exact engine replacements and interpreter sources are in the referenced archive; no production source changes in this retest.'),source_identity=json.loads((p/'source-identity.json').read_text()),reuse_context=json.loads((p/'reuse-context.json').read_text()),validation=dict(go_checks=6,rust_native_cases=28,module_source_edit_cases=18,expected_failures_included=True),limits=['Warm edited listing only; no new cold timing','Rust checks establish correctness, not latency gain or transferred-cache behavior','Existing compiled-declaration prototype required; not a standalone main patch','Initial non-Git fixture and two inspection-query failures retained; Go timings completed beforehand'],wcprof_streams=streams,files={str(f.relative_to(p)):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(files)})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copy2(p/'assessment.json',out/'summary.json');shutil.copy2(p/'final-state.json',out/'final-state.json')
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();tick=time.monotonic()
with (out/'evidence.tar.gz').open('wb') as target:
 with gzip.GzipFile(filename='',mode='wb',fileobj=target,compresslevel=6,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|') as archive:
   for f in sorted(files):
    info=archive.gettarinfo(str(f),arcname=str(f.relative_to(p)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with f.open('rb') as data:archive.addfile(info,data)
   info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mtime=0;archive.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(out/'evidence.tar.gz','r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(files)+1
 for member in members:
  data=archive.extractfile(member).read()
  if member.name=='manifest.json':assert data==manifest_bytes
  else:assert hashlib.sha256(data).hexdigest()==manifest['files'][member.name]['sha256']
artifact=out/'evidence.tar.gz';record=dict(bytes=artifact.stat().st_size,sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),members=len(files)+1,all_member_hashes_verified=True,wcprof_streams_reconstructed=True,archive_seconds=time.monotonic()-tick)
(out/'archive.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
