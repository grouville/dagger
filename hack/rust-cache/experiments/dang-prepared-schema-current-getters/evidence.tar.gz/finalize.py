from pathlib import Path
import json,subprocess,urllib.request,hashlib,shutil
p=Path(__file__).parent;base=p.parent;old=base/'dang-shared-receiver-decode'
def get(route):
 with urllib.request.urlopen('http://127.0.0.1:16108/debug/'+route,timeout=15) as f:return json.load(f)
state=get('client-lifecycle');assert state['active_requests']==0 and not state.get('sessions')
plan=json.loads((old/'engine-plan.json').read_text());flags={r:get(r)['enabled'] for r in plan['flags']};assert flags==plan['flags'];assert not get('prepared-schema')['enabled']
assert not get('wcprof/enabled')['global_enabled'];assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
activation=json.loads((old/'activation.json').read_text());binaries={activation['engine']:activation['sha256'],**activation['retained_engines']}
for name,expected in binaries.items():
 actual=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==expected
for workload in ['test','source']:
 r=json.loads((p/(workload+'-edit-paired/restoration.json')).read_text());assert r['source_restored'] and r['test_restored'] and r['config_restored']
for relative,number,error_key in [('checks.json',6,None),('rust-pipeline/results.json',28,'expected'),('module-edits/results.json',18,'expected_error')]:
 rows=json.loads((p/relative).read_text());assert len(rows)==number
 for r in rows:
  if error_key=='expected':assert (r['exit_code']==0)==(r['expected']==0) and not r.get('cancelled')
  elif error_key=='expected_error':assert (r['exit_code']!=0)==bool(r['expected_error'])
  else:assert r['exit_code']==0
identity={}
for name,path in [('go',Path('/tmp/dagger-go-snapshot-test-directories')),('rust',Path('/tmp/dagger-rust-test-collection-granularity')),('repository',Path('/tmp/dagger-go-real-repository-main'))]:
 identity[name]=dict(path=str(path),commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=path,text=True).splitlines())
assert identity['go']['commit']=='a3d0e4bf562b834c31135bff24e5931fd32b3acc' and not identity['go']['status']
(p/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(p/'final-state.json').write_text(json.dumps(dict(binaries=binaries,flags=flags,prepared_schema=get('prepared-schema'),lifecycle=state,wcprof=get('wcprof/enabled'),lock_profiler=get('lock-profiler'),validation=dict(go=6,rust_native=28,module_edits=18),timings_completed_before_rust_setup_attempts=True,cold_performance_unmeasured=True,rust_latency_gain_unmeasured=True),indent=2)+'\n')
assets=p/'sdk-sources';assets.mkdir()
for name in ['sdk.patch','before-helpers.go','after-helpers.go','before-declarations.go','after-declarations.go','declarations_test.go','prepared_schema_test.go']:
 shutil.copy2(base/'dang-prepared-schema'/name,assets/name)
shutil.copy2(old/'helpers.go',assets/'measured-helpers.go');shutil.copy2(base/'dang-prepared-schema/mode.go',assets/'mode.go')
shutil.copy2(old/'sdk-race.log',assets/'exact-engine-sdk-race.log');shutil.copy2(old/'validation.json',assets/'exact-engine-validation.json')
shutil.copytree(base/'native-getter-allocation-attribution',p/'allocation-study',ignore=shutil.ignore_patterns('__pycache__','wcprof-complete.ndjson'))
for source in [Path('/tmp/dagger-rust-test-collection-granularity/main.dang'),Path('/tmp/dagger-rust-test-collection-granularity/dagger-module.toml')]:
 target=p/'rust-module-source'/source.name;target.parent.mkdir(exist_ok=True);shutil.copy2(source,target)
print(json.dumps(dict(flags_restored=True,retained_engines_unchanged=True,active_requests=state['active_requests'],validation_cases=52,go=identity['go']['commit'],rust=identity['rust']['commit'])),flush=True)
