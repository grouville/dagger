package main

import (
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"github.com/google/pprof/profile"
)

type totals struct {
	Bytes   int64 `json:"bytes"`
	Objects int64 `json:"objects"`
}
type row struct {
	Name string `json:"name"`
	totals
}

func category(names []string) string {
	has := func(fragment string) bool {
		for _, name := range names {
			if strings.Contains(name, fragment) {
				return true
			}
		}
		return false
	}
	switch {
	case has(".callDangFunction"):
		switch {
		case has(".decodeDangParent"):
			return "receiver JSON decoding"
		case has(".dangConverter.convert"):
			switch {
			case has(".(*FunctionBase).Eval"):
				return "receiver method construction"
			case has(".evaluateDangClassBody"):
				return "receiver class initialization"
			default:
				return "receiver value conversion"
			}
		default:
			return "getter or function execution"
		}
	case has(".(*Server).SchemaForView"):
		return "GraphQL schema materialization"
	case has(".(*Server).initializeClientRuntime"):
		return "client runtime initialization"
	case has(".(*runtime).Call") || has(".evalDangSource"):
		switch {
		case has(".(*decodedSchemaCache).read"):
			return "schema file reading and decoding"
		case has(".Marshal") || has(".marshal"):
			return "native runtime result encoding"
		default:
			return "other native runtime preparation"
		}
	case has("/clientdb."):
		return "telemetry storage"
	case has("/pkg/dang."):
		return "other interpreted module execution"
	case has(".(*ModuleFunction).Call"):
		return "engine module-call preparation"
	case has("/dagql."):
		return "other graph evaluation"
	default:
		return "other engine work"
	}
}

func read(path string) (*profile.Profile, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	return profile.Parse(file)
}
func main() {
	if len(os.Args) != 3 {
		panic("usage: allocations before.pprof after.pprof")
	}
	sums := map[string]totals{}
	leaf := map[string]totals{}
	var total totals
	for index, path := range os.Args[1:] {
		p, err := read(path)
		if err != nil {
			panic(err)
		}
		bytesIndex, objectsIndex := -1, -1
		for i, t := range p.SampleType {
			if t.Type == "alloc_space" {
				bytesIndex = i
			}
			if t.Type == "alloc_objects" {
				objectsIndex = i
			}
		}
		if bytesIndex < 0 || objectsIndex < 0 {
			panic("missing allocation sample types")
		}
		sign := int64(1)
		if index == 0 {
			sign = -1
		}
		for _, sample := range p.Sample {
			var names []string
			for _, location := range sample.Location {
				for _, line := range location.Line {
					if line.Function != nil {
						names = append(names, line.Function.Name)
					}
				}
			}
			delta := totals{Bytes: sign * sample.Value[bytesIndex], Objects: sign * sample.Value[objectsIndex]}
			name := category(names)
			sum := sums[name]
			sum.Bytes += delta.Bytes
			sum.Objects += delta.Objects
			sums[name] = sum
			if len(names) > 0 {
				head := leaf[names[0]]
				head.Bytes += delta.Bytes
				head.Objects += delta.Objects
				leaf[names[0]] = head
			}
			total.Bytes += delta.Bytes
			total.Objects += delta.Objects
		}
	}
	ordered := func(m map[string]totals) []row {
		var rows []row
		for name, value := range m {
			rows = append(rows, row{Name: name, totals: value})
		}
		sort.Slice(rows, func(i, j int) bool { return rows[i].Bytes > rows[j].Bytes })
		return rows
	}
	result := struct {
		Note       string `json:"note"`
		Total      totals `json:"sampled_total"`
		Categories []row  `json:"exclusive_stack_categories"`
		Leaf       []row  `json:"allocation_sites"`
	}{Note: "Sampled allocation-profile difference without forced GC. Categories are exclusive by the documented stack precedence, not additive cumulative frame totals. Natural GC reporting can lag the command.", Total: total, Categories: ordered(sums), Leaf: ordered(leaf)}
	output, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		panic(err)
	}
	fmt.Println(string(output))
}
