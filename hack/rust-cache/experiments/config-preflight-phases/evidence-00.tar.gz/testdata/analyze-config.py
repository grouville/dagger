from collections import Counter, defaultdict
from pathlib import Path
import json
import statistics

root = Path(__file__).parent
p = root / 'capture'
metadata = json.loads((p / 'metadata.json').read_text())
activation = json.loads((root / 'activation.json').read_text())
assert metadata['engine_sha256'] == activation['after_sha256']
assert metadata['engine_sha256'] == json.loads((root / 'engine-builds.json').read_text())[1]['sha256']
for flag in ['lazy-schema-candidates', 'schema-read-buffers', 'prepared-schema',
             'recovered-schema-templates', 'canonical-core-providers']:
    assert not metadata['flags_during'][flag], flag

ops = {}
intervals = defaultdict(list)
with (p / 'wcprof-complete.ndjson').open() as stream:
    header = json.loads(next(stream))
    names = header['strings']
    for line in stream:
        event = json.loads(line)
        if event['e'] == 'op':
            assert event['id'] not in ops
            event['cls'] = names[event['c']]
            ops[event['id']] = event
        if event['e'] in ['op', 'wait']:
            intervals[event.get('p', 0)].append((event['s'], event['d']))
assert header['dropped_events'] == 0 and not header.get('open_ops')


def union_ns(spans):
    end = -1
    total = 0
    for start, stop in sorted(spans):
        total += max(0, stop - max(start, end))
        end = max(stop, end)
    return total


def own_ns(event):
    spans = [(max(event['s'], start), min(event['d'], end))
             for start, end in intervals[event['id']]
             if end > event['s'] and start < event['d']]
    return max(0, event['d'] - event['s'] - union_ns(spans))


def text_id(event, key):
    return names[event.get(key, 0)]


def stats(events):
    if not events:
        return dict(count=0)
    ns = sorted(event['d'] - event['s'] for event in events)
    return dict(count=len(ns), outcomes=dict(Counter(e.get('o') for e in events)),
                sum_seconds=sum(ns) / 1e9,
                own_seconds=sum(own_ns(e) for e in events) / 1e9,
                union_seconds=union_ns((e['s'], e['d']) for e in events) / 1e9,
                median_ms=statistics.median(ns) / 1e6,
                p95_ms=ns[min(len(ns)-1, int(len(ns)*.95))] / 1e6,
                max_ms=max(ns) / 1e6)


phase_names = ['core.moduleDynamicInputs', 'core.localClientGuard',
               'core.gitClientGuard', 'core.readGitClientDeclarations',
               'core.config.ownerMetadata', 'core.config.backendClient',
               'core.config.stat', 'core.config.read']
groups = {name: [e for e in ops.values() if e['cls'] == name] for name in phase_names}
assert all(groups.values()), {name: len(rows) for name, rows in groups.items()}


def dynamic_input_name(event):
    seen = set()
    while event is not None:
        assert event['id'] not in seen
        seen.add(event['id'])
        if event['cls'] == 'core.moduleDynamicInputs':
            return text_id(event, 'i')
        event = ops.get(event.get('p', 0))
    return '<no-recorded-dynamic-input-ancestor>'


by_file = defaultdict(list)
for cls in ['core.config.stat', 'core.config.read']:
    for event in groups[cls]:
        by_file[(cls, text_id(event, 'cl'), text_id(event, 'i'))].append(event)

files = []
for (cls, client, path), rows in by_file.items():
    # Fixed-schedule overlap screen only. A group ends at the FIRST caller's
    # completion, never at a follower's later completion. Chaining overlapping
    # intervals would incorrectly imply reuse of a completed read's result.
    leaders = 0
    followers = 0
    leader_end = -1
    for event in sorted(rows, key=lambda e: (e['s'], e['id'])):
        if event['s'] < leader_end:
            followers += 1
        else:
            leaders += 1
            leader_end = event['d']
    activity = []
    for e in rows:
        activity.extend([(e['s'], 1), (e['d'], -1)])
    concurrent = 0
    maximum = 0
    for _, delta in sorted(activity):
        concurrent += delta
        maximum = max(maximum, concurrent)
    assert concurrent == 0
    files.append(dict(phase=cls, client=client, path=path, **stats(rows),
                      callers=dict(Counter(dynamic_input_name(e) for e in rows)),
                      first_completion_groups=leaders, overlapping_followers=followers,
                      max_concurrent=maximum))

callers = defaultdict(list)
for event in groups['core.moduleDynamicInputs']:
    callers[text_id(event, 'i')].append(event)

result = dict(
    scope='One diagnostic listing, not a timing comparison. Durations of concurrent calls overlap. Own time subtracts direct recorded child intervals and waits and may contain uninstrumented blocking. Per-file first-completion grouping screens baseline overlap only; it does not prove safe coalescing or predict elapsed savings. Equal host/path is not a complete declaration-result cache key.',
    capture_dir=str(p), engine_sha256=metadata['engine_sha256'],
    events=header['event_count'],
    phases={name: stats(rows) for name, rows in groups.items()},
    files=sorted(files, key=lambda row: row['sum_seconds'], reverse=True),
    callers={name: stats(rows) for name, rows in sorted(callers.items(),
             key=lambda item: len(item[1]), reverse=True)},
    declaration_errors=[dict(id=e['id'], outcome=e.get('o'),
                             module=text_id(e, 'i'), start_ns=e['s'], end_ns=e['d'])
                        for e in groups['core.readGitClientDeclarations']
                        if e.get('o') != 'ok'])
(p / 'configuration-phases.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(phases=result['phases'],
                      files=[{k: v for k, v in row.items() if k != 'callers'}
                             for row in result['files']],
                      declaration_errors=len(result['declaration_errors'])), indent=2))
