from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess
import time

p = Path(__file__).parent
work = Path('/tmp/dagger-cache-usage-payload-reads')
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
subprocess.run([str(Path(go).with_name('gofmt')), '-w',
                *[str(p / name) for name in ['before-cache_usage.go', 'after-cache_usage.go', 'cache_usage_payload_test.go']]], check=True)
for name, source in [('cache_usage.go', 'after-cache_usage.go'), ('cache_usage_payload_test.go', 'cache_usage_payload_test.go')]:
    (work / 'dagql' / name).write_bytes((p / source).read_bytes())
metadata = dict(upstream_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
                dependencies_unchanged=True, normal_gc=True, procs=8,
                go_version=subprocess.check_output([go, 'version'], env=env, text=True).strip(),
                source_sha256={name: hashlib.sha256((p / name).read_bytes()).hexdigest() for name in ['before-cache_usage.go', 'after-cache_usage.go', 'cache_usage_payload_test.go']})
(p / 'validation-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
commands = []
def run(label, arm, arguments):
    command = [go, 'test', '-p', '2', '-buildvcs=false', '-mod=readonly',
               '-overlay', str(p / (arm + '-overlay.json')), *arguments, './dagql']
    tick = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=work, env=env, stdout=output, stderr=subprocess.STDOUT)
    commands.append(dict(label=label, arm=arm, command=command, exit_code=result.returncode, seconds=time.monotonic()-tick))
    (p / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-4000:]
prior = json.loads((p.parent / 'commands.json').read_text())
assert all(next(row for row in prior if row['label'] == 'race-' + arm)['exit_code'] == 0 for arm in ['before', 'after'])
assert (p / 'after-cache_usage.go').read_bytes() == (p.parent / 'after-cache_usage.go').read_bytes()
assert (p / 'cache_usage_payload_test.go').read_text().split('func BenchmarkCacheUsagePayload')[0] == (p.parent / 'cache_usage_payload_test.go').read_text().split('func BenchmarkCacheUsagePayload')[0]
(p / 'race-reference.json').write_text(json.dumps(dict(path=str(p.parent / 'commands.json'), reason='Production code and ownership regression are unchanged. Only duplicate benchmark link positions are corrected to distinct indices.'), indent=2) + '\n')
rows = []
for pair in range(4):
    for arm in (['after', 'before'] if pair % 2 == 0 else ['before', 'after']):
        label = f'{pair}-{arm}'
        run(label, arm, ['-run=^$', '-bench=^BenchmarkCacheUsagePayload$', '-benchtime=500ms', '-count=1', '-cpu=8', '-benchmem'])
        for line in (p / (label + '.log')).read_text().splitlines():
            if not line.startswith('BenchmarkCacheUsagePayload/'):
                continue
            words = line.split()
            metrics = {words[i+1]: float(words[i]) for i in range(2, len(words)-1, 2)}
            rows.append(dict(pair=pair, arm=arm, case=words[0].removeprefix('BenchmarkCacheUsagePayload/').removesuffix('-8'), metrics=metrics))
        (p / 'component-results.json').write_text(json.dumps(rows, indent=2) + '\n')
assert len(rows) == 48
summary = {}
for case in sorted({r['case'] for r in rows}):
    entry = {arm: {metric: statistics.median(r['metrics'][metric] for r in rows if r['case'] == case and r['arm'] == arm)
                   for metric in ['ns/op', 'B/op', 'allocs/op']} for arm in ['before', 'after']}
    entry['faster_pairs'] = sum(next(r['metrics']['ns/op'] for r in rows if r['case'] == case and r['pair'] == pair and r['arm'] == 'after') <
                                next(r['metrics']['ns/op'] for r in rows if r['case'] == case and r['pair'] == pair and r['arm'] == 'before') for pair in range(4))
    summary[case] = entry
(p / 'component-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
