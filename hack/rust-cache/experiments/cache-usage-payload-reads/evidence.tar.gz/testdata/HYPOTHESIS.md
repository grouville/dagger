# Avoid copying unrelated payload fields during disk-usage sampling

A real collection-listing tail dump caught cache-usage capture in `loadPayloadState -> cloneSnapshotRefLinks` while publication waited for the graph lock. Main clones snapshot links for every capture and every revision check. Capture then clones them a second time for unloaded records.

Read the needed payload fields under the same payload read lock. Loaded records keep the immutable value; unloaded records still deep-copy their snapshot links exactly once. Revision validation reads only the revision, after checking graph membership. Existing size maps remain independent copies. No callback, usage ownership, resampling, cache key or eviction-policy change is intended.

Run existing usage/prune tests with the race detector before and after, plus one ownership/revision regression. Measure capture and validation for scalar, loaded-snapshot and unloaded-snapshot rows in four fixed alternating process pairs, using the unchanged main dependencies and normal GC. Preserve all results. A component win alone does not establish full collection-listing impact.
