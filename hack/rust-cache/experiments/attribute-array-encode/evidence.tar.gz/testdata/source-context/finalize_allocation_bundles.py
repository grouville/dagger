from pathlib import Path
import json,subprocess,time,urllib.request
base=Path('/tmp/rust-cache-sipsma-review')
routes=['prepared-schema','callback-caller-reuse','lazy-type-maps','interface-field-snapshots','parallel-client-admission']
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16104/debug/'+route,data=data),timeout=20) as r:return json.load(r)
def mode(route,enabled):assert get(route+'?enabled='+str(enabled).lower(),b'')['enabled']==enabled
saved={r:get(r)['enabled'] for r in routes};assert not any(saved.values())
try:
 for name,enabled_routes in [('go-allocation-bundle',routes[:-1]),('go-admission-allocation-bundle',routes)]:
  p=base/name
  for route in routes:mode(route,route in enabled_routes)
  command=['python3',str(base/'trivial-scalar-projection/verify_retained_first.py'),name+'-after-cohort']
  tick=time.monotonic()
  with (p/'retained-after-cohort.log').open('w') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
  row=dict(command=command,seconds=time.monotonic()-tick,exit_code=r.returncode,modes={route:get(route) for route in routes})
  (p/'retained-after-cohort.json').write_text(json.dumps(row,indent=2)+'\n');assert r.returncode==0
  print(name, 'all six retained histories reusable with candidate enabled',flush=True)
finally:
 for route,state in saved.items():mode(route,state)
 state=dict(modes={route:get(route) for route in routes},wcprof=get('wcprof/enabled')['global_enabled'],locks=get('lock-profiler'),span_sharing=get('span-row-sharing')['enabled'],selected_go_module='/tmp/dagger-go-module-test-name-index',new_pr_opened=False)
 for name in ['go-allocation-bundle','go-admission-allocation-bundle']:(base/name/'selected-state.json').write_text(json.dumps(state,indent=2)+'\n')
 assert not state['wcprof'] and not state['span_sharing'] and state['locks']==dict(mutex_fraction=0,block_profile_rate_ns=0)
