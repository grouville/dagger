package clientdb

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"

	commonpb "go.opentelemetry.io/proto/otlp/common/v1"
	"google.golang.org/protobuf/encoding/protojson"
)

var attributeArrayEncodeEnabled atomic.Bool

func init() {
	attributeArrayEncodeEnabled.Store(os.Getenv("DAGGER_DIAG_ATTRIBUTE_ARRAY_ENCODE") == "1")
}

// A KeyValueList encodes the attributes with one encoder. Keep only its values
// array so stored records retain the existing JSON format.
func marshalAttributeArray(attrs []*commonpb.KeyValue) ([]byte, error) {
	encoded, err := (protojson.MarshalOptions{}).MarshalAppend(make([]byte, 0, 64*len(attrs)+16), &commonpb.KeyValueList{Values: attrs})
	if err != nil {
		return nil, fmt.Errorf("failed to protojson marshal: %w", err)
	}
	return encoded[bytes.IndexByte(encoded, '[') : bytes.LastIndexByte(encoded, ']')+1], nil
}

func AttributeArrayEncodeDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		attributeArrayEncodeEnabled.Store(enabled)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": attributeArrayEncodeEnabled.Load()})
}
