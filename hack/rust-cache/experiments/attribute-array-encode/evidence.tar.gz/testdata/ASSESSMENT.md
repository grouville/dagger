# Attribute-array encoding screening

The candidate feeds all attributes through one native KeyValueList protobuf-JSON encoder, then retains only its values array. It uses the same protobuf library, JSON values and existing storage format. Existing clientdb tests pass under the race detector with the candidate disabled and enabled, including invalid UTF-8, nil elements, nested values and stored-key scans.

Four alternating fresh-process component pairs measure 23968.5 -> 23943.5 ns/op, faster in two pairs. Allocation changes 13891 -> 13443 bytes and 170 -> 168 allocations. That is no useful speedup. No engine is deployed for this candidate and no complete-command benchmark is warranted. The source and all observations are retained. No proposal or PR is added.
