from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
base='/tmp/dagger-filesync-snapshot-seeds'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
subprocess.run([str(Path(go).with_name('gofmt')),'-w',str(p/'span.go'),str(p/'attribute_array_encode.go')],check=True)
rows=[]
def run(label,args,enabled):
 command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/'component-overlay.json'),*args,'./engine/clientdb']
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as output:r=subprocess.run(command,cwd=base,env=dict(env,DAGGER_DIAG_ATTRIBUTE_ARRAY_ENCODE=str(int(enabled))),stdout=output,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,enabled=enabled,exit_code=r.returncode,seconds=time.monotonic()-tick);rows.append(row);(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True)
 assert r.returncode==0,(p/(label+'.log')).read_text()[-5000:]
 return (p/(label+'.log')).read_text()
for enabled in [False,True]:run('clientdb-race-'+str(enabled).lower(),['-count=1','-race'],enabled)
bench=[]
for pair in range(4):
 for arm in (['after','before'] if pair%2==0 else ['before','after']):
  text=run(f'benchmark-{pair}-{arm}',['-run=^$','-bench=^BenchmarkMarshalProtoJSONs$/^current$','-benchtime=750ms','-cpu=1','-count=1','-benchmem'],arm=='after')
  m=re.search(r'BenchmarkMarshalProtoJSONs/current\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op',text);assert m,text
  bench.append(dict(pair=pair,arm=arm,ns=float(m[1]),bytes=float(m[2]),allocs=float(m[3])));(p/'component-results.json').write_text(json.dumps(bench,indent=2)+'\n')
summary={arm:{field:statistics.median(r[field] for r in bench if r['arm']==arm) for field in ['ns','bytes','allocs']} for arm in ['before','after']}
summary['faster_pairs']=sum(next(r['ns'] for r in bench if r['pair']==pair and r['arm']=='after')<next(r['ns'] for r in bench if r['pair']==pair and r['arm']=='before') for pair in range(4))
(p/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
