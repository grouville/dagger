from pathlib import Path
import hashlib
import io
import json
import shutil
import tarfile

p = Path(__file__).parent
repository = Path('/home/dagger/dagger_otra')
for study, name in [(p,'cache-treeset-iteration'), (p.parent/'cache-small-id-sets','cache-small-id-sets')]:
    decision = json.loads((study/'decision.json').read_text())
    assert not decision['selected'] and not decision['engine_replaced'] and not decision['pr_opened']
    dest = repository/'hack/rust-cache/experiments'/name
    dest.mkdir(parents=True,exist_ok=False)
    sources = [f for f in study.rglob('*') if f.is_file() and '__pycache__' not in f.parts]
    records = []
    archive = dest/'evidence.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=6) as output:
        for source in sorted(sources):
            data = source.read_bytes()
            relative = source.relative_to(study).as_posix()
            entry = tarfile.TarInfo(relative)
            entry.size=len(data);entry.mode=0o644;entry.mtime=0
            output.addfile(entry,io.BytesIO(data))
            records.append(dict(path=relative,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
    with tarfile.open(archive,'r:gz') as saved:
        for record in records:
            data = saved.extractfile(record['path']).read()
            assert len(data)==record['size'] and hashlib.sha256(data).hexdigest()==record['sha256']
    (dest/'MANIFEST.json').write_text(json.dumps(dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=records,decision=decision),indent=2)+'\n')
    if name=='cache-treeset-iteration':
        shutil.copy2(p/'iterator-stack.patch',dest/'iterator-stack.patch')
        note='The private stack change improves larger full iterations but has early-stop tradeoffs. The saved real-listing allocation profile attributes only 0.065% of sampled objects to this stack. No complete-listing gain is established. The plain patch is included beside the archive for review.'
    else:
        note='The separate inline-ID prototype improves singleton construction but slows promotion and adds allocations for larger sets. It is unselected; no actual-cache or complete-command benefit is claimed.'
    (dest/'README.md').write_text('# '+name+'\n\nSee [the assessment](../../NATIVE_TREESET_ITERATION.md). '+note+'\n\nThe verified archive includes exact source, dependencies or overlays, checks, every component sample and the decision. Original absolute paths need adapting for replay. No engine binary, cache volume or credentials are included. The selected engine is unchanged and no PR is open.\n')
    print(json.dumps(dict(study=name,members=len(records),archive_bytes=archive.stat().st_size)),flush=True)
