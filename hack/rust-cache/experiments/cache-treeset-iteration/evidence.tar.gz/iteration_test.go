package set

import (
	"cmp"
	"fmt"
	"testing"
)

func TestTreeSetIterationStopsAndRestarts(t *testing.T) {
	for _, count := range []int{0, 1, 8, 128, 4096} {
		for _, descending := range []bool{false, true} {
			t.Run(fmt.Sprintf("count=%d/descending=%v", count, descending), func(t *testing.T) {
				compare := cmp.Compare[int]
				if descending {
					compare = func(a, b int) int { return cmp.Compare(b, a) }
				}
				values := NewTreeSet(compare)
				for i := range count {
					values.Insert(i)
				}
				for _, limit := range []int{1, 4, count + 1, 1} {
					seen := 0
					for value := range values.Items() {
						want := seen
						if descending {
							want = count - 1 - seen
						}
						if value != want {
							t.Fatalf("item %d: got %d, want %d", seen, value, want)
						}
						seen++
						if seen == limit {
							break
						}
					}
					if seen != min(count, limit) || values.Size() != count {
						t.Fatalf("iteration changed contents: seen=%d size=%d", seen, values.Size())
					}
				}
			})
		}
	}
}

var treeIterationSum int

func BenchmarkTreeSetIteration(b *testing.B) {
	for _, count := range []int{0, 1, 8, 128, 4096} {
		b.Run(fmt.Sprint(count), func(b *testing.B) {
			values := NewTreeSet(cmp.Compare[int])
			for i := range count {
				values.Insert(i)
			}
			b.Run("all", func(b *testing.B) {
				b.ReportAllocs()
				var sum int
				for range b.N {
					for value := range values.Items() {
						sum += value
					}
				}
				treeIterationSum = sum
			})
			b.Run("first", func(b *testing.B) {
				b.ReportAllocs()
				var sum int
				for range b.N {
					for value := range values.Items() {
						sum += value
						break
					}
				}
				treeIterationSum = sum
			})
		})
	}
}
