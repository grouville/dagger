// Copyright IBM Corp. 2022, 2025
// SPDX-License-Identifier: MPL-2.0

package set

type stack[T any] struct {
	items []T
}

func makeStack[T any]() *stack[T] {
	return new(stack[T])
}

func (s *stack[T]) push(item T) {
	s.items = append(s.items, item)
}

func (s *stack[T]) pop() T {
	last := len(s.items) - 1
	item := s.items[last]
	var zero T
	s.items[last] = zero
	s.items = s.items[:last]
	return item
}

func (s *stack[T]) empty() bool {
	return len(s.items) == 0
}
