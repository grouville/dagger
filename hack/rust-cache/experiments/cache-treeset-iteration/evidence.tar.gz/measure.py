from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOWORK='off', GOTOOLCHAIN='local', GOMAXPROCS='8')
assert (p/'dagql-race.log').read_text().startswith('ok ')
orders = [['before', 'after'], ['after', 'before'], ['before', 'after'], ['after', 'before']]
plan = dict(scope='Private iterator-stack component only, using local copies of Dagger pinned go-set v3.0.1. No inline-ID wrapper or other library change. Tree construction is outside timing. No engine is replaced.', orders=orders, library='github.com/hashicorp/go-set/v3@v3.0.1', benchmark_sha256=hashlib.sha256((p/'iteration_test.go').read_bytes()).hexdigest())
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
rows = []
def run(label, arm, flags):
    directory = p/('pinned-'+arm)
    overlay = p/(arm+'-library-overlay.json')
    overlay.write_text(json.dumps({'Replace':{str(directory/'iteration_extra_test.go'):str(p/'iteration_test.go')}},indent=2)+'\n')
    command = [go, 'test', '-p=2', '-count=1', '-timeout=240s', '-overlay='+str(overlay), *flags, '.']
    start = time.monotonic()
    log = p/(label+'.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=directory, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, arm=arm, command=command, exit_code=result.returncode, process_seconds=time.monotonic()-start)
    rows.append(row)
    (p/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode == 0,log.read_text()[-5000:]
for arm in ['before','after']:
    run(arm+'-pinned-race',arm,['-race'])
for pair, order in enumerate(orders):
    for arm in order:
        run(f'component-{pair}-{arm}',arm,['-run=^$', '-bench=^BenchmarkTreeSetIteration$', '-benchtime=200ms', '-benchmem', '-cpu=8'])
