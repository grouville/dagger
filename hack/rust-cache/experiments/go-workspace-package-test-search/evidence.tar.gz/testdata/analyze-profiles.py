from collections import Counter
from pathlib import Path
import json

p = Path(__file__).parent


def summarize(path):
    counts = Counter()
    parents = {}
    classes = {}
    publications = []
    interesting = []
    with path.open() as stream:
        header = json.loads(next(stream))
        names = header['strings']
        for line in stream:
            event = json.loads(line)
            if event.get('e') != 'op':
                continue
            cls = names[event['c']]
            kind = event['k']
            counts[(kind, cls)] += 1
            parents[event['id']] = event.get('p', 0)
            classes[event['id']] = (kind, cls)
            if cls == 'dagql.publishResult':
                publications.append(event.get('p', 0))
            if cls in ['session.serveQuery', 'Artifacts.items', 'go:Go.packages', 'go:GoPackage.tests']:
                interesting.append(dict(event, cls=cls))
    by_field = Counter()
    for parent in publications:
        while parent and parent in classes:
            kind, cls = classes[parent]
            if kind in ['call', 'call_exec']:
                by_field[cls] += 1
                break
            parent = parents.get(parent, 0)
    main = max((e for e in interesting if e['cls'] == 'session.serveQuery'), key=lambda e: e['d']-e['s'])
    fields = ['Workspace.file', 'Host.directory', 'File.search', 'Workspace.search', 'Workspace.glob', 'Workspace.findRoots', 'String.glob', 'gomod:GomodGoMod.ownFiles',
              'SearchResult.search', 'SearchResult.filePath', 'SearchResult.matchedLines',
              'Artifact.items', 'ArtifactDimensionKey.dimensionKeys',
              'ArtifactDimensionKey.dimension', 'ArtifactDimensionKey.key']
    return dict(header={k: v for k, v in header.items() if k != 'strings'}, main_query=main,
                operation_counts={kind+' '+cls:count for (kind,cls),count in counts.items()},
                publications=len(publications), publications_by_field=dict(by_field),
                fields={f: {kind: counts[(kind, f)] for kind in ['call', 'call_exec']} for f in fields},
                longest_intervals={cls: sorted([
                    dict(id=e['id'], seconds=(e['d']-e['s'])/1e9)
                    for e in interesting if e['cls'] == cls
                ], key=lambda e: e['seconds'], reverse=True)[:4]
                    for cls in ['Artifacts.items', 'go:Go.packages', 'go:GoPackage.tests']})


import subprocess

reports={arm:summarize(p/('profile-'+arm)/'wcprof-complete.ndjson') for arm in ['before','after']}
for arm,data in reports.items():
    assert not data['header']['dropped_events'] and not data['header'].get('open_ops')
    command=['/tmp/rust-cache-wcprof-report-current','-view','critpath','-op',str(data['main_query']['id']),'-depth','9','-top','35','-limit','180',str(p/('profile-'+arm)/'wcprof-complete.ndjson')]
    with (p/('critical-path-'+arm+'.log')).open('w') as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
    assert result.returncode==0
before=reports['before'];after=reports['after']
fields=['session_phase session.query','internal dang.apiRequest','call Workspace.file','call Host.directory','call File.search','call Workspace.search','io snapshot.commit.backend','call go:GoPackage.tests','call Artifact.items']
counts={field:{arm:data['operation_counts'].get(field,0) for arm,data in reports.items()} for field in fields}
(p/'profile-derived.json').write_text(json.dumps(dict(counts=counts,profiles=reports),indent=2)+'\n')
print(json.dumps(counts,indent=2),flush=True)
assert counts['call Artifact.items']==dict(before=4398,after=4398)
assert counts['call go:GoPackage.tests']==dict(before=800,after=800)
assert counts['call File.search']['before']>0 and counts['call File.search']['after']==0
assert counts['call Workspace.file']['before']>counts['call Workspace.file']['after']
assert counts['session_phase session.query']['before']>counts['session_phase session.query']['after']
