from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).parent
source = Path('/tmp/dagger-go-module-test-name-index')
module = Path('/tmp/dagger-go-workspace-package-test-search')
metadata = json.loads((p/'SOURCE.json').read_text())
assert hashlib.sha256((source/'go.dang').read_bytes()).hexdigest() == metadata['base_go_dang_sha256']
assert hashlib.sha256((p/'go.dang').read_bytes()).hexdigest() == metadata['candidate_go_dang_sha256']
assert not module.exists()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
subprocess.run(['git', 'worktree', 'add', '--detach', str(module), revision], cwd=source, check=True)
(module/'go.dang').write_bytes((p/'go.dang').read_bytes())
checks = module/'.dagger/modules/go-dev/main.dang'
original = checks.read_text()
reference = Path('/tmp/dagger-go-package-search-recheck/.dagger/modules/go-dev/main.dang').read_text()
start = reference.index('    # Reusing a package with the same path and filename must read edited contents.')
end = reference.index('    let removed = overlay.withNewFile', start)
marker = '    let removed = overlay.withNewFile'
assert original.count(marker) == 1
checks.write_text(original.replace(marker, reference[start:end] + marker))
(p/'check-source.dang').write_bytes(checks.read_bytes())
(p/'module.patch').write_text(subprocess.check_output(['git','diff','--','go.dang','.dagger/modules/go-dev/main.dang'], cwd=module, text=True))
metadata.update(module_path=str(module), revision=revision, status='prepared-not-tested', check_source_sha256=hashlib.sha256(checks.read_bytes()).hexdigest())
(p/'SOURCE.json').write_text(json.dumps(metadata, indent=2)+'\n')
print('Prepared exact candidate and retained-package edit check.', flush=True)
