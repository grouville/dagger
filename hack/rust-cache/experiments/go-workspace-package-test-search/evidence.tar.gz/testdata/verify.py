from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
base = p.parent
module = Path('/tmp/dagger-go-workspace-package-test-search')
env = dict(os.environ, RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16276',
           RUST_CACHE_BENCH_CLI=str(base/'filesync-literal-pathwalk/dagger-after'),
           RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',
           _EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows = []
for check in ['go-dev:tests-collection-check', 'go-dev:package-layout-rebind-check']:
    begin = time.monotonic()
    with (p/(check.replace(':','-')+'.log')).open('w') as output:
        result = subprocess.run(['python3', str(base/'local_cli_collector.py'), 'check', check], cwd=module, env=env, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(check=check, exit_code=result.returncode, seconds=time.monotonic()-begin))
    (p/'correctness.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(rows[-1], flush=True)
    assert result.returncode == 0, check
