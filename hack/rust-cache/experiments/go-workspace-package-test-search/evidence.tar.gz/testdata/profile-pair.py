from pathlib import Path
import json
import os
import subprocess
import time

p=Path(__file__).parent
summary=json.loads((p/'full-command-paired/summary.json').read_text())
assert summary['all_commands_succeeded'] and summary['same_rows']
rows=[]
for arm in ['before','after']:
    command=['python3',str(p/'capture.py'),'--output',str(p/('profile-'+arm)),'--languages','go']
    started=time.monotonic()
    with (p/('profile-'+arm+'-driver.log')).open('w') as out:
        result=subprocess.run(command,env=dict(os.environ,GO_WORKSPACE_SEARCH_ARM=arm),stdout=out,stderr=subprocess.STDOUT)
    row=dict(arm=arm,command=command,seconds=time.monotonic()-started,exit_code=result.returncode)
    rows.append(row);(p/'profile-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(row,flush=True)
    assert result.returncode==0,(p/('profile-'+arm+'-driver.log')).read_text()[-5000:]
