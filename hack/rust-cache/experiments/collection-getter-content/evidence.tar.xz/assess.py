from pathlib import Path
import json,statistics,hashlib,subprocess
p=Path(__file__).parent
reports={}
for family in ['test-edit','source-edit','known-ids']:
 rows=json.loads((p/(family+'-paired')/'samples.json').read_text());summary=json.loads((p/(family+'-paired')/'summary.json').read_text());pairs=[]
 for block in range(1,5):
  before=next(x for x in rows if x['block']==block and x['arm']=='before');after=next(x for x in rows if x['block']==block and x['arm']=='combined')
  pairs.append(dict(block=block,before_seconds=before['seconds'],after_seconds=after['seconds'],saved_seconds=before['seconds']-after['seconds'],before_cpu=before['engine_cpu'],after_cpu=after['engine_cpu'],before_allocated_bytes=before['heap_delta']['TotalAlloc'],after_allocated_bytes=after['heap_delta']['TotalAlloc']))
 reports[family]=dict(summary=summary,pairs=pairs,faster_pairs=sum(x['saved_seconds']>0 for x in pairs),median_paired_saved_seconds=statistics.median(x['saved_seconds'] for x in pairs),all_ten_correct=all(x['exit_code']==0 and x['correct_names'] and x['same_full_rows'] and not x['cancelled'] for x in rows),pressure_max={k:max(x['pressure'][k] for x in rows) for k in rows[0]['pressure']},restoration=json.loads((p/(family+'-paired')/'restoration.json').read_text()))
 print(family,json.dumps({k:reports[family][k] for k in ['faster_pairs','median_paired_saved_seconds','all_ten_correct']}))
for arm in ['before','candidate']:
 c=p/('capture-'+arm);trace=c/'wcprof-complete.ndjson';h=hashlib.sha256();size=0
 with trace.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);size+=len(b)
 (c/'trace-identity.json').write_text(json.dumps(dict(bytes=size,sha256=h.hexdigest()),indent=2)+'\n')
 reports['profile-'+arm]=json.loads((c/'attribution.json').read_text())
(p/'assessments.json').write_text(json.dumps(reports,indent=2)+'\n')
worktree=Path('/tmp/dagger-go-subtree-test-discovery')
(p/'subtree-go.dang').write_bytes((worktree/'go.dang').read_bytes());(p/'module.patch').write_bytes(subprocess.check_output(['git','diff','6b9173a88d8c2c97cee0c9ee59735b0236275f9b','--','go.dang'],cwd=worktree))
(p/'engine.patch').write_text(subprocess.run(['diff','-u','--label','a/core/modfunc.go','--label','b/core/modfunc.go',str(p/'before-modfunc.go'),str(p/'after-modfunc.go')],stdout=subprocess.PIPE,text=True).stdout)
(p/'source-identity.json').write_text(json.dumps(dict(module_parent='6b9173a88d8c2c97cee0c9ee59735b0236275f9b',module_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip(),module_worktree=str(worktree),module_branch=subprocess.check_output(['git','branch','--show-current'],cwd=worktree,text=True).strip(),module_source_sha256=hashlib.sha256((worktree/'go.dang').read_bytes()).hexdigest(),engine_checkout='/tmp/dagger-filesync-snapshot-seeds',engine_parent='19eda924854e7f22582f3a7430272aa729cbeb5f',binary_sha256=json.loads((p/'build-steps.json').read_text())[-1]['sha256'],production_sources_changed=False,pr_opened=False),indent=2)+'\n')
