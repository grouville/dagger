from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent
engine=Path('/tmp/dagger-filesync-snapshot-seeds')
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
steps=[('before-repro','before-overlay.json','^TestCollectionGetterReusesUnchangedChild$',False,1,'unchanged child content must reuse downstream work'),('unsafe-scope','unsafe-overlay.json','^TestCollectionGetterContentScope$',False,1,'content identity must include implementation, type and effective view'),('core-race','after-overlay.json','^Test(Collection|ModuleObject|ModuleSelfDependency|ModuleDependency|SecretPlaintextFallsBack|SocketForwardAgentClientFallsBack|CollectedContent)',True,0,None)]
source={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.go')}
(p/'validation-source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
rows=[]
for label,overlay,pattern,race,expected,reason in steps:
 command=[go,'test','-p=2','-count=1','-v','-timeout=180s','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod','-overlay='+str(p/overlay),'-run='+pattern]
 if race:command.append('-race')
 command.append('./core');start=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=engine,env=env,stdout=out,stderr=subprocess.STDOUT)
 text=(p/(label+'.log')).read_text();row=dict(label=label,command=command,seconds=time.monotonic()-start,exit_code=r.returncode,expected_exit_code=expected,passed=sum(line.startswith('--- PASS:') for line in text.splitlines()),expected_assertion=reason,expected_assertion_seen=reason in text if reason else None)
 rows.append(row);(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==expected,(label,text[-4000:])
 if reason:assert reason in text and '[build failed]' not in text,(label,'wrong failure')
 assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in source.items()),'source changed during tests'
