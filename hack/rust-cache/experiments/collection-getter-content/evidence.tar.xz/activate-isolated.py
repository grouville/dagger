from pathlib import Path
import hashlib,json,subprocess,time,urllib.request
p=Path(__file__).parent
name='dagger-collection-content-oct18';volume=name
old='dagger-rust-parser-state-pool-oct14';old_debug='http://127.0.0.1:16104/debug/';debug='http://127.0.0.1:16105/debug/'
def get(base,route,data=None):
 with urllib.request.urlopen(urllib.request.Request(base+route,data=data),timeout=10) as r:return json.load(r)
steps=json.loads((p/'build-steps.json').read_text());assert len(steps)==3 and all(s['exit_code']==s['expected_exit_code'] for s in steps)
sha=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest();assert sha==steps[-1]['sha256']
inspection=json.loads(subprocess.check_output(['docker','inspect',old]))[0]
old_binary=subprocess.check_output(['docker','exec',old,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
assert old_binary=='1a514c536c6bf10d2463faab2d4e4329f187dd4c0af5f46aba1cbe91460e2fb7'
assert get(old_debug,'client-lifecycle')['active_requests']==0
routes=list(json.loads((p.parent/'telemetry-native-storage/capture/metadata.json').read_text())['flags_during'])
flags={r:get(old_debug,r)['enabled'] for r in routes}
for route in ['response-data-projection','batch-metadata','attribute-array-decode','native-telemetry-storage','known-input-ids']:
 flags[route]=get(old_debug,route)['enabled']
assert not get(old_debug,'wcprof/enabled')['global_enabled']
assert not subprocess.check_output(['docker','ps','-aq','--filter','name=^/'+name+'$'],text=True).strip(),'diagnostic container already exists; inspect rather than replacing it'
plan=dict(name=name,volume=volume,engine_sha256=sha,image=inspection['Image'],runner='tcp://127.0.0.1:16277',debug=debug,flags_from_existing_engine=flags,existing_engine=old,existing_engine_binary_sha256=old_binary,existing_engine_modified=False,existing_cache_reset=False,isolated_volume=True,telemetry_v2_dual_readers_inherited=True)
(p/'isolated-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
cmd=['docker','create','--name',name,'--label','codex.task=go-collection-content-oct18','--privileged','-p','127.0.0.1:16277:1234','-p','127.0.0.1:16105:6060','--mount','type=volume,source='+volume+',target=/var/lib/dagger',inspection['Image'],*inspection['Config']['Cmd']]
created=subprocess.check_output(cmd,text=True).strip();plan['container_id']=created
subprocess.run(['docker','cp',str(p/'dagger-engine'),name+':/usr/local/bin/dagger-engine'],check=True)
seed=subprocess.check_output(['docker','exec',old,'sh','-c','cat /tmp/filesync-snapshot-seeds-mode 2>/dev/null || true'])
if seed:
 (p/'filesync-snapshot-seeds-mode').write_bytes(seed);subprocess.run(['docker','cp',str(p/'filesync-snapshot-seeds-mode'),name+':/tmp/filesync-snapshot-seeds-mode'],check=True)
subprocess.run(['docker','start',name],check=True,stdout=subprocess.DEVNULL)
deadline=time.monotonic()+90
while True:
 try:
  get(debug,'wcprof/enabled');break
 except Exception:
  assert time.monotonic()<deadline,'isolated engine readiness timed out'
  time.sleep(1)
for route,enabled in flags.items():assert get(debug,route+'?enabled='+str(enabled).lower(),b'')['enabled']==enabled
assert not get(debug,'collection-item-content')['enabled']
assert not get(debug,'wcprof/enabled')['global_enabled']
assert get(debug,'lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
plan.update(ready=True,feature_default_off=True,flags_after={r:get(debug,r) for r in flags},original_engine_sha256_after=subprocess.check_output(['docker','exec',old,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0])
assert plan['original_engine_sha256_after']==old_binary
(p/'isolated-activation.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(container=name,container_id=created,engine_sha256=sha,runner=plan['runner'],debug=debug,original_engine_unchanged=True)),flush=True)
