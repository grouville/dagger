from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent
engine=Path('/tmp/dagger-filesync-snapshot-seeds')
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
shared=['-p=2','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod','-overlay='+str(p/'engine-overlay.json')]
steps=[('controlled-race',[go,'test',*shared,'-race','-count=1','-v','-timeout=120s','-run=^TestCollectionGetter','./core'],'true',0),('disabled-control',[go,'test',*shared,'-race','-count=1','-v','-timeout=120s','-run=^TestCollectionGetterReusesUnchangedChild$','./core'],'false',1),('engine-build',[go,'build',*shared,'-buildvcs=false','-o',str(p/'dagger-engine'),'./cmd/engine'],'false',0)]
files=json.loads((p/'engine-overlay.json').read_text())['Replace'].values();hashes={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files}
(p/'engine-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
rows=[]
for label,cmd,mode,expected in steps:
 start=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=engine,env=dict(env,DAGGER_BENCH_COLLECTION_ITEM_CONTENT=mode),stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=cmd,seconds=time.monotonic()-start,exit_code=r.returncode,expected_exit_code=expected,feature_enabled=mode=='true')
 if label=='engine-build' and r.returncode==0:row['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
 rows.append(row);(p/'build-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==expected,(label,(p/(label+'.log')).read_text()[-4000:])
 if expected:assert 'unchanged child content must reuse downstream work' in (p/(label+'.log')).read_text()
 assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in hashes.items()),'overlay source changed'
