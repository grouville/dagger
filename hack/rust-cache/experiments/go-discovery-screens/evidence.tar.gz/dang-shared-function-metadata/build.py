from pathlib import Path
import subprocess,os,json,time,hashlib
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
subprocess.run([str(Path(go).with_name('gofmt')),'-w',*[str(p/n) for n in ['controlled-ast_declarations.go','engine-debug.go','mode.go']]],check=True)
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',DANG_BENCH_COERCED_METHOD_HOISTING='true',DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT='true',DANG_BENCH_SHARED_FUNCTION_METADATA='true')
engine=Path('/tmp/dagger-filesync-snapshot-seeds');dang=Path('/tmp/rust-cache-sipsma-review/dang-module-blueprint-content-key')
overlay='-overlay='+str(p/'engine-overlay.json')
commands=[
 ('development-dang-race',dang,[go,'test','-p=2','-mod=mod','-modfile=/tmp/rust-cache-sipsma-review/dang-evaluation-context/dang.go.mod',overlay,'-count=1','-race','-timeout=120s','./pkg/dang']),
 ('development-sdk-race',engine,[go,'test','-p=2','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod',overlay,'-count=1','-race','-timeout=120s','./core/sdk/dang/v2']),
 ('engine-build',engine,[go,'build','-p=2','-buildvcs=false','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod',overlay,'-o',str(p/'dagger-engine'),'./cmd/engine'])]
rows=[]
for label,cwd,cmd in commands:
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=cmd,seconds=time.monotonic()-tick,exit_code=r.returncode)
 if label=='engine-build' and not r.returncode:row['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
 rows.append(row);(p/'engine-build-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'.log')).read_text()[-5000:]);raise SystemExit(r.returncode)
