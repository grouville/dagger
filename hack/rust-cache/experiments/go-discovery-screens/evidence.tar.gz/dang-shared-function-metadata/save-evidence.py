from pathlib import Path
import hashlib,json,statistics,tarfile,subprocess,urllib.request
p=Path(__file__).parent;base=p.parent
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-discovery-screens');out.mkdir(parents=True,exist_ok=True)
assessment={}
for name in ['test-edit-paired','source-edit-paired']:
 rows=json.loads((p/name/'samples.json').read_text());pairs=[]
 for block in sorted({r['block'] for r in rows if not r['warmup']}):
  d={r['arm']:r for r in rows if r['block']==block};pairs.append(d['combined']['seconds']-d['before']['seconds'])
 assessment[name]=dict(summary=json.loads((p/name/'summary.json').read_text()),commands=len(rows),all_correct=all(r['exit_code']==0 and r['correct_names'] and r['same_full_rows'] for r in rows),candidate_faster_pairs=sum(d<0 for d in pairs),paired_changes=pairs,max_host_cpu_pressure=max(r['pressure']['host.cpu.some'] for r in rows),restoration=json.loads((p/name/'restoration.json').read_text()))
for case in ['capture-before','capture-candidate']:
 d=json.loads((p/case/'attribution.json').read_text());assessment[case]={k:d[k] for k in ['events','dropped','open_ops','function_evaluations','sdk_requests','main_query']}
assessment.update(selected=False,reason='No demonstrated complete-command gain; continue toward sharing larger parts of receiver/call preparation.',engine_sha256=json.loads((p/'engine-build-steps.json').read_text())[-1]['sha256'],go_module='09518aac0858390722e71c82a719c2f6e131e611',telemetry=True,ordinary_gc=True)
with urllib.request.urlopen('http://127.0.0.1:16105/debug/client-lifecycle',timeout=10) as f:lifecycle=json.load(f)
assert lifecycle['active_requests']==0 and not lifecycle.get('sessions')
flags={}
for route in ['shared-function-metadata','coerced-method-hoisting','lazy-eval-error-context','collection-item-content','receiver-preparation']:
 with urllib.request.urlopen('http://127.0.0.1:16105/debug/'+route,timeout=10) as f:flags[route]=json.load(f)
 assert not flags[route]['enabled']
with urllib.request.urlopen('http://127.0.0.1:16105/debug/wcprof/enabled',timeout=10) as f:assert not json.load(f)['global_enabled']
original=subprocess.check_output(['docker','exec','dagger-rust-parser-state-pool-oct14','sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]
assert original=='1a514c536c6bf10d2463faab2d4e4329f187dd4c0af5f46aba1cbe91460e2fb7'
(p/'final-state.json').write_text(json.dumps(dict(flags=flags,lifecycle=lifecycle,wcprof=False,original_rust_engine_sha256=original),indent=2)+'\n')
(p/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');(out/'assessment.json').write_bytes((p/'assessment.json').read_bytes())
paths=['before-ast_declarations.go','after-ast_declarations.go','controlled-ast_declarations.go','function_metadata_test.go','mode.go','engine-debug.go','engine-overlay.json']
identity=json.loads((p/'source-identity.json').read_text());identity.update({n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in paths});(p/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
files=[]
for name in ['dang-shared-function-metadata','go-shared-source-markers','native-sort-current-discovery']:
 directory=base/name
 for q in sorted(directory.rglob('*')):
  if not q.is_file() or '__pycache__' in q.parts or q.suffix=='.pyc' or q.name in ['dang','dagger-engine'] or q.suffix=='.ndjson':continue
  files.append((name+'/'+str(q.relative_to(directory)),q))
for label,repo in [('before','/tmp/dagger-go-batch-package-discovery'),('empty','/tmp/dagger-go-empty-binary-selection'),('shared','/tmp/dagger-go-shared-source-markers'),('sort','/tmp/dagger-go-native-sort-current')]:
 for name in ['go.dang','gomod/main.dang','.dagger/modules/go-dev/main.dang','AGENTS.md','dagger.toml','gomod/dagger.toml']:
  q=Path(repo)/name
  if q.is_file():files.append(('module-source/'+label+'/'+name,q))
manifest=[]
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,q in files:
  data=q.read_bytes();manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
  info=tar.gettarinfo(str(q),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with q.open('rb') as f:tar.addfile(info,f)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for m,entry in zip(members,manifest):
  assert m.name==entry['path'] and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==entry['sha256']
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
info=dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,members=len(manifest),uncompressed_bytes=sum(r['bytes'] for r in manifest),verified=True)
(out/'archive.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)
