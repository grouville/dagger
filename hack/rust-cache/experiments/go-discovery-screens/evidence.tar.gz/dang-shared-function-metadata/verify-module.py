from pathlib import Path
import json,os,subprocess,time,urllib.request
p=Path(__file__).parent;base=p.parent;debug='http://127.0.0.1:16105/debug/'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=10) as f:return json.load(f)
routes=['collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata']
flags={r:get(r)['enabled'] for r in routes};assert not get('wcprof/enabled')['global_enabled']
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16277',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows=[]
try:
 for route in routes:get(route+'?enabled=true',b'')
 for check in ['gomod-checks:package-facts-check','gomod-checks:own-files-check','gomod-checks:discovery-check','gomod-checks:lookup-check','go-dev:discovery-check','go-dev:package-layout-rebind-check','go-dev:tests-collection-check']:
  tick=time.monotonic()
  with (p/(check.replace(':','-')+'.log')).open('w') as out:r=subprocess.run(['python3',str(base/'local_cli_collector.py'),'check',check],cwd='/tmp/dagger-go-batch-package-discovery',env=env,stdout=out,stderr=subprocess.STDOUT)
  row=dict(check=check,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'module-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
finally:
 for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
 (p/'module-checks-restoration.json').write_text(json.dumps({r:get(r) for r in routes},indent=2)+'\n')
