from pathlib import Path
import hashlib,json,subprocess,time,urllib.request
p=Path(__file__).parent;engine='dagger-collection-content-oct18';debug='http://127.0.0.1:16105/debug/'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=10) as f:return json.load(f)
steps=json.loads((p/'engine-build-steps.json').read_text());assert len(steps)==3 and all(x['exit_code']==0 for x in steps)
sha=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest();assert sha==steps[-1]['sha256']
before=json.loads(subprocess.check_output(['docker','inspect',engine]))[0];assert before['Id']=='c852f474863db6e93f76740af2d3a00e22e3204c5a881faacb0c8584059283d2'
oldsha=subprocess.check_output(['docker','exec',engine,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert oldsha=='1ddf5411131aaeb87579f5d8dd099eae705139690f0895c4216b8571d6050060'
assert not get('wcprof/enabled')['global_enabled'];assert get('client-lifecycle')['active_requests']==0 and not get('client-lifecycle').get('sessions')
routes=list(json.loads((p.parent/'collection-getter-content/isolated-activation.json').read_text())['flags_from_existing_engine'])
for r in ['collection-item-content','known-input-ids','response-data-projection','batch-metadata','attribute-array-decode','native-telemetry-storage','evaluation-context','receiver-preparation','coerced-method-hoisting','lazy-eval-error-context']:
 if r not in routes:routes.append(r)
flags={r:get(r)['enabled'] for r in routes}
flags['shared-function-metadata']=False
plan=dict(engine=engine,container_id=before['Id'],mounts=before['Mounts'],old_sha256=oldsha,new_sha256=sha,flags_before=flags,forced_stop=False,volume_reset=False,original_rust_cache_engine_replaced=False,native_telemetry_v2_dual_readers_preserved=True)
(p/'activation-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=time.monotonic();cmd=['python3',str(p/'restart-isolated-clean.py'),'--engine',engine,'--debug-port','16105','--output',str(p/'restart'),'--binary',str(p/'dagger-engine'),'--readiness-timeout','360']
with (p/'restart-driver.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
(p/'restart-result.json').write_text(json.dumps(dict(command=cmd,seconds=time.monotonic()-start,exit_code=r.returncode),indent=2)+'\n');assert r.returncode==0,(p/'restart-driver.log').read_text()[-4000:]
for route,enabled in flags.items():assert get(route+'?enabled='+str(enabled).lower(),b'')['enabled']==enabled
assert not get('evaluation-context')['enabled']
assert not get('receiver-preparation')['enabled']
assert not get('coerced-method-hoisting')['enabled']
assert not get('lazy-eval-error-context')['enabled']
assert not get('shared-function-metadata')['enabled']
after=json.loads(subprocess.check_output(['docker','inspect',engine]))[0];assert after['Id']==before['Id'] and after['Mounts']==before['Mounts']
assert subprocess.check_output(['docker','exec',engine,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]==sha
originalsha=subprocess.check_output(['docker','exec','dagger-rust-parser-state-pool-oct14','sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert originalsha=='1a514c536c6bf10d2463faab2d4e4329f187dd4c0af5f46aba1cbe91460e2fb7'
plan.update(ready=True,flags_after={r:get(r) for r in routes},new_feature_default_off=True,original_engine_sha256=originalsha)
(p/'activation.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(dict(engine=engine,sha256=sha,volume_preserved=True,original_engine_unchanged=True)),flush=True)
