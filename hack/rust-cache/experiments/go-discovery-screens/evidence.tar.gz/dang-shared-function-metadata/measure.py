from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;steps=[]
assert json.loads((p/'activation.json').read_text())['ready']
commands=[('module-checks',['python3',str(p/'verify-module.py')]),('test-edits',['python3',str(p/'measure-test-edits.py'),'--output',str(p/'test-edit-paired'),'--fixture','real','--arms','before','combined','--pairs','4']),('source-edits',['python3',str(p/'measure-source-edits.py'),'--output',str(p/'source-edit-paired'),'--fixture','real','--arms','before','combined','--pairs','4']),('capture-before',['python3',str(p/'capture.py'),'--arm','before','--output',str(p/'capture-before'),'--cpu-profile','--edit-test-body']),('capture-candidate',['python3',str(p/'capture.py'),'--arm','candidate','--output',str(p/'capture-candidate'),'--cpu-profile','--edit-test-body'])]
for label,cmd in commands:
 tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,seconds=time.monotonic()-tick,exit_code=r.returncode,command=cmd);steps.append(row);(p/'timing-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-4500:]);raise SystemExit(r.returncode)
