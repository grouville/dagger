from pathlib import Path
import subprocess,os,json,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
up=Path('/tmp/rust-cache-sipsma-review/dang-lazy-eval-error-context/upstream-source/vito-dang-da1bed3')
assert p.joinpath('before-ast_declarations.go').read_bytes()==up.joinpath('pkg/dang/ast_declarations.go').read_bytes()
subprocess.run([str(Path(go).with_name('gofmt')),'-w',str(p/'after-ast_declarations.go'),str(p/'function_metadata_test.go')],check=True)
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',DANG_BENCH_COERCED_METHOD_HOISTING='true',DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT='true')
steps=[]
commands=[
 ('before-behavior',up,[go,'test','-p=2','-overlay='+str(p/'before-upstream-overlay.json'),'-run=^TestFunctionMetadata','-count=1','-race','-timeout=120s','./pkg/dang']),
 ('after-upstream-race',up,[go,'test','-p=2','-overlay='+str(p/'after-upstream-overlay.json'),'-count=1','-race','-timeout=120s','./pkg/dang']),
 ('v2-after-scaling',Path('/tmp/dagger-filesync-snapshot-seeds'),[go,'test','-p=2','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod','-overlay='+str(p/'after-scaling-overlay.json'),'-run=^$','-bench=^BenchmarkReceiverPreparation$','-benchtime=1x','-count=3','-timeout=120s','./core/sdk/dang/v2'])]
for label,cwd,cmd in commands:
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,seconds=time.monotonic()-tick,exit_code=r.returncode,command=cmd);steps.append(row)
 (p/'validation-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 print((p/(label+'.log')).read_text()[-2300:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
