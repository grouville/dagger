from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
p=Path(__file__).parent
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/interface-candidate-index');out.mkdir(parents=True,exist_ok=False)
repo=Path('/tmp/dagger-interface-candidate-index')
for name in ['dagql/server.go','dagql/interfaces.go','dagql/objects.go','dagql/interface_candidate_index_test.go','dagql/interface_reconciliation_benchmark_test.go','dagql/interface_core_shape_benchmark_test.go','go.mod','go.sum']:
 f=p/'source-context'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((repo/name).read_bytes())
(p/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','ff0b029a4d270a651b9a8c7286babc79089066e4','--binary'],cwd=repo))
shutil.copytree(p.parent/'go-ownership-quiet-confirmation',p/'ownership-confirmation')
files=[f for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.test']
manifest=[dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in files];manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(p)));info.mtime=0
  with f.open('rb') as source:tar.addfile(info,source)
 info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mtime=0;tar.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  payload=tar.extractfile(row['path']).read();assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
(out/'manifest.json').write_bytes(manifest_bytes)
for name in ['assessment.json','candidate.patch','source-correspondence.json','source-identity.json','final-state.json']:(out/name).write_bytes((p/name).read_bytes())
metadata=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files)+1,all_member_hashes_verified=True,test_binaries_excluded=True)
(out/'archive.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata),flush=True)
