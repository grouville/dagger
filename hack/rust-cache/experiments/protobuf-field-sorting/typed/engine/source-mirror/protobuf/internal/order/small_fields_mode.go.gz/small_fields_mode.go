package order

import "sync/atomic"

var smallFields atomic.Bool

func SetSmallFieldsDiagnostic(enabled bool) { smallFields.Store(enabled) }
func SmallFieldsDiagnosticEnabled() bool    { return smallFields.Load() }
