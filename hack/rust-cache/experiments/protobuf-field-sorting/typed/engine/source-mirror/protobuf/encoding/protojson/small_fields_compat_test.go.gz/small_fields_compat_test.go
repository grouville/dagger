package protojson_test

import (
	"bytes"
	"fmt"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/internal/detrand"
	"google.golang.org/protobuf/internal/order"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/reflect/protodesc"
	"google.golang.org/protobuf/reflect/protoreflect"
	"google.golang.org/protobuf/types/descriptorpb"
	"google.golang.org/protobuf/types/dynamicpb"
	"google.golang.org/protobuf/types/known/anypb"
	"google.golang.org/protobuf/types/known/structpb"
	"google.golang.org/protobuf/types/known/wrapperspb"
	"math"
	"testing"
)

func TestSmallFieldEncodingCompatibility(t *testing.T) {
	detrand.Disable()
	defer order.SetSmallFieldsDiagnostic(order.SmallFieldsDiagnosticEnabled())
	nested, err := structpb.NewStruct(map[string]any{"unicode": "é\n\"", "nested": []any{nil, true, 2.5, map[string]any{"k": "v"}}})
	if err != nil {
		t.Fatal(err)
	}
	any, err := anypb.New(nested)
	if err != nil {
		t.Fatal(err)
	}
	messages := []proto.Message{&wrapperspb.StringValue{}, wrapperspb.String("text\n\""), wrapperspb.String("\xff"), wrapperspb.Int64(math.MinInt64), wrapperspb.Double(math.Inf(1)), wrapperspb.Double(math.NaN()), nested, any}
	definition := &descriptorpb.DescriptorProto{Name: proto.String("Fields")}
	for n := 128; n > 0; n-- {
		definition.Field = append(definition.Field, &descriptorpb.FieldDescriptorProto{Name: proto.String(fmt.Sprintf("field_%03d", n)), Number: proto.Int32(int32(n)), Type: descriptorpb.FieldDescriptorProto_TYPE_INT64.Enum(), Label: descriptorpb.FieldDescriptorProto_LABEL_OPTIONAL.Enum()})
	}
	file, err := protodesc.NewFile(&descriptorpb.FileDescriptorProto{Name: proto.String("smallfields.proto"), Package: proto.String("smallfields"), Syntax: proto.String("proto3"), MessageType: []*descriptorpb.DescriptorProto{definition}}, nil)
	if err != nil {
		t.Fatal(err)
	}
	for _, size := range []int{0, 1, 2, 3, 32, 128} {
		message := dynamicpb.NewMessage(file.Messages().Get(0))
		for i := 0; i < size; i++ {
			fd := message.Descriptor().Fields().Get(i)
			message.Set(fd, protoreflect.ValueOfInt64(-int64(fd.Number())))
		}
		messages = append(messages, message)
	}
	for i, message := range messages {
		for _, options := range []protojson.MarshalOptions{{}, {UseProtoNames: true, EmitUnpopulated: true}, {Multiline: true, Indent: "  "}} {
			order.SetSmallFieldsDiagnostic(false)
			want, wantErr := options.Marshal(message)
			order.SetSmallFieldsDiagnostic(true)
			got, gotErr := options.Marshal(message)
			if !bytes.Equal(got, want) || fmt.Sprint(gotErr) != fmt.Sprint(wantErr) {
				t.Fatalf("message %d JSON differs: got %q (%v), want %q (%v)", i, got, gotErr, want, wantErr)
			}
		}
		order.SetSmallFieldsDiagnostic(false)
		want, wantErr := (proto.MarshalOptions{Deterministic: true}).Marshal(message)
		order.SetSmallFieldsDiagnostic(true)
		got, gotErr := (proto.MarshalOptions{Deterministic: true}).Marshal(message)
		if !bytes.Equal(got, want) || fmt.Sprint(gotErr) != fmt.Sprint(wantErr) {
			t.Fatalf("message %d deterministic wire bytes differ", i)
		}
	}
}
