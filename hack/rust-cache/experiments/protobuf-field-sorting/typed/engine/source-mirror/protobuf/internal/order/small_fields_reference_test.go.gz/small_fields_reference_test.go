package order

import (
	"fmt"
	"google.golang.org/protobuf/reflect/protoreflect"
	"math/rand"
	"reflect"
	"sort"
	"testing"
)

func TestSmallFieldsMatchReference(t *testing.T) {
	defer SetSmallFieldsDiagnostic(SmallFieldsDiagnosticEnabled())
	rng := rand.New(rand.NewSource(2026101603))
	for _, size := range []int{0, 1, 2, 3, 8, 32, 128} {
		for permutation := 0; permutation < 16; permutation++ {
			fields := make(fieldRange, size)
			for i := range fields {
				n := i + 1
				fields[i] = messageField{fieldDesc{index: size - i, name: protoreflect.FullName(fmt.Sprintf("field_%03d", n)), number: protoreflect.FieldNumber(n), extension: i%3 == 0, oneofIndex: i%4 - 1}, protoreflect.ValueOfInt64(int64(-n))}
			}
			rng.Shuffle(size, func(i, j int) { fields[i], fields[j] = fields[j], fields[i] })
			for orderName, less := range map[string]FieldOrder{"unsorted": nil, "number": NumberFieldOrder, "index": IndexNameFieldOrder, "legacy": LegacyFieldOrder} {
				for _, limit := range []int{1, 3, size + 1} {
					reference := append(fieldRange(nil), fields...)
					if less != nil {
						sort.Slice(reference, func(i, j int) bool { return less(reference[i].fd, reference[j].fd) })
					}
					var want []string
					for _, f := range reference {
						want = append(want, fmt.Sprintf("%d:%d", f.fd.Number(), f.v.Int()))
						if len(want) >= limit {
							break
						}
					}
					for _, enabled := range []bool{false, true} {
						SetSmallFieldsDiagnostic(enabled)
						var got []string
						RangeFields(fields, less, func(fd protoreflect.FieldDescriptor, v protoreflect.Value) bool {
							got = append(got, fmt.Sprintf("%d:%d", fd.Number(), v.Int()))
							return len(got) < limit
						})
						if !reflect.DeepEqual(got, want) {
							t.Fatalf("size=%d permutation=%d order=%s limit=%d enabled=%t: got %v, want %v", size, permutation, orderName, limit, enabled, got, want)
						}
					}
				}
			}
		}
	}
}
