package clientdb

import (
	"fmt"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

func beforeBulkMarshalProtoJSONs[T proto.Message](protos []T) ([]byte, error) {
	buf := append(make([]byte, 0, 64*len(protos)+2), '[')
	for i, msg := range protos {
		if i > 0 {
			buf = append(buf, ',')
		}
		var err error
		buf, err = protojson.MarshalOptions{}.MarshalAppend(buf, msg)
		if err != nil {
			return nil, fmt.Errorf("failed to protojson marshal: %w", err)
		}
	}
	return append(buf, ']'), nil
}
