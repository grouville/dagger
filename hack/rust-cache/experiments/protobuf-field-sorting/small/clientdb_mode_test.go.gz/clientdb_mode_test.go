package clientdb

import (
	"google.golang.org/protobuf/encoding/protojson"
	"os"
)

func init() { protojson.SetSmallFieldsDiagnostic(os.Getenv("DAGGER_TEST_SMALL_PROTO_FIELDS") == "1") }
