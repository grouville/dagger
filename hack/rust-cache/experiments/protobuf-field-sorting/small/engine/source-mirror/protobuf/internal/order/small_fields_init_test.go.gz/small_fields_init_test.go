package order

import "os"

func init() { SetSmallFieldsDiagnostic(os.Getenv("DAGGER_TEST_SMALL_PROTO_FIELDS") == "1") }
