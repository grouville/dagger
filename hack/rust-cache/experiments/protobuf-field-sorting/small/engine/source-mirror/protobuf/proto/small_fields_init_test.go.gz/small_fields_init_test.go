package proto_test

import (
	"google.golang.org/protobuf/internal/order"
	"os"
)

func init() { order.SetSmallFieldsDiagnostic(os.Getenv("DAGGER_TEST_SMALL_PROTO_FIELDS") == "1") }
