package protojson

import "google.golang.org/protobuf/internal/order"

func SetSmallFieldsDiagnostic(enabled bool) { order.SetSmallFieldsDiagnostic(enabled) }
func SmallFieldsDiagnosticEnabled() bool    { return order.SmallFieldsDiagnosticEnabled() }
