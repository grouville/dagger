from pathlib import Path
import sys,json,time,signal,subprocess,urllib.request,hashlib
p=Path(__file__).parent
sys.argv=[sys.argv[0],'--output',str(p/'allocation-diagnostic')]
protocol=p.parent/'rust-go-test-collections/measure.py'
exec(protocol.read_text().split('fixtures = [f for f')[0].replace('dagger-rust-parser-state-pool-oct14','dagger-collection-interface-index-oct18').replace(':16104',':16109').replace(':16276',':16281'))
cli=base/'typed-artifact-metadata/dagger';env['_EXPERIMENTAL_DAGGER_CLI_BIN']=str(cli);env['_EXPERIMENTAL_DAGGER_VERSION']='v1.0.0-beta.15';env['DAGGER_DIAG_TYPED_ARTIFACT_METADATA']='true'
workspace=Path('/tmp/dagger-go-real-repository-main');module=Path('/tmp/dagger-go-indexed-owner-facts')
files=['dagger.toml','dagger.lock','dagql/types.go','dagql/cache_test.go'];saved={n:(workspace/n).read_bytes() if (workspace/n).exists() else None for n in files}
routes=['batch-metadata','attribute-array-decode','native-telemetry-storage','response-data-projection','collection-item-content','coerced-method-hoisting','lazy-eval-error-context','prepared-schema','callback-caller-reuse','interface-candidate-pruning','interface-field-snapshots'];flags={r:get(r)['enabled'] for r in routes}
assert not get('wcprof/enabled')['global_enabled'] and not get('receiver-preparation')['enabled']
expected=[tuple(line.split()[1:3]) for line in (base/'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
def allocs(path):
 with urllib.request.urlopen(debug+'pprof/allocs',timeout=30) as response:path.write_bytes(response.read())
rows=[];first=None
try:
 for route in routes:mode(route,route not in ['interface-candidate-pruning','interface-field-snapshots'])
 for arm in ['before','candidate']:
  mode('interface-candidate-pruning',arm=='candidate')
  (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n')
  for name in ['dagql/types.go','dagql/cache_test.go']:(workspace/name).write_bytes(saved[name]+f'\n// Allocation diagnostic edit {time.time_ns()}\n'.encode())
  idle(arm);allocs(root/(arm+'-before.pprof'));before=heap();tick=time.monotonic()
  with (root/(arm+'.stdout')).open('w') as out,(root/(arm+'.stderr')).open('w') as err:
   process=subprocess.Popen([str(cli),'check','--module','go','--check','test','--list','--all'],cwd=workspace,env=env,stdout=out,stderr=err,start_new_session=True)
   try:code=process.wait(timeout=240)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGINT);process.wait(timeout=60);raise
  get('upstream-log-queue',b'');seconds=time.monotonic()-tick;after=heap();allocs(root/(arm+'-after.pprof'))
  lines=[line for line in (root/(arm+'.stdout')).read_text().splitlines() if line.startswith('go ')]
  names=[tuple(line.split()[1:3]) for line in lines]
  if first is None:first=lines
  row=dict(arm=arm,seconds=seconds,exit_code=code,correct_names=names==expected,same_full_rows=lines==first,allocated_bytes=after['TotalAlloc']-before['TotalAlloc'],gc_cycles=after['NumGC']-before['NumGC'],diagnostic_not_a_timing_sample=True,no_forced_gc=True,wcprof=False,cpu_profile=False,profile_lag='Go memory profiles may lag up to two GC cycles; deltas are attribution evidence, not exact byte accounting.')
  rows.append(row);(root/'samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  assert code==0 and row['correct_names'] and row['same_full_rows']
finally:
 for name,data in saved.items():
  if data is None:(workspace/name).unlink(missing_ok=True)
  else:(workspace/name).write_bytes(data)
 for route,value in flags.items():mode(route,value)
 (root/'restoration.json').write_text(json.dumps(dict(files_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items()),flags_after={r:get(r) for r in routes},lifecycle=get('client-lifecycle')),indent=2)+'\n')
