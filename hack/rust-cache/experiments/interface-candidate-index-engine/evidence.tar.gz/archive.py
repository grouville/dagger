from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

p = Path(__file__).parent
out = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/interface-candidate-index-engine')
out.mkdir(parents=True, exist_ok=False)

def sha(data):
    return hashlib.sha256(data).hexdigest()

# Keep tracked module inputs as well as the engine build inputs already captured.
modules = {}
for name, repo in [('go', '/tmp/dagger-go-indexed-owner-facts'),
                   ('rust', '/tmp/dagger-rust-test-collection-granularity')]:
    target = p / 'module-source' / name
    target.mkdir(parents=True, exist_ok=True)
    files = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
    for name2 in filter(None, files):
        source = Path(repo) / name2
        if source.is_file():
            dest = target / name2
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(source.read_bytes())
    modules[name] = {'path': repo, 'commit': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()}
(p / 'module-identities.json').write_text(json.dumps(modules, indent=2) + '\n')

reconstruction = []
for folder in sorted(p.glob('capture-*')):
    complete = folder / 'wcprof-complete.ndjson'
    if not complete.exists():
        continue
    chunks = sorted(folder.glob('chunk-*.ndjson.gz'))
    events = []
    for chunk in chunks:
        with gzip.open(chunk, 'rb') as stream:
            header = json.loads(stream.readline())
            events.extend(stream.readlines())
        assert header['dropped_events'] == 0
    header['event_count'] = len(events)
    rebuilt = (json.dumps(header) + '\n').encode() + b''.join(events)
    assert rebuilt == complete.read_bytes(), folder
    reconstruction.append({'capture': folder.name, 'chunks': [c.name for c in chunks],
                           'events': len(events), 'sha256': sha(rebuilt),
                           'exact_bytes_verified': True})
(p / 'wcprof-reconstruction.json').write_text(json.dumps(reconstruction, indent=2) + '\n')

files = [f for f in sorted(p.rglob('*')) if f.is_file()
         and '__pycache__' not in f.parts and '.git' not in f.parts
         and f.name not in {'dagger-engine', 'reproduced-dagger-engine', 'wcprof-complete.ndjson', 'archive-driver.log'}
         and f.suffix != '.test']
manifest = [{'path': str(f.relative_to(p)), 'bytes': f.stat().st_size,
             'sha256': sha(f.read_bytes())} for f in files]
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
archive = out / 'evidence.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
    for f in files:
        info = tar.gettarinfo(str(f), arcname=str(f.relative_to(p)))
        info.mtime = 0
        with f.open('rb') as source:
            tar.addfile(info, source)
    info = tarfile.TarInfo('manifest.json')
    info.size = len(manifest_bytes)
    info.mtime = 0
    tar.addfile(info, io.BytesIO(manifest_bytes))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(files) + 1
    for row in manifest:
        payload = tar.extractfile(row['path']).read()
        assert len(payload) == row['bytes'] and sha(payload) == row['sha256']
(out / 'manifest.json').write_bytes(manifest_bytes)
for name in ['assessment.json', 'final-state.json', 'port.json', 'reproduced-build.json',
             'module-identities.json', 'wcprof-reconstruction.json']:
    (out / name).write_bytes((p / name).read_bytes())
metadata = {'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
            'members': len(files) + 1, 'all_member_hashes_verified': True,
            'binaries_excluded': True, 'four_lossless_streams_reconstructed': True}
(out / 'archive.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata), flush=True)
