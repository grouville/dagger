package core

import (
	"context"
	"time"

	telemetry "github.com/dagger/otel-go"
	"go.opentelemetry.io/otel/log"
	"google.golang.org/protobuf/proto"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call/callpbv1"
	"github.com/dagger/dagger/engine/slog"
	"github.com/dagger/dagger/engine/telemetryattrs"
)

// Call payloads over the protected log channel fill the gaps left by call spans.
//
// This file is the producer half of the CallPayloadContentType contract
// (engine/telemetryattrs), modelled on the agent-state producer next door for
// the same structural reason: a span attribute can only describe a span that
// exists. A client rebuilding a call ID needs a payload for EVERY frame the
// chain references, and whole classes of frame never get a span of their own —
// introspection / isMeta / skipped selections, digests the per-session span
// dedupe already spent, the frames inside an ID-literal argument (LiteralID.pb
// flattens them to a bare digest), and array members that are only ever
// sub-selected.
//
// Calls that do get a recording span carry their frame there, as
// dagger.io/dag.call (core/telemetry.go); that span copy is then the frame's
// only carrier. The exception is a frame whose base64 encoding exceeds
// maxSpanCallPayloadBytes: a span is exported whole and must fit in one OTLP
// frame (64 MiB), so a huge literal argument (a Query.blob of a large file)
// would break the span's export. Such a span carries no frame, and its root is
// logged here as raw proto bytes like any unspanned frame.
//
// The engine exports frame-carrying call spans on a protected lane with the
// same guarantee as payload logs — never dropped on overflow, retried on
// failure — and its span exporter settles the frame's claim per target just
// as the log exporter settles a payload's. Both transports claim digests from
// the same delivery-domain store, so the closure walk below publishes logs
// only for frames no span or log has claimed.
//
// The claim store is scoped per target — the client and its ancestors,
// exactly the per-client DBs telemetry fans out to — NOT to the session. A
// session-wide claim could let one client's emission permanently satisfy a
// client that never received it. Producers CLAIM each frame before doing any
// recipe work, so concurrent walks over a shared chain (parallel selections,
// an LLM loop re-sending the same chain) build and encode each frame once for
// the whole route; the session exporters then settle those claims per target
// once persistence succeeds, releasing any target whose write failed.

// recordCallPayloads publishes the missing frames in the transitive closure of
// a call's ID over the log channel — through receivers, modules, arguments (ID
// literals inside lists and objects included) and implicit inputs — minus
// digests already claimed by a span or log in the client's delivery domain.
// It is the path for calls without a recording span of their own. A root
// already claimed short-circuits the whole walk: reachability is transitive,
// so the claim's own walk already covered every frame this one would — unless
// a payload was lost since (see repairCallPayloads).
func recordCallPayloads(
	ctx context.Context,
	store dagql.CallPayloadSeenKeyStore,
	callDigest string,
	frame *dagql.ResultCall,
) {
	if store == nil || frame == nil {
		return
	}
	claimed, repair := store.ClaimCallPayloadRoot(callDigest)
	if !claimed {
		// Someone already claimed this call's payload, and whoever did also
		// walked its closure — reachability is transitive, so that walk
		// covered everything this one would.
		if repair {
			repairCallPayloads(ctx, store, callDigest, frame)
		}
		return
	}
	recordClaimedCallPayloads(ctx, store, callDigest, frame, false)
}

// repairCallPayloads walks the closure of a call whose payload someone else
// already claimed, when the root's claim reported that a payload was lost
// since: the exporter gave up on it, so the claimant's walk no longer proves
// the closure reached the client. The walk neither logs the root nor records it as
// covered, since it does not own the root's claim, which may be released at
// any moment. It claims through ClaimCallPayloadForRepair, so it emits only
// lost payloads, each at most once per target it was lost for.
func repairCallPayloads(
	ctx context.Context,
	store dagql.CallPayloadSeenKeyStore,
	callDigest string,
	frame *dagql.ResultCall,
) {
	if _, ok := store.(dagql.CallPayloadClosureStore); !ok || frame == nil {
		return
	}
	walkCallPayloads(ctx, store, callDigest, frame, true, true)
}

// claimCallPayload claims a call's own payload for the store's route. A call
// with a recording span claims its root before starting the span: the span's
// exporter settles that claim once the frame lands on the span. repair
// reports that the root was already claimed but its closure needs a repair
// walk (see dagql.CallPayloadSeenKeyStore).
func claimCallPayload(store dagql.CallPayloadSeenKeyStore, callDigest string) (claimed, repair bool) {
	if store == nil {
		return false, false
	}
	return store.ClaimCallPayloadRoot(callDigest)
}

// recordCallPayloadsForSpan is the closure walk for a call that got a span.
// rootClaimed reports whether this call claimed its own payload (see
// claimCallPayload); if not, whoever did also walked its closure, unless
// rootRepair reports a lost payload (see repairCallPayloads). rootOnSpan
// means the root frame rides the span itself, so only its closure needs logs.
func recordCallPayloadsForSpan(
	ctx context.Context,
	store dagql.CallPayloadSeenKeyStore,
	callDigest string,
	frame *dagql.ResultCall,
	rootClaimed, rootRepair, rootOnSpan bool,
) {
	if !rootClaimed {
		if rootRepair {
			repairCallPayloads(ctx, store, callDigest, frame)
		}
		return
	}
	recordClaimedCallPayloads(ctx, store, callDigest, frame, rootOnSpan)
}

// recordClaimedCallPayloads walks the closure of a call whose own payload the
// caller has already claimed. rootOnSpan means the root frame rides the call's
// recording span, whose exporter settles the root's claim: the walk skips its
// log while still visiting the closure. Otherwise the root is logged first.
//
// Everything here is best-effort. A payload that cannot be built or encoded is
// dropped rather than failing the call; the consequence is a client that
// cannot rebuild that one chain, which is exactly the status quo. Such a
// frame stays claimed on purpose: a recipe that cannot be rebuilt fails the
// same way on every walk, and releasing it would only repeat that work.
func recordClaimedCallPayloads(
	ctx context.Context,
	store dagql.CallPayloadSeenKeyStore,
	callDigest string,
	frame *dagql.ResultCall,
	rootOnSpan bool,
) {
	walkCallPayloads(ctx, store, callDigest, frame, rootOnSpan, false)
}

// walkCallPayloads is recordClaimedCallPayloads, or with repair set, the walk
// of repairCallPayloads: the root is left out of the coverage record, and
// frames are claimed for repair.
func walkCallPayloads(
	ctx context.Context,
	store dagql.CallPayloadSeenKeyStore,
	callDigest string,
	frame *dagql.ResultCall,
	rootOnSpan, repair bool,
) {
	if store == nil || frame == nil {
		return
	}

	// A closure store lets the walk stop at frames whose whole closure an
	// earlier walk already claimed, so extending a deep chain by one call
	// costs that call's new frames rather than the whole chain. The claims
	// below still decide what is emitted, so the payloads are the same either
	// way.
	closures, _ := store.(dagql.CallPayloadClosureStore)
	var (
		skip  func(string) bool
		epoch uint64
	)
	if closures != nil {
		epoch = closures.CallPayloadReleaseEpoch()
		skip = closures.CallPayloadClosureCovered
	}
	calls, err := frame.RecipeCalls(ctx, skip)
	if err != nil {
		// Debug, not Warn: a recipe that cannot be rebuilt (a handle-form
		// reference to a shared result, a frame the cache no longer holds)
		// is a known shape, and this runs once per distinct call digest —
		// warning would mean thousands of identical lines for one bad chain.
		slog.DebugContext(ctx, "failed to rebuild recipe for call payloads", "digest", callDigest, "err", err)
		return
	}

	logger := telemetry.Logger(ctx, InstrumentationLibrary)
	var refused bool
	emit := func(dgst string, callPB *callpbv1.Call) {
		if dgst == callDigest {
			// The root was claimed before rebuilding. When its payload rides
			// the span, only its closure needs the log fallback.
			if rootOnSpan {
				return
			}
		} else if repair {
			claimed, refusedNow := closures.ClaimCallPayloadForRepair(dgst)
			refused = refused || refusedNow
			if !claimed {
				return
			}
		} else if !store.ClaimCallPayload(dgst) {
			// Claim every other frame before encoding so concurrent and
			// repeated closure walks skip payloads already claimed by either
			// transport.
			return
		}

		// The payload carries its own digest: it is the key the producer files
		// the frame under everywhere else (span attributes, other frames'
		// references), so consumers use it verbatim rather than re-deriving it
		// and coupling themselves to this engine version's digest scheme.
		payload, err := (proto.MarshalOptions{Deterministic: true}).Marshal(callPB)
		if err != nil {
			slog.WarnContext(ctx, "failed to marshal call payload", "digest", dgst, "err", err)
			return
		}
		rec := log.Record{}
		rec.SetTimestamp(time.Now())
		rec.SetBody(log.BytesValue(payload))
		// Repeat the digest as an attribute so stores that index log attributes
		// can look a payload up by digest without decoding every body. The body
		// stays authoritative.
		rec.AddAttributes(
			log.String(telemetry.ContentTypeAttr, telemetryattrs.CallPayloadContentType),
			log.String(telemetryattrs.CallPayloadDigestAttr, dgst),
		)
		logger.Emit(ctx, rec)
	}

	// The root comes first, so consumers see the frame they asked for before
	// the rest of its closure.
	digests := make([]string, 0, len(calls))
	for _, callPB := range calls {
		emit(callPB.GetDigest(), callPB)
		if !repair || callPB.GetDigest() != callDigest {
			digests = append(digests, callPB.GetDigest())
		}
	}
	if refused {
		// The repair left a frame unclaimed (one still being retried, or one
		// whose repair copy is spent), so these closures are not covered, and
		// a re-walk would be refused the same.
		return
	}
	// Every frame of these closures is now claimed, by this walk or an
	// earlier one; the skipped parts were covered already. Unless a claim was
	// released while the walk ran: if it sat in a part the walk skipped,
	// nothing would reach it again, since this call's root is claimed and a
	// replay stops there. Then claim over the whole closure once more.
	if closures == nil || closures.CoverCallPayloadClosures(digests, epoch) {
		return
	}
	full, err := frame.RecipeCalls(ctx, nil)
	if err != nil {
		slog.DebugContext(ctx, "failed to rebuild recipe for call payloads", "digest", callDigest, "err", err)
		return
	}
	for _, callPB := range full {
		if callPB.GetDigest() != callDigest {
			emit(callPB.GetDigest(), callPB)
		}
	}
}
