package core

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"slices"
	"strings"
	"syscall"
	"time"

	"github.com/containerd/containerd/v2/core/mount"
	containerdfs "github.com/containerd/continuity/fs"
	bkcontenthash "github.com/dagger/dagger/engine/contenthash"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	bkclient "github.com/dagger/dagger/internal/buildkit/client"
	"github.com/opencontainers/go-digest"
	"github.com/vektah/gqlparser/v2/ast"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine/engineutil"
	telemetry "github.com/dagger/otel-go"
)

// File is a content-addressed file.
type File struct {
	filesystemOutput
	transferPending *persistedFilePayload
	Platform        Platform

	// Services necessary to provision the file.
	Services ServiceBindings

	storedDiagnostics *storedSnapshotDiagnostics
	stored            *storedSnapshot
	Lazy              Lazy[*File]

	// Retained operation bytes for snapshot restore and acquired values.
	lazyKind string
	lazyJSON json.RawMessage

	File     *LazyAccessor[string, *File]
	Snapshot *LazyAccessor[bkcache.ImmutableRef, *File]
}

func (*File) Type() *ast.Type {
	return &ast.Type{
		NamedType: "File",
		NonNull:   true,
	}
}

func (*File) TypeDescription() string {
	return "A file."
}

var _ dagql.OnReleaser = (*File)(nil)
var _ dagql.HasDependencyResults = (*File)(nil)
var _ dagql.HasDependencyResultsKinds = (*File)(nil)
var _ dagql.HasLazyEvaluation = (*File)(nil)

var _ dagql.CachePayloadSizer = (*File)(nil)

// CachePayloadBytes reports the blob contents and saved operation bytes the
// file keeps in memory. A blob's contents stay after evaluation as its recipe.
func (file *File) CachePayloadBytes() int64 {
	if file == nil {
		return 0
	}
	file.outputMu.Lock()
	defer file.outputMu.Unlock()
	n := int64(len(file.lazyJSON))
	if file.transferPending != nil {
		n += int64(len(file.transferPending.LazyJSON))
	}
	if lazy, ok := file.Lazy.(*FileBlobLazy); ok {
		n += int64(len(lazy.Contents))
	}
	return n
}

func (file *File) OnRelease(ctx context.Context) error {
	if file == nil || file.Snapshot == nil {
		return nil
	}
	snapshot, ok := file.Snapshot.Peek()
	if ok && snapshot != nil {
		return snapshot.Release(ctx)
	}
	return nil
}

func (file *File) AttachDependencyResults(
	ctx context.Context,
	self dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.AnyResult, error) {
	depsWithKinds, err := file.AttachDependencyResultsKinds(ctx, self, attach)
	if err != nil {
		return nil, err
	}
	deps := make([]dagql.AnyResult, 0, len(depsWithKinds))
	for _, dep := range depsWithKinds {
		deps = append(deps, dep.Result)
	}
	return deps, nil
}

func (file *File) AttachDependencyResultsKinds(
	ctx context.Context,
	_ dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.DependencyResult, error) {
	if file == nil {
		return nil, nil
	}
	return attachFilesystemDependencyResultsKinds(ctx, "file", file.Services, file.Lazy, attach)
}

func (file *File) LazyEvalFunc() dagql.LazyEvalFunc {
	if file == nil {
		return nil
	}
	return file.filesystemOutput.lazyEvalFunc("File", func() (bool, *lazyEvalBody) {
		lazy := file.Lazy
		if lazy == nil {
			return file.transferPending != nil, nil
		}
		return file.transferPending != nil, &lazyEvalBody{
			evaluated: lazy.IsEvaluated,
			evaluate:  func(ctx context.Context) error { return lazy.Evaluate(ctx, file) },
		}
	})
}

func ParseFileOwner(owner string) (*Ownership, error) {
	return ParseDirectoryOwner(owner)
}

func (file *File) snapshotIdentity() (string, bool) {
	if file == nil {
		return "", false
	}
	file.outputMu.Lock()
	defer file.outputMu.Unlock()
	return file.snapshotIdentityLocked()
}

func (file *File) snapshotIdentityLocked() (string, bool) {
	if file == nil {
		return "", false
	}
	if file.Snapshot != nil {
		if snapshot, ok := file.Snapshot.Peek(); ok && snapshot != nil {
			return snapshot.SnapshotID(), true
		}
	}
	if file.stored != nil {
		return file.stored.SnapshotID, true
	}
	return "", false
}

func (file *File) CacheUsageSize(ctx context.Context, provider dagql.CacheUsageSizeProvider, identity string) (int64, bool, error) {
	if file == nil {
		return 0, false, nil
	}
	if file.Snapshot != nil {
		if snapshot, ok := file.Snapshot.Peek(); ok && snapshot != nil && snapshot.SnapshotID() == identity {
			size, err := snapshot.Size(ctx)
			return size, err == nil, err
		}
	}
	if file.stored != nil && file.stored.SnapshotID == identity && provider != nil {
		size, err := provider.SnapshotSize(ctx, identity)
		return size, err == nil, err
	}
	return 0, false, nil
}

func (file *File) CacheUsageIdentities() []string {
	if identity, ok := file.snapshotIdentity(); ok {
		return []string{identity}
	}
	return nil
}

func (file *File) PersistedSnapshotRefLinks() []dagql.PersistedSnapshotRefLink {
	if identity, ok := file.snapshotIdentity(); ok {
		return []dagql.PersistedSnapshotRefLink{{RefKey: identity, Role: "snapshot"}}
	}
	return nil
}

const (
	persistedFileFormSnapshot = "snapshot"
	persistedFileFormLazy     = "lazy"
)

const (
	persistedFileLazyKindDirectoryFile  = "directory.file"
	persistedFileLazyKindContainerFile  = "container.file"
	persistedFileLazyKindBlob           = "file.blob"
	persistedFileLazyKindWithName       = "file.withName"
	persistedFileLazyKindWithReplaced   = "file.withReplaced"
	persistedFileLazyKindWithTimestamps = "file.withTimestamps"
	persistedFileLazyKindChown          = "file.chown"
)

type persistedFilePayload struct {
	ValueKnown     bool                      `json:"valueKnown,omitempty"`
	OperationState string                    `json:"operationState,omitempty"`
	Form           string                    `json:"form"`
	File           string                    `json:"file,omitempty"`
	Platform       Platform                  `json:"platform"`
	Services       []persistedServiceBinding `json:"services,omitempty"`
	LazyKind       string                    `json:"lazyKind,omitempty"`
	LazyJSON       json.RawMessage           `json:"lazyJSON,omitempty"`
}

func (file *File) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	if file == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted file: nil file")
	}
	unlock, err := file.lockForPersistence()
	if err != nil {
		return dagql.PersistedObjectEncoding{}, err
	}
	defer unlock()
	if file.transferPending != nil {
		return encodePersistedObjectPayload(file.transferPending)
	}
	valueKnown := false
	filePath := ""
	if file.File != nil {
		if peekedPath, ok := file.File.Peek(); ok {
			filePath = peekedPath
			valueKnown = true
		}
	}
	services, err := encodePersistedServiceBindings(enc, "file", file.Services)
	if err != nil {
		return dagql.PersistedObjectEncoding{}, err
	}
	payload := persistedFilePayload{
		ValueKnown: valueKnown,
		File:       filePath,
		Platform:   file.Platform,
		Services:   services,
	}
	if identity, ok := file.snapshotIdentityLocked(); ok {
		payload.Form = persistedFileFormSnapshot
		payload.LazyKind = file.lazyKind
		payload.LazyJSON = file.lazyJSON
		var recipe Lazy[*File]
		if file.Lazy != nil {
			if _, restored := file.Lazy.(*FileRestoreLazy); !restored {
				recipe = file.Lazy
			}
		}
		if recipe != nil {
			payload.LazyKind, payload.LazyJSON, err = encodePersistedFileLazy(ctx, enc, recipe)
			if err != nil {
				return dagql.PersistedObjectEncoding{}, err
			}
		}
		payloadJSON, err := json.Marshal(payload)
		if err != nil {
			return dagql.PersistedObjectEncoding{}, fmt.Errorf("marshal persisted file payload: %w", err)
		}
		return dagql.PersistedObjectEncoding{
			JSON: payloadJSON,
			SnapshotLinks: []dagql.PersistedSnapshotRefLink{{
				RefKey: identity,
				Role:   "snapshot",
			}},
		}, nil
	}
	if file.Lazy != nil {
		payload.Form = persistedFileFormLazy
		lazyKind, lazyJSON, err := encodePersistedFileLazy(ctx, enc, file.Lazy)
		if err != nil {
			return dagql.PersistedObjectEncoding{}, err
		}
		payload.LazyKind = lazyKind
		payload.LazyJSON = lazyJSON
		payloadJSON, err := json.Marshal(payload)
		if err != nil {
			return dagql.PersistedObjectEncoding{}, fmt.Errorf("marshal persisted file payload: %w", err)
		}
		return encodePersistedObjectRawJSON(payloadJSON), nil
	}
	return dagql.PersistedObjectEncoding{}, fmt.Errorf("%w: encode persisted file: missing snapshot and lazy op", dagql.ErrPersistStateNotReady)
}

//nolint:dupl // symmetric with decodePersistedDirectoryWithSnapshotRole in directory.go; sharing hides type specifics
func decodePersistedFileWithSnapshotRole(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage, snapshotRole string) (*File, error) {
	var persisted persistedFilePayload
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted file payload: %w", err)
	}
	services, err := decodePersistedServiceBindings(ctx, dec, "file", persisted.Services)
	if err != nil {
		return nil, err
	}

	file := &File{
		Platform: persisted.Platform,
		Services: services,
		File:     new(LazyAccessor[string, *File]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
	}
	defer func() {
		file.outputMu.Lock()
		file.OutputRev++ // private decoded output, before publication
		file.outputMu.Unlock()
	}()
	if persisted.File != "" && persisted.Form != transferPending {
		file.SetPath(persisted.File)
	}
	switch persisted.Form {
	case transferPending:
		if err := foreignFamilyCodec("File").ValidateForeign(dagql.PersistedPayloadVisit{Payload: payload, Call: dec.Call()}); err != nil {
			return nil, err
		}
		file.transferPending = &persisted
		if persisted.ValueKnown {
			file.SetPath(persisted.File)
		}
		return file, nil
	case persistedFileFormSnapshot:
		link, err := loadPersistedSnapshotLinkByResultID(ctx, dec, "file", snapshotRole)
		if err != nil {
			return nil, err
		}
		file.stored = &storedSnapshot{SnapshotID: link.RefKey}
		file.lazyKind = persisted.LazyKind
		file.lazyJSON = slices.Clone(persisted.LazyJSON)
		file.storedDiagnostics = newStoredSnapshotDiagnostics()
		file.SetPath(persisted.File)
		file.Lazy = &FileRestoreLazy{LazyState: NewLazyState()}
		return file, nil
	case persistedFileFormLazy:
		if persisted.LazyKind == "" {
			return nil, fmt.Errorf("decode persisted file payload: missing lazy kind")
		}
		lazy, err := decodePersistedFileLazy(ctx, dec, persisted.LazyKind, persisted.LazyJSON)
		if err != nil {
			return nil, err
		}
		file.Lazy = lazy
		return file, nil
	default:
		return nil, fmt.Errorf("decode persisted file payload: unsupported form %q", persisted.Form)
	}
}

func (*File) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	return decodePersistedFileWithSnapshotRole(ctx, dec, payload, "snapshot")
}

type FileBlobLazy struct {
	LazyState
	Filename    string
	Contents    []byte
	Permissions fs.FileMode
}

type FileWithReplacedLazy struct {
	LazyState
	Parent      dagql.ObjectResult[*File]
	Search      string
	Replacement string
	FirstFrom   *int
	All         bool
}

type FileWithNameLazy struct {
	LazyState
	Parent   dagql.ObjectResult[*File]
	Filename string
}

type FileWithTimestampsLazy struct {
	LazyState
	Parent    dagql.ObjectResult[*File]
	Timestamp int
}

type FileChownLazy struct {
	LazyState
	Parent dagql.ObjectResult[*File]
	Owner  string
}

type FileSubfileLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Directory]
	Path   string
}

type persistedFileBlobLazy struct {
	Filename    string      `json:"filename"`
	Contents    []byte      `json:"contents"`
	Permissions fs.FileMode `json:"permissions"`
}

type persistedFileWithReplacedLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Search         string `json:"search"`
	Replacement    string `json:"replacement"`
	FirstFrom      *int   `json:"firstFrom,omitempty"`
	All            bool   `json:"all,omitempty"`
}

type persistedFileWithNameLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Filename       string `json:"filename"`
}

type persistedFileWithTimestampsLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Timestamp      int    `json:"timestamp"`
}

type persistedFileChownLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Owner          string `json:"owner"`
}

type persistedFileSubfileLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Path           string `json:"path"`
}

func encodePersistedFileLazy(ctx context.Context, enc *dagql.PersistEncodeContext, lazy Lazy[*File]) (string, json.RawMessage, error) {
	switch lazy := lazy.(type) {
	case *FileHTTPResolveLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindHTTPResolve, payload, err

	case *FileBlobLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindBlob, payload, err
	case *FileSubfileLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindDirectoryFile, payload, err
	case *ContainerFileLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindContainerFile, payload, err
	case *FileWithNameLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindWithName, payload, err
	case *FileWithReplacedLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindWithReplaced, payload, err
	case *FileWithTimestampsLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindWithTimestamps, payload, err
	case *FileChownLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindChown, payload, err
	case *FileContainerImageLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindContainerImage, payload, err
	case *FileChangesetPatchLazy:
		payload, err := lazy.EncodePersisted(ctx, enc)
		return persistedFileLazyKindChangesetPatch, payload, err
	default:
		return "", nil, fmt.Errorf("encode persisted file lazy: unsupported lazy type %T", lazy)
	}
}

func decodePersistedFileLazy(ctx context.Context, dec *dagql.PersistDecodeContext, lazyKind string, payload json.RawMessage) (Lazy[*File], error) {
	switch lazyKind {
	case persistedFileLazyKindHTTPResolve:
		return decodeFileHTTPResolveLazy(payload)

	case persistedFileLazyKindBlob:
		var persisted persistedFileBlobLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted file blob lazy: %w", err)
		}
		return &FileBlobLazy{
			LazyState:   NewLazyState(),
			Filename:    persisted.Filename,
			Contents:    slices.Clone(persisted.Contents),
			Permissions: persisted.Permissions,
		}, nil
	case persistedFileLazyKindDirectoryFile:
		var persisted persistedFileSubfileLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted file subfile lazy: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.ParentResultID, "file subfile parent")
		if err != nil {
			return nil, err
		}
		return &FileSubfileLazy{LazyState: NewLazyState(), Parent: parent, Path: persisted.Path}, nil
	case persistedFileLazyKindContainerFile:
		var persisted persistedContainerFileLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container file lazy: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container file parent")
		if err != nil {
			return nil, err
		}
		return &ContainerFileLazy{LazyState: NewLazyState(), Parent: parent, Path: persisted.Path}, nil
	case persistedFileLazyKindWithName:
		var persisted persistedFileWithNameLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted file withName lazy: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*File](ctx, dec, persisted.ParentResultID, "file withName parent")
		if err != nil {
			return nil, err
		}
		return &FileWithNameLazy{LazyState: NewLazyState(), Parent: parent, Filename: persisted.Filename}, nil
	case persistedFileLazyKindWithReplaced:
		var persisted persistedFileWithReplacedLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted file withReplaced lazy: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*File](ctx, dec, persisted.ParentResultID, "file withReplaced parent")
		if err != nil {
			return nil, err
		}
		return &FileWithReplacedLazy{
			LazyState:   NewLazyState(),
			Parent:      parent,
			Search:      persisted.Search,
			Replacement: persisted.Replacement,
			FirstFrom:   persisted.FirstFrom,
			All:         persisted.All,
		}, nil
	case persistedFileLazyKindWithTimestamps:
		var persisted persistedFileWithTimestampsLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted file withTimestamps lazy: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*File](ctx, dec, persisted.ParentResultID, "file withTimestamps parent")
		if err != nil {
			return nil, err
		}
		return &FileWithTimestampsLazy{LazyState: NewLazyState(), Parent: parent, Timestamp: persisted.Timestamp}, nil
	case persistedFileLazyKindChown:
		var persisted persistedFileChownLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted file chown lazy: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*File](ctx, dec, persisted.ParentResultID, "file chown parent")
		if err != nil {
			return nil, err
		}
		return &FileChownLazy{LazyState: NewLazyState(), Parent: parent, Owner: persisted.Owner}, nil
	case persistedFileLazyKindContainerImage:
		return decodeFileContainerImageLazy(ctx, dec, payload)
	case persistedFileLazyKindChangesetPatch:
		return decodeFileChangesetPatchLazy(ctx, dec, payload)
	default:
		return nil, fmt.Errorf("decode persisted file lazy payload: unsupported lazy kind %q", lazyKind)
	}
}

func (lazy *FileBlobLazy) Evaluate(ctx context.Context, file *File) error {
	return file.evaluateLazy(ctx, &lazy.LazyState, "File.blob", func(ctx context.Context) (rerr error) {
		if dir, _ := filepath.Split(lazy.Filename); dir != "" {
			return fmt.Errorf("file name %q must not contain a directory", lazy.Filename)
		}
		if err := ValidateFileName(lazy.Filename); err != nil {
			return err
		}
		permissions := lazy.Permissions
		if permissions == 0 {
			permissions = 0o644
		}

		query, err := CurrentQuery(ctx)
		if err != nil {
			return err
		}
		scratch, err := query.SnapshotManager().Scratch(ctx)
		if err != nil {
			return fmt.Errorf("create blob scratch snapshot: %w", err)
		}
		defer func() { rerr = errors.Join(rerr, scratch.Release(context.WithoutCancel(ctx))) }()
		newRef, err := query.SnapshotManager().New(
			ctx,
			scratch,
			nil,
			bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
			bkcache.WithDescription(fmt.Sprintf("blob %s (%d bytes)", lazy.Filename, len(lazy.Contents))),
		)
		if err != nil {
			return fmt.Errorf("create blob snapshot: %w", err)
		}
		defer func() {
			if newRef != nil {
				rerr = errors.Join(rerr, newRef.Release(context.WithoutCancel(ctx)))
			}
		}()
		filePath := filepath.Join("/", lazy.Filename)
		if err := MountRef(ctx, newRef, func(root string, _ *mount.Mount) error {
			resolvedDest, err := containerdfs.RootPath(root, filePath)
			if err != nil {
				return err
			}
			return os.WriteFile(resolvedDest, lazy.Contents, permissions)
		}); err != nil {
			return err
		}
		snapshot, err := newRef.Commit(ctx)
		if err != nil {
			return fmt.Errorf("commit blob snapshot: %w", err)
		}
		newRef = nil
		file.SetPath(filePath)
		file.SetSnapshot(snapshot)
		return nil
	})
}

func (lazy *FileBlobLazy) AttachDependencies(context.Context, func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	return nil, nil
}

func (lazy *FileBlobLazy) EncodePersisted(context.Context, *dagql.PersistEncodeContext) (json.RawMessage, error) {
	return json.Marshal(persistedFileBlobLazy{
		Filename:    lazy.Filename,
		Contents:    slices.Clone(lazy.Contents),
		Permissions: lazy.Permissions,
	})
}

func (lazy *FileSubfileLazy) Evaluate(ctx context.Context, file *File) error {
	return file.evaluateLazy(ctx, &lazy.LazyState, "File.file", func(ctx context.Context) error {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		if err := cache.Evaluate(ctx, lazy.Parent); err != nil {
			return err
		}

		parentPath, err := lazy.Parent.Self().Dir.GetOrEval(ctx, lazy.Parent.Result)
		if err != nil {
			return fmt.Errorf("failed to get parent directory path: %w", err)
		}
		finalPath := filepath.Join(parentPath, lazy.Path)

		query, err := CurrentQuery(ctx)
		if err != nil {
			return err
		}
		srv, err := query.Server.Server(ctx)
		if err != nil {
			return err
		}

		info, err := lazy.Parent.Self().Stat(ctx, lazy.Parent, srv, lazy.Path, false)
		if err != nil {
			return err
		}
		if info.FileType == FileTypeDirectory {
			return notAFileError{fmt.Errorf("path %s is a directory, not a file", lazy.Path)}
		}

		parentSnapshot, err := lazy.Parent.Self().Snapshot.GetOrEval(ctx, lazy.Parent.Result)
		if err != nil {
			return fmt.Errorf("failed to get parent directory snapshot: %w", err)
		}
		if parentSnapshot == nil {
			return fmt.Errorf("file subfile parent snapshot is nil")
		}

		reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, parentSnapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
		if err != nil {
			return err
		}
		file.SetPath(finalPath)
		file.SetSnapshot(reopened)
		return nil
	})
}

func (lazy *FileSubfileLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachDirectoryResult(attach, lazy.Parent, "attach file subfile parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *FileSubfileLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "file subfile parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedFileSubfileLazy{ParentResultID: parentID, Path: lazy.Path})
}

func (lazy *FileWithReplacedLazy) Evaluate(ctx context.Context, file *File) error {
	return file.evaluateLazy(ctx, &lazy.LazyState, "File.withReplaced", func(ctx context.Context) error {
		return file.WithReplaced(ctx, lazy.Parent, lazy.Search, lazy.Replacement, lazy.FirstFrom, lazy.All)
	})
}

func (lazy *FileWithReplacedLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	attached, err := attachFileResult(attach, lazy.Parent, "attach file withReplaced parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = attached
	return []dagql.AnyResult{attached}, nil
}

func (lazy *FileWithReplacedLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "file withReplaced parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedFileWithReplacedLazy{
		ParentResultID: parentID,
		Search:         lazy.Search,
		Replacement:    lazy.Replacement,
		FirstFrom:      lazy.FirstFrom,
		All:            lazy.All,
	})
}

func (lazy *FileWithNameLazy) Evaluate(ctx context.Context, file *File) error {
	return file.evaluateLazy(ctx, &lazy.LazyState, "File.withName", func(ctx context.Context) error {
		return file.WithName(ctx, lazy.Parent, lazy.Filename)
	})
}

func (lazy *FileWithNameLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	attached, err := attachFileResult(attach, lazy.Parent, "attach file withName parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = attached
	return []dagql.AnyResult{attached}, nil
}

func (lazy *FileWithNameLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "file withName parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedFileWithNameLazy{ParentResultID: parentID, Filename: lazy.Filename})
}

func (lazy *FileWithTimestampsLazy) Evaluate(ctx context.Context, file *File) error {
	return file.evaluateLazy(ctx, &lazy.LazyState, "File.withTimestamps", func(ctx context.Context) error {
		return file.WithTimestamps(ctx, lazy.Parent, lazy.Timestamp)
	})
}

func (lazy *FileWithTimestampsLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	attached, err := attachFileResult(attach, lazy.Parent, "attach file withTimestamps parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = attached
	return []dagql.AnyResult{attached}, nil
}

func (lazy *FileWithTimestampsLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "file withTimestamps parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedFileWithTimestampsLazy{ParentResultID: parentID, Timestamp: lazy.Timestamp})
}

func (lazy *FileChownLazy) Evaluate(ctx context.Context, file *File) error {
	return file.evaluateLazy(ctx, &lazy.LazyState, "File.chown", func(ctx context.Context) error {
		return file.Chown(ctx, lazy.Parent, lazy.Owner)
	})
}

func (lazy *FileChownLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	attached, err := attachFileResult(attach, lazy.Parent, "attach file chown parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = attached
	return []dagql.AnyResult{attached}, nil
}

func (lazy *FileChownLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "file chown parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedFileChownLazy{ParentResultID: parentID, Owner: lazy.Owner})
}

func (file *File) WithContents(ctx context.Context, parent dagql.ObjectResult[*Directory], filePath string, content []byte, permissions fs.FileMode, ownership *Ownership) error {
	if dir, _ := filepath.Split(filePath); dir != "" {
		return fmt.Errorf("file name %q must not contain a directory", filePath)
	}

	if permissions == 0 {
		permissions = 0o644
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return err
	}
	parentSnapshot, err := parent.Self().Snapshot.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	if parentSnapshot == nil {
		return fmt.Errorf("file withContents: nil parent snapshot")
	}
	file.SetPath(filePath)
	newRef, err := query.SnapshotManager().New(
		ctx,
		parentSnapshot,
		nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription(fmt.Sprintf("newFile %s", filePath)),
	)
	if err != nil {
		return err
	}

	err = MountRef(ctx, newRef, func(root string, _ *mount.Mount) error {
		resolvedDest, err := containerdfs.RootPath(root, filePath)
		if err != nil {
			return err
		}
		destPathDir, _ := filepath.Split(resolvedDest)
		err = os.MkdirAll(filepath.Dir(destPathDir), 0o755)
		if err != nil {
			return err
		}
		dst, err := os.OpenFile(resolvedDest, os.O_RDWR|os.O_CREATE|os.O_TRUNC, permissions)
		if err != nil {
			return err
		}
		defer func() {
			if dst != nil {
				_ = dst.Close()
			}
		}()

		if _, err := dst.Write(content); err != nil {
			return err
		}
		if err := dst.Close(); err != nil {
			return err
		}
		dst = nil

		if ownership != nil {
			if err := os.Chown(resolvedDest, ownership.UID, ownership.GID); err != nil {
				return fmt.Errorf("failed to set chown %s: err", resolvedDest)
			}
		}
		return nil
	})
	if err != nil {
		return err
	}

	snapshot, err := newRef.Commit(ctx)
	if err != nil {
		return err
	}
	file.SetSnapshot(snapshot)
	return nil
}

// Contents handles file content retrieval
func (file *File) Contents(ctx context.Context, self dagql.ObjectResult[*File], offset, limit *int) ([]byte, error) {
	if limit != nil && *limit == 0 {
		// edge case: 0 limit, possibly from maths, just don't do anything
		return nil, nil
	}

	var buf bytes.Buffer
	w := &limitedWriter{
		Limit:  engineutil.MaxFileContentsSize,
		Writer: &buf,
	}

	snapshot, err := file.Snapshot.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}
	if snapshot == nil {
		return nil, errEmptyResultRef
	}
	filePath, err := file.File.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}

	err = MountRef(ctx, snapshot, func(root string, _ *mount.Mount) error {
		fullPath, err := containerdfs.RootPath(root, filePath)
		if err != nil {
			return err
		}

		r, err := os.Open(fullPath)
		if err != nil {
			return err
		}
		defer r.Close()

		if offset != nil || limit != nil {
			br := bufio.NewReader(r)
			lineNum := 1
			readLines := 0
			for {
				line, err := br.ReadBytes('\n')
				if err != nil && err != io.EOF {
					return err
				}

				if offset == nil || lineNum > *offset {
					w.Write(line)
					readLines++
					if limit != nil && readLines == *limit {
						break
					}
				}

				if err == io.EOF {
					break
				}

				lineNum++
			}
		} else {
			_, err := io.Copy(w, r)
			if err != nil {
				return err
			}
		}
		return err
	}, mountRefAsReadOnly)
	if err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

type limitedWriter struct {
	Limit int
	io.Writer
	wrote int
}

func (cw *limitedWriter) Write(p []byte) (int, error) {
	if cw.wrote+len(p) > cw.Limit {
		return 0, fmt.Errorf("file size %d exceeds limit %d", cw.wrote+len(p), engineutil.MaxFileContentsSize)
	}
	n, err := cw.Writer.Write(p)
	if err != nil {
		return n, err
	}
	cw.wrote += n
	return n, nil
}

func (file *File) Search(ctx context.Context, self dagql.ObjectResult[*File], opts SearchOpts, verbose bool) ([]*SearchResult, error) {
	ref, err := file.Snapshot.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}
	if ref == nil {
		return nil, errEmptyResultRef
	}
	filePath, err := file.File.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}

	results := []*SearchResult{}
	err = MountRef(ctx, ref, func(root string, _ *mount.Mount) error {
		resolvedDir, err := containerdfs.RootPath(root, filepath.Dir(filePath))
		if err != nil {
			return err
		}
		rgArgs := opts.RipgrepArgs()
		rgArgs = append(rgArgs, "--", filepath.Base(filePath))
		rg := exec.Command("rg", rgArgs...)
		rg.Dir = resolvedDir
		results, err = opts.RunRipgrep(ctx, rg, verbose)
		return err
	})
	if err != nil {
		return nil, err
	}
	return results, nil
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (file *File) WithReplaced(ctx context.Context, parent dagql.ObjectResult[*File], searchStr, replacementStr string, firstFrom *int, all bool) error {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}

	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return err
	}
	parentPath, err := parent.Self().File.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	file.SetPath(parentPath)
	parentSnapshot, err := parent.Self().Snapshot.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	if parentSnapshot == nil {
		return fmt.Errorf("replace file: nil snapshot")
	}

	// reuse Search internally so we get convenient line numbers for an error if
	// there are multiple matches
	matches, err := parent.Self().Search(ctx, parent, SearchOpts{
		Pattern:   searchStr,
		Literal:   true,
		Multiline: strings.ContainsRune(searchStr, '\n'),
	}, false)
	if err != nil {
		return err
	}

	// Drop any matches before *firstFrom
	if firstFrom != nil {
		var matchesFrom []*SearchResult
		for _, match := range matches {
			if match.LineNumber >= *firstFrom {
				matchesFrom = append(matchesFrom, match)
			}
		}
		matches = matchesFrom
	}

	// Check for matches
	if len(matches) == 0 {
		if all {
			// If we're replacing all, it's not an error if there are no matches
			// (just a no-op)
			reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, parentSnapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
			if err != nil {
				return err
			}
			file.SetSnapshot(reopened)
			return nil
		}
		return fmt.Errorf("search string not found")
	}

	var matchedLocs []string
	for _, match := range matches {
		for _, sub := range match.Submatches {
			matchedLocs = append(matchedLocs, fmt.Sprintf("line %d (%d-%d)", match.LineNumber, sub.Start, sub.End))
		}
	}

	// Load content into memory for simple bytes.Replace
	//
	// This is obviously less efficient than streaming, but:
	// 1. it is far simpler (I tried streaming text/transform and hit cryptic errors),
	// 2. we already faced the music on that with File.contents,
	// 3. this will mainly be used for code which is fine to hold in memory, and
	// 4. it is far simpler.
	var offset *int
	if firstFrom != nil {
		o := *firstFrom - 1
		offset = &o
	}
	contents, err := parent.Self().Contents(ctx, parent, offset, nil)
	if err != nil {
		return err
	}
	search := []byte(searchStr)
	replacement := []byte(replacementStr)
	if all {
		contents = bytes.ReplaceAll(contents, search, replacement)
	} else if firstFrom != nil || len(matchedLocs) == 1 {
		contents = bytes.Replace(contents, search, replacement, 1)
	} else if len(matchedLocs) > 0 {
		return fmt.Errorf("search string found multiple times: %s", strings.Join(matchedLocs, ", "))
	}

	// If we replaced after a certain line, bring the content before it back
	if offset != nil && *offset > 0 {
		previous, err := parent.Self().Contents(ctx, parent, nil, offset)
		if err != nil {
			return err
		}
		contents = append(previous, contents...)
	}

	// Create a new layer for the replaced content
	newRef, err := query.SnapshotManager().New(ctx, parentSnapshot, bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription("patch"))
	if err != nil {
		return err
	}
	err = MountRef(ctx, newRef, func(root string, _ *mount.Mount) (rerr error) {
		resolvedPath, err := containerdfs.RootPath(root, parentPath)
		if err != nil {
			return err
		}
		// We're in a new copy-on-write layer, so truncating and rewriting in-place
		// should be fine; we don't need to worry about atomic writes, and this way
		// we preserve permissions and other metadata.
		if err := os.Truncate(resolvedPath, 0); err != nil {
			return err
		}
		f, err := os.OpenFile(resolvedPath, os.O_WRONLY, 0)
		if err != nil {
			return err
		}
		defer f.Close()
		_, err = f.Write(contents)
		return err
	})
	if err != nil {
		return err
	}
	snap, err := newRef.Commit(ctx)
	if err != nil {
		return err
	}
	file.SetSnapshot(snap)
	return nil
}

func (file *File) Digest(ctx context.Context, self dagql.ObjectResult[*File], excludeMetadata bool) (string, error) {
	// If metadata are included, directly compute the digest of the file
	if !excludeMetadata {
		snapshot, err := file.Snapshot.GetOrEval(ctx, self.Result)
		if err != nil {
			return "", fmt.Errorf("failed to evaluate file: %w", err)
		}
		if snapshot == nil {
			return "", fmt.Errorf("failed to evaluate null file")
		}
		filePath, err := file.File.GetOrEval(ctx, self.Result)
		if err != nil {
			return "", fmt.Errorf("failed to get file path: %w", err)
		}

		digest, err := bkcontenthash.Checksum(
			ctx,
			snapshot,
			filePath,
			bkcontenthash.ChecksumOpts{},
		)
		if err != nil {
			return "", fmt.Errorf("failed to compute digest: %w", err)
		}

		return digest.String(), nil
	}

	// If metadata are excluded, compute the digest of the file from its content.
	reader, err := file.Open(ctx, self)
	if err != nil {
		return "", fmt.Errorf("failed to open file to compute digest: %w", err)
	}

	defer reader.Close()

	h := sha256.New()
	if _, err := io.Copy(h, reader); err != nil {
		return "", fmt.Errorf("failed to copy file content into hasher: %w", err)
	}

	return digest.FromBytes(h.Sum(nil)).String(), nil
}

func (file *File) Stat(ctx context.Context, self dagql.ObjectResult[*File]) (*Stat, error) {
	immutableRef, err := file.Snapshot.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}
	if immutableRef == nil {
		filePath, _ := file.File.Peek()
		return nil, &os.PathError{Op: "stat", Path: filePath, Err: syscall.ENOENT}
	}
	filePath, err := file.File.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}

	osStatFunc := os.Stat
	rootPathFunc := containerdfs.RootPath
	// TODO Could there be a case where a File() is a symlink?
	// if doNotFollowSymlinks {
	// 	// symlink testing requires the Lstat call, which does NOT follow symlinks
	// 	osStatFunc = os.Lstat
	// 	// similarly, containerdfs.RootPath can't be used, since it follows symlinks
	// 	rootPathFunc = RootPathWithoutFinalSymlink
	// }

	var fileInfo os.FileInfo
	err = MountRef(ctx, immutableRef, func(root string, _ *mount.Mount) error {
		resolvedPath, err := rootPathFunc(root, filePath)
		if err != nil {
			return err
		}
		fileInfo, err = osStatFunc(resolvedPath)
		return TrimErrPathPrefix(err, root)
	})
	if err != nil {
		return nil, err
	}

	m := fileInfo.Mode()

	stat := &Stat{
		Size:        int(fileInfo.Size()),
		Name:        fileInfo.Name(),
		Permissions: int(fileInfo.Mode().Perm()),
		FileType:    FileModeToFileType(m),
	}

	return stat, nil
}

func (file *File) WithName(ctx context.Context, parent dagql.ObjectResult[*File], filename string) error {
	if dir, _ := filepath.Split(filename); dir != "" {
		return fmt.Errorf("file name %q must not contain a directory", filename)
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return err
	}
	sourcePath, err := parent.Self().File.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	destPath := filepath.Join(filepath.Dir(sourcePath), filename)
	file.SetPath(destPath)
	parentSnapshot, err := parent.Self().Snapshot.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	if parentSnapshot == nil {
		return fmt.Errorf("rename file: nil snapshot")
	}
	newRef, err := query.SnapshotManager().New(
		ctx,
		parentSnapshot,
		nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription(fmt.Sprintf("withName %s", filename)),
	)
	if err != nil {
		return err
	}
	err = MountRef(ctx, newRef, func(root string, _ *mount.Mount) error {
		src, err := RootPathWithoutFinalSymlink(root, sourcePath)
		if err != nil {
			return err
		}
		dst, err := RootPathWithoutFinalSymlink(root, destPath)
		if err != nil {
			return err
		}
		err = os.Rename(src, dst)
		if err != nil {
			return TrimErrPathPrefix(err, root)
		}
		return nil
	})
	if err != nil {
		return err
	}

	snapshot, err := newRef.Commit(ctx)
	if err != nil {
		return err
	}
	file.SetSnapshot(snapshot)
	return nil
}

func (file *File) WithTimestamps(ctx context.Context, parent dagql.ObjectResult[*File], unix int) error {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return err
	}
	parentPath, err := parent.Self().File.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	file.SetPath(parentPath)
	parentSnapshot, err := parent.Self().Snapshot.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	if parentSnapshot == nil {
		return fmt.Errorf("file withTimestamps: nil parent snapshot")
	}
	newRef, err := query.SnapshotManager().New(
		ctx,
		parentSnapshot,
		nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription(fmt.Sprintf("withTimestamps %d", unix)),
	)
	if err != nil {
		return err
	}
	err = MountRef(ctx, newRef, func(root string, _ *mount.Mount) error {
		fullPath, err := RootPathWithoutFinalSymlink(root, parentPath)
		if err != nil {
			return err
		}
		t := time.Unix(int64(unix), 0)
		err = os.Chtimes(fullPath, t, t)
		if err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		return err
	}

	snapshot, err := newRef.Commit(ctx)
	if err != nil {
		return err
	}
	file.SetSnapshot(snapshot)
	return nil
}

type fileReadCloser struct {
	read  func(p []byte) (n int, err error)
	close func() error
}

func (frc fileReadCloser) Read(p []byte) (n int, err error) {
	return frc.read(p)
}

func (frc fileReadCloser) Close() error {
	return frc.close()
}

var _ io.ReadCloser = fileReadCloser{}

func (file *File) Open(ctx context.Context, self dagql.ObjectResult[*File]) (io.ReadCloser, error) {
	snapshot, err := file.Snapshot.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}
	if snapshot == nil {
		return nil, errEmptyResultRef
	}
	filePath, err := file.File.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, err
	}

	root, _, closer, err := MountRefCloser(ctx, snapshot, mountRefAsReadOnly)
	if err != nil {
		return nil, err
	}

	resolvedPath, err := containerdfs.RootPath(root, filePath)
	if err != nil {
		closeErr := closer()
		if closeErr != nil {
			err = errors.Join(err, closeErr)
		}
		return nil, err
	}

	r, err := os.Open(resolvedPath)
	if err != nil {
		closeErr := closer()
		if closeErr != nil {
			err = errors.Join(err, closeErr)
		}
		return nil, err
	}

	return &fileReadCloser{
		read: r.Read,
		close: func() error {
			var errs error
			if err := r.Close(); err != nil {
				errs = errors.Join(errs, err)
			}
			if err := closer(); err != nil {
				errs = errors.Join(errs, err)
			}
			return errs
		},
	}, nil
}

func ExportFile(ctx context.Context, snapshot bkcache.ImmutableRef, filePath, dest string, allowParentDirPath bool) (rerr error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	bk, err := query.Engine(ctx)
	if err != nil {
		return fmt.Errorf("failed to get engine client: %w", err)
	}

	ctx, vtx := Tracer(ctx).Start(ctx, fmt.Sprintf("export file %s to host %s", filepath.Base(filePath), dest))
	defer telemetry.EndWithCause(vtx, &rerr)

	if snapshot == nil {
		return errEmptyResultRef
	}

	return MountRef(ctx, snapshot, func(root string, _ *mount.Mount) error {
		path, err := containerdfs.RootPath(root, filePath)
		if err != nil {
			return err
		}
		return bk.LocalFileExport(ctx, path, filePath, dest, allowParentDirPath)
	})
}

func (file *File) Mount(ctx context.Context, self dagql.ObjectResult[*File], f func(string) error) error {
	snapshot, err := file.Snapshot.GetOrEval(ctx, self.Result)
	if err != nil {
		return err
	}
	if snapshot == nil {
		return errEmptyResultRef
	}
	filePath, err := file.File.GetOrEval(ctx, self.Result)
	if err != nil {
		return err
	}
	err = MountRef(ctx, snapshot, func(root string, _ *mount.Mount) error {
		src, err := containerdfs.RootPath(root, filePath)
		if err != nil {
			return err
		}
		return f(src)
	}, mountRefAsReadOnly)
	return err
}

// AsJSON returns the file contents as JSON when possible, otherwise returns an error
func (file *File) AsJSON(ctx context.Context, self dagql.ObjectResult[*File]) (JSON, error) {
	contents, err := file.Contents(ctx, self, nil, nil)
	if err != nil {
		return nil, err
	}

	json := JSON(contents)
	if err := json.Validate(); err != nil {
		return nil, err
	}

	return json, nil
}

// AsEnvFile converts a File to an EnvFile by parsing its contents
func (file *File) AsEnvFile(ctx context.Context, self dagql.ObjectResult[*File], expand bool) (*EnvFile, error) {
	contents, err := file.Contents(ctx, self, nil, nil)
	if err != nil {
		return nil, err
	}
	return (&EnvFile{
		Expand: expand,
	}).WithContents(string(contents))
}

func (file *File) Chown(ctx context.Context, parent dagql.ObjectResult[*File], owner string) error {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return err
	}
	parentPath, err := parent.Self().File.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	file.SetPath(parentPath)
	parentSnapshot, err := parent.Self().Snapshot.GetOrEval(ctx, parent.Result)
	if err != nil {
		return err
	}
	if parentSnapshot == nil {
		return fmt.Errorf("file chown: nil parent snapshot")
	}
	newRef, err := query.SnapshotManager().New(
		ctx,
		parentSnapshot,
		nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription(fmt.Sprintf("chown %s %s", parentPath, owner)),
	)
	if err != nil {
		return err
	}
	err = MountRef(ctx, newRef, func(root string, _ *mount.Mount) error {
		ownership, err := resolveDirectoryOwner(root, owner)
		if err != nil {
			return fmt.Errorf("failed to parse ownership %s: %w", owner, err)
		}

		chownPath := parentPath
		chownPath, err = containerdfs.RootPath(root, chownPath)
		if err != nil {
			return err
		}

		err = filepath.WalkDir(chownPath, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if err := os.Lchown(path, ownership.UID, ownership.GID); err != nil {
				return fmt.Errorf("failed to set chown %s: %w", path, err)
			}
			return nil
		})
		if err != nil {
			return fmt.Errorf("failed to walk %s: %w", chownPath, err)
		}
		return nil
	})
	if err != nil {
		return err
	}

	snapshot, err := newRef.Commit(ctx)
	if err != nil {
		return err
	}
	file.SetSnapshot(snapshot)
	return nil
}
