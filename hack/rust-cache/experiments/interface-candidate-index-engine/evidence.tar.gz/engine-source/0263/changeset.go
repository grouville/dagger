package core

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"

	"github.com/containerd/containerd/v2/core/mount"
	containerdfs "github.com/containerd/continuity/fs"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	"github.com/dagger/dagger/engine/slog"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	"github.com/dagger/dagger/engine/snapshots/fsdiff"
	enginetel "github.com/dagger/dagger/engine/telemetry"
	"github.com/dagger/dagger/engine/wcprof"
	bkclient "github.com/dagger/dagger/internal/buildkit/client"
	"github.com/dagger/dagger/internal/fsutil"
	fsutiltypes "github.com/dagger/dagger/internal/fsutil/types"
	"github.com/dagger/dagger/util/layercopy"
	"github.com/dagger/dagger/util/parallel"
	telemetry "github.com/dagger/otel-go"
	"github.com/opencontainers/go-digest"
	"github.com/vektah/gqlparser/v2/ast"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/log"
	"golang.org/x/sys/unix"
)

func NewChangeset(ctx context.Context, before, after dagql.ObjectResult[*Directory]) (*Changeset, error) {
	return &Changeset{
		Before: before,
		After:  after,
		paths:  &changesetPathsMemo{},
	}, nil
}

// NewEmptyChangeset creates a changeset with no changes (before and after are the same empty directory).
func NewEmptyChangeset(ctx context.Context) (*Changeset, error) {
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, err
	}

	var emptyDir dagql.ObjectResult[*Directory]
	if err := srv.Select(ctx, srv.Root(), &emptyDir,
		dagql.Selector{Field: "directory"},
	); err != nil {
		return nil, fmt.Errorf("create empty directory: %w", err)
	}

	return NewChangeset(ctx, emptyDir, emptyDir)
}

type ChangesetPaths struct {
	Added      []string
	Modified   []string
	Removed    []string
	AllRemoved []string
	Renamed    map[string]string // newPath → oldPath (also included in Added/Removed)
}

type DiffStatKind string

var DiffStatKindEnum = dagql.NewEnum[DiffStatKind]()

var (
	DiffStatKindAdded = DiffStatKindEnum.Register("ADDED",
		`A file or directory was added.`)
	DiffStatKindModified = DiffStatKindEnum.Register("MODIFIED",
		`A file was modified.`)
	DiffStatKindRemoved = DiffStatKindEnum.Register("REMOVED",
		`A file or directory was removed.`)
	DiffStatKindRenamed = DiffStatKindEnum.Register("RENAMED",
		`A file was renamed.`)
)

func (DiffStatKind) Type() *ast.Type {
	return &ast.Type{
		NamedType: "DiffStatKind",
		NonNull:   true,
	}
}

func (DiffStatKind) TypeDescription() string {
	return "The type of change for a diff stat entry."
}

func (DiffStatKind) Decoder() dagql.InputDecoder {
	return DiffStatKindEnum
}

func (k DiffStatKind) ToLiteral() call.Literal {
	return DiffStatKindEnum.Literal(k)
}

type DiffStat struct {
	Path         string       `field:"true" doc:"Path of the changed file or directory."`
	OldPath      *string      `field:"true" doc:"Previous path of the file, set only for renames."`
	Kind         DiffStatKind `field:"true" doc:"Type of change."`
	AddedLines   int          `field:"true" doc:"Number of added lines for this path."`
	RemovedLines int          `field:"true" doc:"Number of removed lines for this path."`
}

var (
	_ dagql.PersistedObject        = (*DiffStat)(nil)
	_ dagql.PersistedObjectDecoder = (*DiffStat)(nil)
)

func (*DiffStat) Type() *ast.Type {
	return &ast.Type{
		NamedType: "DiffStat",
		NonNull:   true,
	}
}

type persistedDiffStat struct {
	Path         string       `json:"path"`
	OldPath      *string      `json:"oldPath,omitempty"`
	Kind         DiffStatKind `json:"kind"`
	AddedLines   int          `json:"addedLines"`
	RemovedLines int          `json:"removedLines"`
}

func (s *DiffStat) EncodePersistedObject(context.Context, *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	if s == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted diff stat: nil diff stat")
	}
	return encodePersistedObjectPayload(persistedDiffStat{
		Path:         s.Path,
		OldPath:      s.OldPath,
		Kind:         s.Kind,
		AddedLines:   s.AddedLines,
		RemovedLines: s.RemovedLines,
	})
}

func (*DiffStat) DecodePersistedObject(_ context.Context, _ *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	var persisted persistedDiffStat
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted diff stat payload: %w", err)
	}
	return &DiffStat{
		Path:         persisted.Path,
		OldPath:      persisted.OldPath,
		Kind:         persisted.Kind,
		AddedLines:   persisted.AddedLines,
		RemovedLines: persisted.RemovedLines,
	}, nil
}

// ComputePaths computes the added, modified, and removed paths using file
// metadata and git diffs.
func (ch *Changeset) ComputePaths(ctx context.Context) (*ChangesetPaths, error) {
	memo := ch.paths
	memo.once.Do(func() {
		defer memo.done.Store(true)
		_ = enginetel.Task(ctx, "computing paths", func(ctx context.Context) error {
			memo.paths, memo.err = ch.computePathsOnce(ctx)
			if memo.err != nil {
				// nothing to report; paths is nil on error
				return memo.err
			}
			stdio := telemetry.SpanStdio(ctx, InstrumentationLibrary)
			defer stdio.Close()
			fmt.Fprintln(stdio.Stdout, "added:", memo.paths.Added)
			fmt.Fprintln(stdio.Stdout, "removed:", memo.paths.Removed)
			fmt.Fprintln(stdio.Stdout, "modified:", memo.paths.Modified)
			fmt.Fprintln(stdio.Stdout, "renamed:", memo.paths.Renamed)
			return nil
		})
	})
	return memo.paths, memo.err
}

// changesetPathCount is the number of entries ComputePaths reports: every
// added, modified and removed path, directories included. A rename counts
// twice, since it appears in both Added and AllRemoved.
func changesetPathCount(paths *ChangesetPaths) int {
	return len(paths.Added) + len(paths.Modified) + len(paths.AllRemoved)
}

// PathCountExceeds reports whether the changeset touches more than limit
// paths, counted the way ComputePaths reports them (see changesetPathCount).
// It exists for callers deciding whether a changeset is too large to present
// in full, who shouldn't have to walk a 100k-file tree to completion to learn
// that it is.
//
// This is an upper-bound check. When ComputePaths has already run, the answer
// comes straight from its memoized result and is exact. Otherwise the metadata
// delta is walked and abandoned as soon as more than limit entries are seen,
// without the rename detection or content verification ComputePaths performs:
// a distinct backing file still counts even if its content is identical.
// Thus true means more than limit candidate paths, not necessarily actual
// changes, while false guarantees at most limit paths changed.
//
// The partial walk never populates the ComputePaths memo; a later ComputePaths
// still computes the full result. The walk's answer is memoized per limit,
// though, so repeated calls with the same limit only walk once.
func (ch *Changeset) PathCountExceeds(ctx context.Context, limit int) (bool, error) {
	if ch.paths.done.Load() {
		paths, err := ch.ComputePaths(ctx)
		if err != nil {
			return false, err
		}
		return changesetPathCount(paths) > limit, nil
	}

	memo := ch.paths
	memo.boundMu.Lock()
	defer memo.boundMu.Unlock()
	if memo.boundKnown && memo.boundLimit == limit {
		return memo.boundExceeds, nil
	}

	beforeDigest, err := ch.Before.ContentPreferredDigest(ctx)
	if err != nil {
		return false, fmt.Errorf("before content-preferred digest: %w", err)
	}
	afterDigest, err := ch.After.ContentPreferredDigest(ctx)
	if err != nil {
		return false, fmt.Errorf("after content-preferred digest: %w", err)
	}
	if beforeDigest == afterDigest {
		// Nothing changed; only a negative limit is exceeded by zero paths.
		return limit < 0, nil
	}

	var exceeds bool
	var deltaErr error
	err = ch.withMountedDirs(ctx, func(ctx context.Context, beforeDir, afterDir string, layers *fsdiff.LayerDelta) error {
		exceeds, deltaErr = changesetDeltaExceeds(ctx, beforeDir, afterDir, layers, limit)
		return nil
	})
	if err != nil {
		return false, err
	}
	if deltaErr != nil {
		if ctx.Err() != nil {
			return false, context.Cause(ctx)
		}
		// A bounded inspection must not fall back to an unbounded content
		// diff. Callers can omit the summary or keep the raw changeset.
		return false, fmt.Errorf("bound changeset delta: %w", deltaErr)
	}
	memo.boundLimit, memo.boundExceeds, memo.boundKnown = limit, exceeds, true
	return exceeds, nil
}

func (ch *Changeset) computePathsOnce(ctx context.Context) (*ChangesetPaths, error) {
	beforeDigest, err := ch.Before.ContentPreferredDigest(ctx)
	if err != nil {
		return nil, fmt.Errorf("before content-preferred digest: %w", err)
	}
	afterDigest, err := ch.After.ContentPreferredDigest(ctx)
	if err != nil {
		return nil, fmt.Errorf("after content-preferred digest: %w", err)
	}
	if beforeDigest == afterDigest {
		return &ChangesetPaths{}, nil
	}

	var result *ChangesetPaths
	err = ch.withMountedDirs(ctx, func(ctx context.Context, beforeDir, afterDir string, layers *fsdiff.LayerDelta) (err error) {
		result, _, err = computeChangesetPathsDelta(ctx, beforeDir, afterDir, layers, false)
		if err != nil {
			fallBackToContentDiff(ctx, err)
			result, err = computeChangesetPaths(ctx, beforeDir, afterDir)
		}
		return err
	})
	if err != nil {
		return nil, err
	}
	return result, nil
}

// maxGitPathSpecBytes bounds the pathspecs appended to a git diff. They only
// narrow work that would otherwise be correct anyway, and argv has a hard size
// limit, so the list gets collapsed or dropped rather than allowed to grow
// until exec fails.
const maxGitPathSpecBytes = 128 << 10

// gitDiffPathSpecs returns pathspecs limiting a diff to the paths that
// actually changed. Renamed paths need no entry of their own: ChangesetPaths
// records them under both their old and new names, in Removed and Added.
//
// An empty result means "diff everything". Too many paths to pass are first
// collapsed to their parent directories, which still match everything beneath
// them, and given up on entirely once even those don't fit.
func gitDiffPathSpecs(paths *ChangesetPaths) []string {
	specs := slices.Concat(paths.Added, paths.Removed, paths.Modified)
	for pathSpecsSize(specs) > maxGitPathSpecBytes {
		specs = collapsePathSpecsToParents(specs)
		if len(specs) == 0 {
			return nil
		}
	}
	return specs
}

func pathSpecsSize(specs []string) int {
	var size int
	for _, spec := range specs {
		size += len(spec) + 1 // NUL terminator in argv
	}
	return size
}

// collapsePathSpecsToParents replaces each pathspec with its parent directory,
// which matches everything the original did and then some. Returns nil once
// any entry sits at the tree root, since its parent is the whole tree.
func collapsePathSpecsToParents(specs []string) []string {
	seen := make(map[string]struct{}, len(specs))
	collapsed := make([]string, 0, len(specs))
	for _, spec := range specs {
		parent := path.Dir(path.Clean(spec))
		if parent == "." || parent == "/" {
			return nil
		}
		if _, ok := seen[parent]; ok {
			continue
		}
		seen[parent] = struct{}{}
		collapsed = append(collapsed, parent)
	}
	return collapsed
}

func computeChangesetPaths(ctx context.Context, beforeDir, afterDir string) (*ChangesetPaths, error) {
	fc, err := compareDirectories(ctx, beforeDir, afterDir)
	if err != nil {
		return nil, err
	}

	beforeDirs, err := listSubdirectories(beforeDir)
	if err != nil {
		return nil, fmt.Errorf("list before directories: %w", err)
	}
	afterDirs, err := listSubdirectories(afterDir)
	if err != nil {
		return nil, fmt.Errorf("list after directories: %w", err)
	}
	addedDirs, removedDirs := diffStringSlices(beforeDirs, afterDirs)

	// Expand renames into Added/Removed so addedPaths/removedPaths stay complete.
	renamedNew := make([]string, 0, len(fc.Renamed))
	renamedOld := make([]string, 0, len(fc.Renamed))
	for newPath, oldPath := range fc.Renamed {
		renamedNew = append(renamedNew, newPath)
		renamedOld = append(renamedOld, oldPath)
	}

	// Sort to match computeChangesetPathsDelta: both paths must emit one
	// canonical order, or which order a caller observes silently depends on
	// whether the metadata delta walk succeeded on the underlying mounts.
	allRemoved := slices.Concat(fc.Removed, renamedOld, removedDirs)
	slices.Sort(allRemoved)
	added := slices.Concat(fc.Added, renamedNew, addedDirs)
	slices.Sort(added)
	slices.Sort(fc.Modified)

	return &ChangesetPaths{
		Added:      added,
		Modified:   fc.Modified,
		Removed:    collapseChildPaths(allRemoved),
		AllRemoved: allRemoved,
		Renamed:    fc.Renamed,
	}, nil
}

// withMountedDirs mounts the before and after directories and calls fn with
// their paths, and with the overlay layers separating them if there are any
// (see changesetLayers). fn runs in its own internal span, where the delta
// walk records which walk it took (see recordChangesetWalk), so each
// comparison's walk and reasons stay together.
func (ch *Changeset) withMountedDirs(ctx context.Context, fn func(ctx context.Context, beforeDir, afterDir string, layers *fsdiff.LayerDelta) error) error {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	if err := cache.Evaluate(ctx, ch.Before, ch.After); err != nil {
		return fmt.Errorf("evaluate changeset directories: %w", err)
	}

	beforeRef, err := ch.Before.Self().Snapshot.GetOrEval(ctx, ch.Before.Result)
	if err != nil {
		return fmt.Errorf("evaluate before: %w", err)
	}

	afterRef, err := ch.After.Self().Snapshot.GetOrEval(ctx, ch.After.Result)
	if err != nil {
		return fmt.Errorf("evaluate after: %w", err)
	}

	beforeSelector, err := ch.Before.Self().Dir.GetOrEval(ctx, ch.Before.Result)
	if err != nil {
		return fmt.Errorf("evaluate before selector: %w", err)
	}
	afterSelector, err := ch.After.Self().Dir.GetOrEval(ctx, ch.After.Result)
	if err != nil {
		return fmt.Errorf("evaluate after selector: %w", err)
	}

	return MountRef(ctx, beforeRef, func(beforeMount string, beforeMnt *mount.Mount) error {
		beforeDir, err := containerdfs.RootPath(beforeMount, beforeSelector)
		if err != nil {
			return err
		}

		return MountRef(ctx, afterRef, func(afterMount string, afterMnt *mount.Mount) (rerr error) {
			afterDir, err := containerdfs.RootPath(afterMount, afterSelector)
			if err != nil {
				return err
			}

			ctx, span := Tracer(ctx).Start(ctx, "compare changeset trees", telemetry.Internal())
			defer telemetry.EndWithCause(span, &rerr)
			layers, reason := changesetLayers(beforeMount, beforeDir, beforeMnt, afterMount, afterDir, afterMnt)
			if layers == nil {
				span.SetAttributes(attribute.String("dagger.changeset.layers_unavailable", reason))
			}
			return fn(ctx, beforeDir, afterDir, layers)
		}, mountRefAsReadOnly)
	}, mountRefAsReadOnly)
}

// changesetLayers returns the overlay layer directories separating Before
// from After, when there are such layers: both are snapshots of one lineage,
// After one or several Directory operations above Before (a workspace's tool
// edits each add one) or both built on a common ancestor (two copy-on-write
// children of one checkout), and they select the same directory of their
// snapshots. Every difference between the trees is then recorded in those
// layers, and walking them finds them without walking both trees in full.
// Returns nil otherwise, with the reason.
func changesetLayers(beforeRoot, beforeDir string, beforeMnt *mount.Mount, afterRoot, afterDir string, afterMnt *mount.Mount) (*fsdiff.LayerDelta, string) {
	if beforeMnt == nil || afterMnt == nil {
		return nil, "not mounted from snapshots"
	}
	// The selected directories, with symlinks resolved, must be the same
	// path: the layers record changes under their real paths.
	beforeRel, err := filepath.Rel(beforeRoot, beforeDir)
	if err != nil {
		return nil, err.Error()
	}
	afterRel, err := filepath.Rel(afterRoot, afterDir)
	if err != nil || afterRel != beforeRel || strings.HasPrefix(beforeRel, "..") {
		return nil, "different selected directories"
	}
	delta, err := fsdiff.GetLayerDelta([]mount.Mount{*beforeMnt}, []mount.Mount{*afterMnt})
	if err != nil {
		return nil, err.Error()
	}
	if delta.Same {
		// One snapshot's layers, selected at the same directory.
		return &delta, ""
	}
	// Walking a layer from the selected directory needs that directory in
	// it, and neither it nor any parent opaque, replaced or redirected: an
	// opaque directory hides the shared layers beneath it, and a redirected
	// one inherits from another path in them, neither of which the layers
	// alone list. Of several layers, one without the directory changed
	// nothing under it and is left out; a single layer without it is left to
	// the full walk, as it always was.
	var components []string
	if beforeRel != "." {
		components = strings.Split(beforeRel, string(filepath.Separator))
	}
	several := len(delta.Lower)+len(delta.Upper) > 1
	selected := func(layers []string) ([]string, bool) {
		var dirs []string
	layers:
		for _, layer := range layers {
			dir := layer
			for i := 0; ; i++ {
				fi, err := os.Lstat(dir)
				if errors.Is(err, os.ErrNotExist) && several && i > 0 {
					continue layers
				}
				if err != nil || !fi.IsDir() {
					// Anything else, e.g. a whiteout, isn't a layer to
					// walk from here.
					return nil, false
				}
				if opaque, err := fsdiff.IsOpaqueDir(dir); err != nil || opaque {
					return nil, false
				}
				if redirect, err := fsdiff.IsRedirectDir(dir); err != nil || redirect {
					return nil, false
				}
				if i == len(components) {
					break
				}
				dir = filepath.Join(dir, components[i])
			}
			dirs = append(dirs, dir)
		}
		return dirs, true
	}
	lower, ok := selected(delta.Lower)
	if !ok {
		return nil, "selected directory replaced, opaque or redirected in a layer"
	}
	upper, ok := selected(delta.Upper)
	if !ok {
		return nil, "selected directory replaced, opaque or redirected in a layer"
	}
	layers := &fsdiff.LayerDelta{Lower: lower, Upper: upper}
	if layers.Empty() {
		// No layer changed anything under the selected directory: a rare
		// case, left to the full walk.
		return nil, "no layer holds the selected directory"
	}
	return layers, ""
}

type Changeset struct {
	Before dagql.ObjectResult[*Directory] `field:"true" doc:"The older/lower snapshot to compare against."`
	After  dagql.ObjectResult[*Directory] `field:"true" doc:"The newer/upper snapshot."`

	// used for JSON deserialization, since we can't directly load IDs into
	// objects in UnmarshalJSON
	decoded *changesetJSONEnvelope

	paths *changesetPathsMemo
}

// changesetPathsMemo memoizes ComputePaths. Held by pointer so that copies of
// a Changeset share one computation, and so a partial answer from
// PathCountExceeds can tell whether the full one already exists.
type changesetPathsMemo struct {
	once  sync.Once
	done  atomic.Bool // set once paths/err are final
	paths *ChangesetPaths
	err   error

	// bound memoizes PathCountExceeds' partial walk for the last limit asked
	// about. The callers that apply a tool's changeset ask the same question
	// in turn — whether it changes anything, then whether to show it in
	// full — and shouldn't each mount and walk the delta again.
	boundMu      sync.Mutex
	boundLimit   int
	boundExceeds bool
	boundKnown   bool
}

type changesetJSONEnvelope struct {
	BeforeID dagql.ID[*Directory] `json:"beforeId"`
	AfterID  dagql.ID[*Directory] `json:"afterId"`
}

type persistedChangesetPayload struct {
	BeforeResultID uint64 `json:"beforeResultID,omitempty"`
	AfterResultID  uint64 `json:"afterResultID,omitempty"`
}

// MarshalJSON implements custom JSON marshaling that stores directory IDs
func (ch *Changeset) MarshalJSON() ([]byte, error) {
	beforeID, err := ch.Before.ID()
	if err != nil {
		return nil, fmt.Errorf("before ID: %w", err)
	}
	afterID, err := ch.After.ID()
	if err != nil {
		return nil, fmt.Errorf("after ID: %w", err)
	}
	return json.Marshal(changesetJSONEnvelope{
		BeforeID: dagql.NewID[*Directory](beforeID),
		AfterID:  dagql.NewID[*Directory](afterID),
	})
}

// UnmarshalJSON implements custom JSON unmarshaling that stores IDs for later resolution
func (ch *Changeset) UnmarshalJSON(data []byte) error {
	var env changesetJSONEnvelope
	if err := json.Unmarshal(data, &env); err != nil {
		return err
	}
	ch.decoded = &env
	ch.paths = &changesetPathsMemo{}
	return nil
}

// ResolveRefs must be called after JSON unmarshaling to fully reconstruct the Changeset.
func (ch *Changeset) ResolveRefs(ctx context.Context, srv *dagql.Server) error {
	if ch.decoded == nil {
		return nil
	}
	var err error
	ch.Before, err = ch.decoded.BeforeID.Load(ctx, srv)
	if err != nil {
		return fmt.Errorf("load before: %w", err)
	}
	ch.After, err = ch.decoded.AfterID.Load(ctx, srv)
	if err != nil {
		return fmt.Errorf("load after: %w", err)
	}
	ch.decoded = nil
	return nil
}

// encodePersistedChangesetPayload records the exact before and after
// directory rows of a changeset; it is shared by the Changeset codec and by
// values that hold raw changesets inline.
func encodePersistedChangesetPayload(enc *dagql.PersistEncodeContext, ch *Changeset, label string) (persistedChangesetPayload, error) {
	if ch == nil {
		return persistedChangesetPayload{}, fmt.Errorf("encode persisted %s: nil changeset", label)
	}
	beforeID, err := encodePersistedObjectRef(enc, ch.Before, label+" before")
	if err != nil {
		return persistedChangesetPayload{}, err
	}
	afterID, err := encodePersistedObjectRef(enc, ch.After, label+" after")
	if err != nil {
		return persistedChangesetPayload{}, err
	}
	return persistedChangesetPayload{BeforeResultID: beforeID, AfterResultID: afterID}, nil
}

func decodePersistedChangesetPayload(ctx context.Context, dec *dagql.PersistDecodeContext, persisted persistedChangesetPayload, label string) (*Changeset, error) {
	before, err := loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.BeforeResultID, label+" before")
	if err != nil {
		return nil, err
	}
	after, err := loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.AfterResultID, label+" after")
	if err != nil {
		return nil, err
	}
	return NewChangeset(ctx, before, after)
}

func (ch *Changeset) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	_ = ctx
	encoded, err := encodePersistedChangesetPayload(enc, ch, "changeset")
	if err != nil {
		return dagql.PersistedObjectEncoding{}, err
	}
	payload, err := json.Marshal(encoded)
	if err != nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("marshal persisted changeset payload: %w", err)
	}
	return encodePersistedObjectRawJSON(payload), nil
}

func (*Changeset) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	var persisted persistedChangesetPayload
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted changeset payload: %w", err)
	}
	return decodePersistedChangesetPayload(ctx, dec, persisted, "changeset")
}

// changesetPathSets enables O(1) path lookups during conflict detection.
type changesetPathSets struct {
	added    map[string]struct{}
	modified map[string]struct{}
	removed  map[string]struct{}
}

func (ch *ChangesetPaths) pathSets() changesetPathSets {
	sets := changesetPathSets{
		added:    make(map[string]struct{}, len(ch.Added)),
		modified: make(map[string]struct{}, len(ch.Modified)),
		removed:  make(map[string]struct{}, len(ch.Removed)),
	}
	for _, p := range ch.Added {
		sets.added[p] = struct{}{}
	}
	for _, p := range ch.Modified {
		sets.modified[p] = struct{}{}
	}
	for _, p := range ch.Removed {
		sets.removed[p] = struct{}{}
	}
	return sets
}

func (*Changeset) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Changeset",
		NonNull:   true,
	}
}

func (*Changeset) TypeDescription() string {
	return "A comparison between two directories representing changes that can be applied."
}

var (
	_ Syncable                     = (*Changeset)(nil)
	_ dagql.PersistedObject        = (*Changeset)(nil)
	_ dagql.PersistedObjectDecoder = (*Changeset)(nil)
	_ dagql.HasDependencyResults   = (*Changeset)(nil)
)

// Evaluate forces the changeset's before/after directories to materialize. This
// is where a generator's underlying exec (e.g. SDK codegen) actually runs, so
// syncing a changeset within a generator's span attributes any failure to that
// span -- the frontend then renders a red generator with its exec logs, instead
// of the failure surfacing later, unattributed, during the merge.
func (ch *Changeset) Evaluate(ctx context.Context) error {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	return cache.Evaluate(ctx, ch.Before, ch.After)
}

func (ch *Changeset) Sync(ctx context.Context) error {
	return ch.Evaluate(ctx)
}

func (ch *Changeset) AttachDependencyResults(
	ctx context.Context,
	_ dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.AnyResult, error) {
	if ch == nil {
		return nil, nil
	}

	var deps []dagql.AnyResult

	if ch.Before.Self() != nil {
		attached, err := attach(ch.Before)
		if err != nil {
			return nil, fmt.Errorf("attach changeset before: %w", err)
		}
		before, ok := attached.(dagql.ObjectResult[*Directory])
		if !ok {
			return nil, fmt.Errorf("attach changeset before: unexpected result %T", attached)
		}
		ch.Before = before
		deps = append(deps, before)
	}

	if ch.After.Self() != nil {
		attached, err := attach(ch.After)
		if err != nil {
			return nil, fmt.Errorf("attach changeset after: %w", err)
		}
		after, ok := attached.(dagql.ObjectResult[*Directory])
		if !ok {
			return nil, fmt.Errorf("attach changeset after: unexpected result %T", attached)
		}
		ch.After = after
		deps = append(deps, after)
	}

	return deps, nil
}

const ChangesetPatchFilename = "diff.patch"

func (ch *Changeset) IsEmpty(ctx context.Context) (bool, error) {
	beforeDigest, err := ch.Before.ContentPreferredDigest(ctx)
	if err != nil {
		return false, fmt.Errorf("before content-preferred digest: %w", err)
	}
	afterDigest, err := ch.After.ContentPreferredDigest(ctx)
	if err != nil {
		return false, fmt.Errorf("after content-preferred digest: %w", err)
	}
	if beforeDigest == afterDigest {
		return true, nil
	}

	var isEmpty bool
	err = ch.withMountedDirs(ctx, func(ctx context.Context, beforeDir, afterDir string, layers *fsdiff.LayerDelta) error {
		empty, err := changesetDeltaIsEmpty(ctx, beforeDir, afterDir, layers)
		if err == nil {
			isEmpty = empty
			return nil
		}
		fallBackToContentDiff(ctx, err)
		identical, err := directoriesAreIdentical(ctx, beforeDir, afterDir)
		if err != nil {
			return err
		}
		isEmpty = identical
		return nil
	})
	if err != nil {
		return false, err
	}
	return isEmpty, nil
}

func (ch *Changeset) DiffStats(ctx context.Context) ([]*DiffStat, error) {
	var paths *ChangesetPaths
	var statsByPath map[string]lineChanges
	err := ch.withMountedDirs(ctx, func(ctx context.Context, beforeDir, afterDir string, layers *fsdiff.LayerDelta) error {
		computedPaths, deltaStats, err := computeChangesetPathsDelta(ctx, beforeDir, afterDir, layers, true)
		if err != nil {
			fallBackToContentDiff(ctx, err)
			computedPaths, err = computeChangesetPaths(ctx, beforeDir, afterDir)
			if err != nil {
				return fmt.Errorf("compute paths: %w", err)
			}
			deltaStats, err = compareDirectoriesNumStat(ctx, beforeDir, afterDir)
			if err != nil {
				slog.Debug("changeset numstat failed; returning path-only diff stat entries", "error", err)
				deltaStats = nil
			}
		}
		paths = computedPaths
		statsByPath = deltaStats
		return nil
	})
	if err != nil {
		return nil, err
	}

	addEntry := func(path string, kind DiffStatKind) *DiffStat {
		entry := &DiffStat{Path: path, Kind: kind}
		if stat, ok := statsByPath[path]; ok {
			entry.AddedLines = stat.Added
			entry.RemovedLines = stat.Removed
		}
		return entry
	}

	// Build a set of old renamed paths so we can skip them in Removed
	// (they'll appear as KindRenamed via their new path in Added).
	renamedOld := make(map[string]bool, len(paths.Renamed))
	for _, oldPath := range paths.Renamed {
		renamedOld[oldPath] = true
	}

	var entries []*DiffStat
	for _, path := range paths.Added {
		if oldPath, isRenamed := paths.Renamed[path]; isRenamed {
			entry := addEntry(path, DiffStatKindRenamed)
			entry.OldPath = &oldPath
			entries = append(entries, entry)
		} else {
			entries = append(entries, addEntry(path, DiffStatKindAdded))
		}
	}
	for _, path := range paths.Modified {
		entries = append(entries, addEntry(path, DiffStatKindModified))
	}
	// Use AllRemoved (uncollapsed) so that patchpreview.foldRemovedDirs can
	// fold child files into their parent directory with summed line counts.
	for _, path := range paths.AllRemoved {
		if renamedOld[path] {
			continue
		}
		entries = append(entries, addEntry(path, DiffStatKindRemoved))
	}

	slices.SortFunc(entries, func(a, b *DiffStat) int {
		return strings.Compare(a.Path, b.Path)
	})
	return entries, nil
}

func (ch *Changeset) AsPatch(ctx context.Context) (*File, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, ch.Before, ch.After); err != nil {
		return nil, fmt.Errorf("evaluate changeset directories: %w", err)
	}

	beforeRef, err := ch.Before.Self().Snapshot.GetOrEval(ctx, ch.Before.Result)
	if err != nil {
		return nil, err
	}

	afterRef, err := ch.After.Self().Snapshot.GetOrEval(ctx, ch.After.Result)
	if err != nil {
		return nil, err
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}

	newRef, err := query.SnapshotManager().New(ctx, nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription("Changeset.asPatch"))
	if err != nil {
		return nil, err
	}
	beforeSelector, err := ch.Before.Self().Dir.GetOrEval(ctx, ch.Before.Result)
	if err != nil {
		return nil, err
	}
	afterSelector, err := ch.After.Self().Dir.GetOrEval(ctx, ch.After.Result)
	if err != nil {
		return nil, err
	}

	// Determine the changed paths so we only diff things that actually changed,
	// rather than the entire tree
	paths, err := ch.ComputePaths(ctx)
	if err != nil {
		return nil, fmt.Errorf("compute paths: %w", err)
	}
	noChanges := changesetPathsEmpty(paths)
	pathSpecs := gitDiffPathSpecs(paths)

	err = MountRef(ctx, beforeRef, func(before string, _ *mount.Mount) error {
		beforeDir, err := containerdfs.RootPath(before, beforeSelector)
		if err != nil {
			return err
		}
		return MountRef(ctx, afterRef, func(after string, _ *mount.Mount) error {
			afterDir, err := containerdfs.RootPath(after, afterSelector)
			if err != nil {
				return err
			}
			return MountRef(ctx, newRef, func(root string, _ *mount.Mount) (rerr error) {
				beforeMount := filepath.Join(root, "a")
				afterMount := filepath.Join(root, "b")
				if err := os.Mkdir(beforeMount, 0o755); err != nil {
					return err
				}
				defer os.RemoveAll(beforeMount)
				if err := os.Mkdir(afterMount, 0o755); err != nil {
					return err
				}
				defer os.RemoveAll(afterMount)
				if err := syscall.Mount(beforeDir, beforeMount, "", syscall.MS_BIND, ""); err != nil {
					return fmt.Errorf("mount before to ./a/: %w", err)
				}
				defer syscall.Unmount(beforeMount, syscall.MNT_DETACH)
				if err := syscall.Mount(afterDir, afterMount, "", syscall.MS_BIND, ""); err != nil {
					return fmt.Errorf("mount after to ./b/: %w", err)
				}
				defer syscall.Unmount(afterMount, syscall.MNT_DETACH)

				patchFile, err := os.Create(filepath.Join(root, ChangesetPatchFilename))
				if err != nil {
					return err
				}
				defer patchFile.Close()

				if noChanges {
					// No paths actually changed (no-op Changeset) - just return early rather than
					// computing an expensive no-op diff.
					return nil
				}

				return enginetel.Task(ctx, "git diff", func(ctx context.Context) error {
					stdio := telemetry.SpanStdio(ctx, InstrumentationLibrary, log.Bool(telemetry.LogsVerboseAttr, true))
					defer stdio.Close()
					// The patch file gets everything; the span's logs only
					// get a bounded prefix, since the whole patch would
					// otherwise stream to the client as log records before
					// the caller has even asked for the file.
					logged := &truncatingWriter{w: stdio.Stdout, limit: maxPatchTelemetryBytes}
					err := writeGitDiffPatch(ctx, root, pathSpecs,
						io.MultiWriter(patchFile, logged), stdio.Stdout, stdio.Stderr)
					if dropped := logged.Dropped(); dropped > 0 {
						if !logged.atLineStart() {
							fmt.Fprintln(stdio.Stdout)
						}
						fmt.Fprintf(stdio.Stdout, "[... %d bytes truncated; read Changeset.asPatch for the full patch]\n", dropped)
					}
					return err
				})
			})
		}, mountRefAsReadOnly)
	}, mountRefAsReadOnly)
	if err != nil {
		return nil, err
	}
	snap, err := newRef.Commit(ctx)
	if err != nil {
		return nil, err
	}
	file := &File{
		Platform: query.Platform(),
		File:     new(LazyAccessor[string, *File]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
	}
	file.SetPath(ChangesetPatchFilename)
	file.SetSnapshot(snap)
	return file, nil
}

// writeGitDiffPatch runs `git diff` between the a/ and b/ mount dirs beneath
// root and writes the resulting unified diff to out, normalizing the
// `diff --git` header lines along the way (see diffGitHeaderRewriter).
//
// logOut/logErr receive the command's own diagnostics, never the patch data.
func writeGitDiffPatch(ctx context.Context, root string, pathSpecs []string, out, logOut, logErr io.Writer) error {
	// --no-renames: with --no-prefix, git strips the a/ b/ mount dirs
	// from the ---/+++ lines but not from rename from/to lines, so a
	// rename entry makes the patch unapplyable ("inconsistent old
	// filename"). Emitting renames as delete+add avoids the mismatch;
	// with --binary the result is identical.
	args := []string{"diff", "--binary", "--no-prefix", "--no-renames", "--no-index", "a", "b"}
	if len(pathSpecs) > 0 {
		// -- so a path starting with - isn't parsed as a flag, and
		// GIT_LITERAL_PATHSPECS below so one starting with : isn't
		// parsed as pathspec magic. Either would otherwise fail the
		// diff or silently drop the path from the patch.
		args = append(args, "--")
		args = append(args, pathSpecs...)
	}
	// Pathspecs can name an entire repository; log their count, not an
	// unbounded argv that floods the same telemetry as the patch would.
	fmt.Fprintf(logOut, "running git diff (%d pathspecs)\n", len(pathSpecs))

	rewriter := &diffGitHeaderRewriter{w: out}
	cmd := exec.CommandContext(ctx, "git", args...)
	cmd.Dir = root
	cmd.Env = append(os.Environ(), "GIT_LITERAL_PATHSPECS=1")
	cmd.Stdout = rewriter
	cmd.Stderr = logErr
	finish := enginetel.PrepareCommandNetwork(ctx, cmd)
	defer finish()
	runErr := cmd.Run()
	if flushErr := rewriter.Flush(); flushErr != nil && runErr == nil {
		return flushErr
	}
	if runErr != nil {
		var exitErr *exec.ExitError
		// Exit code 1 just means the trees differ, which is the
		// whole point; returning it would end the span in error
		// for every patch that isn't empty.
		if errors.As(runErr, &exitErr) && exitErr.ExitCode() == 1 {
			return nil
		}
		// NB: we could technically populate an ExecError here, but that
		// feels like it leaks implementation details; "exit status 128" isn't
		// exactly clear
		return fmt.Errorf("failed to generate patch: %w", runErr)
	}
	return nil
}

// diffGitHeaderRewriter is an io.Writer that passes a unified diff through
// unchanged apart from its `diff --git` header lines, which it rewrites via
// fixDiffGitHeader. Data is buffered until a newline, so callers must Flush
// once the source is exhausted.
type diffGitHeaderRewriter struct {
	w   io.Writer
	buf []byte
}

func (r *diffGitHeaderRewriter) Write(p []byte) (int, error) {
	r.buf = append(r.buf, p...)
	for {
		i := bytes.IndexByte(r.buf, '\n')
		if i < 0 {
			return len(p), nil
		}
		line := string(r.buf[:i])
		r.buf = r.buf[i+1:]
		if _, err := io.WriteString(r.w, fixDiffGitHeader(line)+"\n"); err != nil {
			return 0, err
		}
	}
}

// Flush writes any trailing data not terminated by a newline.
func (r *diffGitHeaderRewriter) Flush() error {
	if len(r.buf) == 0 {
		return nil
	}
	line := string(r.buf)
	r.buf = nil
	_, err := io.WriteString(r.w, fixDiffGitHeader(line))
	return err
}

// maxPatchTelemetryBytes bounds how much of a patch AsPatch copies into its
// span's logs. The copy exists so the patch can be read in the trace, not to
// carry it: diffing two unrelated trees produces patches in the hundreds of
// megabytes, every byte of which would otherwise stream to the client as log
// records before the caller has even read the file.
const maxPatchTelemetryBytes = 256 << 10

// truncatingWriter forwards at most limit bytes to w and discards the rest,
// counting what it dropped so the caller can say so afterwards. Every write
// reports full success (short of w erroring), so the writer can sit inside an
// io.MultiWriter without cutting off its siblings once the budget is spent.
type truncatingWriter struct {
	w       io.Writer
	limit   int64
	written int64
	dropped int64
	last    byte
}

func (t *truncatingWriter) Write(p []byte) (int, error) {
	n := len(p)
	remaining := t.limit - t.written
	if remaining <= 0 {
		t.dropped += int64(n)
		return n, nil
	}
	if int64(n) > remaining {
		t.dropped += int64(n) - remaining
		p = p[:remaining]
	}
	if len(p) == 0 {
		return n, nil
	}
	if _, err := t.w.Write(p); err != nil {
		return 0, err
	}
	t.written += int64(len(p))
	t.last = p[len(p)-1]
	return n, nil
}

// Dropped returns how many bytes were discarded beyond the limit.
func (t *truncatingWriter) Dropped() int64 {
	return t.dropped
}

// atLineStart reports whether the next forwarded byte would begin a new line,
// i.e. nothing has been forwarded yet or the last forwarded byte was a newline.
func (t *truncatingWriter) atLineStart() bool {
	return t.written == 0 || t.last == '\n'
}

// fixDiffGitHeader normalizes the path prefixes on a `diff --git` header line.
//
// AsPatch diffs two bind mounts literally named a/ and b/ with --no-prefix, so
// the header line carries whichever mount dir the file exists in on both
// sides: an added file yields "diff --git b/f b/f" and a deleted one
// "diff --git a/f a/f". Real git always writes "diff --git a/<path> b/<path>"
// regardless of the change kind (only the ---/+++ lines use /dev/null), and
// `git apply` — plus anything else consuming these patches — expects that, so
// rewrite the prefixes to a/ and b/.
//
// Lines that aren't headers, or that don't parse as a header, are returned
// unchanged. Diff payload lines can never be mistaken for a header: text hunk
// lines always start with ' ', '+', '-' or '\', and --binary payload lines are
// base85, which has no space or '-'.
func fixDiffGitHeader(line string) string {
	const marker = "diff --git "
	rest, ok := strings.CutPrefix(line, marker)
	if !ok {
		return line
	}
	// The two paths only differ in their leading mount dir (--no-renames means
	// git never emits a rename header here), so they have equal length and the
	// separating space sits exactly in the middle. Splitting there — rather
	// than on the first space — keeps paths containing spaces intact.
	var left, right string
	if mid := len(rest) / 2; len(rest)%2 == 1 && rest[mid] == ' ' {
		left, right = rest[:mid], rest[mid+1:]
	} else if fields := strings.Split(rest, " "); len(fields) == 2 {
		left, right = fields[0], fields[1]
	} else {
		return line
	}
	newLeft, leftOK := retagDiffPath(left, 'a')
	newRight, rightOK := retagDiffPath(right, 'b')
	if !leftOK || !rightOK {
		return line
	}
	return marker + newLeft + " " + newRight
}

// retagDiffPath replaces the leading a/ or b/ prefix of a path as it appears on
// a `diff --git` line with the given tag, accounting for git's C-style quoting
// of paths with unusual characters. It reports false if the path doesn't have
// such a prefix, in which case the caller leaves the line alone.
func retagDiffPath(p string, tag byte) (string, bool) {
	i := 0
	if strings.HasPrefix(p, `"`) {
		i = 1
	}
	if len(p) < i+2 || (p[i] != 'a' && p[i] != 'b') || p[i+1] != '/' {
		return "", false
	}
	return p[:i] + string(tag) + p[i+1:], true
}

func (ch *Changeset) Export(ctx context.Context, destPath string) (rerr error) {
	paths, err := ch.ComputePaths(ctx)
	if err != nil {
		return fmt.Errorf("compute paths: %w", err)
	}

	// Snapshot diffs include metadata-only changes that ComputePaths excludes.
	// Export exactly the declared paths from After, including empty directories,
	// so an unchanged file cannot overwrite independent edits at the destination.
	exportedPaths := make(map[string]struct{})
	for _, p := range slices.Concat(paths.Added, paths.Modified) {
		for p = path.Clean(p); p != "." && p != "/"; p = path.Dir(p) {
			exportedPaths[p] = struct{}{}
		}
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	bk, err := query.Engine(ctx)
	if err != nil {
		return fmt.Errorf("failed to get engine client: %w", err)
	}

	ctx, span := Tracer(ctx).Start(ctx, fmt.Sprintf("export changeset to host %s", destPath))
	defer telemetry.EndWithCause(span, &rerr)

	dirSnapshot, err := ch.After.Self().Snapshot.GetOrEval(ctx, ch.After.Result)
	if err != nil {
		return fmt.Errorf("failed to evaluate changeset after snapshot: %w", err)
	}
	dirSelector, err := ch.After.Self().Dir.GetOrEval(ctx, ch.After.Result)
	if err != nil {
		return fmt.Errorf("failed to evaluate changeset after selector: %w", err)
	}

	return MountRef(ctx, dirSnapshot, func(root string, _ *mount.Mount) error {
		root, err = containerdfs.RootPath(root, dirSelector)
		if err != nil {
			return err
		}
		outputFS, err := fsutil.NewFS(root)
		if err != nil {
			return err
		}
		outputFS, err = fsutil.NewFilterFS(outputFS, &fsutil.FilterOpt{
			Map: func(p string, stat *fsutiltypes.Stat) fsutil.MapResult {
				// These are literal paths, not glob patterns. Keeping a parent
				// directory does not implicitly include its unchanged children.
				if _, ok := exportedPaths[filepath.ToSlash(p)]; ok {
					return fsutil.MapResultKeep
				}
				if os.FileMode(stat.Mode).IsDir() {
					return fsutil.MapResultSkipDir
				}
				return fsutil.MapResultExclude
			},
		})
		if err != nil {
			return err
		}
		return bk.LocalFSExport(ctx, outputFS, destPath, true, paths.Removed)
	}, mountRefAsReadOnly)
}

type ChangeType int

const (
	ChangeTypeAdded ChangeType = iota
	ChangeTypeModified
	ChangeTypeRemoved
)

type Conflict struct {
	Path  string
	Self  ChangeType
	Other ChangeType
	Err   error
}

var (
	ErrAddedTwice      = errors.New("path added in both changesets")
	ErrModifiedTwice   = errors.New("path modified in both changesets")
	ErrModifiedRemoved = errors.New("path modified in one changeset and removed in the other")
)

type Conflicts []Conflict

func (conflicts Conflicts) Error() (err error) {
	for _, c := range conflicts {
		err = errors.Join(err, fmt.Errorf("conflict between changesets at path %q: %w", c.Path, c.Err))
	}
	return err
}

func (conflicts Conflicts) IsEmpty() bool {
	return len(conflicts) == 0
}

func (conflicts Conflicts) ModifyDeletePaths() []string {
	var paths []string
	for _, c := range conflicts {
		if errors.Is(c.Err, ErrModifiedRemoved) {
			paths = append(paths, c.Path)
		}
	}
	return paths
}

// CheckConflicts detects conflicts using pre-computed path sets for O(1) lookups
func (ch *ChangesetPaths) CheckConflicts(other *ChangesetPaths) Conflicts {
	otherSets := other.pathSets()
	return ch.checkConflictsWithSets(otherSets)
}

func (ch *ChangesetPaths) checkConflictsWithSets(otherSets changesetPathSets) Conflicts {
	var conflicts Conflicts
	for _, addedPath := range ch.Added {
		// A directory present in both changesets is not a conflict: git's
		// 3-way merge unions directories, so disjoint files under a common
		// new directory merge cleanly. Only a file added in both sides is a
		// real conflict. Directories carry a trailing slash (see
		// listSubdirectories); skip them here.
		if strings.HasSuffix(addedPath, "/") {
			continue
		}
		if _, exists := otherSets.added[addedPath]; exists {
			conflicts = append(conflicts, Conflict{
				Path:  addedPath,
				Self:  ChangeTypeAdded,
				Other: ChangeTypeAdded,
				Err:   ErrAddedTwice,
			})
		}
	}
	for _, modifiedPath := range ch.Modified {
		if _, exists := otherSets.modified[modifiedPath]; exists {
			conflicts = append(conflicts, Conflict{
				Path:  modifiedPath,
				Self:  ChangeTypeModified,
				Other: ChangeTypeModified,
				Err:   ErrModifiedTwice,
			})
			continue
		}
		if _, exists := otherSets.removed[modifiedPath]; exists {
			conflicts = append(conflicts, Conflict{
				Path:  modifiedPath,
				Self:  ChangeTypeModified,
				Other: ChangeTypeRemoved,
				Err:   ErrModifiedRemoved,
			})
		}
	}
	for _, removedPath := range ch.Removed {
		if _, exists := otherSets.modified[removedPath]; exists {
			conflicts = append(conflicts, Conflict{
				Path:  removedPath,
				Self:  ChangeTypeRemoved,
				Other: ChangeTypeModified,
				Err:   ErrModifiedRemoved,
			})
		}
	}
	return conflicts
}

type WithChangesetMergeConflict int

const (
	// FailEarlyOnConflict fails before attempting merge if file-level conflicts are detected.
	FailEarlyOnConflict WithChangesetMergeConflict = iota
	// FailOnConflict attempts the merge and fails if git merge fails due to conflicts.
	FailOnConflict
	// LeaveConflictMarkers lets git create conflict markers in files. For modify/delete
	// conflicts, keeps the modified version. Fails on binary conflicts.
	LeaveConflictMarkers
	// PreferOursOnConflict uses -X ours strategy and resolves modify/delete by preferring ours.
	PreferOursOnConflict
	// PreferTheirsOnConflict uses -X theirs strategy and resolves modify/delete by preferring theirs.
	PreferTheirsOnConflict
)

// WithChangesetsMergeConflict specifies how to handle conflicts when merging multiple changesets
// using git's octopus merge strategy. Only FAIL_EARLY and FAIL are supported (no -X ours/theirs).
type WithChangesetsMergeConflict int

const (
	// FailEarlyOnConflicts fails before attempting merge if file-level conflicts are detected.
	FailEarlyOnConflicts WithChangesetsMergeConflict = iota
	// FailOnConflicts attempts the merge and fails if git merge fails due to conflicts.
	FailOnConflicts
)

// ChangesetMergeConflict is the API enum behind Changeset.withChangeset's
// onConflict argument. It lives in core, next to PatchConflict, so core code
// that merges through the withChangeset field (rather than the raw Go method,
// which would return a detached result) can name a strategy.
type ChangesetMergeConflict string

var ChangesetMergeConflictEnum = dagql.NewEnum[ChangesetMergeConflict]()

var (
	FailEarlyOnMergeConflict = ChangesetMergeConflictEnum.RegisterView("FAIL_EARLY",
		// starting with engine version 0.15.0 Go codegen only exposes scoped enum values
		// like ChangesetMergeConflictFailEarly and doesn't expose anymore unscopped enum values (FailEarly)
		// unscopped enum values will conflict as the same value is defined twice in ChangesetMergeConflictEnum and
		// ChangesetsMergeConflictEnum.
		// Ensure those enum values are only exposed on engines >= 0.15.0
		// Values are removed on this enum ChangesetMergeConflictEnum and not ChangesetsMergeConflictEnum so that
		// there's never an empty enum, that causes troubles with other SDKs like python
		AfterVersion("v0.15.0"),
		`Fail before attempting merge if file-level conflicts are detected`)
	FailOnMergeConflict = ChangesetMergeConflictEnum.RegisterView("FAIL",
		AfterVersion("v0.15.0"),
		`Attempt the merge and fail if git merge fails due to conflicts`)
	LeaveConflictMarkersOnMergeConflict = ChangesetMergeConflictEnum.Register("LEAVE_CONFLICT_MARKERS",
		`Let git create conflict markers in files. For modify/delete conflicts, keeps the modified version. Fails on binary conflicts.`)
	PreferOursOnMergeConflict = ChangesetMergeConflictEnum.Register("PREFER_OURS",
		`The conflict is resolved by applying the version of the calling changeset`)
	PreferTheirsOnMergeConflict = ChangesetMergeConflictEnum.Register("PREFER_THEIRS",
		`The conflict is resolved by applying the version of the other changeset`)
)

func (proto ChangesetMergeConflict) Type() *ast.Type {
	return &ast.Type{
		NamedType: "ChangesetMergeConflict",
		NonNull:   true,
	}
}

func (proto ChangesetMergeConflict) TypeDescription() string {
	return "Strategy to use when merging changesets with conflicting changes."
}

func (proto ChangesetMergeConflict) Decoder() dagql.InputDecoder {
	return ChangesetMergeConflictEnum
}

func (proto ChangesetMergeConflict) ToLiteral() call.Literal {
	return ChangesetMergeConflictEnum.Literal(proto)
}

// MergeWithChangeset produces the merged directory using git-based 3-way merge.
// The onConflictStrategy determines how conflicts are handled:
//   - FailEarlyOnConflict: fail before merge if file-level conflicts are detected
//   - FailOnConflict: attempt merge, fail if git merge fails
//   - LeaveConflictMarkers: let git create conflict markers, keep modified for modify/delete
//   - PreferOursOnConflict: use -X ours strategy
//   - PreferTheirsOnConflict: use -X theirs strategy
func (ch *Changeset) MergeWithChangeset(
	ctx context.Context,
	other *Changeset,
	onConflictStrategy WithChangesetMergeConflict,
) (_ *Directory, rerr error) {
	ctx, span := Tracer(ctx).Start(ctx, "git changeset merge", telemetry.Internal())
	defer telemetry.EndWithCause(span, &rerr)
	phases := newMergePhases(span, "git.merge")
	var ourPaths, theirPaths *ChangesetPaths
	if err := phases.run(ctx, "paths_ours", func(ctx context.Context) (err error) {
		ourPaths, err = ch.ComputePaths(ctx)
		return err
	}); err != nil {
		return nil, fmt.Errorf("compute our paths: %w", err)
	}
	if err := phases.run(ctx, "paths_theirs", func(ctx context.Context) (err error) {
		theirPaths, err = other.ComputePaths(ctx)
		return err
	}); err != nil {
		return nil, fmt.Errorf("compute their paths: %w", err)
	}

	conflicts := ourPaths.CheckConflicts(theirPaths)

	if !conflicts.IsEmpty() && onConflictStrategy == FailEarlyOnConflict {
		return nil, conflicts.Error()
	}

	before, err := MergeBeforeDirectories(ctx, ch, other)
	if err != nil {
		return nil, err
	}

	var ourContent, theirContent *changesetContent
	if err := phases.run(ctx, "content_ours", func(ctx context.Context) (err error) {
		ourContent, err = ch.content(ctx)
		return err
	}); err != nil {
		return nil, fmt.Errorf("materialize our changes: %w", err)
	}
	if err := phases.run(ctx, "content_theirs", func(ctx context.Context) (err error) {
		theirContent, err = other.content(ctx)
		return err
	}); err != nil {
		return nil, fmt.Errorf("materialize their changes: %w", err)
	}

	afterDir, err := gitMergeChangesets(ctx,
		before,
		ourContent, theirContent,
		conflicts,
		onConflictStrategy,
		phases,
	)
	if err != nil {
		return nil, err
	}

	return afterDir, nil
}

// maxParallelChangesets bounds how many changesets are worked on at once.
// Each job mounts both of a changeset's snapshots and walks them, so this is
// I/O bound work holding real resources for its duration, not something to fan
// out one goroutine per changeset over.
const maxParallelChangesets = 8

// changesetJobs returns a job pool for per-changeset work, capped so that a
// merge of many changesets doesn't mount all of them at once.
func changesetJobs() parallel.Jobs {
	return parallel.New().
		WithContextualTracer(true).
		WithInternal(true).
		WithLimit(maxParallelChangesets)
}

// FilterNonemptyChangesets keeps the effective merge inputs in their original
// order, retaining the result handles used to record the Directory operation.
func FilterNonemptyChangesets(ctx context.Context, others []dagql.ObjectResult[*Changeset]) ([]dagql.ObjectResult[*Changeset], error) {
	// Before wasting any effort, remove any changesets that are empty.
	//
	// This asks ComputePaths rather than IsEmpty: every surviving changeset
	// needs its paths computed anyway and ComputePaths memoizes, whereas
	// IsEmpty would mount and walk both trees all over again for each one. It
	// also counts directory-only changes, which IsEmpty deliberately ignores
	// the way `git diff --quiet` does.
	keep := make([]bool, len(others))
	jobs := changesetJobs()
	for i, other := range others {
		jobs = jobs.WithJob(fmt.Sprintf("changeset %d paths", i), func(ctx context.Context) error {
			paths, err := other.Self().ComputePaths(ctx)
			if err != nil {
				return fmt.Errorf("compute paths for changeset %d: %w", i, err)
			}
			keep[i] = !changesetPathsEmpty(paths)
			return nil
		})
	}
	if err := jobs.Run(ctx); err != nil {
		return nil, err
	}
	filtered := make([]dagql.ObjectResult[*Changeset], 0, len(others))
	for i, other := range others {
		if keep[i] {
			filtered = append(filtered, other)
		}
	}
	return filtered, nil
}

// MergeWithChangesets produces the merged directory using git's octopus merge
// strategy. Its caller has already filtered empty changesets before recording
// the Directory-producing call.
func (ch *Changeset) MergeWithChangesets(
	ctx context.Context,
	others []*Changeset,
	onConflictStrategy WithChangesetsMergeConflict,
) (*Directory, error) {
	if len(others) < 2 {
		return nil, fmt.Errorf("multi-changeset merge requires at least two changesets")
	}

	err := enginetel.Task(ctx, "checking pairwise conflicts", func(ctx context.Context) error {
		return checkAllPairwiseConflicts(ctx, ch, others)
	})
	if err != nil && onConflictStrategy == FailEarlyOnConflicts {
		return nil, err
	}

	before, err := enginetel.TaskRet(ctx, "merging before directories", func(ctx context.Context) (dagql.ObjectResult[*Directory], error) {
		return MergeBeforeDirectories(ctx, ch, others...)
	})
	if err != nil {
		return nil, err
	}

	// Each diff is an independent snapshot-diff materialization, so take them
	// all at once.
	var ourContent *changesetContent
	otherContents := make([]*changesetContent, len(others))
	contentJobs := changesetJobs().WithJob("self changes", func(ctx context.Context) error {
		content, err := ch.content(ctx)
		if err != nil {
			return fmt.Errorf("materialize our changes: %w", err)
		}
		ourContent = content
		return nil
	})
	for i, other := range others {
		contentJobs = contentJobs.WithJob(fmt.Sprintf("changeset %d changes", i), func(ctx context.Context) error {
			content, err := other.content(ctx)
			if err != nil {
				return fmt.Errorf("materialize changes for changeset %d: %w", i, err)
			}
			otherContents[i] = content
			return nil
		})
	}
	if err := contentJobs.Run(ctx); err != nil {
		return nil, err
	}

	afterDir, err := enginetel.TaskRet(ctx, "octopus merge", func(ctx context.Context) (*Directory, error) {
		return gitOctopusMergeChangesets(ctx, before, ourContent, otherContents)
	})
	if err != nil {
		return nil, err
	}

	return afterDir, nil
}

// MergeBeforeDirectories merges the "before" directories from all changesets,
// excluding .git since the merge process creates its own temporary .git directory.
func MergeBeforeDirectories(ctx context.Context, ch *Changeset, others ...*Changeset) (dagql.ObjectResult[*Directory], error) {
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return dagql.ObjectResult[*Directory]{}, err
	}

	selectors := []dagql.Selector{
		{Field: "directory"},
	}
	// Changesets merged together are normally diffs taken against a common
	// base, so their before directories are usually the same directory
	// repeated. Merging a directory onto itself is a no-op, but each merge
	// still walks the whole tree, so folding in N identical copies costs N
	// full-tree copies to produce what the first one already produced.
	//
	// Only consecutive repeats are collapsed. Dropping every repeat would
	// reorder a sequence like A, B, A, where the trailing A is what decides
	// paths that A and B disagree on.
	// haveLast rather than comparing against the zero digest: an empty digest
	// would otherwise read as a repeat of nothing and drop the first before
	// directory, silently changing the merge base.
	var lastDigest digest.Digest
	var haveLast bool
	appendBefore := func(before dagql.ObjectResult[*Directory]) error {
		return enginetel.Task(ctx, "append before", func(ctx context.Context) error {
			dgst, err := before.ContentPreferredDigest(ctx)
			if err != nil {
				return fmt.Errorf("before content-preferred digest: %w", err)
			}
			if haveLast && dgst == lastDigest {
				return nil
			}
			id, err := before.ID()
			if err != nil {
				return fmt.Errorf("before ID: %w", err)
			}
			lastDigest, haveLast = dgst, true
			selectors = append(selectors, withDirectorySelector(id))
			return nil
		})
	}

	if err := appendBefore(ch.Before); err != nil {
		return dagql.ObjectResult[*Directory]{}, err
	}
	for _, other := range others {
		if err := appendBefore(other.Before); err != nil {
			return dagql.ObjectResult[*Directory]{}, err
		}
	}

	selectors = append(selectors, dagql.Selector{
		Field: "withoutDirectory",
		Args: []dagql.NamedInput{
			{Name: "path", Value: dagql.NewString(".git")},
		},
	})

	var before dagql.ObjectResult[*Directory]
	if err := srv.Select(ctx, srv.Root(), &before, selectors...); err != nil {
		return dagql.ObjectResult[*Directory]{}, fmt.Errorf("merge before directories: %w", err)
	}
	return before, nil
}

func withDirectorySelector(dirID *call.ID) dagql.Selector {
	return dagql.Selector{
		Field: "withDirectory",
		Args: []dagql.NamedInput{
			{Name: "path", Value: dagql.NewString("")},
			{Name: "source", Value: dagql.NewID[*Directory](dirID)},
		},
	}
}

func checkAllPairwiseConflicts(ctx context.Context, ch *Changeset, others []*Changeset) error {
	ourPaths, err := ch.ComputePaths(ctx)
	if err != nil {
		return fmt.Errorf("compute our paths: %w", err)
	}

	otherPaths := make([]*ChangesetPaths, len(others))
	jobs := changesetJobs()
	for i, other := range others {
		jobs = jobs.WithJob(fmt.Sprintf("changeset %d paths", i), func(ctx context.Context) error {
			paths, err := other.ComputePaths(ctx)
			if err != nil {
				return fmt.Errorf("compute paths for changeset %d: %w", i, err)
			}
			otherPaths[i] = paths
			return nil
		})
	}
	if err := jobs.Run(ctx); err != nil {
		return err
	}

	for i, paths := range otherPaths {
		conflicts := ourPaths.CheckConflicts(paths)
		if !conflicts.IsEmpty() {
			return fmt.Errorf("conflict with changeset %d: %w", i, conflicts.Error())
		}
	}

	for i := 0; i < len(otherPaths); i++ {
		for j := i + 1; j < len(otherPaths); j++ {
			conflicts := otherPaths[i].CheckConflicts(otherPaths[j])
			if !conflicts.IsEmpty() {
				return fmt.Errorf("conflict between changesets %d and %d: %w", i, j, conflicts.Error())
			}
		}
	}

	return nil
}

// changesetContent is a changeset reduced to its file-level content: a diff
// directory holding its added and modified files, plus the computed paths
// describing removals and empty added directories. Unlike a patch, this
// content can be applied onto any base — content the base already contains
// overlays as a no-op instead of double-applying or failing a hunk.
type changesetContent struct {
	// diff is the materialized Before.diff(After) directory — the same
	// content Directory.WithChanges and Changeset.Export apply. Zero when the
	// changeset adds and modifies nothing.
	diff  dagql.ObjectResult[*Directory]
	paths *ChangesetPaths
	// localDiff, set only by tests, is a plain directory holding the diff
	// content in place of a materialized diff snapshot.
	localDiff string
}

// withDiff mounts the changeset's materialized diff read-only and hands fn its
// directory and mount (nil for localDiff). It does not call fn when the
// changeset adds and modifies nothing.
func (content *changesetContent) withDiff(ctx context.Context, fn func(dir string, mnt *mount.Mount) error) error {
	if content.localDiff != "" {
		return fn(content.localDiff, nil)
	}
	if content.diff.Self() == nil {
		return nil
	}
	diffRef, err := content.diff.Self().Snapshot.GetOrEval(ctx, content.diff.Result)
	if err != nil {
		return fmt.Errorf("diff snapshot: %w", err)
	}
	diffPath, err := content.diff.Self().Dir.GetOrEval(ctx, content.diff.Result)
	if err != nil {
		return fmt.Errorf("diff path: %w", err)
	}
	if diffPath == "" {
		diffPath = "/"
	}
	if diffRef == nil {
		return nil
	}
	return MountRef(ctx, diffRef, func(srcRoot string, srcMnt *mount.Mount) error {
		dir, err := containerdfs.RootPath(srcRoot, diffPath)
		if err != nil {
			return err
		}
		return fn(dir, srcMnt)
	}, mountRefAsReadOnly)
}

// hasDiff reports whether the changeset materialized diff content.
func (content *changesetContent) hasDiff() bool {
	return content.localDiff != "" || content.diff.Self() != nil
}

// content reduces the changeset to its file-level content, independent of its
// before directory.
func (ch *Changeset) content(ctx context.Context) (*changesetContent, error) {
	paths, err := ch.ComputePaths(ctx)
	if err != nil {
		return nil, fmt.Errorf("compute paths: %w", err)
	}
	content := &changesetContent{paths: paths}
	if len(paths.Added) == 0 && len(paths.Modified) == 0 {
		// Nothing to overlay; removals are carried by paths alone.
		return content, nil
	}

	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, err
	}
	afterID, err := ch.After.ID()
	if err != nil {
		return nil, fmt.Errorf("after ID: %w", err)
	}
	var diffDir dagql.ObjectResult[*Directory]
	if err := srv.Select(ctx, ch.Before, &diffDir,
		dagql.Selector{
			Field: "diff",
			Args: []dagql.NamedInput{
				{Name: "other", Value: dagql.NewID[*Directory](afterID)},
			},
		},
	); err != nil {
		return nil, fmt.Errorf("compute changes diff directory: %w", err)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, diffDir); err != nil {
		return nil, fmt.Errorf("evaluate changes diff directory: %w", err)
	}
	content.diff = diffDir
	return content, nil
}

// gitMetaPath reports whether p is the workspace-root .git directory or a
// path inside it. The merge workspace's temporary repository lives at that
// path, so changeset content must never be applied there;
// mergeBeforeDirectories excludes the same path from the merge base. Stat-only
// snapshot differences can plant such entries in a changeset's materialized
// diff without ComputePaths ever reporting them, and applying a stale
// .git/HEAD mid-merge silently redirects branch commits.
func gitMetaPath(p string) bool {
	p = strings.TrimPrefix(path.Clean(p), "/")
	return p == ".git" || strings.HasPrefix(p, ".git/")
}

// withoutGitMeta returns a copy of ch with all entries under the
// workspace-root .git directory removed.
func (ch *ChangesetPaths) withoutGitMeta() *ChangesetPaths {
	dropGitMeta := func(paths []string) []string {
		return slices.DeleteFunc(slices.Clone(paths), gitMetaPath)
	}
	filtered := &ChangesetPaths{
		Added:      dropGitMeta(ch.Added),
		Modified:   dropGitMeta(ch.Modified),
		Removed:    dropGitMeta(ch.Removed),
		AllRemoved: dropGitMeta(ch.AllRemoved),
	}
	if ch.Renamed != nil {
		filtered.Renamed = make(map[string]string, len(ch.Renamed))
		for newPath, oldPath := range ch.Renamed {
			if gitMetaPath(newPath) || gitMetaPath(oldPath) {
				continue
			}
			filtered.Renamed[newPath] = oldPath
		}
	}
	return filtered
}

// gitMergeWorkspace is a mounted scratch copy of the merge base that git
// branches are built in.
type gitMergeWorkspace struct {
	root    string       // mounted snapshot root
	dir     string       // base directory selector within root
	workDir string       // absolute path of dir under root; where git runs
	mount   *mount.Mount // the snapshot's mount, when mounted from a ref
}

// applyContent applies a changeset's file-level content to the work tree:
// removed paths are deleted, the diff directory is overlaid, and empty added
// directories are recreated (the diff snapshot does not carry them). This
// mirrors Directory.WithChanges' application of the same content.
func (ws *gitMergeWorkspace) applyContent(ctx context.Context, content *changesetContent) error {
	// Never let changeset content reach the temporary repository's .git.
	paths := content.paths.withoutGitMeta()

	if err := removeChangesetPaths(ws.root, ws.dir, paths.Removed); err != nil {
		return fmt.Errorf("remove paths: %w", err)
	}

	// The copier must write through the mounted view, not the snapshot's
	// upperdir: git runs inside the mount and has to see every file this
	// writes, and modifying an overlay's layers behind a live mount leaves
	// the view incoherent (git add sees names it cannot stat). So no Mount is
	// passed here, unlike Directory.WithChanges, which never reads back
	// through the mount before committing.
	copier, err := layercopy.NewCopier(layercopy.Mount{Root: ws.root})
	if err != nil {
		return err
	}
	defer copier.Close()

	copyOpts := layercopy.CopyOptions{
		CopyDirContents: true,
		ReplaceExisting: true,
		// Linking from the diff snapshot into the mounted
		// work tree crosses devices, so every attempt would
		// just fail into the copy fallback.
		DisableSourceHardlinks: true,
		// The diff snapshot can carry .git entries that
		// ComputePaths never reported: the stat-sensitive
		// differ flags files whose content is identical but
		// whose timestamps diverge across content-deduped
		// snapshots. Overlaying those onto the temporary
		// repository corrupts the merge.
		Filter: layercopy.Filter{
			Exclude: []string{".git"},
		},
	}
	if content.localDiff != "" {
		if err := copier.Copy(ctx, layercopy.Mount{Root: content.localDiff}, "/", ws.dir, copyOpts); err != nil {
			return fmt.Errorf("copy changed paths: %w", err)
		}
	} else if content.diff.Self() != nil {
		diffRef, err := content.diff.Self().Snapshot.GetOrEval(ctx, content.diff.Result)
		if err != nil {
			return fmt.Errorf("diff snapshot: %w", err)
		}
		diffPath, err := content.diff.Self().Dir.GetOrEval(ctx, content.diff.Result)
		if err != nil {
			return fmt.Errorf("diff path: %w", err)
		}
		if diffPath == "" {
			diffPath = "/"
		}
		if diffRef != nil {
			err = MountRef(ctx, diffRef, func(srcRoot string, srcMnt *mount.Mount) error {
				return copier.Copy(ctx,
					layercopy.Mount{Root: srcRoot, Mount: srcMnt},
					diffPath,
					ws.dir,
					copyOpts,
				)
			}, mountRefAsReadOnly)
			if err != nil {
				return fmt.Errorf("copy changed paths: %w", err)
			}
		}
	}

	if err := mkdirChangesetAddedDirs(ctx, copier, ws.dir, paths); err != nil {
		return err
	}
	return ws.touchAppliedPaths(paths)
}

// touchAppliedPaths bumps the mtime of every path the changeset wrote so git
// can see the change. Snapshot contents carry normalized timestamps and the
// copier preserves them, so a same-size edit can leave a file's mtime and
// size both identical to the index entry; with core.checkStat=minimal (see
// gitEphemeralConfig) git add would then skip re-hashing it and silently
// drop the change from the branch commit.
func (ws *gitMergeWorkspace) touchAppliedPaths(paths *ChangesetPaths) error {
	for _, p := range slices.Concat(paths.Added, paths.Modified) {
		if strings.HasSuffix(p, "/") {
			// Directories are untracked by git; only file stat data matters.
			continue
		}
		full, err := RootPathWithoutFinalSymlink(ws.root, path.Join(ws.dir, p))
		if err != nil {
			return err
		}
		err = unix.UtimesNanoAt(unix.AT_FDCWD, full, nil, unix.AT_SYMLINK_NOFOLLOW)
		if err != nil && !errors.Is(err, unix.ENOENT) {
			return fmt.Errorf("touch %s: %w", p, err)
		}
	}
	return nil
}

type mergeDir struct {
	path string
	info os.FileInfo
}

func (ws *gitMergeWorkspace) listDirs() ([]mergeDir, error) {
	var dirs []mergeDir
	err := filepath.WalkDir(ws.workDir, func(p string, entry fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if !entry.IsDir() || p == ws.workDir {
			return nil
		}
		rel, err := filepath.Rel(ws.workDir, p)
		if err != nil {
			return err
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		dirs = append(dirs, mergeDir{path: filepath.ToSlash(rel), info: info})
		return nil
	})
	if err != nil {
		return nil, TrimErrPathPrefix(err, ws.root)
	}
	return dirs, nil
}

// restorePrunedDirs recreates the merge base directories that git removed
// along with their last file and that no changeset removes. Otherwise the
// merged changeset reports them as removed, and exporting it deletes the whole
// directory on the host. A host workspace's changeset holds only the touched
// files and their parent directories, so removing one file empties every
// parent up to the workspace root.
func (ws *gitMergeWorkspace) restorePrunedDirs(baseDirs []mergeDir, contents ...*changesetContent) error {
	removed := make(map[string]struct{})
	for _, content := range contents {
		for _, p := range content.paths.AllRemoved {
			if dir, ok := strings.CutSuffix(p, "/"); ok {
				removed[dir] = struct{}{}
			}
		}
	}
	for _, dir := range baseDirs {
		if _, ok := removed[dir.path]; ok {
			continue
		}
		full, err := RootPathWithoutFinalSymlink(ws.root, path.Join(ws.dir, dir.path))
		if err != nil {
			return err
		}
		if _, err := os.Lstat(full); !errors.Is(err, os.ErrNotExist) {
			if err != nil {
				return TrimErrPathPrefix(err, ws.root)
			}
			continue
		}
		stat := dir.info.Sys().(*syscall.Stat_t)
		if err := os.Mkdir(full, 0o700); err != nil {
			return TrimErrPathPrefix(err, ws.root)
		}
		if err := os.Chmod(full, dir.info.Mode()); err != nil {
			return TrimErrPathPrefix(err, ws.root)
		}
		if err := os.Lchown(full, int(stat.Uid), int(stat.Gid)); err != nil {
			return TrimErrPathPrefix(err, ws.root)
		}
	}
	return nil
}

// verifyMergedPaths confirms that every file-level path the given changesets
// declared as added or modified exists in the merged worktree. A conflict-free
// merge has no legitimate way to drop one; a missing path means the temporary
// repository lost applied content (a lost path here once meant a stale
// .git/HEAD from a changeset diff had redirected the ours commit onto the
// wrong branch, letting the merge silently resolve to one side).
func (ws *gitMergeWorkspace) verifyMergedPaths(contents ...*changesetContent) error {
	var missing []string
	for _, content := range contents {
		if content == nil {
			continue
		}
		paths := content.paths.withoutGitMeta()
		for _, p := range slices.Concat(paths.Added, paths.Modified) {
			if strings.HasSuffix(p, "/") {
				continue
			}
			full, err := RootPathWithoutFinalSymlink(ws.root, path.Join(ws.dir, p))
			if err != nil {
				return err
			}
			if _, err := os.Lstat(full); errors.Is(err, os.ErrNotExist) {
				missing = append(missing, p)
			} else if err != nil {
				return TrimErrPathPrefix(err, ws.root)
			}
		}
	}
	if len(missing) > 0 {
		return fmt.Errorf("merge dropped declared changes: %s (engine bug: the merge workspace lost applied content)", strings.Join(missing, ", "))
	}
	return nil
}

// withGitMergeWorkspace sets up a workspace for git merge operations, runs the provided
// function, then commits and returns the resulting directory.
func withGitMergeWorkspace(ctx context.Context, base dagql.ObjectResult[*Directory], description string, fn func(ws *gitMergeWorkspace) error) (*Directory, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, base); err != nil {
		return nil, fmt.Errorf("evaluate base: %w", err)
	}

	baseRef, err := base.Self().Snapshot.GetOrEval(ctx, base.Result)
	if err != nil {
		return nil, fmt.Errorf("evaluate base: %w", err)
	}
	baseSelector, err := base.Self().Dir.GetOrEval(ctx, base.Result)
	if err != nil {
		return nil, fmt.Errorf("evaluate base selector: %w", err)
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}

	newRef, err := query.SnapshotManager().New(ctx, baseRef,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription(description))
	if err != nil {
		return nil, err
	}
	defer newRef.Release(context.WithoutCancel(ctx))

	err = MountRef(ctx, newRef, func(root string, m *mount.Mount) error {
		workDir, err := containerdfs.RootPath(root, baseSelector)
		if err != nil {
			return err
		}
		return fn(&gitMergeWorkspace{
			root:    root,
			dir:     baseSelector,
			workDir: workDir,
			mount:   m,
		})
	})
	if err != nil {
		return nil, err
	}

	snap, err := newRef.Commit(ctx)
	if err != nil {
		return nil, err
	}
	dir := &Directory{
		Platform: query.Platform(),
		Services: slices.Clone(base.Self().Services),
		Dir:      new(LazyAccessor[string, *Directory]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
	}
	dir.SetPath(baseSelector)
	dir.SetSnapshot(snap)
	return dir, nil
}

// gitMergeChangesets merges two changesets' content on base in a temporary
// repository. Its merge base must be a commit of the whole base tree: git's
// directory rename detection decides from every path in a directory whether
// the directory moved, so a base of only the touched paths would change the
// result. Writing an object for every file of a large base dominates the merge,
// though, so it first tries a scoped base (see initScopedGitRepo): the same
// tree, with objects only where either changeset can write. Any failure of that
// attempt, other than the merge's own conflict, redoes the merge with the full
// `git add -A` base on a fresh copy of base.
func gitMergeChangesets(
	ctx context.Context,
	base dagql.ObjectResult[*Directory],
	ours, theirs *changesetContent,
	conflicts Conflicts,
	strategy WithChangesetMergeConflict,
	phases *mergePhases,
) (*Directory, error) {
	const description = "Changeset.withChangeset git merge"
	// workspace times evaluating, snapshotting and mounting base; commit
	// times committing the result's snapshot.
	run := func(ctx context.Context, scope *gitMergeScope, prefix string) (*Directory, error) {
		start := phaseNow()
		var end phaseMark
		dir, err := withGitMergeWorkspace(ctx, base, description, func(ws *gitMergeWorkspace) error {
			defer func() { end = phaseNow() }()
			phases.record(ctx, prefix+"workspace", start)
			return ws.mergeChangesets(ctx, scope, ours, theirs, conflicts, strategy, phases)
		})
		if err == nil {
			phases.record(ctx, prefix+"commit", end)
		}
		return dir, err
	}
	dir, err := func() (_ *Directory, rerr error) {
		ctx, span := Tracer(ctx).Start(ctx, "scoped git merge base", telemetry.Internal())
		defer func() {
			fallback := rerr != nil && ctx.Err() == nil && !errors.As(rerr, new(gitMergeConflictError))
			if fallback {
				span.SetAttributes(attribute.String("dagger.git.scoped_merge.fallback_reason", rerr.Error()))
				recordFallbackMarker(ctx, "git.merge.scoped_fallback", rerr)
				rerr = errScopedMergeFallback
			}
			span.SetAttributes(attribute.Bool("dagger.git.scoped_merge.supported", !fallback))
			if fallback {
				span.End() // A fallback is not this merge's failure.
			} else {
				telemetry.EndWithCause(span, &rerr)
			}
		}()
		var scope *gitMergeScope
		if err := phases.run(ctx, "scope", func(ctx context.Context) (err error) {
			scope, err = newGitMergeScope(ctx, ours, theirs)
			return err
		}); err != nil {
			return nil, err
		}
		return run(ctx, scope, "")
	}()
	if !errors.Is(err, errScopedMergeFallback) {
		return dir, err
	}
	return run(ctx, nil, "full_")
}

// errScopedMergeFallback asks gitMergeChangesets to redo a merge whose scoped
// base attempt failed with the full base.
var errScopedMergeFallback = errors.New("scoped merge base fallback")

// gitMergeConflictError is a conflict reported by git merge itself, the
// merge's answer for FAIL: a full merge base, with the identical tree, would
// reach the same one.
type gitMergeConflictError struct{ err error }

func (e gitMergeConflictError) Error() string { return e.err.Error() }
func (e gitMergeConflictError) Unwrap() error { return e.err }

// mergeChangesets runs the merge in ws. A nil scope builds the full base with
// `git add -A`; otherwise the scoped base, and then every failure other than
// the merge's own conflict is returned for the caller to retry in full.
func (ws *gitMergeWorkspace) mergeChangesets(ctx context.Context, scope *gitMergeScope, ours, theirs *changesetContent, conflicts Conflicts, strategy WithChangesetMergeConflict, phases *mergePhases) error {
	scoped := scope != nil
	prefix := ""
	if !scoped {
		prefix = "full_"
	}
	var baseDirs []mergeDir
	if err := phases.run(ctx, prefix+"base_dirs", func(context.Context) (err error) {
		baseDirs, err = ws.listDirs()
		return err
	}); err != nil {
		return err
	}
	// Each phase runs its git commands under its own profile op, so a
	// profile breaks a slow phase down by command (git.<verb>).
	if err := phases.run(ctx, prefix+"init", func(ctx context.Context) error {
		if scoped {
			return initScopedGitRepo(ctx, ws.workDir, scope)
		}
		return initGitRepo(ctx, ws.workDir)
	}); err != nil {
		return err
	}
	if err := phases.run(ctx, prefix+"branch_ours", func(ctx context.Context) error {
		return createBranchWithContent(ctx, ws, "ours", ours, scoped)
	}); err != nil {
		return err
	}
	if err := phases.run(ctx, prefix+"branch_theirs", func(ctx context.Context) error {
		return createBranchWithContent(ctx, ws, "theirs", theirs, scoped, "HEAD~1")
	}); err != nil {
		return err
	}
	return phases.run(ctx, prefix+"merge", func(ctx context.Context) error {
		return ws.mergeBranches(ctx, scoped, baseDirs, ours, theirs, conflicts, strategy)
	})
}

// mergeBranches merges the theirs branch into ours, in the worktree, and
// restores the baseDirs git pruned.
func (ws *gitMergeWorkspace) mergeBranches(ctx context.Context, scoped bool, baseDirs []mergeDir, ours, theirs *changesetContent, conflicts Conflicts, strategy WithChangesetMergeConflict) error {
	if err := runGit(ctx, ws.workDir, "checkout", "ours"); err != nil {
		return err
	}

	mergeArgs := []string{"merge", "--no-edit", "--no-commit"}
	switch strategy {
	case PreferOursOnConflict:
		mergeArgs = append(mergeArgs, "-X", "ours")
	case PreferTheirsOnConflict:
		mergeArgs = append(mergeArgs, "-X", "theirs")
	}
	mergeArgs = append(mergeArgs, "theirs")

	mergeOut, mergeErr := runGitCombined(ctx, ws.workDir, mergeArgs...)
	if scoped {
		// Only a plain conflict (exit 1) is the merge's answer. Anything else,
		// or any sign of a missing object even in a conflict or a success,
		// may be the scoped base's doing: fail, for the full-base retry. The
		// non-FAIL strategies below would otherwise ignore such a failure.
		if gitMissingObjectOutput(mergeOut) {
			return fmt.Errorf("git merge read a missing object: %s", mergeOut)
		}
		var exit *exec.ExitError
		if mergeErr != nil && (!errors.As(mergeErr, &exit) || exit.ExitCode() != 1 || !strings.Contains(mergeOut, "CONFLICT")) {
			return mergeErr
		}
	}

	switch strategy {
	case FailOnConflict:
		if mergeErr != nil {
			return gitMergeConflictError{mergeErr}
		}
	case LeaveConflictMarkers, PreferOursOnConflict, PreferTheirsOnConflict:
		modifyDeleteConflicts := conflicts.ModifyDeletePaths()
		if len(modifyDeleteConflicts) > 0 {
			if err := resolveModifyDeleteConflicts(ctx, ws.workDir, modifyDeleteConflicts, strategy, ours.paths.AllRemoved, theirs.paths.AllRemoved); err != nil {
				return err
			}
		}
	default:
		if mergeErr != nil {
			return gitMergeConflictError{mergeErr}
		}
	}

	if err := ws.restorePrunedDirs(baseDirs, ours, theirs); err != nil {
		return err
	}

	if mergeErr == nil && conflicts.IsEmpty() {
		if err := ws.verifyMergedPaths(ours, theirs); err != nil {
			return err
		}
	}

	if err := os.RemoveAll(filepath.Join(ws.workDir, ".git")); err != nil {
		return fmt.Errorf("remove temporary merge git repository: %w", err)
	}
	return nil
}

func gitOctopusMergeChangesets(
	ctx context.Context,
	base dagql.ObjectResult[*Directory],
	ourContent *changesetContent,
	otherContents []*changesetContent,
) (*Directory, error) {
	return withGitMergeWorkspace(ctx, base, "Changeset.withChangesets git octopus merge", func(ws *gitMergeWorkspace) error {
		baseDirs, err := ws.listDirs()
		if err != nil {
			return err
		}
		if err := enginetel.Task(ctx, "init git", func(ctx context.Context) error {
			return initGitRepo(ctx, ws.workDir)
		}); err != nil {
			return err
		}
		if err := enginetel.Task(ctx, "create branch for ours", func(ctx context.Context) error {
			return createBranchWithContent(ctx, ws, "ours", ourContent, false)
		}); err != nil {
			return err
		}

		branchNames := make([]string, len(otherContents))
		for i, content := range otherContents {
			branchName := fmt.Sprintf("branch_%d", i)
			branchNames[i] = branchName
			if err := enginetel.Task(ctx, "create branch "+branchName, func(ctx context.Context) error {
				return createBranchWithContent(ctx, ws, branchName, content, false, "HEAD~1")
			}); err != nil {
				return err
			}
		}

		if err := enginetel.Task(ctx, "checkout ours", func(ctx context.Context) error {
			return runGit(ctx, ws.workDir, "checkout", "ours")
		}); err != nil {
			return err
		}

		mergeArgs := []string{"merge", "--no-edit", "--no-commit"}
		mergeArgs = append(mergeArgs, branchNames...)

		if err := enginetel.Task(ctx, "git merge", func(ctx context.Context) error {
			return runGit(ctx, ws.workDir, mergeArgs...)
		}); err != nil {
			return err
		}

		contents := append([]*changesetContent{ourContent}, otherContents...)
		if err := ws.restorePrunedDirs(baseDirs, contents...); err != nil {
			return err
		}

		// An octopus merge refuses to run with conflicts, so on success every
		// declared path must have survived.
		if err := ws.verifyMergedPaths(contents...); err != nil {
			return err
		}

		if err := os.RemoveAll(filepath.Join(ws.workDir, ".git")); err != nil {
			return fmt.Errorf("remove temporary octopus merge git repository: %w", err)
		}
		return nil
	})
}

var gitEphemeralConfig = []string{
	// These repositories are disposable. Detached maintenance can outlive the
	// git command and race with the immediate .git cleanup below.
	"-c", "maintenance.auto=false",
	"-c", "maintenance.autoDetach=false",
	"-c", "gc.auto=0",
	"-c", "gc.autoDetach=false",
	// Snapshots share file contents via hardlinks, so a file's ctime, inode
	// and device can all change out from under us (e.g. when a concurrent
	// snapshot hardlinks the same inode) without the content changing.
	//
	// Left alone, git sees these as stat-dirty entries, and `git merge`'s
	// internal `git stash create` fails with a bewildering "fatal: stash
	// failed".
	//
	// 'minimal' compares only mtime + size, which is all we can trust here.
	"-c", "core.checkStat=minimal",
	"-c", "core.trustctime=false",
}

func gitCmd(ctx context.Context, dir string, args ...string) *exec.Cmd {
	gitArgs := make([]string, 0, len(gitEphemeralConfig)+len(args))
	gitArgs = append(gitArgs, gitEphemeralConfig...)
	gitArgs = append(gitArgs, args...)

	cmd := exec.CommandContext(ctx, "git", gitArgs...)
	cmd.Dir = dir
	cmd.Env = []string{
		"GIT_CONFIG_NOSYSTEM=1",
		"HOME=/dev/null",
		"GIT_AUTHOR_NAME=Dagger",
		"GIT_AUTHOR_EMAIL=dagger@localhost",
		"GIT_COMMITTER_NAME=Dagger",
		"GIT_COMMITTER_EMAIL=dagger@localhost",
	}
	return cmd
}

// gitThrowawayConfig applies to the merge repositories runGit drives, whose
// .git is deleted once the merge has landed in the worktree. Compressing
// their objects is wasted work, and initGitRepo writes one for every file of
// the base: storing them raw halves its cost on a large tree.
var gitThrowawayConfig = []string{
	"-c", "core.compression=0",
	"-c", "core.looseCompression=0",
}

func runGit(ctx context.Context, dir string, args ...string) (rerr error) {
	ctx, op := beginGitProfileOp(ctx, args)
	defer func() { op.EndErr(rerr) }()
	cmd := gitCmd(ctx, dir, slices.Concat(gitThrowawayConfig, args)...)
	finish := enginetel.PrepareCommandNetwork(ctx, cmd)
	defer finish()
	if output, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("git %v: %w: %s", args, err, output)
	}
	return nil
}

// beginGitProfileOp starts a profile op for one merge git command, e.g.
// git.add, under the caller's phase.
func beginGitProfileOp(ctx context.Context, args []string) (context.Context, *wcprof.Op) {
	verb := "command"
	for i := 0; i < len(args); i++ {
		if args[i] == "-c" {
			i++
			continue
		}
		verb = args[i]
		break
	}
	return wcprof.BeginOp(ctx, wcprof.OpKindIO, "git."+verb, wcprof.OpOpts{})
}

// runGitOutput runs git and returns its stdout.
func runGitOutput(ctx context.Context, dir string, args ...string) (_ string, rerr error) {
	ctx, op := beginGitProfileOp(ctx, args)
	defer func() { op.EndErr(rerr) }()
	cmd := gitCmd(ctx, dir, slices.Concat(gitThrowawayConfig, args)...)
	finish := enginetel.PrepareCommandNetwork(ctx, cmd)
	defer finish()
	var stderr strings.Builder
	cmd.Stderr = &stderr
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("git %v: %w: %s", args, err, stderr.String())
	}
	return string(out), nil
}

// runGitCombined runs git and returns its combined output, even on failure.
func runGitCombined(ctx context.Context, dir string, args ...string) (_ string, rerr error) {
	ctx, op := beginGitProfileOp(ctx, args)
	defer func() { op.EndErr(rerr) }()
	cmd := gitCmd(ctx, dir, slices.Concat(gitThrowawayConfig, args)...)
	finish := enginetel.PrepareCommandNetwork(ctx, cmd)
	defer finish()
	output, err := cmd.CombinedOutput()
	if err != nil {
		return string(output), fmt.Errorf("git %v: %w: %s", args, err, output)
	}
	return string(output), nil
}

// runGitInput runs git with stdin.
func runGitInput(ctx context.Context, dir string, stdin []byte, args ...string) (rerr error) {
	ctx, op := beginGitProfileOp(ctx, args)
	defer func() { op.EndErr(rerr) }()
	cmd := gitCmd(ctx, dir, slices.Concat(gitThrowawayConfig, args)...)
	cmd.Stdin = bytes.NewReader(stdin)
	finish := enginetel.PrepareCommandNetwork(ctx, cmd)
	defer finish()
	if output, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("git %v: %w: %s", args, err, output)
	}
	return nil
}

// gitMissingObjectOutput reports git messages about objects it could not
// read. A scoped merge base omits objects on purpose; git must never need one.
// "invalid object ... for '<path>'" is deliberately not one of them: it is the
// best-effort cache-tree refresh after a checkout or merge declining to record
// a directory whose blobs are absent, which changes nothing but the index's
// tree cache.
func gitMissingObjectOutput(out string) bool {
	for _, msg := range []string{"unable to read", "cannot read object", "bad object", "missing blob", "missing object", "not a valid object", "fatal:"} {
		if strings.Contains(out, msg) {
			return true
		}
	}
	return false
}

func initGitRepo(ctx context.Context, dir string) error {
	if err := runGit(ctx, dir, "init"); err != nil {
		return err
	}
	if err := runGit(ctx, dir, "add", "-A"); err != nil {
		return err
	}
	return runGit(ctx, dir, "commit", "--allow-empty", "-m", "base")
}

// gitMergeScope is every path a two-way changeset merge can make git read or
// write. A merge only ever touches paths where the trees of its base and two
// branches differ, and each branch only differs from the base where its
// changeset wrote: the paths ComputePaths declares, and every entry of its
// materialized diff, which applyContent overlays wholesale, including
// metadata-only rewrites ComputePaths leaves out. Git also reads attribute,
// ignore and submodule control files from the index when checking out.
type gitMergeScope struct {
	// exact paths (no trailing slash).
	exact map[string]bool
	// dirs whose whole base subtree is in scope: removed or added
	// directories, and paths a file replaced.
	dirs map[string]bool
}

// newGitMergeScope reads both changesets' declared paths and diff entries.
func newGitMergeScope(ctx context.Context, contents ...*changesetContent) (*gitMergeScope, error) {
	scope := &gitMergeScope{exact: map[string]bool{}, dirs: map[string]bool{}}
	for _, content := range contents {
		paths := content.paths.withoutGitMeta()
		for _, p := range slices.Concat(paths.Added, paths.Modified, paths.Removed, paths.AllRemoved) {
			clean := strings.TrimSuffix(path.Clean("/"+p), "/")
			clean = strings.TrimPrefix(clean, "/")
			if clean == "" {
				// The whole tree: nothing to save.
				return nil, fmt.Errorf("changeset touches the root directory")
			}
			scope.exact[clean] = true
			if strings.HasSuffix(p, "/") {
				scope.dirs[clean] = true
			}
		}
		for newPath, oldPath := range paths.Renamed {
			scope.exact[strings.TrimSuffix(newPath, "/")] = true
			scope.exact[strings.TrimSuffix(oldPath, "/")] = true
		}
		err := content.withDiff(ctx, func(diffDir string, _ *mount.Mount) error {
			return filepath.WalkDir(diffDir, func(name string, entry fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if err := ctx.Err(); err != nil {
					return err
				}
				rel, err := filepath.Rel(diffDir, name)
				if err != nil {
					return err
				}
				if rel == "." {
					return nil
				}
				rel = filepath.ToSlash(rel)
				if gitMetaPath(rel) {
					// applyContent never copies it.
					if entry.IsDir() {
						return filepath.SkipDir
					}
					return nil
				}
				scope.exact[rel] = true
				if !entry.IsDir() {
					// A file may replace a base directory.
					scope.dirs[rel] = true
				}
				return nil
			})
		})
		if err != nil {
			return nil, fmt.Errorf("list changeset diff: %w", err)
		}
	}
	return scope, nil
}

// inScope reports whether the base entry p needs a real object.
func (scope *gitMergeScope) inScope(p string) bool {
	switch path.Base(p) {
	case ".gitattributes", ".gitignore", ".gitmodules":
		return true
	}
	if scope.exact[p] {
		return true
	}
	for dir := path.Dir(p); dir != "." && dir != "/"; dir = path.Dir(dir) {
		if scope.dirs[dir] {
			return true
		}
	}
	return false
}

// initScopedGitRepo commits exactly the tree initGitRepo would, `git add -A`
// over the whole base directory, but writes objects only for in-scope paths:
// every other file is hashed into the index alone (update-index --info-only)
// and the tree is written with --missing-ok. The file list comes from git's own
// untracked-file walk with the standard excludes, the one add -A uses, so
// ignore rules, symlinks, modes, attributes and empty directories (never
// listed) are git's own. A nested repository, which add -A records as a
// gitlink, fails here for the full-base retry. createBranchWithContent records
// branch commits the same way, since `git commit` refuses missing objects.
func initScopedGitRepo(ctx context.Context, dir string, scope *gitMergeScope) error {
	if err := runGit(ctx, dir, "init"); err != nil {
		return err
	}
	out, err := runGitOutput(ctx, dir, "ls-files", "-z", "--others", "--exclude-standard")
	if err != nil {
		return err
	}
	var real, hashed bytes.Buffer
	for _, p := range splitOnNul([]byte(out)) {
		if strings.HasSuffix(p, "/") {
			return fmt.Errorf("embedded repository %q in merge base", p)
		}
		buf := &hashed
		if scope.inScope(p) {
			buf = &real
		}
		buf.WriteString(p)
		buf.WriteByte(0)
	}
	if hashed.Len() > 0 {
		if err := runGitInput(ctx, dir, hashed.Bytes(), "update-index", "--add", "--info-only", "-z", "--stdin"); err != nil {
			return err
		}
	}
	if real.Len() > 0 {
		if err := runGitInput(ctx, dir, real.Bytes(), "update-index", "--add", "-z", "--stdin"); err != nil {
			return err
		}
	}
	return commitScopedGitIndex(ctx, dir, "base", false)
}

// commitScopedGitIndex commits the index of a scoped merge repository, whose
// out-of-scope blobs are missing, and advances HEAD's branch to it.
func commitScopedGitIndex(ctx context.Context, dir, message string, parent bool) error {
	tree, err := runGitOutput(ctx, dir, "write-tree", "--missing-ok")
	if err != nil {
		return err
	}
	args := []string{"commit-tree", strings.TrimSpace(tree), "-m", message}
	if parent {
		args = append(args, "-p", "HEAD")
	}
	commit, err := runGitOutput(ctx, dir, args...)
	if err != nil {
		return err
	}
	return runGit(ctx, dir, "update-ref", "HEAD", strings.TrimSpace(commit))
}

// createBranchWithContent creates branchName from startPoint (default: the
// current HEAD) and populates it with the changeset's file-level content.
// scoped commits a scoped merge repository's index (see initScopedGitRepo).
func createBranchWithContent(ctx context.Context, ws *gitMergeWorkspace, branchName string, content *changesetContent, scoped bool, startPoint ...string) error {
	checkoutArgs := []string{"checkout", "-b", branchName}
	if len(startPoint) > 0 {
		checkoutArgs = append(checkoutArgs, startPoint[0])
	}
	if err := runGit(ctx, ws.workDir, checkoutArgs...); err != nil {
		return err
	}
	if err := ws.applyContent(ctx, content); err != nil {
		return fmt.Errorf("apply %s changes: %w", branchName, err)
	}
	if err := runGit(ctx, ws.workDir, "add", "-A"); err != nil {
		return err
	}
	staged, err := runGitOutput(ctx, ws.workDir, "diff", "--cached", "--name-only")
	if err != nil {
		return err
	}
	// Each branch must contribute exactly one commit so HEAD~1 resolves to the
	// base, so genuinely empty branches (empty or directory-only changesets,
	// or changes the merge base already carries) still commit with
	// --allow-empty. But an empty commit where git *should* have staged
	// something silently erases the changeset from the merge, so before
	// permitting one, verify the applied content actually reached the
	// worktree.
	commitArgs := []string{"commit", "-m", branchName}
	if strings.TrimSpace(staged) == "" {
		if err := ws.verifyBranchContentLanded(ctx, content); err != nil {
			return fmt.Errorf("branch %s staged no changes: %w", branchName, err)
		}
		commitArgs = []string{"commit", "--allow-empty", "-m", branchName}
	}
	if scoped {
		return commitScopedGitIndex(ctx, ws.workDir, branchName, true)
	}
	if err := runGit(ctx, ws.workDir, commitArgs...); err != nil {
		return err
	}
	return nil
}

// verifyBranchContentLanded discriminates the legitimate reasons a branch can
// stage nothing (empty or directory-only changeset, changes the merge base
// already carries, gitignored paths) from the silent-corruption ones: applied
// content that never reached the worktree, or a stale index stat-cache making
// git skip a real edit. Both corruption modes have produced wrong merges that
// reported success (see the touchAppliedPaths comment for the stat-cache
// history), so failing here is what keeps them from escaping as merged
// results.
func (ws *gitMergeWorkspace) verifyBranchContentLanded(ctx context.Context, content *changesetContent) error {
	paths := content.paths.withoutGitMeta()

	var files []string
	for _, p := range slices.Concat(paths.Added, paths.Modified) {
		if !strings.HasSuffix(p, "/") {
			files = append(files, p)
		}
	}

	// A tracked file whose worktree bytes differ from HEAD must stage; if git
	// saw nothing, its stat cache lied about the file being clean.
	for _, p := range paths.Modified {
		if strings.HasSuffix(p, "/") {
			continue
		}
		wt, err := ws.readWorktreePath(p)
		if err != nil {
			return err
		}
		headBytes, tracked := gitBlobBytes(ctx, ws.workDir, p)
		if !tracked {
			// Untracked (e.g. gitignored in the base); the diff comparison
			// below still validates that the content landed.
			continue
		}
		if wt == nil || !bytes.Equal(wt, headBytes) {
			return fmt.Errorf("worktree content for %q differs from HEAD but git staged nothing (index stat cache failure)", p)
		}
	}

	for _, p := range paths.AllRemoved {
		if strings.HasSuffix(p, "/") {
			// A removed directory can coexist with paths the same changeset
			// re-adds beneath it; only file removals are checkable here.
			continue
		}
		full, err := RootPathWithoutFinalSymlink(ws.root, path.Join(ws.dir, p))
		if err != nil {
			return err
		}
		if _, err := os.Lstat(full); !errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("removal of %q was not applied to the merge worktree", p)
		}
	}

	if len(files) == 0 {
		return nil
	}
	if !content.hasDiff() {
		return fmt.Errorf("changeset declared file changes %v but materialized no diff content", files)
	}
	return ws.withDiffDir(ctx, content, func(diffDir string) error {
		for _, p := range files {
			same, err := ws.worktreeMatchesDiff(p, diffDir)
			if err != nil {
				return err
			}
			if !same {
				return fmt.Errorf("applied content for %q did not land in the merge worktree", p)
			}
		}
		return nil
	})
}

// readWorktreePath returns the worktree content for a changeset path: file
// bytes for regular files, the target for symlinks, nil if the path does not
// exist.
func (ws *gitMergeWorkspace) readWorktreePath(p string) ([]byte, error) {
	full, err := RootPathWithoutFinalSymlink(ws.root, path.Join(ws.dir, p))
	if err != nil {
		return nil, err
	}
	fi, err := os.Lstat(full)
	if errors.Is(err, os.ErrNotExist) {
		return nil, nil
	} else if err != nil {
		return nil, TrimErrPathPrefix(err, ws.root)
	}
	if fi.Mode()&os.ModeSymlink != 0 {
		target, err := os.Readlink(full)
		if err != nil {
			return nil, TrimErrPathPrefix(err, ws.root)
		}
		return []byte(target), nil
	}
	data, err := os.ReadFile(full)
	if err != nil {
		return nil, TrimErrPathPrefix(err, ws.root)
	}
	return data, nil
}

// worktreeMatchesDiff reports whether the worktree content for p matches the
// materialized diff's copy of it.
func (ws *gitMergeWorkspace) worktreeMatchesDiff(p, diffDir string) (bool, error) {
	wt, err := ws.readWorktreePath(p)
	if err != nil {
		return false, err
	}
	if wt == nil {
		return false, nil
	}
	full, err := RootPathWithoutFinalSymlink(diffDir, p)
	if err != nil {
		return false, err
	}
	fi, err := os.Lstat(full)
	if errors.Is(err, os.ErrNotExist) {
		// The path is declared but absent from the diff snapshot; nothing to
		// compare against, and its presence in the worktree is all that can
		// be verified.
		return true, nil
	} else if err != nil {
		return false, TrimErrPathPrefix(err, diffDir)
	}
	var want []byte
	if fi.Mode()&os.ModeSymlink != 0 {
		target, err := os.Readlink(full)
		if err != nil {
			return false, TrimErrPathPrefix(err, diffDir)
		}
		want = []byte(target)
	} else {
		want, err = os.ReadFile(full)
		if err != nil {
			return false, TrimErrPathPrefix(err, diffDir)
		}
	}
	return bytes.Equal(wt, want), nil
}

// withDiffDir mounts the changeset's materialized diff snapshot read-only and
// hands its directory to fn.
func (ws *gitMergeWorkspace) withDiffDir(ctx context.Context, content *changesetContent, fn func(diffDir string) error) error {
	if content.localDiff != "" {
		return fn(content.localDiff)
	}
	diffRef, err := content.diff.Self().Snapshot.GetOrEval(ctx, content.diff.Result)
	if err != nil {
		return fmt.Errorf("diff snapshot: %w", err)
	}
	diffPath, err := content.diff.Self().Dir.GetOrEval(ctx, content.diff.Result)
	if err != nil {
		return fmt.Errorf("diff path: %w", err)
	}
	if diffPath == "" {
		diffPath = "/"
	}
	return MountRef(ctx, diffRef, func(srcRoot string, _ *mount.Mount) error {
		dir, err := containerdfs.RootPath(srcRoot, diffPath)
		if err != nil {
			return err
		}
		return fn(dir)
	}, mountRefAsReadOnly)
}

// gitBlobBytes returns the HEAD blob for path p, or tracked=false if HEAD has
// no such blob (untracked or gitignored paths).
func gitBlobBytes(ctx context.Context, workDir, p string) (data []byte, tracked bool) {
	out, err := runGitOutput(ctx, workDir, "cat-file", "blob", "HEAD:"+p)
	if err != nil {
		return nil, false
	}
	return []byte(out), true
}

// resolveModifyDeleteConflicts handles conflicts where one side modified and the other deleted.
// For LEAVE_CONFLICT_MARKERS, keeps the modified version.
func resolveModifyDeleteConflicts(ctx context.Context, dir string, conflictFiles []string, strategy WithChangesetMergeConflict, ourRemoved, theirRemoved []string) error {
	if len(conflictFiles) == 0 {
		return nil
	}

	ourRemovedSet := toSet(ourRemoved)
	theirRemovedSet := toSet(theirRemoved)

	for _, file := range conflictFiles {
		_, ourDeleted := ourRemovedSet[file]
		_, theirDeleted := theirRemovedSet[file]

		var useOurs bool
		switch strategy {
		case PreferOursOnConflict:
			useOurs = true
		case PreferTheirsOnConflict:
			useOurs = false
		case LeaveConflictMarkers:
			useOurs = theirDeleted && !ourDeleted
		default:
			continue
		}

		deleted := (useOurs && ourDeleted) || (!useOurs && theirDeleted)
		if deleted {
			if err := runGit(ctx, dir, "rm", "--force", "--", file); err != nil {
				return fmt.Errorf("git rm %s: %w", file, err)
			}
		} else {
			side := "--ours"
			if !useOurs {
				side = "--theirs"
			}
			if err := runGit(ctx, dir, "checkout", side, "--", file); err != nil {
				return fmt.Errorf("git checkout %s %s: %w", side, file, err)
			}
		}
	}

	return runGit(ctx, dir, "add", "-A")
}

func toSet(slice []string) map[string]struct{} {
	set := make(map[string]struct{}, len(slice))
	for _, s := range slice {
		set[s] = struct{}{}
	}
	return set
}

const persistedFileLazyKindChangesetPatch = "changeset.asPatch"

// FileChangesetPatchLazy writes a changeset's Git-compatible patch.
type FileChangesetPatchLazy struct {
	LazyState
	Changeset dagql.ObjectResult[*Changeset]
}

type persistedFileChangesetPatchLazy struct {
	ChangesetResultID uint64 `json:"changesetResultID"`
}

func (lazy *FileChangesetPatchLazy) Evaluate(ctx context.Context, file *File) error {
	return evaluateFileOutput(ctx, &lazy.LazyState, "Changeset.asPatch", file, func(ctx context.Context) (*File, error) {
		return lazy.Changeset.Self().AsPatch(ctx)
	})
}

func (lazy *FileChangesetPatchLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	changeset, err := attachLazyInput(attach, lazy.Changeset, "FileChangesetPatchLazy.Changeset")
	if err != nil {
		return nil, err
	}
	lazy.Changeset = changeset
	return []dagql.AnyResult{changeset}, nil
}

func (lazy *FileChangesetPatchLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	changesetID, err := encodePersistedObjectRef(enc, lazy.Changeset, "changeset patch changeset")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedFileChangesetPatchLazy{ChangesetResultID: changesetID})
}

func decodeFileChangesetPatchLazy(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (Lazy[*File], error) {
	var persisted persistedFileChangesetPatchLazy
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted changeset patch lazy: %w", err)
	}
	changeset, err := loadPersistedObjectResultByResultID[*Changeset](ctx, dec, persisted.ChangesetResultID, "changeset patch changeset")
	if err != nil {
		return nil, err
	}
	return &FileChangesetPatchLazy{LazyState: NewLazyState(), Changeset: changeset}, nil
}

const persistedDirectoryLazyKindMergeChangesets = "changeset.merge"

// DirectoryMergeChangesetsLazy produces the directory obtained by merging
// Changes into Parent: Changeset.__mergeWithChangeset for one change,
// __mergeWithChangesets (an octopus merge) for several, and, with Workspace
// set, __mergeForWorkspaceCommit, which tries the native merge first.
type DirectoryMergeChangesetsLazy struct {
	LazyState
	Parent     dagql.ObjectResult[*Changeset]
	Changes    []dagql.ObjectResult[*Changeset]
	OnConflict ChangesetMergeConflict
	Workspace  bool
}

type persistedDirectoryMergeChangesetsLazy struct {
	ParentResultID   uint64                 `json:"parentResultID"`
	ChangesResultIDs []uint64               `json:"changesResultIDs"`
	OnConflict       ChangesetMergeConflict `json:"onConflict,omitempty"`
	Workspace        bool                   `json:"workspace,omitempty"`
}

// MergeStrategy is the strategy of a merge with one changeset.
func (proto ChangesetMergeConflict) MergeStrategy() WithChangesetMergeConflict {
	switch proto {
	case FailEarlyOnMergeConflict:
		return FailEarlyOnConflict
	case LeaveConflictMarkersOnMergeConflict:
		return LeaveConflictMarkers
	case PreferOursOnMergeConflict:
		return PreferOursOnConflict
	case PreferTheirsOnMergeConflict:
		return PreferTheirsOnConflict
	default:
		return FailOnConflict
	}
}

// OctopusMergeStrategy is the strategy of a merge with several changesets,
// which supports only FAIL_EARLY and FAIL.
func (proto ChangesetMergeConflict) OctopusMergeStrategy() WithChangesetsMergeConflict {
	if proto == FailEarlyOnMergeConflict {
		return FailEarlyOnConflicts
	}
	return FailOnConflicts
}

func (lazy *DirectoryMergeChangesetsLazy) Evaluate(ctx context.Context, dir *Directory) error {
	op := "Changeset.__mergeWithChangeset"
	switch {
	case lazy.Workspace:
		op = "Changeset.__mergeForWorkspaceCommit"
	case len(lazy.Changes) > 1:
		op = "Changeset.__mergeWithChangesets"
	}
	return evaluateDirectoryOutput(ctx, &lazy.LazyState, op, dir, func(ctx context.Context) (*Directory, error) {
		if len(lazy.Changes) == 0 {
			return nil, fmt.Errorf("merge changesets: no changes")
		}
		changes := make([]*Changeset, 0, len(lazy.Changes))
		for _, change := range lazy.Changes {
			changes = append(changes, change.Self())
		}
		parent := lazy.Parent.Self()
		switch {
		case lazy.Workspace:
			return mergeForWorkspaceCommit(ctx, lazy.Parent, lazy.Changes[0])
		case len(changes) == 1:
			return parent.MergeWithChangeset(ctx, changes[0], lazy.OnConflict.MergeStrategy())
		default:
			return parent.MergeWithChangesets(ctx, changes, lazy.OnConflict.OctopusMergeStrategy())
		}
	})
}

// mergeForWorkspaceCommit tries the native reconciliation. Unsupported inputs
// and native failures use the general merge, __mergeWithChangeset with FAIL,
// and share its output.
func mergeForWorkspaceCommit(ctx context.Context, working, incoming dagql.ObjectResult[*Changeset]) (*Directory, error) {
	if dir, supported, err := TryNativeWorkspaceMerge(ctx, working.Self(), incoming.Self()); err != nil || supported {
		return dir, err
	}
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, err
	}
	incomingID, err := incoming.ID()
	if err != nil {
		return nil, err
	}
	var merged dagql.ObjectResult[*Directory]
	if err := srv.Select(ctx, working, &merged, dagql.Selector{Field: "__mergeWithChangeset", Args: []dagql.NamedInput{
		{Name: "changes", Value: dagql.NewID[*Changeset](incomingID)},
		{Name: "onConflict", Value: FailOnMergeConflict},
	}}); err != nil {
		return nil, err
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, merged); err != nil {
		return nil, err
	}
	return cloneDetachedDirectoryForContainerResult(ctx, merged.Self())
}

func (lazy *DirectoryMergeChangesetsLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachLazyInput(attach, lazy.Parent, "DirectoryMergeChangesetsLazy.Parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	deps := []dagql.AnyResult{parent}
	for i, change := range lazy.Changes {
		attached, err := attachLazyInput(attach, change, "DirectoryMergeChangesetsLazy.Changes")
		if err != nil {
			return nil, err
		}
		lazy.Changes[i] = attached
		deps = append(deps, attached)
	}
	return deps, nil
}

func (lazy *DirectoryMergeChangesetsLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "changeset merge parent")
	if err != nil {
		return nil, err
	}
	changeIDs := make([]uint64, 0, len(lazy.Changes))
	for _, change := range lazy.Changes {
		id, err := encodePersistedObjectRef(enc, change, "changeset merge changes")
		if err != nil {
			return nil, err
		}
		changeIDs = append(changeIDs, id)
	}
	return json.Marshal(persistedDirectoryMergeChangesetsLazy{
		ParentResultID:   parentID,
		ChangesResultIDs: changeIDs,
		OnConflict:       lazy.OnConflict,
		Workspace:        lazy.Workspace,
	})
}

func decodeDirectoryMergeChangesetsLazy(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (Lazy[*Directory], error) {
	var persisted persistedDirectoryMergeChangesetsLazy
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted changeset merge lazy: %w", err)
	}
	parent, err := loadPersistedObjectResultByResultID[*Changeset](ctx, dec, persisted.ParentResultID, "changeset merge parent")
	if err != nil {
		return nil, err
	}
	changes := make([]dagql.ObjectResult[*Changeset], 0, len(persisted.ChangesResultIDs))
	for _, id := range persisted.ChangesResultIDs {
		change, err := loadPersistedObjectResultByResultID[*Changeset](ctx, dec, id, "changeset merge changes")
		if err != nil {
			return nil, err
		}
		changes = append(changes, change)
	}
	return &DirectoryMergeChangesetsLazy{
		LazyState:  NewLazyState(),
		Parent:     parent,
		Changes:    changes,
		OnConflict: persisted.OnConflict,
		Workspace:  persisted.Workspace,
	}, nil
}
