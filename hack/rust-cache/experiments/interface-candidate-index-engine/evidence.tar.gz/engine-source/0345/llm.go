package core

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"maps"
	"mime"
	"net"
	"net/http"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/anthropics/anthropic-sdk-go"
	"github.com/cenkalti/backoff/v4"
	telemetry "github.com/dagger/otel-go"
	"github.com/iancoleman/strcase"
	"github.com/vektah/gqlparser/v2/ast"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/log"
	"go.opentelemetry.io/otel/trace"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	"github.com/dagger/dagger/engine"
	enginetelemetry "github.com/dagger/dagger/engine/telemetry"
	"github.com/dagger/dagger/engine/telemetryattrs"
)

func init() {
	strcase.ConfigureAcronym("LLM", "LLM")
	// Acronyms only match a whole name, so a module type definition naming
	// these core types would otherwise normalize to "Llmcontent" /
	// "LlmcontentBlock", miss the core type, and be namespaced as a
	// module-local object. Modules return LLMContent from functions exposed
	// as LLM tools. Registering names one by one is a stopgap; see
	// dagger/dagger#13668 for the underlying acronym-handling problem.
	strcase.ConfigureAcronym("LLMContent", "LLMContent")
	strcase.ConfigureAcronym("LLMContentBlock", "LLMContentBlock")
}

const (
	modelDefaultAnthropic  = anthropic.ModelClaudeSonnet4_5
	modelDefaultGoogle     = "gemini-2.5-flash"
	modelDefaultOpenAI     = "gpt-4.1"
	modelDefaultCodex      = "gpt-5.5"
	modelDefaultOpenRouter = "anthropic/claude-sonnet-4.5"
	modelDefaultMeta       = "llama-3.2"
	modelDefaultMistral    = "mistral-7b-instruct"
)

// openRouterBaseURL is OpenRouter's OpenAI-compatible endpoint, the default
// for the openrouter provider when its configuration names none.
const openRouterBaseURL = "https://openrouter.ai/api/v1"

// codexModelPrefix pins a model to the Codex (ChatGPT subscription) backend.
// Current Codex models (gpt-5.5, gpt-5.4, …) no longer carry "codex" in their
// IDs, so the prefix — not the name — is what routes them to the Codex client.
// Route strips it back off so the model still displays and is sent to the API
// under its bare name.
const codexModelPrefix = "openai-codex/"

// normalizeCodexModel ensures a model configured for the Codex slot routes to
// the Codex client regardless of its name, by prefixing it with
// codexModelPrefix. Models that already route to Codex (a "codex"-named model
// or an already-prefixed one) are left untouched.
func normalizeCodexModel(model string) string {
	if model == "" || strings.Contains(model, "codex") || strings.HasPrefix(model, codexModelPrefix) {
		return model
	}
	return codexModelPrefix + model
}

func resolveModelAlias(maybeAlias string) string {
	switch maybeAlias {
	case "anthropic", "claude":
		return modelDefaultAnthropic
	case "google", "gemini":
		return modelDefaultGoogle
	case "openai", "gpt":
		return modelDefaultOpenAI
	case "meta", "llama":
		return modelDefaultMeta
	case "mistral":
		return modelDefaultMistral
	default:
		// not a recognized alias
		return maybeAlias
	}
}

// An instance of a LLM (large language model), with its state and tool calling environment
type LLM struct {
	// The full message history, exposed over the API as first-class content
	// blocks so that conversations can be queried and branched.
	//
	// Installed as a field with version-specific visibility in core/schema/llm.go rather than via
	// a `field:"true"` tag, since struct tag fields cannot carry a view filter.
	Messages []*LLMMessage

	// The environment accessible to the LLM, exposed over MCP
	mcp *MCP

	// model selects the model to converse with; provider, when set, selects
	// the provider explicitly instead of inferring it from the model name.
	model    string
	provider string

	// reasoningEffort, when set, overrides the provider-configured reasoning
	// effort for this conversation (see LLMEndpoint.ReasoningEffort). "none"
	// explicitly disables reasoning; empty defers to the provider config.
	reasoningEffort string

	endpoint          *LLMEndpoint
	endpointSessionID string
	endpointMtx       *sync.Mutex

	// Whether to disable the default system prompt
	disableDefaultSystemPrompt bool

	// maxSteps caps the number of steps per loop when loop() itself doesn't
	// specify a cap. Zero means no cap. Only set via the legacy
	// llm(maxAPICalls:) argument, kept for pre-v1 module views.
	maxSteps int
}

func (*LLM) TypeDescription() string {
	return "A conversation with a large language model (LLM): queue prompts, expose tools, and step the model until it completes its turn."
}

type LLMEndpoint struct {
	Model    string
	BaseURL  string
	Key      string
	Provider LLMProvider
	Client   LLMClient

	// AuthToken and IsOAuth carry subscription OAuth credentials (e.g. Claude
	// Code). When IsOAuth is set, the provider client authenticates with
	// AuthToken as a bearer token instead of Key.
	AuthToken string
	IsOAuth   bool

	// ClaudeCodeVersion overrides the Claude Code release the Anthropic OAuth
	// client identifies as (see defaultClaudeCodeVersion). Empty means the
	// built-in default.
	ClaudeCodeVersion string

	// AuthTokenSource, when set, supersedes AuthToken at request time: the
	// endpoint's HTTP client asks it for the current bearer token before
	// every provider request and overwrites the Authorization header with
	// the result. Subscription OAuth access tokens expire within the hour
	// and are rotated behind the session, so the snapshot AuthToken holds
	// goes stale in any long-running conversation. AuthToken is kept as the
	// value observed when the endpoint was routed (used for the SDK's own
	// construction-time setup and as the fallback when no source is set).
	AuthTokenSource *CredentialSource

	// ReasoningEffort is the reasoning level (e.g. "low"/"medium"/"high",
	// sourced from catwalk's per-model levels) for providers that support
	// reasoning. Each provider maps it onto its native effort parameter
	// (Anthropic output_config.effort, OpenAI/Codex reasoning.effort, Gemini
	// thinking_level). Empty or "none" disables reasoning. Models that don't
	// take an effort level natively (see ReasoningMode) may get it translated,
	// e.g. into an Anthropic thinking budget, or dropped.
	ReasoningEffort string

	// ReasoningMode is how the model takes reasoning configuration, from
	// catwalk's embedded catalog: whether it accepts effort levels, only a
	// thinking-token budget, or no reasoning at all. Providers consult it to
	// translate (or drop) ReasoningEffort for models that don't accept it
	// natively. LLMReasoningUnknown when the model isn't in the catalog.
	ReasoningMode LLMReasoningMode

	// DefaultMaxTokens and ContextWindow are the model's default output-token
	// cap and total context size, from catwalk's embedded catalog. Zero when
	// the model isn't in the catalog (e.g. local endpoints).
	DefaultMaxTokens int64
	ContextWindow    int64

	// dial overrides how the endpoint's HTTP client opens connections. Set
	// for local endpoints so traffic routes through a container-to-host
	// tunnel (forwarding through the client's session) while BaseURL keeps
	// the original host for TLS verification/SNI and the Host header.
	dial func(ctx context.Context, network, addr string) (net.Conn, error)

	// Provider-specific client construction options, carried from the
	// provider's configuration to newClient.
	azureVersion     string
	disableStreaming bool
	apiCompat        string
}

type LLMProvider string

// LLMClient interface defines the methods that each provider must implement
type LLMClient interface {
	SendQuery(ctx context.Context, history []*LLMMessage, tools []LLMTool, opts *LLMCallOpts) (*LLMResponse, error)
	IsRetryable(err error) bool
}

// LLMCallOpts carries per-call options from the LLM state to the provider.
type LLMCallOpts struct {
	// MaxTokens caps the model's output tokens for this API call, from the
	// loop(maxTokens:) / step(maxTokens:) argument. Zero means use the
	// model's default cap (LLMEndpoint.DefaultMaxTokens) or leave the choice
	// to the provider.
	MaxTokens int

	// CallDigest is this turn's LLM state digest, set on the live display spans
	// the provider creates so the TUI can branch the conversation from them.
	CallDigest string
}

// LLMResponse is the internal result returned by a provider's SendQuery.
// It carries content blocks and token usage but is not exposed in the API;
// the evaluation loop converts it into LLMMessage history entries.
type LLMResponse struct {
	Content    []*LLMContentBlock
	TokenUsage LLMTokenUsage

	// DisplaySpans are the OTel spans a provider created to stream this turn's
	// content live (thinking, text, tool-call arguments), in close order. The
	// loop ends any that CallBatch didn't already end.
	DisplaySpans []trace.Span

	// ToolCallDisplays maps a tool call's ID to the display span its arguments
	// streamed into, so CallBatch can parent the tool's execution beneath it and
	// end the span once the tool returns.
	ToolCallDisplays map[string]toolCallDisplay
}

// TextContent returns the concatenation of all text blocks.
func (r *LLMResponse) TextContent() string {
	var sb strings.Builder
	for _, b := range r.Content {
		if b.Kind == LLMContentText {
			sb.WriteString(b.Text)
		}
	}
	return sb.String()
}

// ToolCalls returns just the tool-call content blocks.
func (r *LLMResponse) ToolCalls() []*LLMContentBlock {
	var calls []*LLMContentBlock
	for _, b := range r.Content {
		if b.Kind == LLMContentToolCall {
			calls = append(calls, b)
		}
	}
	return calls
}

type LLMTokenUsage struct {
	// InputTokens is uncached input/prompt tokens. Cached input is accounted for
	// separately in CachedTokenReads/CachedTokenWrites so the buckets are
	// additive for cost and context accounting.
	InputTokens       int64 `field:"true" json:"input_tokens" doc:"Uncached input tokens sent to the model."`
	OutputTokens      int64 `field:"true" json:"output_tokens" doc:"Tokens received from the model, including text and tool calls."`
	CachedTokenReads  int64 `field:"true" json:"cached_token_reads" doc:"Input tokens served from the provider's prompt cache."`
	CachedTokenWrites int64 `field:"true" json:"cached_token_writes" doc:"Input tokens written to the provider's prompt cache."`
	// TotalTokens is the provider-reported total tokens for a single call when
	// available, otherwise the sum of the additive buckets above.
	TotalTokens int64 `field:"true" json:"total_tokens" doc:"Total tokens consumed, as reported by the provider."`
}

func (*LLMTokenUsage) TypeDescription() string {
	return "A count of tokens consumed by LLM API calls."
}

func (usage LLMTokenUsage) hasTokens() bool {
	return usage.InputTokens != 0 ||
		usage.OutputTokens != 0 ||
		usage.CachedTokenReads != 0 ||
		usage.CachedTokenWrites != 0 ||
		usage.TotalTokens != 0
}

// contextTokens returns the number of tokens represented by this usage record
// for context-window purposes. Providers should fill TotalTokens as the sum of
// uncached input, output, cache reads, and cache writes, but using the max keeps
// native provider totals that include extra categories (e.g. reasoning/tool-use
// accounting) from being truncated.
func (usage LLMTokenUsage) contextTokens() int64 {
	components := usage.InputTokens + usage.OutputTokens + usage.CachedTokenReads + usage.CachedTokenWrites
	return max(usage.TotalTokens, components)
}

func uncachedInputTokens(promptTokens, cachedTokens int64) int64 {
	if cachedTokens <= 0 {
		return promptTokens
	}
	if promptTokens >= cachedTokens {
		return promptTokens - cachedTokens
	}
	return promptTokens
}

var _ dagql.PersistedObject = (*LLMTokenUsage)(nil)
var _ dagql.PersistedObjectDecoder = (*LLMTokenUsage)(nil)

func (*LLMTokenUsage) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMTokenUsage",
		NonNull:   true,
	}
}

func (usage *LLMTokenUsage) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	_ = ctx
	_ = enc
	if usage == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted LLM token usage: nil LLM token usage")
	}
	return encodePersistedObjectPayload(usage)
}

func (*LLMTokenUsage) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	_ = ctx
	_ = dec
	var usage LLMTokenUsage
	if err := json.Unmarshal(payload, &usage); err != nil {
		return nil, fmt.Errorf("decode persisted LLM token usage payload: %w", err)
	}
	return &usage, nil
}

// LLMContentBlockKind identifies the kind of content in an LLMContentBlock.
type LLMContentBlockKind string

var LLMContentBlockKinds = dagql.NewEnum[LLMContentBlockKind]()

var (
	LLMContentText       = LLMContentBlockKinds.Register("TEXT", "Plain text content.")
	LLMContentThinking   = LLMContentBlockKinds.Register("THINKING", "Model thinking/reasoning content (e.g. Anthropic extended thinking).")
	LLMContentToolCall   = LLMContentBlockKinds.Register("TOOL_CALL", "A tool/function call from the model.")
	LLMContentToolResult = LLMContentBlockKinds.Register("TOOL_RESULT", "A tool/function result.")
	LLMContentImage      = LLMContentBlockKinds.Register("IMAGE", "An inline image.")
	LLMContentAudio      = LLMContentBlockKinds.Register("AUDIO", "Inline audio.")
	LLMContentDocument   = LLMContentBlockKinds.Register("DOCUMENT", "An inline PDF document.")
)

func (LLMContentBlockKind) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMContentBlockKind",
		NonNull:   true,
	}
}

func (t LLMContentBlockKind) TypeDescription() string {
	return "The kind of content in a message block."
}

func (t LLMContentBlockKind) Decoder() dagql.InputDecoder {
	return LLMContentBlockKinds
}

func (t LLMContentBlockKind) ToLiteral() call.Literal {
	return LLMContentBlockKinds.Literal(t)
}

// LLMContentBlock is a single piece of content within an LLMMessage.
// The Kind field determines which other fields are populated.
type LLMContentBlock struct {
	Kind LLMContentBlockKind `field:"true" json:"kind" doc:"The kind of content block, which determines the other populated fields."`

	// Text content (Kind=TEXT, THINKING, or TOOL_RESULT)
	Text string `field:"true" json:"text,omitempty" doc:"Text content (for TEXT, THINKING, or TOOL_RESULT kinds)."`

	// Tool call fields (Kind=TOOL_CALL)
	CallID    string `field:"true" json:"call_id,omitempty" doc:"The unique ID of a tool call (for TOOL_CALL or TOOL_RESULT kinds)."`
	ToolName  string `field:"true" json:"tool_name,omitempty" doc:"The name of the tool called (for TOOL_CALL kind)."`
	Arguments JSON   `field:"true" json:"arguments,omitempty" doc:"The arguments passed to the tool, JSON-encoded (for TOOL_CALL kind)."`

	// Tool result fields (Kind=TOOL_RESULT)
	// CallID is reused from above.
	Errored bool `field:"true" json:"errored,omitempty" doc:"Whether the tool call resulted in an error (for TOOL_RESULT kind)."`

	MIMEType string             `field:"true" name:"mimeType" json:"mime_type,omitempty" doc:"The media MIME type (for IMAGE, AUDIO, or DOCUMENT kinds)."`
	Data     dagql.Bytes        `field:"true" json:"data,omitempty" doc:"The media bytes (for IMAGE, AUDIO, or DOCUMENT kinds)."`
	Content  []*LLMContentBlock `field:"true" json:"content,omitempty" doc:"Ordered content returned by a tool, following any text (for TOOL_RESULT kind)."`

	// Provider-specific opaque data. Exposed so a conversation exported via
	// messages can be reconstructed losslessly with withResponse — some
	// providers (e.g. Anthropic) reject resubmitted thinking blocks without it.
	Signature string `field:"true" json:"signature,omitempty" doc:"Provider-specific opaque data (e.g. Anthropic thinking signature). Preserve it when reconstructing a conversation."`
}

func (*LLMContentBlock) TypeDescription() string {
	return "A single piece of content within an LLM message."
}

func (*LLMContentBlock) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMContentBlock",
		NonNull:   true,
	}
}

func (b *LLMContentBlock) Clone() *LLMContentBlock {
	if b == nil {
		return nil
	}
	cp := *b
	cp.Arguments = slices.Clone(b.Arguments)
	cp.Data = slices.Clone(b.Data)
	cp.Content = cloneLLMContent(b.Content)
	return &cp
}

func cloneLLMContent(blocks []*LLMContentBlock) []*LLMContentBlock {
	if blocks == nil {
		return nil
	}
	cloned := make([]*LLMContentBlock, len(blocks))
	for i, block := range blocks {
		cloned[i] = block.Clone()
	}
	return cloned
}

// MaxLLMMediaBytes bounds decoded media in one message, including tool results.
const MaxLLMMediaBytes = 20 * 1024 * 1024

// Validate checks a resolved block without interpreting provider-specific signatures.
func (b *LLMContentBlock) Validate() error {
	remaining := MaxLLMMediaBytes
	return b.validate(&remaining)
}

func (b *LLMContentBlock) validate(remaining *int) error {
	if b == nil {
		return fmt.Errorf("nil content block")
	}
	media := b.Kind == LLMContentImage || b.Kind == LLMContentAudio || b.Kind == LLMContentDocument
	if !media && (b.MIMEType != "" || len(b.Data) != 0) {
		return fmt.Errorf("%s cannot contain media data or MIME type", b.Kind)
	}
	if b.Kind != LLMContentToolResult && (len(b.Content) != 0 || b.Errored) {
		return fmt.Errorf("%s cannot contain tool result content or error state", b.Kind)
	}
	if b.Kind != LLMContentToolCall && (b.ToolName != "" || len(b.Arguments) != 0) {
		return fmt.Errorf("%s cannot contain tool call fields", b.Kind)
	}
	if b.Kind != LLMContentToolCall && b.Kind != LLMContentToolResult && b.CallID != "" {
		return fmt.Errorf("%s cannot contain a call ID", b.Kind)
	}
	switch b.Kind {
	case LLMContentText, LLMContentThinking, LLMContentToolCall:
	case LLMContentToolResult:
		for i, child := range b.Content {
			if child == nil {
				return fmt.Errorf("content %d: nil content block", i)
			}
			if child.Kind != LLMContentText && child.Kind != LLMContentImage && child.Kind != LLMContentAudio && child.Kind != LLMContentDocument {
				return fmt.Errorf("content %d: %s is not valid tool result content", i, child.Kind)
			}
			if err := child.validate(remaining); err != nil {
				return fmt.Errorf("content %d: %w", i, err)
			}
		}
	case LLMContentImage, LLMContentAudio, LLMContentDocument:
		return b.validateMedia(remaining)
	default:
		return fmt.Errorf("unknown content block kind %q", b.Kind)
	}
	return nil
}

func (b *LLMContentBlock) validateMedia(remaining *int) error {
	if b.Text != "" {
		return fmt.Errorf("%s cannot contain text", b.Kind)
	}
	if b.MIMEType == "" || len(b.Data) == 0 {
		return fmt.Errorf("%s requires MIME type and data", b.Kind)
	}
	mt, params, err := mime.ParseMediaType(b.MIMEType)
	if err != nil || len(params) != 0 || mt != b.MIMEType {
		return fmt.Errorf("invalid media MIME type %q", b.MIMEType)
	}
	if (b.Kind == LLMContentImage && !strings.HasPrefix(mt, "image/")) || (b.Kind == LLMContentAudio && !strings.HasPrefix(mt, "audio/")) || (b.Kind == LLMContentDocument && mt != "application/pdf") {
		return fmt.Errorf("MIME type %q does not match %s", mt, b.Kind)
	}
	if len(b.Data) > MaxLLMMediaBytes {
		return fmt.Errorf("media exceeds %d bytes", MaxLLMMediaBytes)
	}
	*remaining -= len(b.Data)
	if *remaining < 0 {
		return fmt.Errorf("message media exceeds %d bytes", MaxLLMMediaBytes)
	}
	return nil
}

// ValidateLLMContent validates blocks and the aggregate decoded-media budget.
func ValidateLLMContent(blocks []*LLMContentBlock) error {
	remaining := MaxLLMMediaBytes
	for i, b := range blocks {
		if err := b.validate(&remaining); err != nil {
			return fmt.Errorf("content %d: %w", i, err)
		}
	}
	return nil
}

// ContentText projects content for logs and text-only consumers, never leaking base64.
func (b *LLMContentBlock) ContentText() string {
	if b == nil {
		return ""
	}
	switch b.Kind {
	case LLMContentImage, LLMContentAudio, LLMContentDocument:
		return fmt.Sprintf("[%s: %s]", strings.ToLower(string(b.Kind)), b.MIMEType)
	case LLMContentToolResult:
		parts := []string{}
		if b.Text != "" {
			parts = append(parts, b.Text)
		}
		for _, child := range b.Content {
			parts = append(parts, child.ContentText())
		}
		return strings.Join(parts, "\n")
	default:
		return b.Text
	}
}

// LLMContentBlockInput is the input object type for creating content blocks.
type LLMContentBlockInput struct {
	Kind      LLMContentBlockKind                       `doc:"The kind of content block."`
	Text      string                                    `doc:"Text content (for TEXT, THINKING, or TOOL_RESULT kinds)." default:""`
	CallID    string                                    `doc:"The unique ID of a tool call (for TOOL_CALL or TOOL_RESULT kinds)." default:""`
	ToolName  string                                    `doc:"The name of the tool to call (for TOOL_CALL kind)." default:""`
	Arguments JSON                                      `doc:"The arguments to pass to the tool (for TOOL_CALL kind)." default:""`
	Errored   bool                                      `doc:"Whether the tool call resulted in an error (for TOOL_RESULT kind)." default:"false"`
	Signature string                                    `doc:"Provider-specific opaque data (e.g. Anthropic thinking signature)." default:""`
	MIMEType  string                                    `name:"mimeType" doc:"Media MIME type; required for inline data, inferred for a file." default:""`
	Data      dagql.Optional[dagql.Bytes]               `doc:"Media bytes. Supply exactly one of data or file for media."`
	File      dagql.Optional[FileID]                    `doc:"A media file to resolve to inline bytes."`
	Content   []dagql.InputObject[LLMContentBlockInput] `doc:"Ordered TEXT or media blocks returned by a tool." default:"[]"`
}

func (LLMContentBlockInput) TypeName() string {
	return "LLMContentBlockInput"
}

func (LLMContentBlockInput) TypeDescription() string {
	return "A content block within an LLM message."
}

// ToLLMContentBlock converts the input object to an LLMContentBlock.
func (in LLMContentBlockInput) ToLLMContentBlock() *LLMContentBlock {
	var content []*LLMContentBlock
	for _, child := range in.Content {
		content = append(content, child.Value.ToLLMContentBlock())
	}
	return &LLMContentBlock{
		Kind:      in.Kind,
		Text:      in.Text,
		CallID:    in.CallID,
		ToolName:  in.ToolName,
		Arguments: in.Arguments,
		Errored:   in.Errored,
		Signature: in.Signature,
		MIMEType:  in.MIMEType,
		Data:      in.Data.Value,
		Content:   content,
	}
}

// Resolve resolves file references recursively and validates the stored content.
func (in LLMContentBlockInput) Resolve(ctx context.Context) (*LLMContentBlock, error) {
	block := in.ToLLMContentBlock()
	if in.File.Valid {
		if len(in.Data.Value) != 0 {
			return nil, fmt.Errorf("supply exactly one of file or data")
		}
		if in.Kind != LLMContentImage && in.Kind != LLMContentAudio && in.Kind != LLMContentDocument {
			return nil, fmt.Errorf("%s cannot contain a media file", in.Kind)
		}
		media, err := LLMContentFromFile(ctx, in.File.Value, in.MIMEType)
		if err != nil {
			return nil, err
		}
		block.Data, block.MIMEType = media.Data, media.MIMEType
	}
	for i, child := range in.Content {
		resolved, err := child.Value.Resolve(ctx)
		if err != nil {
			return nil, fmt.Errorf("content %d: %w", i, err)
		}
		block.Content[i] = resolved
	}
	if err := ValidateLLMContent([]*LLMContentBlock{block}); err != nil {
		return nil, err
	}
	return block, nil
}

// LLMContentFromFile reads a media file, inferring its type from its contents.
func LLMContentFromFile(ctx context.Context, id FileID, mimeType string) (*LLMContentBlock, error) {
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, err
	}
	file, err := id.Load(ctx, srv)
	if err != nil {
		return nil, err
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, file); err != nil {
		return nil, err
	}
	data, err := file.Self().Contents(ctx, file, nil, nil)
	if err != nil {
		return nil, err
	}
	return LLMContentFromBytes(data, mimeType)
}

// LLMContentFromBytes builds a media block from raw bytes, inferring the
// media kind (and, when mimeType is empty, the MIME type) from its contents.
func LLMContentFromBytes(data []byte, mimeType string) (*LLMContentBlock, error) {
	if len(data) == 0 || len(data) > MaxLLMMediaBytes {
		return nil, fmt.Errorf("media must contain 1 to %d bytes", MaxLLMMediaBytes)
	}
	if mimeType == "" {
		mimeType = http.DetectContentType(data)
		// net/http uses the audio/wave alias, while provider APIs expect wav.
		if mimeType == "audio/wave" {
			mimeType = "audio/wav"
		}
	}
	kind := LLMContentDocument
	switch {
	case strings.HasPrefix(mimeType, "image/"):
		kind = LLMContentImage
	case strings.HasPrefix(mimeType, "audio/"):
		kind = LLMContentAudio
	case mimeType == "application/pdf":
	default:
		return nil, fmt.Errorf("unsupported media MIME type %q; expected image, audio, or PDF", mimeType)
	}
	block := &LLMContentBlock{Kind: kind, MIMEType: mimeType, Data: dagql.NewBytes(data)}
	if err := block.Validate(); err != nil {
		return nil, err
	}
	return block, nil
}

// LLMContent is an ordered run of text and media blocks built outside any
// conversation. A function exposed as an LLM tool returns it to make the
// blocks the tool result's own content (e.g. a caption and a screenshot), in
// the order they were added.
type LLMContent struct {
	Blocks []*LLMContentBlock `field:"true" json:"blocks" doc:"The ordered text and media blocks."`
}

func (*LLMContent) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMContent",
		NonNull:   true,
	}
}

func (*LLMContent) TypeDescription() string {
	return "An ordered run of text and media content for a model to read, built outside any conversation."
}

func (c *LLMContent) Clone() *LLMContent {
	if c == nil {
		return nil
	}
	return &LLMContent{Blocks: cloneLLMContent(c.Blocks)}
}

// The content is self-contained data: its media is inline bytes, so the
// persisted payload is the value itself and carries no references.
func (c *LLMContent) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	_ = ctx
	_ = enc
	if c == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted LLM content: nil LLM content")
	}
	return encodePersistedObjectPayload(c)
}

func (*LLMContent) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	_ = ctx
	_ = dec
	var content LLMContent
	if err := json.Unmarshal(payload, &content); err != nil {
		return nil, fmt.Errorf("decode persisted LLM content payload: %w", err)
	}
	if err := ValidateLLMContent(content.Blocks); err != nil {
		return nil, fmt.Errorf("decode persisted LLM content payload: %w", err)
	}
	return &content, nil
}

// WithBlock appends a block, enforcing the per-message media budget across
// the whole run so an oversized result fails where it is built rather than
// when the tool result is validated.
func (c *LLMContent) WithBlock(block *LLMContentBlock) (*LLMContent, error) {
	cp := c.Clone()
	cp.Blocks = append(cp.Blocks, block)
	if err := ValidateLLMContent(cp.Blocks); err != nil {
		return nil, err
	}
	return cp, nil
}

// LLMMessageOriginKind classifies who put a message on the conversation
// record (hack/designs/agent-messaging.md §4.1).
type LLMMessageOriginKind string

var LLMMessageOriginKinds = dagql.NewEnum[LLMMessageOriginKind]()

var (
	LLMMessageOriginUser = LLMMessageOriginKinds.Register("USER",
		"The user: a prompt submitted by a client rather than sent by an agent.")
	LLMMessageOriginAgent = LLMMessageOriginKinds.Register("AGENT",
		"Another agent: the message was sent from within that agent's turn.")
	LLMMessageOriginEvent = LLMMessageOriginKinds.Register("EVENT",
		"The engine, reporting a subscribed agent's lifecycle transition.")
)

func (kind LLMMessageOriginKind) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMMessageOriginKind",
		NonNull:   true,
	}
}

func (kind LLMMessageOriginKind) TypeDescription() string {
	return "EXPERIMENTAL: Agent APIs are likely to change.\n\n" +
		"Who put a message on the conversation record."
}

func (kind LLMMessageOriginKind) Decoder() dagql.InputDecoder {
	return LLMMessageOriginKinds
}

func (kind LLMMessageOriginKind) ToLiteral() call.Literal {
	return LLMMessageOriginKinds.Literal(kind)
}

// LLMMessageOrigin is the recorded provenance of a consumed mailbox message:
// who sent it, its short ref within the receiving agent's runtime, and the
// message it answers, if any. It is resolved at the central enqueue path
// (AgentRuntimes.Send), recorded as a withPrompt argument so the conversation
// chain itself says who said what, and rendered to the model as a
// deterministic attribution header at request-build time — never baked into
// the stored prompt text.
type LLMMessageOrigin struct {
	Kind      LLMMessageOriginKind `field:"true" name:"kind" json:"kind" doc:"Who put this message on the record." experimental:"Agent APIs are likely to change."`
	AgentName string               `field:"true" name:"agentName" json:"agent_name,omitempty" doc:"The display name of the sending agent (for AGENT origins) or the observed agent (for EVENT origins)." experimental:"Agent APIs are likely to change."`
	Ref       string               `field:"true" name:"ref" json:"ref,omitempty" doc:"The message's short ref within the receiving agent's runtime, e.g. \"#3\": the deterministic token replies name (send's replyTo) and the message lookup takes." experimental:"Agent APIs are likely to change."`
	ReplyTo   string               `field:"true" name:"replyTo" json:"reply_to,omitempty" doc:"The ref of the message this one answers, in the sender's own runtime, if any." experimental:"Agent APIs are likely to change."`
}

func (*LLMMessageOrigin) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMMessageOrigin",
		NonNull:   true,
	}
}

func (*LLMMessageOrigin) TypeDescription() string {
	return "EXPERIMENTAL: Agent APIs are likely to change.\n\n" +
		"The recorded provenance of a message that arrived through an agent mailbox."
}

func (o *LLMMessageOrigin) Clone() *LLMMessageOrigin {
	cp := *o
	return &cp
}

// AttributionHeader renders the deterministic, model-facing header for a
// non-user message. The ref is a per-runtime ordinal rather than the opaque
// message handle precisely so this render is stable across identical flows —
// replay recordings compare wire text byte for byte. Empty for USER origins:
// the user's own words carry no header.
func (o *LLMMessageOrigin) AttributionHeader() string {
	if o == nil {
		return ""
	}
	switch o.Kind {
	case LLMMessageOriginAgent:
		if o.ReplyTo != "" {
			return fmt.Sprintf("[reply from agent %q to your message %s]", o.AgentName, o.ReplyTo)
		}
		return fmt.Sprintf("[message %s from agent %q]", o.Ref, o.AgentName)
	case LLMMessageOriginEvent:
		return fmt.Sprintf("[event from agent %q]", o.AgentName)
	default:
		if o.ReplyTo != "" {
			return fmt.Sprintf("[reply to your message %s]", o.ReplyTo)
		}
		return ""
	}
}

// LLMMessageOriginInput is the input-object form of LLMMessageOrigin, for the
// withPrompt selector the agent loop records when draining its mailbox.
type LLMMessageOriginInput struct {
	Kind      LLMMessageOriginKind `doc:"Who put this message on the record." experimental:"Agent APIs are likely to change."`
	AgentName string               `name:"agentName" doc:"The display name of the sending or observed agent." default:"" experimental:"Agent APIs are likely to change."`
	Ref       string               `doc:"The message's short ref within the receiving agent's runtime, e.g. \"#3\"." default:"" experimental:"Agent APIs are likely to change."`
	ReplyTo   string               `name:"replyTo" doc:"The ref of the message this one answers, if any." default:"" experimental:"Agent APIs are likely to change."`
}

func (LLMMessageOriginInput) TypeName() string {
	return "LLMMessageOriginInput"
}

func (LLMMessageOriginInput) TypeDescription() string {
	return "EXPERIMENTAL: Agent APIs are likely to change.\n\n" +
		"The provenance of a message delivered through an agent mailbox."
}

// ToLLMMessageOrigin converts the input object to an LLMMessageOrigin.
func (in LLMMessageOriginInput) ToLLMMessageOrigin() *LLMMessageOrigin {
	return &LLMMessageOrigin{
		Kind:      in.Kind,
		AgentName: in.AgentName,
		Ref:       in.Ref,
		ReplyTo:   in.ReplyTo,
	}
}

// originInput builds the withPrompt origin argument for a recorded origin,
// via the decoder (a bare InputObject struct literal leaves its internals nil
// and panics when the selector is serialized to a call literal — see
// responseSelectorFromBlocks).
func originInput(origin *LLMMessageOrigin) (dagql.InputObject[LLMMessageOriginInput], error) {
	var zero dagql.InputObject[LLMMessageOriginInput]
	decoded, err := (dagql.InputObject[LLMMessageOriginInput]{}).Decoder().DecodeInput(map[string]any{
		"kind":      string(origin.Kind),
		"agentName": origin.AgentName,
		"ref":       origin.Ref,
		"replyTo":   origin.ReplyTo,
	})
	if err != nil {
		return zero, fmt.Errorf("decode message origin input: %w", err)
	}
	input, ok := decoded.(dagql.InputObject[LLMMessageOriginInput])
	if !ok {
		return zero, fmt.Errorf("decode message origin input: unexpected type %T", decoded)
	}
	return input, nil
}

// LLMMessage represents a single message in the LLM conversation history.
// Content is a list of typed content blocks, supporting multi-modal and
// multi-part messages (e.g. thinking + text + tool calls in one turn).
type LLMMessage struct {
	Role    LLMMessageRole     `field:"true" json:"role" doc:"The role that produced this message."`
	Content []*LLMContentBlock `field:"true" json:"content" doc:"The message's content blocks, in the order the model produced them."`

	// Token usage for this message (all zeros except on assistant responses).
	TokenUsage *LLMTokenUsage `field:"true" json:"token_usage,omitempty" doc:"Token usage reported by the provider for the API call that produced this message; all zeros except on assistant responses."`

	// Origin records who put this message on the record, when it arrived
	// through an agent mailbox (hack/designs/agent-messaging.md §4.1). Nil for
	// the user's own prompts and for everything the model or tools produced.
	// Exposed through an explicit nullable accessor rather than field:"true",
	// since absent is the common case.
	Origin *LLMMessageOrigin `json:"origin,omitempty"`

	// CompositionOwner identifies the module that installed a system
	// prompt. Empty means caller-owned/unowned. This is independent of mailbox
	// Origin and is never sent to a model as prompt text or attribution.
	CompositionOwner string `json:"composition_owner,omitempty"`
}

func (*LLMMessage) TypeDescription() string {
	return "A single message in an LLM conversation."
}

func (*LLMMessage) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMMessage",
		NonNull:   true,
	}
}

func (m *LLMMessage) Clone() *LLMMessage {
	cp := *m
	cp.Content = make([]*LLMContentBlock, len(m.Content))
	for i, block := range m.Content {
		cp.Content[i] = block.Clone()
	}
	if m.TokenUsage != nil {
		usage := *m.TokenUsage
		cp.TokenUsage = &usage
	}
	if m.Origin != nil {
		cp.Origin = m.Origin.Clone()
	}
	return &cp
}

// TextContent returns the concatenation of all text blocks in this message.
func (m *LLMMessage) TextContent() string {
	var sb strings.Builder
	for _, b := range m.Content {
		if b.Kind == LLMContentText {
			sb.WriteString(b.Text)
		}
	}
	return sb.String()
}

// estimateTokens returns a conservative token estimate for a message when the
// provider has not reported exact usage yet. It mirrors Pi's chars/4 fallback
// and is only used for messages after the last provider usage record (usually
// tool results queued for the next call) or before the first model call.
func (m *LLMMessage) estimateTokens() int64 {
	var chars int
	for _, b := range m.Content {
		chars += len(b.ContentText())
		chars += len(b.CallID)
		chars += len(b.ToolName)
		chars += len(b.Arguments)
	}
	return estimateTextTokens(chars)
}

// estimateTextTokens turns a character count into a conservative token estimate
// using the same chars/4 heuristic as LLMMessage.estimateTokens. It backs the
// per-tool-call result size the TUI surfaces so an inordinate result is easy to
// spot even though providers only report usage per API call, not per result.
func estimateTextTokens(chars int) int64 {
	if chars == 0 {
		return 0
	}
	return int64((chars + 3) / 4)
}

// ToolCalls returns the tool-call content blocks.
func (m *LLMMessage) ToolCalls() []*LLMContentBlock {
	var calls []*LLMContentBlock
	for _, b := range m.Content {
		if b.Kind == LLMContentToolCall {
			calls = append(calls, b)
		}
	}
	return calls
}

// IsToolResult returns true if this message is a tool result (has a TOOL_RESULT block).
func (m *LLMMessage) IsToolResult() bool {
	for _, b := range m.Content {
		if b.Kind == LLMContentToolResult {
			return true
		}
	}
	return false
}

// ToolResultContent returns a safe text projection of the first TOOL_RESULT block.
func (m *LLMMessage) ToolResultContent() string {
	for _, b := range m.Content {
		if b.Kind == LLMContentToolResult {
			return b.ContentText()
		}
	}
	return ""
}

// ToolResultCallID returns the call ID from the first TOOL_RESULT block, if any.
func (m *LLMMessage) ToolResultCallID() string {
	for _, b := range m.Content {
		if b.Kind == LLMContentToolResult {
			return b.CallID
		}
	}
	return ""
}

// ToolResultErrored returns whether the first TOOL_RESULT block is an error.
func (m *LLMMessage) ToolResultErrored() bool {
	for _, b := range m.Content {
		if b.Kind == LLMContentToolResult {
			return b.Errored
		}
	}
	return false
}

type LLMMessageRole string

var LLMMessageRoles = dagql.NewEnum[LLMMessageRole]()

var (
	LLMMessageRoleUser      = LLMMessageRoles.Register("USER", "A user prompt or tool response.")
	LLMMessageRoleAssistant = LLMMessageRoles.Register("ASSISTANT", "A reply from the model.")
	LLMMessageRoleSystem    = LLMMessageRoles.Register("SYSTEM", "A system prompt.")
)

func (LLMMessageRole) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMMessageRole",
		NonNull:   true,
	}
}

func (role LLMMessageRole) TypeDescription() string {
	return "The role that generated a message."
}

func (role LLMMessageRole) Decoder() dagql.InputDecoder {
	return LLMMessageRoles
}

func (role LLMMessageRole) ToLiteral() call.Literal {
	return LLMMessageRoles.Literal(role)
}

func (role LLMMessageRole) String() string {
	return string(role)
}

// LLMToolCall is kept as a convenience type for the MCP layer and provider
// interfaces that work with tool calls as a flat list.
type LLMToolCall struct {
	CallID    string `json:"id"`
	Name      string `json:"name"`
	Arguments JSON   `json:"arguments"`
}

const (
	OpenAI      LLMProvider = "openai"
	OpenAICodex LLMProvider = "openai-codex"
	OpenRouter  LLMProvider = "openrouter"
	Anthropic   LLMProvider = "anthropic"
	Google      LLMProvider = "google"
	Meta        LLMProvider = "meta"
	Mistral     LLMProvider = "mistral"
	DeepSeek    LLMProvider = "deepseek"
	Local       LLMProvider = "local"
	Other       LLMProvider = "other"
)

func (r *LLMRouter) getRecording(model string) ([]*LLMMessage, error) {
	model, ok := strings.CutPrefix(model, "recording-")
	if !ok {
		model, ok = strings.CutPrefix(model, "recording/")
		if !ok {
			return nil, fmt.Errorf("model %q is not a recording", model)
		}
	}

	result, err := base64.StdEncoding.DecodeString(model)
	if err != nil {
		return nil, err
	}
	return decodeRecordedMessages(result)
}

func (q *Query) NewLLM(ctx context.Context, model, provider string) (*LLM, error) {
	// The LLM starts with no workspace. Binding one is the caller's explicit
	// choice (LLM.withWorkspace), recorded as a selector on the LLM ID: the CLI
	// binds currentWorkspace at session start, agent composition seeds the base
	// from the workspace the group was rolled up from, and a module function
	// returning an LLM threads a Workspace it was handed. An unbound LLM is
	// valid — MCP.baseServer falls back to the current client's served deps —
	// so nothing here depends on the calling context's ambient workspace.
	_ = ctx
	return &LLM{
		model:       model,
		provider:    provider,
		mcp:         newMCP(),
		endpointMtx: &sync.Mutex{},
	}, nil
}

// DefaultLLMRoute resolves the configured default model and the provider it
// routes to, so llm() can re-call itself with both pinned (the way
// Container.from re-calls itself with the digested ref). provider, when
// non-empty, is the caller's explicit choice: it is returned unchanged, with
// that provider's own default model. A ("", "") result means no default is
// configured — nothing to pin.
func (q *Query) DefaultLLMRoute(ctx context.Context, provider string) (string, string, error) {
	router, err := loadLLMRouter(ctx, q)
	if err != nil {
		return "", "", err
	}
	if provider != "" {
		model := router.providerDefaultModel(LLMProvider(provider))
		if model == "" {
			return "", "", nil
		}
		return model, provider, nil
	}
	model, defaultProvider := router.DefaultRoute()
	if model == "" {
		return "", "", nil
	}
	provider = string(defaultProvider)
	if provider == "" {
		endpoint, err := router.Route(model, "")
		if err != nil {
			return "", "", err
		}
		provider = string(endpoint.Provider)
	}
	return model, provider, nil
}

// SmallModelRoute resolves this conversation's current concrete route, then
// selects that provider's configured or catalog-recommended small model. If the
// provider has neither (as with an arbitrary local or unknown provider), the
// current concrete route is returned unchanged.
func (llm *LLM) SmallModelRoute(ctx context.Context) (string, string, error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return "", "", err
	}
	router, err := loadLLMRouter(ctx, query)
	if err != nil {
		return "", "", err
	}
	current, err := router.Route(llm.model, llm.provider)
	if err != nil {
		return "", "", err
	}
	provider := current.Provider
	small, ok := router.SmallModel(provider)
	if !ok {
		return current.Model, string(provider), nil
	}
	resolved, err := router.Route(small, string(provider))
	if err != nil {
		return "", "", err
	}
	return resolved.Model, string(resolved.Provider), nil
}

func (*LLM) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLM",
		NonNull:   true,
	}
}

func (llm *LLM) Clone() *LLM {
	// Read under the lock: llm may be a persistent, shared value whose
	// endpoint another goroutine is resolving right now — a detached agent
	// loop cloning per step against the CLI's status line resolving the model
	// on the same node.
	llm.endpointMtx.Lock()
	cp := *llm
	llm.endpointMtx.Unlock()
	// The messages themselves stay shared with the receiver and any other
	// clones, so they must be treated as immutable: copy-on-write via
	// LLMMessage.Clone before modifying one.
	cp.Messages = slices.Clone(cp.Messages)
	cp.mcp = cp.mcp.Clone()
	cp.endpointMtx = &sync.Mutex{}
	return &cp
}

var _ dagql.HasDependencyResults = (*LLM)(nil)

// AttachDependencyResults declares the results the LLM value embeds outside
// its call structure: the workspace it is bound to (rebound imperatively by
// workspace-mutating tool results) and the objects bound
// as tools when a tool result rebound them mid-step (a withTools arg is
// already a structural dependency, but a rebind happens inside step execution).
// Declaring these edges lets the cache retain the embedded results and
// propagate any session-resource requirements they carry (e.g. a secret or
// socket reached through the workspace), so those requirements are not lost
// just because the dependency is held imperatively rather than structurally.
func (llm *LLM) AttachDependencyResults(
	ctx context.Context,
	_ dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.AnyResult, error) {
	_ = ctx
	if llm == nil || llm.mcp == nil {
		return nil, nil
	}
	var deps []dagql.AnyResult
	if llm.mcp.workspace.Self() != nil {
		attached, err := attach(llm.mcp.workspace)
		if err != nil {
			return nil, fmt.Errorf("attach llm workspace: %w", err)
		}
		ws, ok := attached.(dagql.ObjectResult[*Workspace])
		if !ok {
			return nil, fmt.Errorf("attach llm workspace: unexpected result %T", attached)
		}
		llm.mcp.workspace = ws
		deps = append(deps, attached)
	}
	for i, bound := range llm.mcp.boundTools {
		// The binding dispatches through its composition-time class, whose
		// resolvers and module provider use the module that installed it.
		// Own that module for eager and lazy bindings alike: a lazy binding
		// keeps its class without ever loading the receiver, and an eager one
		// deliberately rewraps the receiver in this class even when the
		// receiver was loaded through another same-named class.
		if classModule, ok := ModuleObjectTypeModule(bound.objType); ok {
			attached, err := attach(classModule)
			if err != nil {
				return nil, fmt.Errorf("attach llm bound tool module: %w", err)
			}
			deps = append(deps, attached)
		}
		if bound.object == nil {
			// A lazy binding (restored from a persisted session) has no loaded
			// object to attach; it is loaded on first dispatch instead.
			continue
		}
		attached, err := attach(bound.object)
		if err != nil {
			return nil, fmt.Errorf("attach llm bound tool object: %w", err)
		}
		obj, ok := attached.(dagql.AnyObjectResult)
		if !ok {
			return nil, fmt.Errorf("attach llm bound tool object: unexpected result %T", attached)
		}
		// Dependency attachment may rewrap the value in the current server's
		// same-named class. The tool binding must keep the class captured when
		// it was composed, including a newer module revision after reload.
		obj, err = bound.objType.New(obj)
		if err != nil {
			return nil, fmt.Errorf("attach llm bound tool type: %w", err)
		}
		llm.mcp.boundTools[i].object = obj
		deps = append(deps, obj)
	}
	for i, skillDir := range llm.mcp.skillDirs {
		attached, err := attach(skillDir.Directory)
		if err != nil {
			return nil, fmt.Errorf("attach llm skill directory: %w", err)
		}
		dir, ok := attached.(dagql.ObjectResult[*Directory])
		if !ok {
			return nil, fmt.Errorf("attach llm skill directory: unexpected result %T", attached)
		}
		llm.mcp.skillDirs[i].Directory = dir
		deps = append(deps, attached)
	}
	return deps, nil
}

func (llm *LLM) Endpoint(ctx context.Context) (*LLMEndpoint, error) {
	llm.endpointMtx.Lock()
	defer llm.endpointMtx.Unlock()

	// Cached/restored conversations and their clones can be used by another
	// session. Credentials and local tunnels belong to the session that routed
	// them, so only reuse the memo within that execution session. In particular,
	// never let a warm credential cache hide a cross-session endpoint reuse.
	var sessionID string
	if scope, ok := engine.ClientScopeFromContext(ctx); ok {
		sessionID = scope.SessionID()
	}
	if llm.endpoint != nil && llm.endpointSessionID == sessionID {
		return llm.endpoint, nil
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	router, err := loadLLMRouter(ctx, query)
	if err != nil {
		return nil, err
	}
	endpoint, err := router.Endpoint(ctx, llm.model, llm.provider)
	if err != nil {
		return nil, err
	}
	if endpoint.Model == "" {
		return nil, fmt.Errorf("no valid LLM endpoint configuration")
	}

	// A local endpoint is reachable from the client's host, not necessarily the
	// engine (which may run in a container or on another host). Tunnel its
	// traffic through the client's session before building the client, so it
	// dials through the tunnel.
	if endpoint.Provider == Local {
		// Tunnel through the session of the client that configured the local
		// endpoint (the base URL is reachable from *its* host) — the calling
		// client by default, the session's main client when the config was
		// inherited from it.
		tunnelClient := router.localClient
		if tunnelClient == nil {
			tunnelClient, err = query.NonModuleParentClientMetadata(ctx)
			if err != nil {
				return nil, fmt.Errorf("local LLM: parent client metadata: %w", err)
			}
		}
		// The tunnel serves the endpoint beyond this call, so scope it to the
		// client's session: it shuts down when the session closes.
		sessionCtx, err := query.Server.SessionScopedContext(ctx)
		if err != nil {
			return nil, fmt.Errorf("local LLM: session context: %w", err)
		}
		tunnelCtx := engine.ContextWithClientMetadata(sessionCtx, tunnelClient)
		if err := setupLocalTunnel(tunnelCtx, endpoint); err != nil {
			return nil, fmt.Errorf("setup local LLM tunnel: %w", err)
		}
	}

	// Apply the conversation-level reasoning effort override, if any. Route()
	// builds a fresh endpoint per call, so mutating it here is safe. "none" is
	// passed through: providers treat it the same as empty (reasoning off),
	// but it must override a non-empty provider-configured effort.
	if llm.reasoningEffort != "" {
		endpoint.ReasoningEffort = llm.reasoningEffort
	}

	if endpoint.Client == nil {
		endpoint.Client, err = endpoint.newClient()
		if err != nil {
			return nil, err
		}
	}

	llm.endpoint = endpoint
	llm.endpointSessionID = sessionID

	return llm.endpoint, nil
}

// Generate a human-readable documentation of tools available to the model
func (llm *LLM) ToolsDoc(ctx context.Context) (string, error) {
	tools, err := llm.mcp.Tools(ctx)
	if err != nil {
		return "", err
	}
	var result string
	for _, tool := range tools {
		schema, err := json.MarshalIndent(tool.Schema, "", "  ")
		if err != nil {
			return "", err
		}
		result = fmt.Sprintf("%s## %s\n\n%s\n\n%s\n\n", result, tool.Name, tool.Description, string(schema))
	}
	return result, nil
}

// WithModel changes the model for the rest of the conversation. An empty
// provider infers the provider from the model name; a non-empty one selects
// it explicitly.
func (llm *LLM) WithModel(model, provider string) *LLM {
	llm = llm.Clone()
	llm.model = model
	llm.provider = provider
	// No lock: the clone is not shared with anyone yet, and locking its own
	// fresh mutex would protect nothing.
	llm.endpoint = nil

	return llm
}

// WithReasoningEffort changes the reasoning effort for the rest of the
// conversation, overriding any provider-configured default. "none" explicitly
// disables reasoning.
func (llm *LLM) WithReasoningEffort(effort string) *LLM {
	llm = llm.Clone()
	llm.reasoningEffort = effort
	llm.endpoint = nil

	return llm
}

// Append a user message (prompt) to the message history
func (llm *LLM) WithPrompt(
	// The prompt message.
	prompt string,
) *LLM {
	return llm.WithPromptOrigin(prompt, nil)
}

// WithPromptOrigin appends a user prompt carrying its recorded provenance:
// who sent it (an agent, the engine's event channel) and what it replies to.
// A nil origin is the user's own prompt — the unmarked common case, which is
// also what keeps every pre-provenance chain and recording byte-stable.
func (llm *LLM) WithPromptOrigin(prompt string, origin *LLMMessageOrigin) *LLM {
	return llm.WithContent([]*LLMContentBlock{{Kind: LLMContentText, Text: prompt}}, origin)
}

// WithContent appends one ordered user message. Callers validate resolved blocks first.
func (llm *LLM) WithContent(blocks []*LLMContentBlock, origin *LLMMessageOrigin) *LLM {
	llm = llm.Clone()
	llm.Messages = append(llm.Messages, (&LLMMessage{
		Role:    LLMMessageRoleUser,
		Content: blocks,
		Origin:  origin,
	}).Clone())
	return llm
}

// WithPromptFile is like WithPrompt but reads the prompt from a file
func (llm *LLM) WithPromptFile(ctx context.Context, file *File) (*LLM, error) {
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, err
	}
	fileRes, err := dagql.NewObjectResultForCurrentCall(ctx, srv, file)
	if err != nil {
		return nil, err
	}
	contents, err := file.Contents(ctx, fileRes, nil, nil)
	if err != nil {
		return nil, err
	}
	return llm.WithPrompt(string(contents)), nil
}

// WithoutMessageHistory removes all messages, leaving only the system prompts
func (llm *LLM) WithoutMessageHistory() *LLM {
	llm = llm.Clone()
	llm.Messages = slices.DeleteFunc(llm.Messages, func(msg *LLMMessage) bool {
		return msg.Role != LLMMessageRoleSystem
	})
	return llm
}

// WithoutSystemPrompts removes all system prompts from the history, leaving
// only the default system prompt
func (llm *LLM) WithoutSystemPrompts() *LLM {
	llm = llm.Clone()
	llm.Messages = slices.DeleteFunc(llm.Messages, func(msg *LLMMessage) bool {
		return msg.Role == LLMMessageRoleSystem
	})
	return llm
}

// WithoutComposition removes system prompts, tools, and skill directories
// installed by the named module. Unowned state is never removed, even for an
// empty owner. History, other modules' contributions, and configuration survive.
func (llm *LLM) WithoutComposition(owner string) *LLM {
	llm = llm.Clone()
	if owner == "" {
		return llm
	}
	llm.Messages = slices.DeleteFunc(llm.Messages, func(msg *LLMMessage) bool {
		return msg.Role == LLMMessageRoleSystem && compositionOwnerMatches(msg.CompositionOwner, owner)
	})
	llm.mcp.boundTools = slices.DeleteFunc(llm.mcp.boundTools, func(binding boundTool) bool {
		return compositionOwnerMatches(binding.Owner, owner)
	})
	llm.mcp.skillDirs = slices.DeleteFunc(llm.mcp.skillDirs, func(dir ownedSkillDirectory) bool {
		return compositionOwnerMatches(dir.Owner, owner)
	})
	return llm
}

// Append an unowned system prompt message to the history.
func (llm *LLM) WithSystemPrompt(prompt string) *LLM {
	return llm.WithSystemPromptOwner(prompt, "")
}

// WithSystemPromptOwner records the installing module's identity.
// Recipe replay uses this to preserve even an empty owner.
func (llm *LLM) WithSystemPromptOwner(prompt, owner string) *LLM {
	llm = llm.Clone()
	llm.Messages = append(llm.Messages, &LLMMessage{
		Role:             LLMMessageRoleSystem,
		CompositionOwner: owner,
		Content: []*LLMContentBlock{{
			Kind: LLMContentText,
			Text: prompt,
		}},
	})
	return llm
}

// WithResponse appends an assistant response to the message history.
// The content blocks come directly from the LLMResponse.
func (llm *LLM) WithResponse(blocks []*LLMContentBlock, tokenUsage LLMTokenUsage) *LLM {
	llm = llm.Clone()
	llm.Messages = append(llm.Messages, &LLMMessage{
		Role:       LLMMessageRoleAssistant,
		Content:    cloneLLMContent(blocks),
		TokenUsage: &tokenUsage,
	})
	return llm
}

// WithToolResult appends a tool result (user) message to the history.
func (llm *LLM) WithToolResult(callID, content string, errored bool) *LLM {
	return llm.WithToolResultBlocks(callID, content, nil, errored)
}

// WithToolResultBlocks appends one result, with legacy text preceding ordered blocks.
func (llm *LLM) WithToolResultBlocks(callID, text string, blocks []*LLMContentBlock, errored bool) *LLM {
	llm = llm.Clone()
	llm.Messages = append(llm.Messages, &LLMMessage{
		Role: LLMMessageRoleUser,
		Content: []*LLMContentBlock{{
			Kind:    LLMContentToolResult,
			Text:    text,
			Content: cloneLLMContent(blocks),
			CallID:  callID,
			Errored: errored,
		}},
	})
	return llm
}

// WithTools binds an object so every eligible method from definingSchema becomes
// a tool (hack/designs/workspace-agents.md). A tool that returns the bound object's
// own type rebinds it as the new agent state; except lists method names to exclude
// (e.g. the module's own entrypoint).
func (llm *LLM) WithTools(obj dagql.AnyObjectResult, definingSchema *ast.Schema, except []string) *LLM {
	return llm.WithToolsOwner(obj, definingSchema, except, "", 0)
}

// WithToolsOwner binds tools with an explicit installing module identity.
// It is also used when replaying a recorded binding or state transition.
func (llm *LLM) WithToolsOwner(obj dagql.AnyObjectResult, definingSchema *ast.Schema, except []string, owner string, version int) *LLM {
	llm = llm.Clone()
	llm.mcp = llm.mcp.withToolsOwner(obj, definingSchema, except, owner, version)
	return llm
}

// WithLazyTools binds an object's methods as tools from its unevaluated ID,
// preserving the schema that defined its type without loading the object.
// See MCP.WithLazyTools.
func (llm *LLM) WithLazyTools(id *call.ID, objType dagql.ObjectType, definingSchema *ast.Schema, except []string) *LLM {
	return llm.WithLazyToolsOwner(id, objType, definingSchema, except, "", 0)
}

// WithLazyToolsOwner is the lazy counterpart of WithToolsOwner.
func (llm *LLM) WithLazyToolsOwner(id *call.ID, objType dagql.ObjectType, definingSchema *ast.Schema, except []string, owner string, version int) *LLM {
	llm = llm.Clone()
	llm.mcp = llm.mcp.withLazyToolsOwner(id, objType, definingSchema, except, owner, version)
	return llm
}

// WithMaxAPICalls sets a default cap on the number of steps per loop, used
// when loop() doesn't specify its own cap. Kept for the legacy
// llm(maxAPICalls:) argument exposed to pre-v1 module views.
func (llm *LLM) WithMaxAPICalls(calls int) *LLM {
	llm = llm.Clone()
	llm.maxSteps = calls
	return llm
}

// Disable the default system prompt
func (llm *LLM) WithoutDefaultSystemPrompt() *LLM {
	llm = llm.Clone()
	llm.disableDefaultSystemPrompt = true
	return llm
}

// Add an external MCP server to the LLM
func (llm *LLM) WithMCPServer(name string, svc dagql.ObjectResult[*Service]) *LLM {
	llm = llm.Clone()
	llm.mcp = llm.mcp.WithMCPServer(&MCPServerConfig{
		Name:    name,
		Service: svc,
	})
	return llm
}

// WithSkills installs a directory of skills — each a subdirectory holding a
// SKILL.md — surfaced to the model through ListSkills/ReadSkill alongside
// the engine-embedded and workspace-discovered skills.
func (llm *LLM) WithSkills(dir dagql.ObjectResult[*Directory]) *LLM {
	return llm.WithSkillsOwner(dir, "")
}

// WithSkillsOwner installs a skill directory with an explicit module owner.
func (llm *LLM) WithSkillsOwner(dir dagql.ObjectResult[*Directory], owner string) *LLM {
	llm = llm.Clone()
	llm.mcp = llm.mcp.withSkillsOwner(dir, owner)
	return llm
}

// Skills returns the discovery index of every skill visible to the model — the
// same list the ListSkills tool serves, across all sources with the same
// precedence.
func (llm *LLM) Skills(ctx context.Context) ([]*LLMSkill, error) {
	return listSkills(ctx, llm.mcp.skillSources())
}

// Return the last message sent by the agent
func (llm *LLM) LastReply() (string, bool) {
	reply := "(no reply)"
	var foundReply bool
	for _, msg := range llm.Messages {
		if msg.Role != LLMMessageRoleAssistant {
			continue
		}
		txt := msg.TextContent()
		if len(txt) == 0 {
			continue
		}
		foundReply = true
		reply = txt
	}
	return reply, foundReply
}

func (llm *LLM) messagesWithSystemPrompt(ctx context.Context) ([]*LLMMessage, error) {
	var systemPrompt string
	if !llm.disableDefaultSystemPrompt {
		var err error
		systemPrompt, err = llm.mcp.DefaultSystemPrompt(ctx)
		if err != nil {
			return nil, err
		}
	}
	messages := renderMessagesForModel(llm.Messages)
	if systemPrompt != "" {
		return append([]*LLMMessage{{
			Role: LLMMessageRoleSystem,
			Content: []*LLMContentBlock{{
				Kind: LLMContentText,
				Text: systemPrompt,
			}},
		}}, messages...), nil
	}
	return messages, nil
}

// renderMessagesForModel applies each message's recorded origin as a
// model-facing attribution header (hack/designs/agent-messaging.md §4.1):
// the model must be able to tell another agent's words from the user's, so
// non-user origins render as a deterministic header line prepended to the
// message text at request-build time. The stored history keeps clean text
// plus structured origin; only the wire form carries the header.
func renderMessagesForModel(messages []*LLMMessage) []*LLMMessage {
	var rendered []*LLMMessage
	for i, msg := range messages {
		header := msg.Origin.AttributionHeader()
		if header == "" || msg.Role != LLMMessageRoleUser {
			if rendered != nil {
				rendered = append(rendered, msg)
			}
			continue
		}
		if rendered == nil {
			rendered = make([]*LLMMessage, 0, len(messages))
			rendered = append(rendered, messages[:i]...)
		}
		cp := msg.Clone()
		// Attribution must precede the entire message, not just its first
		// text block: media may come before the accompanying prompt.
		if len(cp.Content) > 0 && cp.Content[0].Kind == LLMContentText {
			cp.Content[0].Text = header + "\n\n" + cp.Content[0].Text
		} else {
			cp.Content = append([]*LLMContentBlock{{
				Kind: LLMContentText,
				Text: header,
			}}, cp.Content...)
		}
		rendered = append(rendered, cp)
	}
	if rendered == nil {
		return messages
	}
	return rendered
}

type ModelFinishedError struct {
	Reason string
}

func (err *ModelFinishedError) Error() string {
	return fmt.Sprintf("model finished: %s", err.Reason)
}

// Step submits the queued prompt or tool-call results, evaluates any tool
// calls, and materializes the resulting message history through the API as a
// new LLM DAG node (via withResponse/withToolResult/withTools selectors).
func (llm *LLM) Step(ctx context.Context, inst dagql.ObjectResult[*LLM], maxTokens int) (dagql.ObjectResult[*LLM], error) {
	if err := llm.allowed(ctx); err != nil {
		return inst, err
	}
	return llm.step(ctx, inst, maxTokens)
}

func (llm *LLM) step(ctx context.Context, inst dagql.ObjectResult[*LLM], maxTokens int) (dagql.ObjectResult[*LLM], error) {
	llm = llm.Clone()

	// Capture the bound state entering this step before anything can mutate it
	// on this step's transient MCP clone - building the tool list already
	// touches the bindings. Anything that changes during the step must be
	// re-recorded onto the materialized state via withWorkspace/withTools, or
	// later steps will rebuild history from the stale bindings and silently
	// revert it.
	wsBefore, _ := llm.mcp.WorkspaceID()
	toolsBefore, _ := llm.mcp.BoundToolBindings()

	tools, err := llm.mcp.Tools(ctx)
	if err != nil {
		return inst, err
	}

	messagesToSend, err := llm.messagesWithSystemPrompt(ctx)
	if err != nil {
		return inst, err
	}

	// Compute the LLM call digest for prompt/response span metadata. inst is the
	// LLM state entering step() (typically the result of withPrompt). Its recipe
	// digest matches the dagql call span's digest (dagger.io/dag.digest), so the
	// TUI can locate that call and branch from this point. Note that inst.ID()
	// returns a post-evaluation runtime handle with no recipe digest, so derive
	// the recipe digest directly instead.
	var llmCallDigest string
	if dig, digErr := inst.RecipeDigest(ctx); digErr == nil {
		llmCallDigest = dig.String()
	}

	emitNewMessageSpans(ctx, messagesToSend, llmCallDigest)

	res, err := llm.sendQueryWithRetry(ctx, messagesToSend, tools, llmCallDigest, maxTokens)
	if err != nil {
		return inst, err
	}

	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return inst, err
	}

	responseSel, err := responseSelector(res)
	if err != nil {
		return inst, err
	}
	// Extract tool calls from response content blocks for the MCP layer.
	var toolCalls []*LLMToolCall
	for _, block := range res.Content {
		if block.Kind == LLMContentToolCall {
			toolCalls = append(toolCalls, &LLMToolCall{
				CallID:    block.CallID,
				Name:      block.ToolName,
				Arguments: block.Arguments,
			})
		}
	}

	// Tool-call display spans are ended by CallBatch as each tool returns. End
	// the remaining (text/thinking) spans once the turn's results have been
	// applied, so they close in the order they streamed.
	endedByCallBatch := make(map[trace.Span]bool, len(res.ToolCallDisplays))
	for _, tc := range res.ToolCallDisplays {
		endedByCallBatch[tc.Span] = true
	}
	endRemainingDisplaySpans := func() {
		for _, s := range res.DisplaySpans {
			if !endedByCallBatch[s] {
				s.End()
			}
		}
	}

	// Materialize the assistant response BEFORE dispatching the tool calls, so
	// the object-tool adapter can pass the conversation up to and including its
	// own call directly to hidden LLM arguments. This is the same chain a
	// single multi-selector Select would build; only the timing differs.
	var responded dagql.ObjectResult[*LLM]
	if err := srv.Select(ctx, inst, &responded, responseSel); err != nil {
		for _, s := range res.DisplaySpans {
			s.End()
		}
		return inst, err
	}
	stampResponseDigest(ctx, res.DisplaySpans, responded)
	llm.mcp.SetSelfLLM(responded)

	// Run the turn's tool calls in the order written; see toolDispatch.
	dispatch := &toolDispatch{
		srv:         srv,
		mcp:         llm.mcp,
		tools:       tools,
		base:        responded,
		wsBefore:    wsBefore,
		toolsBefore: toolsBefore,
	}
	resultMsgs := dispatch.run(ctx, toolCalls, res.ToolCallDisplays)
	base := dispatch.base
	stateSels := dispatch.stateSelectors()

	toolNames := make(map[string]string, len(toolCalls))
	for _, tc := range toolCalls {
		toolNames[tc.CallID] = tc.Name
	}
	sels, err := toolResultSelectors(base.Self(), resultMsgs, toolNames)
	if err != nil {
		endRemainingDisplaySpans()
		return inst, err
	}
	sels = append(sels, stateSels...)

	var stepped dagql.ObjectResult[*LLM]
	if len(sels) == 0 {
		// Nothing left to record: base is already materialized, whether it is
		// the bare response (no tool calls this turn) or a continuation.
		endRemainingDisplaySpans()
		return base, nil
	}

	// A canceled tool call still produced protocol-significant history: the
	// assistant's tool_use above and CallBatch's errored tool_result. Record
	// those pure selectors on a context detached from cancellation so the next
	// user prompt sees why the tool ran without sending providers a dangling
	// tool_use. We still return the cancellation cause below, so the agent loop
	// commits this state and parks rather than taking another model step.
	recordCtx := ctx
	detached := ctx.Err() != nil
	if detached {
		recordCtx = context.WithoutCancel(ctx)
	}
	err = srv.Select(recordCtx, base, &stepped, sels...)
	if err != nil && !detached && ctx.Err() != nil {
		// Cancellation may have raced with the first Select. Its selectors are
		// immutable history construction, so retrying them is safe.
		err = srv.Select(context.WithoutCancel(ctx), base, &stepped, sels...)
	}
	endRemainingDisplaySpans()
	if err != nil {
		return inst, err
	}
	if cause := context.Cause(ctx); cause != nil {
		return stepped, cause
	}

	return stepped, nil
}

// toolDispatch runs one turn's tool calls for step(), in the order written.
// A continuation — a tool returning an LLM — replaces the conversation
// mid-turn, so the calls the model wrote after it run on THAT conversation:
// its workspace, bindings and toolset. `[checkout, log]` logs the new
// checkout, and `[edit, reload]` reloads the edit.
//
// mcp is the transient MCP running the current stretch of calls, with its
// toolset, and base the materialized conversation it is in sync with as of
// wsBefore and toolsBefore. Before a continuation runs, the stretch's
// workspace and binding changes are folded into base (fold), so the
// continuation receives them.
type toolDispatch struct {
	srv         *dagql.Server
	mcp         *MCP
	tools       []LLMTool
	base        dagql.ObjectResult[*LLM]
	wsBefore    *call.ID
	toolsBefore []boundToolBinding
}

// run runs the calls and returns one result per call, in call order.
func (d *toolDispatch) run(ctx context.Context, toolCalls []*LLMToolCall, displays map[string]toolCallDisplay) []*LLMMessage {
	var results []*LLMMessage
	for remaining := toolCalls; len(remaining) > 0; {
		ran, rest := d.mcp.CallBatch(ctx, d.tools, remaining, displays, d.fold)
		results = append(results, ran...)
		// A tool returned an LLM: it acted as a continuation, and the turn
		// resumes from THAT conversation — its env, tools, system prompts and
		// history — instead of the one that made the call (see MCP.adoptLLM).
		// Its ID records the transform, so loading it restores that
		// conversation. The state changes before it were folded into the
		// conversation it derived from, and adoptLLM refuses a continuation
		// that would drop any.
		cont := d.mcp.Continuation()
		if cont.Self() == nil {
			break
		}
		d.base = cont
		if len(rest) == 0 {
			break
		}
		if err := d.continueOn(ctx, cont); err != nil {
			text := fmt.Sprintf("not run: failed to load the tools of the conversation continued by an earlier call: %s", err)
			for _, tc := range rest {
				endToolCallDisplay(displays, tc.CallID, true, text)
				results = append(results, &LLMMessage{
					Role: LLMMessageRoleUser,
					Content: []*LLMContentBlock{{
						Kind:    LLMContentToolResult,
						CallID:  tc.CallID,
						Text:    text,
						Errored: true,
					}},
				})
			}
			break
		}
		remaining = rest
	}
	return results
}

// fold records the current stretch's state changes onto base, materialized
// the way the response itself was, and hands base to the MCP as the
// conversation a continuation receives.
func (d *toolDispatch) fold(ctx context.Context) error {
	if sels := stateDeltaSelectors(d.mcp, d.wsBefore, d.toolsBefore); len(sels) > 0 {
		var withState dagql.ObjectResult[*LLM]
		if err := d.srv.Select(ctx, d.base, &withState, sels...); err != nil {
			return err
		}
		d.base = withState
	}
	// base now carries the MCP's state: later changes are relative to it.
	d.wsBefore, _ = d.mcp.WorkspaceID()
	d.toolsBefore, _ = d.mcp.BoundToolBindings()
	d.mcp.SetSelfLLM(d.base)
	return nil
}

// continueOn prepares a continuation to run the calls the model wrote after
// the one that returned it, the way the next step would run them: a transient
// clone of its MCP, dispatching on its behalf, with its toolset. The bindings
// are captured before the toolset is built, since building it already touches
// them (see step).
func (d *toolDispatch) continueOn(ctx context.Context, cont dagql.ObjectResult[*LLM]) error {
	next := cont.Self().mcp.Clone()
	wsBefore, _ := next.WorkspaceID()
	toolsBefore, _ := next.BoundToolBindings()
	next.SetSelfLLM(cont)
	tools, err := next.Tools(ctx)
	if err != nil {
		return err
	}
	d.mcp, d.tools = next, tools
	d.wsBefore, d.toolsBefore = wsBefore, toolsBefore
	return nil
}

// stateSelectors re-records the in-step state changes — a Changeset overlaid
// onto the bound workspace, a Workspace returned, an object rebound as the
// new state — that live only on the transient MCP. They must be recorded onto
// the materialized state as withWorkspace/withTools selectors, or later steps
// rebuild history from the stale bindings and silently revert them. If the
// turn ended on an adopted continuation, nothing remains to persist on top of
// it.
func (d *toolDispatch) stateSelectors() []dagql.Selector {
	if d.mcp.Continuation().Self() != nil {
		return nil
	}
	return stateDeltaSelectors(d.mcp, d.wsBefore, d.toolsBefore)
}

// toolResultSelectors builds the selectors that append this turn's tool results
// to `target` — normally the LLM that made the calls, but after a continuation
// (MCP.adoptLLM) an arbitrary conversation the tool handed back.
//
// Providers require every tool_result to directly follow the matching
// tool_use, keyed by call ID: the call must be in the last assistant message,
// and nothing may already answer it. An adopted conversation need not satisfy
// that — a self-compaction or summarize-and-restart continuation drops the call
// altogether, and one that ran further turns of its own (a sub-agent's
// conversation handed back) has moved past it — so appending the result as a
// tool-result block there would produce a protocol-invalid history, which the
// provider rejects on every later step. Such a result is instead appended as a
// plain user message carrying the same information, so nothing is lost and the
// history stays valid. Where the call IS still the pending one (the
// install/reload case, which preserves history) results append normally.
func toolResultSelectors(target *LLM, msgs []*LLMMessage, toolNames map[string]string) ([]dagql.Selector, error) {
	var sels []dagql.Selector
	for _, msg := range msgs {
		var result *LLMContentBlock
		for _, block := range msg.Content {
			if block.Kind == LLMContentToolResult {
				result = block
				break
			}
		}
		if result == nil {
			return nil, fmt.Errorf("tool result message has no TOOL_RESULT block")
		}
		callID := result.CallID
		if target != nil && !toolResultAttachable(target.Messages, callID) {
			name := toolNames[callID]
			if name == "" {
				name = callID
			}
			text := fmt.Sprintf("[continued via tool %s]\n%s", name, result.Text)
			if len(result.Content) > 0 {
				// A continuation can discard the matching tool call. Retain the
				// media as user content, not just its plain-text placeholder.
				blocks := append([]*LLMContentBlock{{Kind: LLMContentText, Text: text}}, result.Content...)
				inputs, err := contentBlockInputs(blocks)
				if err != nil {
					return nil, err
				}
				sels = append(sels, dagql.Selector{Field: "withContent", Args: []dagql.NamedInput{{Name: "content", Value: inputs}}})
			} else {
				sels = append(sels, dagql.Selector{Field: "withPrompt", Args: []dagql.NamedInput{{Name: "prompt", Value: dagql.NewString(text)}}})
			}
			continue
		}
		sel := dagql.Selector{
			Field: "withToolResult",
			Args: []dagql.NamedInput{
				{Name: "callId", Value: dagql.NewString(callID)},
				{Name: "content", Value: dagql.NewString(result.Text)},
				{Name: "errored", Value: dagql.NewBoolean(result.Errored)},
			},
		}
		if len(result.Content) > 0 {
			inputs, err := contentBlockInputs(result.Content)
			if err != nil {
				return nil, err
			}
			sel.Args = append(sel.Args, dagql.NamedInput{Name: "blocks", Value: inputs})
		}
		sels = append(sels, sel)
	}
	return sels, nil
}

// stateDeltaSelectors builds the selectors that re-record what this step's tool
// calls changed on the transient MCP clone, relative to the bindings captured
// entering the step, so the change survives the LLM history rebuild:
//
//   - a workspace change (e.g. a tool returned a Changeset that was overlaid
//     onto the bound workspace) as withWorkspace — a rebuild otherwise re-binds
//     the original workspace (via NewLLM or the last recorded withWorkspace)
//     and loses the overlay;
//   - a state transition — a tool that returned its bound object's own type
//     rebinds it (hack/designs/workspace-agents.md) — as a withTools selector
//     for each binding whose object changed.
//
// Comparisons are handle-safe (post-eval IDs are handle-form).
func stateDeltaSelectors(m *MCP, wsBefore *call.ID, toolsBefore []boundToolBinding) []dagql.Selector {
	var sels []dagql.Selector
	if wsAfter, err := m.WorkspaceID(); err == nil && wsAfter != nil &&
		stableIDDigest(wsAfter) != stableIDDigest(wsBefore) {
		sels = append(sels, dagql.Selector{
			Field: "withWorkspace",
			Args: []dagql.NamedInput{
				{
					Name:  "workspace",
					Value: dagql.NewID[*Workspace](wsAfter),
				},
			},
		})
	}
	if toolsAfter, err := m.BoundToolBindings(); err == nil {
		for i, after := range toolsAfter {
			if i < len(toolsBefore) &&
				stableIDDigest(after.ID) == stableIDDigest(toolsBefore[i].ID) &&
				after.Version == toolsBefore[i].Version &&
				after.Owner == toolsBefore[i].Owner && slices.Equal(after.Except, toolsBefore[i].Except) {
				continue
			}
			sels = append(sels, dagql.Selector{
				Field: "withTools",
				Args: []dagql.NamedInput{
					{
						Name:  "object",
						Value: dagql.NewAnyID(after.ID),
					},
					{
						Name:  "except",
						Value: dagql.ArrayInput[dagql.String](dagql.NewStringArray(after.Except...)),
					},
					{Name: "owner", Value: dagql.Opt(dagql.String(after.Owner))},
					{Name: "version", Value: dagql.Int(after.Version)},
				},
			})
		}
	}
	return sels
}

// toolResultAttachable reports whether a tool result for callID can be appended
// to the history as a tool-result block: the call must be in the LAST assistant
// message, and nothing after that message may already answer it. That is the
// shape providers accept — a tool_result directly following its tool_use — so
// merely finding the call somewhere in the history is not enough: a
// conversation that went on to further assistant turns, or that already
// carries a result for the call, has moved past it.
func toolResultAttachable(msgs []*LLMMessage, callID string) bool {
	if callID == "" {
		return false
	}
	last := -1
	for i := len(msgs) - 1; i >= 0; i-- {
		if msgs[i] != nil && msgs[i].Role == LLMMessageRoleAssistant {
			last = i
			break
		}
	}
	if last < 0 || !messageHasBlock(msgs[last], LLMContentToolCall, callID) {
		return false
	}
	for _, msg := range msgs[last+1:] {
		if messageHasBlock(msg, LLMContentToolResult, callID) {
			return false
		}
	}
	return true
}

// messageHasBlock reports whether msg contains a content block of the given
// kind for the given call ID.
func messageHasBlock(msg *LLMMessage, kind LLMContentBlockKind, callID string) bool {
	if msg == nil {
		return false
	}
	for _, block := range msg.Content {
		if block != nil && block.Kind == kind && block.CallID == callID {
			return true
		}
	}
	return false
}

// stampResponseDigest re-points the response's display spans (text, thinking
// and tool calls) at the withResponse call that recorded them, now that it
// exists. They start streaming before the response is materialized, so they
// open carrying the REQUEST state's digest; left that way, a branch from a
// reply would rewind to the state before it and silently drop the reply the
// user picked. Every display span is still open here — CallBatch and step's
// own cleanup end them later — so the attribute rides their end export.
func stampResponseDigest(ctx context.Context, spans []trace.Span, responded dagql.ObjectResult[*LLM]) {
	if len(spans) == 0 {
		return
	}
	dig, err := responded.RecipeDigest(ctx)
	if err != nil || dig == "" {
		return
	}
	attr := attribute.String(telemetryattrs.LLMCallDigestAttr, dig.String())
	for _, s := range spans {
		s.SetAttributes(attr)
	}
}

// emitNewMessageSpans emits display spans for prompt content appended since the
// last response. Tool results already have their own display logs, but are not
// a boundary: a continuation can append a prompt before step adds its results.
func emitNewMessageSpans(ctx context.Context, messages []*LLMMessage, llmCallDigest string) {
	var newMessages []*LLMMessage
	for _, msg := range slices.Backward(messages) {
		if msg.Role == LLMMessageRoleAssistant {
			// Only display messages appended since the last response.
			break
		}
		// Skip result-only messages without hiding direct prompt content in a
		// mixed message. emitUserMessageSpan ignores TOOL_RESULT blocks, whose
		// contents were already emitted by the tool call itself.
		if !slices.ContainsFunc(msg.Content, func(block *LLMContentBlock) bool {
			switch block.Kind {
			case LLMContentText, LLMContentImage, LLMContentAudio, LLMContentDocument:
				return true
			default:
				return false
			}
		}) {
			continue
		}
		newMessages = append(newMessages, msg)
	}
	slices.Reverse(newMessages)
	for _, msg := range newMessages {
		emitMessageSpan(ctx, msg, llmCallDigest)
	}
}

// sendQueryWithRetry submits the conversation to the model's endpoint,
// retrying retryable provider failures with exponential backoff.
func (llm *LLM) sendQueryWithRetry(ctx context.Context, messages []*LLMMessage, tools []LLMTool, llmCallDigest string, maxTokens int) (*LLMResponse, error) {
	for i, msg := range messages {
		if msg == nil {
			return nil, fmt.Errorf("message %d: nil message", i)
		}
		if err := ValidateLLMContent(msg.Content); err != nil {
			return nil, fmt.Errorf("message %d: %w", i, err)
		}
	}

	ctx, err := enginetelemetry.WithNetworkRecording(ctx)
	if err != nil {
		return nil, fmt.Errorf("create LLM network recorders: %w", err)
	}
	b := backoff.NewExponentialBackOff()
	// Sane defaults (ideally not worth extra knobs)
	b.InitialInterval = 1 * time.Second
	b.MaxInterval = 30 * time.Second
	b.MaxElapsedTime = 2 * time.Minute

	ep, err := llm.Endpoint(ctx)
	if err != nil {
		return nil, err
	}

	var res *LLMResponse
	var authRetried bool
	err = backoff.Retry(func() error {
		// Read the client inside the retry: recovering from a rejected
		// credential is only worth anything if the next attempt picks up what
		// the recovery changed.
		client := ep.Client
		var sendErr error
		// The provider streams this turn's content into its own per-block display
		// spans (thinking, response, tool calls); it sets the call digest on them
		// so the TUI can branch from a span, and ends them (or the loop does for
		// text/thinking spans, once tool results are applied).
		res, sendErr = client.SendQuery(ctx, messages, tools, &LLMCallOpts{
			MaxTokens:  maxTokens,
			CallDigest: llmCallDigest,
		})
		if sendErr != nil {
			var finished *ModelFinishedError
			if errors.As(sendErr, &finished) {
				// Don't retry if the model finished explicitly, treat as permanent.
				return backoff.Permanent(sendErr)
			}
			if isAuthFailure(sendErr) {
				// Retry a rejected credential exactly once. The transport has
				// already invalidated the token actually used and arranged for
				// the next lookup to request a refresh from the client. Do not
				// invalidate again here: another concurrent request may already
				// have resolved a newer credential in the meantime.
				if authRetried || ep.AuthTokenSource == nil {
					return backoff.Permanent(ep.credentialError(sendErr))
				}
				authRetried = true
				return sendErr
			}
			if !client.IsRetryable(sendErr) {
				// Maybe an invalid request - give up.
				return backoff.Permanent(sendErr)
			}
			// Log retry attempts? Maybe with increasing severity?
			// For now, just return the error to signal backoff to retry.
			return sendErr
		}
		// Success, stop retrying
		return nil
	}, backoff.WithContext(b, ctx))
	if err != nil {
		return nil, err
	}
	return res, nil
}

// responseSelector builds the withResponse selector that records the model's
// reply - its content blocks and token usage - as a new node in the LLM DAG.
func responseSelector(res *LLMResponse) (dagql.Selector, error) {
	return responseSelectorFromBlocks(res.Content, res.TokenUsage)
}

// contentBlockInputMap uses GraphQL's lowerCamel field names recursively.
func contentBlockInputMap(block *LLMContentBlock) map[string]any {
	content := make([]any, len(block.Content))
	for i, child := range block.Content {
		content[i] = contentBlockInputMap(child)
	}
	m := map[string]any{
		"kind": string(block.Kind), "text": block.Text,
		"callId": block.CallID, "toolName": block.ToolName,
		"arguments": string(block.Arguments), "errored": block.Errored,
		"signature": block.Signature, "mimeType": block.MIMEType,
		"content": content,
	}
	if len(block.Data) != 0 {
		m["data"] = block.Data
	}
	return m
}

// contentBlockInputs decodes maps rather than constructing bare InputObjects:
// their decoded fields are required when serializing a selector to a call literal.
func contentBlockInputs(blocks []*LLMContentBlock) (dagql.ArrayInput[dagql.InputObject[LLMContentBlockInput]], error) {
	if err := ValidateLLMContent(blocks); err != nil {
		return nil, err
	}
	inputs := make(dagql.ArrayInput[dagql.InputObject[LLMContentBlockInput]], len(blocks))
	for i, block := range blocks {
		decoded, err := (dagql.InputObject[LLMContentBlockInput]{}).Decoder().DecodeInput(contentBlockInputMap(block))
		if err != nil {
			return nil, fmt.Errorf("decode content block %d input: %w", i, err)
		}
		inputs[i] = decoded.(dagql.InputObject[LLMContentBlockInput])
	}
	return inputs, nil
}

// responseSelectorFromBlocks builds a withResponse selector from raw content
// blocks and token usage for fresh responses.
func responseSelectorFromBlocks(blocks []*LLMContentBlock, tokenUsage LLMTokenUsage) (dagql.Selector, error) {
	contentInputs, err := contentBlockInputs(blocks)
	if err != nil {
		return dagql.Selector{}, err
	}
	args := []dagql.NamedInput{
		{
			Name:  "content",
			Value: contentInputs,
		},
	}
	if tokenUsage.InputTokens != 0 {
		args = append(args, dagql.NamedInput{
			Name:  "inputTokens",
			Value: dagql.NewInt(tokenUsage.InputTokens),
		})
	}
	if tokenUsage.OutputTokens != 0 {
		args = append(args, dagql.NamedInput{
			Name:  "outputTokens",
			Value: dagql.NewInt(tokenUsage.OutputTokens),
		})
	}
	if tokenUsage.CachedTokenReads != 0 {
		args = append(args, dagql.NamedInput{
			Name:  "cachedTokenReads",
			Value: dagql.NewInt(tokenUsage.CachedTokenReads),
		})
	}
	if tokenUsage.CachedTokenWrites != 0 {
		args = append(args, dagql.NamedInput{
			Name:  "cachedTokenWrites",
			Value: dagql.NewInt(tokenUsage.CachedTokenWrites),
		})
	}
	if tokenUsage.TotalTokens != 0 {
		args = append(args, dagql.NamedInput{
			Name:  "totalTokens",
			Value: dagql.NewInt(tokenUsage.TotalTokens),
		})
	}
	return dagql.Selector{
		Field: "withResponse",
		Args:  args,
	}, nil
}

// Loop sends the context to the LLM endpoint, processes replies and tool calls,
// and continues stepping until the model ends its turn (no more prompts) or
// the step cap is reached. maxTokens caps the model's output tokens on each
// step made during this loop; zero uses the model's default.
func (llm *LLM) Loop(ctx context.Context, inst dagql.ObjectResult[*LLM], maxSteps, maxTokens int) (dagql.ObjectResult[*LLM], error) {
	if err := llm.allowed(ctx); err != nil {
		return inst, err
	}

	if maxSteps <= 0 {
		// fall back to the legacy llm(maxAPICalls:) cap, if one was set
		maxSteps = llm.maxSteps
	}

	var steps int
	for {
		llm := inst.Self()

		if !llm.HasPending() {
			// nothing to do - either never prompted, or naturally reached the end of
			// the loop (e.g. LLM reply with no additional tool calls)
			return inst, nil
		}

		if maxSteps > 0 && steps >= maxSteps {
			return inst, fmt.Errorf("reached step limit: %d", steps)
		}

		steps++

		var err error
		inst, err = inst.Self().Step(ctx, inst, maxTokens)
		if err != nil {
			if ctx.Err() != nil {
				// Context was cancelled (user interrupt). Return the last
				// successfully recorded state so that the prompt and any prior
				// progress are preserved in history.
				return inst, nil //nolint:nilerr // deliberate: interrupts are not errors
			}
			// Handle persistent error after all retries failed.
			return inst, err
		}
	}
}

func (llm *LLM) Interject(ctx context.Context, self dagql.ObjectResult[*LLM]) (dagql.ObjectResult[*LLM], bool, error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return self, false, err
	}
	bk, err := query.Engine(ctx)
	if err != nil {
		return self, false, err
	}
	if !bk.Opts.Interactive {
		return self, false, nil
	}
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return self, false, err
	}
	var selfDigest string
	if dig, digErr := self.RecipeDigest(ctx); digErr == nil {
		selfDigest = dig.String()
	}
	attrs := []attribute.KeyValue{
		attribute.String(telemetry.UIActorEmojiAttr, "🧑"),
		attribute.String(telemetry.UIMessageAttr, telemetry.UIMessageSent),
		attribute.String(telemetry.LLMRoleAttr, telemetry.LLMRoleUser),
		attribute.String(telemetryattrs.LLMCallDigestAttr, selfDigest),
	}
	attrs = append(attrs, genAIAgentAttrsFromContext(ctx)...)
	ctx, span := Tracer(ctx).Start(ctx, "LLM prompt", trace.WithAttributes(attrs...))
	defer span.End()
	stdio := telemetry.SpanStdio(ctx, InstrumentationLibrary,
		log.String(telemetry.ContentTypeAttr, "text/markdown"))
	defer stdio.Close()
	lastAssistantMessage, foundReply := llm.LastReply()
	if !foundReply {
		return self, false, fmt.Errorf("no message from assistant")
	}
	msg, err := bk.PromptHumanHelp(ctx, "LLM needs help!", fmt.Sprintf("The LLM was unable to complete its task and needs a prompt to continue. Here is its last message:\n%s", mdQuote(lastAssistantMessage)))
	if err != nil {
		return self, false, err
	}
	if msg == "" {
		return self, false, nil
	}
	fmt.Fprint(stdio.Stdout, msg)

	var inst dagql.ObjectResult[*LLM]
	if err := srv.Select(ctx, self, &inst, dagql.Selector{
		Field: "withPrompt",
		Args: []dagql.NamedInput{
			{
				Name:  "prompt",
				Value: dagql.NewString(msg),
			},
		},
	}); err != nil {
		return self, false, err
	}
	return inst, true, nil
}

func mdQuote(msg string) string {
	lines := strings.Split(msg, "\n")
	for i, line := range lines {
		lines[i] = fmt.Sprintf("> %s", line)
	}
	return strings.Join(lines, "\n")
}

// HasPending reports whether anything is queued to send to the model: an
// unsent prompt or unevaluated tool results. When true, another step will do
// work; when false, the turn is complete.
func (llm *LLM) HasPending() bool {
	return len(llm.Messages) > 0 && llm.Messages[len(llm.Messages)-1].Role == LLMMessageRoleUser
}

func (llm *LLM) allowed(ctx context.Context) error {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	module, err := query.CurrentModule(ctx)
	if err != nil {
		// allow non-module calls
		if errors.Is(err, ErrNoCurrentModule) {
			return nil
		}
		return fmt.Errorf("failed to figure out module while deciding if llm is allowed: %w", err)
	}

	src := module.Self().ContextSource.Value.Self()
	if src.Kind != ModuleSourceKindGit {
		return nil
	}

	md, err := engine.ClientMetadataFromContext(ctx) // not mainclient
	if err != nil {
		return fmt.Errorf("llm sync failed fetching client metadata from context: %w", err)
	}

	moduleURL := src.Git.Symbolic
	for _, allowedModule := range md.AllowedLLMModules {
		if allowedModule == "all" || moduleURL == allowedModule {
			return nil
		}
	}

	bk, err := query.Engine(ctx)
	if err != nil {
		return fmt.Errorf("llm sync failed fetching bk client for llm allow prompting: %w", err)
	}

	return bk.PromptAllowLLM(ctx, moduleURL)
}

// emitMessageSpan creates telemetry for a live LLM message.
// Restored history comes from imported telemetry, never newly emitted spans.
// callDigest is the DAG digest enabling TUI branching from that point.
func emitMessageSpan(ctx context.Context, msg *LLMMessage, callDigest string) {
	switch msg.Role {
	case LLMMessageRoleUser, LLMMessageRoleSystem:
		emitUserMessageSpan(ctx, msg, callDigest)
	case LLMMessageRoleAssistant:
		emitAssistantMessageSpan(ctx, msg, callDigest)
	}
}

// messageOriginAttrs renders a recorded message origin as span attributes for
// the message's telemetry span, so frontends can attribute another agent's
// words to their sender and render engine lifecycle events compactly
// (hack/designs/agent-messaging.md §4.1). Nil — the user's own prompt — emits
// nothing, keeping pre-provenance spans unchanged.
func messageOriginAttrs(origin *LLMMessageOrigin) []attribute.KeyValue {
	if origin == nil {
		return nil
	}
	attrs := []attribute.KeyValue{
		attribute.String(telemetryattrs.LLMMessageOriginKindAttr, string(origin.Kind)),
	}
	if origin.AgentName != "" {
		attrs = append(attrs, attribute.String(telemetryattrs.LLMMessageOriginAgentNameAttr, origin.AgentName))
	}
	if origin.Ref != "" {
		attrs = append(attrs, attribute.String(telemetryattrs.LLMMessageOriginRefAttr, origin.Ref))
	}
	if origin.ReplyTo != "" {
		attrs = append(attrs, attribute.String(telemetryattrs.LLMMessageOriginReplyToAttr, origin.ReplyTo))
	}
	return attrs
}

func emitUserMessageSpan(ctx context.Context, msg *LLMMessage, callDigest string) {
	var emoji string
	switch msg.Role {
	case LLMMessageRoleUser:
		emoji = "🧑"
	case LLMMessageRoleSystem:
		emoji = "⚙️"
	}
	attrs := []attribute.KeyValue{
		attribute.String(telemetry.UIActorEmojiAttr, emoji),
		attribute.String(telemetry.UIMessageAttr, telemetry.UIMessageSent),
		attribute.String(telemetry.LLMRoleAttr, telemetry.LLMRoleUser),
		attribute.Bool(telemetry.UIInternalAttr, msg.Role == LLMMessageRoleSystem),
	}
	attrs = append(attrs, messageOriginAttrs(msg.Origin)...)
	attrs = append(attrs, genAIAgentAttrsFromContext(ctx)...)
	if callDigest != "" {
		attrs = append(attrs, attribute.String(telemetryattrs.LLMCallDigestAttr, callDigest))
	}
	ctx, span := Tracer(ctx).Start(ctx, "LLM prompt", trace.WithAttributes(attrs...))
	defer span.End()
	stdio := telemetry.SpanStdio(ctx, InstrumentationLibrary,
		log.String(telemetry.ContentTypeAttr, "text/markdown"))
	defer stdio.Close()
	for _, block := range msg.Content {
		switch block.Kind {
		case LLMContentText:
			fmt.Fprint(stdio.Stdout, block.Text)
		case LLMContentImage, LLMContentAudio, LLMContentDocument:
			emitContentLog(ctx, stdio.Stdout, block, "\n",
				log.String(telemetry.ContentTypeAttr, "text/markdown"))
		}
	}
}

func emitAssistantMessageSpan(ctx context.Context, msg *LLMMessage, callDigest string) {
	// Each content block gets its own span, matching the provider streaming
	// behavior: thinking, text (LLM response), and tool calls each appear
	// separately. Contiguous runs of the same non-tool-call type are grouped.
	type spanGroup struct {
		kind   LLMContentBlockKind
		blocks []*LLMContentBlock
	}
	var groups []spanGroup
	for _, block := range msg.Content {
		// Tool calls always get their own span (one per call).
		if block.Kind == LLMContentToolCall {
			groups = append(groups, spanGroup{kind: block.Kind, blocks: []*LLMContentBlock{block}})
			continue
		}
		// Group contiguous thinking or text blocks together.
		if len(groups) > 0 && groups[len(groups)-1].kind == block.Kind {
			groups[len(groups)-1].blocks = append(groups[len(groups)-1].blocks, block)
		} else {
			groups = append(groups, spanGroup{kind: block.Kind, blocks: []*LLMContentBlock{block}})
		}
	}

	toolAnchorCtx := ctx
	for _, g := range groups {
		func() {
			var name string
			var extraAttrs []attribute.KeyValue
			var contentType string
			switch g.kind {
			case LLMContentThinking:
				name = "thinking"
				contentType = "text/markdown"
				extraAttrs = append(extraAttrs,
					attribute.String(telemetry.UIActorEmojiAttr, "💭"),
					attribute.String(telemetry.UIMessageAttr, telemetry.UIMessageReceived),
					attribute.Bool("llm.thinking", true),
				)
			case LLMContentToolCall:
				block := g.blocks[0]
				name = block.ToolName
				contentType = "application/json"
				var toolArgNames []string
				var toolArgValues []string
				var args map[string]any
				if len(block.Arguments) > 0 {
					if err := json.Unmarshal(block.Arguments.Bytes(), &args); err == nil {
						for _, name := range slices.Sorted(maps.Keys(args)) {
							val, ok := args[name]
							if !ok {
								continue
							}
							if str, ok := toolArgHeaderValue(name, val); ok {
								toolArgNames = append(toolArgNames, name)
								toolArgValues = append(toolArgValues, str)
							}
						}
					}
				}
				extraAttrs = append(extraAttrs,
					attribute.String(telemetry.UIActorEmojiAttr, "🤖"),
					attribute.Bool(telemetry.UIBoundaryAttr, true),
					attribute.String(telemetry.LLMToolAttr, block.ToolName),
					attribute.StringSlice(telemetry.LLMToolArgNamesAttr, toolArgNames),
					attribute.StringSlice(telemetry.LLMToolArgValuesAttr, toolArgValues),
				)
			default:
				name = "LLM response"
				contentType = "text/markdown"
				extraAttrs = append(extraAttrs,
					attribute.String(telemetry.UIActorEmojiAttr, "🤖"),
					attribute.String(telemetry.UIMessageAttr, telemetry.UIMessageReceived),
				)
			}
			attrs := []attribute.KeyValue{
				attribute.String(telemetry.LLMRoleAttr, telemetry.LLMRoleAssistant),
			}
			attrs = append(attrs, extraAttrs...)
			startCtx := ctx
			if g.kind == LLMContentToolCall {
				startCtx = toolAnchorCtx
			}
			attrs = append(attrs, genAIAgentAttrsFromContext(startCtx)...)
			if callDigest != "" {
				attrs = append(attrs, attribute.String(telemetryattrs.LLMCallDigestAttr, callDigest))
			}
			spanCtx, span := Tracer(startCtx).Start(startCtx, name, trace.WithAttributes(attrs...))
			if g.kind != LLMContentToolCall {
				toolAnchorCtx = spanCtx
			}
			defer span.End()
			stdio := telemetry.SpanStdio(spanCtx, InstrumentationLibrary,
				log.String(telemetry.ContentTypeAttr, contentType))
			defer stdio.Close()
			for _, block := range g.blocks {
				switch block.Kind {
				case LLMContentText, LLMContentThinking, LLMContentImage, LLMContentAudio, LLMContentDocument:
					emitContentLog(spanCtx, stdio.Stdout, block, "",
						log.String(telemetry.ContentTypeAttr, contentType))
				case LLMContentToolCall:
					fmt.Fprintln(stdio.Stdout, string(block.Arguments))
				}
			}
		}()
	}
}

// Transcript returns the message history as plain text suitable for LLM
// consumption (e.g. for summarization). Role-tagged lines, tool calls shown
// as function signatures, and tool results included inline.
func (llm *LLM) Transcript() string {
	var parts []string
	for _, msg := range llm.Messages {
		switch msg.Role {
		case LLMMessageRoleUser:
			for _, block := range msg.Content {
				switch block.Kind {
				case LLMContentToolResult:
					prefix := "[Tool result]"
					if block.Errored {
						prefix = "[Tool result ERROR]"
					}
					if text := block.ContentText(); text != "" {
						parts = append(parts, prefix+": "+text)
					}
				case LLMContentText, LLMContentImage, LLMContentAudio, LLMContentDocument:
					if text := block.ContentText(); text != "" {
						parts = append(parts, "[User]: "+text)
					}
				}
			}
		case LLMMessageRoleAssistant:
			var thinkingParts, textParts []string
			var toolCalls []string
			for _, block := range msg.Content {
				switch block.Kind {
				case LLMContentThinking:
					if block.Text != "" {
						thinkingParts = append(thinkingParts, block.Text)
					}
				case LLMContentText, LLMContentImage, LLMContentAudio, LLMContentDocument:
					if text := block.ContentText(); text != "" {
						textParts = append(textParts, text)
					}
				case LLMContentToolCall:
					toolCalls = append(toolCalls,
						fmt.Sprintf("%s(%s)", block.ToolName, string(block.Arguments)))
				}
			}
			if len(thinkingParts) > 0 {
				parts = append(parts, "[Assistant thinking]: "+strings.Join(thinkingParts, "\n"))
			}
			if len(textParts) > 0 {
				parts = append(parts, "[Assistant]: "+strings.Join(textParts, "\n"))
			}
			if len(toolCalls) > 0 {
				parts = append(parts, "[Assistant tool calls]: "+strings.Join(toolCalls, "; "))
			}
		case LLMMessageRoleSystem:
			// System prompts are omitted from serialization
		}
	}
	return strings.Join(parts, "\n\n")
}

func (llm *LLM) WithWorkspace(ws dagql.ObjectResult[*Workspace]) *LLM {
	llm = llm.Clone()
	llm.mcp.workspace = ws
	return llm
}

func (llm *LLM) Workspace() dagql.ObjectResult[*Workspace] {
	return llm.mcp.workspace
}

// Artifacts returns the conversation's artifact scope; see MCP.Artifacts.
func (llm *LLM) Artifacts(ctx context.Context, srv *dagql.Server, include []string) (*Artifacts, error) {
	return llm.mcp.Artifacts(ctx, srv, include)
}

// A variable in the LLM environment
type LLMVariable struct {
	// The name of the variable
	Name string `field:"true"`
	// The type name of the variable's value
	TypeName string `field:"true"`
	// A hash of the variable's value, used to detect changes
	Hash string `field:"true"`
}

var _ dagql.Typed = (*LLMVariable)(nil)
var _ dagql.PersistedObject = (*LLMVariable)(nil)
var _ dagql.PersistedObjectDecoder = (*LLMVariable)(nil)

func (v *LLMVariable) Type() *ast.Type {
	return &ast.Type{
		NamedType: "LLMVariable",
		NonNull:   true,
	}
}

func (v *LLMVariable) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	_ = ctx
	_ = enc
	if v == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted LLM variable: nil LLM variable")
	}
	return encodePersistedObjectPayload(v)
}

func (*LLMVariable) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	_ = ctx
	_ = dec
	var v LLMVariable
	if err := json.Unmarshal(payload, &v); err != nil {
		return nil, fmt.Errorf("decode persisted LLM variable payload: %w", err)
	}
	return &v, nil
}

func (llm *LLM) TokenUsage(ctx context.Context, dag *dagql.Server) (*LLMTokenUsage, error) {
	var res LLMTokenUsage
	for _, msg := range llm.Messages {
		if msg.TokenUsage == nil {
			continue
		}
		res.InputTokens += msg.TokenUsage.InputTokens
		res.OutputTokens += msg.TokenUsage.OutputTokens
		res.CachedTokenReads += msg.TokenUsage.CachedTokenReads
		res.CachedTokenWrites += msg.TokenUsage.CachedTokenWrites
		res.TotalTokens += msg.TokenUsage.TotalTokens
	}
	return &res, nil
}

// ContextTokens returns the estimated number of tokens currently occupying the
// context window. Unlike TokenUsage, this is not cumulative over the whole
// session: it uses the last provider-reported assistant usage as a baseline and
// estimates any trailing messages (for example tool results) that have been
// appended since that response and will be sent with the next request.
func (llm *LLM) ContextTokens(ctx context.Context, dag *dagql.Server) (int, error) {
	_ = dag
	messages, err := llm.messagesWithSystemPrompt(ctx)
	if err != nil {
		return 0, err
	}
	return int(estimateOccupiedContextTokens(messages)), nil
}

func estimateOccupiedContextTokens(messages []*LLMMessage) int64 {
	lastUsageIndex := -1
	var tokens int64
	for i := len(messages) - 1; i >= 0; i-- {
		usage := messages[i].TokenUsage
		if usage != nil && usage.hasTokens() {
			lastUsageIndex = i
			tokens = usage.contextTokens()
			break
		}
	}

	for i := lastUsageIndex + 1; i < len(messages); i++ {
		tokens += messages[i].estimateTokens()
	}
	return tokens
}
