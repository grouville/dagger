package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"github.com/containerd/containerd/v2/core/mount"
	"github.com/containerd/continuity/fs"
	"github.com/dagger/dagger/dagql"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	bkclient "github.com/dagger/dagger/internal/buildkit/client"
	"github.com/dagger/dagger/util/gitutil"
	telemetry "github.com/dagger/otel-go"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
)

type LocalGitRepository struct {
	Directory    dagql.ObjectResult[*Directory]
	CheckoutBase *GitCheckoutBase
	// HistorySource is the exact authorized remote anchor of owned shallow
	// storage. Descendant commits retain one capability, not an ancestry chain.
	HistorySource dagql.ObjectResult[*GitRef]
	// Upstream is the remote repository this storage was derived from, with
	// the authentication and service bindings it was constructed with. Owned
	// storage only carries the history it was built from; names it does not
	// contain resolve (and fetch) through Upstream instead. Upstream never
	// contributes objects to this storage and is never a donor: it is the
	// same capability the caller already held, retained for name resolution.
	Upstream dagql.ObjectResult[*GitRepository]
}

// GitUpstream returns the remote repository that storage derived from repo
// should retain as its Upstream: repo itself when it is remote, the retained
// Upstream when it is owned storage, and nothing otherwise.
func GitUpstream(repo dagql.ObjectResult[*GitRepository]) dagql.ObjectResult[*GitRepository] {
	if repo.Self() == nil {
		return dagql.ObjectResult[*GitRepository]{}
	}
	switch backend := repo.Self().Backend.(type) {
	case *RemoteGitRepository:
		return repo
	case *LocalGitRepository:
		return backend.Upstream
	}
	return dagql.ObjectResult[*GitRepository]{}
}

func (repo *LocalGitRepository) validateUpstream() error {
	if repo.Upstream.Self() == nil {
		return nil
	}
	if _, ok := repo.Upstream.Self().Backend.(*RemoteGitRepository); !ok {
		return fmt.Errorf("git repository upstream must be a remote repository, got %T", repo.Upstream.Self().Backend)
	}
	return nil
}

// GitCheckoutBase retains the exact canonical recipe of a checked commit's
// parent (GitRef.withCommit) or, for a pull, of an ancestor it was built on.
// It is a DAG dependency, never a mounted path or a dirty worktree baseline.
type GitCheckoutBase struct {
	Parent    dagql.ObjectResult[*GitRef]
	CommitSHA string
	// Remote parents additionally pin their exact evaluated canonical tree.
	// Reusing it must never require another fetch after mirror/cache eviction.
	Tree dagql.ObjectResult[*Directory]
}

// validateTree checks the producer recipe, not filesystem equality. Completed
// Directories may retain only snapshot-backed evaluation state after restart;
// their call frame still proves the exact parent and source-only tree selector.
func (base *GitCheckoutBase) validateTree(ctx context.Context) error {
	if base == nil || base.Tree.Self() == nil {
		return nil
	}
	frame, err := base.Tree.ResultCall()
	if err != nil {
		return err
	}
	if frame == nil || frame.Field != "tree" || frame.Receiver == nil {
		return fmt.Errorf("git checkout base tree must be the canonical parent tree")
	}
	discard := false
	for _, arg := range frame.Args {
		if arg.Name == "discardGitDir" && arg.Value != nil && arg.Value.Kind == dagql.ResultCallLiteralKindBool {
			discard = arg.Value.BoolValue
		}
	}
	if !discard {
		return fmt.Errorf("git checkout base tree must discard Git metadata")
	}
	receiver, err := frame.ReceiverCall(ctx)
	if err != nil {
		return err
	}
	if receiver == nil {
		return fmt.Errorf("git checkout base tree has no parent recipe")
	}
	got, err := receiver.RecipeDigest(ctx)
	if err != nil {
		return err
	}
	want, err := base.Parent.RecipeDigest(ctx)
	if err != nil {
		return err
	}
	if got != want {
		return fmt.Errorf("git checkout base tree has a different parent recipe")
	}
	return nil
}

// provenTree returns Tree only when validateTree accepts it. The engine cache
// may answer tree() on a content-equivalent GitRef (keepGitDir, service hosts
// and known hosts are outside its content digest) with another recipe's result
// and frame. Such a tree cannot prove this parent, so it is dropped rather than
// failing the repository: the parent provenance stays, and only the incremental
// checkout of a remote parent, which needs the pinned tree, falls back to a
// full checkout.
func (base *GitCheckoutBase) provenTree(ctx context.Context) dagql.ObjectResult[*Directory] {
	if base == nil || base.validateTree(ctx) != nil {
		return dagql.ObjectResult[*Directory]{}
	}
	return base.Tree
}

var _ GitRepositoryBackend = (*LocalGitRepository)(nil)

type LocalGitRef struct {
	*gitutil.Ref
	repo *LocalGitRepository
}

var _ GitRefBackend = (*LocalGitRef)(nil)

func (repo *LocalGitRepository) Get(ctx context.Context, ref *gitutil.Ref) (GitRefBackend, error) {
	return &LocalGitRef{
		Ref:  ref,
		repo: repo,
	}, nil
}

func (repo *LocalGitRepository) Remote(ctx context.Context) (*gitutil.Remote, error) {
	var remote *gitutil.Remote
	err := repo.mount(ctx, 0, false, nil, func(ctx context.Context, git *gitutil.GitCLI) error {
		gitURL, err := git.URL(ctx)
		if err != nil {
			return err
		}
		remote, err = gitutil.NewGitCLI().LsRemote(ctx, gitURL)
		return err
	})
	if err != nil {
		return nil, err
	}
	return remote, nil
}

// ResolveShortSHA expands an abbreviated commit SHA against the repository's
// authorized object database. The raw owned storage is tried first, so a prefix
// of the anchor or of the workspace's own commits never fetches the remote.
// Only when nothing matches there does owned shallow storage hydrate its
// complete history and retry; ambiguity and other local errors are final.
func (repo *LocalGitRepository) ResolveShortSHA(ctx context.Context, prefix string) (string, error) {
	sha, err := repo.resolveShortSHA(ctx, prefix)
	if err == nil || repo.HistorySource.Self() == nil || !errors.Is(err, gitutil.ErrShortSHANotFound) {
		return sha, err
	}
	complete, herr := repo.fullHistory(ctx)
	if herr != nil {
		return "", herr
	}
	if complete == repo {
		// No shallow boundary: the storage was already complete.
		return "", err
	}
	return complete.resolveShortSHA(ctx, prefix)
}

// resolveShortSHA resolves against this repository's raw storage only; it
// never hydrates.
func (repo *LocalGitRepository) resolveShortSHA(ctx context.Context, prefix string) (string, error) {
	var sha string
	err := repo.mount(ctx, 0, false, nil, func(ctx context.Context, git *gitutil.GitCLI) error {
		var err error
		sha, err = git.ResolveShortSHA(ctx, prefix)
		return err
	})
	if err != nil {
		return "", err
	}
	return sha, nil
}

// HasCommit reports whether the repository's raw storage contains the commit.
// It never hydrates: a commit beyond an owned shallow boundary is absent.
func (repo *LocalGitRepository) HasCommit(ctx context.Context, sha string) (bool, error) {
	var has bool
	err := repo.mount(ctx, 0, false, nil, func(ctx context.Context, git *gitutil.GitCLI) error {
		// --quiet: a missing commit is an answer, not an error worth logging.
		out, err := git.New(gitutil.WithIgnoreError()).Run(ctx, "rev-parse", "--verify", "--quiet", sha+"^{commit}")
		if err != nil {
			return err
		}
		has = strings.EqualFold(strings.TrimSpace(string(out)), sha)
		return nil
	})
	return has, err
}

func (repo *LocalGitRepository) File(ctx context.Context, filename string) (*File, error) {
	var gitDir string
	err := repo.mount(ctx, 0, false, nil, func(ctx context.Context, git *gitutil.GitCLI) error {
		dir, err := git.GitDir(ctx)
		if err != nil {
			return err
		}
		if filepath.IsAbs(dir) {
			dir, err = filepath.Rel(dir, git.Dir())
			if err != nil {
				return err
			}
		}
		gitDir = dir
		return nil
	})
	if err != nil {
		return nil, err
	}

	return repo.Directory.Self().Subfile(ctx, repo.Directory, filepath.Join(gitDir, filename))
}

func (repo *LocalGitRepository) Dirty(ctx context.Context) (inst dagql.ObjectResult[*Directory], rerr error) {
	return repo.Directory, nil
}

func (repo *LocalGitRepository) Cleaned(ctx context.Context) (inst dagql.ObjectResult[*Directory], rerr error) {
	srv := dagql.CurrentDagqlServer(ctx)
	query, err := CurrentQuery(ctx)
	if err != nil {
		return inst, err
	}
	dir := &Directory{Platform: query.Platform(), Dir: new(LazyAccessor[string, *Directory]), Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory])}
	unchanged, err := repo.cleanedInto(ctx, dir)
	if err != nil {
		return inst, err
	}
	if unchanged {
		return repo.Directory, nil
	}
	inst, err = dagql.NewObjectResultForCurrentCall(ctx, srv, dir)
	if err != nil {
		return inst, errors.Join(err, dir.OnRelease(context.WithoutCancel(ctx)))
	}
	return inst, nil
}

func (repo *LocalGitRepository) cleanedInto(ctx context.Context, dst *Directory) (unchanged bool, rerr error) {
	if err := validateLazyDirectoryReceiver(dst); err != nil {
		return false, err
	}
	query, err := CurrentQuery(ctx)
	if err != nil {
		return false, err
	}
	cache := query.SnapshotManager()

	parent, err := repo.Directory.Self().Snapshot.GetOrEval(ctx, repo.Directory.Result)
	if err != nil {
		return false, fmt.Errorf("get git directory snapshot: %w", err)
	}
	repoDirPath, err := repo.Directory.Self().Dir.GetOrEval(ctx, repo.Directory.Result)
	if err != nil {
		return false, fmt.Errorf("get git directory path: %w", err)
	}

	bkref, err := cache.New(ctx, parent,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription("git cleaned worktree"))

	if err != nil {
		return false, err
	}
	defer func() {
		if bkref != nil {
			rerr = errors.Join(rerr, bkref.Release(context.WithoutCancel(ctx)))
		}
	}()
	skip := false
	err = MountRef(ctx, bkref, func(parentRoot string, _ *mount.Mount) error {
		src, err := fs.RootPath(parentRoot, repoDirPath)
		if err != nil {
			return err
		}

		git := gitutil.NewGitCLI(gitutil.WithDir(src))
		worktree, err := git.WorkTree(ctx)
		if err != nil {
			return err
		}
		if worktree == "" {
			skip = true // no worktree, no changes
			return nil
		}
		gitDir, err := git.GitDir(ctx)
		if err != nil {
			return err
		}

		idx, err := os.Open(filepath.Join(gitDir, "index"))
		if err != nil {
			return err
		}
		defer idx.Close()

		// NOTE: apply the index to a temp file because "git restore --staged"
		// re-writes the index which we don't want to show up as a changed file
		// in the final result
		tmp, err := os.CreateTemp("", "dagger-git-index-")
		if err != nil {
			return err
		}
		return withTemporaryGitIndex(idx, tmp, func(indexPath string) error {
			return cleanGitWorktree(ctx, git.New(gitutil.WithIndexFile(indexPath)))
		})
	})
	if err != nil {
		return false, err
	}
	if skip {
		return true, nil
	}

	snap, err := bkref.Commit(ctx)
	if err != nil {
		return false, err
	}
	bkref = nil
	dst.SetPath(repoDirPath)
	dst.Services = slices.Clone(repo.Directory.Self().Services)
	dst.SetSnapshot(snap)
	return false, nil
}

// cleanGitWorktree resets git's index (a private copy: see cleanedInto) and
// worktree to HEAD and removes untracked files, keeping ignored ones.
func cleanGitWorktree(ctx context.Context, git *gitutil.GitCLI) error {
	// reset index to HEAD
	// NOTE: we cannot use "git reset --hard" because it writes every file,
	// which *kills* performance on overlayfs
	if _, err := git.Run(ctx, "restore", "--staged", "."); err != nil {
		return err
	}
	// Retained checkouts store an index without stat data
	// (finishGitCheckout and commits normalize it with read-tree), so restore
	// would find every entry changed and rewrite the whole worktree: seconds
	// on a large tree, and a copy of every file in the new layer. Refresh it
	// first. With no stat data to match, refresh compares every file's
	// content with its blob, so only files that really differ are restored.
	// Failing to refresh only loses the shortcut: restore rewrites what it
	// must.
	_, _ = git.New(gitutil.WithIgnoreError()).Run(ctx, "update-index", "-q", "--unmerged", "--refresh")
	if _, err := git.Run(ctx, "restore", "."); err != nil {
		return err
	}
	_, err := git.Run(ctx, "clean", "-fd")
	return err
}

// withTemporaryGitIndex owns the newly created index until the Git commands finish.
func withTemporaryGitIndex(idx io.Reader, tmp *os.File, run func(string) error) error {
	defer os.Remove(tmp.Name())
	if _, err := io.Copy(tmp, idx); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return run(tmp.Name())
}

func (repo *LocalGitRepository) mount(ctx context.Context, depth int, includeTags bool, refs []GitRefBackend, fn func(context.Context, *gitutil.GitCLI) error) error {
	// A nil refs list is a raw-storage request (identity, staging, validation).
	// Bundle/push/export callers explicitly request refs and complete history.
	if len(refs) > 0 && repo.HistorySource.Self() != nil {
		complete, err := repo.fullHistory(ctx)
		if err != nil {
			return err
		}
		return complete.mount(ctx, depth, includeTags, nil, fn)
	}
	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}
	svcs, err := query.Services(ctx)
	if err != nil {
		return fmt.Errorf("failed to get services: %w", err)
	}
	detach, _, err := svcs.StartBindings(ctx, repo.Directory.Self().Services)
	if err != nil {
		return err
	}
	defer detach()

	ref, err := repo.Directory.Self().Snapshot.GetOrEval(ctx, repo.Directory.Result)
	if err != nil {
		return err
	}
	repoDirPath, err := repo.Directory.Self().Dir.GetOrEval(ctx, repo.Directory.Result)
	if err != nil {
		return err
	}

	return MountRef(ctx, ref, func(root string, _ *mount.Mount) error {
		src, err := fs.RootPath(root, repoDirPath)
		if err != nil {
			return err
		}

		git := gitutil.NewGitCLI(gitutil.WithDir(src))
		return fn(ctx, git)
	}, mountRefAsReadOnly)
}

func (ref *LocalGitRef) mount(ctx context.Context, depth int, includeTags bool, fn func(context.Context, *gitutil.GitCLI) error) error {
	return ref.mountHistory(ctx, depth, includeTags, fn)
}

// readGitConfigRemotes reads configured names in configuration order, then
// asks Git for their effective fetch and push URLs. Git applies URL rewrites
// and selects the first URL when a remote has several destinations.
func readGitConfigRemotes(ctx context.Context, git *gitutil.GitCLI) ([]GitRemote, error) {
	out, err := git.New(gitutil.WithIgnoreError()).Run(ctx, "config", "-z", "--get-regexp", `^remote\.`)
	if err != nil {
		return nil, err
	}
	byName := map[string]*GitRemote{}
	var order []string
	for _, entry := range strings.Split(string(out), "\x00") {
		key, value, ok := strings.Cut(entry, "\n")
		if !ok {
			continue
		}
		rest, isRemote := strings.CutPrefix(key, "remote.")
		if !isRemote {
			continue
		}
		// Suffix-first parsing keeps remote names containing dots intact.
		var name, attr string
		if n, isURL := strings.CutSuffix(rest, ".url"); isURL {
			name, attr = n, "url"
		} else if n, isPush := strings.CutSuffix(rest, ".pushurl"); isPush {
			name, attr = n, "pushurl"
		} else {
			continue
		}
		if name == "" || value == "" {
			continue
		}
		remote, ok := byName[name]
		if !ok {
			remote = &GitRemote{Name: name}
			byName[name] = remote
			order = append(order, name)
		}
		switch attr {
		case "url":
			remote.URL = value
		case "pushurl":
			// Git pushes to every configured pushurl; only the first one is
			// retained here, since a push routes to one destination.
			if remote.PushURL == "" {
				remote.PushURL = value
			}
		}
	}
	remotes := make([]GitRemote, 0, len(order))
	for _, name := range order {
		remote, err := resolveGitConfigRemote(ctx, git, *byName[name])
		if err != nil {
			return nil, err
		}
		remotes = append(remotes, remote)
	}
	return remotes, nil
}

func resolveGitConfigRemote(ctx context.Context, git *gitutil.GitCLI, remote GitRemote) (GitRemote, error) {
	if remote.URL != "" {
		out, err := git.Run(ctx, "remote", "get-url", "--", remote.Name)
		if err != nil {
			return GitRemote{}, fmt.Errorf("read remote %q fetch URL: %w", remote.Name, err)
		}
		remote.URL = strings.TrimSuffix(string(out), "\n")
	}
	out, err := git.Run(ctx, "remote", "get-url", "--push", "--", remote.Name)
	if err != nil {
		return GitRemote{}, fmt.Errorf("read remote %q push URL: %w", remote.Name, err)
	}
	pushURL := strings.TrimSuffix(string(out), "\n")
	if remote.PushURL != "" || pushURL != remote.URL {
		remote.PushURL = pushURL
	}
	return remote, nil
}

func (ref *LocalGitRef) Tree(ctx context.Context, srv *dagql.Server, discardGitDir bool, depth int, includeTags bool, remotes []GitRemote, upstreamRemote *string) (_ *Directory, rerr error) {
	if discardGitDir {
		var finish func(path, detail string, skipped []string, err error)
		ctx, finish = startGitSourceTree(ctx)
		path, detail, skipped := "full", "", []string(nil)
		defer func() { finish(path, detail, skipped, rerr) }()
		if reason := ref.incrementalCheckoutIneligible(); reason != "" {
			skipped = append(skipped, "incremental="+reason)
		} else {
			dir, supported, reason, err := ref.incrementalTree(ctx, srv)
			if err != nil || supported {
				path, detail = "incremental", "base="+reason
				return dir, err
			}
			skipped = append(skipped, "incremental="+reason)
		}
		dir, supported, reason, err := ref.contentsCheckoutTree(ctx, srv)
		if err != nil || supported {
			path, detail = "checkout", reason
			return dir, err
		}
		skipped = append(skipped, "checkout="+reason)
	}
	if !discardGitDir && depth <= 0 {
		dir, supported, err := ref.cowTree(ctx, srv, remotes, upstreamRemote)
		if err != nil || supported {
			return dir, err
		}
	}
	ctx, span := Tracer(ctx).Start(ctx, "materialize local git checkout", telemetry.Internal(), trace.WithAttributes(
		attribute.Int("dagger.git.checkout.depth", depth),
		attribute.Bool("dagger.git.checkout.discard_git_dir", discardGitDir),
	))
	defer telemetry.EndWithCause(span, &rerr)
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	cache := query.SnapshotManager()

	bkref, err := cache.New(ctx, nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription(fmt.Sprintf("git local checkout (%s %s)", ref.Ref.Name, ref.Ref.SHA)))
	if err != nil {
		return nil, err
	}
	defer func() {
		if rerr != nil && bkref != nil {
			bkref.Release(context.WithoutCancel(ctx))
		}
	}()

	mountDepth := depth
	if discardGitDir {
		mountDepth = 1
	}
	err = ref.mount(ctx, mountDepth, includeTags, func(ctx context.Context, git *gitutil.GitCLI) error {
		gitURL, err := git.URL(ctx)
		if err != nil {
			return fmt.Errorf("could not find git url: %w", err)
		}

		checkoutRemotes, upstream, err := localCheckoutRemotes(ctx, git, ref.Ref.Name, remotes, upstreamRemote)
		if err != nil {
			return err
		}

		return MountRef(ctx, bkref, func(checkoutDir string, _ *mount.Mount) error {
			checkoutDirGit := filepath.Join(checkoutDir, ".git")
			if err := os.MkdirAll(checkoutDir, 0711); err != nil {
				return err
			}
			checkoutGit := git.New(
				gitutil.WithDir(checkoutDir),
				gitutil.WithWorkTree(checkoutDir),
				gitutil.WithGitDir(checkoutDirGit),
			)
			if discardGitDir {
				return doLocalGitTreeCheckout(ctx, git, checkoutGit, checkoutRemotes, gitURL, ref.Ref)
			}
			if err := doGitCheckout(ctx, checkoutGit, checkoutRemotes, gitURL, ref.Ref, depth, false); err != nil {
				return err
			}
			return writeGitRemoteSelection(ctx, checkoutGit, checkoutRemotes, upstream)
		})
	})
	if err != nil {
		return nil, fmt.Errorf("failed to checkout %s: %w", ref.Ref.Name, err)
	}

	snap, err := bkref.Commit(ctx)
	if err != nil {
		return nil, err
	}
	bkref = nil
	dir := &Directory{
		Platform: query.Platform(),
		Dir:      new(LazyAccessor[string, *Directory]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
	}
	dir.SetPath("/")
	dir.SetSnapshot(snap)
	return dir, nil
}

// localCheckoutRemotes selects the remote configuration a retained checkout
// of the named ref carries. The checkout is rebuilt rather than copied, which
// would drop the source repository's remotes. Carry its remote configuration
// over -- with any remotes registered on the repository object overlaid -- so
// remote-aware tooling (gh, git fetch) keeps resolving the repository from the
// result; the checkout itself never fetches from those remotes.
func localCheckoutRemotes(ctx context.Context, git *gitutil.GitCLI, name string, remotes []GitRemote, upstreamRemote *string) ([]GitRemote, string, error) {
	if upstreamRemote != nil {
		return MergeGitRemotes(nil, remotes), *upstreamRemote, nil
	}
	configRemotes, err := readGitConfigRemotes(ctx, git)
	if err != nil {
		return nil, "", fmt.Errorf("could not read remotes: %w", err)
	}
	upstream, err := gitBranchUpstream(ctx, git, name)
	if err != nil {
		return nil, "", err
	}
	return MergeGitRemotes(configRemotes, remotes), upstream, nil
}

// doLocalGitTreeCheckout borrows the mounted source's objects while creating a
// tree without .git. No history is copied or fetched: depth and tag selection
// cannot affect the resulting worktree. The source must remain mounted until
// this returns, including submodule materialization and removal of .git (and
// the temporary alternates file). Retained checkouts still use doGitCheckout
// so that they are self-contained after the source mount is released.
func doLocalGitTreeCheckout(ctx context.Context, source, checkout *gitutil.GitCLI, remotes []GitRemote, cloneURL string, ref *gitutil.Ref) error {
	if err := initLocalGitTreeCheckout(ctx, source, checkout); err != nil {
		return err
	}
	return finishGitCheckout(ctx, checkout, remotes, cloneURL, ref, true, "", gitCheckoutFresh)
}

func initLocalGitTreeCheckout(ctx context.Context, source, checkout *gitutil.GitCLI) error {
	format, err := source.Run(ctx, "rev-parse", "--show-object-format")
	if err != nil {
		return fmt.Errorf("read local git object format: %w", err)
	}
	// Resolve through Git, not .git/objects: linked worktrees keep objects in
	// their common directory. Git also follows any source alternates itself.
	objects, err := source.Run(ctx, "rev-parse", "--path-format=absolute", "--git-path", "objects")
	if err != nil {
		return fmt.Errorf("resolve local git objects: %w", err)
	}
	if _, err := checkout.Run(ctx, "-c", "init.defaultBranch=main", "init", "--object-format="+strings.TrimSpace(string(format))); err != nil {
		return err
	}
	gitDir, err := checkout.GitDir(ctx)
	if err != nil {
		return err
	}
	shallow, err := source.Run(ctx, "rev-parse", "--path-format=absolute", "--git-path", "shallow")
	if err != nil {
		return err
	}
	if err := copyGitShallowBoundary(filepath.Dir(strings.TrimSuffix(string(shallow), "\n")), gitDir); err != nil {
		return err
	}
	// Remove only Git's output terminator: whitespace can be part of a path.
	objectPath := strings.TrimSuffix(string(objects), "\n")
	if err := writeGitAlternates(filepath.Join(gitDir, "objects"), []string{objectPath}); err != nil {
		return fmt.Errorf("write local git checkout alternates: %w", err)
	}
	return nil
}

const persistedDirectoryLazyKindGitCleaned = "gitCleaned"

type DirectoryGitCleanedLazy struct {
	LazyState
	Repo dagql.ObjectResult[*GitRepository]
}

type persistedDirectoryGitCleanedLazy struct {
	RepoResultID uint64 `json:"repoResultID"`
}

func (p *persistedDirectoryGitCleanedLazy) validate() error {
	if p.RepoResultID == 0 {
		return fmt.Errorf("DirectoryGitCleanedLazy: missing repoResultID")
	}
	return nil
}

var errGitCleanedUnchanged = errors.New("git cleaned input has no worktree")

func (lazy *DirectoryGitCleanedLazy) Evaluate(ctx context.Context, dir *Directory) error {
	err := lazy.evaluate(ctx, dir)
	if errors.Is(err, errGitCleanedUnchanged) {
		return fmt.Errorf("git cleaned operation: saved input has no worktree")
	}
	return err
}

// EvaluateForCall preserves the no-worktree alias before publishing this shell.
func (lazy *DirectoryGitCleanedLazy) EvaluateForCall(ctx context.Context, dir *Directory) (bool, error) {
	err := lazy.evaluate(ctx, dir)
	if errors.Is(err, errGitCleanedUnchanged) {
		return true, nil
	}
	return false, err
}

func (lazy *DirectoryGitCleanedLazy) evaluate(ctx context.Context, dir *Directory) error {
	return dir.evaluateLazy(ctx, &lazy.LazyState, "GitRepository.__cleaned", func(ctx context.Context) error {
		if err := validateLazyDirectoryReceiver(dir); err != nil {
			return err
		}
		if lazy.Repo.Self() == nil {
			return fmt.Errorf("git cleaned operation: missing Repo")
		}
		local, ok := lazy.Repo.Self().Backend.(*LocalGitRepository)
		if !ok {
			return fmt.Errorf("git cleaned operation: Repo is not local")
		}
		unchanged, err := local.cleanedInto(ctx, dir)
		if err != nil {
			return err
		}
		if unchanged {
			return errGitCleanedUnchanged
		}
		return nil
	})
}
func (lazy *DirectoryGitCleanedLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	repo, err := attachLazyInput(attach, lazy.Repo, "DirectoryGitCleanedLazy.Repo")
	if err != nil {
		return nil, err
	}
	lazy.Repo = repo
	return []dagql.AnyResult{repo}, nil
}
func (lazy *DirectoryGitCleanedLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	repoID, err := encodePersistedObjectRef(enc, lazy.Repo, "DirectoryGitCleanedLazy.Repo")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedDirectoryGitCleanedLazy{RepoResultID: repoID})
}
func decodeDirectoryGitCleanedLazy(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (Lazy[*Directory], error) {
	var p persistedDirectoryGitCleanedLazy
	if err := json.Unmarshal(payload, &p); err != nil {
		return nil, fmt.Errorf("decode DirectoryGitCleanedLazy: %w", err)
	}
	if err := p.validate(); err != nil {
		return nil, err
	}
	repo, err := loadPersistedObjectResultByResultID[*GitRepository](ctx, dec, p.RepoResultID, "DirectoryGitCleanedLazy.Repo")
	if err != nil {
		return nil, err
	}
	return &DirectoryGitCleanedLazy{LazyState: NewLazyState(), Repo: repo}, nil
}
