package schema

import (
	"cmp"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path"
	"path/filepath"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/containerd/platforms"
	"github.com/dagger/dagger/util/hashutil"
	telemetry "github.com/dagger/otel-go"
	"github.com/distribution/reference"
	dockerspec "github.com/moby/docker-image-spec/specs-go/v1"
	"github.com/opencontainers/go-digest"
	"github.com/vektah/gqlparser/v2/ast"
	"golang.org/x/sync/errgroup"

	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/core/workspace"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine"
	"github.com/dagger/dagger/engine/engineutil"
	serverresolver "github.com/dagger/dagger/engine/server/resolver"
	"github.com/dagger/dagger/engine/slog"
	bkcache "github.com/dagger/dagger/engine/snapshots"
)

type containerSchema struct{}

var _ SchemaResolvers = &containerSchema{}

func (s *containerSchema) Install(srv *dagql.Server) {
	srv.InstallObject(dagql.NewClass[core.Command](srv).View(AfterVersion("v1.0.0-0")))
	dagql.Fields[core.Command]{}.Install(srv)

	dagql.Fields[*core.Query]{
		dagql.FuncWithDynamicInputs("container", s.container, s.containerDynamicInputs).
			Doc(`Creates a scratch container, with no image or metadata.`,
				`To pull an image, follow up with the "from" function.`).
			Args(
				dagql.Arg("platform").Doc(`Platform to initialize the container with. Defaults to the native platform of the current engine`),
			),
	}.Install(srv)

	dagql.Fields[*core.Container]{
		Syncer[*core.Container]().
			Doc(`Forces evaluation of the pipeline in the engine.`,
				`It doesn't run the default command if no exec has been set.`),

		dagql.Func("pipeline", s.pipeline).
			View(BeforeVersion("v0.13.0")).
			Deprecated("Explicit pipeline creation is now a no-op").
			Doc(`Creates a named sub-pipeline.`).
			Args(
				dagql.Arg("name").Doc("Name of the sub-pipeline."),
				dagql.Arg("description").Doc("Description of the sub-pipeline."),
				dagql.Arg("labels").Doc("Labels to apply to the sub-pipeline."),
			),

		dagql.NodeFunc("from", s.from).
			IsPersistable().
			WithInput(fromSessionScopeInput).
			Doc(`Download a container image, and apply it to the container state. All previous state will be lost.`).
			Args(
				dagql.Arg("address").Doc(
					`Address of the container image to download, in standard OCI ref format. Example: "registry.dagger.io/engine:latest".`,
					`An address without a tag or digest selects the greatest stable release tag, falling back to the literal "latest" tag when no eligible release exists.`,
				),
				dagql.Arg("version").
					Doc(`Version query used to select an image tag. The address must not contain a tag or digest.`).
					View(AfterVersion(workspace.VersionQueriesVersion)),
				dagql.Arg("registryService").Doc(
					`Service to use as the registry endpoint for the image address.`,
					`The service will be started only for this pull.`).
					View(AfterVersion("v0.21.6")),
				dagql.Arg("protocol").Doc(
					`Protocol to use for registry communication.`,
					`Defaults to "HTTPS". Use "HTTP" only for plain HTTP registries.`).
					View(AfterVersion("v1.0.0-0")),
				dagql.Arg("insecureSkipTLSVerify").Doc(`Allow HTTPS registry communication without verifying the server certificate.`).
					View(AfterVersion("v1.0.0-0")),
				dagql.Arg("noLock").
					View(AfterVersion("v1.0.0-beta.15")).
					Doc(`Ignore the workspace lockfile for this lookup.`),
			),
		dagql.NodeFunc("build", s.build).
			View(BeforeVersion("v0.19.0")).
			Deprecated("Use `Directory.build` instead").
			Doc(`Initializes this container from a Dockerfile build.`).
			Args(
				dagql.Arg("context").Doc("Directory context used by the Dockerfile."),
				dagql.Arg("dockerfile").Doc("Path to the Dockerfile to use."),
				dagql.Arg("target").Doc("Target build stage to build."),
				dagql.Arg("buildArgs").Doc("Additional build arguments."),
				dagql.Arg("secrets").Doc(`Secrets to pass to the build.`,
					`They will be mounted at /run/secrets/[secret-name] in the build container`,
					`They can be accessed in the Dockerfile using the "secret" mount type
					and mount path /run/secrets/[secret-name], e.g. RUN
					--mount=type=secret,id=my-secret curl [http://example.com?token=$(cat
					/run/secrets/my-secret)](http://example.com?token=$(cat
						/run/secrets/my-secret))`),
				dagql.Arg("noInit").Doc(`If set, skip the automatic init process injected into containers created by RUN statements.`,
					`This should only be used if the user requires that their exec processes be the
					pid 1 process in the container. Otherwise it may result in unexpected behavior.`,
				),
			),

		dagql.NodeFunc("rootfs", s.rootfs).
			Doc(`Return a snapshot of the container's root filesystem. The snapshot can be modified then written back using withRootfs. Use that method for filesystem modifications.`),
		dagql.NodeFunc("withRootfs", s.withRootfs).
			Doc(`Change the container's root filesystem. The previous root filesystem will be lost.`).
			Args(
				dagql.Arg("directory").Doc("The new root filesystem."),
			),
		dagql.NodeFunc("directory", s.directory).
			Doc(`Retrieve a directory from the container's root filesystem`,
				`Mounts are included.`).
			Args(
				dagql.Arg("path").Doc(`The path of the directory to retrieve (e.g., "./src").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("file", s.file).
			Doc(`Retrieves a file at the given path.`, `Mounts are included.`).
			Args(
				dagql.Arg("path").Doc(`The path of the file to retrieve (e.g., "./README.md").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),

		dagql.NodeFunc("user", s.user).
			Doc("Retrieves the user to be set for all commands."),

		dagql.NodeFunc("withUser", s.withUser).
			Doc(`Retrieves this container with a different command user.`).
			Args(
				dagql.Arg("name").Doc(`The user to set (e.g., "root").`),
			),

		dagql.NodeFunc("withoutUser", s.withoutUser).
			Doc(`Retrieves this container with an unset command user.`,
				`Should default to root.`),

		dagql.NodeFunc("workdir", s.workdir).
			Doc("Retrieves the working directory for all commands."),

		dagql.NodeFunc("withWorkdir", s.withWorkdir).
			Doc(`Change the container's working directory. Like WORKDIR in Dockerfile.`).
			Args(
				dagql.Arg("path").Doc(`The path to set as the working directory (e.g., "/app").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withoutWorkdir", s.withoutWorkdir).
			Doc(`Unset the container's working directory.`,
				`Should default to "/".`),

		dagql.NodeFunc("envVariables", s.envVariables).
			Doc(`Retrieves the list of persistent environment variables configured on the container.`),

		dagql.NodeFunc("envVariable", s.envVariable).
			Doc(`Retrieves the value of the specified persistent environment variable.`).
			Args(
				dagql.Arg("name").Doc(`The name of the environment variable to retrieve (e.g., "PATH").`),
			),

		dagql.NodeFunc("withEnvVariable", s.withEnvVariable).
			Doc(`Set a new environment variable in the container.`).
			Args(
				dagql.Arg("name").Doc(`Name of the environment variable (e.g., "HOST").`),
				dagql.Arg("value").Doc(`Value of the environment variable. (e.g., "localhost").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value according to the current `+
					`environment variables defined in the container (e.g. "/opt/bin:$PATH").`),
			),

		dagql.NodeFunc("withEnvFileVariables", s.withEnvFileVariables).
			Doc(`Export environment variables from an env-file to the container.`).
			Args(
				dagql.Arg("source").Doc(`Identifier of the envfile`),
			),

		// NOTE: this is internal-only for now (hidden from codegen via the __ prefix) as we
		// currently only want to use it for allowing the Go SDK to inherit custom GOPROXY
		// settings from the engine container. It may be made public in the future with more
		// refined design.
		dagql.NodeFunc("__withSystemEnvVariable", s.withSystemEnvVariable).
			Doc(`(Internal-only) Inherit this environment variable from the engine container if set there with a special prefix.`),

		// NOTE: this is internal-only (hidden from codegen via the __ prefix). It exists so
		// llbtodagger can faithfully apply Docker image config metadata fields that do not yet
		// have public SDK methods.
		dagql.NodeFunc("__withImageConfigMetadata", func(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithImageConfigMetadataArgs) (*core.Container, error) {
			ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
			if err != nil {
				return nil, err
			}
			ctr, err = s.withImageConfigMetadata(ctx, ctr, args)
			if err != nil {
				return nil, err
			}
			var healthcheck *dockerspec.HealthcheckConfig
			if ctr.Config.Healthcheck != nil {
				hc := *ctr.Config.Healthcheck
				hc.Test = slices.Clone(ctr.Config.Healthcheck.Test)
				healthcheck = &hc
			}
			volumes := make([]string, 0, len(ctr.Config.Volumes))
			for volume := range ctr.Config.Volumes {
				volumes = append(volumes, volume)
			}
			ctr.Lazy = &core.ContainerWithImageConfigMetadataLazy{
				LazyState:   core.NewLazyState(),
				Parent:      parent,
				Healthcheck: healthcheck,
				OnBuild:     slices.Clone(ctr.Config.OnBuild),
				Shell:       slices.Clone(ctr.Config.Shell),
				Volumes:     volumes,
				StopSignal:  ctr.Config.StopSignal,
			}
			if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
				return nil, err
			}
			return ctr, nil
		}).
			Doc(`(Internal-only) Set Docker image config metadata fields not yet exposed as public container APIs.`).
			Args(
				dagql.Arg("healthcheck").Doc(`JSON-encoded Docker HealthcheckConfig.`),
				dagql.Arg("onBuild").Doc(`Docker ONBUILD trigger list.`),
				dagql.Arg("shell").Doc(`Docker shell override for shell-form instructions.`),
				dagql.Arg("volumes").Doc(`Docker image config volume mountpoints.`),
				dagql.Arg("stopSignal").Doc(`Docker image config stop signal.`),
			),

		dagql.NodeFunc("withSecretVariable", s.withSecretVariable).
			Doc(`Set a new environment variable, using a secret value`).
			Args(
				dagql.Arg("name").Doc(`Name of the secret variable (e.g., "API_SECRET").`),
				dagql.Arg("secret").Doc(`Identifier of the secret value.`),
			),

		dagql.NodeFunc("withVolatileVariable", s.withVolatileVariable).
			View(AfterVersion("v0.21.4")).
			WithInput(dagql.PerSessionInput).
			Doc(`Set a new non-secret environment variable for future execs without invalidating exec cache when only its value changes.`,
				`This is an expert-only escape hatch. If a volatile value affects observable exec results, stale cached results may be reused.`).
			Args(
				dagql.Arg("name").Doc(`Name of the volatile variable (e.g., "CI_RUN_ID").`),
				dagql.Arg("value").Doc(`Value of the volatile variable.`),
			),

		dagql.NodeFunc("withoutEnvVariable", s.withoutEnvVariable).
			Doc(`Retrieves this container minus the given environment variable.`).
			Args(
				dagql.Arg("name").Doc(`The name of the environment variable (e.g., "HOST").`),
			),

		dagql.NodeFunc("withoutSecretVariable", s.withoutSecretVariable).
			Doc(`Retrieves this container minus the given environment variable containing the secret.`).
			Args(
				dagql.Arg("name").Doc(`The name of the environment variable (e.g., "HOST").`),
			),

		dagql.NodeFunc("withoutVolatileVariable", s.withoutVolatileVariable).
			View(AfterVersion("v0.21.4")).
			Doc(`Retrieves this container minus the given volatile environment variable.`).
			Args(
				dagql.Arg("name").Doc(`The name of the volatile environment variable (e.g., "CI_RUN_ID").`),
			),

		dagql.NodeFunc("withLabel", s.withLabel).
			Doc(`Retrieves this container plus the given label.`).
			Args(
				dagql.Arg("name").Doc(`The name of the label (e.g., "org.opencontainers.artifact.created").`),
				dagql.Arg("value").Doc(`The value of the label (e.g., "2023-01-01T00:00:00Z").`),
			),

		dagql.NodeFunc("label", s.label).
			Doc(`Retrieves the value of the specified label.`).
			Args(
				dagql.Arg("name").Doc(`The name of the label (e.g., "org.opencontainers.artifact.created").`),
			),

		dagql.NodeFunc("labels", s.labels).
			Doc(`Retrieves the list of labels passed to container.`),

		dagql.NodeFunc("withoutLabel", s.withoutLabel).
			Doc(`Retrieves this container minus the given environment label.`).
			Args(
				dagql.Arg("name").Doc(`The name of the label to remove (e.g., "org.opencontainers.artifact.created").`),
			),

		dagql.NodeFunc("withDockerHealthcheck", func(ctx context.Context, parent dagql.ObjectResult[*core.Container], args WithHealthcheckArgs) (*core.Container, error) {
			ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
			if err != nil {
				return nil, err
			}
			ctr, err = s.withHealthcheck(ctx, ctr, args)
			if err != nil {
				return nil, err
			}
			hc := *ctr.Config.Healthcheck
			hc.Test = slices.Clone(ctr.Config.Healthcheck.Test)
			ctr.Lazy = &core.ContainerWithHealthcheckLazy{
				LazyState:   core.NewLazyState(),
				Parent:      parent,
				Healthcheck: hc,
			}
			if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
				return nil, err
			}
			return ctr, nil
		}).
			Doc(`Retrieves this container with the specificed docker healtcheck command set.`).
			Args(
				dagql.Arg("args").Doc(`Healthcheck command to execute. Example: ["go", "run", "main.go"].`),
				dagql.Arg("shell").Doc(`When true, command must be a single element, which is run using the container's shell`),
				dagql.Arg("interval").Doc(`Interval between running healthcheck. Example: "30s"`),
				dagql.Arg("timeout").Doc(`Healthcheck timeout. Example: "3s"`),
				dagql.Arg("startPeriod").Doc(`StartPeriod allows for failures during this initial startup period which do not count towards maximum number of retries. Example: "0s"`),
				dagql.Arg("startInterval").Doc(`StartInterval configures the duration between checks during the startup phase. Example: "5s"`),
				dagql.Arg("retries").Doc(`The maximum number of consecutive failures before the container is marked as unhealthy. Example: "3"`),
			),

		dagql.NodeFunc("withoutDockerHealthcheck", func(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (*core.Container, error) {
			ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
			if err != nil {
				return nil, err
			}
			ctr, err = s.withoutHealthcheck(ctx, ctr, args)
			if err != nil {
				return nil, err
			}
			ctr.Lazy = &core.ContainerWithoutHealthcheckLazy{
				LazyState: core.NewLazyState(),
				Parent:    parent,
			}
			if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
				return nil, err
			}
			return ctr, nil
		}).
			Doc(`Retrieves this container without a configured docker healtcheck command.`),

		dagql.NodeFunc("dockerHealthcheck", s.healthcheck).
			Doc(`Retrieves this container's configured docker healthcheck.`),

		dagql.NodeFunc("entrypoint", s.entrypoint).
			Doc(`Return the container's OCI entrypoint.`),

		dagql.NodeFunc("withEntrypoint", s.withEntrypoint).
			Doc(`Set an OCI-style entrypoint. It will be included in the container's OCI configuration. Note, withExec ignores the entrypoint by default.`).
			Args(
				dagql.Arg("args").Doc(`Arguments of the entrypoint. Example: ["go", "run"].`),
				dagql.Arg("keepDefaultArgs").Doc(`Don't reset the default arguments when setting the entrypoint. By default it is reset, since entrypoint and default args are often tightly coupled.`),
			),

		dagql.NodeFunc("withoutEntrypoint", s.withoutEntrypoint).
			Doc(`Reset the container's OCI entrypoint.`).
			Args(
				dagql.Arg("keepDefaultArgs").Doc(`Don't remove the default arguments when unsetting the entrypoint.`),
			),

		dagql.NodeFunc("defaultArgs", s.defaultArgs).
			Doc(`Return the container's default arguments.`),

		dagql.NodeFunc("withDefaultArgs", s.withDefaultArgs).
			Doc(`Configures default arguments for future commands. Like CMD in Dockerfile.`).
			Args(
				dagql.Arg("args").Doc(`Arguments to prepend to future executions (e.g., ["-v", "--no-cache"]).`),
			),

		dagql.NodeFunc("withoutDefaultArgs", s.withoutDefaultArgs).
			Doc(`Remove the container's default arguments.`),

		dagql.NodeFunc("mounts", s.mounts).
			Doc(`Retrieves the list of paths where a directory is mounted.`),

		dagql.NodeFunc("withMountedDirectory", s.withMountedDirectory).
			Doc(`Retrieves this container plus a directory mounted at the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the mounted directory (e.g., "/mnt/directory").`),
				dagql.Arg("source").Doc(`Identifier of the mounted directory.`),
				dagql.Arg("owner").Doc(`A user:group to set for the mounted directory and its contents.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("readOnly").Doc(`Mount the directory read-only.`).
					View(AfterVersion("v0.21.0")),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withMountedFile", s.withMountedFile).
			Doc(`Retrieves this container plus a file mounted at the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the mounted file (e.g., "/tmp/file.txt").`),
				dagql.Arg("source").Doc(`Identifier of the mounted file.`),
				dagql.Arg("owner").Doc(`A user or user:group to set for the mounted file.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),

		dagql.NodeFunc("__withMountedPathDockerfileCompat", s.withMountedPathDockerfileCompat).
			Doc(`(Internal-only) Dockerfile-compat bind mount path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the mounted path.`),
				dagql.Arg("source").Doc(`Identifier of the directory containing the mounted path.`),
				dagql.Arg("sourcePath").Doc(`Path within source to mount.`),
				dagql.Arg("readOnly").Doc(`Mount the path read-only.`),
			),

		dagql.NodeFunc("withMountedTemp", s.withMountedTemp).
			Doc(`Retrieves this container plus a temporary directory mounted at the given path. Any writes will be ephemeral to a single withExec call; they will not be persisted to subsequent withExecs.`).
			Args(
				dagql.Arg("path").Doc(`Location of the temporary directory (e.g., "/tmp/temp_dir").`),
				dagql.Arg("size").Doc(`Size of the temporary directory in bytes.`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFuncWithDynamicInputs("withMountedCache", s.withMountedCache, s.withMountedCacheDynamicInputs).
			Doc(`Retrieves this container plus a cache volume mounted at the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the cache directory (e.g., "/root/.npm").`),
				dagql.Arg("cache").Doc(`Identifier of the cache volume to mount.`),
				dagql.Arg("source").Doc(`Identifier of the directory to use as the cache volume's root.`),
				dagql.Arg("sharing").Doc(`Sharing mode of the cache volume.`),
				dagql.Arg("owner").Doc(`A user:group to set for the mounted cache directory.`,
					`Note that this changes the ownership of the specified mount along with
					the initial filesystem provided by source (if any). It does not have
					any effect if/when the cache has already been created.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withMountedVolume", s.withMountedVolume).
			View(AfterVersion("v1.0.0-0")).
			Doc(`Retrieves this container plus a volume mounted at the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the volume mount (e.g., "/mnt/volume").`),
				dagql.Arg("volume").Doc(`Identifier of the volume to mount.`),
				dagql.Arg("readOnly").Doc(`Mount the volume read-only.`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withMountedSecret", s.withMountedSecret).
			Doc(`Retrieves this container plus a secret mounted into a file at the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the secret file (e.g., "/tmp/secret.txt").`),
				dagql.Arg("source").Doc(`Identifier of the secret to mount.`),
				dagql.Arg("owner").Doc(`A user:group to set for the mounted secret.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("mode").Doc(`Permission given to the mounted secret (e.g., 0600).`,
					`This option requires an owner to be set to be active.`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withUnixSocket", s.withUnixSocket).
			Doc(`Retrieves this container plus a socket forwarded to the given Unix socket path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the forwarded Unix socket (e.g., "/tmp/socket").`),
				dagql.Arg("source").Doc(`Identifier of the socket to forward.`),
				dagql.Arg("owner").Doc(`A user:group to set for the mounted socket.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withoutUnixSocket", s.withoutUnixSocket).
			Doc(`Retrieves this container with a previously added Unix socket removed.`).
			Args(
				dagql.Arg("path").Doc(`Location of the socket to remove (e.g., "/tmp/socket").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withoutMount", s.withoutMount).
			Doc(`Retrieves this container after unmounting everything at the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the cache directory (e.g., "/root/.npm").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("withFile", s.withFile).
			IsPersistable().
			Doc(`Return a container snapshot with a file added`).
			Args(
				dagql.Arg("path").Doc(`Path of the new file. Example: "/path/to/new-file.txt"`),
				dagql.Arg("source").Doc(`File to add`),
				dagql.Arg("permissions").Doc(`Permissions of the new file. Example: 0600`),
				dagql.Arg("owner").Doc(`A user:group to set for the file.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),

		dagql.NodeFunc("withoutFile", s.withoutFile).
			IsPersistable().
			Doc(`Retrieves this container with the file at the given path removed.`).
			Args(
				dagql.Arg("path").Doc(`Location of the file to remove (e.g., "/file.txt").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),

		dagql.NodeFunc("withoutFiles", s.withoutFiles).
			IsPersistable().
			Doc(`Return a new container spanshot with specified files removed`).
			Args(
				dagql.Arg("paths").Doc(`Paths of the files to remove. Example: ["foo.txt, "/root/.ssh/config"`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of paths according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),

		dagql.NodeFunc("withFiles", s.withFiles).
			IsPersistable().
			Doc(`Retrieves this container plus the contents of the given files copied to the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location where copied files should be placed (e.g., "/src").`),
				dagql.Arg("sources").Doc(`Identifiers of the files to copy.`),
				dagql.Arg("permissions").Doc(`Permission given to the copied files (e.g., 0600).`),
				dagql.Arg("owner").Doc(`A user:group to set for the files.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),

		dagql.NodeFunc("withNewFile", s.withNewFile).
			IsPersistable().
			View(AllVersion).
			Doc(`Return a new container snapshot, with a file added to its filesystem with text content`).
			Args(
				dagql.Arg("path").Doc(`Path of the new file. May be relative or absolute. Example: "README.md" or "/etc/profile"`),
				dagql.Arg("contents").Doc(`Contents of the new file. Example: "Hello world!"`),
				dagql.Arg("permissions").Doc(`Permissions of the new file. Example: 0600`),
				dagql.Arg("owner").Doc(
					`A user:group to set for the file.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("expand").Doc(
					`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
						`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),
		dagql.NodeFunc("withNewFile", s.withNewFileLegacy).
			View(BeforeVersion("v0.12.0")).
			Doc(`Retrieves this container plus a new file written at the given path.`).
			Args(
				dagql.Arg("path").Doc(`Location of the written file (e.g., "/tmp/file.txt").`),
				dagql.Arg("contents").Doc(`Content of the file to write (e.g., "Hello world!").`),
				dagql.Arg("permissions").Doc(`Permission given to the written file (e.g., 0600).`),
				dagql.Arg("owner").Doc(`A user:group to set for the file.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
			),

		dagql.NodeFunc("withDirectory", s.withDirectory).
			IsPersistable().
			View(AllVersion).
			Doc(`Return a new container snapshot, with a directory added to its filesystem`).
			Args(
				dagql.Arg("path").Doc(`Location of the written directory (e.g., "/tmp/directory").`),
				dagql.Arg("directory").Doc(`Identifier of the directory to write`).View(BeforeVersion("v0.19.0")),
				dagql.Arg("source").Doc(`Identifier of the directory to write`).View(AfterVersion("v0.19.0")),
				dagql.Arg("exclude").Doc(`Patterns to exclude in the written directory (e.g. ["node_modules/**", ".gitignore", ".git/"]).`),
				dagql.Arg("include").Doc(`Patterns to include in the written directory (e.g. ["*.go", "go.mod", "go.sum"]).`),
				dagql.Arg("gitignore").Doc(`Apply .gitignore rules when writing the directory.`),
				dagql.Arg("owner").Doc(`A user:group to set for the directory and its contents.`,
					`The user and group can either be an ID (1000:1000) or a name (foo:bar).`,
					`If the group is omitted, it defaults to the same as the user.`),
				dagql.Arg("inheritOwner").Doc(`Set the owner to the container's current user.`).View(AfterVersion("v1.0.0-0")),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
				dagql.Arg("permissions").View(AfterVersion("v0.21.0")),
			),

		dagql.NodeFunc("withoutDirectory", s.withoutDirectory).
			IsPersistable().
			Doc(`Return a new container snapshot, with a directory removed from its filesystem`).
			Args(
				dagql.Arg("path").Doc(`Location of the directory to remove (e.g., ".github/").`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),

		dagql.NodeFunc("exists", s.exists).
			Doc(`check if a file or directory exists`).
			Args(
				dagql.Arg("path").Doc(`Path to check (e.g., "/file.txt").`),
				dagql.Arg("expectedType").Doc(`If specified, also validate the type of file (e.g. "REGULAR_TYPE", "DIRECTORY_TYPE", or "SYMLINK_TYPE").`),
				dagql.Arg("doNotFollowSymlinks").Doc(`If specified, do not follow symlinks.`),
				dagql.Arg("expand").Doc(`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
					`environment variables defined in the container (e.g. "/$VAR/foo").`).
					View(AfterVersion("v0.21.5")),
			),

		dagql.NodeFunc("stat", s.stat).
			Doc(`Return file status`).
			Args(
				dagql.Arg("path").Doc(`Path to check (e.g., "/file.txt").`),
				dagql.Arg("doNotFollowSymlinks").Doc(`If specified, do not follow symlinks.`),
			),

		dagql.NodeFunc("withError", s.withError).
			Doc(`Raise an error.`).
			Args(
				dagql.Arg("err").Doc(`Message of the error to raise. If empty, the error will be ignored.`),
			),

		dagql.NodeFunc("withExec", s.withExec).
			IsPersistable().
			View(AllVersion).
			Doc(`Execute a command in the container, and return a new snapshot of the container state after execution.`).
			Args(
				dagql.Arg("args").Doc(
					`Command to execute. Must be valid exec() arguments, not a shell command. Example: ["go", "run", "main.go"].`,
					`To run a shell command, execute the shell and pass the shell command as argument. Example: ["sh", "-c", "ls -l | grep foo"]`,
					`Defaults to the container's default arguments (see "defaultArgs" and "withDefaultArgs").`),
				dagql.Arg("useEntrypoint").
					View(AllVersion).
					Doc(`Apply the OCI entrypoint, if present, by prepending it to the args. Ignored by default.`),
				dagql.Arg("useEntrypoint").
					View(BeforeVersion("v0.12.0")).
					Default(dagql.Boolean(true)).
					Doc(`Apply the OCI entrypoint, if present, by prepending it to the args. Ignored by default.`),
				dagql.Arg("skipEntrypoint").
					View(BeforeVersion("v0.13.0")).
					Doc("For true this can be removed. For false, use `useEntrypoint` instead."),
				dagql.Arg("stdin").Doc(
					`Content to write to the command's standard input. Example: "Hello world")`),
				dagql.Arg("redirectStdin").Doc(
					`Redirect the command's standard input from a file in the container. Example: "./stdin.txt"`),
				dagql.Arg("redirectStdout").
					View(AfterVersion(redirectNotLoggedVersion)).
					Doc(`Redirect the command's standard output to a file in the container. The redirected output is not logged. Example: "./stdout.txt"`),
				dagql.Arg("redirectStdout").
					View(BeforeVersion(redirectNotLoggedVersion)).
					Doc(`Redirect the command's standard output to a file in the container. Example: "./stdout.txt"`),
				dagql.Arg("redirectStderr").
					View(AfterVersion(redirectNotLoggedVersion)).
					Doc(`Redirect the command's standard error to a file in the container. The redirected output is not logged. Example: "./stderr.txt"`),
				dagql.Arg("redirectStderr").
					View(BeforeVersion(redirectNotLoggedVersion)).
					Doc(`Redirect the command's standard error to a file in the container. Example: "./stderr.txt"`),
				dagql.Arg("expect").Doc(`Exit codes this command is allowed to exit with without error`),
				disableNestingArg,
				legacyNestingArg,
				deprecatedNestingArg,
				newSessionNestingArg,
				dagql.Arg("insecureRootCapabilities").Doc(
					`Execute the command with all root capabilities. Like --privileged in Docker`,
					`DANGER: this grants the command full access to the host system. Only use when 1) you trust the command being executed and 2) you specifically need this level of access.`),
				dagql.Arg("expand").Doc(
					`Replace "${VAR}" or "$VAR" in the args according to the current `+
						`environment variables defined in the container (e.g. "/$VAR/foo").`),
				dagql.Arg("noInit").Doc(
					`Skip the automatic init process injected into containers by default.`,
					`Only use this if you specifically need the command to be pid 1 in the container. Otherwise it may result in unexpected behavior. If you're not sure, you don't need this.`,
				),
			),

		dagql.NodeFunc("stdout", s.stdout).
			View(AllVersion).
			Doc(`The buffered standard output stream of the last executed command`,
				`Returns an error if no command was executed`),
		dagql.NodeFunc("stdout", s.stdoutLegacy).
			View(BeforeVersion("v0.12.0")).
			Extend(),

		dagql.NodeFunc("stderr", s.stderr).
			View(AllVersion).
			Doc(`The buffered standard error stream of the last executed command`,
				`Returns an error if no command was executed`),
		dagql.NodeFunc("stderr", s.stderrLegacy).
			View(BeforeVersion("v0.12.0")).
			Extend(),

		dagql.NodeFunc("combinedOutput", s.combinedOutput).
			Doc(`The combined buffered standard output and standard error stream of the last executed command`,
				`Returns an error if no command was executed`),

		dagql.NodeFunc("exitCode", s.exitCode).
			Doc(`The exit code of the last executed command`,
				`Returns an error if no command was executed`),

		dagql.NodeFunc("withSymlink", s.withSymlink).
			IsPersistable().
			Doc(`Return a snapshot with a symlink`).
			Args(
				dagql.Arg("target").Doc(`Location of the file or directory to link to (e.g., "/existing/file").`),
				dagql.Arg("linkName").Doc(`Location where the symbolic link will be created (e.g., "/new-file-link").`),
				dagql.Arg("expand").Doc(
					`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
						`environment variables defined in the container (e.g. "/$VAR/foo.txt").`),
			),

		dagql.NodeFunc("withAnnotation", s.withAnnotation).
			Doc(`Retrieves this container plus the given OCI annotation.`).
			Args(
				dagql.Arg("name").Doc(`The name of the annotation.`),
				dagql.Arg("value").Doc(`The value of the annotation.`),
			),

		dagql.NodeFunc("withoutAnnotation", s.withoutAnnotation).
			Doc(`Retrieves this container minus the given OCI annotation.`).
			Args(
				dagql.Arg("name").Doc(`The name of the annotation.`),
			),

		dagql.NodeFunc("publish", s.publish).
			WithInput(dagql.PerCallInput).
			DoNotCache("side effect on an external system (OCI registry)").
			Doc(`Package the container state as an OCI image, and publish it to a registry`,
				`Returns the fully qualified address of the published image, with digest`).
			Args(
				dagql.Arg("address").Doc(
					`The OCI address to publish to`,
					`Same format as "docker push". Example: "registry.example.com/user/repo:tag"`),
				dagql.Arg("platformVariants").Doc(
					`Identifiers for other platform specific containers.`,
					`Used for multi-platform image.`),
				dagql.Arg("forcedCompression").Doc(
					`Force each layer of the published image to use
					the specified compression algorithm.`,
					`If this is unset, then if a layer already has a compressed blob in the
					engine's cache, that will be used (this can result in a mix of
					compression algorithms for different layers). If this is unset and a
					layer has no compressed blob in the engine's cache, then it will be
					compressed using Gzip.`),
				dagql.Arg("mediaTypes").Doc(
					`Use the specified media types for the published image's layers.`,
					`Defaults to "OCI", which is compatible with most recent
				registries, but "Docker" may be needed for older registries without OCI
				support.`),
				dagql.Arg("registryService").Doc(
					`Service to use as the registry endpoint for the image address.`,
					`The service will be started only for this push.`).
					View(AfterVersion("v0.21.6")),
				dagql.Arg("protocol").Doc(
					`Protocol to use for registry communication.`,
					`Defaults to "HTTPS". Use "HTTP" only for plain HTTP registries.`).
					View(AfterVersion("v1.0.0-0")),
				dagql.Arg("insecureSkipTLSVerify").Doc(`Allow HTTPS registry communication without verifying the server certificate.`).
					View(AfterVersion("v1.0.0-0")),
			),

		dagql.NodeFunc("platform", s.platform).
			Doc(`The platform this container executes and publishes as.`),

		dagql.NodeFunc("export", s.export).
			WithInput(dagql.PerCallInput).
			View(AllVersion).
			DoNotCache("Writes to the local host.").
			Doc(`Writes the container as an OCI tarball to the destination file path on the host.`,
				`It can also export platform variants.`).
			Args(
				dagql.Arg("path").Doc(
					`Host's destination path (e.g., "./tarball").`,
					`Path can be relative to the engine's workdir or absolute.`),
				dagql.Arg("platformVariants").Doc(
					`Identifiers for other platform specific containers.`,
					`Used for multi-platform image.`),
				dagql.Arg("forcedCompression").Doc(
					`Force each layer of the exported image to use the specified compression algorithm.`,
					`If this is unset, then if a layer already has a compressed blob in the
					engine's cache, that will be used (this can result in a mix of
					compression algorithms for different layers). If this is unset and a
					layer has no compressed blob in the engine's cache, then it will be
					compressed using Gzip.`),
				dagql.Arg("mediaTypes").Doc(
					`Use the specified media types for the exported image's layers.`,
					`Defaults to OCI, which is largely compatible with most recent
					container runtimes, but Docker may be needed for older runtimes without
					OCI support.`),
				dagql.Arg("expand").Doc(
					`Replace "${VAR}" or "$VAR" in the value of path according to the current `+
						`environment variables defined in the container (e.g. "/$VAR/foo").`),
			),
		dagql.NodeFunc("export", s.exportLegacy).
			WithInput(dagql.PerCallInput).
			View(BeforeVersion("v0.12.0")).
			Extend(),

		dagql.NodeFunc("exportImage", s.exportImage).
			DoNotCache("Writes to the local host.").
			Doc("Exports the container as an image to the host's container image store.").
			Args(
				dagql.Arg("name").Doc("Name of image to export to in the host's store"),
				dagql.Arg("platformVariants").Doc(
					`Identifiers for other platform specific containers.`,
					`Used for multi-platform image.`),
				dagql.Arg("forcedCompression").Doc(
					`Force each layer of the exported image to use the specified compression algorithm.`,
					`If this is unset, then if a layer already has a compressed blob in the
					engine's cache, that will be used (this can result in a mix of
					compression algorithms for different layers). If this is unset and a
					layer has no compressed blob in the engine's cache, then it will be
					compressed using Gzip.`),
				dagql.Arg("mediaTypes").Doc(
					`Use the specified media types for the exported image's layers.`,
					`Defaults to OCI, which is largely compatible with most recent
					container runtimes, but Docker may be needed for older runtimes without
					OCI support.`),
			),

		dagql.NodeFunc("asTarball", s.asTarball).
			IsPersistable().
			Doc(`Package the container state as an OCI image, and return it as a tar archive`).
			Args(
				dagql.Arg("platformVariants").Doc(
					`Identifiers for other platform specific containers.`,
					`Used for multi-platform images.`),
				dagql.Arg("forcedCompression").Doc(
					`Force each layer of the image to use the specified compression algorithm.`,
					`If this is unset, then if a layer already has a compressed blob in the
					engine's cache, that will be used (this can result in a mix of
					compression algorithms for different layers). If this is unset and a
					layer has no compressed blob in the engine's cache, then it will be
					compressed using Gzip.`),
				dagql.Arg("mediaTypes").Doc(`Use the specified media types for the image's layers.`,
					`Defaults to OCI, which is largely compatible with most recent
					container runtimes, but Docker may be needed for older runtimes without
					OCI support.`),
			),

		dagql.NodeFunc("import", s.import_).
			Doc(`Reads the container from an OCI tarball.`).
			Args(
				dagql.Arg("source").Doc(`File to read the container from.`),
				dagql.Arg("tag").Doc(`Identifies the tag to import from the archive, if the archive bundles multiple tags.`),
			),

		dagql.NodeFunc("withRegistryAuth", s.withRegistryAuth).
			WithInput(dagql.PerSessionInput).
			Doc(`Attach credentials for future publishing to a registry. Use in combination with publish`).
			Args(
				dagql.Arg("address").Doc(`The image address that needs authentication. Same format as "docker push". Example: "registry.dagger.io/dagger:latest"`),
				dagql.Arg("username").Doc(`The username to authenticate with. Example: "alice"`),
				dagql.Arg("secret").Doc(`The API key, password or token to authenticate to this registry`),
			),

		dagql.NodeFunc("withoutRegistryAuth", s.withoutRegistryAuth).
			WithInput(dagql.PerSessionInput).
			Doc(`Retrieves this container without the registry authentication of a given address.`).
			Args(
				dagql.Arg("address").Doc(`Registry's address to remove the authentication from.`,
					`Formatted as [host]/[user]/[repo]:[tag] (e.g. docker.io/dagger/dagger:main).`),
			),

		dagql.Func("imageRef", s.imageRef).
			Doc(`The unique image reference which can only be retrieved immediately after the 'Container.From' call.`),

		dagql.NodeFunc("manifest", s.manifest).
			View(AfterVersion("v1.0.0-0")).
			// A manifest names this engine's layer digests, which a rebuild elsewhere
			// does not reproduce: manifest and layer(id) stay on one engine.
			WithInput(dagql.PerEngineCacheInput).
			Doc(`Computes and returns the manifest for this container as a File.`).
			Args(
				dagql.Arg("forcedCompression").Doc(
					`Force each layer of the image to use the specified compression algorithm.`,
					`If this is unset, then if a layer already has a compressed blob in the
						engine's cache, that will be used (this can result in a mix of
						compression algorithms for different layers). If this is unset and a
						layer has no compressed blob in the engine's cache, then it will be
						compressed using Gzip.`),
				dagql.Arg("mediaTypes").Doc(`Media types to use for image layers. Defaults to OCI.`),
			),

		dagql.NodeFunc("layer", s.layer).
			View(AfterVersion("v1.0.0-0")).
			// A manifest names this engine's layer digests, which a rebuild elsewhere
			// does not reproduce: manifest and layer(id) stay on one engine.
			WithInput(dagql.PerEngineCacheInput).
			Doc(`Returns the image layer or configuration blob with the given digest as a File.`).
			Args(
				dagql.Arg("id").Doc(`Digest of the layer or configuration blob (e.g. "sha256:abc123...").`),
				dagql.Arg("forcedCompression").Doc(
					`Force each layer of the image to use the specified compression algorithm.`,
					`If this is unset, then if a layer already has a compressed blob in the
						engine's cache, that will be used (this can result in a mix of
						compression algorithms for different layers). If this is unset and a
						layer has no compressed blob in the engine's cache, then it will be
						compressed using Gzip.`),
				dagql.Arg("mediaTypes").Doc(`Media types to use for image layers. Defaults to OCI.`),
			),

		dagql.NodeFunc("withExposedPort", s.withExposedPort).
			Doc(`Expose a network port. Like EXPOSE in Dockerfile (but with healthcheck support)`,
				`Exposed ports serve two purposes:`,
				`- For health checks and introspection, when running services`,
				`- For setting the EXPOSE OCI field when publishing the container`).
			Args(
				dagql.Arg("port").Doc(`Port number to expose. Example: 8080`),
				dagql.Arg("protocol").Doc(`Network protocol. Example: "tcp"`),
				dagql.Arg("description").Doc(`Port description. Example: "payment API endpoint"`),
				dagql.Arg("experimentalSkipHealthcheck").Doc(`Skip the health check when run as a service.`),
			),

		dagql.NodeFunc("withoutExposedPort", s.withoutExposedPort).
			Doc(`Unexpose a previously exposed port.`).
			Args(
				dagql.Arg("port").Doc(`Port number to unexpose`),
				dagql.Arg("protocol").Doc(`Port protocol to unexpose`),
			),

		dagql.NodeFunc("exposedPorts", s.exposedPorts).
			Doc(`Retrieves the list of exposed ports.`,
				`This includes ports already exposed by the image, even if not explicitly added with dagger.`),

		dagql.NodeFunc("withServiceBinding", s.withServiceBinding).
			Doc(`Establish a runtime dependency from a container to a network service.`,
				`The service will be started automatically when needed and detached
				when it is no longer needed, executing the default command if none is
				set.`,
				`The service will be reachable from the container via the provided hostname alias.`,
				`The service dependency will also convey to any files or directories produced by the container.`).
			Args(
				dagql.Arg("alias").Doc(`Hostname that will resolve to the target service (only accessible from within this container)`),
				dagql.Arg("service").Doc(`The target service`),
			),

		dagql.Func("withFocus", s.withFocus).
			View(BeforeVersion("v0.13.4")).
			Doc(`Indicate that subsequent operations should be featured more prominently in the UI.`),
		dagql.Func("withoutFocus", s.withoutFocus).
			View(BeforeVersion("v0.13.4")).
			Doc(`Indicate that subsequent operations should not be featured more prominently in the UI.`,
				`This is the initial state of all containers.`),

		dagql.NodeFunc("withDefaultTerminalCmd", s.withDefaultTerminalCmd).
			View(AllVersion).
			Deprecated("Use withShell.").
			Doc(`Set the default command to invoke for the container's terminal API.`).
			Args(
				dagql.Arg("args").Doc(`The args of the command.`),
				disableNestingArg,
				legacyNestingArg,
				deprecatedNestingArg,
				dagql.Arg("insecureRootCapabilities").Doc(
					`Execute the command with all root capabilities. This is similar to
				running a command with "sudo" or executing "docker run" with the
				"--privileged" flag. Containerization does not provide any security
				guarantees when using this option. It should only be used when
				absolutely necessary and only with trusted commands.`),
			),

		dagql.NodeFunc("withShell", s.withShell).
			View(AfterVersion("v1.0.0-0")).
			Doc(`Set the shell used by terminal() and withRun().`).
			Args(
				dagql.Arg("interactive").Doc(`Command arguments for interactive use. Example: ["sh"].`),
				dagql.Arg("batch").Doc(`Command arguments for batch use. The script is appended as one argument. Defaults to interactive followed by "-c".`),
				disableNestingArg,
				legacyNestingArg,
				deprecatedNestingArg,
				dagql.Arg("insecureRootCapabilities").Doc(`Give the shell all root capabilities. Use only with trusted commands.`),
			),

		dagql.NodeFunc("shell", s.shell).
			View(AfterVersion("v1.0.0-0")).
			Doc(`Return the configured shell command. Defaults to ["sh"].`).
			Args(dagql.Arg("batch").Doc(`Return the batch command instead of the interactive command.`)),

		dagql.NodeFunc("withRun", s.withRun).
			View(AfterVersion("v1.0.0-0")).
			IsPersistable().
			Doc(`Execute a script with the configured batch shell and return the modified container.`).
			Args(
				dagql.Arg("command").Doc(`Script to append to the shell command as one argument.`),
				dagql.Arg("shell").Doc(`Override the batch shell arguments. Example: ["bash", "-c"].`),
				dagql.Arg("disableDaggerInDagger").
					View(AfterVersion(defaultNestingVersion)).
					Doc(`Override whether the shell is denied Dagger API access. Omit to use the configured shell setting.`),
				legacyNestingArg,
				deprecatedNestingArg,
				dagql.Arg("insecureRootCapabilities").Doc(`Override whether the shell has all root capabilities.`),
			),

		dagql.NodeFunc("terminal", s.terminal).
			View(AfterVersion("v0.12.0")).
			DoNotCache("Only creates a temporary container for the user to interact with and then returns original parent.").Reevaluate().
			Doc(`Opens an interactive terminal for this container using its configured default terminal command if not overridden by args (or sh as a fallback default).`).
			Args(
				dagql.Arg("cmd").Doc(`If set, override the container's default terminal command and invoke these command arguments instead.`),
				disableNestingArg,
				legacyNestingArg,
				deprecatedNestingArg,
				dagql.Arg("insecureRootCapabilities").Doc(
					`Execute the command with all root capabilities. This is similar to
				running a command with "sudo" or executing "docker run" with the
				"--privileged" flag. Containerization does not provide any security
				guarantees when using this option. It should only be used when
				absolutely necessary and only with trusted commands.`),
			),
		dagql.NodeFunc("terminal", s.terminalLegacy).
			View(BeforeVersion("v0.12.0")).
			Doc(`Opens an interactive terminal for this container using its configured default terminal command if not overridden by args (or sh as a fallback default).`).
			Args(
				dagql.Arg("cmd").Doc(`If set, override the container's default terminal command and invoke these command arguments instead.`),
				disableNestingArg,
				legacyNestingArg,
				deprecatedNestingArg,
				dagql.Arg("insecureRootCapabilities").Doc(
					`Execute the command with all root capabilities. This is similar to
				running a command with "sudo" or executing "docker run" with the
				"--privileged" flag. Containerization does not provide any security
				guarantees when using this option. It should only be used when
				absolutely necessary and only with trusted commands.`),
			),

		dagql.NodeFunc("withGPU", s.withAllGPUs).
			View(AfterVersion(gpuAPIVersion)).
			Doc(`Configures all GPUs available on the host to be accessible to this container.`,
				`This currently works with NVIDIA devices only, and requires the engine to run with GPU support enabled.`),

		dagql.NodeFunc("experimentalWithGPU", s.withGPU).
			View(BeforeVersion(gpuAPIVersion)).
			Doc(`EXPERIMENTAL API! Subject to change/removal at any time.`,
				`Configures the provided list of devices to be accessible to this container.`,
				`This currently works for Nvidia devices only.`).
			Args(
				dagql.Arg("devices").Doc(`List of devices to be accessible to this container.`),
			),
		dagql.NodeFunc("experimentalWithGPU", s.withGPU).
			View(AfterVersion(gpuAPIVersion)).
			Doc(`Configures the provided list of devices to be accessible to this container.`,
				`This currently works for Nvidia devices only.`).
			Args(
				dagql.Arg("devices").Doc(`List of devices to be accessible to this container.`),
			).
			Deprecated(`Use "withGPU" instead, which exposes all GPUs available on the host.`),

		dagql.NodeFunc("experimentalWithAllGPUs", s.withAllGPUs).
			View(BeforeVersion(gpuAPIVersion)).
			Doc(`EXPERIMENTAL API! Subject to change/removal at any time.`,
				`Configures all available GPUs on the host to be accessible to this container.`,
				`This currently works for Nvidia devices only.`),
		dagql.NodeFunc("experimentalWithAllGPUs", s.withAllGPUs).
			View(AfterVersion(gpuAPIVersion)).
			Doc(`Configures all available GPUs on the host to be accessible to this container.`,
				`This currently works for Nvidia devices only.`).
			Deprecated(`Use "withGPU" instead.`),
	}.Install(srv)

	dagql.Fields[*core.TerminalLegacy]{
		Syncer[*core.TerminalLegacy]().
			Doc(`Forces evaluation of the pipeline in the engine.`,
				`It doesn't run the default command if no exec has been set.`),

		dagql.Func("websocketEndpoint", s.terminalLegacyWebsocketEndpoint).
			View(BeforeVersion("v0.12.0")).
			Deprecated("Use newer dagger to access the terminal").
			Doc(`An http endpoint at which this terminal can be connected to over a websocket.`),
	}.Install(srv)
}

type containerArgs struct {
	Platform dagql.Optional[core.Platform]
}

func (s *containerSchema) containerDynamicInputs(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Query],
	args containerArgs,
	req *dagql.CallRequest,
) error {
	if args.Platform.Valid {
		return nil
	}
	return req.SetArgInput(ctx, "platform", parent.Self().Platform(), false)
}

func (s *containerSchema) container(ctx context.Context, parent *core.Query, args containerArgs) (_ *core.Container, rerr error) {
	var platform core.Platform
	if args.Platform.Valid {
		platform = args.Platform.Value
	} else {
		platform = parent.Platform()
	}
	return core.NewContainer(platform), nil
}

type containerFromArgs struct {
	Address               string
	Version               string `default:""`
	RegistryService       dagql.Optional[core.ServiceID]
	Protocol              dagql.Optional[core.RegistryProtocol]
	InsecureSkipTLSVerify bool `name:"insecureSkipTLSVerify" default:"false"`
	NoLock                bool `name:"noLock" default:"false"`
}

func registryTransportFromArgs(protocol dagql.Optional[core.RegistryProtocol], insecureSkipTLSVerify bool) (serverresolver.RegistryTransport, error) {
	if protocol.Valid && protocol.Value == core.RegistryProtocolHTTP && insecureSkipTLSVerify {
		return serverresolver.RegistryTransport{}, errors.New("insecureSkipTLSVerify cannot be used with HTTP registry protocol")
	}

	if !protocol.Valid {
		if insecureSkipTLSVerify {
			return serverresolver.RegistryTransport{
				Protocol:              serverresolver.RegistryProtocolHTTPS,
				InsecureSkipTLSVerify: true,
			}, nil
		}
		return serverresolver.RegistryTransport{}, nil
	}

	switch protocol.Value {
	case core.RegistryProtocolHTTPS:
		return serverresolver.RegistryTransport{
			Protocol:              serverresolver.RegistryProtocolHTTPS,
			InsecureSkipTLSVerify: insecureSkipTLSVerify,
		}, nil
	case core.RegistryProtocolHTTP:
		return serverresolver.RegistryTransport{
			Protocol: serverresolver.RegistryProtocolHTTP,
		}, nil
	default:
		return serverresolver.RegistryTransport{}, fmt.Errorf("unsupported registry protocol %q", protocol.Value)
	}
}

func shouldSelectLatestImageRelease(
	ctx context.Context,
	ref reference.Named,
) bool {
	return reference.IsNameOnly(ref) && core.Supports(ctx, workspace.LatestReleaseVersion)
}

// if the image ref has a digest, then it's immutable and we don't need to scope it to the session. If it's just a tag, then
// we scope to the session so that resolution of a tag->digest is cached within the session but not across.
var fromSessionScopeInput = dagql.ImplicitInput{
	Name: "fromSessionScope",
	Resolver: func(ctx context.Context, args map[string]dagql.Input) (dagql.Input, error) {
		rawAddress, ok := args["address"]
		if !ok || rawAddress == nil {
			return nil, errors.New("missing required address argument")
		}
		address, ok := rawAddress.(dagql.String)
		if !ok {
			return nil, fmt.Errorf("unexpected address input type %T", rawAddress)
		}

		refName, err := reference.ParseNormalizedNamed(address.String())
		if err != nil {
			return nil, fmt.Errorf("failed to parse image address %s: %w", address.String(), err)
		}
		refName = reference.TagNameOnly(refName)
		if _, isCanonical := refName.(reference.Canonical); isCanonical {
			// Digest-addressed refs are immutable and don't need session scoping.
			return dagql.NewString(""), nil
		}

		clientMD, err := engine.ClientMetadataFromContext(ctx)
		if err != nil {
			return nil, fmt.Errorf("failed to get client metadata: %w", err)
		}
		if clientMD.SessionID == "" {
			return nil, errors.New("session ID not found in context")
		}
		// Tag-only refs are mutable; resolve once per session.
		return dagql.NewString(clientMD.SessionID), nil
	},
}

//nolint:gocyclo
func (s *containerSchema) from(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerFromArgs) (inst dagql.ObjectResult[*core.Container], _ error) {
	if args.NoLock {
		ctx = withoutWorkspaceLookupLock(ctx)
	}
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get dagql server: %w", err)
	}
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return inst, err
	}
	rslvr, err := query.RegistryResolver(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get registry resolver: %w", err)
	}
	registryTransport, err := registryTransportFromArgs(args.Protocol, args.InsecureSkipTLSVerify)
	if err != nil {
		return inst, err
	}
	platform := parent.Self().Platform
	var registryServices core.ServiceBindings

	refName, err := reference.ParseNormalizedNamed(args.Address)
	if err != nil {
		return inst, fmt.Errorf("failed to parse image address %s: %w", args.Address, err)
	}
	if args.Version != "" && !reference.IsNameOnly(refName) {
		return inst, fmt.Errorf(
			"version query %q cannot be used with image address %q because it contains a tag or digest",
			args.Version,
			args.Address,
		)
	}
	latestRelease := args.Version != "" || shouldSelectLatestImageRelease(ctx, refName)
	if latestRelease {
		refName = reference.TrimNamed(refName)
	} else {
		// TagNameOnly is deliberately called after testing IsNameOnly so an
		// implicit tag remains distinguishable from an explicit latest tag.
		refName = reference.TagNameOnly(refName)
	}
	if args.RegistryService.Valid {
		service, err := args.RegistryService.Value.Load(ctx, srv)
		if err != nil {
			return inst, err
		}
		registryServices, err = core.ContainerRegistryServiceBinding(ctx, refName.String(), service)
		if err != nil {
			return inst, err
		}
	}

	if refName, isCanonical := refName.(reference.Canonical); isCanonical {
		clonedMounts, err := core.CloneContainerMounts(ctx, parent.Self().Mounts)
		if err != nil {
			return inst, err
		}
		clonedMeta, err := core.CloneContainerMetaSnapshot(ctx, parent.Self().MetaSnapshot)
		if err != nil {
			return inst, err
		}
		ctr := &core.Container{
			FS:                 new(core.LazyAccessor[*core.Directory, *core.Container]),
			MetaSnapshot:       clonedMeta,
			Config:             core.CloneContainerImageConfig(parent.Self().Config),
			EnabledGPUs:        slices.Clone(parent.Self().EnabledGPUs),
			Mounts:             clonedMounts,
			Platform:           parent.Self().Platform,
			Annotations:        slices.Clone(parent.Self().Annotations),
			Secrets:            slices.Clone(parent.Self().Secrets),
			Sockets:            slices.Clone(parent.Self().Sockets),
			ImageRef:           "",
			Ports:              slices.Clone(parent.Self().Ports),
			Services:           slices.Clone(parent.Self().Services),
			DefaultTerminalCmd: parent.Self().DefaultTerminalCmd,
			SystemEnvNames:     slices.Clone(parent.Self().SystemEnvNames),
			VolatileEnv:        slices.Clone(parent.Self().VolatileEnv),
			DefaultArgs:        parent.Self().DefaultArgs,
		}

		refStr := refName.String()
		network, detach, err := core.ContainerRegistryNetwork(ctx, registryServices)
		if err != nil {
			return inst, err
		}
		defer detach()

		_, _, cfgBytes, err := rslvr.ResolveImageConfig(ctx, refStr, serverresolver.ResolveImageConfigOpts{
			Platform:          ptr(platform.Spec()),
			ResolveMode:       serverresolver.ResolveModeDefault,
			Network:           network,
			RegistryTransport: registryTransport,
		})
		if err != nil {
			return inst, fmt.Errorf("failed to resolve image %q (platform: %q): %w", refStr, platform.Format(), err)
		}

		var imgSpec dockerspec.DockerOCIImage
		if err := json.Unmarshal(cfgBytes, &imgSpec); err != nil {
			return inst, err
		}

		ctr.Config = core.MergeImageConfig(ctr.Config, imgSpec.Config)
		ctr.ImageRef = refStr
		ctr.Platform = core.Platform(platforms.Normalize(imgSpec.Platform))
		ctr.Lazy = &core.ContainerFromImageRefLazy{
			Parent:            parent,
			LazyState:         core.NewLazyState(),
			CanonicalRef:      refStr,
			Config:            core.CloneContainerImageConfig(ctr.Config),
			ImageRef:          ctr.ImageRef,
			Platform:          ctr.Platform,
			ResolveMode:       serverresolver.ResolveModeDefault,
			RegistryServices:  registryServices,
			RegistryTransport: registryTransport,
		}

		inst, err = dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
		if err != nil {
			return inst, err
		}

		// Detach identity from the :tag and make the result purely
		// content-addressed when From is operating on an otherwise untouched
		// scratch container. Derived containers may carry state that From
		// preserves, so they must retain their call identity.
		if parent.Self().CanUseFromContentDigest() {
			var err error
			inst, err = inst.WithContentDigest(ctx, hashutil.HashStrings(
				"container.from",
				refName.Digest().String(),
				ctr.Platform.Format(),
			))
			if err != nil {
				return inst, fmt.Errorf("failed to set content digest: %w", err)
			}
		}

		return inst, nil
	}

	var lookupLock *workspaceLookupLock
	// A ref like "registry:5000/app:latest" can point to different images
	// depending on registryService, so disable workspace lock entries when
	// registryService is set.
	if len(registryServices) == 0 {
		lookupLock, err = lookupLockForAPI(ctx, query, workspace.LockOperationOCISHA)
		if err != nil {
			return inst, err
		}
	}

	registryLockOptions := func() []workspace.LookupOption {
		var options []workspace.LookupOption
		if registryTransport.Protocol != "" {
			options = append(options, workspace.LookupOption{
				Name:  "protocol",
				Value: string(registryTransport.Protocol),
			})
		}
		if registryTransport.InsecureSkipTLSVerify {
			options = append(options, workspace.LookupOption{
				Name:  "insecureSkipTLSVerify",
				Value: true,
			})
		}
		return options
	}

	if latestRelease {
		latestOptions := registryLockOptions()
		if args.Version != "" {
			latestOptions = append(latestOptions, workspace.LookupOption{
				Name:  "version",
				Value: args.Version,
			})
		}
		latestInputs := workspace.LookupInputs(
			[]any{refName.String()},
			latestOptions...,
		)
		latestResolution := resolveLookupFromLoadedLock(
			lookupLock,
			workspace.LockOperationOCILatest,
			latestInputs,
		)

		var selectedTag string
		if latestResolution.Pin != "" {
			selectedTag = latestResolution.Pin
			if err := core.ValidateContainerTag(selectedTag, args.Version); err != nil {
				return inst, fmt.Errorf("%s lock value: %w", workspace.LockOperationOCILatest, err)
			}
		} else {
			rslvr, err := query.RegistryResolver(ctx)
			if err != nil {
				return inst, fmt.Errorf("failed to get registry resolver: %w", err)
			}
			network, detach, err := core.ContainerRegistryNetwork(ctx, registryServices)
			if err != nil {
				return inst, err
			}
			defer detach()

			listCtx, span := core.Tracer(ctx).Start(
				ctx,
				fmt.Sprintf("select latest release for %s", refName.String()),
				telemetry.Internal(),
				telemetry.Encapsulate(),
			)
			tags, err := rslvr.ListImageTags(listCtx, refName.String(), serverresolver.ListImageTagsOpts{
				Network:           network,
				RegistryTransport: registryTransport,
			})
			telemetry.EndWithCause(span, &err)
			if err != nil {
				return inst, fmt.Errorf("failed to list image tags for %q: %w", refName.String(), err)
			}
			selectedTag, err = core.SelectContainerTag(tags, args.Version)
			if err != nil {
				return inst, fmt.Errorf("select latest image tag for %q: %w", refName.String(), err)
			}
			if latestResolution.ShouldWrite && lookupLock != nil {
				if err := lookupLock.SetLookup(
					workspace.CoreLockNamespace,
					workspace.LockOperationOCILatest,
					latestInputs,
					selectedTag,
				); err != nil {
					return inst, fmt.Errorf("set lock entry for %s: %w", workspace.LockOperationOCILatest, err)
				}
			}
		}
		refName, err = reference.WithTag(refName, selectedTag)
		if err != nil {
			return inst, fmt.Errorf("apply selected image tag %q: %w", selectedTag, err)
		}
	}

	shaInputs := workspace.LookupInputs(
		[]any{refName.String()},
		registryLockOptions()...,
	)
	shaResolution := resolveLookupFromLoadedLock(
		lookupLock,
		workspace.LockOperationOCISHA,
		shaInputs,
	)
	if shaResolution.Pin != "" {
		pin := shaResolution.Pin
		resolvedDigest, err := digest.Parse(pin)
		if err != nil {
			return inst, fmt.Errorf("invalid lock digest %q for image %q: %w", pin, refName.String(), err)
		}
		refName, err = reference.WithDigest(refName, resolvedDigest)
		if err != nil {
			return inst, fmt.Errorf("failed to apply lock digest on image %s: %w", refName.String(), err)
		}
	} else {
		rslvr, err := query.RegistryResolver(ctx)
		if err != nil {
			return inst, fmt.Errorf("failed to get registry resolver: %w", err)
		}
		network, detach, err := core.ContainerRegistryNetwork(ctx, registryServices)
		if err != nil {
			return inst, err
		}
		defer detach()

		_, resolvedDigest, _, err := rslvr.ResolveImageConfig(ctx, refName.String(), serverresolver.ResolveImageConfigOpts{
			Platform:          ptr(platform.Spec()),
			ResolveMode:       serverresolver.ResolveModeDefault,
			Network:           network,
			RegistryTransport: registryTransport,
		})
		if err != nil {
			return inst, fmt.Errorf("failed to resolve image %q (platform: %q): %w", refName.String(), platform.Format(), err)
		}
		refName, err = reference.WithDigest(refName, resolvedDigest)
		if err != nil {
			return inst, fmt.Errorf("failed to set digest on image %s: %w", refName.String(), err)
		}

		if shaResolution.ShouldWrite && lookupLock != nil {
			if err := lookupLock.SetLookup(
				workspace.CoreLockNamespace,
				workspace.LockOperationOCISHA,
				shaInputs,
				resolvedDigest.String(),
			); err != nil {
				return inst, fmt.Errorf("set lock entry for %s: %w", workspace.LockOperationOCISHA, err)
			}
		}
	}

	ctx, span := core.Tracer(ctx).Start(ctx, fmt.Sprintf("from %s", refName),
		telemetry.Internal(),
	)
	defer telemetry.EndWithCause(span, nil)

	// We resolved the tag to a digest. Call from again with that digest so the
	// container ID is stable, and keep registryService so the final pull still
	// uses the same local registry.
	fromArgs := []dagql.NamedInput{
		{Name: "address", Value: dagql.String(refName.String())},
	}
	if args.RegistryService.Valid {
		fromArgs = append(fromArgs, dagql.NamedInput{
			Name:  "registryService",
			Value: dagql.Opt(args.RegistryService.Value),
		})
	}
	if registryTransport.Protocol != "" {
		protocol := core.RegistryProtocolHTTPS
		if registryTransport.Protocol == serverresolver.RegistryProtocolHTTP {
			protocol = core.RegistryProtocolHTTP
		}
		fromArgs = append(fromArgs, dagql.NamedInput{
			Name:  "protocol",
			Value: dagql.Opt(protocol),
		})
	}
	if registryTransport.InsecureSkipTLSVerify {
		fromArgs = append(fromArgs, dagql.NamedInput{
			Name:  "insecureSkipTLSVerify",
			Value: dagql.Boolean(true),
		})
	}
	err = srv.Select(ctx, parent, &inst,
		dagql.Selector{
			Field: "from",
			Args:  fromArgs,
		},
	)
	if err != nil {
		return inst, err
	}

	return inst, nil
}

type containerBuildArgs struct {
	Context    core.DirectoryID
	Dockerfile string                             `default:"Dockerfile"`
	Target     string                             `default:""`
	BuildArgs  []dagql.InputObject[core.BuildArg] `default:"[]"`
	Secrets    []core.SecretID                    `default:"[]"`
	NoInit     bool                               `default:"false"`
}

func (s *containerSchema) build(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Container],
	args containerBuildArgs,
) (inst dagql.ObjectResult[*core.Container], _ error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return inst, err
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	contextDir, err := args.Context.Load(ctx, srv)
	if err != nil {
		return inst, err
	}
	buildctxDir, err := applyDockerIgnore(ctx, srv, contextDir, args.Dockerfile)
	if err != nil {
		return inst, err
	}

	secrets, err := dagql.LoadIDResults(ctx, srv, args.Secrets)
	if err != nil {
		return inst, err
	}

	buildctxDirID, err := buildctxDir.RecipeID(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get build context recipe ID: %w", err)
	}

	return parent.Self().Build(
		ctx,
		contextDir,
		buildctxDirID,
		args.Dockerfile,
		collectInputsSlice(args.BuildArgs),
		args.Target,
		secrets,
		args.NoInit,
		dagql.ObjectResult[*core.Socket]{},
	)
}

type containerWithRootFSArgs struct {
	Directory core.DirectoryID
}

func (s *containerSchema) withRootfs(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithRootFSArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	dir, err := args.Directory.Load(ctx, srv)
	if err != nil {
		return nil, err
	}
	clonedMounts, err := core.CloneContainerMounts(ctx, parent.Self().Mounts)
	if err != nil {
		return nil, err
	}
	clonedMeta, err := core.CloneContainerMetaSnapshot(ctx, parent.Self().MetaSnapshot)
	if err != nil {
		return nil, err
	}
	ctr := &core.Container{
		FS:                 new(core.LazyAccessor[*core.Directory, *core.Container]),
		MetaSnapshot:       clonedMeta,
		Config:             core.CloneContainerImageConfig(parent.Self().Config),
		EnabledGPUs:        slices.Clone(parent.Self().EnabledGPUs),
		Mounts:             clonedMounts,
		Platform:           parent.Self().Platform,
		Annotations:        slices.Clone(parent.Self().Annotations),
		Secrets:            slices.Clone(parent.Self().Secrets),
		Sockets:            slices.Clone(parent.Self().Sockets),
		ImageRef:           "",
		Ports:              slices.Clone(parent.Self().Ports),
		Services:           slices.Clone(parent.Self().Services),
		DefaultTerminalCmd: parent.Self().DefaultTerminalCmd,
		SystemEnvNames:     slices.Clone(parent.Self().SystemEnvNames),
		VolatileEnv:        slices.Clone(parent.Self().VolatileEnv),
		DefaultArgs:        parent.Self().DefaultArgs,
		Lazy: &core.ContainerWithRootFSLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Source:    dir,
		},
	}
	return ctr, nil
}

type containerPipelineArgs struct {
	Name        string
	Description string                             `default:""`
	Labels      []dagql.InputObject[PipelineLabel] `default:"[]"`
}

func (s *containerSchema) pipeline(ctx context.Context, parent *core.Container, args containerPipelineArgs) (*core.Container, error) {
	// deprecated no-op
	return parent, nil
}

func (s *containerSchema) rootfs(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (dagql.ObjectResult[*core.Directory], error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return dagql.ObjectResult[*core.Directory]{}, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return dagql.ObjectResult[*core.Directory]{}, err
	}

	dir := &core.Directory{
		Platform: parent.Self().Platform,
		Services: slices.Clone(parent.Self().Services),
		Lazy: &core.ContainerRootFSLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
		},
		Dir:      new(core.LazyAccessor[string, *core.Directory]),
		Snapshot: new(core.LazyAccessor[bkcache.ImmutableRef, *core.Directory]),
	}
	dir.SetPath("/")
	return dagql.NewObjectResultForCurrentCall(ctx, srv, dir)
}

type containerExecArgs struct {
	core.ContainerExecOpts

	// If the container has an entrypoint, ignore it for this exec rather than
	// calling it with args
	SkipEntrypoint *bool `default:"false"`

	// ExecMD carries internal runtime execution metadata.
	ExecMD dagql.SerializedString[*engineutil.ExecutionMetadata] `name:"execMD" internal:"true" default:"null"`

	// ModuleContext carries the module whose execution context owns this exec.
	ModuleContext dagql.Optional[core.ModuleID] `name:"moduleContext" internal:"true"`
}

func (s *containerSchema) withError(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{ Err string }) (inst dagql.ObjectResult[*core.Container], rerr error) {
	if args.Err == "" {
		return parent, nil
	}
	return inst, errors.New(args.Err)
}

func (s *containerSchema) withExec(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerExecArgs) (inst dagql.ObjectResult[*core.Container], _ error) {
	if args.Stdin != "" && args.RedirectStdin != "" {
		return inst, fmt.Errorf("cannot set both stdin and redirectStdin")
	}

	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	if args.SkipEntrypoint != nil {
		args.UseEntrypoint = !*args.SkipEntrypoint
	}
	if core.Supports(ctx, defaultNestingVersion) {
		args.ExperimentalPrivilegedNesting, err = v1Nesting(args.DisableDaggerInDagger, args.DaggerInDaggerNewSession)
		if err != nil {
			return inst, err
		}
	}
	args.LogRedirectedOutput = !core.Supports(ctx, redirectNotLoggedVersion)

	var md *engineutil.ExecutionMetadata
	if args.ExecMD.Self != nil {
		md = args.ExecMD.Self
	}
	var moduleContext dagql.ObjectResult[*core.Module]
	if args.ModuleContext.Valid {
		moduleContext, err = args.ModuleContext.Value.Load(ctx, srv)
		if err != nil {
			return inst, fmt.Errorf("load exec module context: %w", err)
		}
	}

	ctr, _, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	err = ctr.WithExec(ctx, parent, args.ContainerExecOpts, md, moduleContext, nil)
	if err != nil {
		return inst, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
}

func (s *containerSchema) stdout(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (string, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return "", err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartExecMeta); err != nil {
		return "", err
	}
	return parent.Self().Stdout(ctx)
}

//nolint:dupl
func (s *containerSchema) stdoutLegacy(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (string, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get server: %w", err)
	}

	out, err := parent.Self().Stdout(ctx)
	if errors.Is(err, core.ErrNoCommand) {
		var ctr dagql.ObjectResult[*core.Container]
		if err := srv.Select(ctx, parent, &ctr, dagql.Selector{
			Field: "withExec",
			View:  "v0.12.0",
			Args: []dagql.NamedInput{
				{
					Name:  "args",
					Value: dagql.ArrayInput[dagql.String]{},
				},
				{
					Name:  "useEntrypoint",
					Value: dagql.NewBoolean(true),
				},
			},
		}); err != nil {
			return "", err
		}
		return ctr.Self().Stdout(ctx)
	}
	return out, err
}

func (s *containerSchema) stderr(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (string, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return "", err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartExecMeta); err != nil {
		return "", err
	}
	return parent.Self().Stderr(ctx)
}

//nolint:dupl
func (s *containerSchema) stderrLegacy(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (string, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get server: %w", err)
	}

	out, err := parent.Self().Stderr(ctx)
	if errors.Is(err, core.ErrNoCommand) {
		var ctr dagql.ObjectResult[*core.Container]
		if err := srv.Select(ctx, parent, &ctr, dagql.Selector{
			Field: "withExec",
			View:  "v0.12.0",
			Args: []dagql.NamedInput{
				{
					Name:  "args",
					Value: dagql.ArrayInput[dagql.String]{},
				},
				{
					Name:  "useEntrypoint",
					Value: dagql.NewBoolean(true),
				},
			},
		}); err != nil {
			return "", err
		}
		return ctr.Self().Stderr(ctx)
	}
	return out, err
}

func (s *containerSchema) combinedOutput(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (string, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return "", err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartExecMeta); err != nil {
		return "", err
	}
	return parent.Self().CombinedOutput(ctx)
}

func (s *containerSchema) exitCode(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (int, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return 0, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartExecMeta); err != nil {
		return 0, err
	}
	return parent.Self().ExitCode(ctx)
}

type containerWithSymlinkArgs struct {
	Target   string
	LinkName string
	Expand   bool `default:"false"`
}

func (s *containerSchema) withSymlink(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithSymlinkArgs) (inst dagql.ObjectResult[*core.Container], _ error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	target, err := expandEnvVar(ctx, parent.Self(), args.Target, args.Expand)
	if err != nil {
		return inst, err
	}

	linkName, err := expandEnvVar(ctx, parent.Self(), args.LinkName, args.Expand)
	if err != nil {
		return inst, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	ctr.Lazy = &core.ContainerWithSymlinkLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		LinkPath:  linkName,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
}

type containerGpuArgs struct {
	core.ContainerGPUOpts
}

func (s *containerSchema) withGPU(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerGpuArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.WithGPU(ctx, args.ContainerGPUOpts)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerSetGPUsLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Devices:   slices.Clone(args.Devices),
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

func (s *containerSchema) withAllGPUs(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	devices := []string{"all"}
	ctr, err = ctr.WithGPU(ctx, core.ContainerGPUOpts{Devices: devices})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerSetGPUsLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Devices:   devices,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithEntrypointArgs struct {
	Args            []string
	KeepDefaultArgs bool `default:"false"`
}

func (s *containerSchema) withEntrypoint(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithEntrypointArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.Entrypoint = args.Args
		if !args.KeepDefaultArgs {
			cfg.Cmd = nil
		}
		return cfg
	})
	if err != nil {
		return nil, err
	}
	if parentPendingLazy {
		ctr.Lazy = &core.ContainerWithEntrypointLazy{
			LazyState:       core.NewLazyState(),
			Parent:          parent,
			Args:            slices.Clone(args.Args),
			KeepDefaultArgs: args.KeepDefaultArgs,
		}
	}
	return ctr, nil
}

type containerWithoutEntrypointArgs struct {
	KeepDefaultArgs bool `default:"false"`
}

func (s *containerSchema) withoutEntrypoint(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutEntrypointArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.Entrypoint = nil
		if !args.KeepDefaultArgs {
			cfg.Cmd = nil
		}
		return cfg
	})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithoutEntrypointLazy{
		LazyState:       core.NewLazyState(),
		Parent:          parent,
		KeepDefaultArgs: args.KeepDefaultArgs,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

func (s *containerSchema) entrypoint(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) ([]string, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return nil, err
	}
	return slices.Clone(parent.Self().Config.Entrypoint), nil
}

type containerWithDefaultArgs struct {
	Args []string
}

func (s *containerSchema) withDefaultArgs(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithDefaultArgs) (*core.Container, error) {
	c, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	c.DefaultArgs = true
	c, err = c.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		if args.Args == nil {
			cfg.Cmd = []string{}
			return cfg
		}

		cfg.Cmd = args.Args
		return cfg
	})
	if err != nil {
		return nil, err
	}
	c.Lazy = &core.ContainerWithDefaultArgsLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Args:      slices.Clone(args.Args),
	}
	if err := evaluateOverBuiltParent(ctx, c, parentPendingLazy); err != nil {
		return nil, err
	}
	return c, nil
}

func (s *containerSchema) withoutDefaultArgs(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (*core.Container, error) {
	c, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	c.DefaultArgs = false
	c, err = c.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.Cmd = nil
		return cfg
	})
	if err != nil {
		return nil, err
	}
	if parentPendingLazy {
		c.Lazy = &core.ContainerWithoutDefaultArgsLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
		}
	}
	return c, nil
}

func (s *containerSchema) defaultArgs(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) ([]string, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return nil, err
	}
	return slices.Clone(parent.Self().Config.Cmd), nil
}

type containerWithUserArgs struct {
	Name string
}

func (s *containerSchema) withUser(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithUserArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.User = args.Name
		return cfg
	})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithUserLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

func (s *containerSchema) withoutUser(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.User = ""
		return cfg
	})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithoutUserLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

func (s *containerSchema) user(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (string, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return "", err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return "", err
	}
	return parent.Self().Config.User, nil
}

type containerWithWorkdirArgs struct {
	Path   string
	Expand bool `default:"false"`
}

func (s *containerSchema) withWorkdir(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithWorkdirArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.WorkingDir = absPath(cfg.WorkingDir, path)
		return cfg
	})
	if err != nil {
		return nil, err
	}
	if parentPendingLazy {
		ctr.Lazy = &core.ContainerWithWorkdirLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Path:      args.Path,
			Expand:    args.Expand,
		}
	}
	return ctr, nil
}

func (s *containerSchema) withoutWorkdir(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.WorkingDir = ""
		return cfg
	})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithoutWorkdirLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

func (s *containerSchema) workdir(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (string, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return "", err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return "", err
	}
	return parent.Self().Config.WorkingDir, nil
}

type containerWithVariableArgs struct {
	Name   string
	Value  string
	Expand bool `default:"false"`
}

func (s *containerSchema) withEnvVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithVariableArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	value, err := core.ExpandContainerInput(ctr, args.Value, args.Expand)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.Env = core.AddEnv(cfg.Env, args.Name, value)
		return cfg
	})
	if err != nil {
		return nil, err
	}
	if parentPendingLazy {
		ctr.Lazy = &core.ContainerWithEnvVariableLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Name:      args.Name,
			Value:     args.Value,
			Expand:    args.Expand,
		}
	}
	return ctr, nil
}

type withEnvFileVariablesArgs struct {
	Source core.EnvFileID
}

func (s *containerSchema) withEnvFileVariables(ctx context.Context, parent dagql.ObjectResult[*core.Container], args withEnvFileVariablesArgs) (*core.Container, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	ef, err := args.Source.Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	vars, err := ef.Self().Variables(ctx, false)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		for _, v := range vars {
			cfg.Env = core.AddEnv(cfg.Env, v.Name, v.Value)
		}
		return cfg
	})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithEnvFileVariablesLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Source:    ef,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithSystemEnvArgs struct {
	Name string
}

type containerWithVolatileVariableArgs struct {
	Name  string
	Value string
}

func (s *containerSchema) withSystemEnvVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithSystemEnvArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr.SystemEnvNames = append(ctr.SystemEnvNames, args.Name)
	if parentPendingLazy {
		ctr.Lazy = &core.ContainerWithSystemEnvVariableLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Name:      args.Name,
		}
	}
	return ctr, nil
}

func (s *containerSchema) withVolatileVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithVolatileVariableArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	curCall := dagql.CurrentCall(ctx)
	if curCall == nil {
		return inst, fmt.Errorf("current call is nil")
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	ctr.WithVolatileVariable(args.Name, args.Value)
	ctr.Lazy = &core.ContainerWithVolatileVariableLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
		Value:     args.Value,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}
	inst, err = dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
	if err != nil {
		return inst, err
	}

	clientMetadata, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return inst, fmt.Errorf("resolve volatile variable %q: current client metadata: %w", args.Name, err)
	}
	if clientMetadata.SessionID == "" {
		return inst, fmt.Errorf("resolve volatile variable %q: empty session ID", args.Name)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return inst, fmt.Errorf("resolve volatile variable %q: current dagql cache: %w", args.Name, err)
	}
	if err := cache.SetVolatileVars(ctx, clientMetadata.SessionID, args.Name, args.Value); err != nil {
		return inst, fmt.Errorf("record volatile variable %q: %w", args.Name, err)
	}

	parentDig, err := parent.ContentPreferredDigest(ctx)
	if err != nil {
		return inst, err
	}

	return inst.WithContentDigest(ctx, hashutil.HashStrings(
		string(parentDig),
		fmt.Sprintf("with-volatile-variable-name-only:%s", args.Name),
	))
}

type containerWithImageConfigMetadataArgs struct {
	Healthcheck string `default:""`
	OnBuild     dagql.Optional[dagql.ArrayInput[dagql.String]]
	Shell       dagql.Optional[dagql.ArrayInput[dagql.String]]
	Volumes     dagql.Optional[dagql.ArrayInput[dagql.String]]
	StopSignal  string `default:""`
}

func (s *containerSchema) withImageConfigMetadata(ctx context.Context, parent *core.Container, args containerWithImageConfigMetadataArgs) (*core.Container, error) {
	var healthcheck *dockerspec.HealthcheckConfig
	if args.Healthcheck != "" {
		healthcheck = new(dockerspec.HealthcheckConfig)
		if err := json.Unmarshal([]byte(args.Healthcheck), healthcheck); err != nil {
			return nil, fmt.Errorf("failed to decode healthcheck metadata: %w", err)
		}
	}

	return parent.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		if args.Healthcheck != "" {
			cfg.Healthcheck = healthcheck
		}
		if args.OnBuild.Valid {
			onBuild := make([]string, 0, len(args.OnBuild.Value))
			for _, trigger := range args.OnBuild.Value {
				onBuild = append(onBuild, trigger.String())
			}
			cfg.OnBuild = onBuild
		}
		if args.Shell.Valid {
			shellArgs := make([]string, 0, len(args.Shell.Value))
			for _, shellArg := range args.Shell.Value {
				shellArgs = append(shellArgs, shellArg.String())
			}
			cfg.Shell = shellArgs
		}
		if args.Volumes.Valid {
			volumes := make(map[string]struct{}, len(args.Volumes.Value))
			for _, volumePath := range args.Volumes.Value {
				volumes[volumePath.String()] = struct{}{}
			}
			cfg.Volumes = volumes
		}
		if args.StopSignal != "" {
			cfg.StopSignal = args.StopSignal
		}
		return cfg
	})
}

type containerWithoutVariableArgs struct {
	Name string
}

func (s *containerSchema) withoutEnvVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutVariableArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		newEnv := []string{}

		core.WalkEnv(cfg.Env, func(k, _, env string) {
			if k != args.Name {
				newEnv = append(newEnv, env)
			}
		})

		cfg.Env = newEnv

		return cfg
	})
	if err != nil {
		return nil, err
	}
	if parentPendingLazy {
		ctr.Lazy = &core.ContainerWithoutEnvVariableLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Name:      args.Name,
		}
	}
	return ctr, nil
}

func (s *containerSchema) withoutVolatileVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutVariableArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr.WithoutVolatileVariable(args.Name)
	ctr.Lazy = &core.ContainerWithoutVolatileVariableLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

func (s *containerSchema) envVariables(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (dagql.Array[core.EnvVariable], error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return nil, err
	}

	vars := make([]core.EnvVariable, 0, len(parent.Self().Config.Env))

	core.WalkEnv(parent.Self().Config.Env, func(k, v, _ string) {
		vars = append(vars, core.EnvVariable{Name: k, Value: v})
	})

	return vars, nil
}

type containerVariableArgs struct {
	Name string
}

func (s *containerSchema) envVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerVariableArgs) (dagql.Nullable[dagql.String], error) {
	none := dagql.Null[dagql.String]()
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return none, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return none, err
	}

	if val, ok := core.LookupEnv(parent.Self().Config.Env, args.Name); ok {
		return dagql.NonNull(dagql.NewString(val)), nil
	}

	return none, nil
}

type Label struct {
	Name  string `field:"true" doc:"The label name."`
	Value string `field:"true" doc:"The label value."`
}

func (Label) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Label",
		NonNull:   true,
	}
}

func (Label) TypeDescription() string {
	return "A simple key value object that represents a label."
}

func (s *containerSchema) labels(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (dagql.Array[Label], error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return nil, err
	}

	labels := make([]Label, 0, len(parent.Self().Config.Labels))
	for name, value := range parent.Self().Config.Labels {
		label := Label{
			Name:  name,
			Value: value,
		}

		labels = append(labels, label)
	}

	// FIXME(vito): sort, test; order must be stable for IDs to work as expected

	return labels, nil
}

type containerLabelArgs struct {
	Name string
}

func (s *containerSchema) label(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerLabelArgs) (dagql.Nullable[dagql.String], error) {
	none := dagql.Null[dagql.String]()
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return none, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return none, err
	}

	if val, ok := parent.Self().Config.Labels[args.Name]; ok {
		return dagql.NonNull(dagql.NewString(val)), nil
	}

	return none, nil
}

type containerWithMountedDirectoryArgs struct {
	Path         string
	Source       core.DirectoryID
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	ReadOnly     bool   `default:"false"`
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withMountedDirectory(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithMountedDirectoryArgs) (_ *core.Container, rerr error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	dir, err := args.Source.Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr := &core.Container{
		FS:           new(core.LazyAccessor[*core.Directory, *core.Container]),
		MetaSnapshot: new(core.LazyAccessor[bkcache.ImmutableRef, *core.Container]),
	}
	core.CopyContainerMetadata(ctr, parent.Self())
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	ctr.Lazy = &core.ContainerWithMountedDirectoryLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		Source:    dir,
		Owner:     owner,
		Readonly:  args.ReadOnly,
	}
	ctr.Mounts = ctr.Mounts.With(core.ContainerMount{
		Target:          target,
		Readonly:        args.ReadOnly,
		DirectorySource: new(core.LazyAccessor[*core.Directory, *core.Container]),
	})
	return ctr, nil
}

type containerWithAnnotationArgs struct {
	Name  string
	Value string
}

func (s *containerSchema) withAnnotation(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithAnnotationArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.WithAnnotation(ctx, args.Name, args.Value)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithAnnotationLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
		Value:     args.Value,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithoutAnnotationArgs struct {
	Name string
}

func (s *containerSchema) withoutAnnotation(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutAnnotationArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.WithoutAnnotation(ctx, args.Name)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithoutAnnotationLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerExistsArgs struct {
	Path                string
	ExpectedType        dagql.Optional[core.ExistsType]
	DoNotFollowSymlinks bool `default:"false"`
	Expand              bool `default:"false"`
}

func (s *containerSchema) exists(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerExistsArgs) (dagql.Boolean, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return false, fmt.Errorf("failed to get server: %w", err)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return false, err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return false, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return false, err
	}

	exists, err := parent.Self().Exists(ctx, parent, srv, path, args.ExpectedType.Value, args.DoNotFollowSymlinks)
	return dagql.NewBoolean(exists), err
}

func (s *containerSchema) stat(ctx context.Context, parent dagql.ObjectResult[*core.Container], args statArgs) (*core.Stat, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return nil, err
	}
	return parent.Self().Stat(ctx, parent, srv, args.Path, args.DoNotFollowSymlinks)
}

type containerPublishArgs struct {
	Address               dagql.String
	PlatformVariants      []core.ContainerID `default:"[]"`
	ForcedCompression     dagql.Optional[core.ImageLayerCompression]
	MediaTypes            core.ImageMediaTypes `default:"OCI"`
	RegistryService       dagql.Optional[core.ServiceID]
	Protocol              dagql.Optional[core.RegistryProtocol]
	InsecureSkipTLSVerify bool `name:"insecureSkipTLSVerify" default:"false"`
}

func evaluateContainerImageParts(
	ctx context.Context,
	cache *dagql.Cache,
	containers ...dagql.ObjectResult[*core.Container],
) error {
	eg, egctx := errgroup.WithContext(ctx)
	for _, container := range containers {
		if container.Self() == nil {
			continue
		}
		container := container
		eg.Go(func() error {
			return cache.EvaluateParts(egctx, container, core.ContainerPartMetadata, core.ContainerPartFS)
		})
	}
	return eg.Wait()
}

func (s *containerSchema) publish(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerPublishArgs) (dagql.String, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get server: %w", err)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return "", err
	}
	variantResults, err := dagql.LoadIDResults(ctx, srv, args.PlatformVariants)
	if err != nil {
		return "", err
	}
	if err := evaluateContainerImageParts(ctx, cache, append([]dagql.ObjectResult[*core.Container]{parent}, variantResults...)...); err != nil {
		return "", err
	}
	registryTransport, err := registryTransportFromArgs(args.Protocol, args.InsecureSkipTLSVerify)
	if err != nil {
		return "", err
	}
	var registryServices core.ServiceBindings
	if args.RegistryService.Valid {
		service, err := args.RegistryService.Value.Load(ctx, srv)
		if err != nil {
			return "", err
		}
		registryServices, err = core.ContainerRegistryServiceBinding(ctx, args.Address.String(), service)
		if err != nil {
			return "", err
		}
	}
	variants := make([]*core.Container, 0, len(variantResults))
	for _, variant := range variantResults {
		if variant.Self() != nil {
			variants = append(variants, variant.Self())
		}
	}
	ref, err := parent.Self().Publish(
		ctx,
		args.Address.String(),
		variants,
		args.ForcedCompression.Value,
		args.MediaTypes,
		registryServices,
		registryTransport,
	)
	if err != nil {
		return "", err
	}
	return dagql.NewString(ref), nil
}

type containerWithMountedFileArgs struct {
	Path         string
	Source       core.FileID
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withMountedFile(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithMountedFileArgs) (_ *core.Container, rerr error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	file, err := args.Source.Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr := &core.Container{
		FS:           new(core.LazyAccessor[*core.Directory, *core.Container]),
		MetaSnapshot: new(core.LazyAccessor[bkcache.ImmutableRef, *core.Container]),
	}
	core.CopyContainerMetadata(ctr, parent.Self())
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	ctr.Lazy = &core.ContainerWithMountedFileLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		Source:    file,
		Owner:     owner,
		Readonly:  false,
	}
	ctr.Mounts = ctr.Mounts.With(core.ContainerMount{
		Target:     target,
		Readonly:   false,
		FileSource: new(core.LazyAccessor[*core.File, *core.Container]),
	})
	return ctr, nil
}

type containerWithMountedPathDockerfileCompatArgs struct {
	Path       string
	Source     core.DirectoryID
	SourcePath string `internal:"true" default:"/"`
	ReadOnly   bool   `default:"false"`
}

func (s *containerSchema) withMountedPathDockerfileCompat(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithMountedPathDockerfileCompatArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	dir, err := args.Source.Load(ctx, srv)
	if err != nil {
		return inst, err
	}
	dagqlCache, err := dagql.EngineCache(ctx)
	if err != nil {
		return inst, err
	}
	if err := dagqlCache.Evaluate(ctx, dir); err != nil {
		return inst, fmt.Errorf("failed to content hash dockerfile bind mount: evaluate source: %w", err)
	}
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}

	target := absPath(parent.Self().Config.WorkingDir, args.Path)
	sourceIsFile, err := core.DockerfileCompatMountSourceIsFile(ctx, dir, srv, args.SourcePath)
	if err != nil {
		return inst, err
	}
	ctr.Lazy = &core.ContainerWithMountedPathDockerfileCompatLazy{
		LazyState:  core.NewLazyState(),
		Parent:     parent,
		Target:     target,
		Source:     dir,
		SourcePath: args.SourcePath,
		Readonly:   args.ReadOnly,
	}
	mount := core.ContainerMount{
		Target:   target,
		Readonly: args.ReadOnly,
	}
	if sourceIsFile {
		mount.FileSource = new(core.LazyAccessor[*core.File, *core.Container])
	} else {
		mount.DirectorySource = new(core.LazyAccessor[*core.Directory, *core.Container])
	}
	ctr.Mounts = ctr.Mounts.With(mount)

	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	inst, err = dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
	if err != nil {
		return inst, err
	}

	// Key the result on the mounted content rather than the source directory's
	// recipe, mirroring BuildKit's content-checksummed bind-mount cache keys.
	// A taught content digest is a global alias for the result's cache identity,
	// so it must still include everything that distinguishes this container:
	// the parent it was built from and the target/readOnly mount config.
	parentDgst, err := parent.ContentPreferredDigest(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to content hash dockerfile bind mount: parent digest: %w", err)
	}
	srcSnapshot, err := dir.Self().Snapshot.GetOrEval(ctx, dir.Result)
	if err != nil {
		return inst, fmt.Errorf("failed to content hash dockerfile bind mount: source snapshot: %w", err)
	}
	srcRoot, err := dir.Self().Dir.GetOrEval(ctx, dir.Result)
	if err != nil {
		return inst, fmt.Errorf("failed to content hash dockerfile bind mount: source path: %w", err)
	}
	srcHash := "empty"
	if srcSnapshot != nil {
		dgst, err := core.GetContentHashFromFile(ctx, srcSnapshot, path.Join(srcRoot, args.SourcePath))
		if err != nil {
			return inst, fmt.Errorf("failed to content hash dockerfile bind mount at %q: %w", args.SourcePath, err)
		}
		srcHash = string(dgst)
	}
	return inst.WithContentDigest(ctx, hashutil.HashStrings(
		"__withMountedPathDockerfileCompat",
		string(parentDgst),
		target,
		strconv.FormatBool(args.ReadOnly),
		srcHash,
	))
}

type containerWithMountedCacheArgs struct {
	Path         string
	Cache        core.CacheVolumeID
	Source       dagql.Optional[core.DirectoryID]
	Sharing      core.CacheSharingMode `default:"SHARED"`
	Owner        string                `default:""`
	InheritOwner bool                  `default:"false"`
	Expand       bool                  `default:"false"`
}

func (s *containerSchema) withMountedCacheDynamicInputs(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Container],
	args containerWithMountedCacheArgs,
	req *dagql.CallRequest,
) error {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return err
	}
	hasSourceArg := req.HasArg("source")
	hasSharingArg := req.HasArg("sharing")
	hasOwnerArg := req.HasArg("owner")
	hasInheritOwnerArg := req.HasArg("inheritOwner")
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return err
	}

	cache, err := args.Cache.Load(ctx, srv)
	if err != nil {
		return err
	}
	if cache.Self() == nil {
		return errors.New("cache volume is nil")
	}

	cacheSelf := cache.Self()
	sharing := cacheSelf.Sharing
	if sharing == "" {
		sharing = core.CacheSharingModeShared
	}
	needsRewrite := hasSourceArg || hasSharingArg || hasOwnerArg
	if hasSharingArg {
		sharing = args.Sharing
	}

	owner := cacheSelf.Owner
	if hasOwnerArg {
		owner = args.Owner
	}
	if args.InheritOwner {
		if hasOwnerArg && args.Owner != "" {
			return errors.New("cannot set both owner and inheritOwner")
		}
		owner = parent.Self().Config.User
	}
	if hasInheritOwnerArg {
		needsRewrite = true
	}
	if ownerNeedsLookup(owner) {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		if err := cache.Evaluate(ctx, parent); err != nil {
			return err
		}
		owner, err = parent.Self().ResolveOwnership(ctx, parent, owner)
		if err != nil {
			return fmt.Errorf("failed to resolve ownership for %s: %w", owner, err)
		}
		needsRewrite = true
	}

	source := cacheSelf.Source
	if hasSourceArg {
		source = dagql.Null[dagql.ObjectResult[*core.Directory]]()
		if args.Source.Valid {
			loaded, err := args.Source.Value.Load(ctx, srv)
			if err != nil {
				return err
			}
			source = dagql.NonNull(loaded)
		}
	}
	if !needsRewrite {
		return nil
	}

	cacheSelectArgs := []dagql.NamedInput{
		{Name: "key", Value: dagql.NewString(cacheSelf.Key)},
		{Name: "namespace", Value: dagql.NewString(cacheSelf.Namespace)},
		{Name: "sharing", Value: sharing},
		{Name: "owner", Value: dagql.NewString(owner)},
	}
	if source.Valid {
		sourceID, err := source.Value.ID()
		if err != nil {
			return fmt.Errorf("resolve cache source ID: %w", err)
		}
		cacheSelectArgs = append(cacheSelectArgs, dagql.NamedInput{
			Name:  "source",
			Value: dagql.Opt(dagql.NewID[*core.Directory](sourceID)),
		})
	}

	var resolvedCache dagql.Result[*core.CacheVolume]
	if err := srv.Select(ctx, srv.Root(), &resolvedCache, dagql.Selector{
		Field: "cacheVolume",
		Args:  cacheSelectArgs,
	}); err != nil {
		return err
	}
	resolvedCacheID, err := resolvedCache.ID()
	if err != nil {
		return fmt.Errorf("resolve rewritten cache volume ID: %w", err)
	}
	args.Cache = dagql.NewID[*core.CacheVolume](resolvedCacheID)
	return req.SetArgInput(ctx, "cache", args.Cache, false)
}

func (s *containerSchema) withMountedCache(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithMountedCacheArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	cache, err := args.Cache.Load(ctx, srv)
	if err != nil {
		return nil, err
	}
	if cache.Self() == nil {
		return nil, errors.New("cache volume is nil")
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	if !parentPendingLazy {
		_, err := ctr.WithMountedCache(ctx, target, cache)
		return ctr, err
	}
	ctr.Lazy = &core.ContainerWithMountedCacheLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		Cache:     cache,
	}
	ctr.Mounts = ctr.Mounts.With(core.ContainerMount{
		Target: target,
		CacheSource: &core.CacheMountSource{
			Volume: cache,
		},
	})
	return ctr, nil
}

type containerWithMountedVolumeArgs struct {
	Path     string
	Volume   core.VolumeID
	ReadOnly bool `default:"false"`
	Expand   bool `default:"false"`
}

func (s *containerSchema) withMountedVolume(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithMountedVolumeArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	volume, err := args.Volume.Load(ctx, srv)
	if err != nil {
		return nil, err
	}
	if volume.Self() == nil {
		return nil, errors.New("volume is nil")
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	ctr.Lazy = &core.ContainerWithMountedVolumeLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		Volume:    volume,
		Readonly:  args.ReadOnly,
	}
	ctr.Mounts = ctr.Mounts.With(core.ContainerMount{
		Target:   target,
		Readonly: args.ReadOnly,
		VolumeSource: &core.VolumeMountSource{
			Volume: volume,
		},
	})
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithMountedTempArgs struct {
	Path   string
	Size   dagql.Optional[dagql.Int]
	Expand bool `default:"false"`
}

func (s *containerSchema) withMountedTemp(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithMountedTempArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	ctr.Lazy = &core.ContainerWithMountedTempLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		Size:      args.Size.Value.Int(),
	}
	ctr.Mounts = ctr.Mounts.With(core.ContainerMount{
		Target: target,
		TmpfsSource: &core.TmpfsMountSource{
			Size: args.Size.Value.Int(),
		},
	})
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithoutMountArgs struct {
	Path   string
	Expand bool `default:"false"`
}

func (s *containerSchema) withoutMount(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutMountArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	if _, err := ctr.WithoutMount(ctx, target); err != nil {
		return nil, err
	}
	if parentPendingLazy {
		ctr.Lazy = &core.ContainerWithoutMountLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Target:    target,
		}
	}
	return ctr, nil
}

func (s *containerSchema) mounts(ctx context.Context, parent dagql.ObjectResult[*core.Container], _ struct{}) (dagql.Array[dagql.String], error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return nil, err
	}

	targets, err := parent.Self().MountTargets(ctx)
	if err != nil {
		return nil, err
	}
	return dagql.NewStringArray(targets...), nil
}

type containerWithLabelArgs struct {
	Name  string
	Value string
}

func (s *containerSchema) withLabel(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithLabelArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		if cfg.Labels == nil {
			cfg.Labels = make(map[string]string)
		}
		cfg.Labels[args.Name] = args.Value
		return cfg
	})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithLabelLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
		Value:     args.Value,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithoutLabelArgs struct {
	Name string
}

func (s *containerSchema) withoutLabel(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutLabelArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		delete(cfg.Labels, args.Name)
		return cfg
	})
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithoutLabelLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type WithHealthcheckArgs struct {
	Args          []string
	Shell         dagql.Optional[dagql.Boolean]
	Timeout       dagql.Optional[dagql.String]
	Interval      dagql.Optional[dagql.String]
	StartPeriod   dagql.Optional[dagql.String]
	StartInterval dagql.Optional[dagql.String]
	Retries       dagql.Optional[dagql.Int]
}

func (s *containerSchema) withHealthcheck(ctx context.Context, parent *core.Container, args WithHealthcheckArgs) (*core.Container, error) {
	var healthcheck dockerspec.HealthcheckConfig
	if args.Shell.Valid && args.Shell.Value.Bool() {
		if len(args.Args) != 1 {
			return nil, fmt.Errorf("WithHealthcheck args must be a single element when shell mode is set")
		}
		healthcheck.Test = append([]string{"CMD-SHELL"}, args.Args...)
	} else {
		if len(args.Args) == 0 {
			return nil, fmt.Errorf("WithHealthcheck args is missing")
		}
		healthcheck.Test = append([]string{"CMD"}, args.Args...)
	}
	if args.Timeout.Valid {
		timeout, err := time.ParseDuration(args.Timeout.Value.String())
		if err != nil {
			return nil, err
		}
		healthcheck.Timeout = timeout
	}
	if args.Interval.Valid {
		interval, err := time.ParseDuration(args.Interval.Value.String())
		if err != nil {
			return nil, err
		}
		healthcheck.Interval = interval
	}
	if args.StartPeriod.Valid {
		startPeriod, err := time.ParseDuration(args.StartPeriod.Value.String())
		if err != nil {
			return nil, err
		}
		healthcheck.StartPeriod = startPeriod
	}
	if args.StartInterval.Valid {
		startInterval, err := time.ParseDuration(args.StartInterval.Value.String())
		if err != nil {
			return nil, err
		}
		healthcheck.StartInterval = startInterval
	}
	if args.Retries.Valid {
		healthcheck.Retries = int(args.Retries.Value)
	}
	return parent.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.Healthcheck = &healthcheck
		return cfg
	})
}

func (s *containerSchema) withoutHealthcheck(ctx context.Context, parent *core.Container, args struct{}) (*core.Container, error) {
	return parent.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
		cfg.Healthcheck = nil
		return cfg
	})
}

type HealthcheckConfig struct {
	Args          []string `field:"true" doc:"Healthcheck command arguments."`
	Shell         bool     `field:"true" doc:"Healthcheck command is a shell command."`
	Timeout       string   `field:"true" doc:"Healthcheck timeout. Example:3s"`
	Interval      string   `field:"true" doc:"Interval between running healthcheck. Example:30s"`
	StartPeriod   string   `field:"true" doc:"StartPeriod allows for failures during this initial startup period which do not count towards maximum number of retries. Example:0s"`
	StartInterval string   `field:"true" doc:"StartInterval configures the duration between checks during the startup phase. Example:5s"`
	Retries       int      `field:"true" doc:"The maximum number of consecutive failures before the container is marked as unhealthy. Example:3"`
}

func (HealthcheckConfig) Type() *ast.Type {
	return &ast.Type{
		NamedType: "HealthcheckConfig",
		NonNull:   true,
	}
}

func (HealthcheckConfig) TypeDescription() string {
	return "Image healthcheck configuration."
}

func (s *containerSchema) healthcheck(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (inst dagql.Nullable[HealthcheckConfig], err error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return inst, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return inst, err
	}
	if parent.Self().Config.Healthcheck == nil || len(parent.Self().Config.Healthcheck.Test) == 0 || parent.Self().Config.Healthcheck.Test[0] == "NONE" {
		return dagql.Null[HealthcheckConfig](), nil
	}

	hcc := HealthcheckConfig{
		Timeout:       parent.Self().Config.Healthcheck.Timeout.String(),
		Interval:      parent.Self().Config.Healthcheck.Interval.String(),
		StartPeriod:   parent.Self().Config.Healthcheck.StartPeriod.String(),
		StartInterval: parent.Self().Config.Healthcheck.StartInterval.String(),
		Retries:       parent.Self().Config.Healthcheck.Retries,
	}

	testType := parent.Self().Config.Healthcheck.Test[0]
	switch testType {
	case "CMD-SHELL":
		if len(parent.Self().Config.Healthcheck.Test) != 2 {
			return inst, fmt.Errorf("HEALTHCHECK command is a shell command, but got unexpected length of %d; cmd=%v",
				len(parent.Self().Config.Healthcheck.Test), parent.Self().Config.Healthcheck.Test)
		}
		hcc.Shell = true
	case "CMD":
		if len(parent.Self().Config.Healthcheck.Test) < 2 {
			return inst, fmt.Errorf("HEALTHCHECK command is empty")
		}
	default:
		return inst, fmt.Errorf("unexpected HEALTHCHECK command of type %s found", testType)
	}
	hcc.Args = slices.Clone(parent.Self().Config.Healthcheck.Test[1:])
	return dagql.NonNull(hcc), nil
}

type containerDirectoryArgs struct {
	Path   string
	Expand bool `default:"false"`
}

//nolint:dupl // symmetric with (*containerSchema).file; sharing hides Directory vs File specifics
func (s *containerSchema) directory(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerDirectoryArgs) (dagql.ObjectResult[*core.Directory], error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return dagql.ObjectResult[*core.Directory]{}, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return dagql.ObjectResult[*core.Directory]{}, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return dagql.ObjectResult[*core.Directory]{}, err
	}
	resolvedPath := absPath(parent.Self().Config.WorkingDir, path)

	dir := &core.Directory{
		Platform: parent.Self().Platform,
		Services: slices.Clone(parent.Self().Services),
		Lazy: &core.ContainerDirectoryLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Path:      path,
		},
		Dir:      new(core.LazyAccessor[string, *core.Directory]),
		Snapshot: new(core.LazyAccessor[bkcache.ImmutableRef, *core.Directory]),
	}
	dir.SetPath(resolvedPath)
	return dagql.NewObjectResultForCurrentCall(ctx, srv, dir)
}

type containerFileArgs struct {
	Path   string
	Expand bool `default:"false"`
}

//nolint:dupl // symmetric with (*containerSchema).directory; sharing hides File vs Directory specifics
func (s *containerSchema) file(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerFileArgs) (dagql.ObjectResult[*core.File], error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return dagql.ObjectResult[*core.File]{}, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return dagql.ObjectResult[*core.File]{}, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return dagql.ObjectResult[*core.File]{}, err
	}
	resolvedPath := absPath(parent.Self().Config.WorkingDir, path)

	file := &core.File{
		Platform: parent.Self().Platform,
		Services: slices.Clone(parent.Self().Services),
		Lazy: &core.ContainerFileLazy{
			LazyState: core.NewLazyState(),
			Parent:    parent,
			Path:      path,
		},
		File:     new(core.LazyAccessor[string, *core.File]),
		Snapshot: new(core.LazyAccessor[bkcache.ImmutableRef, *core.File]),
	}
	file.SetPath(resolvedPath)
	return dagql.NewObjectResultForCurrentCall(ctx, srv, file)
}

func absPath(workDir string, containerPath string) string {
	if path.IsAbs(containerPath) {
		return containerPath
	}

	if workDir == "" {
		workDir = "/"
	}

	return path.Join(workDir, containerPath)
}

func ownerNeedsLookup(owner string) bool {
	if owner == "" {
		return false
	}

	uidOrName, gidOrName, hasGroup := strings.Cut(owner, ":")
	if _, err := strconv.Atoi(uidOrName); err != nil {
		return true
	}
	if hasGroup {
		if _, err := strconv.Atoi(gidOrName); err != nil {
			return true
		}
	}
	return false
}

func inheritedOwner(parent dagql.ObjectResult[*core.Container], owner string, inheritOwner bool) (string, error) {
	if !inheritOwner {
		return owner, nil
	}
	if owner != "" {
		return "", errors.New("cannot set both owner and inheritOwner")
	}
	return parent.Self().Config.User, nil
}

// Demand metadata before reading Container configuration, platform or mount shape.
func evaluateContainerMetadata(ctx context.Context, parent dagql.ObjectResult[*core.Container]) error {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	return cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata)
}

func cloneContainerForSchemaChild(ctx context.Context, parent dagql.ObjectResult[*core.Container]) (*core.Container, bool, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, false, err
	}
	// Foreign shells report pending work here too, so the child's ordinary
	// operation keeps its parent dependency and delegates unresolved parts.
	parentPendingLazy := dagql.HasPendingLazyEvaluation(parent)

	clonedFS, err := core.CloneContainerDirectoryAccessor(ctx, parent.Self().FS)
	if err != nil {
		return nil, false, err
	}
	clonedMounts, err := core.CloneContainerMounts(ctx, parent.Self().Mounts)
	if err != nil {
		return nil, false, err
	}
	clonedMeta, err := core.CloneContainerMetaSnapshot(ctx, parent.Self().MetaSnapshot)
	if err != nil {
		return nil, false, err
	}
	ctr := &core.Container{
		// CanUseFromContentDigest intentionally defaults to false for schema
		// children: any container transformation may carry state through From.
		FS:                 clonedFS,
		MetaSnapshot:       clonedMeta,
		Config:             core.CloneContainerImageConfig(parent.Self().Config),
		EnabledGPUs:        slices.Clone(parent.Self().EnabledGPUs),
		Mounts:             clonedMounts,
		Platform:           parent.Self().Platform,
		Annotations:        slices.Clone(parent.Self().Annotations),
		Secrets:            slices.Clone(parent.Self().Secrets),
		Sockets:            slices.Clone(parent.Self().Sockets),
		ImageRef:           parent.Self().ImageRef,
		Ports:              slices.Clone(parent.Self().Ports),
		Services:           slices.Clone(parent.Self().Services),
		DefaultTerminalCmd: parent.Self().DefaultTerminalCmd,
		SystemEnvNames:     slices.Clone(parent.Self().SystemEnvNames),
		VolatileEnv:        slices.Clone(parent.Self().VolatileEnv),
		DefaultArgs:        parent.Self().DefaultArgs,
	}
	return ctr, parentPendingLazy, nil
}

// evaluateOverBuiltParent runs a mutation's operation right away when its
// parent was already built, as the mutation did before it saved the operation.
func evaluateOverBuiltParent(ctx context.Context, ctr *core.Container, parentPendingLazy bool) error {
	if parentPendingLazy {
		return nil
	}
	return ctr.Evaluate(ctx)
}

func expandEnvVar(ctx context.Context, parent *core.Container, input string, expand bool) (string, error) {
	if !expand {
		return input, nil
	}

	cfg, err := parent.ImageConfig(ctx)
	if err != nil {
		return "", err
	}

	secretEnvs := []string{}
	for _, secret := range parent.Secrets {
		secretEnvs = append(secretEnvs, secret.EnvName)
	}
	volatileEnvs := []string{}
	core.WalkEnv(parent.VolatileEnv, func(name, _, _ string) {
		volatileEnvs = append(volatileEnvs, name)
	})

	var secretEnvFoundError error
	expanded := os.Expand(input, func(k string) string {
		// set error if its a secret env variable
		if slices.Contains(secretEnvs, k) {
			secretEnvFoundError = fmt.Errorf("expand cannot be used with secret env variable %q", k)
			return ""
		}
		if slices.Contains(volatileEnvs, k) {
			secretEnvFoundError = fmt.Errorf("expand cannot be used with volatile env variable %q", k)
			return ""
		}

		v, _ := core.LookupEnv(cfg.Env, k)
		return v
	})

	if secretEnvFoundError != nil {
		return "", secretEnvFoundError
	}

	return expanded, nil
}

type containerWithSecretVariableArgs struct {
	Name   string
	Secret core.SecretID
}

func (s *containerSchema) withSecretVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithSecretVariableArgs) (*core.Container, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	secret, err := args.Secret.Load(ctx, srv)
	if err != nil {
		return nil, err
	}
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.WithSecretVariable(ctx, args.Name, secret)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithSecretVariableLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
		Secret:    secret,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithoutSecretVariableArgs struct {
	Name string
}

func (s *containerSchema) withoutSecretVariable(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutSecretVariableArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.WithoutSecretVariable(ctx, args.Name)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithoutSecretVariableLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Name:      args.Name,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithMountedSecretArgs struct {
	Path         string
	Source       core.SecretID
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	Mode         int    `default:"0400"` // FIXME(vito): verify octal
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withMountedSecret(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithMountedSecretArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	secret, err := args.Source.Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return nil, err
	}
	var secretOwner *core.Ownership
	if owner != "" {
		ownership, err := ctr.ResolveOwnership(ctx, parent, owner)
		if err != nil {
			return nil, err
		}
		uid, gid, _ := strings.Cut(ownership, ":")
		uidInt, err := strconv.Atoi(uid)
		if err != nil {
			return nil, err
		}
		gidInt, err := strconv.Atoi(gid)
		if err != nil {
			return nil, err
		}
		secretOwner = &core.Ownership{UID: uidInt, GID: gidInt}
	}
	ctr.Secrets = append(ctr.Secrets, core.ContainerSecret{
		Secret:    secret,
		MountPath: target,
		Owner:     secretOwner,
		Mode:      fs.FileMode(args.Mode),
	})
	ctr.Lazy = &core.ContainerWithMountedSecretLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		Source:    secret,
		Owner:     owner,
		Mode:      fs.FileMode(args.Mode),
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithDirectoryArgs struct {
	WithDirectoryArgs
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withDirectory(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithDirectoryArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	dir, err := cmp.Or(args.Source, args.Directory).Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithDirectoryLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Path:      path,
		Source:    dir,
		Filter:    args.CopyFilter,
		Owner:     owner,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithFileArgs struct {
	WithFileArgs
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withFile(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithFileArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return inst, err
	}

	var perms *int
	if args.Permissions.Valid {
		p := int(args.Permissions.Value)
		perms = &p
	}

	file, err := args.Source.Load(ctx, srv)
	if err != nil {
		return inst, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return inst, err
	}
	ctr.Lazy = &core.ContainerWithFileLazy{
		LazyState:   core.NewLazyState(),
		Parent:      parent,
		Path:        path,
		Source:      file,
		Permissions: perms,
		Owner:       owner,
	}

	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	inst, err = dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
	return inst, err
}

type containerWithFilesArgs struct {
	WithFilesArgs
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withFiles(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithFilesArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	files, err := dagql.LoadIDResults(ctx, srv, args.Sources)
	if err != nil {
		return inst, err
	}

	paths, err := core.SourceFilePaths(ctx, files)
	if err != nil {
		return inst, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return inst, err
	}

	var perms *int
	if args.Permissions.Valid {
		p := int(args.Permissions.Value)
		perms = &p
	}
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return inst, err
	}
	current := parent
	for i, file := range files {
		filePath := paths[i]
		fileID, err := file.ID()
		if err != nil {
			return inst, err
		}
		filePath = filepath.Join(path, filepath.Base(filePath))
		selectArgs := []dagql.NamedInput{
			{Name: "path", Value: dagql.String(filePath)},
			{Name: "source", Value: dagql.NewID[*core.File](fileID)},
		}
		if perms != nil {
			selectArgs = append(selectArgs, dagql.NamedInput{Name: "permissions", Value: dagql.Opt(dagql.Int(*perms))})
		}
		if owner != "" {
			selectArgs = append(selectArgs, dagql.NamedInput{Name: "owner", Value: dagql.String(owner)})
		}
		var next dagql.ObjectResult[*core.Container]
		if err := srv.Select(ctx, current, &next, dagql.Selector{
			Field: "withFile",
			Args:  selectArgs,
		}); err != nil {
			return inst, err
		}
		current = next
	}
	return current, nil
}

type containerWithoutDirectoryArgs struct {
	Path   string
	Expand bool `default:"false"`
}

//nolint:dupl // symmetric with withoutFile; the distinct argument types preserve the schema operations
func (s *containerSchema) withoutDirectory(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutDirectoryArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return inst, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	ctr.Lazy = &core.ContainerWithoutPathLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Path:      path,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
}

type containerWithoutFileArgs struct {
	Path   string
	Expand bool `default:"false"`
}

//nolint:dupl // symmetric with withoutDirectory; the distinct argument types preserve the schema operations
func (s *containerSchema) withoutFile(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutFileArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return inst, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	ctr.Lazy = &core.ContainerWithoutPathLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Path:      path,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
}

type containerWithoutFilesArgs struct {
	Paths  []string
	Expand bool `default:"false"`
}

func (s *containerSchema) withoutFiles(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutFilesArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	paths := args.Paths
	for i, p := range args.Paths {
		paths[i], err = expandEnvVar(ctx, parent.Self(), p, args.Expand)
		if err != nil {
			return inst, err
		}
	}

	current := parent
	for _, path := range paths {
		var next dagql.ObjectResult[*core.Container]
		if err := srv.Select(ctx, current, &next, dagql.Selector{
			Field: "withoutFile",
			Args: []dagql.NamedInput{
				{Name: "path", Value: dagql.String(path)},
			},
		}); err != nil {
			return inst, err
		}
		current = next
	}
	return current, nil
}

type containerWithNewFileArgs struct {
	Path         string
	Contents     string
	Permissions  int    `default:"0644"`
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withNewFile(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithNewFileArgs) (inst dagql.ObjectResult[*core.Container], err error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return inst, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return inst, err
	}

	_, fileName := filepath.Split(filepath.Clean(path))
	var newFile dagql.ObjectResult[*core.File]
	fileArgs := []dagql.NamedInput{
		{Name: "name", Value: dagql.String(fileName)},
		{Name: "contents", Value: dagql.String(args.Contents)},
	}
	if args.Permissions != 0 {
		fileArgs = append(fileArgs, dagql.NamedInput{
			Name:  "permissions",
			Value: dagql.Opt(dagql.Int(args.Permissions)),
		})
	}
	if err := srv.Select(ctx, srv.Root(), &newFile, dagql.Selector{
		Field: "file",
		Args:  fileArgs,
	}); err != nil {
		return inst, fmt.Errorf("failed to create new file %s: %w", path, err)
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return inst, err
	}
	ctr.Lazy = &core.ContainerWithFileLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Path:      path,
		Source:    newFile,
		Owner:     owner,
	}

	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
}

type containerWithNewFileArgsLegacy struct {
	Path        string
	Contents    string `default:""`
	Permissions int    `default:"0644"`
	Owner       string `default:""`
}

func (s *containerSchema) withNewFileLegacy(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithNewFileArgsLegacy) (inst dagql.ObjectResult[*core.Container], err error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}

	_, fileName := filepath.Split(filepath.Clean(args.Path))
	var newFile dagql.ObjectResult[*core.File]
	fileArgs := []dagql.NamedInput{
		{Name: "name", Value: dagql.String(fileName)},
		{Name: "contents", Value: dagql.String(args.Contents)},
	}
	if args.Permissions != 0 {
		fileArgs = append(fileArgs, dagql.NamedInput{
			Name:  "permissions",
			Value: dagql.Opt(dagql.Int(args.Permissions)),
		})
	}
	if err := srv.Select(ctx, srv.Root(), &newFile, dagql.Selector{
		Field: "file",
		Args:  fileArgs,
	}); err != nil {
		return inst, fmt.Errorf("failed to create new file %s: %w", args.Path, err)
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return inst, err
	}
	ctr.Lazy = &core.ContainerWithFileLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Path:      args.Path,
		Source:    newFile,
		Owner:     args.Owner,
	}

	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return inst, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, ctr)
}

type containerWithUnixSocketArgs struct {
	Path         string
	Source       core.SocketID
	Owner        string `default:""`
	InheritOwner bool   `default:"false"`
	Expand       bool   `default:"false"`
}

func (s *containerSchema) withUnixSocket(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithUnixSocketArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	socket, err := args.Source.Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	owner, err := inheritedOwner(parent, args.Owner, args.InheritOwner)
	if err != nil {
		return nil, err
	}
	if !parentPendingLazy {
		_, err := ctr.WithUnixSocketFromParent(ctx, parent, target, socket, owner)
		return ctr, err
	}
	var socketOwner *core.Ownership
	if owner != "" {
		ownership, err := ctr.ResolveOwnership(ctx, parent, owner)
		if err != nil {
			return nil, err
		}
		uid, gid, _ := strings.Cut(ownership, ":")
		uidInt, err := strconv.Atoi(uid)
		if err != nil {
			return nil, err
		}
		gidInt, err := strconv.Atoi(gid)
		if err != nil {
			return nil, err
		}
		socketOwner = &core.Ownership{UID: uidInt, GID: gidInt}
	}
	replaced := false
	for i, sock := range ctr.Sockets {
		if sock.ContainerPath != target {
			continue
		}
		ctr.Sockets[i] = core.ContainerSocket{
			Source:        socket,
			ContainerPath: target,
			Owner:         socketOwner,
		}
		replaced = true
		break
	}
	if !replaced {
		ctr.Sockets = append(ctr.Sockets, core.ContainerSocket{
			Source:        socket,
			ContainerPath: target,
			Owner:         socketOwner,
		})
	}
	ctr.Lazy = &core.ContainerWithUnixSocketLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
		Source:    socket,
		Owner:     owner,
	}
	return ctr, nil
}

type containerWithoutUnixSocketArgs struct {
	Path   string
	Expand bool `default:"false"`
}

func (s *containerSchema) withoutUnixSocket(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutUnixSocketArgs) (*core.Container, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return nil, err
	}
	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	target := absPath(parent.Self().Config.WorkingDir, path)
	if !parentPendingLazy {
		_, err := ctr.WithoutUnixSocket(ctx, target)
		return ctr, err
	}
	for i, sock := range ctr.Sockets {
		if sock.ContainerPath != target {
			continue
		}
		ctr.Sockets = slices.Delete(ctr.Sockets, i, i+1)
		break
	}
	ctr.Lazy = &core.ContainerWithoutUnixSocketLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Target:    target,
	}
	return ctr, nil
}

func (s *containerSchema) platform(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (core.Platform, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return core.Platform{}, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return core.Platform{}, err
	}
	return parent.Self().Platform, nil
}

type containerExportArgs struct {
	Path              string
	PlatformVariants  []core.ContainerID `default:"[]"`
	ForcedCompression dagql.Optional[core.ImageLayerCompression]
	MediaTypes        core.ImageMediaTypes `default:"OCI"`
	Expand            bool                 `default:"false"`
}

func (s *containerSchema) export(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerExportArgs) (dagql.String, error) {
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return "", err
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get server: %w", err)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return "", err
	}
	variantResults, err := dagql.LoadIDResults(ctx, srv, args.PlatformVariants)
	if err != nil {
		return "", err
	}
	if err := evaluateContainerImageParts(ctx, cache, append([]dagql.ObjectResult[*core.Container]{parent}, variantResults...)...); err != nil {
		return "", err
	}
	variants := make([]*core.Container, 0, len(variantResults))
	for _, variant := range variantResults {
		if variant.Self() != nil {
			variants = append(variants, variant.Self())
		}
	}

	path, err := expandEnvVar(ctx, parent.Self(), args.Path, args.Expand)
	if err != nil {
		return "", err
	}

	_, err = parent.Self().Export(
		ctx,
		core.ExportOpts{
			Dest:              path,
			PlatformVariants:  variants,
			ForcedCompression: args.ForcedCompression.Value,
			MediaTypes:        args.MediaTypes,
			Tar:               true,
		},
	)
	if err != nil {
		return "", err
	}
	bk, err := query.Engine(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get engine client: %w", err)
	}
	stat, err := bk.StatCallerHostPath(ctx, path, true)
	if err != nil {
		return "", err
	}
	return dagql.String(stat.Path), err
}

func (s *containerSchema) exportLegacy(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerExportArgs) (dagql.Boolean, error) {
	_, err := s.export(ctx, parent, args)
	if err != nil {
		return false, err
	}
	return true, nil
}

type containerAsTarballArgs struct {
	PlatformVariants  []core.ContainerID `default:"[]"`
	ForcedCompression dagql.Optional[core.ImageLayerCompression]
	MediaTypes        core.ImageMediaTypes `default:"OCI"`
}

func (s *containerSchema) asTarball(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Container],
	args containerAsTarballArgs,
) (inst dagql.ObjectResult[*core.File], rerr error) {
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return inst, err
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}
	platformVariantResults, err := dagql.LoadIDResults(ctx, srv, args.PlatformVariants)
	if err != nil {
		return inst, err
	}
	platformVariants := make([]dagql.ObjectResult[*core.Container], 0, len(platformVariantResults))
	for _, variant := range platformVariantResults {
		if variant.Self() != nil {
			platformVariants = append(platformVariants, variant)
		}
	}
	return newContainerImageFile(ctx, srv, query, &core.FileContainerImageLazy{
		LazyState:         core.NewLazyState(),
		Parent:            parent,
		PlatformVariants:  platformVariants,
		ForcedCompression: args.ForcedCompression.Value,
		MediaTypes:        args.MediaTypes,
	})
}

func newContainerImageFile(ctx context.Context, srv *dagql.Server, query *core.Query, lazy *core.FileContainerImageLazy) (dagql.ObjectResult[*core.File], error) {
	file, err := evaluatedFile(ctx, query, lazy)
	if err != nil {
		return dagql.ObjectResult[*core.File]{}, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, file)
}

type containerExportImageArgs struct {
	Name string

	PlatformVariants  []core.ContainerID `default:"[]"`
	ForcedCompression dagql.Optional[core.ImageLayerCompression]
	MediaTypes        core.ImageMediaTypes `default:"OCI"`
}

func (s *containerSchema) exportImage(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Container],
	args containerExportImageArgs,
) (_ core.Void, rerr error) {
	refName, err := reference.ParseNormalizedNamed(args.Name)
	if err != nil {
		return core.Void{}, fmt.Errorf("failed to parse image address %s: %w", args.Name, err)
	}
	refName = reference.TagNameOnly(refName)

	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return core.Void{}, err
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return core.Void{}, fmt.Errorf("failed to get server: %w", err)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return core.Void{}, err
	}
	platformVariantResults, err := dagql.LoadIDResults(ctx, srv, args.PlatformVariants)
	if err != nil {
		return core.Void{}, err
	}
	if err := evaluateContainerImageParts(ctx, cache, append([]dagql.ObjectResult[*core.Container]{parent}, platformVariantResults...)...); err != nil {
		return core.Void{}, err
	}
	platformVariants := make([]*core.Container, 0, len(platformVariantResults))
	for _, variant := range platformVariantResults {
		if variant.Self() != nil {
			platformVariants = append(platformVariants, variant.Self())
		}
	}

	_, err = parent.Self().Export(ctx, core.ExportOpts{
		Dest:              refName.String(),
		PlatformVariants:  platformVariants,
		ForcedCompression: args.ForcedCompression.Value,
		MediaTypes:        args.MediaTypes,
		Tar:               false,
	})
	if err != nil {
		return core.Void{}, err
	}
	return core.Void{}, nil
}

type containerImportArgs struct {
	Source core.FileID
	Tag    string `default:""`
}

func (s *containerSchema) import_(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerImportArgs) (*core.Container, error) {
	start := time.Now()
	slog.ExtraDebug("importing container", "source", args.Source.Display(), "tag", args.Tag)
	defer func() {
		slog.ExtraDebug("done importing container", "source", args.Source.Display(), "tag", args.Tag, "took", start)
	}()
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	source, err := args.Source.Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	ctr, _, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerImportLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Source:    source,
		Tag:       args.Tag,
	}
	return ctr, nil
}

type containerWithRegistryAuthArgs struct {
	Address  string
	Username string
	Secret   core.SecretID
}

func (s *containerSchema) withRegistryAuth(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithRegistryAuthArgs) (dagql.ObjectResult[*core.Container], error) {
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return parent, err
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return parent, fmt.Errorf("failed to get server: %w", err)
	}

	secret, err := args.Secret.Load(ctx, srv)
	if err != nil {
		return parent, err
	}

	secretBytes, err := secret.Self().Plaintext(ctx)
	if err != nil {
		return parent, err
	}

	auth, err := query.Auth(ctx)
	if err != nil {
		return parent, err
	}
	if err := auth.AddCredential(args.Address, args.Username, string(secretBytes)); err != nil {
		return parent, err
	}

	// Registry credentials belong to the session, not the container.
	return parent, nil
}

type containerWithoutRegistryAuthArgs struct {
	Address string
}

func (s *containerSchema) withoutRegistryAuth(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutRegistryAuthArgs) (dagql.ObjectResult[*core.Container], error) {
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return parent, err
	}
	auth, err := query.Auth(ctx)
	if err != nil {
		return parent, err
	}
	if err := auth.RemoveCredential(args.Address); err != nil {
		return parent, err
	}

	// Registry credentials belong to the session, not the container.
	return parent, nil
}

func (s *containerSchema) imageRef(ctx context.Context, parent *core.Container, args struct{}) (string, error) {
	return parent.ImageRefOrErr(ctx)
}

type containerManifestArgs struct {
	ForcedCompression dagql.Optional[core.ImageLayerCompression]
	MediaTypes        core.ImageMediaTypes `default:"OCI"`
}

func (s *containerSchema) manifest(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Container],
	args containerManifestArgs,
) (inst dagql.ObjectResult[*core.File], err error) {
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return inst, err
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}
	return newContainerImageFile(ctx, srv, query, &core.FileContainerImageLazy{
		LazyState:         core.NewLazyState(),
		Parent:            parent,
		ForcedCompression: args.ForcedCompression.Value,
		MediaTypes:        args.MediaTypes,
		Manifest:          true,
	})
}

type containerLayerArgs struct {
	ID                string
	ForcedCompression dagql.Optional[core.ImageLayerCompression]
	MediaTypes        core.ImageMediaTypes `default:"OCI"`
}

func (s *containerSchema) layer(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Container],
	args containerLayerArgs,
) (inst dagql.ObjectResult[*core.File], err error) {
	query, err := core.CurrentQuery(ctx)
	if err != nil {
		return inst, err
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return inst, fmt.Errorf("failed to get server: %w", err)
	}
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return inst, err
	}
	if err := evaluateContainerImageParts(ctx, cache, parent); err != nil {
		return inst, err
	}
	parentDigest, err := parent.RecipeDigest(ctx)
	if err != nil {
		return inst, err
	}
	f, err := parent.Self().Layer(ctx, parentDigest, args.ForcedCompression.Value, args.MediaTypes, args.ID)
	if err != nil {
		return inst, err
	}
	return dagql.NewObjectResultForCurrentCall(ctx, srv, f)
}

type containerWithServiceBindingArgs struct {
	Alias   string
	Service core.ServiceID
}

func (s *containerSchema) withServiceBinding(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithServiceBindingArgs) (*core.Container, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	svc, err := args.Service.Load(ctx, srv)
	if err != nil {
		return nil, err
	}

	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.WithServiceBinding(ctx, svc, args.Alias)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithServiceBindingLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Service:   svc,
		Alias:     args.Alias,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithExposedPortArgs struct {
	Port                        int
	Protocol                    core.NetworkProtocol `default:"TCP"`
	Description                 *string
	ExperimentalSkipHealthcheck bool `default:"false"`
}

func (s *containerSchema) withExposedPort(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithExposedPortArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	port := core.Port{
		Protocol:                    args.Protocol,
		Port:                        args.Port,
		Description:                 args.Description,
		ExperimentalSkipHealthcheck: args.ExperimentalSkipHealthcheck,
	}
	ctr, err = ctr.WithExposedPort(port)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithExposedPortLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Port:      port,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithoutExposedPortArgs struct {
	Port     int
	Protocol core.NetworkProtocol `default:"TCP"`
}

func (s *containerSchema) withoutExposedPort(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithoutExposedPortArgs) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr, err = ctr.WithoutExposedPort(args.Port, args.Protocol)
	if err != nil {
		return nil, err
	}
	ctr.Lazy = &core.ContainerWithoutExposedPortLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Port:      args.Port,
		Protocol:  args.Protocol,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

func (s *containerSchema) exposedPorts(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct{}) (dagql.Array[core.Port], error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.EvaluateParts(ctx, parent, core.ContainerPartMetadata); err != nil {
		return nil, err
	}

	// get descriptions from `Container.Ports` (not in the OCI spec)
	ports := make(map[string]core.Port, len(parent.Self().Ports))
	for _, p := range parent.Self().Ports {
		ociPort := fmt.Sprintf("%d/%s", p.Port, p.Protocol.Network())
		ports[ociPort] = p
	}

	exposedPorts := []core.Port{}
	for ociPort := range parent.Self().Config.ExposedPorts {
		p, exists := ports[ociPort]
		if !exists {
			var err error
			p, err = core.NewPortFromOCI(ociPort)
			if err != nil {
				// ignore errors when parsing from OCI
				continue
			}
		}
		exposedPorts = append(exposedPorts, p)
	}

	return exposedPorts, nil
}

func (s *containerSchema) withFocus(ctx context.Context, parent *core.Container, args struct{}) (*core.Container, error) {
	return parent, nil
}

func (s *containerSchema) withoutFocus(ctx context.Context, parent *core.Container, args struct{}) (*core.Container, error) {
	return parent, nil
}

type containerWithDefaultTerminalCmdArgs struct {
	Args                          []string
	ExperimentalPrivilegedNesting dagql.Optional[dagql.Boolean] `default:"false"`
	InsecureRootCapabilities      dagql.Optional[dagql.Boolean] `default:"false"`
	DisableDaggerInDagger         bool                          `default:"false"`
}

func (s *containerSchema) withDefaultTerminalCmd(
	ctx context.Context,
	parent dagql.ObjectResult[*core.Container],
	args containerWithDefaultTerminalCmdArgs,
) (*core.Container, error) {
	if core.Supports(ctx, defaultNestingVersion) {
		args.ExperimentalPrivilegedNesting = dagql.Opt(dagql.Boolean(!args.DisableDaggerInDagger))
	}
	return withContainerShell(ctx, parent, core.DefaultTerminalCmdOpts{
		Args:                          args.Args,
		DisableDaggerInDagger:         args.DisableDaggerInDagger,
		ExperimentalPrivilegedNesting: args.ExperimentalPrivilegedNesting,
		InsecureRootCapabilities:      args.InsecureRootCapabilities,
	})
}

func withContainerShell(ctx context.Context, parent dagql.ObjectResult[*core.Container], opts core.DefaultTerminalCmdOpts) (*core.Container, error) {
	ctr, parentPendingLazy, err := cloneContainerForSchemaChild(ctx, parent)
	if err != nil {
		return nil, err
	}
	ctr.DefaultTerminalCmd = opts
	ctr.Lazy = &core.ContainerWithDefaultTerminalCmdLazy{
		LazyState: core.NewLazyState(),
		Parent:    parent,
		Opts:      opts,
	}
	if err := evaluateOverBuiltParent(ctx, ctr, parentPendingLazy); err != nil {
		return nil, err
	}
	return ctr, nil
}

type containerWithShellArgs struct {
	Interactive                   []string
	Batch                         dagql.Optional[dagql.ArrayInput[dagql.String]]
	ExperimentalPrivilegedNesting dagql.Optional[dagql.Boolean] `default:"false"`
	InsecureRootCapabilities      dagql.Optional[dagql.Boolean] `default:"false"`
	DisableDaggerInDagger         bool                          `default:"false"`
}

func (s *containerSchema) withShell(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithShellArgs) (*core.Container, error) {
	if len(args.Interactive) == 0 {
		return nil, fmt.Errorf("interactive shell arguments must not be empty")
	}
	if core.Supports(ctx, defaultNestingVersion) {
		args.ExperimentalPrivilegedNesting = dagql.Opt(dagql.Boolean(!args.DisableDaggerInDagger))
	}
	opts := core.DefaultTerminalCmdOpts{
		Args:                          args.Interactive,
		DisableDaggerInDagger:         args.DisableDaggerInDagger,
		ExperimentalPrivilegedNesting: args.ExperimentalPrivilegedNesting,
		InsecureRootCapabilities:      args.InsecureRootCapabilities,
	}
	if args.Batch.Valid {
		if len(args.Batch.Value) == 0 {
			return nil, fmt.Errorf("batch shell arguments must not be empty")
		}
		opts.Batch = make([]string, len(args.Batch.Value))
		for i, arg := range args.Batch.Value {
			opts.Batch[i] = string(arg)
		}
	}
	return withContainerShell(ctx, parent, opts)
}

func (s *containerSchema) shell(ctx context.Context, parent dagql.ObjectResult[*core.Container], args struct {
	Batch bool `default:"false"`
}) (core.Command, error) {
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return core.Command{}, err
	}
	return parent.Self().Shell(args.Batch, core.Supports(ctx, defaultNestingVersion)), nil
}

type containerWithRunArgs struct {
	Command                       string
	Shell                         dagql.Optional[dagql.ArrayInput[dagql.String]]
	ExperimentalPrivilegedNesting dagql.Optional[dagql.Boolean]
	InsecureRootCapabilities      dagql.Optional[dagql.Boolean]
	DisableDaggerInDagger         dagql.Optional[dagql.Boolean]
}

func (s *containerSchema) withRun(ctx context.Context, parent dagql.ObjectResult[*core.Container], args containerWithRunArgs) (res dagql.ObjectResult[*core.Container], _ error) {
	if args.Shell.Valid && len(args.Shell.Value) == 0 {
		return res, fmt.Errorf("shell arguments must not be empty")
	}
	if err := evaluateContainerMetadata(ctx, parent); err != nil {
		return res, err
	}
	defaultNesting := core.Supports(ctx, defaultNestingVersion)
	shell := parent.Self().Shell(true, defaultNesting)
	if args.Shell.Valid {
		shell.Args = make([]string, len(args.Shell.Value))
		for i, arg := range args.Shell.Value {
			shell.Args[i] = string(arg)
		}
	}
	if defaultNesting {
		if args.DisableDaggerInDagger.Valid {
			shell.PrivilegedNesting = !args.DisableDaggerInDagger.Value.Bool()
		}
	} else if args.ExperimentalPrivilegedNesting.Valid {
		shell.PrivilegedNesting = args.ExperimentalPrivilegedNesting.Value.Bool()
	}
	if args.InsecureRootCapabilities.Valid {
		shell.InsecureRootCapabilities = bool(args.InsecureRootCapabilities.Value)
	}
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return res, err
	}
	execArgs := []dagql.NamedInput{
		{Name: "args", Value: dagql.ArrayInput[dagql.String](dagql.NewStringArray(append(shell.Args, args.Command)...))},
		{Name: "insecureRootCapabilities", Value: dagql.Boolean(shell.InsecureRootCapabilities)},
	}
	if defaultNesting {
		execArgs = append(execArgs, dagql.NamedInput{Name: "disableDaggerInDagger", Value: dagql.Boolean(!shell.PrivilegedNesting)})
	} else {
		execArgs = append(execArgs, dagql.NamedInput{Name: "experimentalPrivilegedNesting", Value: dagql.Boolean(shell.PrivilegedNesting)})
	}
	return res, srv.Canonical().Select(ctx, parent, &res, dagql.Selector{
		Field: "withExec",
		View:  dagql.CurrentCall(ctx).View,
		Args:  execArgs,
	})
}

type containerTerminalArgs struct {
	core.TerminalArgs
}

func (s *containerSchema) terminal(
	ctx context.Context,
	ctr dagql.ObjectResult[*core.Container],
	args containerTerminalArgs,
) (res dagql.ObjectResult[*core.Container], _ error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return res, err
	}
	if err := cache.Evaluate(ctx, ctr); err != nil {
		return res, err
	}

	args.TerminalArgs = ctr.Self().WithTerminalDefaults(args.TerminalArgs)

	if core.Supports(ctx, defaultNestingVersion) {
		defaults := ctr.Self().DefaultTerminalCmd.ExperimentalPrivilegedNesting.GetOr(dagql.Boolean(true))
		args.ExperimentalPrivilegedNesting = dagql.Opt(dagql.Boolean(defaults.Bool() && !args.DisableDaggerInDagger))
	}

	ctrDig, err := ctr.ContentPreferredDigest(ctx)
	if err != nil {
		return res, err
	}
	ctrID, err := ctr.ID()
	if err != nil {
		return res, err
	}
	err = ctr.Self().Terminal(ctx, ctrID, ctrDig, ctr, &args.TerminalArgs)
	if err != nil {
		return res, err
	}

	return ctr, nil
}

func (s *containerSchema) terminalLegacy(
	ctx context.Context,
	ctr dagql.ObjectResult[*core.Container],
	args containerTerminalArgs,
) (*core.TerminalLegacy, error) {
	srv, err := core.CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	// HACK: when attempting to construct a legacy terminal, just spin up a new
	// terminal attachable. The returned terminal is definitely invalid, but,
	// the intention was probably to debug it anyways, so we're probably okay.
	var inputs []dagql.NamedInput
	if args.Cmd != nil {
		inputs = append(inputs, dagql.NamedInput{
			Name:  "cmd",
			Value: dagql.ArrayInput[dagql.String](dagql.NewStringArray(args.Cmd...)),
		})
	}
	if args.ExperimentalPrivilegedNesting.Valid {
		inputs = append(inputs, dagql.NamedInput{
			Name:  "experimentalPrivilegedNesting",
			Value: args.ExperimentalPrivilegedNesting,
		})
	}
	if args.InsecureRootCapabilities.Valid {
		inputs = append(inputs, dagql.NamedInput{
			Name:  "insecureRootCapabilities",
			Value: args.InsecureRootCapabilities,
		})
	}

	err = srv.Select(ctx, ctr, new(dagql.Result[*core.Container]),
		dagql.Selector{
			Field: "terminal",
			View:  "v0.12.0",
			Args:  inputs,
		},
	)
	if err != nil {
		return nil, err
	}

	return &core.TerminalLegacy{}, nil
}

func (s *containerSchema) terminalLegacyWebsocketEndpoint(ctx context.Context, parent *core.TerminalLegacy, args struct{}) (string, error) {
	return "", nil
}
