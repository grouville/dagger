package core

import (
	"bytes"
	"encoding/json"
	"fmt"

	"github.com/iancoleman/strcase"
	"github.com/vektah/gqlparser/v2/ast"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
)

type JSON json.RawMessage

func init() {
	strcase.ConfigureAcronym("JSON", "JSON")
}

func (p JSON) String() string {
	return string(p)
}

func (p JSON) Bytes() []byte {
	return p
}

var _ dagql.Typed = JSON{}

var _ dagql.CachePayloadSizer = JSON{}

func (p JSON) CachePayloadBytes() int64 {
	return int64(len(p))
}

func (p JSON) TypeName() string {
	return "JSON"
}

func (p JSON) TypeDescription() string {
	return "An arbitrary JSON-encoded value."
}

func (p JSON) Type() *ast.Type {
	return &ast.Type{
		NamedType: p.TypeName(),
		NonNull:   true,
	}
}

var _ dagql.Input = JSON("")

func (p JSON) Decoder() dagql.InputDecoder {
	return p
}

func (p JSON) ToLiteral() call.Literal {
	return call.NewLiteralString(string(p))
}

func (p JSON) MarshalJSON() ([]byte, error) {
	if p == nil {
		return []byte("null"), nil
	}
	// The SDKs expect a string, not direct JSON, so marshal to that
	return json.Marshal(string(p))
}

func (p *JSON) UnmarshalJSON(bs []byte) error {
	if p == nil {
		return fmt.Errorf("cannot unmarshal into nil JSON")
	}
	if bytes.Equal(bs, []byte("null")) {
		*p = nil
		return nil
	}
	// mirroring MarshalJSON, unmarshal to a *string*
	var s string
	if err := json.Unmarshal(bs, &s); err != nil {
		return err
	}
	*p = JSON(s)
	return nil
}

var _ dagql.ScalarType = JSON{}

func (JSON) DecodeInput(val any) (res dagql.Input, err error) {
	switch x := val.(type) {
	case string:
		if x == "" {
			return nil, nil
		}
		return JSON(x), nil
	case []byte:
		return JSON(x), nil
	case json.RawMessage:
		return JSON(x), nil
	default:
		return nil, fmt.Errorf("cannot convert %T to JSON", val)
	}
}

// Validate checks if the JSON is valid
func (p JSON) Validate() error {
	if !json.Valid([]byte(p)) {
		return fmt.Errorf("invalid JSON")
	}
	return nil
}
