package core

import (
	"context"
	"encoding/json"
	stderrors "errors"
	"fmt"
	"io"
	"io/fs"
	"maps"
	"net"
	"os"
	"path"
	"path/filepath"
	"slices"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"

	"github.com/containerd/containerd/v2/core/content"
	"github.com/containerd/containerd/v2/core/images"
	"github.com/containerd/containerd/v2/core/mount"
	containerdfs "github.com/containerd/continuity/fs"
	"github.com/containerd/platforms"
	"github.com/dagger/dagger/engine"
	serverresolver "github.com/dagger/dagger/engine/server/resolver"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	bkclient "github.com/dagger/dagger/internal/buildkit/client"
	"github.com/dagger/dagger/internal/buildkit/client/llb"
	"github.com/dagger/dagger/internal/buildkit/frontend/dockerfile/dockerfile2llb"
	dockerfileparser "github.com/dagger/dagger/internal/buildkit/frontend/dockerfile/parser"
	"github.com/dagger/dagger/internal/buildkit/frontend/dockerui"
	"github.com/dagger/dagger/util/containerutil"
	"github.com/dagger/dagger/util/hashutil"
	"github.com/dagger/dagger/util/llbtodagger"
	telemetry "github.com/dagger/otel-go"
	"github.com/distribution/reference"
	dockerspec "github.com/moby/docker-image-spec/specs-go/v1"
	digest "github.com/opencontainers/go-digest"
	specs "github.com/opencontainers/image-spec/specs-go/v1"
	"github.com/pkg/errors"
	"github.com/vektah/gqlparser/v2/ast"
	"golang.org/x/sync/errgroup"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	"github.com/dagger/dagger/engine/engineutil"
)

var ErrMountNotExist = errors.New("mount does not exist")

type DefaultTerminalCmdOpts struct {
	Args  []string
	Batch []string `json:",omitempty"`

	// Provide dagger access to the executed command
	ExperimentalPrivilegedNesting dagql.Optional[dagql.Boolean] `default:"false"`

	// Disable access to the Dagger API from terminal commands.
	DisableDaggerInDagger bool `default:"false"`

	// Grant the process all root capabilities
	InsecureRootCapabilities dagql.Optional[dagql.Boolean] `default:"false"`
}

// Container is a content-addressed container.
type Container struct {
	partHost       atomic.Pointer[dagql.PartHost]
	acquiredOutput atomic.Pointer[containerAcquiredOutput]
	acquiredOpens  sync.Map
	// fromContentDigestSafe tracks whether Container.From can give its result a
	// content digest based only on the resolved image and platform. It is false
	// by default so derived containers conservatively retain their call identity.
	// Only a newly constructed scratch container starts out safe; operations that
	// do not change container state can preserve it by returning the same value.
	fromContentDigestSafe bool

	// Allocated only when the internal container-part diagnostic is enabled.
	partDiagnostics *containerPartDiagnostics

	// The container's root filesystem.
	FS *LazyAccessor[*Directory, *Container]

	// Image configuration (env, workdir, etc)
	Config dockerspec.DockerOCIImageConfig

	// List of GPU devices that will be exposed to the container
	EnabledGPUs []string

	// Mount points configured for the container.
	Mounts ContainerMounts

	// MetaSnapshot is the internal exec metadata snapshot containing stdout,
	// stderr, combined output, and exit code files. It will be nil if nothing
	// has run yet.
	MetaSnapshot *LazyAccessor[bkcache.ImmutableRef, *Container]

	// The platform of the container's rootfs.
	Platform Platform

	// OCI annotations
	Annotations []containerutil.ContainerAnnotation

	// Secrets to expose to the container.
	Secrets []ContainerSecret

	// Volatile env vars exposed to future execs but not persisted in image config.
	VolatileEnv []string

	// Sockets to expose to the container.
	Sockets []ContainerSocket

	// Image reference
	ImageRef string

	// Ports to expose from the container.
	Ports []Port

	// Services to start before running the container.
	Services ServiceBindings

	// The args to invoke when using the terminal api on this container.
	DefaultTerminalCmd DefaultTerminalCmdOpts

	// (Internal-only for now) Environment variables from the engine container, prefixed
	// with a special value, that will be inherited by this container if set.
	SystemEnvNames []string

	// DefaultArgs have been explicitly set by the user
	DefaultArgs bool

	Lazy Lazy[*Container]

	// storedParts records completed values decoded from persistence. It is
	// immutable after construction, survives operation evaluation, and is not copied
	// into schema children. Accessors hold only values opened in this process.
	storedParts map[dagql.PartKey]containerStoredPart

	// Retained operation bytes let restored values open snapshots without
	// decoding the operation's inputs.
	lazyJSON json.RawMessage

	// lazyOpMu protects routing reads of the operation independently of its
	// body latch. It is held only for pointer access, never across a body.
	lazyOpMu sync.Mutex
}

type ContainerWithEntrypointLazy struct {
	LazyState
	Parent          dagql.ObjectResult[*Container]
	Args            []string
	KeepDefaultArgs bool
}

type ContainerWithoutEntrypointLazy struct {
	LazyState
	Parent          dagql.ObjectResult[*Container]
	KeepDefaultArgs bool
}

type ContainerWithDefaultArgsLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Args   []string
}

type ContainerWithoutDefaultArgsLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
}

type ContainerWithUserLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
}

type ContainerWithoutUserLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
}

type ContainerWithWorkdirLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Path   string
	Expand bool
}

type ContainerWithoutWorkdirLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
}

type ContainerWithEnvVariableLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
	Value  string
	Expand bool
}

type ContainerWithEnvFileVariablesLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Source dagql.ObjectResult[*EnvFile]
}

type ContainerWithSystemEnvVariableLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
}

type ContainerWithVolatileVariableLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
	Value  string
}

type ContainerWithoutEnvVariableLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
}

type ContainerWithoutVolatileVariableLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
}

type ContainerWithLabelLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
	Value  string
}

type ContainerWithoutLabelLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
}

type ContainerWithImageConfigMetadataLazy struct {
	LazyState
	Parent      dagql.ObjectResult[*Container]
	Healthcheck *dockerspec.HealthcheckConfig
	OnBuild     []string
	Shell       []string
	Volumes     []string
	StopSignal  string
}

type ContainerWithHealthcheckLazy struct {
	LazyState
	Parent      dagql.ObjectResult[*Container]
	Healthcheck dockerspec.HealthcheckConfig
}

type ContainerWithoutHealthcheckLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
}

type ContainerSetGPUsLazy struct {
	LazyState
	Parent  dagql.ObjectResult[*Container]
	Devices []string
}

type ContainerWithAnnotationLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
	Value  string
}

type ContainerWithoutAnnotationLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
}

type ContainerWithSecretVariableLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
	Secret dagql.ObjectResult[*Secret]
}

type ContainerWithoutSecretVariableLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Name   string
}

type ContainerWithServiceBindingLazy struct {
	LazyState
	Parent  dagql.ObjectResult[*Container]
	Service dagql.ObjectResult[*Service]
	Alias   string
}

type ContainerWithExposedPortLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Port   Port
}

type ContainerWithoutExposedPortLazy struct {
	LazyState
	Parent   dagql.ObjectResult[*Container]
	Port     int
	Protocol NetworkProtocol
}

type ContainerWithDefaultTerminalCmdLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Opts   DefaultTerminalCmdOpts
}

type ContainerRootFSLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
}

type ContainerWithRootFSLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Source dagql.ObjectResult[*Directory]
}

type ContainerDirectoryLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Path   string
}

type ContainerFileLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Path   string
}

type ContainerWithDirectoryLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Path   string
	Source dagql.ObjectResult[*Directory]
	Filter CopyFilter
	Owner  string
}

type ContainerWithFileLazy struct {
	LazyState
	Parent      dagql.ObjectResult[*Container]
	Path        string
	Source      dagql.ObjectResult[*File]
	Permissions *int
	Owner       string
}

type ContainerWithMountedDirectoryLazy struct {
	LazyState
	Parent   dagql.ObjectResult[*Container]
	Target   string
	Source   dagql.ObjectResult[*Directory]
	Owner    string
	Readonly bool
}

type ContainerWithMountedFileLazy struct {
	LazyState
	Parent   dagql.ObjectResult[*Container]
	Target   string
	Source   dagql.ObjectResult[*File]
	Owner    string
	Readonly bool
}

type ContainerWithMountedPathDockerfileCompatLazy struct {
	LazyState
	Parent     dagql.ObjectResult[*Container]
	Target     string
	Source     dagql.ObjectResult[*Directory]
	SourcePath string
	Readonly   bool
}

type ContainerWithMountedCacheLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Target string
	Cache  dagql.ObjectResult[*CacheVolume]
}

type ContainerWithMountedVolumeLazy struct {
	LazyState
	Parent   dagql.ObjectResult[*Container]
	Target   string
	Volume   dagql.ObjectResult[*Volume]
	Readonly bool
}

type ContainerWithMountedTempLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Target string
	Size   int
}

// ContainerWithMountedSecretLazy resolves named ownership in its metadata
// group, which reads /etc/passwd from the parent's rootfs.
type ContainerWithMountedSecretLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Target string
	Source dagql.ObjectResult[*Secret]
	Owner  string
	Mode   fs.FileMode
}

type ContainerWithoutMountLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Target string
}

type ContainerWithoutPathLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Path   string
}

type ContainerWithSymlinkLazy struct {
	LazyState
	Parent   dagql.ObjectResult[*Container]
	Target   string
	LinkPath string
}

// ContainerWithUnixSocketLazy resolves named ownership in its metadata
// group, which reads /etc/passwd from the parent's rootfs.
type ContainerWithUnixSocketLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Target string
	Source dagql.ObjectResult[*Socket]
	Owner  string
}

type ContainerWithoutUnixSocketLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Target string
}

type ContainerImportLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Container]
	Source dagql.ObjectResult[*File]
	Tag    string
}

// ContainerMount is a mount point configured in a container.
type ContainerMount struct {
	// The path of the mount within the container.
	Target string

	// Configure the mount as read-only.
	Readonly bool

	// The following fields are mutually exclusive, only one of them should be set.

	// The mounted directory.
	DirectorySource *LazyAccessor[*Directory, *Container]
	// The mounted file.
	FileSource *LazyAccessor[*File, *Container]
	// The mounted cache.
	CacheSource *CacheMountSource
	// The mounted volume.
	VolumeSource *VolumeMountSource
	// The mounted tmpfs.
	TmpfsSource *TmpfsMountSource
}

type CacheMountSource struct {
	// The cache volume backing this mount.
	Volume dagql.ObjectResult[*CacheVolume]
}

type VolumeMountSource struct {
	// The volume backing this mount.
	Volume dagql.ObjectResult[*Volume]
}

type TmpfsMountSource struct {
	// Configure the size of the mounted tmpfs in bytes.
	Size int
}

type ContainerMounts []ContainerMount

type persistedContainerMountPayload struct {
	Target               string `json:"target"`
	Readonly             bool   `json:"readonly,omitempty"`
	Kind                 string `json:"kind"`
	CacheSourceResultID  uint64 `json:"cacheSourceResultID,omitempty"`
	VolumeSourceResultID uint64 `json:"volumeSourceResultID,omitempty"`
	TmpfsSize            int    `json:"tmpfsSize,omitempty"`
}

type persistedContainerSecretPayload struct {
	SecretResultID uint64      `json:"secretResultID"`
	EnvName        string      `json:"envName,omitempty"`
	MountPath      string      `json:"mountPath,omitempty"`
	Owner          *Ownership  `json:"owner,omitempty"`
	Mode           fs.FileMode `json:"mode,omitempty"`
}

type persistedContainerSocketPayload struct {
	SourceResultID uint64     `json:"sourceResultID"`
	ContainerPath  string     `json:"containerPath"`
	Owner          *Ownership `json:"owner,omitempty"`
}

const (
	persistedContainerMountKindDirectory = "directory"
	persistedContainerMountKindFile      = "file"
	persistedContainerMountKindCache     = "cache"
	persistedContainerMountKindVolume    = "volume"
	persistedContainerMountKindTmpfs     = "tmpfs"
)

type persistedContainerPayload struct {
	OperationState string                                   `json:"operationState,omitempty"`
	Metadata       persistedContainerMetadata               `json:"metadata"`
	Parts          map[dagql.PartKey]persistedContainerPart `json:"parts"`
	LazyJSON       json.RawMessage                          `json:"lazyJSON,omitempty"`
}

type persistedContainerMetadata struct {
	Consumed bool                            `json:"consumed"`
	Value    persistedContainerMetadataValue `json:"value"`
}

type persistedContainerMetadataValue struct {
	Config             dockerspec.DockerOCIImageConfig     `json:"config"`
	EnabledGPUs        []string                            `json:"enabledGPUs,omitempty"`
	Mounts             []persistedContainerMountPayload    `json:"mounts,omitempty"`
	Secrets            []persistedContainerSecretPayload   `json:"secrets,omitempty"`
	Sockets            []persistedContainerSocketPayload   `json:"sockets,omitempty"`
	Platform           Platform                            `json:"platform"`
	Annotations        []containerutil.ContainerAnnotation `json:"annotations,omitempty"`
	ImageRef           string                              `json:"imageRef,omitempty"`
	Ports              []Port                              `json:"ports,omitempty"`
	Services           []persistedServiceBinding           `json:"services,omitempty"`
	DefaultTerminalCmd DefaultTerminalCmdOpts              `json:"defaultTerminalCmd"`
	SystemEnvNames     []string                            `json:"systemEnvNames,omitempty"`
	VolatileEnv        []string                            `json:"volatileEnv,omitempty"`
	DefaultArgs        bool                                `json:"defaultArgs,omitempty"`
}

type persistedContainerWithEntrypointLazy struct {
	ParentResultID  uint64   `json:"parentResultID"`
	Args            []string `json:"args,omitempty"`
	KeepDefaultArgs bool     `json:"keepDefaultArgs,omitempty"`
}

type persistedContainerWithoutEntrypointLazy struct {
	ParentResultID  uint64 `json:"parentResultID"`
	KeepDefaultArgs bool   `json:"keepDefaultArgs,omitempty"`
}

type persistedContainerWithDefaultArgsLazy struct {
	ParentResultID uint64   `json:"parentResultID"`
	Args           []string `json:"args,omitempty"`
}

type persistedContainerWithoutDefaultArgsLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
}

type persistedContainerWithUserLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
}

type persistedContainerWithoutUserLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
}

type persistedContainerWithWorkdirLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Path           string `json:"path"`
	Expand         bool   `json:"expand,omitempty"`
}

type persistedContainerWithoutWorkdirLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
}

type persistedContainerWithEnvVariableLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
	Value          string `json:"value"`
	Expand         bool   `json:"expand,omitempty"`
}

type persistedContainerWithEnvFileVariablesLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	SourceResultID uint64 `json:"sourceResultID"`
}

type persistedContainerWithSystemEnvVariableLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
}

type persistedContainerWithVolatileVariableLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
	Value          string `json:"value"`
}

type persistedContainerWithoutEnvVariableLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
}

type persistedContainerWithoutVolatileVariableLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
}

type persistedContainerWithLabelLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
	Value          string `json:"value"`
}

type persistedContainerWithoutLabelLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
}

type persistedContainerWithImageConfigMetadataLazy struct {
	ParentResultID uint64                        `json:"parentResultID"`
	Healthcheck    *dockerspec.HealthcheckConfig `json:"healthcheck,omitempty"`
	OnBuild        []string                      `json:"onBuild,omitempty"`
	Shell          []string                      `json:"shell,omitempty"`
	Volumes        []string                      `json:"volumes,omitempty"`
	StopSignal     string                        `json:"stopSignal,omitempty"`
}

type persistedContainerWithHealthcheckLazy struct {
	ParentResultID uint64                       `json:"parentResultID"`
	Healthcheck    dockerspec.HealthcheckConfig `json:"healthcheck"`
}

type persistedContainerWithoutHealthcheckLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
}

type persistedContainerSetGPUsLazy struct {
	ParentResultID uint64   `json:"parentResultID"`
	Devices        []string `json:"devices,omitempty"`
}

type persistedContainerWithAnnotationLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
	Value          string `json:"value"`
}

type persistedContainerWithoutAnnotationLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
}

type persistedContainerWithSecretVariableLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
	SecretResultID uint64 `json:"secretResultID"`
}

type persistedContainerWithoutSecretVariableLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Name           string `json:"name"`
}

type persistedContainerWithServiceBindingLazy struct {
	ParentResultID  uint64 `json:"parentResultID"`
	ServiceResultID uint64 `json:"serviceResultID"`
	Alias           string `json:"alias,omitempty"`
}

type persistedContainerWithExposedPortLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Port           Port   `json:"port"`
}

type persistedContainerWithoutExposedPortLazy struct {
	ParentResultID uint64          `json:"parentResultID"`
	Port           int             `json:"port"`
	Protocol       NetworkProtocol `json:"protocol"`
}

type persistedContainerWithDefaultTerminalCmdLazy struct {
	ParentResultID uint64                 `json:"parentResultID"`
	Opts           DefaultTerminalCmdOpts `json:"opts"`
}

type persistedContainerFromLazy struct {
	ParentResultID    uint64                           `json:"parentResultID"`
	CanonicalRef      string                           `json:"canonicalRef"`
	Config            dockerspec.DockerOCIImageConfig  `json:"config"`
	ImageRef          string                           `json:"imageRef,omitempty"`
	Platform          Platform                         `json:"platform"`
	RegistryServices  []persistedServiceBinding        `json:"registryServices,omitempty"`
	RegistryTransport serverresolver.RegistryTransport `json:"registryTransport,omitempty"`
}

type persistedContainerWithRootFSLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	SourceResultID uint64 `json:"sourceResultID"`
}

type persistedContainerRootFSLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
}

type persistedContainerWithDirectoryLazy struct {
	ParentResultID uint64     `json:"parentResultID"`
	Path           string     `json:"path"`
	SourceResultID uint64     `json:"sourceResultID"`
	Filter         CopyFilter `json:"filter,omitempty"`
	Owner          string     `json:"owner,omitempty"`
}

type persistedContainerDirectoryLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Path           string `json:"path"`
}

type persistedContainerWithFileLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Path           string `json:"path"`
	SourceResultID uint64 `json:"sourceResultID"`
	Permissions    *int   `json:"permissions,omitempty"`
	Owner          string `json:"owner,omitempty"`
}

type persistedContainerFileLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Path           string `json:"path"`
}

type persistedContainerWithMountedDirectoryLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	SourceResultID uint64 `json:"sourceResultID"`
	Owner          string `json:"owner,omitempty"`
	Readonly       bool   `json:"readonly,omitempty"`
}

type persistedContainerWithMountedFileLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	SourceResultID uint64 `json:"sourceResultID"`
	Owner          string `json:"owner,omitempty"`
	Readonly       bool   `json:"readonly,omitempty"`
}

type persistedContainerWithMountedPathDockerfileCompatLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	SourceResultID uint64 `json:"sourceResultID"`
	SourcePath     string `json:"sourcePath,omitempty"`
	Readonly       bool   `json:"readonly,omitempty"`
}

type persistedContainerWithMountedCacheLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	CacheResultID  uint64 `json:"cacheResultID"`
}

type persistedContainerWithMountedVolumeLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	VolumeResultID uint64 `json:"volumeResultID"`
	Readonly       bool   `json:"readonly,omitempty"`
}

type persistedContainerWithMountedTempLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	Size           int    `json:"size,omitempty"`
}

type persistedContainerWithMountedSecretLazy struct {
	ParentResultID uint64      `json:"parentResultID"`
	Target         string      `json:"target"`
	SourceResultID uint64      `json:"sourceResultID"`
	Owner          string      `json:"owner,omitempty"`
	Mode           fs.FileMode `json:"mode,omitempty"`
}

type persistedContainerWithoutMountLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
}

type persistedContainerWithoutPathLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Path           string `json:"path"`
}

type persistedContainerWithSymlinkLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	LinkPath       string `json:"linkPath"`
}

type persistedContainerWithUnixSocketLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
	SourceResultID uint64 `json:"sourceResultID"`
	Owner          string `json:"owner,omitempty"`
}

type persistedContainerWithoutUnixSocketLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	Target         string `json:"target"`
}

type persistedContainerImportLazy struct {
	ParentResultID uint64 `json:"parentResultID"`
	SourceResultID uint64 `json:"sourceResultID"`
	Tag            string `json:"tag,omitempty"`
}

func (*Container) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Container",
		NonNull:   true,
	}
}

func (*Container) TypeDescription() string {
	return "An OCI-compatible container, also known as a Docker container."
}

func NewContainer(platform Platform) *Container {
	return &Container{
		fromContentDigestSafe: true,
		FS:                    new(LazyAccessor[*Directory, *Container]),
		MetaSnapshot:          new(LazyAccessor[bkcache.ImmutableRef, *Container]),
		Platform:              platform,
	}
}

// CanUseFromContentDigest reports whether Container.From can safely identify
// its result using only the resolved image digest and platform.
func (container *Container) CanUseFromContentDigest() bool {
	return container != nil && container.fromContentDigestSafe
}

//nolint:dupl // symmetric with cloneDetachedFileForContainerResult; sharing obscures type specifics
func cloneDetachedDirectoryForContainerResult(ctx context.Context, src *Directory) (*Directory, error) {
	if src == nil {
		return nil, nil
	}
	// Pending computation, not the operation's evaluated flag: a value whose
	// part was acquired has a stored descriptor and an opened snapshot, and
	// its restore operation never runs.
	if src.HasPendingLazyComputation() {
		return nil, fmt.Errorf("clone detached directory for container result: directory must be materialized, got lazy %T", src.Lazy)
	}

	if src.Dir == nil || src.Snapshot == nil {
		return nil, fmt.Errorf("clone detached directory: missing accessors")
	}
	selectedPath, pathSet := src.Dir.Peek()
	snapshot, snapshotSet := src.Snapshot.Peek()
	if !pathSet || !snapshotSet {
		return nil, fmt.Errorf("clone detached directory: output is not installed")
	}

	cp := &Directory{
		Platform: src.Platform,
		Services: slices.Clone(src.Services),
		Dir:      new(LazyAccessor[string, *Directory]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
	}
	cp.SetPath(selectedPath)
	if snapshot == nil {
		cp.SetSnapshot(nil)
		return cp, nil
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, snapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
	if err != nil {
		return nil, err
	}
	cp.SetSnapshot(reopened)
	return cp, nil
}

//nolint:dupl // symmetric with cloneDetachedDirectoryForContainerResult; sharing obscures type specifics
func cloneDetachedFileForContainerResult(ctx context.Context, src *File) (*File, error) {
	if src == nil {
		return nil, nil
	}
	// Pending computation, not the operation's evaluated flag: a value whose
	// part was acquired has a stored descriptor and an opened snapshot, and
	// its restore operation never runs.
	if src.HasPendingLazyComputation() {
		return nil, fmt.Errorf("clone detached file for container result: file must be materialized, got lazy %T", src.Lazy)
	}

	if src.File == nil || src.Snapshot == nil {
		return nil, fmt.Errorf("clone detached file: missing accessors")
	}
	selectedPath, pathSet := src.File.Peek()
	snapshot, snapshotSet := src.Snapshot.Peek()
	if !pathSet || !snapshotSet {
		return nil, fmt.Errorf("clone detached file: output is not installed")
	}

	cp := &File{
		Platform: src.Platform,
		Services: slices.Clone(src.Services),
		File:     new(LazyAccessor[string, *File]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
	}
	cp.SetPath(selectedPath)
	if snapshot == nil {
		cp.SetSnapshot(nil)
		return cp, nil
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, snapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
	if err != nil {
		return nil, err
	}
	cp.SetSnapshot(reopened)
	return cp, nil
}

func CloneContainerMetaSnapshot(ctx context.Context, src *LazyAccessor[bkcache.ImmutableRef, *Container]) (*LazyAccessor[bkcache.ImmutableRef, *Container], error) {
	if src == nil {
		return nil, nil
	}
	cp := new(LazyAccessor[bkcache.ImmutableRef, *Container])
	snapshot, ok := src.Peek()
	if !ok || snapshot == nil {
		return cp, nil
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, snapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
	if err != nil {
		return nil, err
	}
	cp.setValue(reopened)
	return cp, nil
}

func CloneContainerDirectoryAccessor(ctx context.Context, src *LazyAccessor[*Directory, *Container]) (*LazyAccessor[*Directory, *Container], error) {
	if src == nil {
		return nil, nil
	}
	cp := new(LazyAccessor[*Directory, *Container])
	dir, ok := src.Peek()
	if !ok || dir == nil {
		return cp, nil
	}
	detached, err := cloneDetachedDirectoryForContainerResult(ctx, dir)
	if err != nil {
		return nil, err
	}
	cp.setValue(detached)
	return cp, nil
}

func CloneContainerFileAccessor(ctx context.Context, src *LazyAccessor[*File, *Container]) (*LazyAccessor[*File, *Container], error) {
	if src == nil {
		return nil, nil
	}
	cp := new(LazyAccessor[*File, *Container])
	file, ok := src.Peek()
	if !ok || file == nil {
		return cp, nil
	}
	detached, err := cloneDetachedFileForContainerResult(ctx, file)
	if err != nil {
		return nil, err
	}
	cp.setValue(detached)
	return cp, nil
}

func CloneContainerMounts(ctx context.Context, mounts ContainerMounts) (ContainerMounts, error) {
	if mounts == nil {
		return nil, nil
	}
	cp := make(ContainerMounts, len(mounts))
	for i, mnt := range mounts {
		cp[i] = mnt
		var err error
		cp[i].DirectorySource, err = CloneContainerDirectoryAccessor(ctx, mnt.DirectorySource)
		if err != nil {
			return nil, err
		}
		cp[i].FileSource, err = CloneContainerFileAccessor(ctx, mnt.FileSource)
		if err != nil {
			return nil, err
		}
	}
	return cp, nil
}

func CloneContainerImageConfig(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
	cp := cfg
	cp.ExposedPorts = maps.Clone(cp.ExposedPorts)
	cp.Env = slices.Clone(cp.Env)
	cp.Entrypoint = slices.Clone(cp.Entrypoint)
	cp.Cmd = slices.Clone(cp.Cmd)
	cp.Volumes = maps.Clone(cp.Volumes)
	cp.Labels = maps.Clone(cp.Labels)
	if cp.Healthcheck != nil {
		cloned := *cp.Healthcheck
		cloned.Test = slices.Clone(cloned.Test)
		cp.Healthcheck = &cloned
	}
	cp.OnBuild = slices.Clone(cp.OnBuild)
	cp.Shell = slices.Clone(cp.Shell)
	return cp
}

func materializeContainerStateFromParent(ctx context.Context, dst *Container, parent dagql.ObjectResult[*Container]) error {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return err
	}
	if err := cache.Evaluate(ctx, parent); err != nil {
		return err
	}

	clonedFS, err := CloneContainerDirectoryAccessor(ctx, parent.Self().FS)
	if err != nil {
		return err
	}
	clonedMounts, err := CloneContainerMounts(ctx, parent.Self().Mounts)
	if err != nil {
		return err
	}
	clonedMeta, err := CloneContainerMetaSnapshot(ctx, parent.Self().MetaSnapshot)
	if err != nil {
		return err
	}

	dst.Config = CloneContainerImageConfig(parent.Self().Config)
	dst.EnabledGPUs = slices.Clone(parent.Self().EnabledGPUs)
	dst.FS = clonedFS
	dst.Mounts = clonedMounts
	dst.MetaSnapshot = clonedMeta
	dst.Platform = parent.Self().Platform
	dst.Annotations = slices.Clone(parent.Self().Annotations)
	dst.Secrets = slices.Clone(parent.Self().Secrets)
	dst.VolatileEnv = slices.Clone(parent.Self().VolatileEnv)
	dst.Sockets = slices.Clone(parent.Self().Sockets)
	dst.ImageRef = parent.Self().ImageRef
	dst.Ports = slices.Clone(parent.Self().Ports)
	dst.Services = slices.Clone(parent.Self().Services)
	dst.DefaultTerminalCmd = parent.Self().DefaultTerminalCmd
	dst.SystemEnvNames = slices.Clone(parent.Self().SystemEnvNames)
	dst.DefaultArgs = parent.Self().DefaultArgs
	return nil
}

var _ dagql.OnReleaser = (*Container)(nil)
var _ dagql.HasDependencyResults = (*Container)(nil)
var _ dagql.HasDependencyResultsKinds = (*Container)(nil)
var _ dagql.HasLazyEvaluation = (*Container)(nil)

func (container *Container) LazyEvalFunc() dagql.LazyEvalFunc {
	if container != nil {
		if view := container.acquiredOutput.Load(); view != nil {
			return func(ctx context.Context) error {
				if host := container.partHost.Load(); host != nil {
					return host.Evaluate(ctx)
				}
				_, err := container.resolveTransferParts(nil)
				return err
			}
		}
		if host := container.partHost.Load(); host != nil && host.Managed() {
			return func(ctx context.Context) error { return host.Evaluate(ctx) }
		}
	}

	if container == nil {
		return nil
	}

	lazy := container.lazyOpForRouting()
	if lazy == nil || lazy.IsEvaluated() {
		return nil
	}
	if op, ok := lazy.(LazyContainerParts); ok {
		if done, err := container.lazyGroupsEvaluated(context.Background(), op); err == nil && done {
			return nil
		}
	}
	// The captured op runs, not a re-read: a concurrent consumption
	// between closure creation and call makes this a no-op through the
	// op's own latch instead of a nil-interface call.
	return func(ctx context.Context) error {
		if host := container.partHost.Load(); host != nil {
			if !host.Admitted(ctx) {
				return host.Evaluate(ctx)
			}
			if _, refined := lazy.(LazyContainerParts); !refined {
				return host.RunNative(ctx, dagql.LazyGroupWhole, append([]dagql.PartKey{ContainerPartMetadata}, containerSnapshotParts(container)...), func(ctx context.Context) error { return lazy.Evaluate(ctx, container) })
			}
		}
		return lazy.Evaluate(ctx, container)
	}
}

func (container *Container) Evaluate(ctx context.Context) error {
	if container == nil {
		return nil
	}
	if host := container.partHost.Load(); host != nil && !host.Admitted(ctx) {
		return host.Evaluate(ctx)
	}
	if lazy := container.LazyEvalFunc(); lazy != nil {
		return lazy(ctx)
	}
	return nil
}

func (container *Container) Sync(ctx context.Context) error {
	return container.Evaluate(ctx)
}

func (container *Container) AttachDependencyResults(
	ctx context.Context,
	self dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.AnyResult, error) {
	depsWithKinds, err := container.AttachDependencyResultsKinds(ctx, self, attach)
	if err != nil {
		return nil, err
	}
	deps := make([]dagql.AnyResult, 0, len(depsWithKinds))
	for _, dep := range depsWithKinds {
		deps = append(deps, dep.Result)
	}
	return deps, nil
}

func (container *Container) AttachDependencyResultsKinds(
	ctx context.Context,
	_ dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.DependencyResult, error) {
	if container == nil {
		return nil, nil
	}

	container.lazyOpMu.Lock()
	lazy := container.Lazy
	container.lazyOpMu.Unlock()
	owned := make([]dagql.DependencyResult, 0, len(container.Mounts)+len(container.Secrets)+len(container.Sockets)+len(container.Services))
	for i := range container.Mounts {
		mnt := &container.Mounts[i]
		if mnt.CacheSource != nil && mnt.CacheSource.Volume.Self() != nil {
			attached, err := attach(mnt.CacheSource.Volume)
			if err != nil {
				return nil, fmt.Errorf("attach container cache mount %q: %w", mnt.Target, err)
			}
			typed, ok := attached.(dagql.ObjectResult[*CacheVolume])
			if !ok {
				return nil, fmt.Errorf("attach container cache mount %q: unexpected result %T", mnt.Target, attached)
			}
			mnt.CacheSource.Volume = typed
			owned = append(owned, dagql.DependencyResult{Result: typed, Owned: true})
		}
		if mnt.VolumeSource != nil && mnt.VolumeSource.Volume.Self() != nil {
			volume, err := attachVolumeResult(attach, mnt.VolumeSource.Volume, fmt.Sprintf("attach container volume mount %q", mnt.Target))
			if err != nil {
				return nil, err
			}
			mnt.VolumeSource.Volume = volume
			owned = append(owned, dagql.DependencyResult{Result: volume, Owned: true})
		}
	}
	for i := range container.Secrets {
		secret := &container.Secrets[i]
		if secret.Secret.Self() == nil {
			continue
		}
		attached, err := attach(secret.Secret)
		if err != nil {
			return nil, fmt.Errorf("attach container secret %q: %w", secret.EnvName, err)
		}
		typed, ok := attached.(dagql.ObjectResult[*Secret])
		if !ok {
			return nil, fmt.Errorf("attach container secret %q: unexpected result %T", secret.EnvName, attached)
		}
		secret.Secret = typed
		owned = append(owned, dagql.DependencyResult{Result: typed, Owned: true})
	}
	for i := range container.Sockets {
		socket := &container.Sockets[i]
		if socket.Source.Self() == nil {
			continue
		}
		attached, err := attach(socket.Source)
		if err != nil {
			return nil, fmt.Errorf("attach container socket %q: %w", socket.ContainerPath, err)
		}
		typed, ok := attached.(dagql.ObjectResult[*Socket])
		if !ok {
			return nil, fmt.Errorf("attach container socket %q: unexpected result %T", socket.ContainerPath, attached)
		}
		socket.Source = typed
		owned = append(owned, dagql.DependencyResult{Result: typed, Owned: true})
	}
	serviceDeps, err := container.Services.AttachDependencyResults("container", attach)
	if err != nil {
		return nil, err
	}
	owned = append(owned, serviceDeps...)

	if lazy != nil {
		deps, err := lazy.AttachDependencies(ctx, attach)
		if err != nil {
			return nil, err
		}
		// Lazy parents are receiver/prerequisite chains, not owned by this
		// call. Track for liveness/preflight, but don't propagate this
		// call's install span — failures attribute to the parent's own
		// install span via direct lookup.
		for _, dep := range deps {
			owned = append(owned, dagql.DependencyResult{Result: dep, Owned: false})
		}
	}

	return owned, nil
}

func (container *Container) PersistedSnapshotRefLinks() []dagql.PersistedSnapshotRefLink {
	if container != nil {
		if view := container.acquiredOutput.Load(); view != nil {
			return dagql.ClonePersistedSnapshotLinks(view.Links)
		}
	}
	if container == nil {
		return nil
	}
	var links []dagql.PersistedSnapshotRefLink
	if container.MetaSnapshot != nil {
		if snapshot, ok := container.MetaSnapshot.Peek(); ok && snapshot != nil {
			links = append(links, dagql.PersistedSnapshotRefLink{
				RefKey: snapshot.SnapshotID(),
				Role:   "meta",
			})
		}
	}
	if container.FS != nil {
		if dir, ok := container.FS.Peek(); ok && dir != nil {
			if snapshot, ok := dir.Snapshot.Peek(); ok && snapshot != nil {
				links = append(links, dagql.PersistedSnapshotRefLink{
					RefKey: snapshot.SnapshotID(),
					Role:   "fs",
				})
			}
		}
	}
	for i, mnt := range container.Mounts {
		if mnt.DirectorySource != nil {
			if dir, ok := mnt.DirectorySource.Peek(); ok && dir != nil {
				if snapshot, ok := dir.Snapshot.Peek(); ok && snapshot != nil {
					links = append(links, dagql.PersistedSnapshotRefLink{
						RefKey: snapshot.SnapshotID(),
						Role:   fmt.Sprintf("mount_dir:%d", i),
					})
				}
			}
		}
		if mnt.FileSource != nil {
			if file, ok := mnt.FileSource.Peek(); ok && file != nil {
				if snapshot, ok := file.Snapshot.Peek(); ok && snapshot != nil {
					links = append(links, dagql.PersistedSnapshotRefLink{
						RefKey: snapshot.SnapshotID(),
						Role:   fmt.Sprintf("mount_file:%d", i),
					})
				}
			}
		}
	}
	for _, stored := range container.storedParts {
		if stored.SnapshotID != "" {
			link := dagql.PersistedSnapshotRefLink{RefKey: stored.SnapshotID, Role: stored.Role}
			if !slices.ContainsFunc(links, func(existing dagql.PersistedSnapshotRefLink) bool {
				return existing.Role == link.Role && existing.RefKey == link.RefKey
			}) {
				links = append(links, link)
			}
		}
	}
	return links
}

func (container *Container) CacheUsageIdentities() []string {
	seen := make(map[string]struct{})
	var identities []string
	for _, link := range container.PersistedSnapshotRefLinks() {
		if link.RefKey == "" {
			continue
		}
		if _, ok := seen[link.RefKey]; !ok {
			seen[link.RefKey] = struct{}{}
			identities = append(identities, link.RefKey)
		}
	}
	slices.Sort(identities)
	return identities
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (container *Container) CacheUsageSize(ctx context.Context, sizeProvider dagql.CacheUsageSizeProvider, identity string) (int64, bool, error) {
	if container != nil {
		if view := container.acquiredOutput.Load(); view != nil {
			for _, link := range view.Links {
				if link.RefKey == identity && sizeProvider != nil {
					size, err := sizeProvider.SnapshotSize(ctx, identity)
					return size, err == nil, err
				}
			}
			return 0, false, nil
		}
	}

	if container == nil || identity == "" {
		return 0, false, nil
	}

	if container.MetaSnapshot != nil {
		if snapshot, ok := container.MetaSnapshot.Peek(); ok && snapshot != nil && snapshot.SnapshotID() == identity {
			size, err := snapshot.Size(ctx)
			if err != nil {
				return 0, false, err
			}
			return size, true, nil
		}
	}

	if container.FS != nil {
		if dir, ok := container.FS.Peek(); ok && dir != nil {
			if snapshot, ok := dir.Snapshot.Peek(); ok && snapshot != nil && snapshot.SnapshotID() == identity {
				size, err := snapshot.Size(ctx)
				if err != nil {
					return 0, false, err
				}
				return size, true, nil
			}
		}
	}

	for _, mnt := range container.Mounts {
		if mnt.DirectorySource != nil {
			if dir, ok := mnt.DirectorySource.Peek(); ok && dir != nil {
				if snapshot, ok := dir.Snapshot.Peek(); ok && snapshot != nil && snapshot.SnapshotID() == identity {
					size, err := snapshot.Size(ctx)
					if err != nil {
						return 0, false, err
					}
					return size, true, nil
				}
			}
		}
		if mnt.FileSource != nil {
			if file, ok := mnt.FileSource.Peek(); ok && file != nil {
				if snapshot, ok := file.Snapshot.Peek(); ok && snapshot != nil && snapshot.SnapshotID() == identity {
					size, err := snapshot.Size(ctx)
					if err != nil {
						return 0, false, err
					}
					return size, true, nil
				}
			}
		}
	}

	owned := false
	for _, ownedIdentity := range container.CacheUsageIdentities() {
		if ownedIdentity == identity {
			owned = true
			break
		}
	}
	if !owned {
		return 0, false, nil
	}

	if sizeProvider == nil {
		return 0, false, nil
	}
	size, err := sizeProvider.SnapshotSize(ctx, identity)
	if err != nil {
		return 0, false, err
	}
	return size, true, nil
}

func (container *Container) encodeContainerMetadata(enc *dagql.PersistEncodeContext) (persistedContainerMetadataValue, error) {
	if container == nil {
		return persistedContainerMetadataValue{}, fmt.Errorf("encode persisted container: nil container")
	}
	services, err := encodePersistedServiceBindings(enc, "container", container.Services)
	if err != nil {
		return persistedContainerMetadataValue{}, err
	}

	payload := persistedContainerMetadataValue{
		Config:             container.Config,
		EnabledGPUs:        slices.Clone(container.EnabledGPUs),
		Mounts:             make([]persistedContainerMountPayload, 0, len(container.Mounts)),
		Secrets:            make([]persistedContainerSecretPayload, 0, len(container.Secrets)),
		Sockets:            make([]persistedContainerSocketPayload, 0, len(container.Sockets)),
		Platform:           container.Platform,
		Annotations:        slices.Clone(container.Annotations),
		ImageRef:           container.ImageRef,
		Ports:              slices.Clone(container.Ports),
		Services:           services,
		DefaultTerminalCmd: container.DefaultTerminalCmd,
		SystemEnvNames:     slices.Clone(container.SystemEnvNames),
		VolatileEnv:        slices.Clone(container.VolatileEnv),
		DefaultArgs:        container.DefaultArgs,
	}

	for _, mnt := range container.Mounts {
		encoded := persistedContainerMountPayload{
			Target:   mnt.Target,
			Readonly: mnt.Readonly,
		}
		switch {
		case mnt.DirectorySource != nil:
			encoded.Kind = persistedContainerMountKindDirectory
		case mnt.FileSource != nil:
			encoded.Kind = persistedContainerMountKindFile
		case mnt.CacheSource != nil:
			encoded.Kind = persistedContainerMountKindCache
			id, err := encodePersistedObjectRef(enc, mnt.CacheSource.Volume, fmt.Sprintf("cache mount %q", mnt.Target))
			if err != nil {
				return persistedContainerMetadataValue{}, err
			}
			encoded.CacheSourceResultID = id
		case mnt.VolumeSource != nil:
			encoded.Kind = persistedContainerMountKindVolume
			id, err := encodePersistedObjectRef(enc, mnt.VolumeSource.Volume, fmt.Sprintf("volume mount %q", mnt.Target))
			if err != nil {
				return persistedContainerMetadataValue{}, err
			}
			encoded.VolumeSourceResultID = id
		case mnt.TmpfsSource != nil:
			encoded.Kind = persistedContainerMountKindTmpfs
			encoded.TmpfsSize = mnt.TmpfsSource.Size
		default:
			return persistedContainerMetadataValue{}, fmt.Errorf("encode persisted container mount %q: unsupported mount source", mnt.Target)
		}
		payload.Mounts = append(payload.Mounts, encoded)
	}
	for _, secret := range container.Secrets {
		secretID, err := encodePersistedObjectRef(enc, secret.Secret, "container secret")
		if err != nil {
			return persistedContainerMetadataValue{}, err
		}
		payload.Secrets = append(payload.Secrets, persistedContainerSecretPayload{
			SecretResultID: secretID,
			EnvName:        secret.EnvName,
			MountPath:      secret.MountPath,
			Owner:          secret.Owner,
			Mode:           secret.Mode,
		})
	}
	for _, socket := range container.Sockets {
		sourceID, err := encodePersistedObjectRef(enc, socket.Source, "container socket")
		if err != nil {
			return persistedContainerMetadataValue{}, err
		}
		payload.Sockets = append(payload.Sockets, persistedContainerSocketPayload{
			SourceResultID: sourceID,
			ContainerPath:  socket.ContainerPath,
			Owner:          socket.Owner,
		})
	}

	return payload, nil
}

// decodePersistedContainerResources rebuilds a persisted container's mounts,
// secrets and sockets, loading their sources by result id. Directory and file
// mount sources stay lazy accessors until their parts are demanded.
func decodePersistedContainerResources(ctx context.Context, dec *dagql.PersistDecodeContext, persisted persistedContainerMetadataValue) (ContainerMounts, []ContainerSecret, []ContainerSocket, error) {
	mounts := make(ContainerMounts, 0, len(persisted.Mounts))
	for _, persistedMount := range persisted.Mounts {
		mnt := ContainerMount{
			Target:   persistedMount.Target,
			Readonly: persistedMount.Readonly,
		}
		switch persistedMount.Kind {
		case persistedContainerMountKindDirectory:
			mnt.DirectorySource = new(LazyAccessor[*Directory, *Container])
		case persistedContainerMountKindFile:
			mnt.FileSource = new(LazyAccessor[*File, *Container])
		case persistedContainerMountKindCache:
			cacheRes, err := loadPersistedObjectResultByResultID[*CacheVolume](ctx, dec, persistedMount.CacheSourceResultID, "container mount cache")
			if err != nil {
				return nil, nil, nil, err
			}
			mnt.CacheSource = &CacheMountSource{Volume: cacheRes}
		case persistedContainerMountKindVolume:
			volumeRes, err := loadPersistedObjectResultByResultID[*Volume](ctx, dec, persistedMount.VolumeSourceResultID, "container mount volume")
			if err != nil {
				return nil, nil, nil, err
			}
			mnt.VolumeSource = &VolumeMountSource{Volume: volumeRes}
		case persistedContainerMountKindTmpfs:
			mnt.TmpfsSource = &TmpfsMountSource{Size: persistedMount.TmpfsSize}
		default:
			return nil, nil, nil, fmt.Errorf("decode persisted container mount %q: unsupported kind %q", persistedMount.Target, persistedMount.Kind)
		}
		mounts = append(mounts, mnt)
	}
	secrets := make([]ContainerSecret, 0, len(persisted.Secrets))
	for _, persistedSecret := range persisted.Secrets {
		secret, err := loadPersistedObjectResultByResultID[*Secret](ctx, dec, persistedSecret.SecretResultID, "container secret")
		if err != nil {
			return nil, nil, nil, err
		}
		secrets = append(secrets, ContainerSecret{
			Secret:    secret,
			EnvName:   persistedSecret.EnvName,
			MountPath: persistedSecret.MountPath,
			Owner:     persistedSecret.Owner,
			Mode:      persistedSecret.Mode,
		})
	}
	sockets := make([]ContainerSocket, 0, len(persisted.Sockets))
	for _, persistedSocket := range persisted.Sockets {
		source, err := loadPersistedObjectResultByResultID[*Socket](ctx, dec, persistedSocket.SourceResultID, "container socket")
		if err != nil {
			return nil, nil, nil, err
		}
		sockets = append(sockets, ContainerSocket{
			Source:        source,
			ContainerPath: persistedSocket.ContainerPath,
			Owner:         persistedSocket.Owner,
		})
	}
	return mounts, secrets, sockets, nil
}

func (*Container) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	var envelope persistedContainerPayload
	if err := json.Unmarshal(payload, &envelope); err != nil {
		return nil, fmt.Errorf("decode persisted container payload: %w", err)
	}
	persisted := envelope.Metadata.Value
	fs := new(LazyAccessor[*Directory, *Container])

	mounts, secrets, sockets, err := decodePersistedContainerResources(ctx, dec, persisted)
	if err != nil {
		return nil, err
	}
	services, err := decodePersistedServiceBindings(ctx, dec, "container", persisted.Services)
	if err != nil {
		return nil, err
	}

	metaAccessor := new(LazyAccessor[bkcache.ImmutableRef, *Container])
	links, err := loadPersistedSnapshotLinksByResultID(ctx, dec, "container")
	if err != nil {
		return nil, err
	}

	container := &Container{
		FS:                 fs,
		Config:             persisted.Config,
		EnabledGPUs:        slices.Clone(persisted.EnabledGPUs),
		Mounts:             mounts,
		MetaSnapshot:       metaAccessor,
		Platform:           persisted.Platform,
		Annotations:        slices.Clone(persisted.Annotations),
		Secrets:            secrets,
		Sockets:            sockets,
		ImageRef:           persisted.ImageRef,
		Ports:              slices.Clone(persisted.Ports),
		Services:           services,
		DefaultTerminalCmd: persisted.DefaultTerminalCmd,
		SystemEnvNames:     slices.Clone(persisted.SystemEnvNames),
		VolatileEnv:        slices.Clone(persisted.VolatileEnv),
		DefaultArgs:        persisted.DefaultArgs,
	}
	// Local persistence may contain an unchanged pending part without a recipe.
	// Admit only the same closed, recorded-parent mapping used after transfer.
	delegated := false
	for key, part := range envelope.Parts {
		if part.Kind != containerPartPending || envelope.OperationState != "" {
			continue
		}
		mapping, err := containerPartDelegation(dagql.PersistedPayloadVisit{Call: dec.Call(), SnapshotLinks: links}, envelope, key)
		if err != nil {
			return nil, err
		}
		delegated = delegated || mapping != nil
	}
	if envelope.OperationState != "" || delegated {
		kind := ""
		if dec.Call() != nil && len(envelope.LazyJSON) > 0 {
			kind = dec.Call().Field
		}
		if envelope.OperationState != "" {
			if err := validateTransferOperation(envelope.OperationState, kind, envelope.LazyJSON); err != nil {
				return nil, err
			}
		}
		if _, err := mapContainerTransferParts(dagql.PersistedPayloadVisit{SnapshotLinks: links}, envelope); err != nil {
			return nil, err
		}
		container.acquiredOutput.Store(&containerAcquiredOutput{Payload: envelope, Links: dagql.ClonePersistedSnapshotLinks(links), Revision: 1})
		for part, descriptor := range envelope.Parts {
			if descriptor.Kind == containerPartAbsent {
				container.setAbsentTransferPart(part)
			}
		}
		return container, nil
	}

	var recipe Lazy[*Container]
	pending := !envelope.Metadata.Consumed
	for _, part := range envelope.Parts {
		pending = pending || part.Kind == containerPartPending
	}
	if !pending {
		container.lazyJSON = slices.Clone(envelope.LazyJSON)
	} else if len(envelope.LazyJSON) != 0 {
		if dec.Call() == nil {
			return nil, fmt.Errorf("decode persisted container: missing call for recipe")
		}
		recipe, err = decodePersistedContainerRecipe(ctx, dec, dec.Call(), envelope.LazyJSON)
		if err != nil {
			return nil, err
		}
	}
	if err := container.installContainerParts(ctx, dec, envelope.Metadata.Consumed, envelope.Parts, links, recipe); err != nil {
		return nil, fmt.Errorf("decode persisted container: %w", err)
	}
	return container, nil
}

func (container *Container) OnRelease(ctx context.Context) error {
	if container == nil {
		return nil
	}
	var rerr error
	if container.MetaSnapshot != nil {
		if snapshot, ok := container.MetaSnapshot.Peek(); ok && snapshot != nil {
			rerr = stderrors.Join(rerr, snapshot.Release(ctx))
		}
	}
	if container.FS != nil {
		if dir, ok := container.FS.Peek(); ok && dir != nil {
			rerr = stderrors.Join(rerr, dir.OnRelease(ctx))
		}
	}
	for i := range container.Mounts {
		mnt := &container.Mounts[i]
		if mnt.DirectorySource != nil {
			if dir, ok := mnt.DirectorySource.Peek(); ok && dir != nil {
				rerr = stderrors.Join(rerr, dir.OnRelease(ctx))
			}
		}
		if mnt.FileSource != nil {
			if file, ok := mnt.FileSource.Peek(); ok && file != nil {
				rerr = stderrors.Join(rerr, file.OnRelease(ctx))
			}
		}
	}
	return rerr
}

// Ownership contains a UID/GID pair resolved from a user/group name or ID pair
// provided via the API. It primarily exists to distinguish an unspecified
// ownership from UID/GID 0 (root) ownership.
type Ownership struct {
	UID int
	GID int
}

// ContainerSecret configures a secret to expose, either as an environment
// variable or mounted to a file path.
type ContainerSecret struct {
	Secret    dagql.ObjectResult[*Secret]
	EnvName   string
	MountPath string
	Owner     *Ownership
	Mode      fs.FileMode
}

// ContainerSocket configures a socket to expose, currently as a Unix socket,
// but potentially as a TCP or UDP address in the future.
type ContainerSocket struct {
	Source        dagql.ObjectResult[*Socket]
	ContainerPath string
	Owner         *Ownership
}

func attachContainerResult(attach func(dagql.AnyResult) (dagql.AnyResult, error), res dagql.ObjectResult[*Container], label string) (dagql.ObjectResult[*Container], error) {
	attached, err := attach(res)
	if err != nil {
		return dagql.ObjectResult[*Container]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[*Container])
	if !ok {
		return dagql.ObjectResult[*Container]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

func attachSecretResult(attach func(dagql.AnyResult) (dagql.AnyResult, error), res dagql.ObjectResult[*Secret], label string) (dagql.ObjectResult[*Secret], error) {
	attached, err := attach(res)
	if err != nil {
		return dagql.ObjectResult[*Secret]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[*Secret])
	if !ok {
		return dagql.ObjectResult[*Secret]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

func attachSocketResult(attach func(dagql.AnyResult) (dagql.AnyResult, error), res dagql.ObjectResult[*Socket], label string) (dagql.ObjectResult[*Socket], error) {
	attached, err := attach(res)
	if err != nil {
		return dagql.ObjectResult[*Socket]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[*Socket])
	if !ok {
		return dagql.ObjectResult[*Socket]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

func attachServiceResult(attach func(dagql.AnyResult) (dagql.AnyResult, error), res dagql.ObjectResult[*Service], label string) (dagql.ObjectResult[*Service], error) {
	attached, err := attach(res)
	if err != nil {
		return dagql.ObjectResult[*Service]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[*Service])
	if !ok {
		return dagql.ObjectResult[*Service]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

func attachCacheVolumeResult(attach func(dagql.AnyResult) (dagql.AnyResult, error), res dagql.ObjectResult[*CacheVolume], label string) (dagql.ObjectResult[*CacheVolume], error) {
	attached, err := attach(res)
	if err != nil {
		return dagql.ObjectResult[*CacheVolume]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[*CacheVolume])
	if !ok {
		return dagql.ObjectResult[*CacheVolume]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

func attachVolumeResult(attach func(dagql.AnyResult) (dagql.AnyResult, error), res dagql.ObjectResult[*Volume], label string) (dagql.ObjectResult[*Volume], error) {
	attached, err := attach(res)
	if err != nil {
		return dagql.ObjectResult[*Volume]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[*Volume])
	if !ok {
		return dagql.ObjectResult[*Volume]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

func attachEnvFileResult(attach func(dagql.AnyResult) (dagql.AnyResult, error), res dagql.ObjectResult[*EnvFile], label string) (dagql.ObjectResult[*EnvFile], error) {
	attached, err := attach(res)
	if err != nil {
		return dagql.ObjectResult[*EnvFile]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[*EnvFile])
	if !ok {
		return dagql.ObjectResult[*EnvFile]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

func bareDirectoryForContainerPath(container *Container, targetPath string) (*Directory, error) {
	mnt, _, err := locatePath(container, targetPath)
	if err != nil {
		return nil, err
	}
	switch {
	case mnt == nil:
		if container.FS == nil {
			return nil, fmt.Errorf("missing bare rootfs output for %s", targetPath)
		}
		dir, ok := container.FS.Peek()
		if !ok || dir == nil {
			return nil, fmt.Errorf("missing bare rootfs output for %s", targetPath)
		}
		return dir, nil
	case mnt.DirectorySource != nil:
		dir, ok := mnt.DirectorySource.Peek()
		if !ok || dir == nil {
			return nil, fmt.Errorf("missing bare directory output for %s", targetPath)
		}
		return dir, nil
	default:
		return nil, fmt.Errorf("path %s does not resolve to a bare directory output shell", targetPath)
	}
}

func targetParentDirectoryForContainerPath(ctx context.Context, parent dagql.ObjectResult[*Container], current *Container, targetPath string) (dagql.ObjectResult[*Directory], error) {
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return dagql.ObjectResult[*Directory]{}, fmt.Errorf("failed to get dagql server: %w", err)
	}
	if current == nil {
		return dagql.ObjectResult[*Directory]{}, fmt.Errorf("container lazy current state is nil")
	}
	mnt, _, err := locatePath(current, targetPath)
	if err != nil {
		return dagql.ObjectResult[*Directory]{}, err
	}
	switch {
	case mnt == nil:
		var dir dagql.ObjectResult[*Directory]
		if err := srv.Select(ctx, parent, &dir, dagql.Selector{Field: "rootfs"}); err != nil {
			return dagql.ObjectResult[*Directory]{}, err
		}
		return dir, nil
	case mnt.DirectorySource != nil:
		var dir dagql.ObjectResult[*Directory]
		if err := srv.Select(ctx, parent, &dir, dagql.Selector{
			Field: "directory",
			Args: []dagql.NamedInput{
				{Name: "path", Value: dagql.String(mnt.Target)},
			},
		}); err != nil {
			return dagql.ObjectResult[*Directory]{}, err
		}
		return dir, nil
	default:
		return dagql.ObjectResult[*Directory]{}, fmt.Errorf("path %s does not resolve to a directory target parent", targetPath)
	}
}

func ExpandContainerInput(container *Container, input string, expand bool) (string, error) {
	if !expand {
		return input, nil
	}

	secretEnvs := []string{}
	for _, secret := range container.Secrets {
		secretEnvs = append(secretEnvs, secret.EnvName)
	}
	volatileEnvs := []string{}
	WalkEnv(container.VolatileEnv, func(name, _, _ string) {
		volatileEnvs = append(volatileEnvs, name)
	})

	var secretEnvFoundError error
	expanded := os.Expand(input, func(k string) string {
		if slices.Contains(secretEnvs, k) {
			secretEnvFoundError = fmt.Errorf("expand cannot be used with secret env variable %q", k)
			return ""
		}
		if slices.Contains(volatileEnvs, k) {
			secretEnvFoundError = fmt.Errorf("expand cannot be used with volatile env variable %q", k)
			return ""
		}

		v, _ := LookupEnv(container.Config.Env, k)
		return v
	})
	if secretEnvFoundError != nil {
		return "", secretEnvFoundError
	}
	return expanded, nil
}

func resolveContainerInputPath(container *Container, rawPath string, expand bool) (string, error) {
	path, err := ExpandContainerInput(container, rawPath, expand)
	if err != nil {
		return "", err
	}
	return absPath(container.Config.WorkingDir, path), nil
}

func (lazy *ContainerWithEntrypointLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithEntrypointLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithEntrypointLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withEntrypoint", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.Entrypoint = slices.Clone(lazy.Args)
			if !lazy.KeepDefaultArgs {
				cfg.Cmd = nil
			}
			return cfg
		})
		if err != nil {
			return err
		}
		if !lazy.KeepDefaultArgs {
			container.DefaultArgs = false
		}
		return nil
	})
}

func (lazy *ContainerWithEntrypointLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withEntrypoint parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithEntrypointLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withEntrypoint parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithEntrypointLazy{
		ParentResultID:  parentID,
		Args:            slices.Clone(lazy.Args),
		KeepDefaultArgs: lazy.KeepDefaultArgs,
	})
}

func (lazy *ContainerWithoutEntrypointLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutEntrypointLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutEntrypointLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutEntrypoint", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.Entrypoint = nil
			if !lazy.KeepDefaultArgs {
				cfg.Cmd = nil
			}
			return cfg
		})
		if err != nil {
			return err
		}
		if !lazy.KeepDefaultArgs {
			container.DefaultArgs = false
		}
		return nil
	})
}

func (lazy *ContainerWithoutEntrypointLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutEntrypoint parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutEntrypointLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutEntrypoint parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutEntrypointLazy{
		ParentResultID:  parentID,
		KeepDefaultArgs: lazy.KeepDefaultArgs,
	})
}

func (lazy *ContainerWithDefaultArgsLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithDefaultArgsLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithDefaultArgsLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withDefaultArgs", container, lazy.Parent, group, func(ctx context.Context) error {
		container.DefaultArgs = true
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			if lazy.Args == nil {
				cfg.Cmd = []string{}
			} else {
				cfg.Cmd = slices.Clone(lazy.Args)
			}
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithDefaultArgsLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withDefaultArgs parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithDefaultArgsLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withDefaultArgs parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithDefaultArgsLazy{
		ParentResultID: parentID,
		Args:           slices.Clone(lazy.Args),
	})
}

func (lazy *ContainerWithoutDefaultArgsLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutDefaultArgsLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutDefaultArgsLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutDefaultArgs", container, lazy.Parent, group, func(ctx context.Context) error {
		container.DefaultArgs = false
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.Cmd = nil
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutDefaultArgsLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutDefaultArgs parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutDefaultArgsLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutDefaultArgs parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutDefaultArgsLazy{
		ParentResultID: parentID,
	})
}

func (lazy *ContainerWithUserLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithUserLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithUserLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withUser", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.User = lazy.Name
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithUserLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withUser parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithUserLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withUser parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithUserLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
	})
}

func (lazy *ContainerWithoutUserLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutUserLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutUserLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutUser", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.User = ""
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutUserLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutUser parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutUserLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutUser parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutUserLazy{
		ParentResultID: parentID,
	})
}

func (lazy *ContainerWithWorkdirLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithWorkdirLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithWorkdirLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withWorkdir", container, lazy.Parent, group, func(ctx context.Context) error {
		resolvedPath, err := resolveContainerInputPath(container, lazy.Path, lazy.Expand)
		if err != nil {
			return err
		}
		_, err = container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.WorkingDir = resolvedPath
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithWorkdirLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withWorkdir parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithWorkdirLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withWorkdir parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithWorkdirLazy{
		ParentResultID: parentID,
		Path:           lazy.Path,
		Expand:         lazy.Expand,
	})
}

func (lazy *ContainerWithoutWorkdirLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutWorkdirLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutWorkdirLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutWorkdir", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.WorkingDir = ""
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutWorkdirLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutWorkdir parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutWorkdirLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutWorkdir parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutWorkdirLazy{
		ParentResultID: parentID,
	})
}

func (lazy *ContainerWithEnvVariableLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithEnvVariableLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithEnvVariableLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withEnvVariable", container, lazy.Parent, group, func(ctx context.Context) error {
		value, err := ExpandContainerInput(container, lazy.Value, lazy.Expand)
		if err != nil {
			return err
		}
		_, err = container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.Env = AddEnv(cfg.Env, lazy.Name, value)
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithEnvVariableLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withEnvVariable parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithEnvVariableLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withEnvVariable parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithEnvVariableLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
		Value:          lazy.Value,
		Expand:         lazy.Expand,
	})
}

func (lazy *ContainerWithEnvFileVariablesLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithEnvFileVariablesLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithEnvFileVariablesLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withEnvFileVariables", container, lazy.Parent, group, func(ctx context.Context) error {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		if err := cache.Evaluate(ctx, lazy.Source); err != nil {
			return err
		}
		vars, err := lazy.Source.Self().Variables(ctx, false)
		if err != nil {
			return err
		}
		_, err = container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			for _, v := range vars {
				cfg.Env = AddEnv(cfg.Env, v.Name, v.Value)
			}
			return cfg
		})
		return err
	})
}

func (lazy *ContainerWithEnvFileVariablesLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withEnvFileVariables parent")
	if err != nil {
		return nil, err
	}
	source, err := attachEnvFileResult(attach, lazy.Source, "attach container withEnvFileVariables source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithEnvFileVariablesLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withEnvFileVariables parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withEnvFileVariables source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithEnvFileVariablesLazy{
		ParentResultID: parentID,
		SourceResultID: sourceID,
	})
}

func (lazy *ContainerWithSystemEnvVariableLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithSystemEnvVariableLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithSystemEnvVariableLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withSystemEnvVariable", container, lazy.Parent, group, func(ctx context.Context) error {
		container.SystemEnvNames = append(container.SystemEnvNames, lazy.Name)
		return nil
	})
}

func (lazy *ContainerWithSystemEnvVariableLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withSystemEnvVariable parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithSystemEnvVariableLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withSystemEnvVariable parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithSystemEnvVariableLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
	})
}

func (lazy *ContainerWithVolatileVariableLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithVolatileVariableLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithVolatileVariableLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withVolatileVariable", container, lazy.Parent, group, func(ctx context.Context) error {
		container.WithVolatileVariable(lazy.Name, lazy.Value)
		return nil
	})
}

func (lazy *ContainerWithVolatileVariableLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withVolatileVariable parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithVolatileVariableLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withVolatileVariable parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithVolatileVariableLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
		Value:          lazy.Value,
	})
}

func (lazy *ContainerWithoutEnvVariableLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutEnvVariableLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutEnvVariableLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutEnvVariable", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			newEnv := []string{}
			WalkEnv(cfg.Env, func(k, _, env string) {
				if k != lazy.Name {
					newEnv = append(newEnv, env)
				}
			})
			cfg.Env = newEnv
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutVolatileVariableLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutVolatileVariableLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutVolatileVariableLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutVolatileVariable", container, lazy.Parent, group, func(ctx context.Context) error {
		container.WithoutVolatileVariable(lazy.Name)
		return nil
	})
}

func (lazy *ContainerWithoutVolatileVariableLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutVolatileVariable parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutVolatileVariableLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutVolatileVariable parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutVolatileVariableLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
	})
}

func (lazy *ContainerWithoutEnvVariableLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutEnvVariable parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutEnvVariableLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutEnvVariable parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutEnvVariableLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
	})
}

func (lazy *ContainerWithLabelLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithLabelLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithLabelLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withLabel", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			if cfg.Labels == nil {
				cfg.Labels = make(map[string]string)
			}
			cfg.Labels[lazy.Name] = lazy.Value
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithLabelLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withLabel parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithLabelLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withLabel parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithLabelLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
		Value:          lazy.Value,
	})
}

func (lazy *ContainerWithoutLabelLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutLabelLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutLabelLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutLabel", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			delete(cfg.Labels, lazy.Name)
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutLabelLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutLabel parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutLabelLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutLabel parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutLabelLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
	})
}

func (lazy *ContainerWithImageConfigMetadataLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithImageConfigMetadataLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithImageConfigMetadataLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withImageConfigMetadata", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			if lazy.Healthcheck != nil {
				healthcheck := *lazy.Healthcheck
				if lazy.Healthcheck.Test != nil {
					healthcheck.Test = slices.Clone(lazy.Healthcheck.Test)
				}
				cfg.Healthcheck = &healthcheck
			}
			if lazy.OnBuild != nil {
				cfg.OnBuild = slices.Clone(lazy.OnBuild)
			}
			if lazy.Shell != nil {
				cfg.Shell = slices.Clone(lazy.Shell)
			}
			if lazy.Volumes != nil {
				volumes := make(map[string]struct{}, len(lazy.Volumes))
				for _, volume := range lazy.Volumes {
					volumes[volume] = struct{}{}
				}
				cfg.Volumes = volumes
			}
			if lazy.StopSignal != "" {
				cfg.StopSignal = lazy.StopSignal
			}
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithImageConfigMetadataLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withImageConfigMetadata parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithImageConfigMetadataLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withImageConfigMetadata parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithImageConfigMetadataLazy{
		ParentResultID: parentID,
		Healthcheck:    lazy.Healthcheck,
		OnBuild:        slices.Clone(lazy.OnBuild),
		Shell:          slices.Clone(lazy.Shell),
		Volumes:        slices.Clone(lazy.Volumes),
		StopSignal:     lazy.StopSignal,
	})
}

func (lazy *ContainerWithHealthcheckLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithHealthcheckLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithHealthcheckLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withHealthcheck", container, lazy.Parent, group, func(ctx context.Context) error {
		healthcheck := lazy.Healthcheck
		if lazy.Healthcheck.Test != nil {
			healthcheck.Test = slices.Clone(lazy.Healthcheck.Test)
		}
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.Healthcheck = &healthcheck
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithHealthcheckLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withHealthcheck parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithHealthcheckLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withHealthcheck parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithHealthcheckLazy{
		ParentResultID: parentID,
		Healthcheck:    lazy.Healthcheck,
	})
}

func (lazy *ContainerWithoutHealthcheckLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutHealthcheckLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutHealthcheckLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutHealthcheck", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.UpdateImageConfig(ctx, func(cfg dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig {
			cfg.Healthcheck = nil
			return cfg
		})
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutHealthcheckLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutHealthcheck parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutHealthcheckLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutHealthcheck parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutHealthcheckLazy{
		ParentResultID: parentID,
	})
}

func (lazy *ContainerSetGPUsLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerSetGPUsLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerSetGPUsLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.setGPUs", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithGPU(ctx, ContainerGPUOpts{Devices: slices.Clone(lazy.Devices)}); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerSetGPUsLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container setGPUs parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerSetGPUsLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container setGPUs parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerSetGPUsLazy{
		ParentResultID: parentID,
		Devices:        slices.Clone(lazy.Devices),
	})
}

func (lazy *ContainerWithAnnotationLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithAnnotationLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithAnnotationLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withAnnotation", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithAnnotation(ctx, lazy.Name, lazy.Value); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithAnnotationLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withAnnotation parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithAnnotationLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withAnnotation parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithAnnotationLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
		Value:          lazy.Value,
	})
}

func (lazy *ContainerWithoutAnnotationLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutAnnotationLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutAnnotationLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutAnnotation", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithoutAnnotation(ctx, lazy.Name); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutAnnotationLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutAnnotation parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutAnnotationLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutAnnotation parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutAnnotationLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
	})
}

func (lazy *ContainerWithSecretVariableLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithSecretVariableLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithSecretVariableLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withSecretVariable", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithSecretVariable(ctx, lazy.Name, lazy.Secret); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithSecretVariableLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withSecretVariable parent")
	if err != nil {
		return nil, err
	}
	secret, err := attachSecretResult(attach, lazy.Secret, "attach container withSecretVariable secret")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Secret = secret
	return []dagql.AnyResult{parent, secret}, nil
}

func (lazy *ContainerWithSecretVariableLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withSecretVariable parent")
	if err != nil {
		return nil, err
	}
	secretID, err := encodePersistedObjectRef(enc, lazy.Secret, "container withSecretVariable secret")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithSecretVariableLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
		SecretResultID: secretID,
	})
}

func (lazy *ContainerWithoutSecretVariableLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutSecretVariableLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutSecretVariableLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutSecretVariable", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithoutSecretVariable(ctx, lazy.Name); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutSecretVariableLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutSecretVariable parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutSecretVariableLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutSecretVariable parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutSecretVariableLazy{
		ParentResultID: parentID,
		Name:           lazy.Name,
	})
}

func (lazy *ContainerWithServiceBindingLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithServiceBindingLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithServiceBindingLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withServiceBinding", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithServiceBinding(ctx, lazy.Service, lazy.Alias); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithServiceBindingLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withServiceBinding parent")
	if err != nil {
		return nil, err
	}
	service, err := attachServiceResult(attach, lazy.Service, "attach container withServiceBinding service")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Service = service
	return []dagql.AnyResult{parent, service}, nil
}

func (lazy *ContainerWithServiceBindingLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withServiceBinding parent")
	if err != nil {
		return nil, err
	}
	serviceID, err := encodePersistedObjectRef(enc, lazy.Service, "container withServiceBinding service")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithServiceBindingLazy{
		ParentResultID:  parentID,
		ServiceResultID: serviceID,
		Alias:           lazy.Alias,
	})
}

func (lazy *ContainerWithExposedPortLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithExposedPortLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithExposedPortLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withExposedPort", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithExposedPort(lazy.Port); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithExposedPortLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withExposedPort parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithExposedPortLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withExposedPort parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithExposedPortLazy{
		ParentResultID: parentID,
		Port:           lazy.Port,
	})
}

func (lazy *ContainerWithoutExposedPortLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutExposedPortLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutExposedPortLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutExposedPort", container, lazy.Parent, group, func(ctx context.Context) error {
		if _, err := container.WithoutExposedPort(lazy.Port, lazy.Protocol); err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerWithoutExposedPortLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutExposedPort parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutExposedPortLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutExposedPort parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutExposedPortLazy{
		ParentResultID: parentID,
		Port:           lazy.Port,
		Protocol:       lazy.Protocol,
	})
}

func (lazy *ContainerWithDefaultTerminalCmdLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithDefaultTerminalCmdLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithDefaultTerminalCmdLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withDefaultTerminalCmd", container, lazy.Parent, group, func(ctx context.Context) error {
		container.DefaultTerminalCmd = lazy.Opts
		return nil
	})
}

func (lazy *ContainerWithDefaultTerminalCmdLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withDefaultTerminalCmd parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithDefaultTerminalCmdLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withDefaultTerminalCmd parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithDefaultTerminalCmdLazy{
		ParentResultID: parentID,
		Opts:           lazy.Opts,
	})
}

func (lazy *ContainerRootFSLazy) Evaluate(ctx context.Context, dir *Directory) error {
	return dir.evaluateLazy(ctx, &lazy.LazyState, "Container.rootfs", func(ctx context.Context) error {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		// The rootfs view needs exactly the parent's fs part.
		if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartFS); err != nil {
			return err
		}

		parent := lazy.Parent.Self()
		if parent == nil {
			return fmt.Errorf("container rootfs lazy: nil parent container")
		}

		if parent.FS != nil {
			if src, ok := parent.FS.Peek(); ok && src != nil {
				detached, err := cloneDetachedDirectoryForContainerResult(ctx, src)
				if err != nil {
					return err
				}
				dir.Platform = detached.Platform
				dir.Services = slices.Clone(detached.Services)
				if dirPath, ok := detached.Dir.Peek(); ok {
					dir.SetPath(dirPath)
				}
				if snapshot, ok := detached.Snapshot.Peek(); ok {
					dir.SetSnapshot(snapshot)
				}

				return nil
			}
		}

		scratchDir, scratchSnapshot, err := loadCanonicalScratchDirectory(ctx)
		if err != nil {
			return err
		}
		dir.SetPath(scratchDir)
		dir.SetSnapshot(scratchSnapshot)

		return nil
	})
}

func (lazy *ContainerRootFSLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container rootfs parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerRootFSLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container rootfs parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerRootFSLazy{ParentResultID: parentID})
}

func (lazy *ContainerWithRootFSLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

// ContainerLazyGroups implements the withRootfs mapping (a static
// snapshot writer): the fs part is the written part; metadata delegates
// with the ImageRef clear as its one edit; everything else delegates.
func (lazy *ContainerWithRootFSLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	if parts == nil {
		groups := []dagql.LazyGroupKey{ContainerLazyGroupMetadata, ContainerLazyGroupWrite}
		for _, part := range containerSnapshotParts(ctr) {
			if part == ContainerPartFS {
				continue
			}
			groups = append(groups, containerDelegationGroup(part))
		}
		return groups, nil
	}
	var groups []dagql.LazyGroupKey
	seen := make(map[dagql.LazyGroupKey]struct{}, len(parts))
	for _, part := range parts {
		var group dagql.LazyGroupKey
		switch part {
		case ContainerPartMetadata:
			group = ContainerLazyGroupMetadata
		case ContainerPartFS:
			group = ContainerLazyGroupWrite
		default:
			group = containerDelegationGroup(part)
		}
		if _, dup := seen[group]; dup {
			continue
		}
		seen[group] = struct{}{}
		groups = append(groups, group)
	}
	return groups, nil
}

func (lazy *ContainerWithRootFSLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	switch group {
	case ContainerLazyGroupMetadata:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withRootfs", group, func(ctx context.Context) error {
			if err := materializeContainerMetadataFromParent(ctx, container, lazy.Parent); err != nil {
				return err
			}
			container.ImageRef = ""
			return nil
		})
	case ContainerLazyGroupWrite:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withRootfs", group, func(ctx context.Context) error {
			cache, err := dagql.EngineCache(ctx)
			if err != nil {
				return err
			}
			if err := cache.Evaluate(ctx, lazy.Source); err != nil {
				return err
			}
			detached, err := cloneDetachedDirectoryForContainerResult(ctx, lazy.Source.Self())
			if err != nil {
				return err
			}
			container.ensureFSAccessor().SetValue(detached)
			return nil
		})
	default:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withRootfs", group, func(ctx context.Context) error {
			return delegateContainerPart(ctx, container, lazy.Parent, dagql.PartKey(group))
		})
	}
}

func (lazy *ContainerWithRootFSLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withRootfs parent")
	if err != nil {
		return nil, err
	}
	source, err := attachDirectoryResult(attach, lazy.Source, "attach container withRootfs source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithRootFSLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withRootfs parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withRootfs source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithRootFSLazy{
		ParentResultID: parentID,
		SourceResultID: sourceID,
	})
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (lazy *ContainerDirectoryLazy) Evaluate(ctx context.Context, dir *Directory) error {
	return dir.evaluateLazy(ctx, &lazy.LazyState, "Container.directory", func(ctx context.Context) error {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		// Locating the path needs only the parent's metadata (the mount
		// list and working directory); the selected part is evaluated
		// below, and untouched sibling parts stay pending.
		if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartMetadata); err != nil {
			return err
		}

		parent := lazy.Parent.Self()
		if parent == nil {
			return fmt.Errorf("container directory lazy: nil parent container")
		}

		srv, err := CurrentDagqlServer(ctx)
		if err != nil {
			return err
		}

		mnt, subpath, err := locatePath(parent, lazy.Path)
		if err != nil {
			return err
		}

		var resolved dagql.ObjectResult[*Directory]
		switch {
		case mnt == nil:
			if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartFS); err != nil {
				return err
			}
			var rootfs dagql.ObjectResult[*Directory]
			if err := srv.Select(ctx, lazy.Parent, &rootfs, dagql.Selector{Field: "rootfs"}); err != nil {
				return err
			}
			if subpath == "" || subpath == "." || subpath == "/" {
				resolved = rootfs
			} else {
				if err := srv.Select(ctx, rootfs, &resolved, dagql.Selector{
					Field: "directory",
					Args: []dagql.NamedInput{
						{Name: "path", Value: dagql.String(subpath)},
					},
				}); err != nil {
					return err
				}
			}
		case mnt.DirectorySource != nil:
			if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartMount(mnt.Target)); err != nil {
				return err
			}
			mountedDir, ok := mnt.DirectorySource.Peek()
			if !ok || mountedDir == nil {
				return fmt.Errorf("container directory lazy: missing mounted directory source for %s", mnt.Target)
			}
			if subpath == "" || subpath == "." {
				detached, err := cloneDetachedDirectoryForContainerResult(ctx, mountedDir)
				if err != nil {
					return err
				}
				dir.Platform = detached.Platform
				dir.Services = slices.Clone(detached.Services)
				if dirPath, ok := detached.Dir.Peek(); ok {
					dir.SetPath(dirPath)
				}
				if snapshot, ok := detached.Snapshot.Peek(); ok {
					dir.SetSnapshot(snapshot)
				}

				return nil
			}
			mountedDirPath, ok := mountedDir.Dir.Peek()
			if !ok {
				return fmt.Errorf("container directory lazy: missing mounted directory path for %s", mnt.Target)
			}
			mountedSnapshot, ok := mountedDir.Snapshot.Peek()
			if !ok || mountedSnapshot == nil {
				return fmt.Errorf("container directory lazy: missing mounted directory snapshot for %s", mnt.Target)
			}
			finalDir := path.Join(mountedDirPath, subpath)
			if err := MountRef(ctx, mountedSnapshot, func(root string, _ *mount.Mount) error {
				resolvedPath, err := containerdfs.RootPath(root, finalDir)
				if err != nil {
					return err
				}
				info, err := os.Lstat(resolvedPath)
				if err != nil {
					return TrimErrPathPrefix(err, root)
				}
				if !info.IsDir() {
					return notADirectoryError{fmt.Errorf("path %s is a file, not a directory", lazy.Path)}
				}
				return nil
			}); err != nil {
				return RestoreErrPath(err, lazy.Path)
			}
			query, err := CurrentQuery(ctx)
			if err != nil {
				return err
			}
			reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, mountedSnapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
			if err != nil {
				return err
			}
			dir.Platform = mountedDir.Platform
			dir.Services = slices.Clone(mountedDir.Services)
			dir.SetPath(finalDir)
			dir.SetSnapshot(reopened)

			return nil
		case mnt.FileSource != nil:
			return notADirectoryError{fmt.Errorf("path %s is a file, not a directory", lazy.Path)}
		default:
			return fmt.Errorf("container directory lazy: invalid path %s in container mounts", lazy.Path)
		}

		if err := cache.Evaluate(ctx, resolved); err != nil {
			return err
		}

		src := resolved.Self()
		if src == nil {
			return fmt.Errorf("container directory lazy: nil resolved directory")
		}
		detached, err := cloneDetachedDirectoryForContainerResult(ctx, src)
		if err != nil {
			return err
		}
		dir.Platform = detached.Platform
		dir.Services = slices.Clone(detached.Services)
		if dirPath, ok := detached.Dir.Peek(); ok {
			dir.SetPath(dirPath)
		}
		if snapshot, ok := detached.Snapshot.Peek(); ok {
			dir.SetSnapshot(snapshot)
		}

		return nil
	})
}

func (lazy *ContainerDirectoryLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container directory parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerDirectoryLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container directory parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerDirectoryLazy{
		ParentResultID: parentID,
		Path:           lazy.Path,
	})
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func (lazy *ContainerFileLazy) Evaluate(ctx context.Context, file *File) error {
	return file.evaluateLazy(ctx, &lazy.LazyState, "Container.file", func(ctx context.Context) error {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		// Locating the path needs only the parent's metadata (the mount
		// list and working directory); the selected part is evaluated
		// below, and untouched sibling parts stay pending.
		if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartMetadata); err != nil {
			return err
		}

		parent := lazy.Parent.Self()
		if parent == nil {
			return fmt.Errorf("container file lazy: nil parent container")
		}

		srv, err := CurrentDagqlServer(ctx)
		if err != nil {
			return err
		}

		mnt, subpath, err := locatePath(parent, lazy.Path)
		if err != nil {
			return err
		}

		var resolved dagql.ObjectResult[*File]
		switch {
		case mnt == nil:
			if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartFS); err != nil {
				return err
			}
			var rootfs dagql.ObjectResult[*Directory]
			if err := srv.Select(ctx, lazy.Parent, &rootfs, dagql.Selector{Field: "rootfs"}); err != nil {
				return err
			}
			if err := srv.Select(ctx, rootfs, &resolved, dagql.Selector{
				Field: "file",
				Args: []dagql.NamedInput{
					{Name: "path", Value: dagql.String(subpath)},
				},
			}); err != nil {
				return err
			}
		case mnt.DirectorySource != nil:
			if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartMount(mnt.Target)); err != nil {
				return err
			}
			mountedDir, ok := mnt.DirectorySource.Peek()
			if !ok || mountedDir == nil {
				return fmt.Errorf("container file lazy: missing mounted directory source for %s", mnt.Target)
			}
			mountedDirPath, ok := mountedDir.Dir.Peek()
			if !ok {
				return fmt.Errorf("container file lazy: missing mounted directory path for %s", mnt.Target)
			}
			mountedSnapshot, ok := mountedDir.Snapshot.Peek()
			if !ok || mountedSnapshot == nil {
				return fmt.Errorf("container file lazy: missing mounted directory snapshot for %s", mnt.Target)
			}
			finalFile := path.Join(mountedDirPath, subpath)
			if err := MountRef(ctx, mountedSnapshot, func(root string, _ *mount.Mount) error {
				resolvedPath, err := containerdfs.RootPath(root, finalFile)
				if err != nil {
					return err
				}
				info, err := os.Lstat(resolvedPath)
				if err != nil {
					return TrimErrPathPrefix(err, root)
				}
				if info.IsDir() {
					return notAFileError{fmt.Errorf("path %s is a directory, not a file", lazy.Path)}
				}
				return nil
			}); err != nil {
				return RestoreErrPath(err, lazy.Path)
			}
			query, err := CurrentQuery(ctx)
			if err != nil {
				return err
			}
			reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, mountedSnapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
			if err != nil {
				return err
			}
			file.Platform = mountedDir.Platform
			file.Services = slices.Clone(mountedDir.Services)
			file.SetPath(finalFile)
			file.SetSnapshot(reopened)

			return nil
		case mnt.FileSource != nil:
			if err := cache.EvaluateParts(ctx, lazy.Parent, ContainerPartMount(mnt.Target)); err != nil {
				return err
			}
			mountedFile, ok := mnt.FileSource.Peek()
			if !ok || mountedFile == nil {
				return fmt.Errorf("container file lazy: missing mounted file source for %s", mnt.Target)
			}
			if subpath != "" && subpath != "." {
				return notAFileError{fmt.Errorf("path %s is a directory, not a file", lazy.Path)}
			}
			detached, err := cloneDetachedFileForContainerResult(ctx, mountedFile)
			if err != nil {
				return err
			}
			file.Platform = detached.Platform
			file.Services = slices.Clone(detached.Services)
			if filePath, ok := detached.File.Peek(); ok {
				file.SetPath(filePath)
			}
			if snapshot, ok := detached.Snapshot.Peek(); ok {
				file.SetSnapshot(snapshot)
			}

			return nil
		default:
			return fmt.Errorf("container file lazy: invalid path %s in container mounts", lazy.Path)
		}

		if err := cache.Evaluate(ctx, resolved); err != nil {
			return err
		}

		src := resolved.Self()
		if src == nil {
			return fmt.Errorf("container file lazy: nil resolved file")
		}
		detached, err := cloneDetachedFileForContainerResult(ctx, src)
		if err != nil {
			return err
		}
		file.Platform = detached.Platform
		file.Services = slices.Clone(detached.Services)
		if filePath, ok := detached.File.Peek(); ok {
			file.SetPath(filePath)
		}
		if snapshot, ok := detached.Snapshot.Peek(); ok {
			file.SetSnapshot(snapshot)
		}

		return nil
	})
}

func (lazy *ContainerFileLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container file parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerFileLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container file parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerFileLazy{
		ParentResultID: parentID,
		Path:           lazy.Path,
	})
}

func (lazy *ContainerWithDirectoryLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithDirectoryLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return containerPathWriterGroups(ctr, []string{lazy.Path}, parts)
}

func (lazy *ContainerWithDirectoryLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateContainerPathWriterGroup(
		ctx,
		container,
		&lazy.LazyState,
		lazy.Parent,
		group,
		"Container.withDirectory",
		[]string{lazy.Path},
		func(mnt *ContainerMount) bool { return mnt.FileSource != nil },
		lazy.Source,
		func(ctx context.Context) error {
			_, err := container.WithDirectory(ctx, lazy.Parent, lazy.Path, lazy.Source, lazy.Filter, lazy.Owner)
			return err
		},
	)
}

func (lazy *ContainerWithDirectoryLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withDirectory parent")
	if err != nil {
		return nil, err
	}
	source, err := attachDirectoryResult(attach, lazy.Source, "attach container withDirectory source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithDirectoryLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withDirectory parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withDirectory source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithDirectoryLazy{
		ParentResultID: parentID,
		Path:           lazy.Path,
		SourceResultID: sourceID,
		Filter:         lazy.Filter,
		Owner:          lazy.Owner,
	})
}

func (lazy *ContainerWithFileLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithFileLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return containerPathWriterGroups(ctr, []string{lazy.Path}, parts)
}

func (lazy *ContainerWithFileLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateContainerPathWriterGroup(
		ctx,
		container,
		&lazy.LazyState,
		lazy.Parent,
		group,
		"Container.withFile",
		[]string{lazy.Path},
		removableExactContainerMount,
		lazy.Source,
		func(ctx context.Context) error {
			_, err := container.WithFile(ctx, lazy.Parent, lazy.Path, lazy.Source, lazy.Permissions, lazy.Owner)
			return err
		},
	)
}

func (lazy *ContainerWithFileLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withFile parent")
	if err != nil {
		return nil, err
	}
	source, err := attachFileResult(attach, lazy.Source, "attach container withFile source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithFileLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withFile parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withFile source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithFileLazy{
		ParentResultID: parentID,
		Path:           lazy.Path,
		SourceResultID: sourceID,
		Permissions:    lazy.Permissions,
		Owner:          lazy.Owner,
	})
}

func (lazy *ContainerWithMountedDirectoryLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithMountedDirectoryLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return containerMountWriterGroups(ctr, lazy.Target, parts)
}

//nolint:dupl // symmetric with ContainerWithMountedFileLazy; sharing would hide directory and file accessor semantics
func (lazy *ContainerWithMountedDirectoryLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	switch group {
	case ContainerLazyGroupMetadata:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedDirectory", group, func(ctx context.Context) error {
			var source *LazyAccessor[*Directory, *Container]
			if mnt := container.mountAt(absPath(container.Config.WorkingDir, lazy.Target)); mnt != nil {
				source = mnt.DirectorySource
			}
			if err := materializeContainerMetadataFromParent(ctx, container, lazy.Parent); err != nil {
				return err
			}
			target := absPath(container.Config.WorkingDir, lazy.Target)
			if source == nil {
				source = new(LazyAccessor[*Directory, *Container])
			}
			container.Mounts = container.Mounts.With(ContainerMount{
				Target:          target,
				Readonly:        lazy.Readonly,
				DirectorySource: source,
			})
			container.ImageRef = ""
			return nil
		})
	case ContainerLazyGroupWrite:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedDirectory", group, func(ctx context.Context) (rerr error) {
			source := lazy.Source
			var err error
			if lazy.Owner != "" {
				source, err = container.chownDir(ctx, lazy.Parent, source, lazy.Owner)
				if err != nil {
					return err
				}
			}
			cache, err := dagql.EngineCache(ctx)
			if err != nil {
				return err
			}
			if err := cache.Evaluate(ctx, source); err != nil {
				return err
			}
			detached, err := cloneDetachedDirectoryForContainerResult(ctx, source.Self())
			if err != nil {
				return err
			}
			defer func() {
				if detached != nil {
					rerr = stderrors.Join(rerr, detached.OnRelease(context.WithoutCancel(ctx)))
				}
			}()
			target := absPath(container.Config.WorkingDir, lazy.Target)
			mnt := container.mountAt(target)
			if mnt == nil || mnt.DirectorySource == nil {
				return fmt.Errorf("container withMountedDirectory: no directory mount at target %q", target)
			}
			mnt.DirectorySource.SetValue(detached)
			detached = nil
			return nil
		})
	default:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedDirectory", group, func(ctx context.Context) error {
			return delegateContainerPart(ctx, container, lazy.Parent, dagql.PartKey(group))
		})
	}
}

func (lazy *ContainerWithMountedDirectoryLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withMountedDirectory parent")
	if err != nil {
		return nil, err
	}
	source, err := attachDirectoryResult(attach, lazy.Source, "attach container withMountedDirectory source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithMountedDirectoryLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withMountedDirectory parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withMountedDirectory source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithMountedDirectoryLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		SourceResultID: sourceID,
		Owner:          lazy.Owner,
		Readonly:       lazy.Readonly,
	})
}

func (lazy *ContainerWithMountedFileLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithMountedFileLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return containerMountWriterGroups(ctr, lazy.Target, parts)
}

//nolint:dupl // symmetric with ContainerWithMountedDirectoryLazy; sharing would hide file and directory accessor semantics
func (lazy *ContainerWithMountedFileLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	switch group {
	case ContainerLazyGroupMetadata:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedFile", group, func(ctx context.Context) error {
			var source *LazyAccessor[*File, *Container]
			if mnt := container.mountAt(absPath(container.Config.WorkingDir, lazy.Target)); mnt != nil {
				source = mnt.FileSource
			}
			if err := materializeContainerMetadataFromParent(ctx, container, lazy.Parent); err != nil {
				return err
			}
			target := absPath(container.Config.WorkingDir, lazy.Target)
			if source == nil {
				source = new(LazyAccessor[*File, *Container])
			}
			container.Mounts = container.Mounts.With(ContainerMount{
				Target:     target,
				Readonly:   lazy.Readonly,
				FileSource: source,
			})
			container.ImageRef = ""
			return nil
		})
	case ContainerLazyGroupWrite:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedFile", group, func(ctx context.Context) (rerr error) {
			source := lazy.Source
			var err error
			if lazy.Owner != "" {
				source, err = container.chownFile(ctx, lazy.Parent, source, lazy.Owner)
				if err != nil {
					return err
				}
			}
			cache, err := dagql.EngineCache(ctx)
			if err != nil {
				return err
			}
			if err := cache.Evaluate(ctx, source); err != nil {
				return err
			}
			detached, err := cloneDetachedFileForContainerResult(ctx, source.Self())
			if err != nil {
				return err
			}
			defer func() {
				if detached != nil {
					rerr = stderrors.Join(rerr, detached.OnRelease(context.WithoutCancel(ctx)))
				}
			}()
			target := absPath(container.Config.WorkingDir, lazy.Target)
			mnt := container.mountAt(target)
			if mnt == nil || mnt.FileSource == nil {
				return fmt.Errorf("container withMountedFile: no file mount at target %q", target)
			}
			mnt.FileSource.SetValue(detached)
			detached = nil
			return nil
		})
	default:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedFile", group, func(ctx context.Context) error {
			return delegateContainerPart(ctx, container, lazy.Parent, dagql.PartKey(group))
		})
	}
}

func (lazy *ContainerWithMountedFileLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withMountedFile parent")
	if err != nil {
		return nil, err
	}
	source, err := attachFileResult(attach, lazy.Source, "attach container withMountedFile source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithMountedFileLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withMountedFile parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withMountedFile source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithMountedFileLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		SourceResultID: sourceID,
		Owner:          lazy.Owner,
		Readonly:       lazy.Readonly,
	})
}

func (lazy *ContainerWithMountedPathDockerfileCompatLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithMountedPathDockerfileCompatLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return containerMountWriterGroups(ctr, lazy.Target, parts)
}

func (lazy *ContainerWithMountedPathDockerfileCompatLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	switch group {
	case ContainerLazyGroupMetadata:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedPathDockerfileCompat", group, func(ctx context.Context) error {
			target := absPath(container.Config.WorkingDir, lazy.Target)
			var directorySource *LazyAccessor[*Directory, *Container]
			var fileSource *LazyAccessor[*File, *Container]
			if mnt := container.mountAt(target); mnt != nil {
				directorySource = mnt.DirectorySource
				fileSource = mnt.FileSource
			}
			if err := materializeContainerMetadataFromParent(ctx, container, lazy.Parent); err != nil {
				return err
			}
			target = absPath(container.Config.WorkingDir, lazy.Target)
			mount := ContainerMount{Target: target, Readonly: lazy.Readonly}
			if fileSource != nil {
				mount.FileSource = fileSource
			} else {
				if directorySource == nil {
					directorySource = new(LazyAccessor[*Directory, *Container])
				}
				mount.DirectorySource = directorySource
			}
			container.Mounts = container.Mounts.With(mount)
			container.ImageRef = ""
			return nil
		})
	case ContainerLazyGroupWrite:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedPathDockerfileCompat", group, func(ctx context.Context) error {
			cache, err := dagql.EngineCache(ctx)
			if err != nil {
				return err
			}
			if err := cache.Evaluate(ctx, lazy.Source); err != nil {
				return err
			}
			target := absPath(container.Config.WorkingDir, lazy.Target)
			mnt := container.mountAt(target)
			if mnt == nil {
				return fmt.Errorf("container withMountedPathDockerfileCompat: no mount at target %q", target)
			}
			sourcePath := cleanDockerfileCompatMountSourcePath(lazy.SourcePath)
			switch {
			case mnt.DirectorySource != nil:
				var detached *Directory
				if path.Clean(sourcePath) == "/" {
					detached, err = cloneDetachedDirectoryForContainerResult(ctx, lazy.Source.Self())
				} else {
					detached, err = detachedDirectoryAtSourcePath(ctx, lazy.Source, sourcePath)
				}
				if err != nil {
					return err
				}
				mnt.DirectorySource.SetValue(detached)
				return nil
			case mnt.FileSource != nil:
				if dockerfileCompatMountSourcePathHasDirHint(sourcePath) {
					return notADirectoryError{fmt.Errorf("path %s is a file, not a directory", sourcePath)}
				}
				detached, err := detachedFileAtSourcePath(ctx, lazy.Source, sourcePath)
				if err != nil {
					return err
				}
				mnt.FileSource.SetValue(detached)
				return nil
			default:
				return fmt.Errorf("container withMountedPathDockerfileCompat: mount at target %q has no snapshot source", target)
			}
		})
	default:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.withMountedPathDockerfileCompat", group, func(ctx context.Context) error {
			return delegateContainerPart(ctx, container, lazy.Parent, dagql.PartKey(group))
		})
	}
}

func (lazy *ContainerWithMountedPathDockerfileCompatLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withMountedPathDockerfileCompat parent")
	if err != nil {
		return nil, err
	}
	source, err := attachDirectoryResult(attach, lazy.Source, "attach container withMountedPathDockerfileCompat source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithMountedPathDockerfileCompatLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withMountedPathDockerfileCompat parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withMountedPathDockerfileCompat source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithMountedPathDockerfileCompatLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		SourceResultID: sourceID,
		SourcePath:     lazy.SourcePath,
		Readonly:       lazy.Readonly,
	})
}

func (lazy *ContainerWithMountedCacheLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithMountedCacheLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithMountedCacheLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withMountedCache", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.WithMountedCache(ctx, lazy.Target, lazy.Cache)
		return err
	})
}

func (lazy *ContainerWithMountedCacheLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withMountedCache parent")
	if err != nil {
		return nil, err
	}
	cacheVolume, err := attachCacheVolumeResult(attach, lazy.Cache, "attach container withMountedCache cache")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Cache = cacheVolume
	return []dagql.AnyResult{parent, cacheVolume}, nil
}

func (lazy *ContainerWithMountedCacheLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withMountedCache parent")
	if err != nil {
		return nil, err
	}
	cacheID, err := encodePersistedObjectRef(enc, lazy.Cache, "container withMountedCache cache")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithMountedCacheLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		CacheResultID:  cacheID,
	})
}

func (lazy *ContainerWithMountedVolumeLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithMountedVolumeLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithMountedVolumeLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withMountedVolume", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.WithMountedVolume(ctx, lazy.Target, lazy.Volume, lazy.Readonly)
		return err
	})
}

func (lazy *ContainerWithMountedVolumeLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withMountedVolume parent")
	if err != nil {
		return nil, err
	}
	volume, err := attachVolumeResult(attach, lazy.Volume, "attach container withMountedVolume volume")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Volume = volume
	return []dagql.AnyResult{parent, volume}, nil
}

func (lazy *ContainerWithMountedVolumeLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withMountedVolume parent")
	if err != nil {
		return nil, err
	}
	volumeID, err := encodePersistedObjectRef(enc, lazy.Volume, "container withMountedVolume volume")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithMountedVolumeLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		VolumeResultID: volumeID,
		Readonly:       lazy.Readonly,
	})
}

func (lazy *ContainerWithMountedTempLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithMountedTempLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithMountedTempLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withMountedTemp", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.WithMountedTemp(ctx, lazy.Target, lazy.Size)
		return err
	})
}

func (lazy *ContainerWithMountedTempLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withMountedTemp parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithMountedTempLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withMountedTemp parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithMountedTempLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		Size:           lazy.Size,
	})
}

func (lazy *ContainerWithMountedSecretLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithMountedSecretLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithMountedSecretLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withMountedSecret", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.WithMountedSecret(ctx, lazy.Parent, lazy.Target, lazy.Source, lazy.Owner, lazy.Mode)
		return err
	})
}

func (lazy *ContainerWithMountedSecretLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withMountedSecret parent")
	if err != nil {
		return nil, err
	}
	source, err := attachSecretResult(attach, lazy.Source, "attach container withMountedSecret source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithMountedSecretLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withMountedSecret parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withMountedSecret source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithMountedSecretLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		SourceResultID: sourceID,
		Owner:          lazy.Owner,
		Mode:           lazy.Mode,
	})
}

func (lazy *ContainerWithoutMountLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutMountLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutMountLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutMount", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.WithoutMount(ctx, lazy.Target)
		return err
	})
}

func (lazy *ContainerWithoutMountLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutMount parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutMountLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutMount parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutMountLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
	})
}

func (lazy *ContainerWithoutPathLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutPathLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return containerPathWriterGroups(ctr, []string{lazy.Path}, parts)
}

func (lazy *ContainerWithoutPathLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateContainerPathWriterGroup(
		ctx,
		container,
		&lazy.LazyState,
		lazy.Parent,
		group,
		"Container.withoutPath",
		[]string{lazy.Path},
		removableExactContainerMount,
		nil,
		func(ctx context.Context) error {
			_, err := container.WithoutPaths(ctx, lazy.Parent, lazy.Path)
			return err
		},
	)
}

func (lazy *ContainerWithoutPathLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutPath parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutPathLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutPath parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutPathLazy{
		ParentResultID: parentID,
		Path:           lazy.Path,
	})
}

func (lazy *ContainerWithSymlinkLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithSymlinkLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return containerPathWriterGroups(ctr, []string{lazy.LinkPath}, parts)
}

func (lazy *ContainerWithSymlinkLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateContainerPathWriterGroup(
		ctx,
		container,
		&lazy.LazyState,
		lazy.Parent,
		group,
		"Container.withSymlink",
		[]string{lazy.LinkPath},
		removableExactContainerMount,
		nil,
		func(ctx context.Context) error {
			_, err := container.WithSymlink(ctx, lazy.Parent, lazy.Target, lazy.LinkPath)
			return err
		},
	)
}

func (lazy *ContainerWithSymlinkLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withSymlink parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithSymlinkLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withSymlink parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithSymlinkLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		LinkPath:       lazy.LinkPath,
	})
}

func (lazy *ContainerWithUnixSocketLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithUnixSocketLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithUnixSocketLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withUnixSocket", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.WithUnixSocketFromParent(ctx, lazy.Parent, lazy.Target, lazy.Source, lazy.Owner)
		return err
	})
}

func (lazy *ContainerWithUnixSocketLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withUnixSocket parent")
	if err != nil {
		return nil, err
	}
	source, err := attachSocketResult(attach, lazy.Source, "attach container withUnixSocket source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerWithUnixSocketLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withUnixSocket parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container withUnixSocket source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithUnixSocketLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
		SourceResultID: sourceID,
		Owner:          lazy.Owner,
	})
}

func (lazy *ContainerWithoutUnixSocketLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

func (lazy *ContainerWithoutUnixSocketLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	return templateAContainerGroups(ctr, parts)
}

func (lazy *ContainerWithoutUnixSocketLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	return evaluateTemplateAContainerGroup(ctx, lazy, "Container.withoutUnixSocket", container, lazy.Parent, group, func(ctx context.Context) error {
		_, err := container.WithoutUnixSocket(ctx, lazy.Target)
		return err
	})
}

func (lazy *ContainerWithoutUnixSocketLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container withoutUnixSocket parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	return []dagql.AnyResult{parent}, nil
}

func (lazy *ContainerWithoutUnixSocketLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container withoutUnixSocket parent")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerWithoutUnixSocketLazy{
		ParentResultID: parentID,
		Target:         lazy.Target,
	})
}

func (lazy *ContainerImportLazy) Evaluate(ctx context.Context, container *Container) error {
	return lazy.LazyState.Evaluate(ctx, "Container.import", func(ctx context.Context) error {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return err
		}
		if err := cache.Evaluate(ctx, lazy.Parent, lazy.Source); err != nil {
			return err
		}
		if err := materializeContainerStateFromParent(ctx, container, lazy.Parent); err != nil {
			return err
		}
		r, err := lazy.Source.Self().Open(ctx, lazy.Source)
		if err != nil {
			return err
		}
		defer r.Close()
		_, err = container.Import(ctx, r, lazy.Tag)
		if err != nil {
			return err
		}
		return nil
	})
}

func (lazy *ContainerImportLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container import parent")
	if err != nil {
		return nil, err
	}
	source, err := attachFileResult(attach, lazy.Source, "attach container import source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *ContainerImportLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container import parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "container import source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerImportLazy{
		ParentResultID: parentID,
		SourceResultID: sourceID,
		Tag:            lazy.Tag,
	})
}

//nolint:gocyclo // intrinsically long state machine; refactoring would hurt clarity
func decodePersistedContainerRecipe(
	ctx context.Context,
	dec *dagql.PersistDecodeContext,
	call *dagql.ResultCall,
	payload json.RawMessage,
) (Lazy[*Container], error) {
	switch call.Field {
	case "_builtinContainer":
		return decodeContainerBuiltinLazy(payload)

	case "withEntrypoint":
		var persisted persistedContainerWithEntrypointLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withEntrypoint lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withEntrypoint parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithEntrypointLazy{
			LazyState:       NewLazyState(),
			Parent:          parent,
			Args:            persisted.Args,
			KeepDefaultArgs: persisted.KeepDefaultArgs,
		}, nil
	case "withoutEntrypoint":
		var persisted persistedContainerWithoutEntrypointLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutEntrypoint lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutEntrypoint parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutEntrypointLazy{
			LazyState:       NewLazyState(),
			Parent:          parent,
			KeepDefaultArgs: persisted.KeepDefaultArgs,
		}, nil
	case "withDefaultArgs":
		var persisted persistedContainerWithDefaultArgsLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withDefaultArgs lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withDefaultArgs parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithDefaultArgsLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Args:      persisted.Args,
		}, nil
	case "withoutDefaultArgs":
		var persisted persistedContainerWithoutDefaultArgsLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutDefaultArgs lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutDefaultArgs parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutDefaultArgsLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
		}, nil
	case "withUser":
		var persisted persistedContainerWithUserLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withUser lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withUser parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithUserLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
		}, nil
	case "withoutUser":
		var persisted persistedContainerWithoutUserLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutUser lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutUser parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutUserLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
		}, nil
	case "withWorkdir":
		var persisted persistedContainerWithWorkdirLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withWorkdir lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withWorkdir parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithWorkdirLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Path:      persisted.Path,
			Expand:    persisted.Expand,
		}, nil
	case "withoutWorkdir":
		var persisted persistedContainerWithoutWorkdirLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutWorkdir lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutWorkdir parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutWorkdirLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
		}, nil
	case "withEnvVariable":
		var persisted persistedContainerWithEnvVariableLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withEnvVariable lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withEnvVariable parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithEnvVariableLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
			Value:     persisted.Value,
			Expand:    persisted.Expand,
		}, nil
	case "withEnvFileVariables":
		var persisted persistedContainerWithEnvFileVariablesLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withEnvFileVariables lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withEnvFileVariables parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*EnvFile](ctx, dec, persisted.SourceResultID, "container withEnvFileVariables source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithEnvFileVariablesLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Source:    source,
		}, nil
	case "__withSystemEnvVariable":
		var persisted persistedContainerWithSystemEnvVariableLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withSystemEnvVariable lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withSystemEnvVariable parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithSystemEnvVariableLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
		}, nil
	case "withVolatileVariable":
		var persisted persistedContainerWithVolatileVariableLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withVolatileVariable lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withVolatileVariable parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithVolatileVariableLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
			Value:     persisted.Value,
		}, nil
	case "withoutEnvVariable":
		var persisted persistedContainerWithoutEnvVariableLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutEnvVariable lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutEnvVariable parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutEnvVariableLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
		}, nil
	case "withoutVolatileVariable":
		var persisted persistedContainerWithoutVolatileVariableLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutVolatileVariable lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutVolatileVariable parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutVolatileVariableLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
		}, nil
	case "withLabel":
		var persisted persistedContainerWithLabelLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withLabel lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withLabel parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithLabelLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
			Value:     persisted.Value,
		}, nil
	case "withoutLabel":
		var persisted persistedContainerWithoutLabelLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutLabel lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutLabel parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutLabelLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
		}, nil
	case "__withImageConfigMetadata":
		var persisted persistedContainerWithImageConfigMetadataLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withImageConfigMetadata lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withImageConfigMetadata parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithImageConfigMetadataLazy{
			LazyState:   NewLazyState(),
			Parent:      parent,
			Healthcheck: persisted.Healthcheck,
			OnBuild:     persisted.OnBuild,
			Shell:       persisted.Shell,
			Volumes:     persisted.Volumes,
			StopSignal:  persisted.StopSignal,
		}, nil
	case "withDockerHealthcheck":
		var persisted persistedContainerWithHealthcheckLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withHealthcheck lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withHealthcheck parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithHealthcheckLazy{
			LazyState:   NewLazyState(),
			Parent:      parent,
			Healthcheck: persisted.Healthcheck,
		}, nil
	case "withoutDockerHealthcheck":
		var persisted persistedContainerWithoutHealthcheckLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutHealthcheck lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutHealthcheck parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutHealthcheckLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
		}, nil
	case "withGPU", "experimentalWithGPU", "experimentalWithAllGPUs":
		var persisted persistedContainerSetGPUsLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container setGPUs lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container setGPUs parent")
		if err != nil {
			return nil, err
		}
		return &ContainerSetGPUsLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Devices:   persisted.Devices,
		}, nil
	case "withAnnotation":
		var persisted persistedContainerWithAnnotationLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withAnnotation lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withAnnotation parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithAnnotationLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
			Value:     persisted.Value,
		}, nil
	case "withoutAnnotation":
		var persisted persistedContainerWithoutAnnotationLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutAnnotation lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutAnnotation parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutAnnotationLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
		}, nil
	case "withSecretVariable":
		var persisted persistedContainerWithSecretVariableLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withSecretVariable lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withSecretVariable parent")
		if err != nil {
			return nil, err
		}
		secret, err := loadPersistedObjectResultByResultID[*Secret](ctx, dec, persisted.SecretResultID, "container withSecretVariable secret")
		if err != nil {
			return nil, err
		}
		return &ContainerWithSecretVariableLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
			Secret:    secret,
		}, nil
	case "withoutSecretVariable":
		var persisted persistedContainerWithoutSecretVariableLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutSecretVariable lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutSecretVariable parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutSecretVariableLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Name:      persisted.Name,
		}, nil
	case "withServiceBinding":
		var persisted persistedContainerWithServiceBindingLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withServiceBinding lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withServiceBinding parent")
		if err != nil {
			return nil, err
		}
		svc, err := loadPersistedObjectResultByResultID[*Service](ctx, dec, persisted.ServiceResultID, "container withServiceBinding service")
		if err != nil {
			return nil, err
		}
		return &ContainerWithServiceBindingLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Service:   svc,
			Alias:     persisted.Alias,
		}, nil
	case "withExposedPort":
		var persisted persistedContainerWithExposedPortLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withExposedPort lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withExposedPort parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithExposedPortLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Port:      persisted.Port,
		}, nil
	case "withoutExposedPort":
		var persisted persistedContainerWithoutExposedPortLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutExposedPort lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutExposedPort parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutExposedPortLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Port:      persisted.Port,
			Protocol:  persisted.Protocol,
		}, nil
	// withShell sets the same default terminal command, with batch arguments.
	case "withDefaultTerminalCmd", "withShell":
		var persisted persistedContainerWithDefaultTerminalCmdLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withDefaultTerminalCmd lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withDefaultTerminalCmd parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithDefaultTerminalCmdLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Opts:      persisted.Opts,
		}, nil
	case "from":
		var persisted persistedContainerFromLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container from lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container from parent")
		if err != nil {
			return nil, err
		}
		lazy := &ContainerFromImageRefLazy{
			Parent:            parent,
			LazyState:         NewLazyState(),
			CanonicalRef:      persisted.CanonicalRef,
			Config:            persisted.Config,
			ImageRef:          persisted.ImageRef,
			Platform:          persisted.Platform,
			ResolveMode:       serverresolver.ResolveModeDefault,
			RegistryTransport: persisted.RegistryTransport,
		}
		if len(persisted.RegistryServices) > 0 {
			services, err := decodePersistedServiceBindings(ctx, dec, "container from registry", persisted.RegistryServices)
			if err != nil {
				return nil, err
			}
			lazy.RegistryServices = services
		}
		return lazy, nil
	case "withRootfs":
		var persisted persistedContainerWithRootFSLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withRootfs lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withRootfs parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.SourceResultID, "container withRootfs source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithRootFSLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Source:    source,
		}, nil
	case "withDirectory":
		var persisted persistedContainerWithDirectoryLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withDirectory lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withDirectory parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.SourceResultID, "container withDirectory source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithDirectoryLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Path:      persisted.Path,
			Source:    source,
			Filter:    persisted.Filter,
			Owner:     persisted.Owner,
		}, nil
	case "withFile", "withNewFile":
		var persisted persistedContainerWithFileLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container %s lazy payload: %w", call.Field, err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container "+call.Field+" parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*File](ctx, dec, persisted.SourceResultID, "container "+call.Field+" source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithFileLazy{
			LazyState:   NewLazyState(),
			Parent:      parent,
			Path:        persisted.Path,
			Source:      source,
			Permissions: persisted.Permissions,
			Owner:       persisted.Owner,
		}, nil
	case "withMountedDirectory":
		var persisted persistedContainerWithMountedDirectoryLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withMountedDirectory lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withMountedDirectory parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.SourceResultID, "container withMountedDirectory source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithMountedDirectoryLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			Source:    source,
			Owner:     persisted.Owner,
			Readonly:  persisted.Readonly,
		}, nil
	case "withMountedFile":
		var persisted persistedContainerWithMountedFileLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withMountedFile lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withMountedFile parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*File](ctx, dec, persisted.SourceResultID, "container withMountedFile source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithMountedFileLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			Source:    source,
			Owner:     persisted.Owner,
			Readonly:  persisted.Readonly,
		}, nil
	case "__withMountedPathDockerfileCompat":
		var persisted persistedContainerWithMountedPathDockerfileCompatLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withMountedPathDockerfileCompat lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withMountedPathDockerfileCompat parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.SourceResultID, "container withMountedPathDockerfileCompat source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithMountedPathDockerfileCompatLazy{
			LazyState:  NewLazyState(),
			Parent:     parent,
			Target:     persisted.Target,
			Source:     source,
			SourcePath: persisted.SourcePath,
			Readonly:   persisted.Readonly,
		}, nil
	case "withMountedCache":
		var persisted persistedContainerWithMountedCacheLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withMountedCache lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withMountedCache parent")
		if err != nil {
			return nil, err
		}
		cacheVolume, err := loadPersistedObjectResultByResultID[*CacheVolume](ctx, dec, persisted.CacheResultID, "container withMountedCache cache")
		if err != nil {
			return nil, err
		}
		return &ContainerWithMountedCacheLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			Cache:     cacheVolume,
		}, nil
	case "withMountedVolume":
		var persisted persistedContainerWithMountedVolumeLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withMountedVolume lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withMountedVolume parent")
		if err != nil {
			return nil, err
		}
		volume, err := loadPersistedObjectResultByResultID[*Volume](ctx, dec, persisted.VolumeResultID, "container withMountedVolume volume")
		if err != nil {
			return nil, err
		}
		return &ContainerWithMountedVolumeLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			Volume:    volume,
			Readonly:  persisted.Readonly,
		}, nil
	case "withMountedTemp":
		var persisted persistedContainerWithMountedTempLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withMountedTemp lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withMountedTemp parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithMountedTempLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			Size:      persisted.Size,
		}, nil
	case "withMountedSecret":
		var persisted persistedContainerWithMountedSecretLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withMountedSecret lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withMountedSecret parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*Secret](ctx, dec, persisted.SourceResultID, "container withMountedSecret source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithMountedSecretLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			Source:    source,
			Owner:     persisted.Owner,
			Mode:      persisted.Mode,
		}, nil
	case "withoutMount":
		var persisted persistedContainerWithoutMountLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutMount lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutMount parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutMountLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
		}, nil
	case "withoutDirectory", "withoutFile", "withoutFiles":
		var persisted persistedContainerWithoutPathLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutPath lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutPath parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutPathLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Path:      persisted.Path,
		}, nil
	case "withSymlink":
		var persisted persistedContainerWithSymlinkLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withSymlink lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withSymlink parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithSymlinkLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			LinkPath:  persisted.LinkPath,
		}, nil
	case "withUnixSocket":
		var persisted persistedContainerWithUnixSocketLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withUnixSocket lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withUnixSocket parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*Socket](ctx, dec, persisted.SourceResultID, "container withUnixSocket source")
		if err != nil {
			return nil, err
		}
		return &ContainerWithUnixSocketLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
			Source:    source,
			Owner:     persisted.Owner,
		}, nil
	case "withoutUnixSocket":
		var persisted persistedContainerWithoutUnixSocketLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container withoutUnixSocket lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container withoutUnixSocket parent")
		if err != nil {
			return nil, err
		}
		return &ContainerWithoutUnixSocketLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Target:    persisted.Target,
		}, nil
	case "import":
		var persisted persistedContainerImportLazy
		if err := json.Unmarshal(payload, &persisted); err != nil {
			return nil, fmt.Errorf("decode persisted container import lazy payload: %w", err)
		}
		parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container import parent")
		if err != nil {
			return nil, err
		}
		source, err := loadPersistedObjectResultByResultID[*File](ctx, dec, persisted.SourceResultID, "container import source")
		if err != nil {
			return nil, err
		}
		return &ContainerImportLazy{
			LazyState: NewLazyState(),
			Parent:    parent,
			Source:    source,
			Tag:       persisted.Tag,
		}, nil
	case "withExec":
		return decodePersistedContainerExecLazy(ctx, dec, payload)
	default:
		return nil, fmt.Errorf("decode persisted container lazy payload: unsupported field %q", call.Field)
	}
}

func (mnts ContainerMounts) With(newMnt ContainerMount) ContainerMounts {
	mntsCp := make(ContainerMounts, 0, len(mnts))

	// NB: this / might need to change on Windows, but I'm not even sure how
	// mounts work on Windows, so...
	parent := newMnt.Target + "/"

	for _, mnt := range mnts {
		if mnt.Target == newMnt.Target || strings.HasPrefix(mnt.Target, parent) {
			continue
		}

		mntsCp = append(mntsCp, mnt)
	}

	mntsCp = append(mntsCp, newMnt)

	return mntsCp
}

func (mnts ContainerMounts) Replace(newMnt ContainerMount) (ContainerMounts, error) {
	mntsCp := make(ContainerMounts, 0, len(mnts))
	found := false
	for _, mnt := range mnts {
		if mnt.Target == newMnt.Target {
			mntsCp = append(mntsCp, newMnt)
			found = true
		} else {
			mntsCp = append(mntsCp, mnt)
		}
	}
	if !found {
		return nil, fmt.Errorf("failed to replace %s: %w", newMnt.Target, ErrMountNotExist)
	}
	return mntsCp, nil
}

func (container *Container) FromRefString(ctx context.Context, addr string) (dagql.ObjectResult[*Container], error) {
	refName, err := reference.ParseNormalizedNamed(addr)
	if err != nil {
		return dagql.ObjectResult[*Container]{}, fmt.Errorf("failed to parse image address %s: %w", addr, err)
	}

	// add a default :latest if no tag or digest, otherwise this is a no-op
	refName = reference.TagNameOnly(refName)

	var containerArgs []dagql.NamedInput
	if container.Platform.OS != "" {
		containerArgs = append(containerArgs, dagql.NamedInput{Name: "platform", Value: dagql.Opt(container.Platform)})
	}

	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return dagql.ObjectResult[*Container]{}, fmt.Errorf("failed to get Dagger server: %w", err)
	}
	// Desugar through the canonical server so entrypoint proxies on the
	// outer Query root cannot shadow the core container constructor.
	coreSrv := srv.Canonical()

	ctx, span := Tracer(ctx).Start(ctx, fmt.Sprintf("from %s", addr),
		telemetry.Internal(),
	)
	defer telemetry.EndWithCause(span, nil)

	var ctr dagql.ObjectResult[*Container]
	err = coreSrv.Select(ctx, coreSrv.Root(), &ctr,
		dagql.Selector{
			Field: "container",
			Args:  containerArgs,
		},
		dagql.Selector{
			Field: "from",
			Args: []dagql.NamedInput{
				{Name: "address", Value: dagql.String(refName.String())},
			},
		},
	)
	if err != nil {
		return dagql.ObjectResult[*Container]{}, err
	}

	return ctr, nil
}

// FromCanonicalRef resolves a digest-addressed image pull and updates only the
// rootfs snapshot state.
func (container *Container) FromCanonicalRef(
	ctx context.Context,
	refName reference.Canonical,
) error {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return err
	}

	platform := container.Platform
	refStr := refName.String()

	rslvr, err := query.RegistryResolver(ctx)
	if err != nil {
		return fmt.Errorf("failed to get registry resolver: %w", err)
	}
	network, detach, err := ContainerRegistryNetwork(ctx, container.Services)
	if err != nil {
		return err
	}
	defer detach()

	pulled, err := rslvr.Pull(ctx, refStr, serverresolver.PullOpts{
		Platform:    platform.Spec(),
		ResolveMode: serverresolver.ResolveModeDefault,
		Network:     network,
	})
	if err != nil {
		return fmt.Errorf("pull image %q: %w", refStr, err)
	}
	defer pulled.Release(context.WithoutCancel(ctx))

	ref, err := query.SnapshotManager().ImportImage(ctx, &bkcache.ImportedImage{
		Ref:          pulled.Ref,
		ManifestDesc: pulled.ManifestDesc,
		ConfigDesc:   pulled.ConfigDesc,
		Layers:       pulled.Layers,
		Nonlayers:    pulled.Nonlayers,
	}, bkcache.ImportImageOpts{
		ImageRef:   pulled.Ref,
		RecordType: bkclient.UsageRecordTypeRegular,
	})
	if err != nil {
		return fmt.Errorf("import image %q: %w", refStr, err)
	}

	if container.FS == nil {
		container.FS = new(LazyAccessor[*Directory, *Container])
	}
	rootfsDir := &Directory{
		Platform: container.Platform,
		Services: slices.Clone(container.Services),
		Dir:      new(LazyAccessor[string, *Directory]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
	}
	rootfsDir.SetPath("/")
	rootfsDir.SetSnapshot(ref)
	container.FS.setValue(rootfsDir)

	return nil
}

const defaultDockerfileName = "Dockerfile"

func isKnownDockerfileSyntaxFrontend(syntaxRef string) bool {
	ref := strings.TrimSpace(strings.ToLower(syntaxRef))
	if ref == "" {
		return false
	}

	known := []string{
		"docker/dockerfile",
		"docker/dockerfile-upstream",
		"docker.io/docker/dockerfile",
		"docker.io/docker/dockerfile-upstream",
		"index.docker.io/docker/dockerfile",
		"index.docker.io/docker/dockerfile-upstream",
		"moby/dockerfile",
		"moby/dockerfile-upstream",
		"docker.io/moby/dockerfile",
		"docker.io/moby/dockerfile-upstream",
		"index.docker.io/moby/dockerfile",
		"index.docker.io/moby/dockerfile-upstream",
	}
	for _, prefix := range known {
		if ref == prefix || strings.HasPrefix(ref, prefix+":") || strings.HasPrefix(ref, prefix+"@") {
			return true
		}
	}
	return false
}

func (container *Container) Build(
	ctx context.Context,
	dockerfileDir dagql.ObjectResult[*Directory],
	// contextDirID is dockerfileDir with files excluded as per dockerignore file,
	// expressed as a recipe-form ID so llbtodagger can append to it.
	contextDirID *call.ID,
	dockerfile string,
	buildArgs []BuildArg,
	target string,
	secrets []dagql.ObjectResult[*Secret],
	noInit bool,
	sshSocket dagql.ObjectResult[*Socket],
) (dagql.ObjectResult[*Container], error) {
	var zero dagql.ObjectResult[*Container]
	dockerfilePath := dockerfile
	if dockerfilePath == "" {
		dockerfilePath = defaultDockerfileName
	}
	dagqlCache, err := dagql.EngineCache(ctx)
	if err != nil {
		return zero, err
	}
	if err := dagqlCache.Evaluate(ctx, dockerfileDir); err != nil {
		return zero, fmt.Errorf("failed to evaluate Dockerfile directory: %w", err)
	}
	dockerfileRef, err := dockerfileDir.Self().Snapshot.GetOrEval(ctx, dockerfileDir.Result)
	if err != nil {
		return zero, fmt.Errorf("failed to get Dockerfile directory snapshot: %w", err)
	}
	if dockerfileRef == nil {
		return zero, fmt.Errorf("failed to load Dockerfile %q: directory is empty", dockerfilePath)
	}
	dockerfileSelector, err := dockerfileDir.Self().Dir.GetOrEval(ctx, dockerfileDir.Result)
	if err != nil {
		return zero, fmt.Errorf("failed to get Dockerfile directory selector: %w", err)
	}
	var dockerfileBytes []byte
	err = MountRef(ctx, dockerfileRef, func(root string, _ *mount.Mount) error {
		resolvedDockerfilePath, err := containerdfs.RootPath(root, path.Join(dockerfileSelector, dockerfilePath))
		if err != nil {
			return err
		}
		dockerfileBytes, err = os.ReadFile(resolvedDockerfilePath)
		if err != nil {
			return TrimErrPathPrefix(err, root)
		}
		return nil
	})
	if err != nil {
		return zero, fmt.Errorf("failed to read Dockerfile %q: %w", dockerfilePath, err)
	}
	if syntaxRef, _, _, ok := dockerfileparser.DetectSyntax(dockerfileBytes); ok && !isKnownDockerfileSyntaxFrontend(syntaxRef) {
		return zero, fmt.Errorf("dockerBuild syntax frontend %q is unsupported in hard-cutover path", syntaxRef)
	}
	mainContext := llbtodagger.DockerfileMainContextSentinelState()

	query, err := CurrentQuery(ctx)
	if err != nil {
		return zero, err
	}
	rslvr, err := query.RegistryResolver(ctx)
	if err != nil {
		return zero, fmt.Errorf("failed to get registry resolver: %w", err)
	}
	srv, err := query.Server.Server(ctx)
	if err != nil {
		return zero, fmt.Errorf("failed to get server: %w", err)
	}

	buildArgMap := make(map[string]string, len(buildArgs))
	for _, buildArg := range buildArgs {
		buildArgMap[buildArg.Name] = buildArg.Value
	}
	secretIDsByLLBID := make(map[string]*call.ID, len(secrets))
	returnedSecretMounts := make([]ContainerSecret, 0, len(secrets))
	for _, secret := range secrets {
		secretRecipeID, err := secret.RecipeID(ctx)
		if err != nil {
			return zero, fmt.Errorf("get dockerBuild secret recipe ID: %w", err)
		}
		secretName, err := secret.Self().Name(ctx)
		if err != nil {
			return zero, fmt.Errorf("get dockerBuild secret name: %w", err)
		}
		if secretName == "" {
			return zero, fmt.Errorf("secret has no name and cannot be referenced from Dockerfile secret id")
		}
		if existing, found := secretIDsByLLBID[secretName]; found {
			if existing.Digest() != secretRecipeID.Digest() {
				return zero, fmt.Errorf("multiple secrets provided for dockerBuild secret id %q", secretName)
			}
			continue
		}
		secretIDsByLLBID[secretName] = secretRecipeID
		returnedSecretMounts = append(returnedSecretMounts, ContainerSecret{
			Secret:    secret,
			MountPath: fmt.Sprintf("/run/secrets/%s", secretName),
		})
	}
	sshSocketIDsByLLBID := map[string]*call.ID{}
	if sshSocket.Self() != nil {
		sshSocketRecipeID, err := sshSocket.RecipeID(ctx)
		if err != nil {
			return zero, fmt.Errorf("get dockerBuild ssh socket recipe ID: %w", err)
		}
		sshSocketIDsByLLBID[""] = sshSocketRecipeID
	}

	convertOpt := dockerfile2llb.ConvertOpt{
		Config: dockerui.Config{
			BuildArgs: buildArgMap,
			Target:    target,
			// BuildPlatforms must be the engine's native platform, matching what
			// BuildKit's dockerui frontend does (see dockerui.Client.init). This is
			// what feeds the predefined BUILDPLATFORM/BUILDOS/BUILDARCH build args. If
			// left unset, buildPlatformOpt falls back to using the target platform as
			// the build platform, so BUILDPLATFORM would incorrectly track the target
			// (emulating $BUILDPLATFORM stages and diverging the cache key per target
			// platform instead of sharing it across them).
			BuildPlatforms: []specs.Platform{query.Platform().Spec()},
		},
		MainContext:    &mainContext,
		TargetPlatform: ptr(container.Platform.Spec()),
		MetaResolver:   dockerfileImageMetaResolver{resolver: rslvr},
	}

	st, img, _, _, err := dockerfile2llb.Dockerfile2LLB(ctx, dockerfileBytes, convertOpt)
	if err != nil {
		return zero, fmt.Errorf("failed to convert Dockerfile to LLB: %w", err)
	}
	def, err := st.Marshal(ctx, llb.Platform(container.Platform.Spec()))
	if err != nil {
		return zero, fmt.Errorf("failed to marshal Dockerfile LLB: %w", err)
	}
	containerID, err := llbtodagger.DefinitionToIDWithOptions(def.ToPB(), img, llbtodagger.DefinitionToIDOptions{
		MainContextDirectoryID: contextDirID,
		SecretIDsByLLBID:       secretIDsByLLBID,
		SSHSocketIDsByLLBID:    sshSocketIDsByLLBID,
		NoInit:                 noInit,
	})
	if err != nil {
		return zero, fmt.Errorf("failed to convert Dockerfile LLB to Dagger ID: %w", err)
	}
	// Return the converted container itself, so the result keeps its recipe.
	// The build still runs here, at the call.
	built, err := dagql.NewID[*Container](containerID).Load(ctx, srv)
	if err != nil {
		return zero, fmt.Errorf("failed to load container from converted ID: %w", err)
	}
	if err := dagqlCache.Evaluate(ctx, built); err != nil {
		return zero, fmt.Errorf("failed to clone built container state: %w", err)
	}
	return withDockerBuildSecretMounts(ctx, srv, built, returnedSecretMounts)
}

// withDockerBuildSecretMounts mounts the build's secrets on its result. Mode 0
// and no owner keep each mount exactly as the build declares it.
func withDockerBuildSecretMounts(ctx context.Context, srv *dagql.Server, built dagql.ObjectResult[*Container], mounts []ContainerSecret) (dagql.ObjectResult[*Container], error) {
	for _, mount := range mounts {
		secretID, err := mount.Secret.ID()
		if err != nil {
			return dagql.ObjectResult[*Container]{}, fmt.Errorf("get dockerBuild secret ID: %w", err)
		}
		if err := srv.Select(ctx, built, &built, dagql.Selector{Field: "withMountedSecret", Args: []dagql.NamedInput{
			{Name: "path", Value: dagql.String(mount.MountPath)},
			{Name: "source", Value: dagql.NewID[*Secret](secretID)},
			{Name: "mode", Value: dagql.Int(0)},
		}}); err != nil {
			return dagql.ObjectResult[*Container]{}, fmt.Errorf("mount dockerBuild secret %q: %w", mount.MountPath, err)
		}
	}
	return built, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithRootFS(ctx context.Context, dir dagql.ObjectResult[*Directory]) (*Container, error) {
	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, dir); err != nil {
		return nil, err
	}
	detached, err := cloneDetachedDirectoryForContainerResult(ctx, dir.Self())
	if err != nil {
		return nil, err
	}
	if container.FS == nil {
		container.FS = new(LazyAccessor[*Directory, *Container])
	}
	container.FS.setValue(detached)
	container.ImageRef = ""
	return container, nil
}

func (container *Container) ensureRootFS(ctx context.Context) error {
	if container.FS == nil {
		container.FS = new(LazyAccessor[*Directory, *Container])
	}
	if _, ok := container.FS.Peek(); ok {
		return nil
	}

	scratchDir, scratchSnapshot, err := loadCanonicalScratchDirectory(ctx)
	if err != nil {
		return err
	}
	rootfs := &Directory{
		Platform: container.Platform,
		Services: slices.Clone(container.Services),
		Dir:      new(LazyAccessor[string, *Directory]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
	}
	rootfs.SetPath(scratchDir)
	rootfs.SetSnapshot(scratchSnapshot)
	container.FS.setValue(rootfs)
	return nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithDirectory(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	subdir string,
	src dagql.ObjectResult[*Directory],
	filter CopyFilter,
	owner string,
) (*Container, error) {
	mnt, mntSubpath, err := locatePath(container, subdir)
	if err != nil {
		return nil, fmt.Errorf("failed to locate path %s: %w", subdir, err)
	}

	// if the path being overwritten is an exact mount point for a file, then we need to unmount it
	// and then overwrite the source that exists below it (including unmounting any mounts below it)
	if mnt != nil && mnt.FileSource != nil && (mntSubpath == "/" || mntSubpath == "" || mntSubpath == ".") {
		container, err = container.WithoutMount(ctx, mnt.Target)
		if err != nil {
			return nil, fmt.Errorf("failed to unmount %s: %w", mnt.Target, err)
		}
		return container.WithDirectory(ctx, parent, subdir, src, filter, owner)
	}

	resolvedOwner := owner
	if owner != "" {
		ownership, err := container.ownership(ctx, parent, owner)
		if err != nil {
			return nil, fmt.Errorf("failed to resolve ownership for %s: %w", owner, err)
		}
		resolvedOwner = strconv.Itoa(ownership.UID) + ":" + strconv.Itoa(ownership.GID)
	}

	if mnt == nil {
		if err := container.ensureRootFS(ctx); err != nil {
			return nil, err
		}
	}

	targetParent, err := targetParentDirectoryForContainerPath(ctx, parent, container, subdir)
	if err != nil {
		return nil, err
	}
	dir, err := bareDirectoryForContainerPath(container, subdir)
	if err != nil {
		return nil, err
	}
	container.recordPartDiagnostic("writerBody", "")
	if err := dir.withDirectory(ctx, targetParent, mntSubpath, src, filter, resolvedOwner, nil, container.directoryCommitObserver()); err != nil {
		return nil, err
	}
	container.ImageRef = ""
	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithFile(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	destPath string,
	src dagql.ObjectResult[*File],
	permissions *int,
	owner string,
) (*Container, error) {
	mnt, mntSubpath, err := locatePath(container, destPath)
	if err != nil {
		return nil, fmt.Errorf("failed to locate path %s: %w", destPath, err)
	}

	// if the path being overwritten is an exact mount point, then we need to unmount
	// it and then overwrite the source that exists below it (including unmounting any mounts below it)
	if mnt != nil && (mntSubpath == "/" || mntSubpath == "" || mntSubpath == ".") {
		container, err = container.WithoutMount(ctx, mnt.Target)
		if err != nil {
			return nil, fmt.Errorf("failed to unmount %s: %w", mnt.Target, err)
		}
		return container.WithFile(ctx, parent, destPath, src, permissions, owner)
	}

	resolvedOwner := owner
	if owner != "" {
		ownership, err := container.ownership(ctx, parent, owner)
		if err != nil {
			return nil, fmt.Errorf("failed to resolve ownership for %s: %w", owner, err)
		}
		resolvedOwner = strconv.Itoa(ownership.UID) + ":" + strconv.Itoa(ownership.GID)
	}

	if mnt == nil {
		if container.FS == nil {
			container.FS = new(LazyAccessor[*Directory, *Container])
		}
		if _, ok := container.FS.Peek(); !ok {
			scratchDir, scratchSnapshot, err := loadCanonicalScratchDirectory(ctx)
			if err != nil {
				return nil, err
			}
			rootfs := &Directory{
				Platform: container.Platform,
				Services: slices.Clone(container.Services),
				Dir:      new(LazyAccessor[string, *Directory]),
				Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
			}
			rootfs.SetPath(scratchDir)
			rootfs.SetSnapshot(scratchSnapshot)
			container.FS.setValue(rootfs)
		}
	}

	targetParent, err := targetParentDirectoryForContainerPath(ctx, parent, container, destPath)
	if err != nil {
		return nil, err
	}
	dir, err := bareDirectoryForContainerPath(container, destPath)
	if err != nil {
		return nil, err
	}
	if err := dir.WithFile(ctx, targetParent, mntSubpath, src, permissions, resolvedOwner, false, false); err != nil {
		return nil, err
	}
	container.ImageRef = ""
	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithoutPaths(ctx context.Context, parent dagql.ObjectResult[*Container], destPaths ...string) (*Container, error) {
	for _, destPath := range destPaths {
		var err error
		container, err = container.withoutPath(ctx, parent, destPath)
		if err != nil {
			return nil, fmt.Errorf("failed to remove path %q: %w", destPath, err)
		}
	}
	return container, nil
}

// assumes that container is already cloned by caller
func (container *Container) withoutPath(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	destPath string,
) (*Container, error) {
	mnt, mntSubpath, err := locatePath(container, destPath)
	if err != nil {
		return nil, fmt.Errorf("failed to locate path %s: %w", destPath, err)
	}

	// if the path being removed is an exact mount point, then we need to unmount it and then
	// (recursively) remove the source that exists below it (including unmounting any mounts below it)
	if mnt != nil && (mntSubpath == "/" || mntSubpath == "" || mntSubpath == ".") {
		container, err = container.WithoutMount(ctx, mnt.Target)
		if err != nil {
			return nil, fmt.Errorf("failed to unmount %s: %w", mnt.Target, err)
		}
		return container.withoutPath(ctx, parent, destPath)
	}

	if mnt == nil {
		if container.FS == nil {
			return container, nil
		}
		if _, ok := container.FS.Peek(); !ok {
			return container, nil
		}
	}

	targetParent, err := targetParentDirectoryForContainerPath(ctx, parent, container, destPath)
	if err != nil {
		return nil, err
	}
	dir, err := bareDirectoryForContainerPath(container, destPath)
	if err != nil {
		return nil, err
	}
	if err := dir.Without(ctx, targetParent, dagql.CurrentCall(ctx), false, mntSubpath); err != nil {
		return nil, err
	}
	container.ImageRef = ""
	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithFiles(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	destDir string,
	src []dagql.ObjectResult[*File],
	permissions *int,
	owner string,
) (*Container, error) {
	for _, file := range src {
		filePath, err := file.Self().File.GetOrEval(ctx, file.Result)
		if err != nil {
			return nil, fmt.Errorf("failed to get source file path: %w", err)
		}
		destPath := filepath.Join(destDir, filepath.Base(filePath))
		container, err = container.WithFile(ctx, parent, destPath, file, permissions, owner)
		if err != nil {
			return nil, fmt.Errorf("failed to add file %s: %w", destPath, err)
		}
	}

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithNewFile(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	dest string,
	content []byte,
	permissions fs.FileMode,
	owner string,
) (*Container, error) {
	_, fileName := filepath.Split(filepath.Clean(dest))

	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}

	var newFile dagql.ObjectResult[*File]
	args := []dagql.NamedInput{
		{Name: "name", Value: dagql.String(fileName)},
		{Name: "contents", Value: dagql.String(string(content))},
	}
	if permissions != 0 {
		args = append(args, dagql.NamedInput{Name: "permissions", Value: dagql.Opt(dagql.Int(int(permissions)))})
	}
	err = srv.Select(ctx, srv.Root(), &newFile, dagql.Selector{
		Field: "file",
		Args:  args,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create new file %s: %w", dest, err)
	}

	return container.WithFile(ctx, parent, dest, newFile, nil, owner)
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithSymlink(ctx context.Context, parent dagql.ObjectResult[*Container], target, linkPath string) (*Container, error) {
	mnt, mntSubpath, err := locatePath(container, linkPath)
	if err != nil {
		return nil, fmt.Errorf("failed to locate path %s: %w", linkPath, err)
	}

	// if the path being overwritten is an exact mount point, then we need to unmount it and then overwrite the source that exists below it (including unmounting any mounts below it)
	if mnt != nil && (mntSubpath == "/" || mntSubpath == "" || mntSubpath == ".") {
		container, err = container.WithoutMount(ctx, mnt.Target)
		if err != nil {
			return nil, fmt.Errorf("failed to unmount %s: %w", mnt.Target, err)
		}
		return container.WithSymlink(ctx, parent, target, linkPath)
	}

	if mnt == nil {
		if container.FS == nil {
			container.FS = new(LazyAccessor[*Directory, *Container])
		}
		if _, ok := container.FS.Peek(); !ok {
			scratchDir, scratchSnapshot, err := loadCanonicalScratchDirectory(ctx)
			if err != nil {
				return nil, err
			}
			rootfs := &Directory{
				Platform: container.Platform,
				Services: slices.Clone(container.Services),
				Dir:      new(LazyAccessor[string, *Directory]),
				Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
			}
			rootfs.SetPath(scratchDir)
			rootfs.SetSnapshot(scratchSnapshot)
			container.FS.setValue(rootfs)
		}
	}

	targetParent, err := targetParentDirectoryForContainerPath(ctx, parent, container, linkPath)
	if err != nil {
		return nil, err
	}
	dir, err := bareDirectoryForContainerPath(container, linkPath)
	if err != nil {
		return nil, err
	}
	if err := dir.WithSymlink(ctx, targetParent, target, mntSubpath); err != nil {
		return nil, err
	}
	container.ImageRef = ""
	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
//
//nolint:dupl // symmetric with WithMountedFile; sharing would hide type specifics
func (container *Container) WithMountedDirectory(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	target string,
	dir dagql.ObjectResult[*Directory],
	owner string,
	readonly bool,
) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	var err error
	if owner != "" {
		dir, err = container.chownDir(ctx, parent, dir, owner)
		if err != nil {
			return nil, err
		}
	}

	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, dir); err != nil {
		return nil, err
	}
	detached, err := cloneDetachedDirectoryForContainerResult(ctx, dir.Self())
	if err != nil {
		return nil, err
	}
	source := new(LazyAccessor[*Directory, *Container])
	source.setValue(detached)

	container.Mounts = container.Mounts.With(ContainerMount{
		DirectorySource: source,
		Target:          target,
		Readonly:        readonly,
	})

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
//
//nolint:dupl // symmetric with WithMountedDirectory; sharing would hide type specifics
func (container *Container) WithMountedFile(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	target string,
	file dagql.ObjectResult[*File],
	owner string,
	readonly bool,
) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	var err error
	if owner != "" {
		file, err = container.chownFile(ctx, parent, file, owner)
		if err != nil {
			return nil, err
		}
	}

	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, file); err != nil {
		return nil, err
	}
	detached, err := cloneDetachedFileForContainerResult(ctx, file.Self())
	if err != nil {
		return nil, err
	}
	source := new(LazyAccessor[*File, *Container])
	source.setValue(detached)

	container.Mounts = container.Mounts.With(ContainerMount{
		FileSource: source,
		Target:     target,
		Readonly:   readonly,
	})

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithMountedPathDockerfileCompat(
	ctx context.Context,
	target string,
	source dagql.ObjectResult[*Directory],
	sourcePath string,
	readonly bool,
) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)
	sourcePath = cleanDockerfileCompatMountSourcePath(sourcePath)

	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, source); err != nil {
		return nil, err
	}

	var srv *dagql.Server
	if path.Clean(sourcePath) != "/" {
		query, err := CurrentQuery(ctx)
		if err != nil {
			return nil, err
		}
		srv, err = query.Server.Server(ctx)
		if err != nil {
			return nil, err
		}
	}
	sourceIsFile, err := DockerfileCompatMountSourceIsFile(ctx, source, srv, sourcePath)
	if err != nil {
		return nil, err
	}

	if !sourceIsFile {
		var sourceDir *Directory
		if path.Clean(sourcePath) == "/" {
			sourceDir, err = cloneDetachedDirectoryForContainerResult(ctx, source.Self())
		} else {
			sourceDir, err = detachedDirectoryAtSourcePath(ctx, source, sourcePath)
		}
		if err != nil {
			return nil, err
		}
		mountSource := new(LazyAccessor[*Directory, *Container])
		mountSource.setValue(sourceDir)
		container.Mounts = container.Mounts.With(ContainerMount{
			DirectorySource: mountSource,
			Target:          target,
			Readonly:        readonly,
		})
		container.ImageRef = ""
		return container, nil
	}
	if dockerfileCompatMountSourcePathHasDirHint(sourcePath) {
		return nil, notADirectoryError{fmt.Errorf("path %s is a file, not a directory", sourcePath)}
	}

	sourceFile, err := detachedFileAtSourcePath(ctx, source, sourcePath)
	if err != nil {
		return nil, err
	}
	mountSource := new(LazyAccessor[*File, *Container])
	mountSource.setValue(sourceFile)
	container.Mounts = container.Mounts.With(ContainerMount{
		FileSource: mountSource,
		Target:     target,
		Readonly:   readonly,
	})
	container.ImageRef = ""
	return container, nil
}

// DockerfileCompatMountSourceIsFile decides which accessor kind a bind mount
// needs. It uses the same normalized source path as materialization.
func DockerfileCompatMountSourceIsFile(
	ctx context.Context,
	source dagql.ObjectResult[*Directory],
	srv *dagql.Server,
	sourcePath string,
) (bool, error) {
	if source.Self() == nil {
		return false, fmt.Errorf("dockerfile bind mount source is nil")
	}
	return dockerfileCompatMountSourceIsFile(sourcePath, func(sourcePath string) (FileType, error) {
		stat, err := source.Self().Stat(ctx, source, srv, sourcePath, false)
		if err != nil {
			return "", err
		}
		return stat.FileType, nil
	})
}

func dockerfileCompatMountSourceIsFile(sourcePath string, stat func(string) (FileType, error)) (bool, error) {
	sourcePath = cleanDockerfileCompatMountSourcePath(sourcePath)
	if path.Clean(sourcePath) == "/" {
		return false, nil
	}
	fileType, err := stat(sourcePath)
	if err != nil {
		return false, err
	}
	return fileType != FileTypeDirectory, nil
}

func cleanDockerfileCompatMountSourcePath(sourcePath string) string {
	if sourcePath == "" {
		return "/"
	}
	trailingSlash := dockerfileCompatMountSourcePathHasDirHint(sourcePath)
	sourcePath = path.Clean(sourcePath)
	if !strings.HasPrefix(sourcePath, "/") {
		sourcePath = "/" + sourcePath
	}
	if trailingSlash && !strings.HasSuffix(sourcePath, "/") {
		sourcePath += "/"
	}
	return sourcePath
}

func dockerfileCompatMountSourcePathHasDirHint(sourcePath string) bool {
	return strings.HasSuffix(sourcePath, "/") || strings.HasSuffix(sourcePath, "/.")
}

//nolint:dupl // symmetric with detachedFileAtSourcePath; sharing hides Directory vs File specifics
func detachedDirectoryAtSourcePath(ctx context.Context, source dagql.ObjectResult[*Directory], sourcePath string) (*Directory, error) {
	sourceDirPath, err := source.Self().Dir.GetOrEval(ctx, source.Result)
	if err != nil {
		return nil, fmt.Errorf("failed to get source directory path: %w", err)
	}
	sourceSnapshot, err := source.Self().Snapshot.GetOrEval(ctx, source.Result)
	if err != nil {
		return nil, fmt.Errorf("failed to get source directory snapshot: %w", err)
	}
	if sourceSnapshot == nil {
		return nil, fmt.Errorf("source directory snapshot is nil")
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, sourceSnapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
	if err != nil {
		return nil, err
	}

	dir := &Directory{
		Platform: source.Self().Platform,
		Services: slices.Clone(source.Self().Services),
		Dir:      new(LazyAccessor[string, *Directory]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
	}
	dir.SetPath(path.Join(sourceDirPath, sourcePath))
	dir.SetSnapshot(reopened)
	return dir, nil
}

//nolint:dupl // symmetric with detachedDirectoryAtSourcePath; sharing hides File vs Directory specifics
func detachedFileAtSourcePath(ctx context.Context, source dagql.ObjectResult[*Directory], sourcePath string) (*File, error) {
	sourceDirPath, err := source.Self().Dir.GetOrEval(ctx, source.Result)
	if err != nil {
		return nil, fmt.Errorf("failed to get source directory path: %w", err)
	}
	sourceSnapshot, err := source.Self().Snapshot.GetOrEval(ctx, source.Result)
	if err != nil {
		return nil, fmt.Errorf("failed to get source directory snapshot: %w", err)
	}
	if sourceSnapshot == nil {
		return nil, fmt.Errorf("source directory snapshot is nil")
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	reopened, err := query.SnapshotManager().GetBySnapshotID(ctx, sourceSnapshot.SnapshotID(), bkcache.NoUpdateLastUsed)
	if err != nil {
		return nil, err
	}

	file := &File{
		Platform: source.Self().Platform,
		Services: slices.Clone(source.Self().Services),
		File:     new(LazyAccessor[string, *File]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
	}
	file.SetPath(path.Join(sourceDirPath, sourcePath))
	file.SetSnapshot(reopened)
	return file, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithMountedCache(
	ctx context.Context,
	target string,
	cache dagql.ObjectResult[*CacheVolume],
) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	cacheSelf := cache.Self()
	if cacheSelf == nil {
		return nil, errors.New("cache volume is nil")
	}
	if err := EnsureBackingSnapshot(ctx, cache); err != nil {
		return nil, fmt.Errorf("initialize cache volume snapshot: %w", err)
	}

	mount := ContainerMount{
		Target: target,
		CacheSource: &CacheMountSource{
			Volume: cache,
		},
	}
	container.Mounts = container.Mounts.With(mount)

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithMountedVolume(
	_ context.Context,
	target string,
	volume dagql.ObjectResult[*Volume],
	readonly bool,
) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	if volume.Self() == nil {
		return nil, errors.New("volume is nil")
	}

	container.Mounts = container.Mounts.With(ContainerMount{
		Target:   target,
		Readonly: readonly,
		VolumeSource: &VolumeMountSource{
			Volume: volume,
		},
	})

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithMountedTemp(ctx context.Context, target string, size int) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	container.Mounts = container.Mounts.With(ContainerMount{
		Target: target,
		TmpfsSource: &TmpfsMountSource{
			Size: size,
		},
	})

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithMountedSecret(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	target string,
	source dagql.ObjectResult[*Secret],
	owner string,
	mode fs.FileMode,
) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	ownership, err := container.ownership(ctx, parent, owner)
	if err != nil {
		return nil, err
	}

	container.Secrets = append(container.Secrets, ContainerSecret{
		Secret:    source,
		MountPath: target,
		Owner:     ownership,
		Mode:      mode,
	})

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithoutMount(ctx context.Context, target string) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	var found bool
	var foundIdx int
	for i := len(container.Mounts) - 1; i >= 0; i-- {
		if container.Mounts[i].Target == target {
			found = true
			foundIdx = i
			break
		}
	}

	if found {
		container.Mounts = slices.Delete(container.Mounts, foundIdx, foundIdx+1)
	}

	var secretFound bool
	var secretFoundIdx int
	for i := len(container.Secrets) - 1; i >= 0; i-- {
		if container.Secrets[i].MountPath == target {
			secretFound = true
			secretFoundIdx = i
			break
		}
	}

	if secretFound {
		container.Secrets = slices.Delete(container.Secrets, secretFoundIdx, secretFoundIdx+1)
	}

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

func (container *Container) MountTargets(ctx context.Context) ([]string, error) {
	mounts := []string{}
	for _, mnt := range container.Mounts {
		mounts = append(mounts, mnt.Target)
	}

	return mounts, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithUnixSocket(ctx context.Context, target string, source dagql.ObjectResult[*Socket], owner string) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)
	return container.WithUnixSocketFromParent(ctx, dagql.ObjectResult[*Container]{}, target, source, owner)
}

func (container *Container) WithUnixSocketFromParent(ctx context.Context, parent dagql.ObjectResult[*Container], target string, source dagql.ObjectResult[*Socket], owner string) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	ownership, err := container.ownership(ctx, parent, owner)
	if err != nil {
		return nil, err
	}

	newSocket := ContainerSocket{
		Source:        source,
		ContainerPath: target,
		Owner:         ownership,
	}

	var replaced bool
	for i, sock := range container.Sockets {
		if sock.ContainerPath == target {
			container.Sockets[i] = newSocket
			replaced = true
			break
		}
	}

	if !replaced {
		container.Sockets = append(container.Sockets, newSocket)
	}

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithoutUnixSocket(ctx context.Context, target string) (*Container, error) {
	target = absPath(container.Config.WorkingDir, target)

	for i, sock := range container.Sockets {
		if sock.ContainerPath == target {
			container.Sockets = slices.Delete(container.Sockets, i, i+1)
			break
		}
	}

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithSecretVariable(
	ctx context.Context,
	name string,
	secret dagql.ObjectResult[*Secret],
) (*Container, error) {
	newSecret := ContainerSecret{
		Secret:  secret,
		EnvName: name,
	}

	var replaced bool
	for i, existing := range container.Secrets {
		if existing.EnvName == name {
			container.Secrets[i] = newSecret
			replaced = true
			break
		}
	}

	if !replaced {
		container.Secrets = append(container.Secrets, newSecret)
	}

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithVolatileVariable(name string, value string) *Container {
	container.VolatileEnv = AddEnv(container.VolatileEnv, name, value)

	// set image ref to empty string
	container.ImageRef = ""

	return container
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithoutVolatileVariable(name string) *Container {
	newEnv := []string{}
	WalkEnv(container.VolatileEnv, func(k, _, env string) {
		if k != name {
			newEnv = append(newEnv, env)
		}
	})
	container.VolatileEnv = newEnv

	// set image ref to empty string
	container.ImageRef = ""

	return container
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithoutSecretVariable(ctx context.Context, name string) (*Container, error) {
	for i, secret := range container.Secrets {
		if secret.EnvName == name {
			container.Secrets = slices.Delete(container.Secrets, i, i+1)
			break
		}
	}

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// locatePath finds the mount that contains the given container path. It returns
// the mount and the subpath of containerPath relative to the mountpoint.
func locatePath(
	container *Container,
	containerPath string,
) (*ContainerMount, string, error) {
	containerPath = absPath(container.Config.WorkingDir, containerPath)

	// NB(vito): iterate in reverse order so we'll find deeper mounts first
	for i := len(container.Mounts) - 1; i >= 0; i-- {
		mnt := container.Mounts[i]

		if containerPath == mnt.Target || strings.HasPrefix(containerPath, mnt.Target+"/") {
			if mnt.TmpfsSource != nil {
				return nil, "", fmt.Errorf("%s: cannot retrieve path from tmpfs", containerPath)
			}

			if mnt.CacheSource != nil {
				return nil, "", fmt.Errorf("%s: cannot retrieve path from cache", containerPath)
			}

			relPath, err := filepath.Rel(mnt.Target, containerPath)
			if err != nil {
				return nil, "", err
			}
			return &mnt, relPath, nil
		}
	}

	// Not found in a mount
	return nil, containerPath, nil
}

func (container *Container) chownDir(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	src dagql.ObjectResult[*Directory],
	owner string,
) (res dagql.ObjectResult[*Directory], err error) {
	ownership, err := container.ownership(ctx, parent, owner)
	if err != nil {
		return res, err
	}

	if ownership == nil {
		return src, nil
	}

	// Directory.chown only knows uid/gid ints, provide those
	owner = strconv.Itoa(ownership.UID) + ":" + strconv.Itoa(ownership.GID)

	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return res, fmt.Errorf("failed to get dagql server: %w", err)
	}

	err = srv.Select(ctx, src, &res, dagql.Selector{
		Field: "chown",
		Args: []dagql.NamedInput{
			{Name: "path", Value: dagql.String(".")},
			{Name: "owner", Value: dagql.String(owner)},
		},
	})
	if err != nil {
		return res, fmt.Errorf("failed to chown directory: %w", err)
	}

	return res, nil
}

func (container *Container) chownFile(
	ctx context.Context,
	parent dagql.ObjectResult[*Container],
	src dagql.ObjectResult[*File],
	owner string,
) (res dagql.ObjectResult[*File], err error) {
	ownership, err := container.ownership(ctx, parent, owner)
	if err != nil {
		return res, err
	}

	if ownership == nil {
		return src, nil
	}

	// File.chown only knows uid/gid ints, provide those
	owner = strconv.Itoa(ownership.UID) + ":" + strconv.Itoa(ownership.GID)

	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return res, fmt.Errorf("failed to get dagql server: %w", err)
	}

	err = srv.Select(ctx, src, &res, dagql.Selector{
		Field: "chown",
		Args: []dagql.NamedInput{
			{Name: "owner", Value: dagql.String(owner)},
		},
	})
	if err != nil {
		return res, fmt.Errorf("failed to chown file: %w", err)
	}

	return res, nil
}

func (container *Container) ImageConfig(ctx context.Context) (dockerspec.DockerOCIImageConfig, error) {
	return container.Config, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) UpdateImageConfig(ctx context.Context, updateFn func(dockerspec.DockerOCIImageConfig) dockerspec.DockerOCIImageConfig) (*Container, error) {
	container.Config = updateFn(container.Config)
	container.ImageRef = ""
	return container, nil
}

type ContainerGPUOpts struct {
	Devices []string
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithGPU(ctx context.Context, gpuOpts ContainerGPUOpts) (*Container, error) {
	container.EnabledGPUs = gpuOpts.Devices
	return container, nil
}

func (container *Container) Exists(ctx context.Context, parent dagql.ObjectResult[*Container], srv *dagql.Server, targetPath string, targetType ExistsType, doNotFollowSymlinks bool) (bool, error) {
	mnt, mntSubpath, err := locatePath(container, targetPath)
	if err != nil {
		return false, fmt.Errorf("failed to locate path %s: %w", targetPath, err)
	}

	args := []dagql.NamedInput{
		{Name: "path", Value: dagql.String(mntSubpath)},
	}
	if targetType != "" {
		args = append(args, dagql.NamedInput{Name: "expectedType", Value: dagql.Opt[ExistsType](targetType)})
	}
	if doNotFollowSymlinks {
		args = append(args, dagql.NamedInput{Name: "doNotFollowSymlinks", Value: dagql.Opt[dagql.Boolean](dagql.Boolean(doNotFollowSymlinks))})
	}

	var exists bool
	switch {
	case mnt == nil: // rootfs
		var rootfs dagql.ObjectResult[*Directory]
		err := srv.Select(ctx, parent, &rootfs, dagql.Selector{Field: "rootfs"})
		if err != nil {
			return false, err
		}
		err = srv.Select(ctx, rootfs, &exists, dagql.Selector{
			Field: "exists",
			Args:  args,
		})
		if err != nil {
			return false, err
		}

	case mnt.DirectorySource != nil: // directory mount
		var parentDir dagql.ObjectResult[*Directory]
		err := srv.Select(ctx, parent, &parentDir, dagql.Selector{
			Field: "directory",
			Args: []dagql.NamedInput{
				{Name: "path", Value: dagql.String(mnt.Target)},
			},
		})
		if err != nil {
			return false, err
		}
		err = srv.Select(ctx, parentDir, &exists, dagql.Selector{
			Field: "exists",
			Args:  args,
		})
		if err != nil {
			return false, err
		}

	case mnt.FileSource != nil: // file mount
		if mntSubpath != "" && mntSubpath != "." {
			return false, nil
		}
		var fileRes dagql.ObjectResult[*File]
		if err := srv.Select(ctx, parent, &fileRes, dagql.Selector{
			Field: "file",
			Args: []dagql.NamedInput{
				{Name: "path", Value: dagql.String(mnt.Target)},
			},
		}); err != nil {
			return false, err
		}
		var stat *Stat
		if err := srv.Select(ctx, fileRes, &stat, dagql.Selector{Field: "stat"}); err != nil {
			return false, err
		}
		if stat == nil {
			return false, nil
		}
		if targetType == "" {
			return true, nil
		}
		return targetType == ExistsTypeRegular && stat.FileType == FileTypeRegular, nil

	default:
		return false, fmt.Errorf("invalid mount source for %s", targetPath)
	}

	return exists, nil
}

func (container *Container) Stat(ctx context.Context, parent dagql.ObjectResult[*Container], srv *dagql.Server, targetPath string, doNotFollowSymlinks bool) (*Stat, error) {
	mnt, mntSubpath, err := locatePath(container, targetPath)
	if err != nil {
		return nil, fmt.Errorf("failed to locate path %s: %w", targetPath, err)
	}

	args := []dagql.NamedInput{
		{Name: "path", Value: dagql.String(mntSubpath)},
	}
	if doNotFollowSymlinks {
		args = append(args, dagql.NamedInput{Name: "doNotFollowSymlinks", Value: dagql.Opt[dagql.Boolean](dagql.Boolean(doNotFollowSymlinks))})
	}

	var stat *Stat
	switch {
	case mnt == nil: // rootfs
		var rootfs dagql.ObjectResult[*Directory]
		err := srv.Select(ctx, parent, &rootfs, dagql.Selector{Field: "rootfs"})
		if err != nil {
			return nil, err
		}
		err = srv.Select(ctx, rootfs, &stat, dagql.Selector{
			Field: "stat",
			Args:  args,
		})
		if err != nil {
			return nil, err
		}

	case mnt.DirectorySource != nil: // directory mount
		var parentDir dagql.ObjectResult[*Directory]
		err := srv.Select(ctx, parent, &parentDir, dagql.Selector{
			Field: "directory",
			Args: []dagql.NamedInput{
				{Name: "path", Value: dagql.String(mnt.Target)},
			},
		})
		if err != nil {
			return nil, err
		}
		err = srv.Select(ctx, parentDir, &stat, dagql.Selector{
			Field: "stat",
			Args:  args,
		})
		if err != nil {
			return nil, err
		}

	case mnt.FileSource != nil: // file mount
		if mntSubpath != "" && mntSubpath != "." {
			return nil, &os.PathError{Op: "stat", Path: targetPath, Err: syscall.ENOENT}
		}
		var fileRes dagql.ObjectResult[*File]
		if err := srv.Select(ctx, parent, &fileRes, dagql.Selector{
			Field: "file",
			Args: []dagql.NamedInput{
				{Name: "path", Value: dagql.String(mnt.Target)},
			},
		}); err != nil {
			return nil, err
		}
		err = srv.Select(ctx, fileRes, &stat, dagql.Selector{
			Field: "stat",
		})
		if err != nil {
			return nil, err
		}

	default:
		return nil, fmt.Errorf("invalid mount source for %s", targetPath)
	}

	return stat, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithAnnotation(ctx context.Context, key, value string) (*Container, error) {
	container.Annotations = append(container.Annotations, containerutil.ContainerAnnotation{
		Key:   key,
		Value: value,
	})

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithoutAnnotation(ctx context.Context, name string) (*Container, error) {
	for i, annotation := range container.Annotations {
		if annotation.Key == name {
			container.Annotations = slices.Delete(container.Annotations, i, i+1)
			break
		}
	}

	// set image ref to empty string
	container.ImageRef = ""

	return container, nil
}

func (container *Container) Publish(
	ctx context.Context,
	ref string,
	platformVariants []*Container,
	forcedCompression ImageLayerCompression,
	mediaTypes ImageMediaTypes,
	registryServices ServiceBindings,
	registryTransport serverresolver.RegistryTransport,
) (string, error) {
	variants := filterEmptyContainers(append([]*Container{container}, platformVariants...))
	inputByPlatform, err := getVariantRefs(ctx, variants)
	if err != nil {
		return "", err
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return "", err
	}
	bk, err := query.Engine(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get engine client: %w", err)
	}
	network, detach, err := ContainerRegistryNetwork(ctx, registryServices)
	if err != nil {
		return "", err
	}
	defer detach()

	resp, err := bk.PublishContainerImage(ctx, inputByPlatform, ref, useOCIMediaTypes(mediaTypes), string(forcedCompression), network, registryTransport)
	if err != nil {
		return "", err
	}

	refName, err := reference.ParseNormalizedNamed(ref)
	if err != nil {
		return "", err
	}

	withDig, err := reference.WithDigest(refName, resp.RootDesc.Digest)
	if err != nil {
		return "", fmt.Errorf("with digest: %w", err)
	}
	return withDig.String(), nil
}

func (container *Container) Manifest(
	ctx context.Context,
	containerDigest digest.Digest,
	forcedCompression ImageLayerCompression,
	mediaTypes ImageMediaTypes,
) (f *File, rerr error) {
	image, err := container.prepareContainerImage(ctx, containerDigest, forcedCompression, mediaTypes)
	if err != nil {
		return nil, err
	}

	return containerImageBlobFile(ctx, image.Manifest(), "manifest.json")
}

func (container *Container) prepareContainerImage(
	ctx context.Context,
	containerDigest digest.Digest,
	forcedCompression ImageLayerCompression,
	mediaTypes ImageMediaTypes,
) (*engineutil.PreparedContainerImage, error) {
	variants := filterEmptyContainers([]*Container{container})
	inputByPlatform, err := getVariantRefs(ctx, variants)
	if err != nil {
		return nil, err
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}

	bk, err := query.Engine(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get engine client: %w", err)
	}

	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	clientMetadata, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return nil, fmt.Errorf("prepare container image session metadata: %w", err)
	}
	cacheKey := hashutil.HashStrings(
		"prepare-container-image",
		clientMetadata.SessionID,
		containerDigest.String(),
		string(forcedCompression),
		string(mediaTypes),
	).String()
	cacheRes, err := cache.GetOrInitArbitrary(ctx, clientMetadata.SessionID, cacheKey, func(ctx context.Context) (any, error) {
		return bk.PrepareContainerImage(ctx, inputByPlatform, useOCIMediaTypes(mediaTypes), string(forcedCompression))
	})
	if err != nil {
		return nil, err
	}

	image, ok := cacheRes.Value().(*engineutil.PreparedContainerImage)
	if !ok {
		return nil, fmt.Errorf("invalid prepared container image cache result %T", cacheRes.Value())
	}
	return image, nil
}

func (container *Container) Layer(
	ctx context.Context,
	containerDigest digest.Digest,
	forcedCompression ImageLayerCompression,
	mediaTypes ImageMediaTypes,
	id string,
) (f *File, rerr error) {
	image, err := container.prepareContainerImage(ctx, containerDigest, forcedCompression, mediaTypes)
	if err != nil {
		return nil, err
	}
	blob, err := image.Blob(id)
	if err != nil {
		return nil, err
	}

	return containerImageBlobFile(ctx, blob, containerImageBlobName(blob))
}

func containerImageBlobName(blob engineutil.ContainerImageBlob) string {
	desc := blob.Descriptor()
	name := desc.Digest.Encoded()
	if images.IsConfigType(desc.MediaType) {
		return name + ".json"
	}

	switch desc.MediaType {
	case specs.MediaTypeImageLayer,
		specs.MediaTypeImageLayerNonDistributable, //nolint:staticcheck // Older images may still contain non-distributable layers.
		images.MediaTypeDockerSchema2Layer,
		images.MediaTypeDockerSchema2LayerForeign:
		return name + ".tar"
	case specs.MediaTypeImageLayerGzip,
		specs.MediaTypeImageLayerNonDistributableGzip, //nolint:staticcheck // Older images may still contain non-distributable layers.
		images.MediaTypeDockerSchema2LayerGzip,
		images.MediaTypeDockerSchema2LayerForeignGzip:
		return name + ".tar.gz"
	case specs.MediaTypeImageLayerZstd,
		specs.MediaTypeImageLayerNonDistributableZstd, //nolint:staticcheck // Older images may still contain non-distributable layers.
		images.MediaTypeDockerSchema2LayerZstd:
		return name + ".tar.zst"
	default:
		return name
	}
}

type ExportOpts struct {
	Dest              string
	PlatformVariants  []*Container
	ForcedCompression ImageLayerCompression
	MediaTypes        ImageMediaTypes
	Tar               bool
	LeaseID           string
}

func useOCIMediaTypes(mediaTypes ImageMediaTypes) bool {
	if mediaTypes == "" {
		// Modern registry implementations support oci types and docker daemons
		// have been capable of pulling them since 2018:
		// https://github.com/moby/moby/pull/37359
		// So they are a safe default.
		mediaTypes = OCIMediaTypes
	}
	return mediaTypes == OCIMediaTypes
}

func filterEmptyContainers(containers []*Container) []*Container {
	// Callers must settle metadata and fs first. Peek intentionally treats a
	// pending rootfs accessor as empty.
	var l []*Container
	for _, c := range containers {
		if c.FS == nil {
			continue
		}
		rootFS, ok := c.FS.Peek()
		if !ok || rootFS == nil {
			continue
		}
		l = append(l, c)
	}
	return l
}

func getVariantRefs(ctx context.Context, variants []*Container) (map[string]engineutil.ContainerExport, error) {
	inputByPlatform := map[string]engineutil.ContainerExport{}
	var eg errgroup.Group
	var mu sync.Mutex
	for _, variant := range variants {
		if err := variant.evaluatePartsDirect(ctx, ContainerPartMetadata); err != nil {
			return nil, err
		}
		platformString := variant.Platform.Format()
		if _, ok := inputByPlatform[platformString]; ok {
			return nil, fmt.Errorf("duplicate platform %q", platformString)
		}

		variant := variant
		platformKey := platformString
		eg.Go(func() error {
			if err := variant.evaluatePartsDirect(ctx, ContainerPartMetadata, ContainerPartFS); err != nil {
				return err
			}
			if variant.FS == nil {
				return nil
			}
			rootFS, ok := variant.FS.Peek()
			if !ok || rootFS == nil {
				return nil
			}
			fsRef, ok := rootFS.Snapshot.Peek()
			if !ok || fsRef == nil {
				return fmt.Errorf("get variant rootfs snapshot for platform %s: unset snapshot", platformKey)
			}

			mu.Lock()
			defer mu.Unlock()

			inputByPlatform[platformKey] = engineutil.ContainerExport{
				Ref:         fsRef,
				Config:      variant.Config,
				Annotations: variant.Annotations,
			}
			return nil
		})
	}
	err := eg.Wait()
	if err != nil {
		return nil, err
	}
	if len(inputByPlatform) == 0 {
		// Could also just ignore and do nothing, airing on side of error until proven otherwise.
		return nil, errors.New("no containers to export")
	}
	return inputByPlatform, nil
}

func (container *Container) Export(ctx context.Context, opts ExportOpts) (*specs.Descriptor, error) {
	if opts.Tar {
		tarball, err := container.AsTarball(
			ctx,
			opts.PlatformVariants,
			opts.ForcedCompression,
			opts.MediaTypes,
			"container.tar",
		)
		if err != nil {
			return nil, err
		}
		defer func() {
			_ = tarball.OnRelease(context.WithoutCancel(ctx))
		}()
		filePath, ok := tarball.File.Peek()
		if !ok {
			return nil, fmt.Errorf("container export tarball file path: unset")
		}
		snapshot, ok := tarball.Snapshot.Peek()
		if !ok {
			return nil, fmt.Errorf("container export tarball snapshot: unset")
		}
		if err := ExportFile(ctx, snapshot, filePath, opts.Dest, false); err != nil {
			return nil, err
		}
		return nil, nil
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	bk, err := query.Engine(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get engine client: %w", err)
	}

	variants := filterEmptyContainers(append([]*Container{container}, opts.PlatformVariants...))
	inputByPlatform, err := getVariantRefs(ctx, variants)
	if err != nil {
		return nil, err
	}

	resp, err := bk.ExportContainerImage(ctx, opts.Dest, inputByPlatform, string(opts.ForcedCompression), opts.Tar, opts.LeaseID, useOCIMediaTypes(opts.MediaTypes))
	if err != nil {
		return nil, err
	}
	return &resp.RootDesc, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithExposedPort(port Port) (*Container, error) {
	// replace existing port to avoid duplicates
	gotOne := false

	for i, p := range container.Ports {
		if p.Port == port.Port && p.Protocol == port.Protocol {
			container.Ports[i] = port
			gotOne = true
			break
		}
	}

	if !gotOne {
		container.Ports = append(container.Ports, port)
	}

	if container.Config.ExposedPorts == nil {
		container.Config.ExposedPorts = map[string]struct{}{}
	}

	ociPort := fmt.Sprintf("%d/%s", port.Port, port.Protocol.Network())
	container.Config.ExposedPorts[ociPort] = struct{}{}
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithoutExposedPort(port int, protocol NetworkProtocol) (*Container, error) {
	filtered := []Port{}
	filteredOCI := map[string]struct{}{}
	for _, p := range container.Ports {
		if p.Port != port || p.Protocol != protocol {
			filtered = append(filtered, p)
			ociPort := fmt.Sprintf("%d/%s", p.Port, p.Protocol.Network())
			filteredOCI[ociPort] = struct{}{}
		}
	}

	container.Ports = filtered
	container.Config.ExposedPorts = filteredOCI
	container.ImageRef = ""

	return container, nil
}

// mutates container caller must have handled cloning or creating a new child.
func (container *Container) WithServiceBinding(ctx context.Context, svc dagql.ObjectResult[*Service], alias string) (*Container, error) {
	svcDig, err := svc.ContentPreferredDigest(ctx)
	if err != nil {
		return nil, err
	}
	host, err := svc.Self().Hostname(ctx, svcDig)
	if err != nil {
		return nil, err
	}

	var aliases AliasSet
	if alias != "" {
		aliases = AliasSet{alias}
	}

	container.Services.Merge(ServiceBindings{
		{
			Service:  svc,
			Hostname: host,
			Aliases:  aliases,
		},
	})

	return container, nil
}

// ContainerRegistryNetwork starts service bindings for a registry operation and
// returns the Dagger DNS view that should apply while that operation is running.
func ContainerRegistryNetwork(ctx context.Context, bindings ServiceBindings) (serverresolver.NetworkConfig, func(), error) {
	if len(bindings) == 0 {
		return serverresolver.NetworkConfig{}, func() {}, nil
	}

	query, err := CurrentQuery(ctx)
	if err != nil {
		return serverresolver.NetworkConfig{}, nil, err
	}
	svcs, err := query.Services(ctx)
	if err != nil {
		return serverresolver.NetworkConfig{}, nil, fmt.Errorf("failed to get services: %w", err)
	}
	detach, _, err := svcs.StartBindings(ctx, bindings)
	if err != nil {
		return serverresolver.NetworkConfig{}, nil, err
	}

	dns, err := DNSConfig(ctx)
	if err != nil {
		detach()
		return serverresolver.NetworkConfig{}, nil, err
	}

	hostAliases := map[string]string{}
	for _, binding := range bindings {
		// Registry refs use the caller's binding aliases, while Dagger DNS knows
		// the service by its canonical hostname.
		hostAliases[binding.Hostname] = binding.Hostname
		aliases := slices.Clone(binding.Aliases)
		slices.Sort(aliases)
		for _, alias := range aliases {
			hostAliases[alias] = binding.Hostname
		}
	}

	return serverresolver.NetworkConfig{
		DNS:         dns,
		HostAliases: hostAliases,
	}, detach, nil
}

func ContainerRegistryServiceBinding(ctx context.Context, ref string, service dagql.ObjectResult[*Service]) (ServiceBindings, error) {
	if service.Self() == nil {
		return nil, nil
	}
	refName, err := reference.ParseNormalizedNamed(ref)
	if err != nil {
		return nil, fmt.Errorf("failed to parse image address %s: %w", ref, err)
	}
	host := reference.Domain(refName)
	alias := host
	// The image ref may include a port, like "registry:5000/app:latest".
	// Dagger DNS only aliases the hostname, so bind "registry" while leaving
	// the original ref as "registry:5000/app:latest".
	if h, _, err := net.SplitHostPort(host); err == nil {
		alias = h
	}

	svcDig, err := service.ContentPreferredDigest(ctx)
	if err != nil {
		return nil, err
	}
	svcHost, err := service.Self().Hostname(ctx, svcDig)
	if err != nil {
		return nil, err
	}
	return ServiceBindings{{
		Service:  service,
		Hostname: svcHost,
		Aliases:  AliasSet{alias},
	}}, nil
}

func (container *Container) ImageRefOrErr(ctx context.Context) (string, error) {
	imgRef := container.ImageRef
	if imgRef != "" {
		return imgRef, nil
	}

	return "", errors.Errorf("Image reference can only be retrieved immediately after the 'Container.From' call. Error in fetching imageRef as the container image is changed")
}

type ContainerAsServiceArgs struct {
	// Command to run instead of the container's default command
	Args []string `default:"[]"`

	// If the container has an entrypoint, prepend it to this exec's args
	UseEntrypoint bool `default:"false"`

	// Provide the executed command access back to the Dagger API
	ExperimentalPrivilegedNesting bool `default:"false"`

	// Disable access to the Dagger API from the service command.
	DisableDaggerInDagger bool `default:"false"`

	// Connect Dagger clients started by the service command as new sessions
	// instead of as clients of the current session.
	DaggerInDaggerNewSession bool `default:"false"`

	// Grant the process all root capabilities
	InsecureRootCapabilities bool `default:"false"`

	// Expand the environment variables in args
	Expand bool `default:"false"`

	// Skip the init process injected into containers by default so that the
	// user's process is PID 1
	NoInit bool `default:"false"`
}

func (container *Container) AsService(ctx context.Context, containerRes dagql.ObjectResult[*Container], args ContainerAsServiceArgs) (*Service, error) {
	if containerRes.Self() == nil {
		return nil, fmt.Errorf("container result is nil")
	}
	if len(args.Args) == 0 &&
		len(container.Config.Cmd) == 0 &&
		len(container.Config.Entrypoint) == 0 {
		return nil, ErrNoSvcCommand
	}

	useEntrypoint := args.UseEntrypoint
	if len(container.Config.Entrypoint) > 0 && !container.DefaultArgs {
		useEntrypoint = true
	}

	var cmdargs = container.Config.Cmd
	if len(args.Args) > 0 {
		cmdargs = args.Args
		if !args.UseEntrypoint {
			useEntrypoint = false
		}
	}

	if len(container.Config.Entrypoint) > 0 && useEntrypoint {
		cmdargs = append(container.Config.Entrypoint, cmdargs...)
	}

	return &Service{
		Container:                     containerRes,
		Args:                          cmdargs,
		ExperimentalPrivilegedNesting: args.ExperimentalPrivilegedNesting,
		DaggerInDaggerNewSession:      args.DaggerInDaggerNewSession,
		InsecureRootCapabilities:      args.InsecureRootCapabilities,
		NoInit:                        args.NoInit,
	}, nil
}

func (container *Container) openFile(ctx context.Context, parent dagql.ObjectResult[*Container], path string) (io.ReadCloser, error) {
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get server: %w", err)
	}
	path = absPath(container.Config.WorkingDir, path)

	var fileSource dagql.ObjectResult[*File]
	if err := srv.Select(ctx, parent, &fileSource, dagql.Selector{
		Field: "file",
		Args: []dagql.NamedInput{
			{Name: "path", Value: dagql.String(path)},
		},
	}); err != nil {
		return nil, err
	}

	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, err
	}
	if err := cache.Evaluate(ctx, fileSource); err != nil {
		return nil, err
	}
	return fileSource.Self().Open(ctx, fileSource)
}

func (container *Container) ownership(ctx context.Context, parent dagql.ObjectResult[*Container], owner string) (*Ownership, error) {
	if owner == "" {
		// do not change ownership
		return nil, nil
	}

	uidOrName, gidOrName, hasGroup := strings.Cut(owner, ":")

	var uid, gid int
	var uname, gname string

	uid, err := parseUID(uidOrName)
	if err != nil {
		uname = uidOrName
	}

	if hasGroup {
		gid, err = parseUID(gidOrName)
		if err != nil {
			gname = gidOrName
		}
	}

	if uname != "" {
		f, err := container.openFile(ctx, parent, "/etc/passwd")
		if err != nil {
			return nil, fmt.Errorf("open /etc/passwd: %w", err)
		}
		defer f.Close()
		uid, err = findUID(f, uname)
		if err != nil {
			return nil, fmt.Errorf("find uid: %w", err)
		}
	}

	if gname != "" {
		f, err := container.openFile(ctx, parent, "/etc/group")
		if err != nil {
			return nil, fmt.Errorf("open /etc/passwd: %w", err)
		}
		defer f.Close()
		gid, err = findGID(f, gname)
		if err != nil {
			return nil, fmt.Errorf("find gid: %w", err)
		}
	}

	if !hasGroup {
		gid = uid
	}

	return &Ownership{uid, gid}, nil
}

func (container *Container) ResolveOwnership(ctx context.Context, parent dagql.ObjectResult[*Container], owner string) (string, error) {
	ownership, err := container.ownership(ctx, parent, owner)
	if err != nil {
		return "", err
	}
	if ownership == nil {
		return "", nil
	}
	return strconv.Itoa(ownership.UID) + ":" + strconv.Itoa(ownership.GID), nil
}

func (container *Container) command(opts ContainerExecOpts) ([]string, error) {
	cfg := container.Config
	args := opts.Args

	if len(args) == 0 {
		// we use the default args if no new default args are passed
		args = cfg.Cmd
	}

	if len(cfg.Entrypoint) > 0 && opts.UseEntrypoint {
		args = append(cfg.Entrypoint, args...)
	}

	if len(args) == 0 {
		return nil, ErrNoCommand
	}

	return args, nil
}

type BuildArg struct {
	Name  string `field:"true" doc:"The build argument name."`
	Value string `field:"true" doc:"The build argument value."`
}

func (BuildArg) TypeName() string {
	return "BuildArg"
}

func (BuildArg) TypeDescription() string {
	return "Key value object that represents a build argument."
}

// OCI manifest annotation that specifies an image's tag
const ociTagAnnotation = "org.opencontainers.image.ref.name"

func ResolveIndex(ctx context.Context, store content.Store, desc specs.Descriptor, platform specs.Platform, tag string) (*specs.Descriptor, error) {
	return resolveIndex(ctx, store, desc, platform, tag)
}

func resolveIndex(ctx context.Context, store content.Store, desc specs.Descriptor, platform specs.Platform, tag string) (*specs.Descriptor, error) {
	if desc.MediaType != specs.MediaTypeImageIndex {
		return nil, fmt.Errorf("expected index, got %s", desc.MediaType)
	}

	indexBlob, err := content.ReadBlob(ctx, store, desc)
	if err != nil {
		return nil, fmt.Errorf("read index blob: %w", err)
	}

	var idx specs.Index
	err = json.Unmarshal(indexBlob, &idx)
	if err != nil {
		return nil, fmt.Errorf("unmarshal index: %w", err)
	}

	matcher := platforms.Only(platform)

	for _, m := range idx.Manifests {
		if m.Platform != nil {
			if !matcher.Match(*m.Platform) {
				// incompatible
				continue
			}
		}

		if tag != "" {
			if m.Annotations == nil {
				continue
			}

			manifestTag, found := m.Annotations[ociTagAnnotation]
			if !found || manifestTag != tag {
				continue
			}
		}

		switch m.MediaType {
		case specs.MediaTypeImageManifest, // OCI
			images.MediaTypeDockerSchema2Manifest: // Docker
			return &m, nil

		case specs.MediaTypeImageIndex, // OCI
			images.MediaTypeDockerSchema2ManifestList: // Docker
			return resolveIndex(ctx, store, m, platform, tag)

		default:
			return nil, fmt.Errorf("expected manifest or index, got %s", m.MediaType)
		}
	}

	return nil, fmt.Errorf("no manifest for platform %s and tag %s", platforms.Format(platform), tag)
}

type ImageLayerCompression string

var ImageLayerCompressions = dagql.NewEnum[ImageLayerCompression]()

var (
	CompressionGzip         = ImageLayerCompressions.Register("Gzip")
	_                       = ImageLayerCompressions.AliasView("GZIP", "Gzip", enumView)
	CompressionZstd         = ImageLayerCompressions.Register("Zstd")
	_                       = ImageLayerCompressions.AliasView("ZSTD", "Zstd", enumView)
	CompressionEStarGZ      = ImageLayerCompressions.Register("EStarGZ")
	_                       = ImageLayerCompressions.AliasView("ESTARGZ", "EStarGZ", enumView)
	CompressionUncompressed = ImageLayerCompressions.Register("Uncompressed")
	_                       = ImageLayerCompressions.AliasView("UNCOMPRESSED", "Uncompressed", enumView)
)

func (proto ImageLayerCompression) Type() *ast.Type {
	return &ast.Type{
		NamedType: "ImageLayerCompression",
		NonNull:   true,
	}
}

func (proto ImageLayerCompression) TypeDescription() string {
	return "Compression algorithm to use for image layers."
}

func (proto ImageLayerCompression) Decoder() dagql.InputDecoder {
	return ImageLayerCompressions
}

func (proto ImageLayerCompression) ToLiteral() call.Literal {
	return ImageLayerCompressions.Literal(proto)
}

type ImageMediaTypes string

var ImageMediaTypesEnum = dagql.NewEnum[ImageMediaTypes]()

var (
	OCIMediaTypes    = ImageMediaTypesEnum.Register("OCIMediaTypes")
	_                = ImageMediaTypesEnum.AliasView("OCI", "OCIMediaTypes", enumView)
	DockerMediaTypes = ImageMediaTypesEnum.Register("DockerMediaTypes")
	_                = ImageMediaTypesEnum.AliasView("DOCKER", "DockerMediaTypes", enumView)
)

func (proto ImageMediaTypes) Type() *ast.Type {
	return &ast.Type{
		NamedType: "ImageMediaTypes",
		NonNull:   true,
	}
}

func (proto ImageMediaTypes) TypeDescription() string {
	return "Mediatypes to use in published or exported image metadata."
}

func (proto ImageMediaTypes) Decoder() dagql.InputDecoder {
	return ImageMediaTypesEnum
}

func (proto ImageMediaTypes) ToLiteral() call.Literal {
	return ImageMediaTypesEnum.Literal(proto)
}

type ReturnTypes string

var ReturnTypesEnum = dagql.NewEnum[ReturnTypes]()

var (
	ReturnSuccess = ReturnTypesEnum.Register("SUCCESS",
		`A successful execution (exit code 0)`,
	)
	ReturnFailure = ReturnTypesEnum.Register("FAILURE",
		`A failed execution (exit codes 1-127 and 192-255)`,
	)
	ReturnAny = ReturnTypesEnum.Register("ANY",
		`Any execution (exit codes 0-127 and 192-255)`,
	)
)

func (expect ReturnTypes) Type() *ast.Type {
	return &ast.Type{
		NamedType: "ReturnType",
		NonNull:   true,
	}
}

func (expect ReturnTypes) TypeDescription() string {
	return "Expected return type of an execution"
}

func (expect ReturnTypes) Decoder() dagql.InputDecoder {
	return ReturnTypesEnum
}

func (expect ReturnTypes) ToLiteral() call.Literal {
	return ReturnTypesEnum.Literal(expect)
}

// ReturnCodes gets the valid exit codes allowed for a specific return status
//
// NOTE: exit status codes 128-191 are likely from exiting via a signal - we
// shouldn't try and handle these. Codes 192-255 are safe to handle to support
// tools that return exit codes >127, such as AWS CLI.
func (expect ReturnTypes) ReturnCodes() []int {
	switch expect {
	case ReturnSuccess:
		return []int{0}
	case ReturnFailure:
		codes := make([]int, 0, 127+64)
		for i := 1; i <= 127; i++ {
			codes = append(codes, i)
		}
		for i := 192; i <= 255; i++ {
			codes = append(codes, i)
		}
		return codes
	case ReturnAny:
		codes := make([]int, 0, 128+64)
		for i := 0; i <= 127; i++ {
			codes = append(codes, i)
		}
		for i := 192; i <= 255; i++ {
			codes = append(codes, i)
		}
		return codes
	default:
		return nil
	}
}

type TerminalLegacy struct{}

func (*TerminalLegacy) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Terminal",
		NonNull:   true,
	}
}

func (*TerminalLegacy) TypeDescription() string {
	return "An interactive terminal that clients can connect to."
}

func (*TerminalLegacy) Evaluate(ctx context.Context) error {
	return nil
}

func (terminal *TerminalLegacy) Sync(ctx context.Context) error {
	return terminal.Evaluate(ctx)
}
