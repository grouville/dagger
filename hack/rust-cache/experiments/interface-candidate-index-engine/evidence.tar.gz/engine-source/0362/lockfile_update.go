package core

import (
	"context"
	"errors"
	"fmt"
	"net/url"
	"path"
	"reflect"
	"sort"
	"strings"

	"github.com/dagger/dagger/core/workspace"
	"github.com/dagger/dagger/dagql"
	serverresolver "github.com/dagger/dagger/engine/server/resolver"
	"github.com/dagger/dagger/engine/slog"
	"github.com/dagger/dagger/util/gitutil"
	telemetry "github.com/dagger/otel-go"
	"github.com/distribution/reference"
	digest "github.com/opencontainers/go-digest"
)

// UpdateWorkspaceLock refreshes the existing entries in a workspace lockfile in place.
func UpdateWorkspaceLock(ctx context.Context, query *Query, lock *workspace.Lock) error {
	_, err := UpdateWorkspaceLockEntries(ctx, query, lock, nil)
	return err
}

// UpdateWorkspaceLockEntries refreshes entries selected by any of selectors.
// An empty selector list refreshes every supported entry. It returns the
// existing entries selected for refresh, in lockfile order.
func UpdateWorkspaceLockEntries(ctx context.Context, query *Query, lock *workspace.Lock, selectors []string) ([]workspace.LookupEntry, error) {
	entries, err := SelectWorkspaceLockEntries(lock, selectors)
	if err != nil {
		return nil, err
	}

	var refreshedEntries []workspace.LookupEntry
	for _, entry := range entries {
		if !isLatestLockEntry(entry) {
			continue
		}

		result, err := updateWorkspaceLockEntry(ctx, query, entry)
		if err != nil {
			if ignoreUnsupportedLockEntry(ctx, entry, err) {
				continue
			}
			return nil, err
		}
		if err := lock.SetLookup(entry.Namespace, entry.Operation, entry.Inputs, result); err != nil {
			return nil, fmt.Errorf("rewrite lock entry for %s %v: %w", entry.Operation, entry.Inputs, err)
		}
		selectedEntry, err := selectedSHAEntry(entry, result)
		if err != nil {
			return nil, err
		}
		if containsLockEntry(refreshedEntries, selectedEntry) {
			continue
		}
		previousValue, found := lock.GetLookup(
			selectedEntry.Namespace,
			selectedEntry.Operation,
			selectedEntry.Inputs,
		)
		if found {
			selectedEntry.Value = previousValue
		}
		selectedValue, err := updateWorkspaceLockEntry(ctx, query, selectedEntry)
		if err != nil {
			return nil, err
		}
		if err := lock.SetLookup(
			selectedEntry.Namespace,
			selectedEntry.Operation,
			selectedEntry.Inputs,
			selectedValue,
		); err != nil {
			return nil, fmt.Errorf(
				"write selected SHA entry for %s %v: %w",
				selectedEntry.Operation,
				selectedEntry.Inputs,
				err,
			)
		}
		refreshedEntries = append(refreshedEntries, selectedEntry)
	}

	for _, entry := range entries {
		if isLatestLockEntry(entry) || containsLockEntry(refreshedEntries, entry) {
			continue
		}
		result, err := updateWorkspaceLockEntry(ctx, query, entry)
		if err != nil {
			if ignoreUnsupportedLockEntry(ctx, entry, err) {
				continue
			}
			return nil, err
		}
		if err := lock.SetLookup(entry.Namespace, entry.Operation, entry.Inputs, result); err != nil {
			return nil, fmt.Errorf("rewrite lock entry for %s %v: %w", entry.Operation, entry.Inputs, err)
		}
	}

	return entries, nil
}

// SelectWorkspaceLockEntries returns supported entries matching any selector.
// Selectors are shell-style patterns matched against user-facing identities
// for each entry. An empty selector list selects every supported entry.
func SelectWorkspaceLockEntries(lock *workspace.Lock, selectors []string) ([]workspace.LookupEntry, error) {
	patternErrs := make([]error, len(selectors))
	for i, selector := range selectors {
		if selector == "" {
			return nil, fmt.Errorf("lock selector must not be empty")
		}
		_, patternErrs[i] = matchLockSelector(selector, "")
	}
	var selected []workspace.LookupEntry
	matched := make([]bool, len(selectors))
	for _, entry := range lock.Entries() {
		if !isSupportedLockEntry(entry) {
			continue
		}
		if len(selectors) == 0 {
			selected = append(selected, entry)
			continue
		}
		entrySelected := false
		for i, selector := range selectors {
			ok, err := lockEntryMatchesSelector(entry, selector)
			if err != nil {
				// A malformed pattern may still be an exact literal selector for
				// another entry, so defer its syntax error until every entry has
				// been checked.
				if patternErrs[i] != nil {
					continue
				}
				return nil, err
			}
			if ok {
				matched[i] = true
				entrySelected = true
			}
		}
		if entrySelected {
			selected = append(selected, entry)
		}
	}
	for i, ok := range matched {
		if !ok {
			if patternErrs[i] != nil {
				return nil, fmt.Errorf("invalid lock selector %q: %w", selectors[i], patternErrs[i])
			}
			return nil, fmt.Errorf("lock selector %q matched no entries", selectors[i])
		}
	}
	return selected, nil
}

// WorkspaceLockEntrySelector is the stable, copyable selector printed by
// `dagger lock update --dry-run`.
func WorkspaceLockEntrySelector(entry workspace.LookupEntry) string {
	required, _, err := workspace.ParseLookupInputs(entry.Inputs)
	if err != nil || len(required) == 0 {
		return ""
	}
	primary, ok := required[0].(string)
	if !ok {
		return ""
	}
	switch entry.Operation {
	case workspace.LockOperationGitLatest, workspace.LockOperationGitSHA:
		remote := workspace.NormalizeGitRemote(primary)
		if remote == "" {
			remote = primary
		}
		if entry.Operation == workspace.LockOperationGitSHA && len(required) == 2 {
			if ref, ok := required[1].(string); ok {
				return remote + "@" + ref
			}
		}
		return remote
	default:
		return primary
	}
}

func lockEntryMatchesSelector(entry workspace.LookupEntry, selector string) (bool, error) {
	if selector == "" {
		return false, fmt.Errorf("lock selector must not be empty")
	}
	candidates := workspaceLockEntrySelectorCandidates(entry)
	// Prefer literal equality before interpreting the selector as a pattern.
	// This keeps selectors printed by --dry-run reusable when an input itself
	// contains pattern metacharacters such as '[' or '?'.
	for _, candidate := range candidates {
		if selector == candidate {
			return true, nil
		}
	}
	for _, candidate := range candidates {
		matched, err := matchLockSelector(selector, candidate)
		if err != nil {
			return false, fmt.Errorf("invalid lock selector %q: %w", selector, err)
		}
		if matched {
			return true, nil
		}
	}
	return false, nil
}

func workspaceLockEntrySelectorCandidates(entry workspace.LookupEntry) []string {
	required, _, err := workspace.ParseLookupInputs(entry.Inputs)
	if err != nil || len(required) == 0 {
		return nil
	}
	primary, ok := required[0].(string)
	if !ok {
		return nil
	}

	var candidates []string
	appendCandidate := func(candidate string) {
		if candidate == "" {
			return
		}
		for _, existing := range candidates {
			if candidate == existing {
				return
			}
		}
		candidates = append(candidates, candidate)
	}

	switch entry.Operation {
	case workspace.LockOperationOCILatest, workspace.LockOperationOCISHA:
		appendCandidate(primary)
		if named, err := reference.ParseNormalizedNamed(primary); err == nil {
			shortName := path.Base(reference.Path(named))
			appendCandidate(shortName)
			if tagged, ok := named.(reference.NamedTagged); ok {
				appendCandidate(shortName + ":" + tagged.Tag())
			}
			if canonical, ok := named.(reference.Canonical); ok {
				appendCandidate(shortName + "@" + canonical.Digest().String())
			}
		}
	case workspace.LockOperationGitLatest, workspace.LockOperationGitSHA:
		remote := workspace.NormalizeGitRemote(primary)
		if remote == "" {
			remote = primary
		}
		repositories := []string{remote, path.Base(strings.TrimSuffix(remote, ".git"))}
		for _, repository := range repositories {
			appendCandidate(repository)
		}
		if entry.Operation == workspace.LockOperationGitSHA && len(required) == 2 {
			if ref, ok := required[1].(string); ok {
				refs := []string{ref}
				if short, found := strings.CutPrefix(ref, "refs/heads/"); found {
					refs = append(refs, short)
				} else if short, found := strings.CutPrefix(ref, "refs/tags/"); found {
					refs = append(refs, short)
				}
				for _, repository := range repositories {
					for _, ref := range refs {
						appendCandidate(repository + "@" + ref)
					}
				}
			}
		}
	case workspace.LockOperationVanityURL:
		appendCandidate(primary)
		if parsed, err := url.Parse(primary); err == nil {
			urlPath := strings.Trim(parsed.Path, "/")
			if urlPath != "" {
				appendCandidate(path.Base(urlPath))
			}
		}
	default:
		appendCandidate(WorkspaceLockEntrySelector(entry))
	}
	return candidates
}

// Lock selectors describe flat resource identities rather than filesystem
// paths, so '/' has no special meaning to '*'. Keep path.Match's familiar
// shell syntax while replacing slashes with a character that cannot be passed
// in a command-line argument.
func matchLockSelector(pattern, candidate string) (bool, error) {
	const slashPlaceholder = "\x00"
	return path.Match(
		strings.ReplaceAll(pattern, "/", slashPlaceholder),
		strings.ReplaceAll(candidate, "/", slashPlaceholder),
	)
}

func isSupportedLockEntry(entry workspace.LookupEntry) bool {
	if entry.Namespace != workspace.CoreLockNamespace {
		return false
	}
	switch entry.Operation {
	case workspace.LockOperationOCILatest,
		workspace.LockOperationOCISHA,
		workspace.LockOperationGitLatest,
		workspace.LockOperationGitSHA,
		workspace.LockOperationVanityURL:
		return true
	default:
		return false
	}
}

var errUnsupportedLockEntry = errors.New("unsupported lock entry")

func ignoreUnsupportedLockEntry(ctx context.Context, entry workspace.LookupEntry, err error) bool {
	if !errors.Is(err, errUnsupportedLockEntry) {
		return false
	}
	slog.GlobalLogger(ctx, InstrumentationLibrary).Warn(
		"ignoring unsupported workspace lock entry",
		"namespace", entry.Namespace,
		"operation", entry.Operation,
		"inputs", entry.Inputs,
		"error", err,
	)
	return true
}

func isLatestLockEntry(entry workspace.LookupEntry) bool {
	return entry.Namespace == workspace.CoreLockNamespace &&
		(entry.Operation == workspace.LockOperationGitLatest ||
			entry.Operation == workspace.LockOperationOCILatest)
}

func containsLockEntry(entries []workspace.LookupEntry, target workspace.LookupEntry) bool {
	for _, entry := range entries {
		if entry.Namespace == target.Namespace &&
			entry.Operation == target.Operation &&
			reflect.DeepEqual(entry.Inputs, target.Inputs) {
			return true
		}
	}
	return false
}

func selectedSHAEntry(
	entry workspace.LookupEntry,
	value string,
) (workspace.LookupEntry, error) {
	if value == "" {
		return workspace.LookupEntry{}, fmt.Errorf("invalid %s lock value", entry.Operation)
	}
	required, options, err := workspace.ParseLookupInputs(entry.Inputs)
	if err != nil {
		return workspace.LookupEntry{}, fmt.Errorf("invalid %s inputs %v: %w", entry.Operation, entry.Inputs, err)
	}

	var operation string
	var selectedInputs []any
	switch entry.Operation {
	case workspace.LockOperationGitLatest:
		if len(required) != 1 {
			return workspace.LookupEntry{}, fmt.Errorf("invalid %s inputs %v", entry.Operation, entry.Inputs)
		}
		operation = workspace.LockOperationGitSHA
		selectedInputs = []any{required[0], value}
	case workspace.LockOperationOCILatest:
		if len(required) != 1 {
			return workspace.LookupEntry{}, fmt.Errorf("invalid %s inputs %v", entry.Operation, entry.Inputs)
		}
		image, ok := required[0].(string)
		if !ok || image == "" {
			return workspace.LookupEntry{}, fmt.Errorf("invalid %s ref %v", entry.Operation, required[0])
		}
		ref, err := reference.ParseNormalizedNamed(image)
		if err != nil {
			return workspace.LookupEntry{}, fmt.Errorf("parse image address %q: %w", image, err)
		}
		ref, err = reference.WithTag(reference.TrimNamed(ref), value)
		if err != nil {
			return workspace.LookupEntry{}, fmt.Errorf("apply selected image tag %q: %w", value, err)
		}
		var shaOptions []workspace.LookupOption
		for name, optionValue := range options {
			if name == "version" {
				continue
			}
			shaOptions = append(shaOptions, workspace.LookupOption{
				Name:  name,
				Value: optionValue,
			})
		}
		sort.Slice(shaOptions, func(i, j int) bool {
			return shaOptions[i].Name < shaOptions[j].Name
		})
		operation = workspace.LockOperationOCISHA
		selectedInputs = workspace.LookupInputs(
			[]any{ref.String()},
			shaOptions...,
		)
	default:
		return workspace.LookupEntry{}, fmt.Errorf(
			"unsupported latest lock entry %q %q",
			entry.Namespace,
			entry.Operation,
		)
	}

	return workspace.LookupEntry{
		Namespace: entry.Namespace,
		Operation: operation,
		Inputs:    selectedInputs,
		Value:     value,
	}, nil
}

func updateWorkspaceLockEntry(ctx context.Context, query *Query, entry workspace.LookupEntry) (string, error) {
	if entry.Namespace != workspace.CoreLockNamespace {
		return "", fmt.Errorf(
			"%w %q %q",
			errUnsupportedLockEntry,
			entry.Namespace,
			entry.Operation,
		)
	}

	switch entry.Operation {
	case workspace.LockOperationOCILatest:
		return updateOCILatestLockEntry(ctx, query, entry)
	case workspace.LockOperationOCISHA:
		return updateOCISHALockEntry(ctx, query, entry)
	case workspace.LockOperationGitLatest:
		return updateGitLatestLockEntry(ctx, entry)
	case workspace.LockOperationGitSHA:
		return updateGitSHALockEntry(ctx, entry)
	case workspace.LockOperationVanityURL:
		return updateVanityURLLockEntry(ctx, entry)
	default:
		return "", fmt.Errorf(
			"%w %q %q",
			errUnsupportedLockEntry,
			entry.Namespace,
			entry.Operation,
		)
	}
}

func updateVanityURLLockEntry(ctx context.Context, entry workspace.LookupEntry) (string, error) {
	required, options, err := workspace.ParseLookupInputs(entry.Inputs)
	if err != nil {
		return "", fmt.Errorf("invalid %s inputs %v: %w", entry.Operation, entry.Inputs, err)
	}
	if len(required) != 1 || len(options) != 0 {
		return "", fmt.Errorf("invalid %s inputs %v", entry.Operation, entry.Inputs)
	}
	sourceURL, ok := required[0].(string)
	if !ok || sourceURL == "" {
		return "", fmt.Errorf("invalid %s source URL %v", entry.Operation, required[0])
	}
	resolved := daggerGetProbe(ctx, sourceURL)
	if resolved == sourceURL {
		return "", fmt.Errorf("refresh vanity-url %q: no valid redirect received", sourceURL)
	}
	return resolved, nil
}

type ociLockInputs struct {
	ref               string
	version           string
	registryTransport serverresolver.RegistryTransport
}

func parseOCILockInputs(
	operation string,
	inputs []any,
	latest bool,
) (ociLockInputs, error) {
	var parsed ociLockInputs
	required, options, err := workspace.ParseLookupInputs(inputs)
	if err != nil {
		return parsed, fmt.Errorf("invalid %s inputs %v: %w", operation, inputs, err)
	}
	if len(required) != 1 {
		return parsed, fmt.Errorf("invalid %s inputs %v", operation, inputs)
	}
	ref, ok := required[0].(string)
	if !ok || ref == "" {
		return parsed, fmt.Errorf("invalid %s ref %v", operation, required[0])
	}
	refName, err := reference.ParseNormalizedNamed(ref)
	if err != nil {
		return parsed, fmt.Errorf("invalid %s ref %q: %w", operation, ref, err)
	}
	if latest && !reference.IsNameOnly(refName) {
		return parsed, fmt.Errorf("invalid %s tagged ref %q", operation, ref)
	}
	if !latest {
		if _, ok := refName.(reference.NamedTagged); !ok {
			return parsed, fmt.Errorf("invalid %s untagged ref %q", operation, ref)
		}
	}
	parsed.ref = ref

	for name, value := range options {
		switch name {
		case "version":
			version, ok := value.(string)
			if !ok || version == "" || !latest {
				return parsed, fmt.Errorf("invalid %s version %v", operation, value)
			}
			if _, err := parseReleaseVersionQuery(version); err != nil {
				return parsed, fmt.Errorf("invalid %s version %v: %w", operation, value, err)
			}
			parsed.version = version
		case "protocol":
			protocol, ok := value.(string)
			if !ok {
				return parsed, fmt.Errorf("invalid %s registry protocol %v", operation, value)
			}
			switch serverresolver.RegistryProtocol(protocol) {
			case serverresolver.RegistryProtocolHTTP, serverresolver.RegistryProtocolHTTPS:
				parsed.registryTransport.Protocol = serverresolver.RegistryProtocol(protocol)
			default:
				return parsed, fmt.Errorf("invalid %s registry protocol %q", operation, protocol)
			}
		case "insecureSkipTLSVerify":
			insecure, ok := value.(bool)
			if !ok {
				return parsed, fmt.Errorf("invalid %s insecureSkipTLSVerify %v", operation, value)
			}
			parsed.registryTransport.InsecureSkipTLSVerify = insecure
		default:
			return parsed, unsupportedLockOptionError(operation, name)
		}
	}
	if parsed.registryTransport.InsecureSkipTLSVerify {
		if parsed.registryTransport.Protocol == serverresolver.RegistryProtocolHTTP {
			return parsed, fmt.Errorf("invalid %s registry transport options", operation)
		}
		if parsed.registryTransport.Protocol == "" {
			parsed.registryTransport.Protocol = serverresolver.RegistryProtocolHTTPS
		}
	}
	return parsed, nil
}

func updateOCILatestLockEntry(
	ctx context.Context,
	query *Query,
	entry workspace.LookupEntry,
) (string, error) {
	inputs, err := parseOCILockInputs(workspace.LockOperationOCILatest, entry.Inputs, true)
	if err != nil {
		return "", err
	}
	refName, err := reference.ParseNormalizedNamed(inputs.ref)
	if err != nil {
		return "", fmt.Errorf("parse image address %q: %w", inputs.ref, err)
	}
	refName = reference.TrimNamed(refName)

	rslvr, err := query.RegistryResolver(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get registry resolver: %w", err)
	}
	// Encapsulate so the tag listing's raw HTTP spans stay out of the default
	// TUI; they surface if the listing fails.
	listCtx, span := Tracer(ctx).Start(ctx, fmt.Sprintf("select latest release for %s", refName.String()),
		telemetry.Internal(), telemetry.Encapsulate())
	tags, err := rslvr.ListImageTags(listCtx, refName.String(), serverresolver.ListImageTagsOpts{
		RegistryTransport: inputs.registryTransport,
	})
	telemetry.EndWithCause(span, &err)
	if err != nil {
		return "", fmt.Errorf("list image tags for %q: %w", refName.String(), err)
	}
	selectedTag, err := SelectContainerTag(tags, inputs.version)
	if err != nil {
		return "", fmt.Errorf("select latest image tag for %q: %w", refName.String(), err)
	}
	return selectedTag, nil
}

func updateOCISHALockEntry(
	ctx context.Context,
	query *Query,
	entry workspace.LookupEntry,
) (string, error) {
	inputs, err := parseOCILockInputs(workspace.LockOperationOCISHA, entry.Inputs, false)
	if err != nil {
		return "", err
	}
	resolvedDigest, err := resolveOCIDigest(ctx, query, inputs)
	if err != nil {
		return "", err
	}
	return resolvedDigest.String(), nil
}

func resolveOCIDigest(ctx context.Context, query *Query, inputs ociLockInputs) (digest.Digest, error) {
	rslvr, err := query.RegistryResolver(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to get registry resolver: %w", err)
	}

	refName, err := reference.ParseNormalizedNamed(inputs.ref)
	if err != nil {
		return "", fmt.Errorf("parse image address %q: %w", inputs.ref, err)
	}
	refName = reference.TagNameOnly(refName)

	_, resolvedDigest, err := rslvr.ResolveImageDigest(ctx, refName.String(), serverresolver.ResolveImageDigestOpts{
		RegistryTransport: inputs.registryTransport,
	})
	if err != nil {
		return "", fmt.Errorf("resolve image %q: %w", refName.String(), err)
	}

	return resolvedDigest, nil
}

func updateGitSHALockEntry(ctx context.Context, entry workspace.LookupEntry) (string, error) {
	remoteURL, name, err := parseGitLookupInputs(workspace.LockOperationGitSHA, entry.Inputs)
	if err != nil {
		return "", err
	}
	result, err := resolveGitSHA(ctx, remoteURL, name)
	if err != nil {
		return "", err
	}
	if oldSHA := entry.Value; strings.HasPrefix(name, "refs/tags/") &&
		gitutil.IsCommitSHA(oldSHA) && oldSHA != result {
		slog.GlobalLogger(ctx, InstrumentationLibrary).Warn(
			"git tag points to a different commit",
			"repository", remoteURL,
			"tag", strings.TrimPrefix(name, "refs/tags/"),
			"oldCommit", oldSHA,
			"newCommit", result,
		)
	}
	return result, nil
}

func parseGitLookupInputs(operation string, inputs []any) (string, string, error) {
	required, options, err := workspace.ParseLookupInputs(inputs)
	if err != nil {
		return "", "", fmt.Errorf("invalid %s inputs %v: %w", operation, inputs, err)
	}
	if len(required) != 2 {
		return "", "", fmt.Errorf("invalid %s inputs %v", operation, inputs)
	}
	for name := range options {
		return "", "", unsupportedLockOptionError(operation, name)
	}
	remoteURL, ok := required[0].(string)
	if !ok || remoteURL == "" {
		return "", "", fmt.Errorf("invalid %s remote %v", operation, inputs[0])
	}
	name, ok := required[1].(string)
	if !ok || name == "" {
		return "", "", fmt.Errorf("invalid %s name %v", operation, inputs[1])
	}
	return remoteURL, name, nil
}

func resolveGitSHA(ctx context.Context, remoteURL, name string) (string, error) {
	if gitutil.IsCommitSHA(name) {
		return name, nil
	}

	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return "", err
	}

	var ref dagql.ObjectResult[*GitRef]
	if err := srv.Select(ctx, srv.Root(), &ref,
		dagql.Selector{
			Field: "git",
			Args: []dagql.NamedInput{
				{Name: "url", Value: dagql.String(remoteURL)},
			},
		},
		dagql.Selector{
			Field: "ref",
			Args: []dagql.NamedInput{
				{Name: "name", Value: dagql.String(name)},
			},
		},
	); err != nil {
		return "", fmt.Errorf("resolve git ref %q for %q: %w", name, remoteURL, err)
	}
	return ref.Self().Ref.SHA, nil
}

func updateGitLatestLockEntry(ctx context.Context, entry workspace.LookupEntry) (string, error) {
	required, options, err := workspace.ParseLookupInputs(entry.Inputs)
	if err != nil {
		return "", fmt.Errorf(
			"invalid %s inputs %v: %w",
			workspace.LockOperationGitLatest,
			entry.Inputs,
			err,
		)
	}
	if len(required) != 1 {
		return "", fmt.Errorf(
			"invalid %s inputs %v",
			workspace.LockOperationGitLatest,
			entry.Inputs,
		)
	}
	remoteURL, ok := required[0].(string)
	if !ok || remoteURL == "" {
		return "", fmt.Errorf(
			"invalid %s remote %v",
			workspace.LockOperationGitLatest,
			required[0],
		)
	}
	var tagPrefix string
	var version string
	for name, value := range options {
		switch name {
		case "tagPrefix":
			var ok bool
			tagPrefix, ok = value.(string)
			if !ok || tagPrefix == "" {
				return "", fmt.Errorf(
					"invalid %s tagPrefix %v",
					workspace.LockOperationGitLatest,
					value,
				)
			}
		case "version":
			var ok bool
			version, ok = value.(string)
			if !ok || version == "" {
				return "", fmt.Errorf(
					"invalid %s version %v",
					workspace.LockOperationGitLatest,
					value,
				)
			}
			if _, err := parseReleaseVersionQuery(version); err != nil {
				return "", fmt.Errorf("invalid %s version %v: %w", workspace.LockOperationGitLatest, value, err)
			}
		default:
			return "", unsupportedLockOptionError(
				workspace.LockOperationGitLatest,
				name,
			)
		}
	}

	// Resolve through the schema's git resolver rather than a bare
	// RemoteGitRepository so the same access context that created the pin
	// (credential helpers, SSH sockets, protocol fallback) applies here too.
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return "", err
	}

	var latestInputs []dagql.NamedInput
	if version != "" {
		latestInputs = append(latestInputs, dagql.NamedInput{
			Name:  "version",
			Value: dagql.String(version),
		})
	}
	if tagPrefix != "" {
		latestInputs = append(latestInputs, dagql.NamedInput{
			Name:  "tagPrefix",
			Value: dagql.String(tagPrefix),
		})
	}

	var latest dagql.ObjectResult[*GitRef]
	if err := srv.Select(ctx, srv.Root(), &latest,
		dagql.Selector{
			Field: "git",
			Args: []dagql.NamedInput{
				{Name: "url", Value: dagql.String(remoteURL)},
			},
		},
		dagql.Selector{
			Field: "latest",
			Args:  latestInputs,
		},
	); err != nil {
		return "", fmt.Errorf("resolve latest git release for %q: %w", remoteURL, err)
	}

	selectedRef := latest.Self().Ref.Name
	return selectedRef, nil
}

func unsupportedLockOptionError(operation, name string) error {
	return fmt.Errorf(
		"%w: cannot update %s: unsupported option %q; "+
			"upgrade Dagger or remove the option",
		errUnsupportedLockEntry,
		operation,
		name,
	)
}
