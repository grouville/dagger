package core

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"

	"github.com/containerd/containerd/v2/core/mount"
	"github.com/dagger/dagger/dagql"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	bkclient "github.com/dagger/dagger/internal/buildkit/client"
	"github.com/dagger/dagger/util/gitutil"
	telemetry "github.com/dagger/otel-go"
)

// Select by the exact ref recipe, not URL, SHA or filesystem equivalence. This
// shares promotion between reconciliation and commit without widening the
// authorization scope. The returned Directory owns all objects, not an alternate
// pointing into a mutable mirror or an operation-local mount.
func nativeCommitRepository(ctx context.Context, parent dagql.ObjectResult[*GitRef]) (*LocalGitRepository, error) {
	if local, ok := parent.Self().Backend.(*LocalGitRef); ok {
		return local.repo, nil
	}
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, err
	}
	// Source-only trees pin branch names to the resolved SHA. Select that
	// same recipe so reconciliation and construction share one promotion even
	// when the caller originally selected a named ref. Repository identity
	// (including auth and service bindings) is unchanged.
	var pinned dagql.ObjectResult[*GitRef]
	if err := srv.Select(ctx, parent.Self().Repo, &pinned, dagql.Selector{Field: "ref", Args: []dagql.NamedInput{{Name: "name", Value: dagql.String(parent.Self().Ref.SHA)}}}); err != nil {
		return nil, err
	}
	var dir dagql.ObjectResult[*Directory]
	if err := srv.Select(ctx, pinned, &dir, dagql.Selector{Field: "__nativeCommitBase", Args: []dagql.NamedInput{{Name: "depth", Value: dagql.Int(1)}}}); err != nil {
		return nil, err
	}
	return &LocalGitRepository{Directory: dir, HistorySource: pinned}, nil
}

// GitRemoteCommitBase promotes only the pinned commit's reachable closure. The
// mirror is mutable and shared by URL (including across authentication recipes):
// neither copying its packs wholesale nor inheriting its refs is safe. Hydrate
// through the normal authenticated fetch path, then pack into private storage
// while the mirror lock is held. Publication never writes to the mirror.
func GitRemoteCommitBase(ctx context.Context, parent dagql.ObjectResult[*GitRef], depth int) (_ *Directory, rerr error) {
	if depth != 0 && depth != 1 {
		return nil, fmt.Errorf("remote commit base depth must be zero or one")
	}
	ref, ok := parent.Self().Backend.(*RemoteGitRef)
	if !ok || ref.Ref == nil || len(ref.SHA) != 40 || !IsFullGitSHA(ref.SHA) {
		return nil, nativeCommitUnsupportedReason("remote-ref")
	}
	ctx, span := Tracer(ctx).Start(ctx, "git promote remote commit base", telemetry.Internal())
	defer telemetry.EndWithCause(span, &rerr)
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	remotes, upstream, err := parent.Self().Repo.Self().ConfiguredRemotes(ctx)
	if err != nil {
		return nil, err
	}
	var child bkcache.MutableRef
	var result *Directory
	defer func() {
		if child != nil {
			rerr = errors.Join(rerr, child.Release(context.WithoutCancel(ctx)))
		}
		rerr = errors.Join(rerr, ctx.Err())
		if rerr != nil && result != nil {
			rerr = errors.Join(rerr, result.OnRelease(context.WithoutCancel(ctx)))
		}
	}()
	pack, err := query.approvedHostCommitPack(ctx, parent, depth)
	if err != nil {
		return nil, err
	}
	if pack != nil {
		// A rejected donation returns no snapshot: fall through to the remote.
		child, err = query.importApprovedHostCommitBase(ctx, pack, ref.SHA, remotes)
		if err != nil {
			return nil, err
		}
	}
	if child == nil {
		child, err = query.SnapshotManager().New(ctx, nil,
			bkcache.WithRecordType(bkclient.UsageRecordTypeGitCheckout),
			bkcache.WithDescription("owned remote commit closure"))
		if err != nil {
			return nil, err
		}
		err = MountRef(ctx, child, func(dest string, _ *mount.Mount) error {
			// Only explicit history consumers request depth zero. Ordinary commits
			// own a single-commit source boundary, even if the mirror is already warm.
			err := ref.mount(ctx, depth, false, func(ctx context.Context, _ *gitutil.GitCLI) error {
				// mount holds both the mirror lock and its snapshot lease. Borrow an
				// actual read-only mount so Git cannot freshen inherited pack mtimes.
				// Reading Mirror.snapshot directly is only safe because ref.mount →
				// initRemote → Mirror.acquire holds mirror.mu until this callback returns.
				return MountRef(ctx, ref.repo.Mirror.Self().snapshot, func(source string, _ *mount.Mount) error {
					return copyRemoteCommitBase(ctx, source, dest, ref.SHA, depth)
				}, mountRefAsReadOnly)
			})
			if err != nil {
				return err
			}
			// dest owns the packed closure: finish with the mirror released.
			return finishRemoteCommitBase(ctx, dest, ref.SHA, remotes)
		})
	}
	if err != nil {
		return nil, err
	}
	// Both approved host donation and remote fetch produce owned storage.
	// Preserve the captured selection regardless of which supplies history.
	if err := MountRef(ctx, child, func(dest string, _ *mount.Mount) error {
		return writeGitRemoteSelection(ctx, gitutil.NewGitCLI(gitutil.WithGitDir(dest)), remotes, upstream)
	}); err != nil {
		return nil, err
	}
	snap, err := child.Commit(ctx)
	if err != nil {
		return nil, err
	}
	child = nil
	result = &Directory{Platform: query.Platform(), Dir: new(LazyAccessor[string, *Directory]), Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory])}
	result.SetPath("/")
	result.SetSnapshot(snap)
	return result, nil
}

// A non-thin pack contains exactly the selected history, even when unrelated
// objects are delta bases in the donor pack. Git reuses compressed objects where
// possible; the cost of traversal/packing is still real and traced separately.
func packRemoteCommitBaseDepth(ctx context.Context, source, dest, sha string, remotes []GitRemote, depth int) error {
	if err := copyRemoteCommitBase(ctx, source, dest, sha, depth); err != nil {
		return err
	}
	return finishRemoteCommitBase(ctx, dest, sha, remotes)
}

// copyRemoteCommitBase packs sha's closure (depth one or complete) from the
// borrowed source into a fresh bare repository at dest. This is the only phase
// of a promotion that reads source: the alternate is a transient environment
// variable, so dest refers back to nothing once this returns.
func copyRemoteCommitBase(ctx context.Context, source, dest, sha string, depth int) (rerr error) {
	ctx, span := Tracer(ctx).Start(ctx, "git pack remote commit closure", telemetry.Internal())
	defer telemetry.EndWithCause(span, &rerr)
	if len(sha) != 40 || !IsFullGitSHA(sha) {
		return fmt.Errorf("remote commit base requires a complete SHA-1")
	}
	gitDir, err := nativeCommitGitDirWithShallow(ctx, source, true)
	if err != nil {
		return err
	}
	if _, err := runWorkspaceCommitGit(ctx, dest, nil, "init", "--bare", "--template=", "--object-format=sha1", "--ref-format=files"); err != nil {
		return err
	}
	if depth == 1 {
		// The boundary is explicit even when the borrowed mirror is complete.
		// Never copy its unrelated shallow markers or rely on alternate metadata.
		if err := os.WriteFile(filepath.Join(dest, "shallow"), []byte(sha+"\n"), 0644); err != nil {
			return err
		}
	}
	// The pack's primary object database (where pack-objects also keeps its
	// temporary files) is dest's own; the mirror is only borrowed.
	run := func(ctx context.Context, env []string, stdin io.Reader, args ...string) (string, error) {
		return runWorkspaceCommitGitInput(ctx, dest, env, stdin, args...)
	}
	return packGitObjects(ctx, run, filepath.Join(dest, "objects"), filepath.Join(gitDir, "objects"), []string{sha}, true)
}

// finishRemoteCommitBase points the packed repository at dest to sha and
// records its remotes. It reads only dest, so it runs with the mirror released.
func finishRemoteCommitBase(ctx context.Context, dest, sha string, remotes []GitRemote) error {
	if err := os.WriteFile(filepath.Join(dest, "HEAD"), []byte(sha+"\n"), 0644); err != nil {
		return err
	}
	git := gitutil.NewGitCLI(gitutil.WithGitDir(dest))
	for _, remote := range remotes {
		if err := writeGitCheckoutRemote(ctx, git, remote); err != nil {
			return err
		}
	}
	return nil
}
