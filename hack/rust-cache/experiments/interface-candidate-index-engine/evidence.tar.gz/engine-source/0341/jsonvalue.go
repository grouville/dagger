package core

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/dagger/dagger/dagql"
	"github.com/vektah/gqlparser/v2/ast"
)

// JSONValue is a simple state carrier for JSON-encoded bytes
type JSONValue struct {
	Data []byte
}

var _ dagql.PersistedObject = (*JSONValue)(nil)
var _ dagql.PersistedObjectDecoder = (*JSONValue)(nil)
var _ dagql.CachePayloadSizer = (*JSONValue)(nil)

func (v *JSONValue) CachePayloadBytes() int64 {
	if v == nil {
		return 0
	}
	return int64(len(v.Data))
}

func (*JSONValue) Type() *ast.Type {
	return &ast.Type{
		NamedType: "JSONValue",
		NonNull:   true,
	}
}

func (v *JSONValue) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	_ = ctx
	_ = enc
	if v == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted JSON value: nil JSON value")
	}
	return encodePersistedObjectPayload(v)
}

func (*JSONValue) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	_ = ctx
	_ = dec
	var v JSONValue
	if err := json.Unmarshal(payload, &v); err != nil {
		return nil, fmt.Errorf("decode persisted JSON value payload: %w", err)
	}
	return &v, nil
}
