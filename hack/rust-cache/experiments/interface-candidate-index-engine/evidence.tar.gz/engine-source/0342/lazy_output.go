package core

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"slices"

	"github.com/dagger/dagger/dagql"
	bkcache "github.com/dagger/dagger/engine/snapshots"
)

func isNilValue(value any) bool {
	if value == nil {
		return true
	}
	switch reflect.ValueOf(value).Kind() {
	case reflect.Pointer, reflect.Interface, reflect.Map, reflect.Slice, reflect.Func, reflect.Chan:
		return reflect.ValueOf(value).IsNil()
	}
	return false
}

func directoryOutput(dir *Directory) (string, bkcache.ImmutableRef, error) {
	if dir == nil || dir.Dir == nil || dir.Snapshot == nil {
		return "", nil, fmt.Errorf("missing Directory accessors")
	}
	path, ok := dir.Dir.Peek()
	if !ok {
		return "", nil, fmt.Errorf("Directory path is unset")
	}
	snapshot, ok := dir.Snapshot.Peek()
	if !ok || isNilValue(snapshot) {
		return "", nil, fmt.Errorf("Directory snapshot is unset")
	}
	return path, snapshot, nil
}

func fileOutput(file *File) (string, bkcache.ImmutableRef, error) {
	if file == nil || file.File == nil || file.Snapshot == nil {
		return "", nil, fmt.Errorf("missing File accessors")
	}
	path, ok := file.File.Peek()
	if !ok {
		return "", nil, fmt.Errorf("File path is unset")
	}
	snapshot, ok := file.Snapshot.Peek()
	if !ok || isNilValue(snapshot) {
		return "", nil, fmt.Errorf("File snapshot is unset")
	}
	return path, snapshot, nil
}

func validateLazyDirectoryReceiver(dir *Directory) error {
	if dir == nil || dir.Dir == nil || dir.Snapshot == nil {
		return fmt.Errorf("operation receiver: missing Directory accessors")
	}
	if snapshot, ok := dir.Snapshot.Peek(); ok && !isNilValue(snapshot) {
		return fmt.Errorf("operation receiver: Directory snapshot already installed")
	}
	if dir.stored != nil {
		return fmt.Errorf("operation receiver: Directory has stored snapshot")
	}
	return nil
}

func validateLazyFileReceiver(file *File) error {
	if file == nil || file.File == nil || file.Snapshot == nil {
		return fmt.Errorf("operation receiver: missing File accessors")
	}
	if snapshot, ok := file.Snapshot.Peek(); ok && !isNilValue(snapshot) {
		return fmt.Errorf("operation receiver: File snapshot already installed")
	}
	if file.stored != nil {
		return fmt.Errorf("operation receiver: File has stored snapshot")
	}
	return nil
}

// moveDirectoryOutput transfers the ref owned by a private temporary output.
// A published destination must be inside its admitted Lazy evaluation; the
// source must not be a borrowed dependency.
func moveDirectoryOutput(dst, src *Directory) error {
	if err := validateLazyDirectoryReceiver(dst); err != nil {
		return err
	}
	path, snapshot, err := directoryOutput(src)
	if err != nil {
		return err
	}
	dst.SetPath(path)
	dst.Services = slices.Clone(src.Services)
	dst.SetSnapshot(snapshot)
	src.Snapshot = new(LazyAccessor[bkcache.ImmutableRef, *Directory])
	return nil
}

func moveFileOutput(dst, src *File) error {
	if err := validateLazyFileReceiver(dst); err != nil {
		return err
	}
	path, snapshot, err := fileOutput(src)
	if err != nil {
		return err
	}
	dst.SetPath(path)
	dst.Services = slices.Clone(src.Services)
	dst.SetSnapshot(snapshot)
	src.Snapshot = new(LazyAccessor[bkcache.ImmutableRef, *File])
	return nil
}

// evaluateFileOutput runs produce as file's operation body and moves the
// private output it returns into file. An output that was not moved is
// released.
func evaluateFileOutput(ctx context.Context, state *LazyState, op string, file *File, produce func(context.Context) (*File, error)) error {
	var unmoved *File
	err := file.evaluateLazy(ctx, state, op, func(ctx context.Context) error {
		if err := validateLazyFileReceiver(file); err != nil {
			return err
		}
		out, err := produce(ctx)
		if err != nil {
			return err
		}
		if err := moveFileOutput(file, out); err != nil {
			unmoved = out
			return err
		}
		return nil
	})
	if unmoved != nil {
		err = errors.Join(err, unmoved.OnRelease(context.WithoutCancel(ctx)))
	}
	return err
}

// evaluateDirectoryOutput is evaluateFileOutput for a Directory.
func evaluateDirectoryOutput(ctx context.Context, state *LazyState, op string, dir *Directory, produce func(context.Context) (*Directory, error)) error {
	var unmoved *Directory
	err := dir.evaluateLazy(ctx, state, op, func(ctx context.Context) error {
		if err := validateLazyDirectoryReceiver(dir); err != nil {
			return err
		}
		out, err := produce(ctx)
		if err != nil {
			return err
		}
		if err := moveDirectoryOutput(dir, out); err != nil {
			unmoved = out
			return err
		}
		return nil
	})
	if unmoved != nil {
		err = errors.Join(err, unmoved.OnRelease(context.WithoutCancel(ctx)))
	}
	return err
}

func attachLazyInput[T dagql.Typed](attach func(dagql.AnyResult) (dagql.AnyResult, error), input dagql.ObjectResult[T], label string) (dagql.ObjectResult[T], error) {
	if isNilValue(input.Self()) {
		return dagql.ObjectResult[T]{}, fmt.Errorf("%s: missing input", label)
	}
	attached, err := attach(input)
	if err != nil {
		return dagql.ObjectResult[T]{}, fmt.Errorf("%s: %w", label, err)
	}
	typed, ok := attached.(dagql.ObjectResult[T])
	if !ok || isNilValue(typed.Self()) {
		return dagql.ObjectResult[T]{}, fmt.Errorf("%s: unexpected result %T", label, attached)
	}
	return typed, nil
}

// attachFilesystemDependencyResultsKinds is the shared body of the Directory
// and File AttachDependencyResultsKinds methods: the service bindings' results
// first, then the lazy recipe's dependencies as liveness-only
// receiver/prerequisite links.
func attachFilesystemDependencyResultsKinds[T dagql.Typed](
	ctx context.Context,
	label string,
	services ServiceBindings,
	lazy Lazy[T],
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.DependencyResult, error) {
	serviceDeps, err := services.AttachDependencyResults(label, attach)
	if err != nil {
		return nil, err
	}
	if lazy == nil {
		return serviceDeps, nil
	}
	lazyDeps, err := lazy.AttachDependencies(ctx, attach)
	if err != nil {
		return nil, err
	}
	deps := make([]dagql.DependencyResult, 0, len(serviceDeps)+len(lazyDeps))
	deps = append(deps, serviceDeps...)
	for _, dep := range lazyDeps {
		// Liveness-only: receiver/prerequisite chain. Failures attribute to
		// the parent's own install span via direct lookup, not transitively
		// onto downstream chained calls.
		deps = append(deps, dagql.DependencyResult{Result: dep, Owned: false})
	}
	return deps, nil
}
