package core

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"

	"github.com/containerd/containerd/v2/core/content"
	"github.com/containerd/containerd/v2/core/mount"
	"github.com/containerd/containerd/v2/core/transfer/archive"
	"github.com/containerd/containerd/v2/pkg/labels"
	"github.com/containerd/platforms"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine/engineutil"
	serverresolver "github.com/dagger/dagger/engine/server/resolver"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	bkclient "github.com/dagger/dagger/internal/buildkit/client"
	"github.com/dagger/dagger/internal/buildkit/client/llb/sourceresolver"
	"github.com/dagger/dagger/internal/buildkit/solver/pb"
	dockerspec "github.com/moby/docker-image-spec/specs-go/v1"
	digest "github.com/opencontainers/go-digest"
	specs "github.com/opencontainers/image-spec/specs-go/v1"
	"golang.org/x/sync/errgroup"
)

type LoadedImportedImage struct {
	Image  bkcache.ImportedImage
	Config dockerspec.DockerOCIImage
}

func containerImageBlobFile(
	ctx context.Context,
	blob engineutil.ContainerImageBlob,
	filePath string,
) (f *File, rerr error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}

	bkref, err := query.SnapshotManager().New(ctx, nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription("dagop.fs container.imageBlob "+filePath),
	)
	if err != nil {
		return nil, err
	}
	defer func() {
		if rerr != nil && bkref != nil {
			bkref.Release(context.WithoutCancel(ctx))
		}
	}()

	err = MountRef(ctx, bkref, func(out string, _ *mount.Mount) error {
		file, err := os.OpenFile(filepath.Join(out, filePath), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
		if err != nil {
			return err
		}
		defer file.Close()
		return blob.WriteTo(ctx, file)
	})
	if err != nil {
		return nil, fmt.Errorf("write container image blob: %w", err)
	}

	snap, err := bkref.Commit(ctx)
	if err != nil {
		return nil, err
	}
	bkref = nil
	f = &File{
		Platform: query.Platform(),
		File:     new(LazyAccessor[string, *File]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
	}
	f.SetPath(filePath)
	f.SetSnapshot(snap)
	return f, nil
}

type ContainerFromImageRefLazy struct {
	LazyState
	Parent            dagql.ObjectResult[*Container]
	CanonicalRef      string
	Config            dockerspec.DockerOCIImageConfig
	ImageRef          string
	Platform          Platform
	ResolveMode       serverresolver.ResolveMode
	RegistryServices  ServiceBindings
	RegistryTransport serverresolver.RegistryTransport
}

type dockerfileImageMetaResolver struct {
	resolver *serverresolver.Resolver
}

func (r dockerfileImageMetaResolver) ResolveImageConfig(
	ctx context.Context,
	ref string,
	opt sourceresolver.Opt,
) (string, digest.Digest, []byte, error) {
	resolveMode := serverresolver.ResolveModeDefault
	if opt.ImageOpt != nil {
		switch opt.ImageOpt.ResolveMode {
		case "", pb.AttrImageResolveModeDefault:
			resolveMode = serverresolver.ResolveModeDefault
		case pb.AttrImageResolveModeForcePull:
			resolveMode = serverresolver.ResolveModeForcePull
		default:
			return "", "", nil, fmt.Errorf("unsupported image resolve mode %q", opt.ImageOpt.ResolveMode)
		}
	}

	if r.resolver == nil {
		return "", "", nil, fmt.Errorf("registry resolver is nil")
	}
	return r.resolver.ResolveImageConfig(ctx, ref, serverresolver.ResolveImageConfigOpts{
		Platform:    opt.Platform,
		ResolveMode: resolveMode,
	})
}

func (lazy *ContainerFromImageRefLazy) Evaluate(ctx context.Context, container *Container) error {
	return container.evaluateAllLazyGroups(ctx, lazy)
}

// ContainerLazyGroups maps the image metadata and rootfs to separate
// groups. The image config is already resolved when the op is created,
// so only the fs group pulls and imports the image layers. Other
// snapshot parts delegate from the parent.
func (lazy *ContainerFromImageRefLazy) ContainerLazyGroups(_ context.Context, ctr *Container, parts []dagql.PartKey) ([]dagql.LazyGroupKey, error) {
	if parts == nil {
		groups := []dagql.LazyGroupKey{ContainerLazyGroupMetadata, ContainerLazyGroupWrite}
		for _, part := range containerSnapshotParts(ctr) {
			if part == ContainerPartFS {
				continue
			}
			groups = append(groups, containerDelegationGroup(part))
		}
		return groups, nil
	}
	var groups []dagql.LazyGroupKey
	seen := make(map[dagql.LazyGroupKey]struct{}, len(parts))
	for _, part := range parts {
		var group dagql.LazyGroupKey
		switch part {
		case ContainerPartMetadata:
			group = ContainerLazyGroupMetadata
		case ContainerPartFS:
			group = ContainerLazyGroupWrite
		default:
			group = containerDelegationGroup(part)
		}
		if _, dup := seen[group]; dup {
			continue
		}
		seen[group] = struct{}{}
		groups = append(groups, group)
	}
	return groups, nil
}

func (lazy *ContainerFromImageRefLazy) EvaluateContainerGroup(ctx context.Context, container *Container, group dagql.LazyGroupKey) error {
	switch group {
	case ContainerLazyGroupMetadata:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.from", group, func(ctx context.Context) error {
			if err := materializeContainerMetadataFromParent(ctx, container, lazy.Parent); err != nil {
				return err
			}
			container.Config = CloneContainerImageConfig(lazy.Config)
			container.ImageRef = lazy.ImageRef
			container.Platform = lazy.Platform
			return nil
		})
	case ContainerLazyGroupWrite:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.from", group, func(ctx context.Context) error {
			query, err := CurrentQuery(ctx)
			if err != nil {
				return err
			}
			rslvr, err := query.RegistryResolver(ctx)
			if err != nil {
				return err
			}
			network, detach, err := ContainerRegistryNetwork(ctx, lazy.RegistryServices)
			if err != nil {
				return err
			}
			defer detach()

			pulled, err := rslvr.Pull(ctx, lazy.CanonicalRef, serverresolver.PullOpts{
				Platform:          lazy.Platform.Spec(),
				ResolveMode:       lazy.ResolveMode,
				Network:           network,
				RegistryTransport: lazy.RegistryTransport,
			})
			if err != nil {
				return fmt.Errorf("pull image %q: %w", lazy.CanonicalRef, err)
			}
			defer pulled.Release(context.WithoutCancel(ctx))

			rootfs, err := query.SnapshotManager().ImportImage(ctx, &bkcache.ImportedImage{
				Ref:          pulled.Ref,
				ManifestDesc: pulled.ManifestDesc,
				ConfigDesc:   pulled.ConfigDesc,
				Layers:       pulled.Layers,
				Nonlayers:    pulled.Nonlayers,
			}, bkcache.ImportImageOpts{
				ImageRef:   pulled.Ref,
				RecordType: bkclient.UsageRecordTypeRegular,
			})
			if err != nil {
				return fmt.Errorf("import image %q: %w", lazy.CanonicalRef, err)
			}
			rootfsDir := &Directory{
				Platform: container.Platform,
				Services: slices.Clone(container.Services),
				Dir:      new(LazyAccessor[string, *Directory]),
				Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
			}
			rootfsDir.SetPath("/")
			rootfsDir.SetSnapshot(rootfs)
			container.ensureFSAccessor().setValue(rootfsDir)
			return nil
		})
	default:
		return lazy.LazyState.EvaluateGroup(ctx, "Container.from", group, func(ctx context.Context) error {
			return delegateContainerPart(ctx, container, lazy.Parent, dagql.PartKey(group))
		})
	}
}

func (lazy *ContainerFromImageRefLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachContainerResult(attach, lazy.Parent, "attach container from parent")
	if err != nil {
		return nil, err
	}
	attachments := []dagql.AnyResult{parent}
	// From may run later, so keep the selected registry service with it.
	for i := range lazy.RegistryServices {
		binding := &lazy.RegistryServices[i]
		service, err := attachServiceResult(attach, binding.Service, "attach container from registry service")
		if err != nil {
			return nil, err
		}
		binding.Service = service
		attachments = append(attachments, service)
	}
	lazy.Parent = parent
	return attachments, nil
}

func (lazy *ContainerFromImageRefLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container from parent")
	if err != nil {
		return nil, err
	}
	services, err := encodePersistedServiceBindings(enc, "container from registry", lazy.RegistryServices)
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedContainerFromLazy{
		ParentResultID:    parentID,
		CanonicalRef:      lazy.CanonicalRef,
		Config:            CloneContainerImageConfig(lazy.Config),
		ImageRef:          lazy.ImageRef,
		Platform:          lazy.Platform,
		RegistryServices:  services,
		RegistryTransport: lazy.RegistryTransport,
	})
}

func (container *Container) Import(
	ctx context.Context,
	tarball io.Reader,
	tag string,
) (*Container, error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}

	stream := archive.NewImageImportStream(tarball, "")
	desc, err := stream.Import(ctx, query.OCIStore())
	if err != nil {
		return nil, fmt.Errorf("image archive import: %w", err)
	}

	manifestDesc, err := resolveIndex(ctx, query.OCIStore(), desc, container.Platform.Spec(), tag)
	if err != nil {
		return nil, fmt.Errorf("resolve imported image manifest: %w", err)
	}

	return container.FromOCIStore(ctx, *manifestDesc, tag)
}

func (container *Container) FromOCIStore(
	ctx context.Context,
	manifestDesc specs.Descriptor,
	imageRef string,
) (*Container, error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}

	loaded, err := loadImportedImageFromStore(ctx, query.OCIStore(), manifestDesc, imageRef)
	if err != nil {
		return nil, err
	}

	rootfs, err := query.SnapshotManager().ImportImage(ctx, &loaded.Image, bkcache.ImportImageOpts{
		ImageRef:   imageRef,
		RecordType: bkclient.UsageRecordTypeRegular,
	})
	if err != nil {
		return nil, fmt.Errorf("import image rootfs %q: %w", imageRef, err)
	}

	rootPlatform := container.Platform
	if loaded.Config.Platform.OS != "" {
		rootPlatform = Platform(platforms.Normalize(loaded.Config.Platform))
		container.Platform = rootPlatform
	}
	container.Config = loaded.Config.Config
	container.ImageRef = imageRef
	rootfsDir := &Directory{
		Platform: rootPlatform,
		Services: slices.Clone(container.Services),
		Dir:      new(LazyAccessor[string, *Directory]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *Directory]),
	}
	rootfsDir.SetPath("/")
	rootfsDir.SetSnapshot(rootfs)
	if container.FS == nil {
		container.FS = new(LazyAccessor[*Directory, *Container])
	}
	container.FS.setValue(rootfsDir)
	return container, nil
}

func (container *Container) FromInternal(
	ctx context.Context,
	desc specs.Descriptor,
) (*Container, error) {
	return container.FromOCIStore(ctx, desc, "")
}

func (container *Container) AsTarball(
	ctx context.Context,
	platformVariants []*Container,
	forcedCompression ImageLayerCompression,
	mediaTypes ImageMediaTypes,
	filePath string,
) (f *File, rerr error) {
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}

	bk, err := query.Engine(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get engine client: %w", err)
	}
	if mediaTypes == "" {
		mediaTypes = OCIMediaTypes
	}

	variants := filterEmptyContainers(append([]*Container{container}, platformVariants...))
	inputByPlatform, err := getVariantRefs(ctx, variants)
	if err != nil {
		return nil, err
	}

	bkref, err := query.SnapshotManager().New(ctx, nil,
		bkcache.WithRecordType(bkclient.UsageRecordTypeRegular),
		bkcache.WithDescription("dagop.fs container.asTarball "+filePath),
	)
	if err != nil {
		return nil, err
	}
	defer func() {
		if rerr != nil && bkref != nil {
			bkref.Release(context.WithoutCancel(ctx))
		}
	}()

	err = MountRef(ctx, bkref, func(out string, _ *mount.Mount) error {
		file, err := os.OpenFile(filepath.Join(out, filePath), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
		if err != nil {
			return err
		}
		defer file.Close()
		return bk.WriteContainerImageTarball(ctx, file, inputByPlatform, useOCIMediaTypes(mediaTypes), string(forcedCompression))
	})
	if err != nil {
		return nil, fmt.Errorf("container image to tarball file conversion failed: %w", err)
	}

	snap, err := bkref.Commit(ctx)
	if err != nil {
		return nil, err
	}
	bkref = nil
	f = &File{
		Platform: query.Platform(),
		File:     new(LazyAccessor[string, *File]),
		Snapshot: new(LazyAccessor[bkcache.ImmutableRef, *File]),
	}
	f.SetPath(filePath)
	f.SetSnapshot(snap)
	return f, nil
}

func loadImportedImageFromStore(
	ctx context.Context,
	store content.Store,
	manifestDesc specs.Descriptor,
	imageRef string,
) (*LoadedImportedImage, error) {
	manifestBlob, err := content.ReadBlob(ctx, store, manifestDesc)
	if err != nil {
		return nil, fmt.Errorf("read manifest blob %s: %w", manifestDesc.Digest, err)
	}

	var manifest specs.Manifest
	if err := json.Unmarshal(manifestBlob, &manifest); err != nil {
		return nil, fmt.Errorf("unmarshal manifest %s: %w", manifestDesc.Digest, err)
	}

	configDesc, err := hydrateImportedDescriptor(ctx, store, manifest.Config)
	if err != nil {
		return nil, err
	}

	configBlob, err := content.ReadBlob(ctx, store, configDesc)
	if err != nil {
		return nil, fmt.Errorf("read image config blob %s: %w", configDesc.Digest, err)
	}

	var imgSpec dockerspec.DockerOCIImage
	if err := json.Unmarshal(configBlob, &imgSpec); err != nil {
		return nil, fmt.Errorf("unmarshal image config %s: %w", configDesc.Digest, err)
	}

	if len(manifest.Layers) != len(imgSpec.RootFS.DiffIDs) {
		return nil, fmt.Errorf(
			"mismatched image rootfs and manifest layers: %d diffIDs vs %d layers",
			len(imgSpec.RootFS.DiffIDs),
			len(manifest.Layers),
		)
	}

	layers := make([]specs.Descriptor, len(manifest.Layers))
	for i, layer := range manifest.Layers {
		hydrated, err := hydrateImportedDescriptor(ctx, store, layer)
		if err != nil {
			return nil, err
		}
		if hydrated.Annotations == nil {
			hydrated.Annotations = map[string]string{}
		}
		hydrated.Annotations[labels.LabelUncompressed] = imgSpec.RootFS.DiffIDs[i].String()
		layers[i] = hydrated
	}

	return &LoadedImportedImage{
		Image: bkcache.ImportedImage{
			Ref:          imageRef,
			ManifestDesc: manifestDesc,
			ConfigDesc:   configDesc,
			Layers:       layers,
		},
		Config: imgSpec,
	}, nil
}

func hydrateImportedDescriptor(
	ctx context.Context,
	store content.Store,
	desc specs.Descriptor,
) (specs.Descriptor, error) {
	if desc.Digest == "" {
		return desc, nil
	}
	info, err := store.Info(ctx, desc.Digest)
	if err != nil {
		return specs.Descriptor{}, fmt.Errorf("stat descriptor %s: %w", desc.Digest, err)
	}
	hydrated := desc
	if hydrated.Size == 0 {
		hydrated.Size = info.Size
	}
	return hydrated, nil
}

const persistedFileLazyKindContainerImage = "container.image"

// FileContainerImageLazy writes a container's image as one file: the OCI
// tarball (Container.asTarball) or the image manifest (Container.manifest).
// A rebuild writes the same image content; its bytes can differ, because
// layers without a recorded compressed blob are compressed again.
type FileContainerImageLazy struct {
	LazyState
	Parent            dagql.ObjectResult[*Container]
	PlatformVariants  []dagql.ObjectResult[*Container]
	ForcedCompression ImageLayerCompression
	MediaTypes        ImageMediaTypes
	Manifest          bool
}

type persistedFileContainerImageLazy struct {
	ParentResultID           uint64                `json:"parentResultID"`
	PlatformVariantResultIDs []uint64              `json:"platformVariantResultIDs,omitempty"`
	ForcedCompression        ImageLayerCompression `json:"forcedCompression,omitempty"`
	MediaTypes               ImageMediaTypes       `json:"mediaTypes,omitempty"`
	Manifest                 bool                  `json:"manifest,omitempty"`
}

func (lazy *FileContainerImageLazy) Evaluate(ctx context.Context, file *File) error {
	op := "Container.asTarball"
	if lazy.Manifest {
		op = "Container.manifest"
	}
	return evaluateFileOutput(ctx, &lazy.LazyState, op, file, func(ctx context.Context) (*File, error) {
		cache, err := dagql.EngineCache(ctx)
		if err != nil {
			return nil, err
		}
		containers := append([]dagql.ObjectResult[*Container]{lazy.Parent}, lazy.PlatformVariants...)
		eg, egctx := errgroup.WithContext(ctx)
		for _, ctr := range containers {
			eg.Go(func() error {
				return cache.EvaluateParts(egctx, ctr, ContainerPartMetadata, ContainerPartFS)
			})
		}
		if err := eg.Wait(); err != nil {
			return nil, err
		}
		if lazy.Manifest {
			parentDigest, err := lazy.Parent.RecipeDigest(ctx)
			if err != nil {
				return nil, err
			}
			return lazy.Parent.Self().Manifest(ctx, parentDigest, lazy.ForcedCompression, lazy.MediaTypes)
		}
		variants := make([]*Container, 0, len(lazy.PlatformVariants))
		for _, variant := range lazy.PlatformVariants {
			variants = append(variants, variant.Self())
		}
		return lazy.Parent.Self().AsTarball(ctx, variants, lazy.ForcedCompression, lazy.MediaTypes, "container.tar")
	})
}

func (lazy *FileContainerImageLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachLazyInput(attach, lazy.Parent, "FileContainerImageLazy.Parent")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	deps := []dagql.AnyResult{parent}
	for i, variant := range lazy.PlatformVariants {
		attached, err := attachLazyInput(attach, variant, "FileContainerImageLazy.PlatformVariants")
		if err != nil {
			return nil, err
		}
		lazy.PlatformVariants[i] = attached
		deps = append(deps, attached)
	}
	return deps, nil
}

func (lazy *FileContainerImageLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "container image parent")
	if err != nil {
		return nil, err
	}
	variantIDs := make([]uint64, 0, len(lazy.PlatformVariants))
	for _, variant := range lazy.PlatformVariants {
		id, err := encodePersistedObjectRef(enc, variant, "container image platform variant")
		if err != nil {
			return nil, err
		}
		variantIDs = append(variantIDs, id)
	}
	return json.Marshal(persistedFileContainerImageLazy{
		ParentResultID:           parentID,
		PlatformVariantResultIDs: variantIDs,
		ForcedCompression:        lazy.ForcedCompression,
		MediaTypes:               lazy.MediaTypes,
		Manifest:                 lazy.Manifest,
	})
}

func decodeFileContainerImageLazy(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (Lazy[*File], error) {
	var persisted persistedFileContainerImageLazy
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted container image lazy: %w", err)
	}
	parent, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, persisted.ParentResultID, "container image parent")
	if err != nil {
		return nil, err
	}
	variants := make([]dagql.ObjectResult[*Container], 0, len(persisted.PlatformVariantResultIDs))
	for _, id := range persisted.PlatformVariantResultIDs {
		variant, err := loadPersistedObjectResultByResultID[*Container](ctx, dec, id, "container image platform variant")
		if err != nil {
			return nil, err
		}
		variants = append(variants, variant)
	}
	return &FileContainerImageLazy{
		LazyState:         NewLazyState(),
		Parent:            parent,
		PlatformVariants:  variants,
		ForcedCompression: persisted.ForcedCompression,
		MediaTypes:        persisted.MediaTypes,
		Manifest:          persisted.Manifest,
	}, nil
}
