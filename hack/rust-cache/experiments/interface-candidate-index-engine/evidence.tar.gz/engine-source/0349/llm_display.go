package core

import (
	"context"
	"encoding/base64"
	"fmt"
	"io"
	"strings"
	"sync"
	"time"

	"github.com/dagger/dagger/engine/telemetryattrs"
	telemetry "github.com/dagger/otel-go"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/log"
	"go.opentelemetry.io/otel/trace"
)

// emitContentLog preserves the text projection while carrying media out of band
// at its exact position. SpanStdio writes synchronously to the same logger, so
// adjacent text records retain their ordering relative to the attachment.
func emitContentLog(ctx context.Context, stdout io.Writer, block *LLMContentBlock, suffix string, attrs ...log.KeyValue) {
	if block == nil {
		return
	}
	switch block.Kind {
	case LLMContentImage, LLMContentAudio, LLMContentDocument:
		rec := log.Record{}
		rec.SetTimestamp(time.Now())
		rec.SetBody(log.StringValue(block.ContentText() + suffix))
		rec.AddAttributes(attrs...)
		rec.AddAttributes(
			log.Int(telemetry.StdioStreamAttr, 1),
			log.String(telemetryattrs.LogMediaKindAttr, strings.ToLower(string(block.Kind))),
			log.String(telemetryattrs.LogMediaMIMETypeAttr, block.MIMEType),
			// The attribute is a base64 string: the UI decodes it (dagui).
			log.String(telemetryattrs.LogMediaDataAttr, base64.StdEncoding.EncodeToString(block.Data)),
		)
		telemetry.Logger(ctx, InstrumentationLibrary).Emit(ctx, rec)
	case LLMContentToolResult:
		if len(block.Content) == 0 {
			fmt.Fprint(stdout, block.Text+suffix)
			return
		}
		if block.Text != "" {
			fmt.Fprintln(stdout, block.Text)
		}
		for i, child := range block.Content {
			childSuffix := "\n"
			if i == len(block.Content)-1 {
				childSuffix = suffix
			}
			emitContentLog(ctx, stdout, child, childSuffix, attrs...)
		}
	default:
		fmt.Fprint(stdout, block.ContentText()+suffix)
	}
}

// emitToolResultLogs is shared by live execution and history replay. Keep the
// all-text path intact (including patch detection), splitting only media-bearing
// results into ordered text and attachment records.
func emitToolResultLogs(ctx context.Context, result *LLMContentBlock) {
	text := result.ContentText()
	attrs := []log.KeyValue{log.Bool(telemetry.LogsVerboseAttr, true)}
	if contentType := toolResultContentType(text); contentType != "" {
		attrs = append(attrs, log.String(telemetry.ContentTypeAttr, contentType))
	}
	stdio := telemetry.SpanStdio(ctx, InstrumentationLibrary, attrs...)
	defer stdio.Close()
	if llmContentHasMedia(result.Content) {
		emitContentLog(ctx, stdio.Stdout, result, "\n", attrs...)
	} else {
		fmt.Fprintln(stdio.Stdout, text)
	}
}

func llmContentHasMedia(blocks []*LLMContentBlock) bool {
	for _, block := range blocks {
		if block == nil {
			continue
		}
		switch block.Kind {
		case LLMContentImage, LLMContentAudio, LLMContentDocument:
			return true
		}
	}
	return false
}

// displayPhase tracks a single display span for streaming LLM content
// (text response, thinking, or tool call arguments). The span names, emojis and
// attributes mirror emitMessageSpan so a live turn and a history-emitted turn
// render identically; the difference is only that these stream token-by-token.
type displayPhase struct {
	ctx  context.Context
	span trace.Span

	// Stdio wraps the span's log output.
	Stdio telemetry.SpanStreams

	// MarkdownW is set for text/thinking phases that stream markdown.
	MarkdownW io.Writer

	// callID is set for tool call phases.
	callID              string
	toolArgsWritten     bool
	toolArgsEndsNewline bool
}

// displayPhases manages the lifecycle of display spans during LLM streaming.
// It is used by all providers to create, track, and close display phases for
// text responses, thinking blocks, and tool call arguments.
type displayPhases struct {
	parentCtx  context.Context
	callDigest string

	// tools are the tools offered to the model this turn, so a tool call's
	// span can identify its tool (bare name, server) from the moment it starts.
	tools []LLMTool

	// toolAnchorCtx is the most recent non-tool assistant content phase. Tool
	// calls are parented beneath it so they read as details of the reply that
	// introduced them instead of as unrelated top-level messages. Parallel tool
	// calls share the same anchor.
	toolAnchorCtx context.Context

	mu     sync.Mutex
	phases map[int64]*displayPhase

	// displaySpans collects closed phases' spans in order.
	displaySpans []trace.Span

	// toolCalls maps call IDs to their display context and span,
	// so that tool execution can be parented beneath them and
	// spans can be ended individually.
	toolCalls map[string]toolCallDisplay
}

// toolCallDisplay bundles the context and span for a tool call's display phase.
type toolCallDisplay struct {
	Ctx  context.Context
	Span trace.Span
}

func newDisplayPhases(parentCtx context.Context, callDigest string, tools []LLMTool) *displayPhases {
	return &displayPhases{
		parentCtx:  parentCtx,
		callDigest: callDigest,
		tools:      tools,
		phases:     map[int64]*displayPhase{},
		toolCalls:  map[string]toolCallDisplay{},
	}
}

// displayAttrs appends the enclosing agent's standard identity and the LLM
// call digest, when present, so live display spans match emitMessageSpan.
func (dp *displayPhases) displayAttrs(attrs []attribute.KeyValue) []attribute.KeyValue {
	attrs = append(attrs, genAIAgentAttrsFromContext(dp.parentCtx)...)
	if dp.callDigest != "" {
		attrs = append(attrs, attribute.String(telemetryattrs.LLMCallDigestAttr, dp.callDigest))
	}
	return attrs
}

// StartText creates or returns the text response display phase at the given
// index. Text phases get markdown content type.
func (dp *displayPhases) StartText(idx int64) *displayPhase {
	dp.mu.Lock()
	defer dp.mu.Unlock()
	if p, ok := dp.phases[idx]; ok {
		return p
	}
	phaseCtx, span := Tracer(dp.parentCtx).Start(dp.parentCtx, "LLM response",
		trace.WithAttributes(dp.displayAttrs([]attribute.KeyValue{
			attribute.String(telemetry.UIActorEmojiAttr, "🤖"),
			attribute.String(telemetry.UIMessageAttr, telemetry.UIMessageReceived),
			attribute.String(telemetry.LLMRoleAttr, telemetry.LLMRoleAssistant),
		})...),
	)
	dp.toolAnchorCtx = phaseCtx
	p := &displayPhase{
		ctx:  phaseCtx,
		span: span,
	}
	p.Stdio = telemetry.SpanStdio(phaseCtx, InstrumentationLibrary)
	p.MarkdownW = telemetry.NewWriter(phaseCtx, InstrumentationLibrary,
		log.String(telemetry.ContentTypeAttr, "text/markdown"))
	dp.phases[idx] = p
	return p
}

// StartThinking creates or returns a thinking display phase at the given index.
func (dp *displayPhases) StartThinking(idx int64) *displayPhase {
	dp.mu.Lock()
	defer dp.mu.Unlock()
	if p, ok := dp.phases[idx]; ok {
		return p
	}
	phaseCtx, span := Tracer(dp.parentCtx).Start(dp.parentCtx, "thinking",
		trace.WithAttributes(dp.displayAttrs([]attribute.KeyValue{
			attribute.String(telemetry.UIActorEmojiAttr, "💭"),
			attribute.String(telemetry.UIMessageAttr, telemetry.UIMessageReceived),
			attribute.String(telemetry.LLMRoleAttr, telemetry.LLMRoleAssistant),
			attribute.Bool("llm.thinking", true),
		})...),
	)
	dp.toolAnchorCtx = phaseCtx
	p := &displayPhase{
		ctx:  phaseCtx,
		span: span,
	}
	p.Stdio = telemetry.SpanStdio(phaseCtx, InstrumentationLibrary,
		log.String(telemetry.ContentTypeAttr, "text/markdown"),
		log.Bool("llm.thinking", true),
	)
	dp.phases[idx] = p
	return p
}

// StartToolCall creates or returns a tool call display phase at the given
// index. Tool call phases stream JSON arguments, and their span parents the
// tool's execution so its sub-spans and logs roll up beneath the call.
func (dp *displayPhases) StartToolCall(idx int64, callID, toolName string) *displayPhase {
	dp.mu.Lock()
	defer dp.mu.Unlock()
	if p, ok := dp.phases[idx]; ok {
		return p
	}
	parentCtx := dp.parentCtx
	if dp.toolAnchorCtx != nil {
		parentCtx = dp.toolAnchorCtx
	}
	// Identify the tool up front: live telemetry only exports a span at start
	// and end, so a name and server set once the tool runs (MCP.CallContent)
	// would show the raw model-facing name until the call finished.
	toolAttrs := []attribute.KeyValue{attribute.String(telemetry.LLMToolAttr, toolName)}
	for i := range dp.tools {
		if dp.tools[i].Name == toolName {
			toolAttrs = toolSpanAttrs(&dp.tools[i])
			break
		}
	}
	phaseCtx, span := Tracer(parentCtx).Start(parentCtx, toolName,
		trace.WithAttributes(dp.displayAttrs(append([]attribute.KeyValue{
			attribute.String(telemetry.UIActorEmojiAttr, "🤖"),
			attribute.String(telemetry.LLMRoleAttr, telemetry.LLMRoleAssistant),
			attribute.Bool(telemetry.UIBoundaryAttr, true),
			attribute.Bool(telemetry.UIRollUpSpansAttr, true),
			attribute.Bool(telemetry.UIRollUpLogsAttr, true),
		}, toolAttrs...))...),
	)
	p := &displayPhase{
		ctx:    phaseCtx,
		span:   span,
		callID: callID,
	}
	p.Stdio = telemetry.SpanStdio(phaseCtx, InstrumentationLibrary,
		log.String(telemetry.ContentTypeAttr, "application/json"),
		log.Bool(telemetry.LogsVerboseAttr, true))
	dp.phases[idx] = p
	return p
}

func (p *displayPhase) writeToolArgs(args string) {
	if args == "" {
		return
	}
	fmt.Fprint(p.Stdio.Stdout, args)
	p.toolArgsWritten = true
	p.toolArgsEndsNewline = args[len(args)-1] == '\n'
}

// EmitToolCall records a fully-accumulated tool call as a display phase: it
// opens the tool-call span, writes its arguments, and closes the phase so the
// span is handed back for execution nesting. Use this for providers that
// deliver tool calls whole rather than streaming their arguments.
func (dp *displayPhases) EmitToolCall(idx int64, callID, toolName, args string) {
	p := dp.StartToolCall(idx, callID, toolName)
	p.writeToolArgs(args)
	dp.Close(idx)
}

// Phase returns the phase at the given index, or nil if none exists.
func (dp *displayPhases) Phase(idx int64) *displayPhase {
	dp.mu.Lock()
	defer dp.mu.Unlock()
	return dp.phases[idx]
}

// Close closes the phase at the given index, ending its stdio and collecting
// its span. Tool call phases are recorded in toolCalls so the evaluation loop
// can parent the tool's execution beneath them and end them individually. Safe
// to call multiple times for the same index.
func (dp *displayPhases) Close(idx int64) {
	dp.mu.Lock()
	defer dp.mu.Unlock()
	p, ok := dp.phases[idx]
	if !ok {
		return
	}
	if p.callID != "" && p.toolArgsWritten && !p.toolArgsEndsNewline {
		// Tool results may be routed into the same display stream. Terminate the
		// JSON arguments so the first result line cannot be glued to the closing
		// brace.
		fmt.Fprintln(p.Stdio.Stdout)
	}
	p.Stdio.Close()
	dp.displaySpans = append(dp.displaySpans, p.span)
	if p.callID != "" {
		dp.toolCalls[p.callID] = toolCallDisplay{
			Ctx:  p.ctx,
			Span: p.span,
		}
	}
	delete(dp.phases, idx)
}

// CloseAll closes any remaining open phases.
func (dp *displayPhases) CloseAll() {
	dp.mu.Lock()
	idxs := make([]int64, 0, len(dp.phases))
	for idx := range dp.phases {
		idxs = append(idxs, idx)
	}
	dp.mu.Unlock()
	for _, idx := range idxs {
		dp.Close(idx)
	}
}

// Abort records an error on all display spans and ends them. Called when
// SendQuery fails and the spans won't be returned to the caller (e.g. between
// retry attempts).
func (dp *displayPhases) Abort(err error) {
	dp.CloseAll()
	for _, s := range dp.displaySpans {
		s.RecordError(err)
		s.End()
	}
	dp.displaySpans = nil
	dp.toolCalls = nil
}

// Response returns the display-related fields to attach to an LLMResponse: the
// closed spans in order, and the tool-call spans keyed by call ID. Text and
// thinking spans are already ended; tool-call spans stay open so the loop can
// nest execution under them.
func (dp *displayPhases) Response() (displaySpans []trace.Span, toolCalls map[string]toolCallDisplay) {
	return dp.displaySpans, dp.toolCalls
}
