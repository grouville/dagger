package schema

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/dagql/call"
	"github.com/dagger/dagger/dagql/introspection"
	bkcache "github.com/dagger/dagger/engine/snapshots"
)

type SchemaResolvers interface {
	Install(*dagql.Server)
}

// Nesting is opt-out in the v1.0 API. Older views retain the
// experimentalPrivilegedNesting opt-in argument and behavior.
//
// This shipped after v1.0.0-beta.14, but views cannot tell v1.0.0 prereleases
// apart (see engine.APIViewVersion), so every v1.0.0 prerelease caller gets
// it.
const defaultNestingVersion = "v1.0.0-0"

// Container.withGPU is available in the v1.0 API. Older views keep the
// experimentalWithGPU and experimentalWithAllGPUs names undecorated; newer
// views still accept them, marked deprecated, so released callers keep
// working.
//
// Like defaultNestingVersion, this shipped after v1.0.0-beta.14 but reaches
// every v1.0.0 prerelease caller.
const gpuAPIVersion = "v1.0.0-0"

// From the v1.0 API on, withExec writes a redirected stdout/stderr only to its
// file. Older views keep logging it too.
const redirectNotLoggedVersion = "v1.0.0-0"

// Newer views still accept experimentalPrivilegedNesting so existing callers
// keep working, but ignore it: nesting is already the default.
var (
	disableNestingArg = dagql.Arg("disableDaggerInDagger").
				View(AfterVersion(defaultNestingVersion)).
				Doc(`Disable Dagger API access for the executed command. By default, commands can connect to the current Dagger engine.`)
	legacyNestingArg = dagql.Arg("experimentalPrivilegedNesting").
				View(BeforeVersion(defaultNestingVersion)).
				Doc(`Provides Dagger access to the executed command.`)
	deprecatedNestingArg = dagql.Arg("experimentalPrivilegedNesting").
				View(AfterVersion(defaultNestingVersion)).
				Deprecated(`Commands can access Dagger by default. Use "disableDaggerInDagger" to opt out.`)
	newSessionNestingArg = dagql.Arg("daggerInDaggerNewSession").
				View(AfterVersion(defaultNestingVersion)).
				Doc(`Connect Dagger clients started by the command to the current engine as new sessions, instead of as clients of the current session. Each connection gets its own session, released when that client closes.`,
			`The command reaches the engine through DAGGER_ENGINE, so SDKs run a Dagger CLI: set _EXPERIMENTAL_DAGGER_CLI_BIN to one in the container, or let the SDK download one.`,
			`Cannot be combined with "disableDaggerInDagger".`)
)

// v1Nesting resolves the v1.0 nesting arguments to whether the command joins
// the current session as a nested client.
func v1Nesting(disable, newSession bool) (bool, error) {
	if disable && newSession {
		return false, fmt.Errorf(`cannot set both "disableDaggerInDagger" and "daggerInDaggerNewSession"`)
	}
	return !disable && !newSession, nil
}

func Syncer[T dagql.Typed]() dagql.Field[T] {
	return dagql.NodeFunc("sync", func(ctx context.Context, self dagql.ObjectResult[T], args struct {
		Recipe bool `default:"false" internal:"true"`
	}) (res dagql.Result[dagql.ID[T]], _ error) {
		if _, ok := dagql.UnwrapAs[dagql.HasLazyEvaluation](self); ok {
			cache, err := dagql.EngineCache(ctx)
			if err != nil {
				return res, err
			}
			if err := cache.Evaluate(ctx, self); err != nil {
				return res, err
			}
		} else {
			syncable, ok := dagql.UnwrapAs[core.Syncable](self)
			if !ok {
				return res, fmt.Errorf("internal error: %T does not support sync", self.Self())
			}
			if err := syncable.Sync(ctx); err != nil {
				return res, err
			}
		}
		var selfID *call.ID
		var err error
		if args.Recipe {
			selfID, err = self.RecipeID(ctx)
		} else {
			selfID, err = self.ID()
		}
		if err != nil {
			return res, err
		}
		id := dagql.NewID[T](selfID)
		return dagql.NewResultForCurrentCall(ctx, id)
	}).DoNotCache("sync is an operational boundary and each object already controls its own underlying lazy/cached state")
}

func collectInputsSlice[T dagql.Type](inputs []dagql.InputObject[T]) []T {
	ts := make([]T, len(inputs))
	for i, input := range inputs {
		ts[i] = input.Value
	}
	return ts
}

func collectIDObjectResults[T dagql.Typed](ctx context.Context, srv *dagql.Server, ids []dagql.ID[T]) ([]dagql.ObjectResult[T], error) {
	ts := make([]dagql.ObjectResult[T], len(ids))
	for i, id := range ids {
		inst, err := id.Load(ctx, srv)
		if err != nil {
			return nil, err
		}
		ts[i] = inst
	}
	return ts, nil
}

func asArrayInput[T any, I dagql.Input](ts []T, conv func(T) I) dagql.ArrayInput[I] {
	ins := make(dagql.ArrayInput[I], len(ts))
	for i, v := range ts {
		ins[i] = conv(v)
	}
	return ins
}

func SchemaIntrospectionJSON(ctx context.Context, dag *dagql.Server) (json.RawMessage, error) {
	data, err := dag.Query(ctx, introspection.Query, nil)
	if err != nil {
		return nil, fmt.Errorf("introspection query failed: %w", err)
	}
	jsonBytes, err := json.Marshal(data)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal introspection result: %w", err)
	}
	return json.RawMessage(jsonBytes), nil
}

func ptr[T any](v T) *T {
	return &v
}

var AllVersion = core.AllVersion

type BeforeVersion = core.BeforeVersion
type AfterVersion = core.AfterVersion

// evaluatedDirectory returns a Directory that carries its saved operation,
// already built: the field did this work at the call before it saved the
// operation.
func evaluatedDirectory(ctx context.Context, query *core.Query, lazy core.Lazy[*core.Directory]) (*core.Directory, error) {
	dir := &core.Directory{
		Platform: query.Platform(),
		Dir:      new(core.LazyAccessor[string, *core.Directory]),
		Snapshot: new(core.LazyAccessor[bkcache.ImmutableRef, *core.Directory]),
		Lazy:     lazy,
	}
	if err := lazy.Evaluate(ctx, dir); err != nil {
		return nil, err
	}
	return dir, nil
}

// evaluatedFile is evaluatedDirectory for a File.
func evaluatedFile(ctx context.Context, query *core.Query, lazy core.Lazy[*core.File]) (*core.File, error) {
	file := &core.File{
		Platform: query.Platform(),
		File:     new(core.LazyAccessor[string, *core.File]),
		Snapshot: new(core.LazyAccessor[bkcache.ImmutableRef, *core.File]),
		Lazy:     lazy,
	}
	if err := lazy.Evaluate(ctx, file); err != nil {
		return nil, err
	}
	return file, nil
}
