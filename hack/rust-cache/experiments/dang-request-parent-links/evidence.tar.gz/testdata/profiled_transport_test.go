package dangshared

import (
	"bytes"
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strconv"
	"testing"

	"github.com/dagger/dagger/engine/wcprof"
	"github.com/stretchr/testify/require"
)

type parentTestTransport struct {
	call func(*http.Request) (*http.Response, error)
}

func (transport parentTestTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	return transport.call(req)
}

func TestProfiledNestedTransportPreservesHTTPCall(t *testing.T) {
	wcprof.EnsureRecorder()
	for _, profiled := range []bool{false, true} {
		t.Run(strconv.FormatBool(profiled), func(t *testing.T) {
			type scopeKey struct{}
			ctx := context.WithValue(t.Context(), scopeKey{}, "invocation")
			if profiled {
				var op *wcprof.Op
				ctx, op = wcprof.BeginOp(wcprof.ContextWithProfiling(ctx), wcprof.OpKindInternal, "test.api", wcprof.OpOpts{})
				defer op.End(wcprof.OutcomeOK)
			}
			req, err := http.NewRequestWithContext(ctx, "POST", "http://localhost/query", bytes.NewBufferString("body"))
			require.NoError(t, err)
			req.Header.Set("X-Caller", "preserved")
			response := &http.Response{StatusCode: 409}
			cause := errors.New("transport error")
			transport := profiledNestedTransport{RoundTripper: parentTestTransport{call: func(got *http.Request) (*http.Response, error) {
				require.Equal(t, req.URL, got.URL)
				require.Equal(t, req.Method, got.Method)
				require.True(t, req.Body == got.Body, "request body changed")
				require.Equal(t, "invocation", got.Context().Value(scopeKey{}))
				require.Equal(t, "preserved", got.Header.Get("X-Caller"))
				if profiled {
					require.NotSame(t, req, got)
					require.Equal(t, strconv.FormatUint(wcprof.CurrentOpID(ctx), 10), got.Header.Get(nestedProfileParentHeader))
				} else {
					require.Same(t, req, got)
				}
				return response, cause
			}}}
			got, err := transport.RoundTrip(req)
			require.Same(t, response, got)
			require.ErrorIs(t, err, cause)
			require.Empty(t, req.Header.Get(nestedProfileParentHeader), "the caller's request was mutated")
		})
	}
}

func TestProfiledNestedHandlerPreservesContextAndIgnoresInvalidParent(t *testing.T) {
	for _, text := range []string{"", "0", "-1", "invalid", "18446744073709551616", "42"} {
		t.Run(text, func(t *testing.T) {
			ctx, cancel := context.WithCancel(wcprof.ContextWithOpID(t.Context(), 17))
			cancel()
			req := httptest.NewRequest("POST", "/query", nil).WithContext(ctx)
			req.Header.Set(nestedProfileParentHeader, text)
			want := uint64(17)
			if text == "42" {
				want = 42
			}
			called := false
			handler := profiledNestedHandler{Handler: http.HandlerFunc(func(w http.ResponseWriter, got *http.Request) {
				called = true
				require.Equal(t, want, wcprof.CurrentOpID(got.Context()))
				require.ErrorIs(t, got.Context().Err(), context.Canceled)
				w.WriteHeader(204)
			})}
			response := httptest.NewRecorder()
			handler.ServeHTTP(response, req)
			require.True(t, called)
			require.Equal(t, 204, response.Code)
			require.Equal(t, uint64(17), wcprof.CurrentOpID(req.Context()))
		})
	}
}
