package dangshared

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"testing"
	"time"

	"github.com/Khan/genqlient/graphql"
	"github.com/dagger/dagger/engine/wcprof"
	"github.com/stretchr/testify/require"
)

func TestProfiledNestedHTTPParents(t *testing.T) {
	wcprof.EnsureRecorder()
	ctx, cancel := context.WithTimeout(wcprof.ContextWithProfiling(t.Context()), 10*time.Second)
	defer cancel()
	ctx, evaluation := wcprof.BeginOp(ctx, wcprof.OpKindInternal, "test.evaluation", wcprof.OpOpts{})
	entered := make(chan uint64, 2)
	release := make(chan struct{})
	server := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, op := wcprof.BeginOp(wcprof.ContextWithProfiling(r.Context()), wcprof.OpKindSessionPhase, "test.serveQuery", wcprof.OpOpts{})
		entered <- op.ID()
		select {
		case <-release:
			_ = json.NewEncoder(w).Encode(map[string]any{"data": map[string]string{"value": "ok"}})
			op.End(wcprof.OutcomeOK)
		case <-r.Context().Done():
			op.EndErr(r.Context().Err())
		}
	})}
	backendIDs := make([]uint64, 0, 2)
	out, err := serveNestedClient(ctx, server, http.DefaultTransport.(*http.Transport).Clone(), func(ctx context.Context, client graphql.Client) ([]byte, error) {
		defer close(release)
		failures := make(chan error, 2)
		for range 2 {
			go func() {
				var got struct {
					Value string `json:"value"`
				}
				err := client.MakeRequest(ctx, &graphql.Request{Query: "query { value }"}, &graphql.Response{Data: &got})
				if err == nil && got.Value != "ok" {
					err = errors.New("response changed")
				}
				failures <- err
			}()
		}
		for range 2 {
			select {
			case id := <-entered:
				backendIDs = append(backendIDs, id)
			case <-ctx.Done():
				return nil, ctx.Err()
			}
		}
		// Release both overlapping requests before collecting their responses.
		go func() { release <- struct{}{}; release <- struct{}{} }()
		first, second := <-failures, <-failures
		return []byte("done"), errors.Join(first, second)
	})
	evaluation.EndErr(err)
	require.NoError(t, err)
	require.Equal(t, []byte("done"), out)
	var dump bytes.Buffer
	require.NoError(t, wcprof.Active().WriteDump(&dump, false))
	header, events, err := wcprof.ReadDump(&dump)
	require.NoError(t, err)
	apiIDs := map[uint64]bool{}
	byID := map[uint64]wcprof.DumpEvent{}
	for _, event := range events {
		if event.Type != "op" {
			continue
		}
		byID[event.OpID] = event
		if header.Strings[event.ClassID] == "dang.apiRequest" && event.ParentID == evaluation.ID() {
			apiIDs[event.OpID] = true
		}
	}
	require.Len(t, apiIDs, 2)
	parents := map[uint64]bool{}
	for _, id := range backendIDs {
		require.Contains(t, byID, id)
		parent := byID[id].ParentID
		require.True(t, apiIDs[parent], "backend %d was not parented to its own recorded API request (%d)", id, parent)
		parents[parent] = true
	}
	require.Len(t, parents, 2, "overlapping requests were assigned the same API parent")
}
