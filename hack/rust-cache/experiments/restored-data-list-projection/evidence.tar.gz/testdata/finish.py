from pathlib import Path
import json
import os
import statistics
import subprocess
import time
import urllib.request

p = Path(__file__).parent
summary = json.loads((p / 'full-command-paired/summary.json').read_text())
samples = json.loads((p / 'full-command-paired/samples.json').read_text())
assert summary['all_commands_succeeded'] and summary['same_rows']
assert len(samples) == 10 and all(row['exit_code'] == 0 for row in samples)

command = ['python3',
    '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py',
    'restored-data-list-projection-after-cohort']
started = time.monotonic()
with (p / 'retained-after-cohort.log').open('w') as output:
    result = subprocess.run(command, env=os.environ, stdout=output, stderr=subprocess.STDOUT)
validation = dict(label='retained-after-cohort', command=command,
                  seconds=time.monotonic()-started, exit_code=result.returncode)
(p / 'followup-validation.json').write_text(json.dumps([validation], indent=2) + '\n')
print(json.dumps(validation), flush=True)
assert result.returncode == 0, (p / 'retained-after-cohort.log').read_text()[-5000:]

selected = (summary['faster_successful_pairs'] == 4 and
            summary['median_allocated_bytes']['after'] < summary['median_allocated_bytes']['before'])
debug = 'http://127.0.0.1:16104/debug/'


def get(route, data=None):
    with urllib.request.urlopen(urllib.request.Request(debug + route, data=data), timeout=20) as response:
        return json.load(response)


assert get('scalar-list-projection')['enabled']
assert get('native-search-projection')['enabled']
assert get('restored-data-list-projection')['enabled']
assert not get('upstream-leaf-arrays')['enabled']
for route in ['native-search-projection', 'restored-data-list-projection']:
    assert get(route + '?enabled=' + str(selected).lower(), b'')['enabled'] == selected
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == dict(mutex_fraction=0, block_profile_rate_ns=0)

pairs = []
for pair in range(1, 5):
    before = next(r for r in samples if r['pair'] == pair and r['arm'] == 'before')
    after = next(r for r in samples if r['pair'] == pair and r['arm'] == 'after')
    pairs.append(dict(pair=pair, before_seconds=before['seconds'], after_seconds=after['seconds'],
                      saved_seconds=before['seconds']-after['seconds'],
                      allocated_bytes={arm: row['heap_delta']['TotalAlloc']
                                       for arm, row in [('before', before), ('after', after)]},
                      class_slots={arm: [row['gc_before']['metadata_estimate']['ClassSlotCount'],
                                         row['gc_after']['metadata_estimate']['ClassSlotCount']]
                                   for arm, row in [('before', before), ('after', after)]}))
derived = dict(pairs=pairs, median_paired_saved_seconds=statistics.median(r['saved_seconds'] for r in pairs),
               max_host_pressure={k: max(row['pressure'][k] for row in samples)
                                  for k in ['host.cpu.some', 'host.io.some', 'host.memory.some']})
(p / 'full-command-derived.json').write_text(json.dumps(derived, indent=2) + '\n')
routes = list(json.loads((p / 'activation.json').read_text())['modes'])
state = dict(engine_sha256=json.loads((p / 'engine-builds.json').read_text())[1]['sha256'],
             scope='Retained Go diagnostic; no new Rust timing claim. Native SearchResult scalar projection includes guarded inline values restored from the persisted parent list.',
             native_search_projection=selected, restored_data_list_projection=selected,
             scalar_list_projection=True, same_owned_volume=True, telemetry=True,
             ordinary_gc=True, new_upstream_proposal=False,
             latest_matched_cohort=summary, modes={route: get(route) for route in routes})
(p / 'selected-state.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps(dict(candidate_selected=selected, summary=summary,
                     median_paired_saved_seconds=derived['median_paired_saved_seconds']), indent=2), flush=True)
