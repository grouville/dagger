package schema

import (
	"context"
	"fmt"
	"testing"

	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine"
	"github.com/stretchr/testify/require"
)

func searchProjectionFixture(t testing.TB, count int, paths ...string) (context.Context, *dagql.Server, *dagql.Cache) {
	t.Helper()
	ctx := engine.ContextWithClientMetadata(t.Context(), &engine.ClientMetadata{
		ClientID: "search-projection", SessionID: "search-projection",
	})
	path := ""
 if len(paths) > 0 { path = paths[0] }
 cache, err := dagql.NewCache(ctx, path, nil, nil)
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, cache.CloseDiscardingPersistence()) })
	ctx = dagql.ContextWithCache(ctx, cache)
	srv, err := dagql.NewServer(ctx, core.NewRoot(nil))
	require.NoError(t, err)
	(&directorySchema{}).Install(srv)
	dagql.Fields[*core.Query]{dagql.Func("searchFixture", func(_ context.Context, _ *core.Query, args struct{ Generation int }) (dagql.Array[*core.SearchResult], error) {
		results := make(dagql.Array[*core.SearchResult], count)
		for i := range results {
			results[i] = &core.SearchResult{
				FilePath: fmt.Sprintf("src/%d-%d.go", args.Generation, i), LineNumber: i + 1,
				AbsoluteOffset: i * 32, MatchedLines: fmt.Sprintf("line %d: λ <&>\n", args.Generation),
				Submatches: []*core.SearchSubmatch{{Text: "λ", Start: 0, End: 2}},
			}
		}
		return results, nil
	}).IsPersistable()}.Install(srv)
	return ctx, srv, cache
}

func TestSearchMetadataProjectionPreservesIDs(t *testing.T) {
	ctx, srv, cache := searchProjectionFixture(t, 3)
	selector := dagql.Selector{Field: "searchFixture", Args: []dagql.NamedInput{{Name: "generation", Value: dagql.Int(0)}}}
	_, err := srv.Root().Select(ctx, srv, selector)
	require.NoError(t, err)
	before := cache.EntryStats().CompletedCalls
	got, err := srv.Query(ctx, `{searchFixture(generation:0){filePath lineNumber absoluteOffset matchedLines}}`, nil)
	require.NoError(t, err)
	require.Equal(t, []any{
		map[string]any{"filePath": dagql.String("src/0-0.go"), "lineNumber": dagql.Int(1), "absoluteOffset": dagql.Int(0), "matchedLines": dagql.String("line 0: λ <&>\n")},
		map[string]any{"filePath": dagql.String("src/0-1.go"), "lineNumber": dagql.Int(2), "absoluteOffset": dagql.Int(32), "matchedLines": dagql.String("line 0: λ <&>\n")},
		map[string]any{"filePath": dagql.String("src/0-2.go"), "lineNumber": dagql.Int(3), "absoluteOffset": dagql.Int(64), "matchedLines": dagql.String("line 0: λ <&>\n")},
	}, got["searchFixture"])
	require.Equal(t, before, cache.EntryStats().CompletedCalls, "reading metadata must retain the list without attaching each item")

	var rows dagql.ObjectResultArray[*core.SearchResult]
	require.NoError(t, srv.Select(ctx, srv.Root(), &rows, selector))
	require.Len(t, rows, 3)
	_, err = srv.Query(ctx, `{searchFixture(generation:1){filePath matchedLines}}`, nil)
	require.NoError(t, err)
	for i, row := range rows {
		id, err := row.ID()
		require.NoError(t, err)
		loaded, err := srv.Load(ctx, id)
		require.NoError(t, err)
		var filePath dagql.String
		require.NoError(t, srv.Select(ctx, loaded, &filePath, dagql.Selector{Field: "filePath"}))
		require.Equal(t, dagql.String(fmt.Sprintf("src/0-%d.go", i)), filePath)
	}
	got, err = srv.Query(ctx, `{searchFixture(generation:2){submatches{text start end}}}`, nil)
	require.NoError(t, err)
	expected := map[string]any{"submatches": []any{map[string]any{"text": dagql.String("λ"), "start": dagql.Int(0), "end": dagql.Int(2)}}}
	require.Equal(t, []any{expected, expected, expected}, got["searchFixture"])
}

func BenchmarkSearchMetadataProjection(b *testing.B) {
	for _, count := range []int{1, 8, 128} {
		for _, fresh := range []bool{false, true} {
			b.Run(fmt.Sprintf("%d/fresh=%t", count, fresh), func(b *testing.B) {
				ctx, srv, _ := searchProjectionFixture(b, count)
				query := `query($g:Int!){searchFixture(generation:$g){filePath matchedLines}}`
				generation := 0
				_, err := srv.Query(ctx, query, map[string]any{"g": generation})
				require.NoError(b, err)
				b.ReportAllocs()
				for b.Loop() {
					if fresh {
						generation++
					}
					got, err := srv.Query(ctx, query, map[string]any{"g": generation})
					require.NoError(b, err)
					require.Len(b, got["searchFixture"], count)
				}
			})
		}
	}
}
