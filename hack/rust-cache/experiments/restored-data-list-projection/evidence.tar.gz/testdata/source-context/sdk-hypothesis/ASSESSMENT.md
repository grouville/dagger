# Materialized-list batching hypothesis: rejected for this listing

The actual core and module-facing File.search and Workspace.search signatures return object lists. The scalar-ID-return hypothesis is false for this case. The exact direct, fold and helper expressions issue one bulk query each under the selected SDK library and real module-facing schema. The initial harness corrections (parser import alias and hidden currentWorkspace field) are preserved.

Grouping existing wcprof operations is decisive: 4,398 SearchResult.search indexed loads occur within 895 session.query operations, often many items per request. They are not 4,398 HTTP requests. All 1,049 File.search calls hit cached parents. The SDK generic ListValue path is real but is not established as the cause here; do not build a batching fix on that attribution.

A real cache save/reopen reproduces a different gap. A fresh native search list is Array[*core.SearchResult] and metadata reads retain one cache entry. After reopening it is DynamicResultArrayOutput, and the same three-result read creates four entries. The regression fails without a guarded restored-list bridge and passes with it. The candidate work continues in ../restored-data-list-projection; no full-command improvement is claimed yet.

Existing debug query logs sampled only native-cache calls and do not identify the Go requests. No query-shape instrumentation or new engine was installed during this SDK verification. The earlier claim that every remaining indexed call was a separate query is rejected. Preserve the raw grouping and findings when updating the public study.
