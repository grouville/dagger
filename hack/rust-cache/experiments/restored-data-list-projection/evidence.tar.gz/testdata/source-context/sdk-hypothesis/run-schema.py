from pathlib import Path
import os
import subprocess

p = Path(__file__).parent
base = p.parent
env = dict(os.environ,
    RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16276',
    RUST_CACHE_BENCH_CLI=str(base/'filesync-literal-pathwalk/dagger-after'),
    RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',
    _EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15',
    _EXPERIMENTAL_DAGGER_CLI_BIN=str(base/'dagger-artifact-workspace-before'))
command = ['python3', str(base/'local_cli_collector.py'), 'api', 'with-session', '--',
           'python3', str(p/'inspect-schema.py')]
with (p/'schema-inspection-v3.log').open('w') as output:
    result = subprocess.run(command, cwd='/tmp/dagger-go-real-repository-main', env=env,
                            stdout=output, stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
