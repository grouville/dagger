from pathlib import Path
import base64
import json
import os
import urllib.request

p = Path(__file__).parent
token = os.environ.get('DAGGER_SESSION_TOKEN', '')
headers = {'Content-Type': 'application/json',
           'Authorization': 'Basic ' + base64.b64encode((token+':').encode()).decode()}
endpoint = 'http://127.0.0.1:' + os.environ['DAGGER_SESSION_PORT'] + '/query'


def query(document):
    request = urllib.request.Request(endpoint, data=json.dumps({'query': document}).encode(), headers=headers)
    with urllib.request.urlopen(request, timeout=180) as response:
        result = json.load(response)
    assert not result.get('errors'), result.get('errors')
    return result['data']


document = '''query { file:__type(name:"File") {name fields{name type{kind name ofType{kind name ofType{kind name ofType{kind name}}}}}} workspace:__type(name:"Workspace"){name fields{name type{kind name ofType{kind name ofType{kind name ofType{kind name}}}}}}}'''
core = query(document)
records = {'core': {name: [field for field in value['fields'] if field['name']=='search']
                    for name, value in core.items() if value is not None}}
module = query('''{moduleSource(ref:"/tmp/dagger-go-module-test-name-index"){introspectionSchemaJSON{contents}}}''')
raw = module['moduleSource']['introspectionSchemaJSON']['contents']
(p/'module-sdk-schema.json').write_text(raw+'\n')
data = json.loads(raw)
schema = data.get('data', data).get('__schema', data.get('schema'))
assert schema is not None, list(data)
records['module_sdk'] = {}
for typ in schema['types']:
    if typ['name'] in ['File','Workspace','SearchResult']:
        records['module_sdk'][typ['name']] = [field for field in typ.get('fields', []) if field['name'] in ['search','matchedLines','filePath']]
(p/'schema-inspection.json').write_text(json.dumps(records, indent=2)+'\n')
print(json.dumps(records, indent=2), flush=True)
