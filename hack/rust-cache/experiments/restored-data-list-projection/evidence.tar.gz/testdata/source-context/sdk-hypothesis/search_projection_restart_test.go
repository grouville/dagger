package schema

import (
	"path/filepath"
	"testing"

	"github.com/dagger/dagger/dagql"
	"github.com/stretchr/testify/require"
)

func TestSearchMetadataProjectionAfterRestart(t *testing.T) {
	path := filepath.Join(t.TempDir(), "cache.db")
	ctx, srv, cache := searchProjectionFixture(t, 3, path)
	selector := dagql.Selector{Field: "searchFixture", Args: []dagql.NamedInput{{Name: "generation", Value: dagql.Int(0)}}}
	parent, err := srv.Root().Select(ctx, srv, selector)
	require.NoError(t, err)
	t.Logf("fresh parent: %T", parent.Unwrap())
	query := `{searchFixture(generation:0){filePath matchedLines}}`
	before := cache.EntryStats().CompletedCalls
	expected, err := srv.Query(ctx, query, nil)
	require.NoError(t, err)
	require.Equal(t, before, cache.EntryStats().CompletedCalls)
	require.NoError(t, cache.ReleaseSession(ctx, "search-projection"))
	require.NoError(t, cache.Close(ctx))
	ctx, srv, cache = searchProjectionFixture(t, 3, path)
	parent, err = srv.Root().Select(ctx, srv, selector)
	require.NoError(t, err)
	t.Logf("restored parent: %T", parent.Unwrap())
	before = cache.EntryStats().CompletedCalls
	got, err := srv.Query(ctx, query, nil)
	require.NoError(t, err)
	require.Equal(t, expected, got)
	require.Equal(t, before, cache.EntryStats().CompletedCalls,
		"reading restored plain metadata must not attach an item for every value")
}
