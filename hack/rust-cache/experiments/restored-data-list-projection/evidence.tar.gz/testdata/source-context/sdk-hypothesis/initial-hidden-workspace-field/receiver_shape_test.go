package dang

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"sync"
	"testing"

	"github.com/Khan/genqlient/graphql"
	"github.com/stretchr/testify/require"
	"github.com/vektah/gqlparser/v2/ast"
	gqlparser "github.com/vektah/gqlparser/v2/parser"
	"github.com/vito/dang/v2/pkg/introspection"
)

type receiverShapeClient struct {
	mu      sync.Mutex
	queries []string
}

func (c *receiverShapeClient) MakeRequest(_ context.Context, req *graphql.Request, resp *graphql.Response) error {
	c.mu.Lock()
	c.queries = append(c.queries, req.Query)
	c.mu.Unlock()
	doc, err := gqlparser.ParseQuery(&ast.Source{Input: req.Query})
	if err != nil {
		return err
	}
	data := receiverShapeData(doc.Operations[0].SelectionSet, 0)
	payload, err := json.Marshal(data)
	if err != nil {
		return err
	}
	return json.Unmarshal(payload, resp.Data)
}

func receiverShapeData(sels ast.SelectionSet, index int) map[string]any {
	out := map[string]any{}
	for _, sel := range sels {
		switch f := sel.(type) {
		case *ast.InlineFragment:
			for name, value := range receiverShapeData(f.SelectionSet, index) {
				out[name] = value
			}
		case *ast.Field:
			name := f.Alias
			if name == "" {
				name = f.Name
			}
			switch f.Name {
			case "search":
				items := make([]any, 3)
				for i := range items {
					items[i] = receiverShapeData(f.SelectionSet, i)
				}
				out[name] = items
			case "matchedLines":
				out[name] = fmt.Sprintf("func TestName%d(t *testing.T) {}\n", index)
			case "filePath":
				out[name] = "one_test.go"
			case "id":
				out[name] = fmt.Sprintf("result-%d", index)
			case "__typename":
				out[name] = "SearchResult"
			default:
				out[name] = receiverShapeData(f.SelectionSet, index)
			}
		}
	}
	return out
}

func TestGoSearchProjectionRequestShape(t *testing.T) {
	data, err := os.ReadFile("/tmp/rust-cache-sipsma-review/sdk-materialized-list-batch/module-sdk-schema.json")
	require.NoError(t, err)
	var intro introspection.Response
	require.NoError(t, json.Unmarshal(data, &intro))
	for name, source := range map[string]string{
		"direct": "currentWorkspace.file(\"/one_test.go\").search(pattern: `^func Test`).{{matchedLines}}",
		"fold": "let empty: [String!]! = []\n[\"one_test.go\"].reduce(empty) { names, file => names + currentWorkspace.file(\"/\" + file).search(pattern: `^func Test`).{{matchedLines}}.map { match => match.matchedLines } }",
		"helper": "let names(ws: Workspace!): [String!]! { let empty: [String!]! = []\n [\"one_test.go\"].reduce(empty) { names, file => names + ws.file(\"/\" + file).search(pattern: `^func Test`).{{matchedLines}}.map { match => match.matchedLines } } }\nnames(currentWorkspace)",
	} {
		t.Run(name, func(t *testing.T) {
			client := &receiverShapeClient{}
			env := TypeScopeFromSchema("Dagger", intro.Schema)
			values := ValueScopeFromSchema(env, client, intro.Schema)
			_ = runProgram(t, env, values, source)
			t.Logf("%d requests: %s", len(client.queries), strings.Join(client.queries, "\n"))
			require.Len(t, client.queries, 1, "a selected search list should execute as one bulk query")
			require.Contains(t, client.queries[0], "matchedLines")
			require.NotContains(t, client.queries[0], "{id}")
		})
	}
}
