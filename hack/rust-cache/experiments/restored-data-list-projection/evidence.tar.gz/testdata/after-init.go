package dagql

func init() {
	scalarListProjection.Store(true)
	directTrivialScalarFields.Store(true)
	nativeSearchProjection.Store(true)
	restoredDataListProjection.Store(true)
}
