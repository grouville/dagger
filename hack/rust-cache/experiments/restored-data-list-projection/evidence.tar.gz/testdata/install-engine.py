from pathlib import Path
import hashlib
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
engine = 'dagger-rust-parser-state-pool-oct14'
debug = 'http://127.0.0.1:16104/debug/'
builds = json.loads((p / 'engine-builds.json').read_text())
assert [row['label'] for row in builds] == ['retained-before', 'engine-build']
assert all(row['exit_code'] == 0 for row in builds)
assert all(row['exit_code'] == row['expected_exit_code'] for row in json.loads((p / 'validation.json').read_text()))
binary = p / 'dagger-engine'
candidate_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
assert candidate_sha == builds[1]['sha256']
before_sha = subprocess.check_output(
    ['docker', 'exec', engine, 'sha256sum', '/usr/local/bin/dagger-engine'], text=True).split()[0]
assert before_sha == 'c07402078e15e3f8db04c4cbe26ed755b578e6d808a514be7304df8b9df75604'
before_mounts = json.loads(subprocess.check_output(['docker', 'inspect', engine]))[0]['Mounts']


def get(route, data=None):
    with urllib.request.urlopen(urllib.request.Request(debug + route, data=data), timeout=20) as response:
        return json.load(response)


def mode(route, enabled):
    result = get(route + '?enabled=' + str(enabled).lower(), b'')
    assert result['enabled'] == enabled, (route, result)


assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == {'mutex_fraction': 0, 'block_profile_rate_ns': 0}
routes = list(json.loads(Path(
    '/tmp/rust-cache-sipsma-review/native-search-data-projection/activation.json'
).read_text())['modes'])
saved = {route: get(route) for route in routes}
assert saved['scalar-list-projection']['enabled']
(p / 'modes-before-engine-replacement.json').write_text(json.dumps(saved, indent=2) + '\n')
restart = ['python3', '/tmp/rust-cache-sipsma-review/restart_owned_engine_clean.py',
           '--engine', engine, '--debug-port', '16104', '--binary', str(binary),
           '--output', str(p / 'graceful-restart')]
with (p / 'restart-driver.log').open('w') as output:
    result = subprocess.run(restart, stdout=output, stderr=subprocess.STDOUT)
assert result.returncode == 0, (p / 'restart-driver.log').read_text()[-5000:]
for route, state in saved.items():
    if 'enabled' not in state:
        continue
    if state.get('read_at'):
        assert get(route)['enabled'] == state['enabled'], route
    else:
        mode(route, state['enabled'])
get('builtin-receivers?enabled=true&record=false', b'')
get('config-declarations?enabled=true&record=false', b'')
get('span-lookup-fanout?enabled=true&record=false', b'')
assert get('collection-expansion-limit?limit=0', b'')['limit'] == 0
mode('native-search-projection', True)
mode('restored-data-list-projection', True)
assert not get('upstream-leaf-arrays')['enabled']
assert get('scalar-list-projection')['enabled']
assert not get('direct-span-protobuf')['enabled']
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == {'mutex_fraction': 0, 'block_profile_rate_ns': 0}
after_sha = subprocess.check_output(
    ['docker', 'exec', engine, 'sha256sum', '/usr/local/bin/dagger-engine'], text=True).split()[0]
after_mounts = json.loads(subprocess.check_output(['docker', 'inspect', engine]))[0]['Mounts']
assert after_sha == candidate_sha and before_mounts == after_mounts
activation = dict(before_sha256=before_sha, after_sha256=after_sha, same_mounts=True,
                  telemetry=True, ordinary_gc=True, forced_shutdown=False, volume_reset=False,
                  modes={route: get(route) for route in routes + ['restored-data-list-projection']})
(p / 'activation.json').write_text(json.dumps(activation, indent=2) + '\n')
print('PASS: controlled engine active on the same volume, prior modes restored, profiling off', flush=True)
command = ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py',
           'restored-data-list-projection-first-after']
start = time.monotonic()
with (p / 'retained-first-after.log').open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
(p / 'retained-first-after.json').write_text(json.dumps(dict(
    command=command, seconds=time.monotonic()-start, exit_code=result.returncode,
    native_search_projection=get('native-search-projection'),
    restored_data_list_projection=get('restored-data-list-projection'),
    scalar_list_projection=get('scalar-list-projection')), indent=2) + '\n')
assert result.returncode == 0, (p / 'retained-first-after.log').read_text()[-5000:]
print((p / 'retained-first-after.log').read_text(), flush=True)
