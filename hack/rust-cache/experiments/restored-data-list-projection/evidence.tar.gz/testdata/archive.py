from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path(__file__).parent
out = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/restored-data-list-projection')
summary = json.loads((root / 'full-command-paired/summary.json').read_text())
assert summary['all_commands_succeeded'] and summary['same_rows']
assert (root / 'retained-after-cohort.log').read_text().count('PASS strict-first') == 6
profile = json.loads((root / 'preflight/result.json').read_text())
assert profile['exit_code'] == 0 and profile['same_rows']
assert profile['recorder']['dropped'] == 0 and profile['recorder']['open'] == 0
selected = json.loads((root / 'selected-state.json').read_text())
context = root / 'source-context'
context.mkdir(exist_ok=True)
sources = []
for overlay_name in ['engine-overlay.json', 'before-test-overlay.json', 'after-test-overlay.json', 'dagql-test-overlay.json']:
    overlay = json.loads((root / overlay_name).read_text())['Replace']
    for destination, source in sorted(overlay.items()):
        source = Path(source)
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        target = context / (digest[:16] + '-' + source.name)
        if not target.exists():
            target.write_bytes(source.read_bytes())
        sources.append(dict(overlay=overlay_name, destination=destination,
                            original_source=str(source), archived_source=str(target.relative_to(root)),
                            sha256=digest))
(context / 'MANIFEST.json').write_text(json.dumps(sources, indent=2) + '\n')
for name, source in {
    'engine.go.mod': '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
    'engine.go.sum': '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.sum',
    'listing-protocol.py': '/tmp/rust-cache-sipsma-review/rust-go-test-collections/measure.py',
    'local_cli_collector.py': '/tmp/rust-cache-sipsma-review/local_cli_collector.py',
    'restart_owned_engine_clean.py': '/tmp/rust-cache-sipsma-review/restart_owned_engine_clean.py',
    'verify_retained_first.py': '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py',
    'go.dang': '/tmp/dagger-go-module-test-name-index/go.dang',
    'gomod-main.dang': '/tmp/dagger-go-module-test-name-index/gomod/main.dang',
}.items():
    (context / name).write_bytes(Path(source).read_bytes())
for name, source in {
    'native-search.go': '/tmp/dagger-filesync-snapshot-seeds/core/search.go',
    'native-persisted-families.go': '/tmp/dagger-filesync-snapshot-seeds/core/persisted_families.go',
    'selected-dang-ast_expressions.go': '/tmp/dang-direct-builtin-receivers/pkg/dang/ast_expressions.go',
    'selected-dang-eval.go': '/tmp/rust-cache-sipsma-review/dang-builtin-receivers/controlled-eval.go',
    'dang-querybuilder.go': '/tmp/rust-cache-sipsma-review/dang-module-blueprint-content-key/pkg/querybuilder/querybuilder.go',
}.items():
    (context / name).write_bytes(Path(source).read_bytes())

sdk = Path('/tmp/rust-cache-sipsma-review/sdk-materialized-list-batch')
for source in sorted(sdk.rglob('*')):
    if not source.is_file() or source.suffix not in {'.go', '.py', '.json', '.log', '.md'}:
        continue
    target = context / 'sdk-hypothesis' / source.relative_to(sdk)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
for suffix in ['before', 'first-after', 'after-cohort']:
    retained = Path('/tmp/rust-cache-sipsma-review') / ('native-discovery-retained-restored-data-list-projection-' + suffix)
    assert retained.is_dir(), retained
    for source in sorted(retained.rglob('*')):
        if source.is_file() and source.suffix in {'.json', '.log', '.stdout', '.stderr'}:
            target = context / retained.name / source.relative_to(retained)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
out.mkdir(exist_ok=False)
files = []
omitted = []
for source in sorted(root.rglob('*')):
    if not source.is_file():
        continue
    if source.name == 'wcprof-complete.ndjson':
        omitted.append(dict(source=str(source), sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                            reason='Reconstructable from archived compressed dump chunks and capture driver.'))
        continue
    if source.name.startswith('dagger-engine') or source.suffix == '.test':
        continue
    if source.suffix not in {'.go', '.py', '.json', '.jsonl', '.log', '.pprof', '.gz', '.txt',
                             '.stdout', '.stderr', '.md', '.mod', '.sum', '.dang', '.patch'}:
        continue
    data = source.read_bytes()
    files.append(dict(path='testdata/' + str(source.relative_to(root)), source=str(source),
                      bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
archive = out / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tf:
    for row in files:
        tf.add(row['source'], arcname=row['path'], recursive=False)
with tarfile.open(archive, 'r:gz') as tf:
    assert len(tf.getmembers()) == len(files)
    for row in files:
        data = tf.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
manifest = dict(archive=dict(path=archive.name, bytes=archive.stat().st_size,
                            sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
                files=files, omitted_reconstructable=omitted, selected=selected,
                new_pr_opened=False, new_upstream_proposal=False, all_attempts_retained=True,
                standalone_overlay_validated=False, proposed_code_selected=False,
                controlled_engine_base='19eda924854e7f22582f3a7430272aa729cbeb5f')
(out / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(files=len(files), bytes=archive.stat().st_size, members_verified=True), indent=2))
