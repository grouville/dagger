package schema

import (
	"golang.org/x/sync/errgroup"
	"path/filepath"
	"testing"

	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/dagql"
	"github.com/stretchr/testify/require"
)

func TestSearchMetadataProjectionAfterRestart(t *testing.T) {
	path := filepath.Join(t.TempDir(), "cache.db")
	ctx, srv, cache := searchProjectionFixture(t, 3, path)
	selector := dagql.Selector{Field: "searchFixture", Args: []dagql.NamedInput{{Name: "generation", Value: dagql.Int(0)}}}
	parent, err := srv.Root().Select(ctx, srv, selector)
	require.NoError(t, err)
	t.Logf("fresh parent: %T", parent.Unwrap())
	query := `{searchFixture(generation:0){filePath matchedLines}}`
	before := cache.EntryStats().CompletedCalls
	expected, err := srv.Query(ctx, query, nil)
	require.NoError(t, err)
	require.Equal(t, before, cache.EntryStats().CompletedCalls)
	require.NoError(t, cache.ReleaseSession(ctx, "search-projection"))
	require.NoError(t, cache.Close(ctx))
	ctx, srv, cache = searchProjectionFixture(t, 3, path)
	parent, err = srv.Root().Select(ctx, srv, selector)
	require.NoError(t, err)
	t.Logf("restored parent: %T", parent.Unwrap())
	before = cache.EntryStats().CompletedCalls
	got, err := srv.Query(ctx, query, nil)
	require.NoError(t, err)
	require.Equal(t, expected, got)
	require.Equal(t, before, cache.EntryStats().CompletedCalls,
		"reading restored plain metadata must not attach an item for every value")
}

func TestRestoredSearchMetadataIDsRemainLoadable(t *testing.T) {
	path := filepath.Join(t.TempDir(), "cache.db")
	ctx, srv, cache := searchProjectionFixture(t, 3, path)
	query := `{searchFixture(generation:0){filePath matchedLines}}`
	_, err := srv.Query(ctx, query, nil)
	require.NoError(t, err)
	for range 2 {
		require.NoError(t, cache.ReleaseSession(ctx, "search-projection"))
		require.NoError(t, cache.Close(ctx))
		ctx, srv, cache = searchProjectionFixture(t, 3, path)
		_, err = srv.Query(ctx, query, nil)
		require.NoError(t, err)
	}
	var rows dagql.ObjectResultArray[*core.SearchResult]
	require.NoError(t, srv.Select(ctx, srv.Root(), &rows, dagql.Selector{Field: "searchFixture", Args: []dagql.NamedInput{{Name: "generation", Value: dagql.Int(0)}}}))
	require.Len(t, rows, 3)
	for _, row := range rows {
		id, err := row.ID()
		require.NoError(t, err)
		loaded, err := srv.Load(ctx, id)
		require.NoError(t, err)
		var path dagql.String
		require.NoError(t, srv.Select(ctx, loaded, &path, dagql.Selector{Field: "filePath"}))
		require.Equal(t, dagql.String(row.Self().FilePath), path)
	}
}

func TestRestoredSearchMetadataConcurrentIDReads(t *testing.T) {
	path := filepath.Join(t.TempDir(), "cache.db")
	ctx, srv, cache := searchProjectionFixture(t, 3, path)
	_, err := srv.Query(ctx, `{searchFixture(generation:0){filePath}}`, nil)
	require.NoError(t, err)
	require.NoError(t, cache.ReleaseSession(ctx, "search-projection"))
	require.NoError(t, cache.Close(ctx))
	ctx, srv, _ = searchProjectionFixture(t, 3, path)
	var group errgroup.Group
	for range 8 {
		group.Go(func() error {
			_, err := srv.Query(ctx, `{searchFixture(generation:0){filePath matchedLines}}`, nil)
			return err
		})
		group.Go(func() error {
			var rows dagql.ObjectResultArray[*core.SearchResult]
			if err := srv.Select(ctx, srv.Root(), &rows, dagql.Selector{Field: "searchFixture", Args: []dagql.NamedInput{{Name: "generation", Value: dagql.Int(0)}}}); err != nil {
				return err
			}
			for _, row := range rows {
				id, err := row.ID()
				if err != nil {
					return err
				}
				if _, err := srv.Load(ctx, id); err != nil {
					return err
				}
			}
			return nil
		})
	}
	require.NoError(t, group.Wait())
}
