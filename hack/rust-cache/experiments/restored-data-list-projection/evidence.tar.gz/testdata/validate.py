from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
base = [go, 'test', '-p', '2', '-buildvcs=false', '-modfile',
        '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod']
steps = [
    ('before-restart', 'before-test-overlay.json', ['-count=1', '-v', '-run', '^TestSearchMetadataProjectionAfterRestart$', './core/schema'], 1),
    ('after-schema-race', 'after-test-overlay.json', ['-race', '-count=1', '-v', '-run', '^Test(SearchMetadataProjection|RestoredSearchMetadataIDs|MergeSearchResults|SearchPathInScopes|SearchSourcePaths|MergeGlobMatches)', './core/schema'], 0),
    ('after-dagql-race', 'dagql-test-overlay.json', ['-race', '-count=1', './dagql'], 0),
]
rows = []
for label, overlay, args, expected in steps:
    command = [*base, '-overlay', str(p/overlay), *args]
    start = time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds', env=env,
                                stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, seconds=time.monotonic()-start,
                     exit_code=result.returncode, expected_exit_code=expected))
    (p/'validation.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == expected, (p/(label+'.log')).read_text()[-5000:]
    if expected:
        assert 'reading restored plain metadata must not attach an item for every value' in (p/(label+'.log')).read_text()
print('PASS: cache-reopen regression, later IDs, scoped schema races and full DagQL races', flush=True)
