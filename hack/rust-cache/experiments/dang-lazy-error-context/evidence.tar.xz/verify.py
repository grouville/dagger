from pathlib import Path
import json, os, subprocess, time

p=Path(__file__).parent
base=p.parent
module=Path('/tmp/dagger-go-batch-package-discovery')
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16277',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
import urllib.request
route='http://127.0.0.1:16105/debug/lazy-eval-error-context'
def mode(enabled):
 with urllib.request.urlopen(urllib.request.Request(route+'?enabled='+str(enabled).lower(),data=b''),timeout=10) as f:return json.load(f)
with urllib.request.urlopen(route,timeout=10) as f:saved=json.load(f)['enabled']
mode(True)
try:
    rows=[]
    for check in ['go-dev:discovery-check','go-dev:package-layout-rebind-check','go-dev:tests-collection-check']:
        tick=time.monotonic();label='isolated-'+check.replace(':','-')
        with (p/(label+'.log')).open('w') as output:result=subprocess.run(['python3',str(base/'local_cli_collector.py'),'check',check],cwd=module,env=env,stdout=output,stderr=subprocess.STDOUT)
        row=dict(check=check,seconds=time.monotonic()-tick,exit_code=result.returncode)
        rows.append(row);(p/'isolated-smoke-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
        assert result.returncode==0,check
finally:
    (p/'isolated-checks-restoration.json').write_text(json.dumps(mode(saved),indent=2)+'\n')
