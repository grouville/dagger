from pathlib import Path
import json, subprocess, time
p=Path(__file__).resolve().parent
rows=[]
for arm in ['before','candidate']:
 command=['python3',str(p/'capture.py'),'--arm',arm,'--edit-test-body','--cpu-profile','--output',str(p/('capture-'+arm))]
 tick=time.monotonic()
 with (p/('capture-'+arm+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(arm=arm,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row)
 (p/'capture-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(p/('capture-'+arm+'-driver.log')).read_text()[-3000:]
