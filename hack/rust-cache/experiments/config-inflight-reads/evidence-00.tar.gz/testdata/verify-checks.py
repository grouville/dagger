from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time
import urllib.request

p = Path(__file__).parent
base = p.parent
module = Path('/tmp/dagger-go-module-test-name-index')
with urllib.request.urlopen('http://127.0.0.1:16104/debug/config-inflight-reads',timeout=20) as response:
    assert json.load(response)['enabled']
for route in ['lazy-schema-candidates', 'schema-read-buffers', 'recovered-schema-templates', 'canonical-core-providers', 'metadata-snapshot-unlocked', 'upstream-log-queue']:
    with urllib.request.urlopen('http://127.0.0.1:16104/debug/' + route, timeout=20) as response:
        assert not json.load(response)['enabled'], route

env = dict(os.environ, RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16276',
    RUST_CACHE_BENCH_CLI=str(base / 'filesync-literal-pathwalk/dagger-after'),
    RUST_CACHE_BENCH_COLLECTOR='http://' + (base / 'otlp-null-address.txt').read_text().strip() + ':43184',
    _EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
checks = []
for prefix, source in [('gomod-checks', 'gomod/.dagger/modules/e2e/main.dang'),
                       ('go-dev', '.dagger/modules/go-dev/main.dang')]:
    for line in (module / source).read_text().splitlines():
        if '@check' not in line:
            continue
        match = re.match(r'^  ([a-zA-Z][a-zA-Z0-9_]*)', line)
        assert match, line
        checks.append(prefix + ':' + re.sub(r'([A-Z])', r'-\1', match[1]).lower())
priority = ['gomod-checks:discovery-check',
            'gomod-checks:own-files-check', 'gomod-checks:skips-non-modules-check',
            'go-dev:tests-collection-check', 'go-dev:package-layout-rebind-check']
assert set(priority) <= set(checks)
checks = priority + [check for check in checks if check not in priority]
(p / 'check-plan.json').write_text(json.dumps(dict(checks=checks, module=str(module),
    source_sha256=hashlib.sha256((module / 'gomod/main.dang').read_bytes()).hexdigest(),
    execution='One check at a time; stop at first failure.'), indent=2) + '\n')

fixture = module / 'testdata/go-module-with-testdata/fixture_test.go'
original = fixture.read_bytes()
rows = []
try:
    fixture.write_bytes(original + ('\n// In-flight configuration read verification ' + str(time.time_ns()) + '\n').encode())
    for check in checks:
        begin = time.monotonic()
        with (p / (check.replace(':', '-') + '.log')).open('w') as output:
            result = subprocess.run(['python3', str(base / 'local_cli_collector.py'), 'check', check],
                cwd=module, env=env, stdout=output, stderr=subprocess.STDOUT)
        row = dict(check=check, exit_code=result.returncode, seconds=time.monotonic() - begin)
        rows.append(row)
        (p / 'correctness.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        assert result.returncode == 0, check
finally:
    fixture.write_bytes(original)
    (p / 'correctness-restoration.json').write_text(json.dumps(dict(
        fixture_restored=fixture.read_bytes() == original, completed=len(rows), planned=len(checks)), indent=2) + '\n')
