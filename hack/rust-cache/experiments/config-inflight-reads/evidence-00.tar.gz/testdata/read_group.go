package core

import (
	"bytes"
	"context"
	"errors"
	"fmt"

	"github.com/dagger/dagger/engine/engineutil"
	"golang.org/x/sync/singleflight"
)

type hostConfigRead struct {
	data  []byte
	found bool
}

type hostConfigReadGroup struct {
	reads singleflight.Group
}

var hostConfigReads hostConfigReadGroup

var errHostConfigReadCanceled = errors.New("host configuration read owner canceled")

// The engine client is session-owned. Include the host owner as well: modules
// in the same session can read from different hosts with identical paths.
func hostConfigReadKey(client *engineutil.Client, owner, path string) string {
	return fmt.Sprintf("%p:%q:%q", client, owner, path)
}

// Do shares only overlapping reads. The singleflight removes the entry before
// publishing its result, so the next call observes the host again. The first
// caller owns the I/O context; if it leaves, remaining callers retry with their
// own contexts rather than inheriting its cancellation or extending its lease.
func (g *hostConfigReadGroup) Do(
	ctx context.Context,
	key string,
	read func(context.Context) (hostConfigRead, error),
) (hostConfigRead, error) {
	for {
		if err := context.Cause(ctx); err != nil {
			return hostConfigRead{}, err
		}
		pending := g.reads.DoChan(key, func() (any, error) {
			result, err := read(ctx)
			if err != nil && context.Cause(ctx) != nil {
				return nil, errHostConfigReadCanceled
			}
			return result, err
		})
		select {
		case <-ctx.Done():
			return hostConfigRead{}, context.Cause(ctx)
		case result := <-pending:
			if errors.Is(result.Err, errHostConfigReadCanceled) {
				continue
			}
			if result.Err != nil {
				return hostConfigRead{}, result.Err
			}
			value := result.Val.(hostConfigRead)
			// Callers own their buffers, as with an independent host read.
			value.data = bytes.Clone(value.data)
			return value, nil
		}
	}
}
