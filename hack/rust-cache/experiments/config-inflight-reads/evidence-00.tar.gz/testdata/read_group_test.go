package core

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"

	"github.com/dagger/dagger/engine/engineutil"
	"github.com/stretchr/testify/require"
)

type hostConfigCallerContext struct {
	context.Context
	registered chan struct{}
	once       sync.Once
}

func (c *hostConfigCallerContext) Done() <-chan struct{} {
	// DoChan has registered this caller before Do starts selecting on Done.
	c.once.Do(func() { close(c.registered) })
	return c.Context.Done()
}

type hostConfigReadResult struct {
	value hostConfigRead
	err   error
}

func startHostConfigRead(ctx context.Context, group *hostConfigReadGroup, key string,
	read func(context.Context) (hostConfigRead, error),
) (<-chan hostConfigReadResult, <-chan struct{}) {
	caller := &hostConfigCallerContext{Context: ctx, registered: make(chan struct{})}
	result := make(chan hostConfigReadResult, 1)
	go func() {
		value, err := group.Do(caller, key, read)
		result <- hostConfigReadResult{value: value, err: err}
	}()
	return result, caller.registered
}

func TestHostConfigReadsShareOnlyOverlappingCalls(t *testing.T) {
	var group hostConfigReadGroup
	var calls atomic.Int32
	started := make(chan struct{})
	release := make(chan struct{})
	read := func(context.Context) (hostConfigRead, error) {
		calls.Add(1)
		close(started)
		<-release
		return hostConfigRead{data: []byte("old"), found: true}, nil
	}
	first, _ := startHostConfigRead(t.Context(), &group, "config", read)
	<-started
	second, registered := startHostConfigRead(t.Context(), &group, "config", read)
	<-registered
	close(release)
	a, b := <-first, <-second
	require.NoError(t, a.err)
	require.NoError(t, b.err)
	require.True(t, a.value.found)
	require.Equal(t, int32(1), calls.Load())
	a.value.data[0] = 'X'
	require.Equal(t, "old", string(b.value.data))

	// A subsequent call sees a change immediately, including creation/removal.
	next, err := group.Do(t.Context(), "config", func(context.Context) (hostConfigRead, error) {
		calls.Add(1)
		return hostConfigRead{data: []byte("new"), found: true}, nil
	})
	require.NoError(t, err)
	require.Equal(t, "new", string(next.data))
	require.Equal(t, int32(2), calls.Load())
	missing, err := group.Do(t.Context(), "config", func(context.Context) (hostConfigRead, error) {
		return hostConfigRead{}, nil
	})
	require.NoError(t, err)
	require.False(t, missing.found)
}

func TestHostConfigReadsRetryCanceledOwner(t *testing.T) {
	var group hostConfigReadGroup
	owner, cancel := context.WithCancel(t.Context())
	defer cancel()
	started, stopped := make(chan struct{}), make(chan struct{})
	first, _ := startHostConfigRead(owner, &group, "config", func(ctx context.Context) (hostConfigRead, error) {
		close(started)
		<-ctx.Done()
		close(stopped)
		return hostConfigRead{}, context.Cause(ctx)
	})
	<-started
	second, registered := startHostConfigRead(t.Context(), &group, "config", func(ctx context.Context) (hostConfigRead, error) {
		return hostConfigRead{data: []byte("fresh"), found: true}, context.Cause(ctx)
	})
	<-registered
	cancel()
	require.ErrorIs(t, (<-first).err, context.Canceled)
	<-stopped
	result := <-second
	require.NoError(t, result.err)
	require.Equal(t, "fresh", string(result.value.data))
}

func TestHostConfigReadsCancelFollowerIndependently(t *testing.T) {
	var group hostConfigReadGroup
	follower, cancel := context.WithCancel(t.Context())
	defer cancel()
	started, release := make(chan struct{}), make(chan struct{})
	first, _ := startHostConfigRead(t.Context(), &group, "config", func(ctx context.Context) (hostConfigRead, error) {
		close(started)
		<-release
		return hostConfigRead{data: []byte("value"), found: true}, context.Cause(ctx)
	})
	<-started
	second, registered := startHostConfigRead(follower, &group, "config", func(context.Context) (hostConfigRead, error) {
		return hostConfigRead{}, errors.New("follower unexpectedly started another read")
	})
	<-registered
	cancel()
	require.ErrorIs(t, (<-second).err, context.Canceled)
	close(release)
	result := <-first
	require.NoError(t, result.err)
	require.Equal(t, "value", string(result.value.data))
}

func TestHostConfigReadsCanceledLastCallerStopsIO(t *testing.T) {
	var group hostConfigReadGroup
	ctx, cancel := context.WithCancel(t.Context())
	defer cancel()
	started, stopped := make(chan struct{}), make(chan struct{})
	result, _ := startHostConfigRead(ctx, &group, "config", func(ctx context.Context) (hostConfigRead, error) {
		close(started)
		<-ctx.Done()
		close(stopped)
		return hostConfigRead{}, context.Cause(ctx)
	})
	<-started
	cancel()
	require.ErrorIs(t, (<-result).err, context.Canceled)
	<-stopped
	_, err := group.Do(ctx, "config", func(context.Context) (hostConfigRead, error) {
		t.Error("a canceled caller started I/O")
		return hostConfigRead{}, nil
	})
	require.ErrorIs(t, err, context.Canceled)
}

func TestHostConfigReadsDoNotRetainErrors(t *testing.T) {
	var group hostConfigReadGroup
	_, err := group.Do(t.Context(), "config", func(context.Context) (hostConfigRead, error) {
		return hostConfigRead{}, os.ErrPermission
	})
	require.ErrorIs(t, err, os.ErrPermission)
	result, err := group.Do(t.Context(), "config", func(context.Context) (hostConfigRead, error) {
		return hostConfigRead{data: []byte("readable"), found: true}, nil
	})
	require.NoError(t, err)
	require.Equal(t, "readable", string(result.data))
}

func TestHostConfigReadsObserveEditBeforeCallerStarts(t *testing.T) {
	var group hostConfigReadGroup
	file := filepath.Join(t.TempDir(), "dagger.toml")
	require.NoError(t, os.WriteFile(file, []byte("old declaration"), 0o600))
	readFinished, deliver := make(chan struct{}), make(chan struct{})
	first, _ := startHostConfigRead(t.Context(), &group, "config", func(context.Context) (hostConfigRead, error) {
		data, err := os.ReadFile(file)
		close(readFinished)
		// Model an RPC whose host read completed but whose response is delayed.
		<-deliver
		return hostConfigRead{data: data, found: err == nil}, err
	})
	<-readFinished
	require.NoError(t, os.WriteFile(file, []byte("new declaration"), 0o600))
	second, registered := startHostConfigRead(t.Context(), &group, "config", func(context.Context) (hostConfigRead, error) {
		data, err := os.ReadFile(file)
		return hostConfigRead{data: data, found: err == nil}, err
	})
	var current hostConfigReadResult
	completed := false
	select {
	case <-registered:
	case current = <-second:
		completed = true
	}
	close(deliver)
	old := <-first
	if !completed {
		current = <-second
	}
	require.NoError(t, old.err)
	require.NoError(t, current.err)
	require.Equal(t, "old declaration", string(old.value.data))
	// The edit completed before the second invocation; it must be observed.
	require.Equal(t, "new declaration", string(current.value.data))
}

func TestHostConfigReadsIsolateSessionOwnerAndPath(t *testing.T) {
	var group hostConfigReadGroup
	client, other := &engineutil.Client{}, &engineutil.Client{}
	key := hostConfigReadKey(client, "host-a", "/dagger.toml")
	started, release := make(chan struct{}), make(chan struct{})
	first, _ := startHostConfigRead(t.Context(), &group, key, func(context.Context) (hostConfigRead, error) {
		close(started)
		<-release
		return hostConfigRead{data: []byte("first"), found: true}, nil
	})
	<-started
	for _, distinct := range []string{
		hostConfigReadKey(other, "host-a", "/dagger.toml"),
		hostConfigReadKey(client, "host-b", "/dagger.toml"),
		hostConfigReadKey(client, "host-a", "/sub/dagger.toml"),
	} {
		result, err := group.Do(t.Context(), distinct, func(context.Context) (hostConfigRead, error) {
			return hostConfigRead{data: []byte("distinct"), found: true}, nil
		})
		require.NoError(t, err)
		require.Equal(t, "distinct", string(result.data))
	}
	close(release)
	require.NoError(t, (<-first).err)
}
