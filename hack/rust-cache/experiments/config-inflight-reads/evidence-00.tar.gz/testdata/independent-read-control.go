package core

import (
	"context"
	"errors"
	"fmt"

	"github.com/dagger/dagger/engine/engineutil"
	"golang.org/x/sync/singleflight"
)

type hostConfigRead struct {
	data  []byte
	found bool
}

type hostConfigReadGroup struct {
	reads singleflight.Group
}

var hostConfigReads hostConfigReadGroup

var errHostConfigReadCanceled = errors.New("host configuration read owner canceled")

// The engine client is session-owned. Include the host owner as well: modules
// in the same session can read from different hosts with identical paths.
func hostConfigReadKey(client *engineutil.Client, owner, path string) string {
	return fmt.Sprintf("%p:%q:%q", client, owner, path)
}

// Do shares only overlapping reads. The singleflight removes the entry before
// publishing its result, so the next call observes the host again. The first
// caller owns the I/O context; if it leaves, remaining callers retry with their
// own contexts rather than inheriting its cancellation or extending its lease.
func (g *hostConfigReadGroup) Do(
	ctx context.Context,
	key string,
	read func(context.Context) (hostConfigRead, error),
) (hostConfigRead, error) {
	return read(ctx)
}
