from pathlib import Path
import json
import statistics

p=Path(__file__).parent
studies=[p.parent/'telemetry-native-storage',p]
all_pairs=[]
cohorts=[]
for study in studies:
    rows=json.loads((study/'paired/samples.json').read_text())
    assert len(rows)==18 and all(r['exit_code']==0 and r['same_rows'] and not r['cancelled'] for r in rows)
    metadata=json.loads((study/'paired/metadata.json').read_text())
    assert metadata['engine_sha256']=='4080ad95b40b58e334380119836d0ebffcea871c9d67d6786f7c425994d73c56'
    before={r['pair']:r for r in rows if r['pair']>0 and r['arm']=='before'}
    after={r['pair']:r for r in rows if r['pair']>0 and r['arm']=='after'}
    assert len(before)==len(after)==8
    pairs=[]
    for i in range(1,9):
        a,b=after[i],before[i]
        pairs.append(dict(pair=i,json_seconds=b['seconds'],native_seconds=a['seconds'],saved_seconds=b['seconds']-a['seconds'],
            json_allocated_bytes=b['heap_delta']['TotalAlloc'],native_allocated_bytes=a['heap_delta']['TotalAlloc'],
            json_engine_cpu=b['engine_cpu'],native_engine_cpu=a['engine_cpu'],
            json_class_slots=[b['gc_before']['metadata_estimate']['ClassSlotCount'],b['gc_after']['metadata_estimate']['ClassSlotCount']],
            native_class_slots=[a['gc_before']['metadata_estimate']['ClassSlotCount'],a['gc_after']['metadata_estimate']['ClassSlotCount']],
            json_go_gc=b['heap_delta']['NumGC'],native_go_gc=a['heap_delta']['NumGC'],
            host_io_pressure={r['arm']:r['pressure']['host.io.some'] for r in [a,b]},
            host_cpu_pressure={r['arm']:r['pressure']['host.cpu.some'] for r in [a,b]}))
    all_pairs.extend(pairs)
    cohorts.append(dict(study=str(study),orders=metadata['orders'],pairs=pairs,
        medians={arm:dict(seconds=statistics.median(r['seconds'] for r in items.values()),
            allocated_bytes=statistics.median(r['heap_delta']['TotalAlloc'] for r in items.values()),
            engine_cpu_seconds=statistics.median(r['engine_cpu'] for r in items.values()),
            cli_cpu_seconds=statistics.median(r['cli_resources']['user_seconds']+r['cli_resources']['system_seconds'] for r in items.values())) for arm,items in [('json',before),('native',after)]}))
assert cohorts[0]['orders'][0]==['before','after'] and cohorts[1]['orders'][0]==['after','before']
result=dict(cohorts=cohorts,total_pairs=len(all_pairs),
    faster_pairs=sum(r['saved_seconds']>0 for r in all_pairs),
    lower_allocation_pairs=sum(r['native_allocated_bytes']<r['json_allocated_bytes'] for r in all_pairs),
    lower_engine_cpu_pairs=sum(r['native_engine_cpu']<r['json_engine_cpu'] for r in all_pairs),
    pooled_medians={arm:dict(seconds=statistics.median(r[arm+'_seconds'] for r in all_pairs),
        allocated_bytes=statistics.median(r[arm+'_allocated_bytes'] for r in all_pairs),
        engine_cpu_seconds=statistics.median(r[arm+'_engine_cpu'] for r in all_pairs)) for arm in ['json','native']},
    median_paired_seconds_saved=statistics.median(r['saved_seconds'] for r in all_pairs),
    scope='Two complete fixed cohorts with opposite starting orders. All admitted observations included. Warm engine, fresh CLI and source edit, telemetry and ordinary maintenance enabled. Same binary in both arms; only writer codec differs. These results do not establish cold or edited-Rust speedups.')
(p/'combined-assessment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cohorts'},indent=2))
