from pathlib import Path
import gzip,hashlib,json,os,signal,subprocess,threading,time,urllib.request
protocol=Path('/tmp/rust-cache-sipsma-review/rust-go-test-collections/measure.py')
exec(protocol.read_text().split('fixtures = [f for f')[0])
cli=base/'filesync-literal-pathwalk/dagger-after'
arm='before'
assert arm in ['before','after']
workspace=Path('/tmp/dagger-go-real-repository-main');module=Path('/tmp/dagger-go-module-test-name-index' if arm=='before' else '/tmp/dagger-go-workspace-package-test-search')
source=workspace/'dagql/types.go';original=source.read_bytes()
configs={name:(workspace/name).read_bytes() if (workspace/name).exists() else None for name in ['dagger.toml','dagger.lock']}
routes=['batch-metadata','attribute-array-decode','reusable-declarations','span-lookup-fanout','usage-sampling','builtin-receivers','config-declarations','trivial-scalar-fields','direct-span-protobuf','span-resource-batches','lazy-type-maps','telemetry-flush-coalescing','callback-caller-reuse','otel-evicted-queue','single-toml-parse','parallel-client-admission','prepared-schema','restored-posting-removal','scalar-list-projection','upstream-leaf-arrays','native-search-projection','restored-data-list-projection','span-row-sharing','interface-field-snapshots','metric-flush-pruning']
flags={route:get(route)['enabled'] for route in routes}
env['_EXPERIMENTAL_DAGGER_VERSION']='v1.0.0-beta.15'
for name in ['CPUPROFILE','PPROF']:env.pop(name,None)
def raw(route,timeout=30):
 with urllib.request.urlopen(debug+route,timeout=timeout) as response:return response.read()
stop=threading.Event();windows=[];errors=[];thread=None
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
idle('publication-tail-forensics')
metadata=dict(scope='One diagnostic edited listing of the selected Go module. Profile the newly isolated publication stalls using engine CPU windows, mutex/allocation deltas and at most four scheduled goroutine dumps. Metric dispatch pruning is off. No CLI/runtime tracing or forced GC. Telemetry, native cache, ordinary GC and cleanup remain enabled; this is not a latency comparison.',arm=arm,module=str(module),engine_sha256=subprocess.check_output(['docker','exec',record['Id'],'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0],cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),warm_engine=True,fresh_cli=True,fresh_source_edit=True,ordinary_gc=True,telemetry=True,flags_before=flags)
stack_thread=None;stacks=[]
(root/'driver.py').write_bytes(Path(__file__).read_bytes())
try:
 for route in routes:mode(route,route in ['batch-metadata','attribute-array-decode','reusable-declarations','span-lookup-fanout','usage-sampling','builtin-receivers','config-declarations','trivial-scalar-fields','scalar-list-projection','restored-posting-removal'])
 get('span-lookup-fanout?record=false',b'');get('builtin-receivers?enabled=true&record=false',b'');get('config-declarations?enabled=true&record=false',b'')
 assert get('collection-expansion-limit')['limit']==0
 get('span-row-sharing?record=false',b'');get('span-resource-batches?record=false',b'')
 metadata['flags_during']={route:get(route)['enabled'] for route in routes}
 (root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
 source.write_bytes(original+f'\n// Exact SDK request profile {time.time_ns()}\n'.encode())
 (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n')
 get('lock-profiler?enabled=true',b'')
 for kind in ['allocs','mutex']:(root/('engine-'+kind+'-before.pprof')).write_bytes(raw('pprof/'+kind))
 gc_before=get('snapshot-collection')
 get('wcprof/enabled',b'on');raw('wcprof/dump')
 tick=time.monotonic();before=heap();before_cpu=cpu();before_pressure=pressure()
 def sample_cpu():
  index=0
  while not stop.is_set():
   begin=time.monotonic()
   try:
    payload=raw('pprof/profile?seconds=5',20)
    filename=f'engine-cpu-{index:03d}.pprof';(root/filename).write_bytes(payload)
    windows.append(dict(path=filename,start_seconds=begin-tick,end_seconds=time.monotonic()-tick,bytes=len(payload)))
   except Exception as error:errors.append(type(error).__name__);break
   index+=1
 def sample_stacks():
  for due in [30,35,40,45]:
   if stop.wait(max(0,due-(time.monotonic()-tick))):break
   try:
    payload=raw('pprof/goroutine?debug=2',20);filename=f'goroutines-{due}.txt';(root/filename).write_bytes(payload)
    stacks.append(dict(path=filename,seconds=time.monotonic()-tick,bytes=len(payload)))
   except Exception as error:errors.append('stack-'+type(error).__name__);break
 thread=threading.Thread(target=sample_cpu);thread.start()
 stack_thread=threading.Thread(target=sample_stacks);stack_thread.start()
 command=[str(cli),'check','--module','go','--check','test','--list','--all']
 timed=['/usr/bin/time','-f','{"user_seconds":%U,"system_seconds":%S,"max_rss_kib":%M}','-o',str(root/'cli-resources.json'),'--',*command]
 with (root/'command.stdout').open('w') as out,(root/'command.stderr').open('w') as err:
  process=subprocess.Popen(timed,cwd=workspace,env=env,stdout=out,stderr=err,start_new_session=True)
  cancelled=False
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait()
 elapsed=time.monotonic()-tick;after=heap();after_cpu=cpu();after_pressure=pressure()
finally:
 stop.set()
 if thread is not None:thread.join()
 if stack_thread is not None:stack_thread.join()
 get('lock-profiler?enabled=false',b'')
 for kind in ['allocs','mutex']:(root/('engine-'+kind+'-after.pprof')).write_bytes(raw('pprof/'+kind))
 get('wcprof/enabled',b'off')
 gc_after=get('snapshot-collection')
 source.write_bytes(original)
 for name,data in configs.items():
  if data is None:(workspace/name).unlink(missing_ok=True)
  else:(workspace/name).write_bytes(data)
 for route,enabled in flags.items():mode(route,enabled)
(root/'collection-state.json').write_text(json.dumps(dict(before=gc_before,after=gc_after),indent=2)+'\n')
(root/'goroutine-windows.json').write_text(json.dumps(stacks,indent=2)+'\n')
(root/'engine-cpu-windows.json').write_text(json.dumps(windows,indent=2)+'\n')
headers=[];events=[];deadline=time.monotonic()+120
while True:
 payload=raw('wcprof/dump',45)
 (root/f'wcprof-{len(headers)}.ndjson.gz').write_bytes(gzip.compress(payload,mtime=0))
 lines=payload.splitlines();header=json.loads(lines[0]);headers.append(header);events.extend(lines[1:])
 if not header.get('open_ops'):break
 assert time.monotonic()<deadline,'open wcprof operations did not finish'
 time.sleep(1)
header=dict(headers[-1]);header['event_count']=len(events)
(root/'wcprof-complete.ndjson').write_bytes((json.dumps(header)+'\n').encode()+b'\n'.join(events)+b'\n')
listed=[line for line in (root/'command.stdout').read_text().splitlines() if line.startswith('go ')]
expected=[line for line in (base/'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
span_rows=get('span-row-sharing');stored_rows=get('span-resource-batches')
get('span-row-sharing?record=false',b'');get('span-resource-batches?record=false',b'')
result=dict(span_row_sharing=span_rows,span_destination_writes=stored_rows,seconds=elapsed,exit_code=code,cancelled=cancelled,rows=len(listed),same_rows=listed==expected,engine_cpu=after_cpu-before_cpu,heap_delta={k:after[k]-before[k] for k in before},pressure={k:(after_pressure[k]-before_pressure[k])/(elapsed*1e6) for k in before_pressure},cli_resources=json.loads((root/'cli-resources.json').read_text().splitlines()[-1]),cpu_windows=len(windows),errors=errors,recorder=dict(events=len(events),dropped=header['dropped_events'],open=len(header.get('open_ops',[]))),source_restored=source.read_bytes()==original)
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
assert code==0 and not cancelled and listed==expected and len(listed)==4398
assert header['dropped_events']==0 and not header.get('open_ops')
assert not errors

assert not get('span-row-sharing')['enabled']
