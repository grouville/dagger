from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;repo='/tmp/dagger-native-glob-prefix';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[]
for block in range(4):
 for arm in (['after','before'] if block%2==0 else ['before','after']):
  command=[go,'test','-p=2']+(['-overlay='+str(p/'before-overlay.json')] if arm=='before' else [])+['-run=^$','-bench=^BenchmarkDirectoryGlobNativePrefix$','-benchmem','-benchtime=200ms','-count=1','./core']
  label=f'{block}-{arm}';tick=time.monotonic()
  with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
  assert r.returncode==0,(label,(p/(label+'.log')).read_text()[-3000:])
  cases=[]
  for pattern,ns,b,allocs in re.findall(r'BenchmarkDirectoryGlobNativePrefix/(\S+)-\d+\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(p/(label+'.log')).read_text()):cases.append(dict(pattern=pattern,ns=float(ns),bytes=int(b),allocs=int(allocs)))
  assert len(cases)==3,cases
  rows.append(dict(block=block,arm=arm,command=command,seconds=time.monotonic()-tick,cases=cases));(p/'paired-benchmark.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
summary={}
for pattern in [c['pattern'] for c in rows[0]['cases']]:
 summary[pattern]={}
 for arm in ['before','after']:
  cases=[c for r in rows if r['arm']==arm for c in r['cases'] if c['pattern']==pattern];summary[pattern][arm]={k:statistics.median(c[k] for c in cases) for k in ['ns','bytes','allocs']}
 summary[pattern]['faster_pairs']=sum(next(c['ns'] for r in rows if r['arm']=='after' and r['block']==block for c in r['cases'] if c['pattern']==pattern)<next(c['ns'] for r in rows if r['arm']=='before' and r['block']==block for c in r['cases'] if c['pattern']==pattern) for block in range(4))
(p/'paired-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
