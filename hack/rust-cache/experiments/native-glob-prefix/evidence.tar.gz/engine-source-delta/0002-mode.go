package core

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var nativeGlobPrefixEnabled atomic.Bool

func init() {
	nativeGlobPrefixEnabled.Store(os.Getenv("DAGGER_TEST_NATIVE_GLOB_PREFIX") == "true")
}
func NativeGlobPrefixDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		v, e := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if e != nil {
			http.Error(w, e.Error(), 400)
			return
		}
		nativeGlobPrefixEnabled.Store(v)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": nativeGlobPrefixEnabled.Load()})
}
