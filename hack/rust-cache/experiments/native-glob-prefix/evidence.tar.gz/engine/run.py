from pathlib import Path
import json,os,subprocess,sys,time
p=Path(__file__).parent;unit=p.parent/'native-glob-prefix';steps=[]
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off')
commands=[('standalone-final-race',[go,'test','-p=2','-race','-count=1','-run=^TestDirectoryGlobNativePrefix$','./core'],'/tmp/dagger-native-glob-prefix')]
commands += [(label,[sys.executable,str(p/script)],None) for label,script in [('build','build-engine.py'),('start','start-engine.py'),('integration','verify-integration.py'),('go-pipeline','verify-module.py'),('rust-pipeline','verify-rust.py'),('native-pipeline','verify-native-module.py'),('timings','measure.py')]]
for label,command,cwd in commands:
 tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,cwd=cwd,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-4500:]);raise SystemExit(r.returncode)
