from pathlib import Path
import json
p=Path(__file__).parent;unit=p.parent/'native-glob-prefix';root=Path('/home/dagger/dagger_otra/hack/rust-cache')
assert json.loads((unit/'current-main-race.json').read_text())['exit_code']==0
body="""`Directory.glob("module/**/*.go")` currently walks unrelated modules. Its existing shortcut only handles patterns whose trimmed form has no wildcard. Repeating scoped globs over a large native snapshot repeats most of the filesystem traversal.

Keep walking from the original root, but skip directories outside the fixed directory prefix before the first pattern character. The matcher, path order, symlink handling and API-dependent directory suffixes stay the same. Global and exclusion patterns retain their full walks. This is the same pruning rule already tested in the CLI's host glob implementation, with no new API, cache or lock.

Four alternating component pairs on a 4,608-file fixture, running the actual native `Directory.Glob` method with a local storage adapter:

| Pattern | Before | After |
| --- | ---: | ---: |
| `module00/pkg00/*_test.go` | 8.59 ms | 88 µs |
| `module00/**/*.go` | 8.76 ms | 555 µs |
| `**/*.go`, full-tree control | 12.37 ms | 12.61 ms |

Scoped cases improve in all four pairs; the global control is mixed. On the native-directory Go prototype, sampled glob CPU falls **3.17 → 0.17 CPU-seconds**. Complete source-edited listing moves **4.80 → 4.41 s** (3/4 faster), while test-edited listing is mixed at **8.42 → 8.17 s** (2/4). The selected module also has mixed timings, so this is not a claim of a general listing speedup. Fresh CLIs, telemetry and cleanup are included on a warm experimental engine. No cold-start result is established.

Parity tests compare exact results and order against a deliberately unpruned walk, including wildcard tails, escapes, Unicode, symlinks, exclusions, cancellation, invalid patterns and missing paths in both directory-suffix views. The focused race suite passes on current main and the experimental engine. The existing real-snapshot glob integration suite passes in both modes with distinct inputs. All 32 public Go checks, 28 Rust/native-cache cases and 48 timed listings have their expected outcomes. Profiles retain all authored getters and normal discovery reuse.
"""
(root/'PR_NATIVE_GLOB_PREFIX.md').write_text('# core: prune native glob walks by directory prefix\n\n'+body+'\n[Source, complete measurements and attempts](NATIVE_DIRECTORY_GLOB_PREFIX.md).\n')
report="""Native directory globs can skip unrelated subtrees using the fixed directory prefix before the first wildcard. The change removes substantial traversal CPU, but mixed complete-command timings do not establish a listing speedup for the selected Go module. The broader native-source module remains unselected.

The implementation adds 13 lines and removes two in core.Directory.Glob. It retains the original walk root and matcher. A directory is pruned only when it is neither the fixed prefix nor an ancestor or descendant of it. Literal-pattern pruning remains; global and exclusion patterns retain their full walks. No dependency, API, cache, lock, source filtering, getter replacement or telemetry change is added. The new prefix rule is already used by the selected CLI host-glob change; it was missing from the separate native snapshot path.

| Actual native glob, 4,608-file fixture | Before | After | Faster pairs |
| --- | ---: | ---: | ---: |
| Scoped filename: module00/pkg00/*_test.go | 8.59 ms | 88 µs | 4/4 |
| Module subtree: module00/**/*.go | 8.76 ms | 555 µs | 4/4 |
| Full-tree control: **/*.go | 12.37 ms | 12.61 ms | 2/4 |

The component gains are approximately 98× and 16×. Scoped-filename allocation falls **1.227 MB → 22.5 kB**, module-subtree allocation **1.232 MB → 75.1 kB**. The global control is mixed and slightly higher in its median; it is not reported as improved. The component calls the actual production Directory.Glob method repeatedly, including cache evaluation and root resolution. Only the snapshot storage boundary is adapted to an ordinary local filesystem so it does not need a privileged read-only bind mount. The component does not measure real snapshot import or mount setup. Separate integration coverage uses actual engine snapshots.

| Complete warm listing after a real edit | Current module, before | Current module, pruning | Broader native input, before | Native input, pruning |
| --- | ---: | ---: | ---: | ---: |
| Ordinary Go source | 3.98 s | 3.84 s | 4.80 s | 4.41 s |
| Test file | 7.20 s | 6.83 s | 8.42 s | 8.17 s |

The current-module comparisons are faster in **2/4 pairs** for each workload. Their median paired savings are **24 ms** after source edits and **446 ms** after test edits, with slower pairs retained. The native-input comparisons are faster in **3/4** and **2/4** pairs, with median paired savings **443 ms** and **295 ms**. Outliers remain in the data. Differences between separate medians are not the paired savings. These mixed results are insufficient to add another selected listing speedup to the ledger.

On the native-input branch, engine CPU medians fall **14.79 → 11.68 CPU-seconds** after source edits and **33.25 → 29.99** after test edits. CPU decreases in all eight native-input pairs. Exact TotalAlloc medians fall **2.229 → 2.077 GB** and **6.663 → 6.481 GB**. Allocation is lower in seven of the eight pairs; the slower test-edit outlier allocates more. These counters are separate from sampled profiles and from elapsed time. Current-module CPU/allocation is broadly comparable; no resource improvement is claimed there.

Four measured blocks follow two complete layout-initialization blocks in all four arms. Every invocation starts a fresh CLI and makes a real edit. All **48 timed commands** return the exact ordered rows and exit successfully: 4,399 during test-addition initialization and 4,398 afterward. Telemetry, output, flushing, session cleanup and ordinary GC remain enabled. No profiling or forced GC runs during timings. All arms use the earlier primitive-array-selection and read-first config improvements. Only native prefix pruning and the explicit Go module version vary. The caches are warmed by correctness gates and initialization; this is not cold first use or a retained-cache restart.

The measured engine is c24933ea4d399cd451baa2352d71b3f86f0099734263a1fba34d120ea5cd73b7. The original CLI remains 97f7d82dc2f7b3da203aa683971ea3658b6de6a8e9b968a44905e379f499f965. Module revisions remain Go720 (720a5258ad8212ab643bbeaa4084127b2e866800) and broad native source Go58 (58c979f). Source identity, flags, every command and every attempt are archived. These are development-stack comparisons, not stock-engine results.

Eight independent lossless wcprof/CPU captures have no dropped events or open operations. Both test-edit modes retain **804 module evaluations, 800 authored getter executions and 799 unchanged test-discovery hits**. Source-only captures retain three evaluations and all 800 getter/discovery hits. SDK requests remain 1,415/493 for the current module and 1,416/494 for the native input. Existing primitive-array selection keeps scalar glob-element result calls at zero in both modes; no extra getter logic is skipped by this patch.

In the native source-only CPU captures, Directory.Glob falls **3.17 → 0.17 sampled CPU-seconds**, while filepath.WalkDir falls **3.35 → 0.40**. This directly confirms the targeted traversal reduction. The candidate diagnostic main query is **4.20 seconds** and attributes **92 ms** of its critical path to five directory-glob segments. Other segments include **979 ms** in interpreted evaluation, **828 ms** in host import, **427 ms** in result publication, **235 ms** in directory copying and **225 ms** in search. CPU and critical-path elapsed time are different; these values must not be added as promised savings.

The selected-module test-edit diagnostic still places **2.26 seconds** of its critical path in encodeResult, alongside 811 ms in evaluation and 384 ms in lifecycle waiting. Its CPU profile is dominated by GC, while coercion and JSON decoding remain visible. A long encoding span includes waiting and GC; it is not proof that 2.26 seconds can be removed by replacing JSON. The next selected-module investigation should attribute that serialization/conversion allocation with current data before proposing another shared receiver or getter shortcut. The earlier recursive Bindings and shared-receiver screens remain unselected and must not be repeated unchanged.

The standalone parity test and benchmark use a small storage adapter but execute the actual glob walk, root resolution and lazy-accessor path. Exact result/order parity is checked against a full walk for 22 patterns in both legacy and current directory-suffix views, plus cancellation, invalid-pattern and missing-root cases. The final focused race suite passes on the measured upstream base and on the exact development overlay. The existing real-snapshot TestDirectory/TestGlob integration suite passes with pruning off and on; main fixture contents differ between arms to invalidate cached glob results. No unrelated full core suite is claimed.

The 27 current-module Go checks, five broader-native-input checks and 28 Rust/native-cache cases all pass with their expected outcomes. These cover source edits/restoration, ownership and module-layout changes, selection, actual test/binary/generate execution, expected failures and native Rust action reuse. These gates are not Rust latency measurements. Initial native-module execution setup remains separate from warmed listing timings; no first-use execution improvement is claimed.

The measured standalone commit is 49dd6533df, based on upstream ff0b029a4d270a651b9a8c7286babc79089066e4. Upstream moved during the study. The review branch is rebased onto **91e4d2b9e20b12d9c42fc923e91403b2805a88b5**, whose glob implementation and related tested files are unchanged. The current-main focused race suite passes. The review commit is [cc89e9c298](https://github.com/grouville/dagger/commit/cc89e9c298881946e2234733ade99a28d0610384), on experiment/native-glob-prefix. The archive preserves the measured and rebased source identities; the recorded engine binary and measurements are unchanged.

All fifteen engines and volumes are retained. Modes, profilers, source files and module checkers are restored; no requests or runtimes remain active. [Prepared review description](PR_NATIVE_GLOB_PREFIX.md). [Exact source, all attempts, matched data and eight lossless profiles](experiments/native-glob-prefix/). No PR is opened.
"""
(root/'NATIVE_DIRECTORY_GLOB_PREFIX.md').write_text(report)
plan=root/'GO_COLLECTION_THREE_SECOND_PLAN.md';s=plan.read_text();marker='## Current measured state\n\n';assert marker in s
paragraph='The [native glob-prefix change](NATIVE_DIRECTORY_GLOB_PREFIX.md) reduces sampled native glob CPU **3.17 → 0.17 CPU-s**, with actual scoped glob components improving about **98× / 16×**. Complete native-input listing moves **4.80 → 4.41 s** after source edits (3/4 faster) and **8.42 → 8.17 s** after test edits (2/4). Selected-module timings are also mixed, so this adds no selected listing speedup. Both real-snapshot integration modes, focused parity/race gates, 32 Go checks, 28 Rust/native-cache cases and all 48 timings pass; eight lossless captures preserve every authored getter and normal cache reuse. The source is rebased onto verified upstream 91e4d2b9e2 and its focused race suite passes. All fifteen engines/volumes are retained. Native input grouping remains unselected because import/copy costs and first-use behavior are unresolved. The remaining selected test-edit profile places substantial elapsed time in result encoding amid GC and conversion; attribute actual allocation/CPU before proposing another receiver-sharing mechanism or treating span duration as removable work.\n\n'
s=s.replace(marker,marker+paragraph,1);plan.write_text(s)
ledger=root/'GO_COLLECTION_IMPROVEMENTS.md';s=ledger.read_text();marker='## What is ready\n\n';assert marker in s
paragraph='The [native glob-prefix optimization](NATIVE_DIRECTORY_GLOB_PREFIX.md) is another standalone engine candidate, with scoped component gains near **98× / 16×** and sampled glob CPU **3.17 → 0.17 CPU-s** on the native-input branch. Complete timings remain mixed, and the broader module remains slower; no selected listing gain is added above. Focused current-main/development race checks, real-snapshot integration, 32 Go checks, 28 Rust/native-cache cases and 48 timings have their expected outcomes. The source and [description](PR_NATIVE_GLOB_PREFIX.md) are prepared for fork review, without a PR.\n\n'
s=s.replace(marker,paragraph+marker,1);ledger.write_text(s)
