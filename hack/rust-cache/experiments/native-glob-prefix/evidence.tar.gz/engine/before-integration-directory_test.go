package core

// These tests cover the GraphQL Directory object: creating, reading, filtering,
// mounting, exporting, and comparing directory contents.
//
// See also:
// - file_test.go: core File object behavior.
// - ownership_test.go: file and directory ownership propagation.

import (
	"context"
	"crypto/rand"
	"fmt"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
	"time"

	"github.com/dagger/dagger/engine/engineutil"
	"github.com/stretchr/testify/require"

	"dagger.io/dagger"
	sdkcore "dagger.io/dagger/core"
	"github.com/dagger/dagger/core"
	"github.com/dagger/dagger/internal/testutil"
	"github.com/dagger/testctx"
)

type DirectorySuite struct{}

func TestDirectory(t *testing.T) {
	testctx.New(t, Middleware()...).RunTests(DirectorySuite{})
}

func (DirectorySuite) TestEmpty(ctx context.Context, t *testctx.T) {
	res, err := testutil.Query[struct {
		Directory struct {
			ID      core.DirectoryID
			Entries []string
		}
	}](t,
		`{
			directory {
				entries
			}
		}`, nil)
	require.NoError(t, err)
	require.Empty(t, res.Directory.Entries)
}

func (DirectorySuite) TestFindUp(ctx context.Context, t *testctx.T) {
	// Reuse the same utility used to test Host.findUp()
	// It creates a directory on the host, but we just load it as a Directory
	dirPath := findupTestDir(t)
	c := connect(ctx, t)
	dir := sdkcore.NewQuery(c).Host().Directory(dirPath)
	start := "a/b"

	t.Run("find file in current directory", func(ctx context.Context, t *testctx.T) {
		found, err := dir.FindUp(ctx, "other.txt", start)
		require.NoError(t, err)
		require.Equal(t, "a/b/other.txt", found)
		content, err := dir.File(found).Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "this is a/b/other.txt", content)
	})

	t.Run("find file in parent directory", func(ctx context.Context, t *testctx.T) {
		found, err := dir.FindUp(ctx, "target.txt", start)
		require.NoError(t, err)
		require.Equal(t, "a/target.txt", found)
		content, err := dir.File(found).Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "this is a/target.txt", content)
	})

	t.Run("find file in root", func(ctx context.Context, t *testctx.T) {
		found, err := dir.FindUp(ctx, "root.txt", start)
		require.NoError(t, err)
		require.Equal(t, "root.txt", found)
		content, err := dir.File(found).Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "this is root.txt", content)
	})

	t.Run("find directory in parent directory", func(ctx context.Context, t *testctx.T) {
		found, err := dir.FindUp(ctx, "somedir", start)
		require.NoError(t, err)
		require.Equal(t, "a/somedir", found)
		entries, err := dir.Directory(found).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"hi.txt"}, entries)
	})

	t.Run("DO NOT find file in child directory", func(ctx context.Context, t *testctx.T) {
		found, err := dir.FindUp(ctx, "leaf.txt", start)
		require.NoError(t, err)
		require.Equal(t, "", found)
	})

	t.Run("DO NOT find non-existent file", func(ctx context.Context, t *testctx.T) {
		found, err := dir.FindUp(ctx, "nonexistent.txt", start)
		require.NoError(t, err)
		require.Equal(t, "", found)
	})
}

func (DirectorySuite) TestScratch(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	_, err := sdkcore.NewQuery(c).Container().Directory("/").Entries(ctx)
	require.NoError(t, err)
	// require.ErrorContains(t, err, "no such file or directory")
}

func (DirectorySuite) TestWithNewFile(ctx context.Context, t *testctx.T) {
	res, err := testutil.Query[struct {
		Directory struct {
			WithNewFile struct {
				ID      core.DirectoryID
				Entries []string
			}
		}
	}](t,
		`{
			directory {
				withNewFile(path: "some-file", contents: "some-content") {
					id
					entries
				}
			}
		}`, nil)
	require.NoError(t, err)
	require.NotEmpty(t, res.Directory.WithNewFile.ID)
	require.Equal(t, []string{"some-file"}, res.Directory.WithNewFile.Entries)
}

func (DirectorySuite) TestEntries(ctx context.Context, t *testctx.T) {
	res, err := testutil.Query[struct {
		Directory struct {
			WithNewFile struct {
				WithNewFile struct {
					Entries []string
				}
			}
		}
	}](t,
		`{
			directory {
				withNewFile(path: "some-file", contents: "some-content") {
					withNewFile(path: "some-dir/sub-file", contents: "some-content") {
						entries
					}
				}
			}
		}`, nil)
	require.NoError(t, err)
	require.ElementsMatch(t, []string{"some-file", "some-dir/"}, res.Directory.WithNewFile.WithNewFile.Entries)
}

func (DirectorySuite) TestEntriesOfPath(ctx context.Context, t *testctx.T) {
	res, err := testutil.Query[struct {
		Directory struct {
			WithNewFile struct {
				WithNewFile struct {
					Entries []string
				}
			}
		}
	}](t,
		`{
			directory {
				withNewFile(path: "some-file", contents: "some-content") {
					withNewFile(path: "some-dir/sub-file", contents: "some-content") {
						entries(path: "some-dir")
					}
				}
			}
		}`, nil)
	require.NoError(t, err)
	require.Equal(t, []string{"sub-file"}, res.Directory.WithNewFile.WithNewFile.Entries)
}

func (DirectorySuite) TestDirectory(ctx context.Context, t *testctx.T) {
	res, err := testutil.Query[struct {
		Directory struct {
			WithNewFile struct {
				WithNewFile struct {
					Directory struct {
						Entries []string
					}
				}
			}
		}
	}](t,
		`{
			directory {
				withNewFile(path: "some-file", contents: "some-content") {
					withNewFile(path: "some-dir/sub-file", contents: "some-content") {
						directory(path: "some-dir") {
							entries
						}
					}
				}
			}
		}`, nil)
	require.NoError(t, err)
	require.Equal(t, []string{"sub-file"}, res.Directory.WithNewFile.WithNewFile.Directory.Entries)
}

func (DirectorySuite) TestDirectoryWithNewFile(ctx context.Context, t *testctx.T) {
	res, err := testutil.Query[struct {
		Directory struct {
			WithNewFile struct {
				WithNewFile struct {
					Directory struct {
						WithNewFile struct {
							Entries []string
						}
					}
				}
			}
		}
	}](t,
		`{
			directory {
				withNewFile(path: "some-file", contents: "some-content") {
					withNewFile(path: "some-dir/sub-file", contents: "some-content") {
						directory(path: "some-dir") {
							withNewFile(path: "another-file", contents: "more-content") {
								entries
							}
						}
					}
				}
			}
		}`, nil)
	require.NoError(t, err)
	require.ElementsMatch(t,
		[]string{"sub-file", "another-file"},
		res.Directory.WithNewFile.WithNewFile.Directory.WithNewFile.Entries)
}

func (DirectorySuite) TestWithDirectory(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	dir := sdkcore.NewQuery(c).Directory().
		WithNewFile("some-file", "some-content").
		WithNewFile("some-dir/sub-file", "sub-content").
		Directory("some-dir")

	entries, err := sdkcore.NewQuery(c).Directory().WithDirectory("with-dir", dir).Entries(ctx, sdkcore.DirectoryEntriesOpts{
		Path: "with-dir",
	})
	require.NoError(t, err)
	require.Equal(t, []string{"sub-file"}, entries)

	entries, err = sdkcore.NewQuery(c).Directory().WithDirectory("sub-dir/sub-sub-dir/with-dir", dir).Entries(ctx, sdkcore.DirectoryEntriesOpts{
		Path: "sub-dir/sub-sub-dir/with-dir",
	})
	require.NoError(t, err)
	require.Equal(t, []string{"sub-file"}, entries)

	t.Run("copies directory contents to .", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithDirectory(".", dir).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"sub-file"}, entries)
	})

	t.Run("respects permissions", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("some-file", "some content", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o444}).
			WithNewDirectory("some-dir", sdkcore.DirectoryWithNewDirectoryOpts{Permissions: 0o444}).
			WithNewFile("some-dir/sub-file", "sub-content", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o444})
		ctr := sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/permissions-test", dir)

		stdout, err := ctr.WithExec([]string{"ls", "-ld", "/permissions-test"}).Stdout(ctx)

		require.NoError(t, err)
		require.Contains(t, stdout, "drwxr-xr-x")

		stdout, err = ctr.WithExec([]string{"ls", "-l", "/permissions-test/some-file"}).Stdout(ctx)

		require.NoError(t, err)
		require.Contains(t, stdout, "-r--r--r--")

		stdout, err = ctr.WithExec([]string{"ls", "-ld", "/permissions-test/some-dir"}).Stdout(ctx)

		require.NoError(t, err)
		require.Contains(t, stdout, "dr--r--r--")

		stdout, err = ctr.WithExec([]string{"ls", "-l", "/permissions-test/some-dir/sub-file"}).Stdout(ctx)

		require.NoError(t, err)
		require.Contains(t, stdout, "-r--r--r--")
	})

	t.Run("scratch into scratch", func(ctx context.Context, t *testctx.T) {
		_, err := sdkcore.NewQuery(c).Directory().WithDirectory("/", sdkcore.NewQuery(c).Directory()).Sync(ctx)
		require.NoError(t, err)
	})

	t.Run("chains preserve layered semantics", func(ctx context.Context, t *testctx.T) {
		base := sdkcore.NewQuery(c).Directory().
			WithNewFile("keep.txt", "base").
			WithNewFile("conflict.txt", "base")
		srcA := sdkcore.NewQuery(c).Directory().
			WithNewFile("a.txt", "a").
			WithNewFile("conflict.txt", "a").
			WithNewFile("skip.txt", "skip")
		srcB := sdkcore.NewQuery(c).Directory().
			WithNewFile("b.txt", "b")
		srcC := sdkcore.NewQuery(c).Directory().
			WithNewFile("c.txt", "c").
			WithNewFile("conflict.txt", "c")

		dir := base.
			WithDirectory("/", srcA, sdkcore.DirectoryWithDirectoryOpts{Exclude: []string{"skip.txt"}}).
			WithDirectory("nested", srcB).
			WithDirectory("/", srcC)

		contents, err := dir.File("keep.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "base", contents)

		contents, err = dir.File("a.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "a", contents)

		contents, err = dir.File("nested/b.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "b", contents)

		contents, err = dir.File("c.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "c", contents)

		contents, err = dir.File("conflict.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "c", contents)

		_, err = dir.File("skip.txt").Contents(ctx)
		require.Error(t, err)
	})

	t.Run("directory replacing file hides older lower directory contents", func(ctx context.Context, t *testctx.T) {
		seed := sdkcore.NewQuery(c).Container().
			WithDirectory("/node", sdkcore.NewQuery(c).Directory().WithNewFile("hidden.txt", "hidden")).
			WithoutDirectory("/node").
			WithNewFile("/node", "file")

		seedRef, err := seed.Publish(ctx, registryRef("with-directory-file-to-dir-opaque-seed"))
		require.NoError(t, err)

		baseDir := sdkcore.NewQuery(c).Container().From(seedRef).Rootfs()
		resultDir := baseDir.WithDirectory("/node", sdkcore.NewQuery(c).Directory().WithNewFile("new.txt", "new"))

		nodeEntries, err := resultDir.Directory("node").Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"new.txt"}, nodeEntries)
	})
}

func (DirectorySuite) TestWithDirectoryOpaqueSourceAncestor(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	source := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithDirectory("/data", sdkcore.NewQuery(c).Directory().
			WithNewFile("a/x.txt", "old").
			WithNewFile("a/b/y.txt", "old")).
		WithExec([]string{"sh", "-c", "rm -rf /data/a && mkdir -p /data/a/b && echo new > /data/a/b/new.txt"}).
		Directory("/data")

	mountedFiles, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithMountedDirectory("/view", source).
		WithExec([]string{"sh", "-c", "find /view -type f | sed 's#^/view/##' | sort"}).
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, "a/b/new.txt\n", mountedFiles)

	exportPath := filepath.Join(t.TempDir(), "export")
	_, err = source.Export(ctx, exportPath)
	require.NoError(t, err)
	require.FileExists(t, filepath.Join(exportPath, "a", "b", "new.txt"))
	require.NoFileExists(t, filepath.Join(exportPath, "a", "x.txt"))
	require.NoFileExists(t, filepath.Join(exportPath, "a", "b", "y.txt"))

	copiedFiles, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithDirectory("/view", source).
		WithExec([]string{"sh", "-c", "find /view -type f | sed 's#^/view/##' | sort"}).
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, "a/b/new.txt\n", copiedFiles)

	copiedSubdirFiles, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithDirectory("/view", source.Directory("a/b")).
		WithExec([]string{"sh", "-c", "find /view -type f | sed 's#^/view/##' | sort"}).
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, "new.txt\n", copiedSubdirFiles)
}

func (DirectorySuite) TestWithDirectoryWhiteoutSourceAncestor(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	source := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithDirectory("/data", sdkcore.NewQuery(c).Directory().
			WithNewFile("a/x.txt", "old").
			WithNewFile("a/b/y.txt", "old").
			WithNewFile("a/b/keep.txt", "old")).
		WithExec([]string{"sh", "-c", "rm -rf /data/a/b"}).
		WithExec([]string{"sh", "-c", "mkdir -p /data/a/b && echo new > /data/a/b/new.txt"}).
		Directory("/data")

	mountedFiles, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithMountedDirectory("/view", source).
		WithExec([]string{"sh", "-c", "find /view -type f | sed 's#^/view/##' | sort"}).
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, "a/b/new.txt\na/x.txt\n", mountedFiles)

	copied := sdkcore.NewQuery(c).Directory().WithDirectory("view", source)
	copiedFiles, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithMountedDirectory("/result", copied).
		WithExec([]string{"sh", "-c", "find /result/view -type f | sed 's#^/result/view/##' | sort"}).
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, "a/b/new.txt\na/x.txt\n", copiedFiles)

	contents, err := copied.File("view/a/b/new.txt").Contents(ctx)
	require.NoError(t, err)
	require.Equal(t, "new\n", contents)

	copiedSubdir := sdkcore.NewQuery(c).Directory().WithDirectory("view", source.Directory("a/b"))
	copiedSubdirFiles, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithMountedDirectory("/result", copiedSubdir).
		WithExec([]string{"sh", "-c", "find /result/view -type f | sed 's#^/result/view/##' | sort"}).
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, "new.txt\n", copiedSubdirFiles)
}

func (DirectorySuite) TestWithDirectoryPermissionsOverride(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	src := sdkcore.NewQuery(c).Directory().
		WithNewDirectory("nested", sdkcore.DirectoryWithNewDirectoryOpts{Permissions: 0o700}).
		WithNewFile("nested/file.txt", "nested", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o600}).
		WithNewFile("root.txt", "root", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o640})

	dir := sdkcore.NewQuery(c).Directory().WithDirectory("out", src, sdkcore.DirectoryWithDirectoryOpts{
		Permissions: 0o751,
	})

	ctr := sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/", dir)
	stdout, err := ctr.WithExec([]string{"sh", "-lc", "stat -c '%a %n' /out /out/nested /out/nested/file.txt /out/root.txt"}).Stdout(ctx)
	require.NoError(t, err)
	require.Contains(t, stdout, "751 /out")
	require.Contains(t, stdout, "751 /out/nested")
	require.Contains(t, stdout, "751 /out/nested/file.txt")
	require.Contains(t, stdout, "751 /out/root.txt")

	dir = sdkcore.NewQuery(c).Directory().WithDirectory("/", src, sdkcore.DirectoryWithDirectoryOpts{
		Permissions: 0o751,
	})

	ctr = sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/", dir)
	stdout, err = ctr.WithExec([]string{"sh", "-lc", "stat -c '%a %n' /nested /nested/file.txt /root.txt"}).Stdout(ctx)
	require.NoError(t, err)
	require.Contains(t, stdout, "751 /nested")
	require.Contains(t, stdout, "751 /nested/file.txt")
	require.Contains(t, stdout, "751 /root.txt")
}

func (DirectorySuite) TestWithDirectoryUnion(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	dir1 := sdkcore.NewQuery(c).Container().From(alpineImage).
		WithMountedDirectory("/working", sdkcore.NewQuery(c).Directory()).
		WithWorkdir("/working").
		WithNewFile("data/some-file", "some-content").
		Directory("/working")

	dir2 := sdkcore.NewQuery(c).Container().From(alpineImage).
		WithMountedDirectory("/working", sdkcore.NewQuery(c).Directory()).
		WithWorkdir("/working").
		WithNewFile("data/some-other-file", "some-other-content").
		Directory("/working")

	dir1 = dir1.WithDirectory("/d", dir1.Directory("/data")).
		WithoutDirectory("/data")

	dir2 = dir2.WithDirectory("/d", dir2.Directory("/data")).
		WithoutDirectory("/data")

	ctr := sdkcore.NewQuery(c).Container().From(alpineImage)

	ctr = ctr.WithDirectory("/", dir1)
	ctr = ctr.WithDirectory("/", dir2)

	contents, err := ctr.File("/d/some-file").Contents(ctx)
	require.NoError(t, err)
	require.Equal(t, "some-content", contents)

	contents, err = ctr.File("/d/some-other-file").Contents(ctx)
	require.NoError(t, err)
	require.Equal(t, "some-other-content", contents)
}

func (DirectorySuite) TestDirectoryFilterIncludeExclude(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	dir := sdkcore.NewQuery(c).Directory().
		WithNewFile("a.txt", "").
		WithNewFile("b.txt", "").
		WithNewFile("c.txt.rar", "").
		WithNewFile("subdir/d.txt", "").
		WithNewFile("subdir/e.txt", "").
		WithNewFile("subdir/f.txt.rar", "")

	t.Run("exclude", func(ctx context.Context, t *testctx.T) {
		entries, err := dir.Filter(sdkcore.DirectoryFilterOpts{
			Exclude: []string{"*.rar"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"a.txt", "b.txt", "subdir/"}, entries)
	})

	t.Run("include", func(ctx context.Context, t *testctx.T) {
		entries, err := dir.Filter(sdkcore.DirectoryFilterOpts{
			Include: []string{"*.rar"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"c.txt.rar"}, entries)
	})

	t.Run("exclude overrides include", func(ctx context.Context, t *testctx.T) {
		entries, err := dir.Filter(sdkcore.DirectoryFilterOpts{
			Include: []string{"*.txt"},
			Exclude: []string{"b.txt"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"a.txt"}, entries)
	})

	t.Run("include does not override exclude", func(ctx context.Context, t *testctx.T) {
		entries, err := dir.Filter(sdkcore.DirectoryFilterOpts{
			Include: []string{"a.txt"},
			Exclude: []string{"*.txt"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{}, entries)
	})

	t.Run("exclude works on directory", func(ctx context.Context, t *testctx.T) {
		entries, err := dir.Filter(sdkcore.DirectoryFilterOpts{
			Exclude: []string{"subdir"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"a.txt", "b.txt", "c.txt.rar"}, entries)
	})

	t.Run("exclude respects subdir", func(ctx context.Context, t *testctx.T) {
		subdir := dir.Directory("subdir")
		entries, err := subdir.Filter(sdkcore.DirectoryFilterOpts{
			Exclude: []string{"*.rar"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"d.txt", "e.txt"}, entries)
	})

	t.Run("gitignore works", func(ctx context.Context, t *testctx.T) {
		dir := dir.WithNewFile(".gitignore", "b.txt\nsubdir/\n")
		entries, err := dir.Filter(sdkcore.DirectoryFilterOpts{
			Gitignore: true,
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{".gitignore", "a.txt", "c.txt.rar"}, entries)
	})
}

func (DirectorySuite) TestWithDirectoryIncludeExclude(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	dir := sdkcore.NewQuery(c).Directory().
		WithNewFile("a.txt", "").
		WithNewFile("b.txt", "").
		WithNewFile("c.txt.rar", "").
		WithNewFile("subdir/d.txt", "").
		WithNewFile("subdir/e.txt", "").
		WithNewFile("subdir/f.txt.rar", "")

	t.Run("exclude", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithDirectory(".", dir, sdkcore.DirectoryWithDirectoryOpts{
			Exclude: []string{"*.rar"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"a.txt", "b.txt", "subdir/"}, entries)
	})

	t.Run("include", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithDirectory(".", dir, sdkcore.DirectoryWithDirectoryOpts{
			Include: []string{"*.rar"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"c.txt.rar"}, entries)
	})

	t.Run("exclude overrides include", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithDirectory(".", dir, sdkcore.DirectoryWithDirectoryOpts{
			Include: []string{"*.txt"},
			Exclude: []string{"b.txt"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"a.txt"}, entries)
	})

	t.Run("include does not override exclude", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithDirectory(".", dir, sdkcore.DirectoryWithDirectoryOpts{
			Include: []string{"a.txt"},
			Exclude: []string{"*.txt"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{}, entries)
	})

	t.Run("exclude works on directory", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithDirectory(".", dir, sdkcore.DirectoryWithDirectoryOpts{
			Exclude: []string{"subdir"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"a.txt", "b.txt", "c.txt.rar"}, entries)
	})

	subdir := dir.Directory("subdir")

	t.Run("exclude respects subdir", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithDirectory(".", subdir, sdkcore.DirectoryWithDirectoryOpts{
			Exclude: []string{"*.rar"},
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"d.txt", "e.txt"}, entries)
	})

	t.Run("gitignore works", func(ctx context.Context, t *testctx.T) {
		dir := dir.WithNewFile(".gitignore", "b.txt\nsubdir/\n")
		entries, err := dir.Filter(sdkcore.DirectoryFilterOpts{
			Gitignore: true,
		}).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{".gitignore", "a.txt", "c.txt.rar"}, entries)
	})
}

func (DirectorySuite) TestWithNewDirectory(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	dir := sdkcore.NewQuery(c).Directory().
		WithNewDirectory("a").
		WithNewDirectory("b/c")

	entries, err := dir.Entries(ctx)
	require.NoError(t, err)
	require.Equal(t, []string{"a/", "b/"}, entries)

	entries, err = dir.Entries(ctx, sdkcore.DirectoryEntriesOpts{
		Path: "b",
	})
	require.NoError(t, err)
	require.Equal(t, []string{"c/"}, entries)

	t.Run("does not permit creating directory outside of root", func(ctx context.Context, t *testctx.T) {
		_, err := dir.Directory("b").WithNewDirectory("../c").Sync(ctx)
		require.ErrorContains(t, err, "cannot create directory outside parent")
	})
}

func (DirectorySuite) TestWithFile(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	file := sdkcore.NewQuery(c).Directory().
		WithNewFile("some-file", "some-content").
		WithNewFile("some-other-file", "some-other-content").
		File("some-file")

	dirWithFile := sdkcore.NewQuery(c).Directory().WithFile("target-file", file)
	content, err := dirWithFile.
		File("target-file").Contents(ctx)
	require.NoError(t, err)
	require.Equal(t, "some-content", content)
	_, err = dirWithFile.File("some-other-file").Contents(ctx)
	require.Error(t, err)

	// Same as above, but use the same name for the file rather than changing it.
	// Needed for testing merge-op corner cases.
	dirWithFile = sdkcore.NewQuery(c).Directory().WithFile("some-file", file)
	content, err = dirWithFile.
		File("some-file").Contents(ctx)
	require.NoError(t, err)
	require.Equal(t, "some-content", content)
	_, err = dirWithFile.File("some-other-file").Contents(ctx)
	require.Error(t, err)

	content, err = sdkcore.NewQuery(c).Directory().
		WithFile("sub-dir/target-file", file).
		File("sub-dir/target-file").Contents(ctx)
	require.NoError(t, err)
	require.Equal(t, "some-content", content)

	t.Run("respects permissions", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile(
				"file-with-permissions",
				"this should have rwxrwxrwx permissions",
				sdkcore.DirectoryWithNewFileOpts{Permissions: 0o777})

		ctr := sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/permissions-test", dir)

		stdout, err := ctr.WithExec([]string{"ls", "-l", "/permissions-test/file-with-permissions"}).Stdout(ctx)
		require.NoError(t, err)
		require.Contains(t, stdout, "rwxrwxrwx")

		dir2 := sdkcore.NewQuery(c).Directory().
			WithNewFile(
				"file-with-permissions",
				"this should have rw-r--r-- permissions")
		ctr2 := sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/permissions-test", dir2)
		stdout2, err := ctr2.WithExec([]string{"ls", "-l", "/permissions-test/file-with-permissions"}).Stdout(ctx)
		require.NoError(t, err)
		require.Contains(t, stdout2, "rw-r--r--")
	})

	t.Run("dir reference is kept", func(ctx context.Context, t *testctx.T) {
		f := sdkcore.NewQuery(c).Directory().WithNewFile("some-file", "data").File("some-file")

		d2 := sdkcore.NewQuery(c).Directory().
			WithNewFile("some-other-file", "other-data").
			WithNewDirectory("some-dir").
			Directory("/some-dir").
			WithFile("f", f)

		// this should no longer be available, since dir.Dir should now be "/dir1"
		_, err := d2.File("some-other-file").Contents(ctx)
		require.Error(t, err)

		s, err := d2.File("f").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "data", s)
	})

	for _, dst := range []string{".", "", "/"} {
		t.Run(fmt.Sprintf("src filename is used dst is a directory referenced by %s", dst), func(ctx context.Context, t *testctx.T) {
			f := sdkcore.NewQuery(c).Directory().WithNewFile("some-file", "data").File("some-file")
			d := sdkcore.NewQuery(c).Directory().WithFile(dst, f)
			s, err := d.File("some-file").Contents(ctx)
			require.NoError(t, err)
			require.Equal(t, "data", s)
		})
	}

	t.Run("src filename (and not directory names) is used dst is empty", func(ctx context.Context, t *testctx.T) {
		f := sdkcore.NewQuery(c).Directory().WithNewFile("sub/subterrain/some-file", "data").File("sub/subterrain/some-file")
		d := sdkcore.NewQuery(c).Directory().WithFile("", f)
		s, err := d.File("some-file").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "data", s)
	})
}

func (DirectorySuite) TestWithFiles(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	file1 := sdkcore.NewQuery(c).Directory().
		WithNewFile("first-file", "file1 content").
		File("first-file")
	file2 := sdkcore.NewQuery(c).Directory().
		WithNewFile("second-file", "file2 content").
		File("second-file")
	files := []*sdkcore.File{file1, file2}

	check := func(ctx context.Context, t *testctx.T, dir *sdkcore.Directory, path string) {
		contents, err := dir.File(filepath.Join(path, "first-file")).Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "file1 content", contents)

		contents, err = dir.File(filepath.Join(path, "second-file")).Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "file2 content", contents)
	}

	t.Run("root", func(ctx context.Context, t *testctx.T) {
		path := "/"
		dir := sdkcore.NewQuery(c).Directory().WithFiles(path, files)
		check(ctx, t, dir, path)
	})

	t.Run("sub", func(ctx context.Context, t *testctx.T) {
		path := "/a/b/c"
		dir := sdkcore.NewQuery(c).Directory().WithFiles(path, files)
		check(ctx, t, dir, path)
	})

	t.Run("sub trailing", func(ctx context.Context, t *testctx.T) {
		path := "/a/b/c/"
		dir := sdkcore.NewQuery(c).Directory().WithFiles(path, files)
		check(ctx, t, dir, path)
	})

	t.Run("respects permissions", func(ctx context.Context, t *testctx.T) {
		file1 := sdkcore.NewQuery(c).Directory().
			WithNewFile("file-set-permissions", "this should have rwxrwxrwx permissions", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o777}).
			File("file-set-permissions")
		file2 := sdkcore.NewQuery(c).Directory().
			WithNewFile("file-default-permissions", "this should have rw-r--r-- permissions").
			File("file-default-permissions")
		files := []*sdkcore.File{file1, file2}
		dir := sdkcore.NewQuery(c).Directory().
			WithFiles("/", files)

		ctr := sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/permissions-test", dir)

		stdout, err := ctr.WithExec([]string{"ls", "-l", "/permissions-test/file-set-permissions"}).Stdout(ctx)
		require.NoError(t, err)
		require.Contains(t, stdout, "rwxrwxrwx")

		ctr2 := sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/permissions-test", dir)
		stdout2, err := ctr2.WithExec([]string{"ls", "-l", "/permissions-test/file-default-permissions"}).Stdout(ctx)
		require.NoError(t, err)
		require.Contains(t, stdout2, "rw-r--r--")
	})

	// sameAsChain checks that withFiles gives the same directory as the
	// equivalent withFile chain, and returns that directory's listing.
	sameAsChain := func(ctx context.Context, t *testctx.T, base *sdkcore.Directory, dest string, files []*sdkcore.File, mode *int) string {
		var opts sdkcore.DirectoryWithFilesOpts
		var fileOpts sdkcore.DirectoryWithFileOpts
		if mode != nil {
			opts.Permissions = *mode
			fileOpts.Permissions = *mode
		}
		bulk := base.WithFiles(dest, files, opts)
		chain := base
		for _, f := range files {
			name, err := f.Name(ctx)
			require.NoError(t, err)
			chain = chain.WithFile(filepath.Join(dest, name), f, fileOpts)
		}

		bulkDigest, err := bulk.Digest(ctx)
		require.NoError(t, err)
		chainDigest, err := chain.Digest(ctx)
		require.NoError(t, err)
		require.Equal(t, chainDigest, bulkDigest)

		listing := func(dir *sdkcore.Directory) string {
			out, err := sdkcore.NewQuery(c).Container().From(alpineImage).
				WithMountedDirectory("/m", dir).
				WithWorkdir("/m").
				WithExec([]string{"sh", "-c", `find . -exec stat -c '%n %F %a %u:%g %s' {} + | sort; find . -type f | sort | xargs cat`}).
				Stdout(ctx)
			require.NoError(t, err)
			return out
		}
		want := listing(chain)
		require.Equal(t, want, listing(bulk))
		return want
	}
	perms := 0o640

	t.Run("same result as a withFile chain", func(ctx context.Context, t *testctx.T) {
		src := sdkcore.NewQuery(c).Directory().
			WithNewFile("one", "one").
			WithNewFile("nested/two", "two", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o755}).
			WithNewFile("other/one", "one again")
		owned := sdkcore.NewQuery(c).Container().From(alpineImage).
			WithExec([]string{"sh", "-c", "echo owned > /owned && chown 1000:1000 /owned && chmod 0640 /owned"}).
			File("/owned")
		files := []*sdkcore.File{
			src.File("one"),
			src.File("nested/two"),
			sdkcore.NewQuery(c).Directory().WithNewFile("three", "three", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o600}).File("three"),
			owned,
			// Same name as the first: the later copy wins.
			src.File("other/one"),
			sdkcore.NewQuery(c).Directory().WithNewFile("deep/four", "four").File("deep/four").WithName("renamed"),
		}
		// The receiver is a subdirectory and has a file that one copy replaces.
		base := sdkcore.NewQuery(c).Directory().
			WithNewFile("root/keep", "keep").
			WithNewFile("root/dest/three", "replaced").
			WithNewFile("outside", "not in the receiver").
			Directory("root")

		for _, dest := range []string{"dest", "/dest/", ".", "a/b/c"} {
			for _, mode := range []*int{nil, &perms} {
				t.Run(fmt.Sprintf("%s permissions=%v", dest, mode != nil), func(ctx context.Context, t *testctx.T) {
					got := sameAsChain(ctx, t, base, dest, files, mode)
					require.Contains(t, got, "one again")
					require.NotContains(t, got, "not in the receiver")
					if strings.Contains(dest, "dest") {
						require.NotContains(t, got, "replaced")
					}
				})
			}
		}
	})

	t.Run("repeated and hard-linked sources", func(ctx context.Context, t *testctx.T) {
		// A/a and A/b are one inode; B/a has the same name as A/a.
		ctr := sdkcore.NewQuery(c).Container().From(alpineImage).
			WithExec([]string{"sh", "-c", "mkdir /A /B && echo A > /A/a && ln /A/a /A/b && echo B > /B/a"})
		for name, files := range map[string][]*sdkcore.File{
			"same file twice": {ctr.File("/A/a"), ctr.File("/A/a")},
			"replaced link":   {ctr.File("/A/a"), ctr.File("/B/a"), ctr.File("/A/b")},
		} {
			for _, mode := range []*int{nil, &perms} {
				t.Run(fmt.Sprintf("%s permissions=%v", name, mode != nil), func(ctx context.Context, t *testctx.T) {
					got := sameAsChain(ctx, t, sdkcore.NewQuery(c).Directory(), "dest", files, mode)
					if name == "replaced link" {
						require.Contains(t, got, "B\nA\n")
					}
				})
			}
		}
	})
}

func (DirectorySuite) TestWithTimestamps(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	reallyImportantTime := time.Date(1985, 10, 26, 8, 15, 0, 0, time.UTC)

	dir := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithExec([]string{"sh", "-c", `
		  mkdir output
			touch output/some-file
			mkdir output/sub-dir
			touch output/sub-dir/sub-file
		`}).
		Directory("output").
		WithTimestamps(int(reallyImportantTime.Unix()))

	t.Run("changes file and directory timestamps recursively", func(ctx context.Context, t *testctx.T) {
		ls, err := sdkcore.NewQuery(c).Container().
			From(alpineImage).
			WithMountedDirectory("/dir", dir).
			WithEnvVariable("RANDOM", rand.Text()).
			WithExec([]string{"sh", "-c", "ls -al /dir && ls -al /dir/sub-dir"}).
			Stdout(ctx)
		require.NoError(t, err)
		require.Regexp(t, regexp.MustCompile(`-rw-r--r--\s+\d+ root\s+root\s+\d+ Oct 26  1985 some-file`), ls)
		require.Regexp(t, regexp.MustCompile(`drwxr-xr-x\s+\d+ root\s+root\s+\d+ Oct 26  1985 sub-dir`), ls)
		require.Regexp(t, regexp.MustCompile(`-rw-r--r--\s+\d+ root\s+root\s+\d+ Oct 26  1985 sub-file`), ls)
	})

	t.Run("results in stable tar archiving", func(ctx context.Context, t *testctx.T) {
		content, err := sdkcore.NewQuery(c).Container().
			From(alpineImage).
			WithMountedDirectory("/dir", dir).
			WithEnvVariable("RANDOM", rand.Text()).
			// NB: there's a gotcha here: we need to tar * and not . because the
			// directory itself has an unstable timestamp. :(
			WithExec([]string{"sh", "-c", "tar -cf - -C /dir * | sha256sum -"}).
			Stdout(ctx)
		require.NoError(t, err)
		require.Contains(t, content, "5f70bf18a086007016e948b04aed3b82103a36bea41755b6cddfaf10ace3c6ef")
	})
}

func (DirectorySuite) TestWithoutPaths(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	dir1 := sdkcore.NewQuery(c).Directory().
		WithNewFile("some-file", "some-content").
		WithNewFile("some-dir/sub-file", "sub-content")

	entries, err := dir1.
		WithoutDirectory("some-dir").
		Entries(ctx)

	require.NoError(t, err)
	require.Equal(t, []string{"some-file"}, entries)

	entries, err = dir1.
		WithoutDirectory("non-existent").
		Entries(ctx)

	require.NoError(t, err)
	require.Equal(t, []string{"some-dir/", "some-file"}, entries)

	dir := sdkcore.NewQuery(c).Directory().
		WithNewFile("foo.txt", "foo").
		WithNewFile("a/bar.txt", "bar").
		WithNewFile("a/data.json", "{\"datum\": 10}").
		WithNewFile("b/foo.txt", "foo").
		WithNewFile("b/bar.txt", "bar").
		WithNewFile("b/data.json", "{\"datum\": 10}").
		WithNewFile("c/file-a1.txt", "file-a1.txt").
		WithNewFile("c/file-a1.json", "file-a1.json").
		WithNewFile("c/file-b1.txt", "file-b1.txt").
		WithNewFile("c/file-b1.json", "file-b1.json")

	entries, err = dir.Entries(ctx)
	require.NoError(t, err)
	require.Equal(t, []string{"a/", "b/", "c/", "foo.txt"}, entries)

	entries, err = dir.
		WithoutDirectory("a").
		Entries(ctx)
	require.NoError(t, err)
	require.Equal(t, []string{"b/", "c/", "foo.txt"}, entries)

	entries, err = dir.
		WithoutFile("b/*.txt").
		Entries(ctx, sdkcore.DirectoryEntriesOpts{Path: "b"})

	require.NoError(t, err)
	require.Equal(t, []string{"data.json"}, entries)

	entries, err = dir.
		WithoutFile("c/*a1*").
		Entries(ctx, sdkcore.DirectoryEntriesOpts{Path: "c"})

	require.NoError(t, err)
	require.Equal(t, []string{"file-b1.json", "file-b1.txt"}, entries)

	dirDir := sdkcore.NewQuery(c).Directory().
		WithNewFile("foo.txt", "foo").
		WithNewFile("a1/a1-file", "a1-file").
		WithNewFile("a2/a2-file", "a2-file").
		WithNewFile("b1/b1-file", "b1-file")

	entries, err = dirDir.WithoutDirectory("a*").Entries(ctx)
	require.NoError(t, err)
	require.Equal(t, []string{"b1/", "foo.txt"}, entries)

	// Test WithoutFile
	filesDir := sdkcore.NewQuery(c).Directory().
		WithNewFile("some-file", "some-content").
		WithNewFile("some-dir/sub-file", "sub-content").
		WithoutFile("some-file")

	entries, err = filesDir.Entries(ctx)
	require.NoError(t, err)
	require.Equal(t, []string{"some-dir/"}, entries)

	// Test WithoutFiles
	filesDir = sdkcore.NewQuery(c).Directory().
		WithNewFile("some-file", "some-content").
		WithNewFile("some-file-2", "some-content").
		WithNewFile("some-dir/sub-file", "sub-content").
		WithoutFiles([]string{"some-file", "some-file-2"})

	entries, err = filesDir.Entries(ctx)
	require.NoError(t, err)
	require.Equal(t, []string{"some-dir/"}, entries)

	// verify WithoutFile works when dir has be selected to a subdir
	subdirWithout := sdkcore.NewQuery(c).Directory().
		WithDirectory("subdir", sdkcore.NewQuery(c).Directory().
			WithNewFile("some-file", "delete me").
			WithNewFile("some-other-file", "keep me"),
		).
		Directory("subdir").
		WithoutFile("some-file")
	entries, err = subdirWithout.Entries(ctx)
	require.NoError(t, err)
	require.Equal(t, []string{"some-other-file"}, entries)
}

func (DirectorySuite) TestDiff(ctx context.Context, t *testctx.T) {
	t.Run("basic", func(ctx context.Context, t *testctx.T) {
		aID := newDirWithFile(t, "a-file", "a-content")
		bID := newDirWithFile(t, "b-file", "b-content")

		diff := `query Diff($id: ID!, $other: ID!) {
			directory: node(id: $id) {
				... on Directory {
					diff(other: $other) {
						entries
					}
				}
			}
		}`
		c := connect(ctx, t)
		res, err := testutil.QueryWithClient[struct {
			Directory struct {
				Diff struct {
					Entries []string
				}
			} `json:"directory"`
		}](c, t, diff, &testutil.QueryOptions{
			Variables: map[string]any{
				"id":    aID,
				"other": bID,
			},
		})
		require.NoError(t, err)

		require.Equal(t, []string{"b-file"}, res.Directory.Diff.Entries)

		res, err = testutil.QueryWithClient[struct {
			Directory struct {
				Diff struct {
					Entries []string
				}
			} `json:"directory"`
		}](c, t, diff, &testutil.QueryOptions{
			Variables: map[string]any{
				"id":    bID,
				"other": aID,
			},
		})
		require.NoError(t, err)

		require.Equal(t, []string{"a-file"}, res.Directory.Diff.Entries)
	})

	// this is a regression test for: https://github.com/dagger/dagger/pull/7328
	t.Run("equivalent", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)
		// This diff checks source content equivalence; .git checkout metadata is not stable enough for it.
		a := sdkcore.NewQuery(c).Git("github.com/dagger/dagger").Ref("main").Tree(sdkcore.GitRefTreeOpts{DiscardGitDir: true})
		b := sdkcore.NewQuery(c).Directory().WithDirectory("", a)
		ents, err := a.Diff(b).Entries(ctx)
		require.NoError(t, err)
		require.Len(t, ents, 0)
	})

	// this is a regression test for: https://github.com/dagger/dagger/pull/11107
	t.Run("equivalent subdirs", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)
		a := sdkcore.NewQuery(c).Git("github.com/dagger/dagger").Ref("main").Tree().Directory("engine")
		b := sdkcore.NewQuery(c).Directory().WithDirectory("engine", a).Directory("engine")
		_, err := a.Diff(b).Sync(ctx)
		require.NoError(t, err)
		ents, err := a.Diff(b).Entries(ctx)
		require.NoError(t, err)
		require.Len(t, ents, 0)
	})

	t.Run("different subdirs", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)
		d := sdkcore.NewQuery(c).Directory().
			WithNewDirectory("sub").
			WithNewDirectory("submarine").
			WithNewFile("sub/file1", "data1").
			WithNewFile("submarine/file1", "data1").
			WithNewFile("submarine/file2", "data2").
			WithTimestamps(0)

		ents, err := d.Directory("sub").Diff(d.Directory("submarine")).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, ents, []string{"file2"})
	})

	t.Run("lower scratch", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)
		upper := sdkcore.NewQuery(c).Directory().WithNewFile("file", "content")
		lower := sdkcore.NewQuery(c).Directory()

		ents, err := lower.Diff(upper).Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, ents, []string{"file"})
	})

	/*
		This triggers a nil panic in Buildkit!

		Issue: https://github.com/dagger/dagger/issues/3337

		This might be fixed once we update Buildkit.

		err = testutil.Query(diff, &res, &testutil.QueryOptions{
			Variables: map[string]any{
				"id":    aID,
				"other": aID,
			},
		})
		require.NoError(t, err)

		require.Empty(t, res.Directory.Diff.Entries)
	*/
}

func (DirectorySuite) TestChown(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	_, err := sdkcore.NewQuery(c).Directory().
		WithNewDirectory("dir").
		Chown("dir", "555:556").
		Sync(ctx)
	require.NoError(t, err)
}

func (DirectorySuite) TestChownLookup(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	d := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithExec([]string{"sh", "-c", "addgroup -g 4321 agroup && adduser -D -u 1234 -G agroup auser"}).
		Rootfs().
		WithNewDirectory("dir").
		WithNewFile("dir/file.txt", "hello").
		Chown("dir", "auser:agroup")

	out, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithExec([]string{"sh", "-c", "addgroup -g 4321 agroup && adduser -D -u 1234 -G agroup auser"}).
		WithMountedDirectory("/mnt", d.Directory("dir")).
		WithExec([]string{"stat", "-c", "%u:%g %U:%G", "/mnt/file.txt"}).
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, "1234:4321 auser:agroup\n", out)
}

func (DirectorySuite) TestExport(ctx context.Context, t *testctx.T) {
	wd := t.TempDir()
	dest := t.TempDir()

	c := connect(ctx, t, dagger.WithWorkdir(wd))

	dir := sdkcore.NewQuery(c).Container().From(alpineImage).Directory("/etc/profile.d")

	t.Run("to absolute dir", func(ctx context.Context, t *testctx.T) {
		actual, err := dir.Export(ctx, dest)
		require.NoError(t, err)
		require.Equal(t, dest, actual)

		entries, err := ls(dest)
		require.NoError(t, err)
		require.Equal(t, []string{"20locale.sh", "README", "color_prompt.sh.disabled"}, entries)
	})

	t.Run("to workdir", func(ctx context.Context, t *testctx.T) {
		actual, err := dir.Export(ctx, ".")
		require.NoError(t, err)
		require.Equal(t, wd, actual)

		entries, err := ls(wd)
		require.NoError(t, err)
		require.Equal(t, []string{"20locale.sh", "README", "color_prompt.sh.disabled"}, entries)

		t.Run("wipe flag", func(ctx context.Context, t *testctx.T) {
			dir := dir.WithoutFile("README")

			// by default a delete in the source dir won't overwrite the destination on the host
			actual, err := dir.Export(ctx, ".")
			require.NoError(t, err)
			require.Contains(t, wd, actual)
			entries, err = ls(wd)
			require.NoError(t, err)
			require.Equal(t, []string{"20locale.sh", "README", "color_prompt.sh.disabled"}, entries)

			// wipe results in the destination being replaced with the source entirely, including deletes
			actual, err = dir.Export(ctx, ".", sdkcore.DirectoryExportOpts{Wipe: true})
			require.NoError(t, err)
			require.Equal(t, wd, actual)
			entries, err = ls(wd)
			require.NoError(t, err)
			require.Equal(t, []string{"20locale.sh", "color_prompt.sh.disabled"}, entries)
		})
	})

	t.Run("to outer dir", func(ctx context.Context, t *testctx.T) {
		actual, err := dir.Export(ctx, "../")
		require.NoError(t, err)
		require.Contains(t, actual, "/")
	})
}

func (DirectorySuite) TestWithNewFileExceedingLength(ctx context.Context, t *testctx.T) {
	_, err := testutil.Query[struct {
		Directory struct {
			WithNewFile struct {
				ID core.DirectoryID
			}
		}
	}](t,
		`{
			directory {
				withNewFile(path: "bhhivbryticrxrjssjtflvkxjsqyltawpjexixdfnzoxpoxtdheuhvqalteblsqspfeblfaayvrxejknhpezrxtwxmqzaxgtjdupwnwyosqbvypdwroozcyplzhdxrrvhpskmocmgtdnoeaecbyvpovpwdwpytdxwwedueyaxytxsnnnsfpfjtnlkrxwxtcikcocnkobvdxdqpbafqhmidqbrnhxlxqynesyijgkfepokrnsfqneixfvgsdy.txt", contents: "some-content") {
					sync
				}
			}
		}`, nil)
	require.Error(t, err)
	requireErrOut(t, err, "File name length exceeds the maximum supported 255 characters")
}

func (DirectorySuite) TestWithFileExceedingLength(ctx context.Context, t *testctx.T) {
	_, err := testutil.Query[struct {
		Directory struct {
			WithNewFile struct {
				file struct {
					ID core.DirectoryID
				}
			}
		}
	}](t,
		`{
			directory {
				withNewFile(path: "dir/bhhivbryticrxrjssjtflvkxjsqyltawpjexixdfnzoxpoxtdheuhvqalteblsqspfeblfaayvrxejknhpezrxtwxmqzaxgtjdupwnwyosqbvypdwroozcyplzhdxrrvhpskmocmgtdnoeaecbyvpovpwdwpytdxwwedueyaxytxsnnnsfpfjtnlkrxwxtcikcocnkobvdxdqpbafqhmidqbrnhxlxqynesyijgkfepokrnsfqneixfvgsdy.txt", contents: "some-content") {
					file(path: "dir/bhhivbryticrxrjssjtflvkxjsqyltawpjexixdfnzoxpoxtdheuhvqalteblsqspfeblfaayvrxejknhpezrxtwxmqzaxgtjdupwnwyosqbvypdwroozcyplzhdxrrvhpskmocmgtdnoeaecbyvpovpwdwpytdxwwedueyaxytxsnnnsfpfjtnlkrxwxtcikcocnkobvdxdqpbafqhmidqbrnhxlxqynesyijgkfepokrnsfqneixfvgsdy.txt") {
						sync
					}
				}
			}
		}`, nil)
	require.Error(t, err)
	requireErrOut(t, err, "File name length exceeds the maximum supported 255 characters")
}

func (DirectorySuite) TestHardlinkCopy(ctx context.Context, t *testctx.T) {
	getDirInodes := func(c *dagger.Client, t *testctx.T, dir *sdkcore.Directory, fileNames ...string) []string {
		t.Helper()
		ctr := sdkcore.NewQuery(c).Container().From(alpineImage).
			WithMountedDirectory("/src", dir).
			WithWorkdir("/src")

		var inodes []string
		for _, fileName := range fileNames {
			out, err := ctr.WithExec([]string{
				"stat", "-c", "%i", fileName,
			}).Stdout(t.Context())
			require.NoError(t, err)
			inodes = append(inodes, strings.TrimSpace(out))
		}
		return inodes
	}

	getFileInode := func(c *dagger.Client, t *testctx.T, f *sdkcore.File) string {
		t.Helper()
		ctr := sdkcore.NewQuery(c).Container().From(alpineImage).
			WithMountedFile("/src/file", f).
			WithWorkdir("/src")

		out, err := ctr.WithExec([]string{
			"stat", "-c", "%i", "file",
		}).Stdout(t.Context())
		require.NoError(t, err)
		return strings.TrimSpace(out)
	}

	t.Run("with directory", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dirA := sdkcore.NewQuery(c).Directory().
			WithNewFile("fileA1", "contentA1").
			WithNewFile("fileA2", "contentA2").
			WithNewFile("common/f", "f").
			WithNewFile("common/a", "a")
		aRootInodes := getDirInodes(c, t, dirA, "fileA1", "fileA2")
		aCommonInodes := getDirInodes(c, t, dirA, "common/a")

		dirB := sdkcore.NewQuery(c).Directory().
			WithNewFile("fileB1", "contentB1").
			WithNewFile("fileB2", "contentB2").
			WithNewFile("subdir/fileB3", "contentB3").
			WithNewFile("extra/subdir/fileB4", "contentB4").
			WithNewFile("common/f", "f").
			WithNewFile("common/b", "b")
		bRootInodes := getDirInodes(c, t, dirB, "fileB1", "fileB2")
		bSubdirInodes := getDirInodes(c, t, dirB, "subdir/fileB3")
		bExtraSubdirInodes := getDirInodes(c, t, dirB, "extra/subdir/fileB4")
		bCommonInodes := getDirInodes(c, t, dirB, "common/b")
		bCommonFInodes := getDirInodes(c, t, dirB, "common/f")

		dirC := sdkcore.NewQuery(c).Directory().
			WithNewFile("fileC1", "contentC1").
			WithNewFile("fileC2", "contentC2").
			WithNewFile("subdir/fileC3", "contentC3")
		cRootInodes := getDirInodes(c, t, dirC, "fileC1", "fileC2")
		cSubdirInodes := getDirInodes(c, t, dirC, "subdir/fileC3")

		combinedDir := dirA.
			WithDirectory("/", dirB).
			WithDirectory("another/subdir", dirC)
		combinedRootInodes := getDirInodes(c, t, combinedDir,
			"fileA1", "fileA2",
			"fileB1", "fileB2",
		)
		combinedCommonInodes := getDirInodes(c, t, combinedDir,
			"common/a", "common/b",
		)
		combinedFInodes := getDirInodes(c, t, combinedDir,
			"common/f",
		)
		combinedSubdirInodes := getDirInodes(c, t, combinedDir,
			"subdir/fileB3",
		)
		combinedExtraSubdirInodes := getDirInodes(c, t, combinedDir,
			"extra/subdir/fileB4",
		)
		combinedCSubdirInodes := getDirInodes(c, t, combinedDir,
			"another/subdir/fileC1",
			"another/subdir/fileC2",
			"another/subdir/subdir/fileC3",
		)

		require.EqualValues(t, aRootInodes, combinedRootInodes[:2], "dirA root inodes should be preserved")
		require.EqualValues(t, bRootInodes, combinedRootInodes[2:4], "dirB root inodes should be preserved")
		require.EqualValues(t, aCommonInodes, combinedCommonInodes[:1], "dirA common inodes should be preserved")
		require.EqualValues(t, bCommonInodes, combinedCommonInodes[1:2], "dirB common inodes should be preserved")
		require.EqualValues(t, bCommonFInodes, combinedFInodes, "dirB common/f inode should be preserved")
		require.EqualValues(t, bSubdirInodes, combinedSubdirInodes, "dirB subdir inodes should be preserved")
		require.EqualValues(t, bExtraSubdirInodes, combinedExtraSubdirInodes, "dirB extra/subdir inodes should be preserved")
		require.EqualValues(t, cRootInodes, combinedCSubdirInodes[:2], "dirC root inodes should be preserved")
		require.EqualValues(t, cSubdirInodes, combinedCSubdirInodes[2:3], "dirC subdir inodes should be preserved")
	})

	t.Run("with file", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dirA := sdkcore.NewQuery(c).Directory().
			WithNewFile("fileA1", "contentA1")
		aInodes := getDirInodes(c, t, dirA, "fileA1")

		f1 := sdkcore.NewQuery(c).File("f1", "contentF1")
		f1Inode := getFileInode(c, t, f1)

		f2 := sdkcore.NewQuery(c).File("f2", "contentF2")
		f2Inode := getFileInode(c, t, f2)

		combinedDir := dirA.
			WithFile("fileFromF1", f1).
			WithFile("subdir/fileFromF2", f2)
		combinedInodes := getDirInodes(c, t, combinedDir,
			"fileA1",
			"fileFromF1",
			"subdir/fileFromF2",
		)

		require.EqualValues(t, aInodes, combinedInodes[:1], "dirA inodes should be preserved")
		require.Equal(t, f1Inode, combinedInodes[1], "f1 inode should be preserved")
		require.Equal(t, f2Inode, combinedInodes[2], "f2 inode should be preserved")
	})
}

func (DirectorySuite) TestFallbackMerge(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	t.Run("dest path same as src selector", func(ctx context.Context, t *testctx.T) {
		// corner case where we need to use the fallback rather than direct merge
		srcDir := sdkcore.NewQuery(c).Directory().
			WithNewFile("/toplevel", "").
			WithNewFile("/dir/lowerlevel", "")
		srcSubdir := srcDir.Directory("/dir")

		mergedDir := sdkcore.NewQuery(c).Directory().WithDirectory("/dir", srcSubdir)
		_, err := mergedDir.File("/dir/lowerlevel").Contents(ctx)
		require.NoError(t, err)
		_, err = mergedDir.File("/toplevel").Contents(ctx)
		require.Error(t, err)
	})
}

func (DirectorySuite) TestSync(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	t.Run("empty", func(ctx context.Context, t *testctx.T) {
		dir, err := sdkcore.NewQuery(c).Directory().Sync(ctx)
		require.NoError(t, err)

		entries, err := dir.Entries(ctx)
		require.NoError(t, err)
		require.Empty(t, entries)
	})

	t.Run("triggers error", func(ctx context.Context, t *testctx.T) {
		_, err := sdkcore.NewQuery(c).Directory().Directory("/foo").Sync(ctx)
		require.Error(t, err)
		requireErrOut(t, err, "foo: no such file or directory")

		_, err = sdkcore.NewQuery(c).Container().From(alpineImage).Directory("/bar").Sync(ctx)
		require.Error(t, err)
		requireErrOut(t, err, "bar: no such file or directory")
	})

	t.Run("allows chaining", func(ctx context.Context, t *testctx.T) {
		dir, err := sdkcore.NewQuery(c).Directory().WithNewFile("foo", "bar").Sync(ctx)
		require.NoError(t, err)

		entries, err := dir.Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"foo"}, entries)
	})
}

func (DirectorySuite) TestGlob(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	srcDir := sdkcore.NewQuery(c).Directory().
		WithNewFile("main.go", "native glob parity before 1792418218086919249").
		WithNewFile("func.go", "").
		WithNewFile("test.md", "").
		WithNewFile("foo.txt", "").
		WithNewFile("README.txt", "").
		WithNewDirectory("/subdir").
		WithNewFile("/subdir/foo.txt", "").
		WithNewFile("/subdir/README.md", "").
		WithNewDirectory("/subdir2").
		WithNewDirectory("/subdir2/subsubdir").
		WithNewFile("/subdir2/baz.txt", "").
		WithNewFile("/subdir2/TESTING.md", "").
		WithNewFile("/subdir/subsubdir/package.json", "").
		WithNewFile("/subdir/subsubdir/index.mts", "").
		WithNewFile("/subdir/subsubdir/JS.md", "")

	srcSubDir := sdkcore.NewQuery(c).Directory().
		WithDirectory("foobar", srcDir).
		Directory("foobar")

	srcAbsDir := sdkcore.NewQuery(c).Directory().
		WithDirectory("/foo/bar", srcDir).
		Directory("/foo/bar")

	testCases := []struct {
		name string
		src  *sdkcore.Directory
	}{
		{
			name: "current directory",
			src:  srcDir,
		},
		{
			name: "sub directory",
			src:  srcSubDir,
		},
		{
			name: "absolute directory",
			src:  srcAbsDir,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(ctx context.Context, t *testctx.T) {
			t.Run("include only markdown", func(ctx context.Context, t *testctx.T) {
				entries, err := tc.src.Glob(ctx, "*.md")

				require.NoError(t, err)
				require.ElementsMatch(t, entries, []string{"test.md"})
			})

			t.Run("recursive listing", func(ctx context.Context, t *testctx.T) {
				entries, err := tc.src.Glob(ctx, "**/*")

				require.NoError(t, err)
				require.ElementsMatch(t, entries, []string{
					"func.go", "main.go", "test.md", "foo.txt", "README.txt",
					"subdir/", "subdir/foo.txt", "subdir/README.md",
					"subdir2/", "subdir2/subsubdir/", "subdir2/baz.txt", "subdir2/TESTING.md",
					"subdir/subsubdir/", "subdir/subsubdir/package.json",
					"subdir/subsubdir/index.mts", "subdir/subsubdir/JS.md",
				})
			})

			t.Run("recursive that include only markdown", func(ctx context.Context, t *testctx.T) {
				entries, err := tc.src.Glob(ctx, "**/*.md")

				require.NoError(t, err)
				require.ElementsMatch(t, entries, []string{
					"test.md", "subdir/README.md",
					"subdir2/TESTING.md", "subdir/subsubdir/JS.md",
				})
			})

			t.Run("wildcard directory then trailing double star", func(ctx context.Context, t *testctx.T) {
				entries, err := tc.src.Glob(ctx, "subdir/*/**")

				require.NoError(t, err)
				require.ElementsMatch(t, entries, []string{
					"subdir/subsubdir/package.json", "subdir/subsubdir/index.mts", "subdir/subsubdir/JS.md",
				})
			})

			t.Run("recursive with complex pattern that include only markdown", func(ctx context.Context, t *testctx.T) {
				entries, err := tc.src.Glob(ctx, "subdir/**/*.md")

				require.NoError(t, err)
				require.ElementsMatch(t, entries, []string{
					"subdir/README.md", "subdir/subsubdir/JS.md",
				})
			})
		})
	}

	t.Run("recursive with directories in the pattern", func(ctx context.Context, t *testctx.T) {
		srcDir := sdkcore.NewQuery(c).Directory().
			WithNewFile("foo/bar.md/w.md", "").
			WithNewFile("foo/bar.md/x.go", "").
			WithNewFile("foo/baz.go/y.md", "").
			WithNewFile("foo/baz.go/z.go", "")

		entries, err := srcDir.Glob(ctx, "**/*.md")

		require.NoError(t, err)
		require.ElementsMatch(t, entries, []string{
			"foo/bar.md/",
			"foo/bar.md/w.md",
			"foo/baz.go/y.md",
		})
	})

	t.Run("sub directory in path", func(ctx context.Context, t *testctx.T) {
		srcDir := sdkcore.NewQuery(c).Directory().
			WithNewFile("foo/bar/x.md", "").
			WithNewFile("foo/bar/y.go", "")

		entries, err := srcDir.Directory("foo").Glob(ctx, "**/*.md")

		require.NoError(t, err)
		require.ElementsMatch(t, entries, []string{"bar/x.md"})
	})

	t.Run("empty sub directory", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().WithNewDirectory("foo").Glob(ctx, "**/*.md")
		require.NoError(t, err)
		require.Empty(t, entries)
	})

	t.Run("empty directory", func(ctx context.Context, t *testctx.T) {
		entries, err := sdkcore.NewQuery(c).Directory().Glob(ctx, "**/*")
		require.NoError(t, err)
		require.Empty(t, entries)
	})

	t.Run("directory doesn't exist", func(ctx context.Context, t *testctx.T) {
		_, err := sdkcore.NewQuery(c).Directory().Directory("foo").Glob(ctx, "**/*")
		requireErrOut(t, err, "foo: no such file or directory")
	})
}

func (DirectorySuite) TestDigest(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	t.Run("compute directory digest", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory().WithNewFile("/foo.txt", "Hello, World!")

		digest, err := dir.Directory("/").Digest(ctx)
		require.NoError(t, err)
		require.Equal(t, "sha256:48ac4b4b73af8a75a3c77e9dc6211d89321c6ed4f13c6987c6837ac58645bd89", digest)
	})

	t.Run("directory digest with same contents should be same", func(ctx context.Context, t *testctx.T) {
		a := sdkcore.NewQuery(c).Directory().WithNewDirectory("a").WithNewFile("a/foo.txt", "Hello, World!")
		b := sdkcore.NewQuery(c).Directory().WithNewDirectory("b").WithNewFile("b/foo.txt", "Hello, World!")

		aDigest, err := a.Directory("a").Digest(ctx)
		require.NoError(t, err)
		bDigest, err := b.Directory("b").Digest(ctx)
		require.NoError(t, err)
		require.Equal(t, aDigest, bDigest)
	})

	t.Run("directory digest with different metadata should be different", func(ctx context.Context, t *testctx.T) {
		fileWithOverwrittenMetadata := sdkcore.NewQuery(c).Directory().WithNewFile("foo.txt", "Hello, World!", sdkcore.DirectoryWithNewFileOpts{
			Permissions: 0777,
		}).File("foo.txt")
		fileWithDefaultMetadata := sdkcore.NewQuery(c).Directory().WithNewFile("foo.txt", "Hello, World!").File("foo.txt")

		digestFileWithOverwrittenMetadata, err := fileWithOverwrittenMetadata.Digest(ctx)
		require.NoError(t, err)

		digestFileWithDefaultMetadata, err := fileWithDefaultMetadata.Digest(ctx)
		require.NoError(t, err)

		require.NotEqual(t, digestFileWithOverwrittenMetadata, digestFileWithDefaultMetadata)
	})

	t.Run("scratch directory", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory()

		digest, err := dir.Digest(ctx)
		require.NoError(t, err)
		require.Equal(t, "sha256:0e5db88383bce812f795689f5318a2b2f4fde740ef31c2a2365a46368aafddd2", digest)
	})
}

func (DirectorySuite) TestDirectoryName(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	t.Run("empty directory name", func(ctx context.Context, t *testctx.T) {
		name, err := sdkcore.NewQuery(c).Directory().Name(ctx)
		require.NoError(t, err)
		require.Equal(t, "/", name)
	})

	t.Run("not found directory", func(ctx context.Context, t *testctx.T) {
		_, err := sdkcore.NewQuery(c).Directory().Directory("foo").Name(ctx)
		requireErrOut(t, err, "foo: no such file or directory")
	})

	t.Run("not found file displays full path in error", func(ctx context.Context, t *testctx.T) {
		_, err := sdkcore.NewQuery(c).Directory().Directory("keep/../this").Name(ctx)
		requireErrOut(t, err, "keep/../this: no such file or directory")
	})

	t.Run("structured directory", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory().WithDirectory("nested", sdkcore.NewQuery(c).Directory()).WithDirectory("very/nested", sdkcore.NewQuery(c).Directory())

		t.Run("root directory", func(ctx context.Context, t *testctx.T) {
			rootName, err := dir.Name(ctx)
			require.NoError(t, err)
			require.Equal(t, "/", rootName)
		})

		t.Run("nested directory", func(ctx context.Context, t *testctx.T) {
			nestedName, err := dir.Directory("nested").Name(ctx)
			require.NoError(t, err)
			require.Equal(t, "nested/", nestedName)
		})

		t.Run("very nested directory", func(ctx context.Context, t *testctx.T) {
			veryNestedName, err := dir.Directory("very/nested").Name(ctx)
			require.NoError(t, err)
			require.Equal(t, "nested/", veryNestedName)
		})
	})

	t.Run("git directory", func(ctx context.Context, t *testctx.T) {
		// Pin the commit explicitly: a git URL fragment is not honored by .Head()
		// (which tracks the live default branch), and .dagger no longer exists there.
		dir := sdkcore.NewQuery(c).Git("https://github.com/dagger/dagger").Commit("ee32df913f57c876e067bd5ecc159561510b6f50").Tree()

		t.Run("root directory", func(ctx context.Context, t *testctx.T) {
			rootName, err := dir.Name(ctx)
			require.NoError(t, err)
			require.Equal(t, "/", rootName)
		})

		t.Run("nested hidden directory", func(ctx context.Context, t *testctx.T) {
			nestedName, err := dir.Directory(".dagger").Name(ctx)
			require.NoError(t, err)
			require.Equal(t, ".dagger/", nestedName)
		})

		t.Run("nested directory", func(ctx context.Context, t *testctx.T) {
			nestedName, err := dir.Directory("sdk").Directory("go").Name(ctx)
			require.NoError(t, err)
			require.Equal(t, "go/", nestedName)
		})
	})
}

func (DirectorySuite) TestPatch(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	t.Run("onConflict LEAVE_CONFLICT_MARKERS", func(ctx context.Context, t *testctx.T) {
		// The patch expects "Hello, World!" in hello.txt, but the content has
		// drifted; other.txt still matches. This is the session-resume shape:
		// a recorded patch reapplied against files that moved on.
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("hello.txt", "Hello, Drifted!\n").
			WithNewFile("other.txt", "unchanged\n")

		patch := `--- a/hello.txt
+++ b/hello.txt
@@ -1 +1 @@
-Hello, World!
+Hello, Dagger!
--- a/other.txt
+++ b/other.txt
@@ -1 +1 @@
-unchanged
+updated
`

		// The default (FAIL) rejects the whole patch on the drifted hunk.
		_, err := dir.WithPatch(patch).Sync(ctx)
		require.Error(t, err)

		// LEAVE_CONFLICT_MARKERS applies what fits and marks what doesn't.
		patched := dir.WithPatch(patch, sdkcore.DirectoryWithPatchOpts{
			OnConflict: sdkcore.PatchConflictLeaveConflictMarkers,
		})
		content, err := patched.File("hello.txt").Contents(ctx)
		require.NoError(t, err)
		require.Contains(t, content, "<<<<<<< workspace")
		require.Contains(t, content, "Hello, Dagger!")
		require.Contains(t, content, "Hello, Drifted!")
		require.Contains(t, content, ">>>>>>> patch")

		other, err := patched.File("other.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "updated\n", other)
	})

	t.Run("basic patch application", func(ctx context.Context, t *testctx.T) {
		// Create a directory with a simple file
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("hello.txt", "Hello, World!\n")

		// Create a patch that modifies the file
		patch := `--- a/hello.txt
+++ b/hello.txt
@@ -1 +1 @@
-Hello, World!
+Hello, Dagger!
`

		// Apply the patch
		patchedDir := dir.WithPatch(patch)

		// Verify the patch was applied
		content, err := patchedDir.File("hello.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "Hello, Dagger!\n", content)
	})

	t.Run("patching a subdirectory", func(ctx context.Context, t *testctx.T) {
		// Create a directory with a simple file
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("sub/hello.txt", "Hello, World!\n").
			Directory("sub")

		// Create a patch that modifies the file
		patch := `--- a/hello.txt
+++ b/hello.txt
@@ -1 +1 @@
-Hello, World!
+Hello, Dagger!
`

		// Apply the patch
		patchedDir := dir.WithPatch(patch)

		// Verify the patch was applied
		content, err := patchedDir.File("hello.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "Hello, Dagger!\n", content)
	})

	t.Run("patch adding new file", func(ctx context.Context, t *testctx.T) {
		// Start with an empty directory
		dir := sdkcore.NewQuery(c).Directory()

		// Create a patch that adds a new file
		patch := `--- /dev/null
+++ b/newfile.txt
@@ -0,0 +1 @@
+This is a new file!
`

		// Apply the patch
		patchedDir := dir.WithPatch(patch)

		// Verify the new file was created
		content, err := patchedDir.File("newfile.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "This is a new file!\n", content)
	})

	t.Run("patch deleting file", func(ctx context.Context, t *testctx.T) {
		// Create a directory with a file to delete
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("delete-me.txt", "This file will be deleted\n").
			WithNewFile("keep-me.txt", "This file will be kept\n")

		// Create a patch that deletes the file
		patch := `--- a/delete-me.txt
+++ /dev/null
@@ -1 +0,0 @@
-This file will be deleted
`

		// Apply the patch
		patchedDir := dir.WithPatch(patch)

		// Verify the file was deleted
		ents, err := patchedDir.Entries(ctx)
		require.NoError(t, err)
		require.Equal(t, []string{"keep-me.txt"}, ents)
	})

	t.Run("multiple file patch", func(ctx context.Context, t *testctx.T) {
		// Create a directory with multiple files
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file1.txt", "Content 1\n").
			WithNewFile("file2.txt", "Content 2\n")

		// Create a patch that modifies both files
		patch := `--- a/file1.txt
+++ b/file1.txt
@@ -1 +1 @@
-Content 1
+Modified Content 1
--- a/file2.txt
+++ b/file2.txt
@@ -1 +1 @@
-Content 2
+Modified Content 2
`

		// Apply the patch
		patchedDir := dir.WithPatch(patch)

		// Verify both files were modified
		content1, err := patchedDir.File("file1.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "Modified Content 1\n", content1)

		content2, err := patchedDir.File("file2.txt").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "Modified Content 2\n", content2)
	})

	t.Run("empty patch", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("test.txt", "test content")

		// Create an empty patch
		invalidPatch := ""

		// Apply the empty patch and expect no error
		_, err := dir.WithPatch(invalidPatch).Sync(ctx)
		require.NoError(t, err)
	})

	t.Run("bad patch application", func(ctx context.Context, t *testctx.T) {
		// Create a directory with a simple file
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("hello.txt", "Hello, World!\n")

		// Create a patch that is looking for the wrong content
		invalidPatch := `--- a/hello.txt
+++ b/hello.txt
@@ -1 +1 @@
-Goodbye, World!
+Hello, Dagger!
`

		// Apply the invalid patch and expect an error
		_, err := dir.WithPatch(invalidPatch).Sync(ctx)
		require.Error(t, err)
	})
}

func (DirectorySuite) TestPatchFileLargerThanMaxFileContentsSize(ctx context.Context, t *testctx.T) {
	// Regression: WithPatchFile should not require loading patch contents into memory.
	// A patch larger than MaxFileContentsSize must still apply successfully.
	c := connect(ctx, t)
	largeFile := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithExec([]string{
			"sh",
			"-c",
			fmt.Sprintf("head -c %d /dev/zero | tr '\\000' 'a' > /large.txt", engineutil.MaxFileContentsSize+1),
		}).
		File("/large.txt")

	patchFile := sdkcore.NewQuery(c).Directory().
		WithFile("large.txt", largeFile).
		Changes(sdkcore.NewQuery(c).Directory()).
		AsPatch()

	patchSize, err := patchFile.Size(ctx)
	require.NoError(t, err)
	require.Greater(t, patchSize, engineutil.MaxFileContentsSize)

	patchID, err := patchFile.ID(ctx)
	require.NoError(t, err)

	loadedPatch := sdkcore.Ref[*sdkcore.File](sdkcore.NewQuery(c), patchID)
	loadedPatchID, err := loadedPatch.ID(ctx)
	require.NoError(t, err)
	require.Equal(t, patchID, loadedPatchID)

	loadedPatchSize, err := loadedPatch.Size(ctx)
	require.NoError(t, err)
	require.Equal(t, patchSize, loadedPatchSize)

	patchedDir := sdkcore.NewQuery(c).Directory().WithPatchFile(loadedPatch)
	_, err = patchedDir.Sync(ctx)
	require.NoError(t, err)

	size, err := patchedDir.File("large.txt").Size(ctx)
	require.NoError(t, err)
	require.Equal(t, engineutil.MaxFileContentsSize+1, size)
}

func (DirectorySuite) TestSearch(ctx context.Context, t *testctx.T) {
	t.Run("literal search", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file1.txt", "Hello, World!\nThis is a test file.\nWorld is great.").
			WithNewFile("file2.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("subdir/file3.txt", "Hello from subdirectory!\nWorld tour.")

		results, err := dir.Search(ctx, "World")
		require.NoError(t, err)

		// Collect all matches to check they're all present (order doesn't matter)
		var matches []string
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			absoluteOffset, err := result.AbsoluteOffset(ctx)
			require.NoError(t, err)
			matchedText, err := result.MatchedLines(ctx)
			require.NoError(t, err)
			submatches, err := result.Submatches(ctx)
			require.NoError(t, err)

			// Verify AbsoluteOffset is reasonable (non-negative)
			require.GreaterOrEqual(t, absoluteOffset, 0)

			// Verify we have at least one submatch for each result
			require.NotEmpty(t, submatches)

			// Verify submatch structure
			for _, submatch := range submatches {
				submatchText, err := submatch.Text(ctx)
				require.NoError(t, err)
				start, err := submatch.Start(ctx)
				require.NoError(t, err)
				end, err := submatch.End(ctx)
				require.NoError(t, err)

				require.NotEmpty(t, submatchText)
				require.GreaterOrEqual(t, start, 0)
				require.Equal(t, len("World"), end-start)
				require.Equal(t, "World", submatchText)
			}

			matches = append(matches, fmt.Sprintf("%s:%d:%s", filePath, lineNumber, matchedText))
		}

		// Check that we have all expected matches
		require.Contains(t, matches, "file1.txt:1:Hello, World!\n")
		require.Contains(t, matches, "file1.txt:3:World is great.")
		require.Contains(t, matches, "subdir/file3.txt:2:World tour.")
	})

	t.Run("search beginning with hyphen", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file1.txt", "Hello, World!\nThis is a --test-- file.\nWorld is great.").
			WithNewFile("file2.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("subdir/file3.txt", "Hello from subdirectory!\nWorld tour.")

		results, err := dir.Search(ctx, "-test")
		require.NoError(t, err)

		// Collect all matches to check they're all present (order doesn't matter)
		var matches []string
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			absoluteOffset, err := result.AbsoluteOffset(ctx)
			require.NoError(t, err)
			matchedText, err := result.MatchedLines(ctx)
			require.NoError(t, err)
			submatches, err := result.Submatches(ctx)
			require.NoError(t, err)

			// Verify AbsoluteOffset is reasonable (non-negative)
			require.GreaterOrEqual(t, absoluteOffset, 0)

			// Verify we have at least one submatch for each result
			require.NotEmpty(t, submatches)

			// Verify submatch structure
			for _, submatch := range submatches {
				submatchText, err := submatch.Text(ctx)
				require.NoError(t, err)
				start, err := submatch.Start(ctx)
				require.NoError(t, err)
				end, err := submatch.End(ctx)
				require.NoError(t, err)

				require.NotEmpty(t, submatchText)
				require.GreaterOrEqual(t, start, 0)
				require.Equal(t, len("-test"), end-start)
				require.Equal(t, "-test", submatchText)
			}

			matches = append(matches, fmt.Sprintf("%s:%d:%s", filePath, lineNumber, matchedText))
		}

		// Check that we have all expected matches
		require.Contains(t, matches, "file1.txt:2:This is a --test-- file.\n")
	})

	t.Run("files-only search", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file1.txt", "Hello, World!\nThis is a test file.\nWorld is great.").
			WithNewFile("file2.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("subdir/file3.txt", "Hello from subdirectory!\nWorld tour.")

		results, err := dir.Search(ctx, "World", sdkcore.DirectorySearchOpts{
			FilesOnly: true,
		})
		require.NoError(t, err)

		// Collect all matches to check they're all present (order doesn't matter)
		var matches []string
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			require.Zero(t, lineNumber)
			matchedText, err := result.MatchedLines(ctx)
			require.NoError(t, err)
			require.Empty(t, matchedText)
			matches = append(matches, filePath)
		}

		// Check that we have all expected matches
		require.ElementsMatch(t, matches, []string{"file1.txt", "subdir/file3.txt"})
	})

	t.Run("limiting results", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file1.txt", "Hello, World!\nThis is a test file.\nWorld is great.").
			WithNewFile("file2.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("file3.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("file4.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("file5.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("file6.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("file7.txt", "Hello, Dagger!\nThis is another test file.").
			WithNewFile("subdir/file3.txt", "Hello from subdirectory!\nWorld tour.")

		results, err := dir.Search(ctx, "another", sdkcore.DirectorySearchOpts{
			Limit: 3,
		})
		require.NoError(t, err)

		// Collect all matches to check they're all present (order doesn't matter)
		var matches []string
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			absoluteOffset, err := result.AbsoluteOffset(ctx)
			require.NoError(t, err)
			matchedText, err := result.MatchedLines(ctx)
			require.NoError(t, err)
			submatches, err := result.Submatches(ctx)
			require.NoError(t, err)

			// Verify AbsoluteOffset is reasonable (non-negative)
			require.GreaterOrEqual(t, absoluteOffset, 0)

			// Verify we have at least one submatch for each result
			require.NotEmpty(t, submatches)

			// Verify submatch structure
			for _, submatch := range submatches {
				submatchText, err := submatch.Text(ctx)
				require.NoError(t, err)
				start, err := submatch.Start(ctx)
				require.NoError(t, err)
				end, err := submatch.End(ctx)
				require.NoError(t, err)

				require.NotEmpty(t, submatchText)
				require.GreaterOrEqual(t, start, 0)
				require.Equal(t, len("another"), end-start)
				require.Equal(t, "another", submatchText)
			}

			matches = append(matches, fmt.Sprintf("%s:%d:%s", filePath, lineNumber, matchedText))
		}

		// Check that we have all expected matches
		// Check that we get exactly 3 matches from the possible files
		require.Len(t, matches, 3)

		// Define all possible matches since order is not stable
		possibleMatches := []string{
			"file2.txt:2:This is another test file.",
			"file3.txt:2:This is another test file.",
			"file4.txt:2:This is another test file.",
			"file5.txt:2:This is another test file.",
			"file6.txt:2:This is another test file.",
			"file7.txt:2:This is another test file.",
		}

		// Verify that all 3 matches are from the possible set and are distinct
		matchSet := make(map[string]bool)
		for _, match := range matches {
			require.Contains(t, possibleMatches, match, "unexpected match: %s", match)
			require.False(t, matchSet[match], "duplicate match: %s", match)
			matchSet[match] = true
		}
	})

	t.Run("regex search", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("main.go", "package main\n\nfunc main() {\n\tfmt.Println(\"hello\")\n}").
			WithNewFile("test.go", "package main\n\nfunc TestSomething() {\n\t// test code\n}").
			WithNewFile("lib/helper.go", "package lib\n\nfunc Helper() string {\n\treturn \"help\"\n}")

		// Search for function definitions
		results, err := dir.Search(ctx, `func \w+\(\)`)
		require.NoError(t, err)
		require.Len(t, results, 3)

		// Collect all matches to check they're all present
		var matches []string
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			absoluteOffset, err := result.AbsoluteOffset(ctx)
			require.NoError(t, err)
			matchedText, err := result.MatchedLines(ctx)
			require.NoError(t, err)
			submatches, err := result.Submatches(ctx)
			require.NoError(t, err)

			// Verify AbsoluteOffset is reasonable (non-negative)
			require.GreaterOrEqual(t, absoluteOffset, 0)

			// Verify we have at least one submatch for each result
			require.NotEmpty(t, submatches)

			// Verify submatch structure for regex - should match "func <name>()"
			for _, submatch := range submatches {
				submatchText, err := submatch.Text(ctx)
				require.NoError(t, err)
				start, err := submatch.Start(ctx)
				require.NoError(t, err)
				end, err := submatch.End(ctx)
				require.NoError(t, err)

				require.NotEmpty(t, submatchText)
				require.GreaterOrEqual(t, start, 0)
				require.Equal(t, len(submatchText), end-start)
				require.Regexp(t, `func \w+\(\)`, submatchText)
			}

			matches = append(matches, fmt.Sprintf("%s:%d:%s", filePath, lineNumber, matchedText))
		}

		// Check that we have all expected matches (order doesn't matter)
		// Note: matches may have trailing newlines, so we use partial matches
		require.Contains(t, matches, "main.go:3:func main() {\n")
		require.Contains(t, matches, "test.go:3:func TestSomething() {\n")
		require.Contains(t, matches, "lib/helper.go:3:func Helper() string {\n")
	})

	t.Run("multiline search", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("dir/code.go", `package main

import "fmt"

func main() {
	name := "Alice"
	age := 30
	fmt.Printf("Name: %s, Age: %d\n", name, age)
}

func another() {
	name := "Alice"
	age := 50
	fmt.Printf("Name: %s, Age: %d\n", name, age)
}`)

		// Search for variable assignments
		results, err := dir.Search(ctx, ":= \"Alice\"\n\tage", sdkcore.DirectorySearchOpts{Multiline: true})
		require.NoError(t, err)
		require.NotEmpty(t, results)

		// Check that we have the expected variable assignments
		var matches []string
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			matchedText, err := result.MatchedLines(ctx)
			require.NoError(t, err)
			matches = append(matches, fmt.Sprintf("%s:%d:%s", filePath, lineNumber, matchedText))
		}

		// Check for the specific assignments we expect (may have different formatting)
		require.Contains(t, matches, "dir/code.go:6:\tname := \"Alice\"\n\tage := 30\n")
		require.Contains(t, matches, "dir/code.go:12:\tname := \"Alice\"\n\tage := 50\n")
	})

	t.Run("multiline regexp search", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("dir/code.go", `package main

import "fmt"

func main() {
	name := "Alice"
	age := 30
	fmt.Printf("Name: %s, Age: %d\n", name, age)
}

func another() {
	name := "Alice"
	age := 50
	fmt.Printf("Name: %s, Age: %d\n", name, age)
}`)

		// Search for variable assignments
		results, err := dir.Search(ctx, `:= ".*"\n\s+age`, sdkcore.DirectorySearchOpts{
			Multiline: true,
		})
		require.NoError(t, err)
		require.NotEmpty(t, results)

		// Check that we have the expected variable assignments
		var matches []string
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			matchedText, err := result.MatchedLines(ctx)
			require.NoError(t, err)
			matches = append(matches, fmt.Sprintf("%s:%d:%s", filePath, lineNumber, matchedText))
		}

		// Check for the specific assignments we expect (may have different formatting)
		require.Contains(t, matches, "dir/code.go:6:\tname := \"Alice\"\n\tage := 30\n")
		require.Contains(t, matches, "dir/code.go:12:\tname := \"Alice\"\n\tage := 50\n")
	})

	t.Run("empty directory", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory()

		results, err := dir.Search(ctx, "anything")
		require.NoError(t, err)
		require.Empty(t, results)
	})

	t.Run("no matches", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file.txt", "Hello, World!")

		results, err := dir.Search(ctx, "nonexistent")
		require.NoError(t, err)
		require.Empty(t, results)
	})

	t.Run("search in subdirectory", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("root.txt", "Root content").
			WithNewFile("sub/file.txt", "Subdirectory content").
			WithNewFile("sub/deep/file.txt", "Deep subdirectory content")

		subdir := dir.Directory("sub")
		results, err := subdir.Search(ctx, "ubdirectory")
		require.NoError(t, err)
		require.Equal(t, len(results), 2)

		// Get all file paths
		var filePaths []string
		for _, result := range results {
			path, err := result.FilePath(ctx)
			require.NoError(t, err)
			filePaths = append(filePaths, path)
		}

		// Check that we have the expected files (order doesn't matter)
		require.Contains(t, filePaths, "file.txt")
		require.Contains(t, filePaths, "deep/file.txt")
	})

	t.Run("case sensitive search", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file.txt", "Hello\nhello\nHELLO")

		results, err := dir.Search(ctx, "Hello")
		require.NoError(t, err)
		require.Len(t, results, 1)
		lineNumber0, err := results[0].LineNumber(ctx)
		require.NoError(t, err)
		require.Equal(t, 1, lineNumber0)
	})

	t.Run("case insensitive search", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("file.txt", "Hello\nhello\nHELLO")

		results, err := dir.Search(ctx, "hello", sdkcore.DirectorySearchOpts{
			Insensitive: true,
		})
		require.NoError(t, err)
		require.Len(t, results, 3)

		// Collect all line numbers to verify we got all matches
		var lineNumbers []int
		for _, result := range results {
			lineNumber, err := result.LineNumber(ctx)
			require.NoError(t, err)
			lineNumbers = append(lineNumbers, lineNumber)
		}
		require.ElementsMatch(t, []int{1, 2, 3}, lineNumbers)
	})

	t.Run("multiple matches in one file", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("code.go", `package main

import "fmt"

func main() {
	fmt.Println("Hello")
	fmt.Println("World")
}`)

		results, err := dir.Search(ctx, "fmt")
		require.NoError(t, err)
		require.Len(t, results, 3)

		lineNumber0, err := results[0].LineNumber(ctx)
		require.NoError(t, err)
		lineNumber1, err := results[1].LineNumber(ctx)
		require.NoError(t, err)
		lineNumber2, err := results[2].LineNumber(ctx)
		require.NoError(t, err)
		require.Equal(t, 3, lineNumber0)
		require.Equal(t, 6, lineNumber1)
		require.Equal(t, 7, lineNumber2)
	})

	t.Run("binary files are skipped", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		// Ripgrep detects binary files by NUL bytes; random data need not
		// contain one. Keep matching text after a deterministic binary marker.
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("text.txt", "text content\n").
			WithNewFile("binary.bin", "\x00text content\n")

		results, err := dir.Search(ctx, "content")
		require.NoError(t, err)

		files := []string{}
		for _, result := range results {
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			files = append(files, filePath)
		}
		require.Equal(t, []string{"text.txt"}, files)
	})

	t.Run("skip hidden files", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("visible.txt", "content with target").
			WithNewFile(".hidden.txt", "content with target").
			WithNewFile("subdir/.hidden2.txt", "content with target")

		t.Run("default behavior includes hidden files", func(ctx context.Context, t *testctx.T) {
			results, err := dir.Search(ctx, "target")
			require.NoError(t, err)

			var filePaths []string
			for _, result := range results {
				path, err := result.FilePath(ctx)
				require.NoError(t, err)
				filePaths = append(filePaths, path)
			}
			// Default should include hidden files
			require.Contains(t, filePaths, "visible.txt")
			require.Contains(t, filePaths, ".hidden.txt")
			require.Contains(t, filePaths, "subdir/.hidden2.txt")
		})

		t.Run("skipHidden excludes hidden files", func(ctx context.Context, t *testctx.T) {
			results, err := dir.Search(ctx, "target", sdkcore.DirectorySearchOpts{
				SkipHidden: true,
			})
			require.NoError(t, err)

			var filePaths []string
			for _, result := range results {
				path, err := result.FilePath(ctx)
				require.NoError(t, err)
				filePaths = append(filePaths, path)
			}
			// Should only include visible files
			require.Contains(t, filePaths, "visible.txt")
			require.NotContains(t, filePaths, ".hidden.txt")
			require.NotContains(t, filePaths, "subdir/.hidden2.txt")
		})
	})

	t.Run("skip ignored files", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("tracked.txt", "content with target").
			WithNewFile("ignored.log", "content with target").
			WithNewFile("build/output.bin", "content with target").
			WithNewFile(".rgignore", "*.log\nbuild/")

		t.Run("default behavior includes ignored files", func(ctx context.Context, t *testctx.T) {
			results, err := dir.Search(ctx, "target")
			require.NoError(t, err)

			var filePaths []string
			for _, result := range results {
				path, err := result.FilePath(ctx)
				require.NoError(t, err)
				filePaths = append(filePaths, path)
			}
			// Default should include ignored files
			require.Contains(t, filePaths, "tracked.txt")
			require.Contains(t, filePaths, "ignored.log")
			require.Contains(t, filePaths, "build/output.bin")
		})

		t.Run("skipIgnored respects rgignore", func(ctx context.Context, t *testctx.T) {
			results, err := dir.Search(ctx, "target", sdkcore.DirectorySearchOpts{
				SkipIgnored: true,
			})
			require.NoError(t, err)

			var filePaths []string
			for _, result := range results {
				path, err := result.FilePath(ctx)
				require.NoError(t, err)
				filePaths = append(filePaths, path)
			}
			// Should only include tracked files
			require.Contains(t, filePaths, "tracked.txt")
			require.NotContains(t, filePaths, "ignored.log")
			require.NotContains(t, filePaths, "build/output.bin")
		})
	})

	t.Run("globs option", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("main.go", "package main\nfunc main() { fmt.Println(\"hello\") }").
			WithNewFile("test.go", "package main\nfunc TestSomething() { /* test code */ }").
			WithNewFile("README.md", "# Project\nThis is a documentation file").
			WithNewFile("config.yaml", "version: 1\nname: test-project").
			WithNewFile("lib/helper.go", "package lib\nfunc Helper() string { return \"help\" }")

		t.Run("single glob pattern", func(ctx context.Context, t *testctx.T) {
			// Search for "func" only in .go files
			results, err := dir.Search(ctx, "func", sdkcore.DirectorySearchOpts{
				Globs: []string{"*.go"},
			})
			require.NoError(t, err)
			require.Len(t, results, 3) // main(), TestSomething(), Helper()

			// Verify all results are from .go files
			for _, result := range results {
				filePath, err := result.FilePath(ctx)
				require.NoError(t, err)
				require.True(t, strings.HasSuffix(filePath, ".go"), "Expected .go file, got: %s", filePath)
			}
		})

		t.Run("multiple glob patterns", func(ctx context.Context, t *testctx.T) {
			// Search for "test" in both .go and .md files
			results, err := dir.Search(ctx, "test", sdkcore.DirectorySearchOpts{
				Globs: []string{"*.go", "*.md"},
			})
			require.NoError(t, err)
			// Only test.go contains "test" (TestSomething function) - README.md doesn't contain "test"
			require.Len(t, results, 1)

			result := results[0]
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			require.Equal(t, "test.go", filePath)
		})

		t.Run("glob with subdirectories", func(ctx context.Context, t *testctx.T) {
			// Search for "func" in all .go files, including subdirectories
			results, err := dir.Search(ctx, "func", sdkcore.DirectorySearchOpts{
				Globs: []string{"**/*.go"},
			})
			require.NoError(t, err)
			require.Len(t, results, 3) // main(), TestSomething(), Helper()

			var filePaths []string
			for _, result := range results {
				filePath, err := result.FilePath(ctx)
				require.NoError(t, err)
				filePaths = append(filePaths, filePath)
			}
			require.Contains(t, filePaths, "main.go")
			require.Contains(t, filePaths, "test.go")
			require.Contains(t, filePaths, "lib/helper.go")
		})

		t.Run("glob with no matches", func(ctx context.Context, t *testctx.T) {
			// Search for a pattern that exists in files but not in the files matching the glob
			results, err := dir.Search(ctx, "main", sdkcore.DirectorySearchOpts{
				Globs: []string{"*.md", "*.yaml"}, // Only search in markdown and yaml files where "main" doesn't appear
			})
			require.NoError(t, err)
			require.Empty(t, results)
		})
	})

	t.Run("paths option", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("src/main.go", "package main\nfunc main() { fmt.Println(\"hello world\") }").
			WithNewFile("src/helper.go", "package main\nfunc Helper() { return \"world peace\" }").
			WithNewFile("tests/main_test.go", "package main\nfunc TestMain() { /* world testing */ }").
			WithNewFile("docs/README.md", "# Project\nHello world documentation").
			WithNewFile("config/app.yaml", "name: world-app\nversion: 1.0").
			WithNewFile("etc/passwd", "root:world passwd").
			WithSymlink("/etc", "symlink")

		t.Run("single path", func(ctx context.Context, t *testctx.T) {
			// Search for "world" only in src directory
			results, err := dir.Search(ctx, "world", sdkcore.DirectorySearchOpts{
				Paths: []string{"src"},
			})
			require.NoError(t, err)
			require.Len(t, results, 2) // "hello world" and "world peace"

			// Verify all results are from src directory
			for _, result := range results {
				filePath, err := result.FilePath(ctx)
				require.NoError(t, err)
				require.True(t, strings.HasPrefix(filePath, "src/"), "Expected src/ path, got: %s", filePath)
			}
		})

		t.Run("multiple paths", func(ctx context.Context, t *testctx.T) {
			// Search for "world" in both src and docs directories
			results, err := dir.Search(ctx, "world", sdkcore.DirectorySearchOpts{
				Paths: []string{"src", "docs"},
			})
			require.NoError(t, err)
			require.Len(t, results, 3) // src/main.go, src/helper.go, docs/README.md

			var filePaths []string
			for _, result := range results {
				filePath, err := result.FilePath(ctx)
				require.NoError(t, err)
				filePaths = append(filePaths, filePath)
				// Should be in src or docs directory
				require.True(t,
					strings.HasPrefix(filePath, "src/") || strings.HasPrefix(filePath, "docs/"),
					"Expected src/ or docs/ path, got: %s", filePath)
			}
			// config/ and tests/ should be excluded
			for _, path := range filePaths {
				require.False(t, strings.HasPrefix(path, "config/"))
				require.False(t, strings.HasPrefix(path, "tests/"))
			}
		})

		t.Run("specific file path", func(ctx context.Context, t *testctx.T) {
			// Search for "main" in a specific file
			results, err := dir.Search(ctx, "main", sdkcore.DirectorySearchOpts{
				Paths: []string{"src/main.go"},
			})
			require.NoError(t, err)
			require.Len(t, results, 2) // "package main" and "func main"

			// Verify all results are from the specific file
			for _, result := range results {
				filePath, err := result.FilePath(ctx)
				require.NoError(t, err)
				require.Equal(t, "src/main.go", filePath)
			}
		})

		t.Run("path with no matches", func(ctx context.Context, t *testctx.T) {
			// Search for non-existent pattern in existing directory
			results, err := dir.Search(ctx, "nonexistent-pattern", sdkcore.DirectorySearchOpts{
				Paths: []string{"src"},
			})
			require.NoError(t, err)
			require.Empty(t, results)
		})

		t.Run("normalizes absolute paths", func(ctx context.Context, t *testctx.T) {
			// Test that absolute paths are treated as relative to the directory
			results, err := dir.Search(ctx, "world", sdkcore.DirectorySearchOpts{
				Paths: []string{"/src"},
			})
			require.NoError(t, err)
			require.Len(t, results, 2) // Should find results in src directory

			// Verify all results are from src directory
			for _, result := range results {
				filePath, err := result.FilePath(ctx)
				require.NoError(t, err)
				require.True(t, strings.HasPrefix(filePath, "src/"), "Expected src/ path, got: %s", filePath)
			}
		})

		t.Run("keeps symlinks within the directory", func(ctx context.Context, t *testctx.T) {
			// Test that symlinks are resolved within the directory
			results, err := dir.Search(ctx, "root", sdkcore.DirectorySearchOpts{
				Paths: []string{"symlink"},
			})
			require.NoError(t, err)
			require.Len(t, results, 1)
			matched, err := results[0].MatchedLines(ctx)
			require.NoError(t, err)
			require.Equal(t, "root:world passwd", matched)

			// Test that we don't allow naively evaluating symlinks by following them
			// first (e.g. symlink/passwd => /etc/passwd)
			results, err = dir.Search(ctx, "root", sdkcore.DirectorySearchOpts{
				Paths: []string{"symlink/passwd"},
			})
			require.NoError(t, err)
			require.Len(t, results, 1)
			matched, err = results[0].MatchedLines(ctx)
			require.NoError(t, err)
			require.Equal(t, "root:world passwd", matched)
		})

		t.Run("resolves symlinks within a scoped dir", func(ctx context.Context, t *testctx.T) {
			dir := sdkcore.NewQuery(c).Directory().
				WithNewFile("symlink", "im innocent").
				WithNewFile("subdir/etc/passwd", "root:world passwd").
				WithSymlink("/etc/passwd", "subdir/symlink")

			results, err := dir.Directory("subdir").Search(ctx, "root", sdkcore.DirectorySearchOpts{
				Paths: []string{"symlink"},
			})
			require.NoError(t, err)
			require.Len(t, results, 1)
			matched, err := results[0].MatchedLines(ctx)
			require.NoError(t, err)
			// make sure we correctly resolve the path WITHIN the directory - in the
			// failure case this will have content from `/etc/passwd` on the host!
			require.Equal(t, "root:world passwd", matched)
		})

		t.Run("rejects paths that escape directory", func(ctx context.Context, t *testctx.T) {
			// Test that paths trying to escape via .. are rejected
			_, err := dir.Search(ctx, "world", sdkcore.DirectorySearchOpts{
				Paths: []string{"../../etc/passwd"},
			})
			require.Error(t, err)
			require.Contains(t, err.Error(), "path cannot escape directory")
		})

		t.Run("rejects nested directory escape attempts", func(ctx context.Context, t *testctx.T) {
			// Test that paths containing ".." anywhere that would escape are rejected
			_, err := dir.Search(ctx, "world", sdkcore.DirectorySearchOpts{
				Paths: []string{"some/../../etc/passwd"},
			})
			require.Error(t, err)
			require.Contains(t, err.Error(), "path cannot escape directory")
		})

		t.Run("allows valid relative paths with double dots", func(ctx context.Context, t *testctx.T) {
			// Test that valid relative paths that don't escape still work
			results, err := dir.Search(ctx, "package main", sdkcore.DirectorySearchOpts{
				Paths: []string{"/src/../"},
			})
			require.NoError(t, err)
			require.Len(t, results, 3)
		})
	})

	t.Run("combined globs and paths", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)

		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("src/main.go", "package main\nfunc main() { fmt.Println(\"hello\") }").
			WithNewFile("src/helper.js", "function helper() { console.log('hello'); }").
			WithNewFile("tests/main_test.go", "package main\nfunc TestMain() { /* hello testing */ }").
			WithNewFile("tests/helper_test.js", "function testHelper() { console.log('hello'); }")

		t.Run("globs and paths together", func(ctx context.Context, t *testctx.T) {
			// Search for "hello" in .go files within src directory only
			results, err := dir.Search(ctx, "hello", sdkcore.DirectorySearchOpts{
				Globs: []string{"*.go"},
				Paths: []string{"src"},
			})
			require.NoError(t, err)
			require.Len(t, results, 1) // Only src/main.go should match

			result := results[0]
			filePath, err := result.FilePath(ctx)
			require.NoError(t, err)
			require.Equal(t, "src/main.go", filePath)
		})

		t.Run("globs and paths with multiple patterns", func(ctx context.Context, t *testctx.T) {
			// Search for "hello" in both .go and .js files within tests directory
			results, err := dir.Search(ctx, "hello", sdkcore.DirectorySearchOpts{
				Globs: []string{"*.go", "*.js"},
				Paths: []string{"tests"},
			})
			require.NoError(t, err)
			require.Len(t, results, 2) // tests/main_test.go and tests/helper_test.js

			var filePaths []string
			for _, result := range results {
				filePath, err := result.FilePath(ctx)
				require.NoError(t, err)
				filePaths = append(filePaths, filePath)
				require.True(t, strings.HasPrefix(filePath, "tests/"))
			}
			require.Contains(t, filePaths, "tests/main_test.go")
			require.Contains(t, filePaths, "tests/helper_test.js")
		})
	})
}

func (DirectorySuite) TestSymlink(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)

	t.Run("symlink in same directory", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory().
			WithNewFile("some-file", "some-content").
			WithSymlink("some-file", "symlink-to-some-file")

		ctr := sdkcore.NewQuery(c).Container().From(alpineImage).WithDirectory("/test-dir", dir)

		// test the symlink is an actual symlink
		_, err := ctr.WithExec([]string{"test", "-L", "/test-dir/symlink-to-some-file"}).Stdout(ctx)
		require.NoError(t, err)

		symlinkContents, err := dir.File("symlink-to-some-file").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "some-content", symlinkContents)

		symlinkContents, err = dir.WithNewFile("some-file", "overwritten-contents").File("symlink-to-some-file").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "overwritten-contents", symlinkContents)
	})

	t.Run("symlink to parent directory", func(ctx context.Context, t *testctx.T) {
		dir := sdkcore.NewQuery(c).Directory().
			WithSymlink("../root", "its-root")
		f := sdkcore.NewQuery(c).Container().From(alpineImage).
			WithDirectory("/test-dir", dir).
			WithNewFile("/test-dir/its-root/f", "data").
			File("/root/f")
		s, err := f.Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "data", s)
	})

	t.Run("symlink with abs path", func(ctx context.Context, t *testctx.T) {
		s, err := sdkcore.NewQuery(c).Directory().
			WithNewFile("/some-file", "some-content").
			WithSymlink("/some-file", "/symlink-to-some-file").
			File("symlink-to-some-file").
			Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "some-content", s)
	})

	t.Run("symlink with abs path mounted as a subdir", func(ctx context.Context, t *testctx.T) {
		d := sdkcore.NewQuery(c).Directory().
			WithNewFile("/some-file", "some-content").
			WithSymlink("/some-file", "/symlink-to-some-file")

		d2 := sdkcore.NewQuery(c).Directory().
			WithNewFile("/some-file", "other-content").
			WithDirectory("/sub-dir", d)

		s, err := d2.
			File("sub-dir/symlink-to-some-file").
			Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "other-content", s)
	})

	t.Run("symlink creates parent dirs", func(ctx context.Context, t *testctx.T) {
		s, err := sdkcore.NewQuery(c).Directory().
			WithNewFile("/some-file", "some-content").
			WithSymlink("../../some-file", "/sub/subdir/symlink").
			File("/sub/subdir/symlink").
			Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "some-content", s)
	})

	t.Run("symlink correctly passes dir path", func(ctx context.Context, t *testctx.T) {
		d := sdkcore.NewQuery(c).Directory().WithNewFile("some-file", "data")

		d2 := sdkcore.NewQuery(c).Directory().
			WithNewFile("some-other-file", "other-data").
			WithNewDirectory("dir1").
			Directory("/dir1").
			WithDirectory("/", d).
			WithSymlink("anything", "link")

		// this should no longer be available, since dir.Dir should now be "/dir1"
		_, err := d2.File("some-other-file").Contents(ctx)
		require.Error(t, err)

		s, err := d2.File("some-file").Contents(ctx)
		require.NoError(t, err)
		require.Equal(t, "data", s)
	})

	t.Run("symlink follows symlinks in dir path but not basename", func(ctx context.Context, t *testctx.T) {
		s, err := sdkcore.NewQuery(c).Directory().
			WithNewDirectory("dir1").
			WithSymlink("dir1", "dir2").
			WithSymlink("file", "dir2/symlink").
			WithoutFile("dir2").
			WithNewFile("dir1/file", "data").
			File("/dir1/symlink").
			Contents(ctx)

		require.NoError(t, err)
		require.Equal(t, "data", s)
	})

	t.Run("symlink errors rather when symlink already exists", func(ctx context.Context, t *testctx.T) {
		_, err := sdkcore.NewQuery(c).Directory().
			WithSymlink("target", "symlink").
			WithSymlink("newtarget", "symlink").
			Sync(ctx)

		require.Error(t, err)
		require.Regexp(t, "symlink newtarget /.*/symlink: file exists", err.Error())
	})
}

func (DirectorySuite) TestExists(ctx context.Context, t *testctx.T) {
	for _, tc := range []struct {
		Description         string
		Path                string
		Type                sdkcore.ExistsType
		Expected            bool
		DoNotFollowSymlinks bool
		ErrorContains       string
	}{
		{
			Description: "test exists is false when referencing a non-existent file",
			Path:        "We believe in nothing Lebowski",
			Type:        "",
			Expected:    false,
		},
		{
			Description: "test existence works on a directory without specifying an expected type",
			Path:        "quotes",
			Type:        "",
			Expected:    true,
		},
		{
			Description: "test is a directory",
			Path:        "quotes",
			Type:        sdkcore.ExistsTypeDirectoryType,
			Expected:    true,
		},
		{
			Description: "test is a directory fails when referencing a file that exists",
			Path:        "quotes/descartes",
			Type:        sdkcore.ExistsTypeDirectoryType,
			Expected:    false,
		},
		{
			Description: "test is a file works",
			Path:        "quotes/descartes",
			Type:        sdkcore.ExistsTypeRegularType,
			Expected:    true,
		},
		{
			Description: "test is a file fails when referencing a directory that exists",
			Path:        "quotes",
			Type:        sdkcore.ExistsTypeRegularType,
			Expected:    false,
		},
		{
			Description: "test is a symlink works",
			Path:        "i-am",
			Type:        sdkcore.ExistsTypeSymlinkType,
			Expected:    true,
		},
		{
			Description: "test symlink fails",
			Path:        "quotes/descartes",
			Type:        sdkcore.ExistsTypeSymlinkType,
			Expected:    false,
		},

		// this is to follow the same functionality as the `test` shell command,
		// from `man test`, it states that "all FILE-related tests dereference symbolic links (except -h and -L, which don't apply here)",
		// so we should do the same.
		{
			Description: "test is a file works on a symlink",
			Path:        "i-am",
			Type:        sdkcore.ExistsTypeRegularType,
			Expected:    true,
		},
		{
			Description:         "test DoNotFollowSymlinks is true when target does not exist",
			Path:                "nothing",
			DoNotFollowSymlinks: true,
			Expected:            true,
		},
		{
			Description:         "test DoNotFollowSymlinks prevents regular file type from being true when referencing a symlink",
			Path:                "i-am",
			Type:                sdkcore.ExistsTypeRegularType,
			DoNotFollowSymlinks: true,
			Expected:            false,
		},
	} {
		t.Run(tc.Description, func(ctx context.Context, t *testctx.T) {
			c := connect(ctx, t)
			quotesDir := sdkcore.NewQuery(c).Directory().WithNewFile("quotes/descartes", "Cogito, ergo sum").WithSymlink("quotes/descartes", "i-am").WithSymlink("quotes/does-not-exist", "nothing")
			exists, err := quotesDir.Exists(ctx, tc.Path, sdkcore.DirectoryExistsOpts{
				ExpectedType:        tc.Type,
				DoNotFollowSymlinks: tc.DoNotFollowSymlinks,
			})
			if tc.ErrorContains == "" {
				require.NoError(t, err)
			} else {
				require.ErrorContains(t, err, tc.ErrorContains)
			}
			require.Equal(t, tc.Expected, exists)
		})
	}
}

func (DirectorySuite) TestStat(ctx context.Context, t *testctx.T) {
	t.Run("file-exists", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)
		stat, err := sdkcore.NewQuery(c).Directory().
			WithNewFile("f", "data", sdkcore.DirectoryWithNewFileOpts{Permissions: 0o444}).
			Stat(ctx, "f")
		require.NoError(t, err)
		require.NotNil(t, stat)

		name, err := stat.Name(ctx)
		require.NoError(t, err)
		require.Equal(t, "f", name)

		size, err := stat.Size(ctx)
		require.NoError(t, err)
		require.Equal(t, 4, size)

		fileType, err := stat.FileType(ctx)
		require.NoError(t, err)
		require.Equal(t, sdkcore.FileTypeRegularType, fileType)

		permissions, err := stat.Permissions(ctx)
		require.NoError(t, err)
		require.Equal(t, 0o444, permissions)
	})
	t.Run("file-dir-exists", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)
		stat, err := sdkcore.NewQuery(c).Directory().
			WithNewDirectory("d", sdkcore.DirectoryWithNewDirectoryOpts{Permissions: 0o750}).
			Stat(ctx, "d")
		require.NoError(t, err)
		require.NotNil(t, stat)

		name, err := stat.Name(ctx)
		require.NoError(t, err)
		require.Equal(t, "d", name)

		size, err := stat.Size(ctx)
		require.NoError(t, err)
		require.Equal(t, 4096, size)

		fileType, err := stat.FileType(ctx)
		require.NoError(t, err)
		require.Equal(t, sdkcore.FileTypeDirectoryType, fileType)

		permissions, err := stat.Permissions(ctx)
		require.NoError(t, err)
		require.Equal(t, 0o750, permissions)
	})
	t.Run("empty-path-fails", func(ctx context.Context, t *testctx.T) {
		c := connect(ctx, t)
		_, err := sdkcore.NewQuery(c).Directory().Stat(ctx, "")
		require.ErrorContains(t, err, ": no such file or directory")
	})
}

func (DirectorySuite) TestExistsUsingAbsoluteSymlink(ctx context.Context, t *testctx.T) {
	c := connect(ctx, t)
	ok, err := sdkcore.NewQuery(c).Directory().
		WithNewFile("/some-file", "some-content").
		WithSymlink("/some-file", "/symlink-to-some-file").
		Exists(ctx, "symlink-to-some-file", sdkcore.DirectoryExistsOpts{
			ExpectedType: sdkcore.ExistsTypeRegularType,
		})
	require.NoError(t, err)
	require.True(t, ok)
}

func (DirectorySuite) TestDirCaching(ctx context.Context, t *testctx.T) {
	// NOTE: This test requires that WithNewFile sets the creation date to the current time,
	// if this side-effect were to ever change (i.e. adopting SOURCE_DATE_EPOCH functionality),
	// then this test will break.

	randID := rand.Text()

	c := connect(ctx, t)
	d1, err := sdkcore.NewQuery(c).Directory().
		WithoutFile("non-existent").
		WithNewFile("file", randID).
		Sync(ctx)
	require.NoError(t, err)

	d2, err := sdkcore.NewQuery(c).Directory().
		WithoutFile("also-non-existent").
		WithNewFile("file", randID).
		Sync(ctx)
	require.NoError(t, err)

	out, err := sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithMountedDirectory("/d1", d1).
		WithMountedDirectory("/d2", d2).
		WithExec([]string{"sh", "-c", "diff <(stat /d1/file | grep Modify) <(stat /d2/file | grep Modify)"}). // they should be the exact same file (i.e. same creation time)
		Stdout(ctx)
	require.NoError(t, err)
	require.Equal(t, out, "")

	d3 := sdkcore.NewQuery(c).Directory().
		WithNewFile("not", "used").
		WithNewFile("file", "data")

	out, err = sdkcore.NewQuery(c).Container().
		From(alpineImage).
		WithMountedDirectory("/d1", d1).
		WithMountedDirectory("/d3", d3).
		WithExec([]string{"sh", "-c", "! diff <(stat /d1/file | grep Modify) <(stat /d3/file | grep Modify)"}). // should be different since "not", "used" file still changed the disk
		Stdout(ctx)
	require.NoError(t, err)
	require.NotEqual(t, out, "")
}
