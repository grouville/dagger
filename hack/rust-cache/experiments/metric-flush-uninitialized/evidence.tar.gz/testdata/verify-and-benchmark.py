from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1',DAGGER_TEST_PARALLEL_CLIENT_ADMISSION='on')
subprocess.run([str(Path(go).with_name('gofmt')),'-w',*[str(p/name) for name in ['session.go','session_test.go','metric_flush.go','metric_flush_test.go']]],check=True)
rows=[]
def run(label,args,enabled):
 command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/'component-overlay.json'),*args,'./engine/server']
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as output:r=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=dict(env,DAGGER_DIAG_METRIC_FLUSH_PRUNING=str(int(enabled))),stdout=output,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,enabled=enabled,exit_code=r.returncode,seconds=time.monotonic()-tick);rows.append(row);(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True)
 assert r.returncode==0,(p/(label+'.log')).read_text()[-5000:]
 return (p/(label+'.log')).read_text()
for enabled in [False,True]:run('server-race-'+str(enabled).lower(),['-count=1','-race'],enabled)
bench=[]
for pair in range(4):
 for arm in (['after','before'] if pair%2==0 else ['before','after']):
  text=run(f'benchmark-{pair}-{arm}',['-run=^$','-bench=^BenchmarkClientMetricFlushDispatch$','-benchtime=500ms','-cpu=8','-count=1','-benchmem'],arm=='after')
  matches=re.findall(r'BenchmarkClientMetricFlushDispatch/(ready-\d+-of-800)-8\s+\d+\s+([\d.]+) ns/op.*?([\d.]+) B/op\s+([\d.]+) allocs/op',text);assert len(matches)==3,text
  bench.extend(dict(pair=pair,arm=arm,case=case,ns=float(ns),bytes=float(size),allocs=float(allocs)) for case,ns,size,allocs in matches);(p/'component-results.json').write_text(json.dumps(bench,indent=2)+'\n')
summary={case:{arm:{field:statistics.median(r[field] for r in bench if r['arm']==arm and r['case']==case) for field in ['ns','bytes','allocs']} for arm in ['before','after']} for case in sorted({r['case'] for r in bench})}
(p/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
