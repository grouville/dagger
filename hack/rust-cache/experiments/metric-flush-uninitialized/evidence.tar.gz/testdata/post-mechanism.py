from pathlib import Path
import json,subprocess,time,urllib.request
p=Path(__file__).parent;debug='http://127.0.0.1:16104/debug/'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=20) as response:return json.load(response)
assert not get('metric-flush-pruning')['enabled']
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
try:
 assert get('metric-flush-pruning?enabled=true',b'')['enabled']
 command=['python3',str(p.parent/'trivial-scalar-projection/verify_retained_first.py'),'metric-flush-uninitialized-after-mechanism']
 tick=time.monotonic()
 with (p/'retained-after-mechanism.log').open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 (p/'retained-after-mechanism.json').write_text(json.dumps(dict(command=command,exit_code=r.returncode,seconds=time.monotonic()-tick,pruning=get('metric-flush-pruning')),indent=2)+'\n')
 assert r.returncode==0
finally:
 get('metric-flush-pruning?enabled=false&record=false',b'')
 routes=['prepared-schema','callback-caller-reuse','lazy-type-maps','interface-field-snapshots','parallel-client-admission','metric-flush-pruning','span-row-sharing']
 state=dict(modes={route:get(route) for route in routes},wcprof=get('wcprof/enabled')['global_enabled'],locks=get('lock-profiler'),selected_go_module='/tmp/dagger-go-module-test-name-index',new_pr_opened=False,new_upstream_proposal=False)
 (p/'selected-state.json').write_text(json.dumps(state,indent=2)+'\n')
 assert not state['wcprof'] and not any(row['enabled'] for row in state['modes'].values())
print('PASS: all six native Rust histories reusable with pruning on; all unselected modes restored off.',flush=True)
