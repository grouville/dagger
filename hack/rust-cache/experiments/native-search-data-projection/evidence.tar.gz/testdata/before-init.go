package dagql

func init() {
	scalarListProjection.Store(true)
	directTrivialScalarFields.Store(true)
	nativeSearchProjection.Store(false)
}
