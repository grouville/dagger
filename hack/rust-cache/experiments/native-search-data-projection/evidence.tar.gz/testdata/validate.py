from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
cwd = '/tmp/dagger-filesync-snapshot-seeds'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
common = [go, 'test', '-p', '2', '-buildvcs=false', '-modfile',
          '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod']
steps = [
    ('focused', 'after-test-overlay.json', ['-count=1', '-v', '-run', '^TestSearchMetadataProjectionPreservesIDs$', './core/schema'], 0),
    ('regression', 'regression-test-overlay.json', ['-count=1', '-v', '-run', '^TestSearchMetadataProjectionPreservesIDs$', './core/schema'], 1),
    ('schema-race', 'after-test-overlay.json', ['-race', '-count=1', '-v', '-run', '^Test(SearchMetadataProjectionPreservesIDs|MergeSearchResults|SearchPathInScopes|SearchSourcePaths|MergeGlobMatches)$', './core/schema'], 0),
    ('dagql-race', 'full-dagql-test-overlay.json', ['-race', '-count=1', './dagql'], 0),
]
for arm in ['before', 'after']:
    steps.append((arm+'-component-build', arm+'-test-overlay.json', ['-c', '-o', str(p/(arm+'.test')), './core/schema'], 0))
rows = []
for label, overlay, args, expected in steps:
    command = [*common, '-overlay', str(p/overlay), *args]
    started = time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, seconds=time.monotonic()-started,
               exit_code=result.returncode, expected_exit_code=expected)
    rows.append(row)
    (p/'validation.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == expected, (p/(label+'.log')).read_text()[-5000:]
    if label == 'regression':
        log = (p/(label+'.log')).read_text()
        assert 'reading metadata must retain the list without attaching each item' in log
        assert '--- FAIL: TestSearchMetadataProjectionPreservesIDs' in log
    if label.endswith('-component-build'):
        arm = label.removesuffix('-component-build')
        row['sha256'] = hashlib.sha256((p/(arm+'.test')).read_bytes()).hexdigest()
        smoke = [str(p/(arm+'.test')), '-test.run=^$', '-test.bench=^BenchmarkSearchMetadataProjection$', '-test.benchtime=1x']
        with (p/(arm+'-component-smoke.log')).open('w') as output:
            check = subprocess.run(smoke, env=env, stdout=output, stderr=subprocess.STDOUT)
        row['smoke_command'] = smoke
        row['smoke_exit_code'] = check.returncode
        (p/'validation.json').write_text(json.dumps(rows, indent=2)+'\n')
        assert check.returncode == 0, (p/(arm+'-component-smoke.log')).read_text()[-5000:]
print('PASS: native regression, focused schema races, full DagQL races and both component smokes', flush=True)
