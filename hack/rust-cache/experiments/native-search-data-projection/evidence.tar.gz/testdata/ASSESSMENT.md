# Native search-result data projection: complete

The completed screen establishes no reliable complete-command gain: selected control 35.91 seconds median versus 35.52 seconds candidate, faster in only two of four pairs. The candidate stays disabled. See STUDY.md for all measured results and tradeoffs.

The controlled native regression, expected failing unannotated case, scoped search/overlay races, full DagQL race suite, 48 component processes, ten complete listing commands and all six retained native histories pass their intended checks. The initial typed-array fixture failure and the rejected zero-whole-command-publications assumption are retained. Search publication count falls 7,507 to 4,398; later loads convert prior cache hits to executions, limiting the optimization. No new upstream proposal or Rust timing claim is made.

FOLLOW_UP.md identifies the actual selected SDK source and the materialized-list query path to verify next. The isolated source overlay is only prepared, not validated or pushed as a proposal.
