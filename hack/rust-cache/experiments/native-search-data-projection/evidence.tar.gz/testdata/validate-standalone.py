from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
summary = json.loads((p/'full-command-paired/summary.json').read_text())
assert summary['all_commands_succeeded'] and summary['same_rows']
assert summary['faster_successful_pairs'] == 4
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
work = '/tmp/dagger-native-data-list-projection'
rows = []
steps = [
    ('standalone-focused', 'standalone-overlay.json', False, 0),
    ('standalone-regression', 'standalone-regression-overlay.json', False, 1),
    ('standalone-schema-race', 'standalone-overlay.json', True, 0),
]
for label, overlay, race, expected in steps:
    command = [go, 'test', '-p', '2', '-buildvcs=false', '-overlay', str(p/overlay), '-count=1', '-v']
    if race:
        command += ['-race']
        run = '^Test(SearchMetadataProjectionPreservesIDs|MergeSearchResults|SearchPathInScopes|SearchSourcePaths|MergeGlobMatches)$'
    else:
        run = '^TestSearchMetadataProjectionPreservesIDs$'
    command += ['-run', run, './core/schema']
    started = time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result = subprocess.run(command, cwd=work, env=env, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, seconds=time.monotonic()-started,
                     exit_code=result.returncode, expected_exit_code=expected))
    (p/'standalone-validation.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == expected, (p/(label+'.log')).read_text()[-5000:]
    if expected:
        assert 'reading metadata must retain the list without attaching each item' in (p/(label+'.log')).read_text()
print('PASS: candidate and failing regression reproduced atop the isolated data-projection branch', flush=True)
