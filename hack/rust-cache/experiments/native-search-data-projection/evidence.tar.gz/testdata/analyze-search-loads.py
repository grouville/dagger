from collections import Counter
from pathlib import Path
import json

p = Path(__file__).parent
ops = {}
links = []
with (p/'preflight/wcprof-complete.ndjson').open() as stream:
    header = json.loads(next(stream))
    names = header['strings']
    for line in stream:
        event = json.loads(line)
        if event.get('e') == 'op':
            ops[event['id']] = event
        elif event.get('e') == 'link' and event.get('lk') == 'nested_client':
            links.append(event)
clients = {event['i']: event['p'] for event in links}
contexts = Counter()
outcomes = Counter()
for event in ops.values():
    if event['k'] != 'call' or names[event['c']] != 'SearchResult.search':
        continue
    parent = ops[event['p']]
    assert names[parent['c']] == 'session.query'
    outcomes[event['o']] += 1
    ancestor = clients.get(event.get('cl'), 0)
    context = None
    while ancestor:
        caller = ops[ancestor]
        cls = names[caller['c']]
        if cls.startswith('go:') or cls.startswith('Artifact.'):
            context = cls
            break
        ancestor = caller.get('p', 0)
    contexts[context] += 1
assert contexts == {'go:GoPackage.tests': 4398}
assert outcomes == {'executed': 4398}
result = dict(caller_contexts=dict(contexts), outcomes=dict(outcomes),
              direct_parent='session.query', links_used='nested_client',
              limitation='Caller association only; no invented wait edges or claim about the exact GraphQL request/type shape.')
(p/'search-load-caller-contexts.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
