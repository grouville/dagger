from collections import Counter
from pathlib import Path
import json

p = Path(__file__).parent


def summarize(path):
    counts = Counter()
    parents = {}
    classes = {}
    publications = []
    interesting = []
    with path.open() as stream:
        header = json.loads(next(stream))
        names = header['strings']
        for line in stream:
            event = json.loads(line)
            if event.get('e') != 'op':
                continue
            cls = names[event['c']]
            kind = event['k']
            counts[(kind, cls)] += 1
            parents[event['id']] = event.get('p', 0)
            classes[event['id']] = (kind, cls)
            if cls == 'dagql.publishResult':
                publications.append(event.get('p', 0))
            if cls in ['session.serveQuery', 'Artifacts.items', 'go:Go.packages', 'go:GoPackage.tests']:
                interesting.append(dict(event, cls=cls))
    by_field = Counter()
    for parent in publications:
        while parent and parent in classes:
            kind, cls = classes[parent]
            if kind in ['call', 'call_exec']:
                by_field[cls] += 1
                break
            parent = parents.get(parent, 0)
    main = max((e for e in interesting if e['cls'] == 'session.serveQuery'), key=lambda e: e['d']-e['s'])
    fields = ['Workspace.glob', 'Workspace.findRoots', 'String.glob', 'gomod:GomodGoMod.ownFiles',
              'SearchResult.search', 'SearchResult.filePath', 'SearchResult.matchedLines',
              'Artifact.items', 'ArtifactDimensionKey.dimensionKeys',
              'ArtifactDimensionKey.dimension', 'ArtifactDimensionKey.key']
    return dict(header={k: v for k, v in header.items() if k != 'strings'}, main_query=main,
                publications=len(publications), publications_by_field=dict(by_field),
                fields={f: {kind: counts[(kind, f)] for kind in ['call', 'call_exec']} for f in fields},
                longest_intervals={cls: sorted([
                    dict(id=e['id'], seconds=(e['d']-e['s'])/1e9)
                    for e in interesting if e['cls'] == cls
                ], key=lambda e: e['seconds'], reverse=True)[:4]
                    for cls in ['Artifacts.items', 'go:Go.packages', 'go:GoPackage.tests']})


baseline = summarize(Path('/tmp/rust-cache-sipsma-review/upstream-leaf-array-response/capture/wcprof-complete.ndjson'))
candidate = summarize(p / 'preflight/wcprof-complete.ndjson')
result = dict(previous_selected_profile=baseline, native_search_profile=candidate)
(p / 'profile-derived.json').write_text(json.dumps(result, indent=2) + '\n')
for label, data in result.items():
    print(label, 'publications', data['publications'], 'fields', json.dumps(data['fields']))
assert candidate['fields']['ArtifactDimensionKey.dimensionKeys']['call'] == 0
assert candidate['fields']['Artifact.items']['call'] == 4398
for field in ['ArtifactDimensionKey.dimension', 'ArtifactDimensionKey.key']:
    assert candidate['fields'][field]['call'] == 17592
assert not candidate['header']['dropped_events']
assert not candidate['header'].get('open_ops')
assert candidate['fields']['SearchResult.search']['call'] == 4398
assert candidate['publications_by_field'].get('SearchResult.search', 0) == 4398
for field in ['SearchResult.filePath', 'SearchResult.matchedLines']:
    assert candidate['fields'][field]['call'] == baseline['fields'][field]['call'], (field, candidate['fields'][field], baseline['fields'][field])
assert baseline['publications_by_field']['SearchResult.search'] == 7507
print('PASS: real listing loses 3,109 search-item publications and 7,487 indexed calls; all search/key scalar getters and rows remain. Separate GoPackage.tests object loads still materialize 4,398 entries.')
