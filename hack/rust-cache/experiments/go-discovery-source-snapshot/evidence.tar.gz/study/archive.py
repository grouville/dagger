from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
p=Path(__file__).parent
root=p/'evidence-root'
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-discovery-source-snapshot')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,x):path.write_text(json.dumps(x,indent=2)+'\n')
def ignore(directory,names):return [n for n in names if n in {'__pycache__','.git','evidence-root','wcprof-complete.ndjson','archive.log'}]
if root.exists():shutil.rmtree(root)
root.mkdir();out.mkdir(exist_ok=True)
shutil.copytree(p,root/'study',ignore=ignore)
streams=[]
for complete in sorted(p.glob('capture-*/wcprof-complete.ndjson')):
 events=[];chunks=sorted(complete.parent.glob('chunk-*.ndjson.gz'));assert chunks
 for chunk in chunks:
  with gzip.open(chunk,'rb') as f:
   header=json.loads(f.readline());events.extend(f.readlines())
  assert header['dropped_events']==0
 assert not header.get('open_ops');header['event_count']=len(events)
 raw=(json.dumps(header)+'\n').encode()+b''.join(events);assert raw==complete.read_bytes()
 streams.append(dict(capture=complete.parent.name,chunks=[f.name for f in chunks],events=len(events),sha256=sha(raw),exact_bytes_verified=True))
assert len(streams)==4;write(root/'wcprof-reconstruction.json',streams)
parent=out.parent/'read-config-before-stat';meta=json.loads((parent/'archive.json').read_text())
assert sha((parent/'evidence.tar.gz').read_bytes())==meta['sha256']
write(root/'engine-source-parent.json',dict(path='../read-config-before-stat/evidence.tar.gz',**meta))
repo=Path('/tmp/dagger-go-discovery-source-snapshot');source=root/'module-source';source.mkdir()
for name in subprocess.check_output(['git','ls-files','-z'],cwd=repo).split(b'\x00'):
 if not name:continue
 name=name.decode();src=repo/name;dst=source/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_symlink():dst.symlink_to(src.readlink())
 else:shutil.copy2(src,dst)
links=[f for f in sorted(root.rglob('*')) if f.is_symlink()]
write(root/'module-source-links.json',[dict(path=str(f.relative_to(root)),target=str(f.readlink())) for f in links])
files=[f for f in sorted(root.rglob('*')) if f.is_file() and not f.is_symlink()]
manifest=[dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files]
mbytes=(json.dumps(manifest,indent=2)+'\n').encode();arc=out/'evidence.tar.gz'
with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for link in links:
  info=tar.gettarinfo(str(link),arcname=str(link.relative_to(root)));info.mtime=0;tar.addfile(info)
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(root)));info.mtime=0
  with f.open('rb') as stream:tar.addfile(info,stream)
 info=tarfile.TarInfo('manifest.json');info.size=len(mbytes);info.mtime=0;tar.addfile(info,io.BytesIO(mbytes))
with tarfile.open(arc,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+len(links)+1
 for link in links:
  info=tar.getmember(str(link.relative_to(root)));assert info.issym() and info.linkname==str(link.readlink())
 for r in manifest:
  data=tar.extractfile(r['path']).read();assert len(data)==r['bytes'] and sha(data)==r['sha256']
(out/'manifest.json').write_bytes(mbytes)
for name in ['assessment.json','source-identity.json','final-state.json','change.patch','scalar-selection-observations.json']:(out/name).write_bytes((p/name).read_bytes())
(out/'engine-source-parent.json').write_bytes((root/'engine-source-parent.json').read_bytes())
(out/'wcprof-reconstruction.json').write_bytes((root/'wcprof-reconstruction.json').read_bytes())
record=dict(bytes=arc.stat().st_size,sha256=sha(arc.read_bytes()),members=len(files)+len(links)+1,symlinks_verified=len(links),all_member_hashes_verified=True,lossless_streams_reconstructed=len(streams),binaries_excluded=True,selected=False)
write(out/'archive.json',record);print(json.dumps(record),flush=True)
