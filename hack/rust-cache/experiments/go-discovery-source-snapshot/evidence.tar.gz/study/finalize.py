from pathlib import Path
import json,subprocess,urllib.request
p=Path(__file__).parent;b=p.parent
previous=json.loads(Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/read-config-before-stat/final-state.json').read_text());expected=dict(previous['binaries']);expected['dagger-collection-read-config-oct19']=json.loads((b/'read-config-before-stat-engine/engine-build.json').read_text())['sha256'];binaries={};volumes={}
for name,want in expected.items():
 actual=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==want,name;binaries[name]=actual
 record=json.loads(subprocess.check_output(['docker','inspect',name]))[0];volumes[name]=[dict(name=m.get('Name'),destination=m['Destination']) for m in record['Mounts'] if m['Type']=='volume'];assert volumes[name]==previous['volumes'].get(name,[dict(name=name,destination='/var/lib/dagger')]),name

def get(port,route):
 with urllib.request.urlopen(f'http://127.0.0.1:{port}/debug/{route}',timeout=15) as f:return json.load(f)
states={}
for label,port in [('previous-benchmark',16112),('reduction-diagnostic',16113),('binding-diagnostic',16114),('merge-benchmark',16115),('lazy-spill-benchmark',16116),('read-config-benchmark',16117)]:
 reference=previous['states'].get(label,previous['states']['lazy-spill-benchmark']);flags={r:get(port,r) for r in reference['flags']}
 for route,want in reference['flags'].items():assert flags[route]['enabled']==want['enabled'],(label,route,flags[route],want)
 assert not flags['metadata-snapshot-json']['record']
 if port==16117:flags['read-config-before-stat']=get(port,'read-config-before-stat');assert not flags['read-config-before-stat']['enabled']
 lifecycle=get(port,'client-lifecycle');assert lifecycle['active_requests']==0 and lifecycle['runtimes']==0,(label,lifecycle);assert all(s['state']=='removed' for s in (lifecycle.get('sessions') or [])),label
 assert not get(port,'wcprof/enabled')['global_enabled'];assert get(port,'lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
 states[label]=dict(flags=flags,lifecycle=lifecycle,wcprof=get(port,'wcprof/enabled'),lock_profiler=get(port,'lock-profiler'))
for repo in ['/tmp/dagger-go-real-repository-main','/tmp/dagger-go-generation-native-membership','/tmp/dagger-read-config-before-stat','/tmp/dagger-go-discovery-source-snapshot']:assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b'',repo
plan_flags=json.loads((b/'read-config-before-stat-engine/engine-plan.json').read_text())['flags']
for route,want in plan_flags.items():assert get(16117,route)['enabled']==want,route
states['read-config-benchmark']['plan_flags_verified']=plan_flags
state=dict(binaries=binaries,volumes=volumes,states=states,real_workspace_clean=True,selected_module_clean=True,all_engines_and_volumes_retained=True,no_pr_opened=True,diagnostic_environment_retained=previous['diagnostic_environment_retained'])
(p/'final-state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(engines=len(binaries),restored=True,active_requests=0)),flush=True)
