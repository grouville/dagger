package clientdb

import (
	"bytes"
	"math"
	"testing"

	"github.com/stretchr/testify/require"
	commonpb "go.opentelemetry.io/proto/otlp/common/v1"
	"google.golang.org/protobuf/proto"
)

// Offline component screen only. This does not change any stored row format.
func TestNativeAttributeEncodingScreen(t *testing.T) {
	fixtures := map[string][]*commonpb.KeyValue{
		"representative": sampleSpanAttrs(),
		"empty":          {},
		"nil element":    {nil, strAttr("k", "v")},
		"special floats": {
			{Key: "nan", Value: &commonpb.AnyValue{Value: &commonpb.AnyValue_DoubleValue{DoubleValue: math.NaN()}}},
			{Key: "positive infinity", Value: &commonpb.AnyValue{Value: &commonpb.AnyValue_DoubleValue{DoubleValue: math.Inf(1)}}},
			{Key: "negative zero", Value: &commonpb.AnyValue{Value: &commonpb.AnyValue_DoubleValue{DoubleValue: math.Copysign(0, -1)}}},
		},
	}
	for name, attrs := range fixtures {
		t.Run(name, func(t *testing.T) {
			jsonBytes, err := MarshalProtoJSONs(attrs)
			require.NoError(t, err)
			var original []*commonpb.KeyValue
			require.NoError(t, unmarshalProtoJSONsOptimized(jsonBytes, &commonpb.KeyValue{}, &original))
			encoded, err := proto.Marshal(&commonpb.KeyValueList{Values: attrs})
			require.NoError(t, err)
			var decoded commonpb.KeyValueList
			require.NoError(t, proto.Unmarshal(encoded, &decoded))
			require.Equal(t, len(original), len(decoded.Values))
			for i := range original {
				require.True(t, proto.Equal(original[i], decoded.Values[i]), "attribute %d", i)
			}
			t.Logf("JSON %d bytes; native %d bytes", len(jsonBytes), len(encoded))
		})
	}
	invalid := []*commonpb.KeyValue{strAttr("key", string([]byte{0xff}))}
	_, jsonErr := MarshalProtoJSONs(invalid)
	_, nativeErr := proto.Marshal(&commonpb.KeyValueList{Values: invalid})
	require.Error(t, jsonErr)
	require.Error(t, nativeErr)
}

func BenchmarkNativeAttributeEncodingScreen(b *testing.B) {
	fixtures := map[string][]*commonpb.KeyValue{
		"small":          {strAttr("dagger.io/dag.digest", "xxh3:0123456789abcdef"), strAttr("name", "a package")},
		"representative": sampleSpanAttrs(),
	}
	for name, attrs := range fixtures {
		b.Run(name, func(b *testing.B) {
			jsonBytes, err := MarshalProtoJSONs(attrs)
			if err != nil {
				b.Fatal(err)
			}
			nativeBytes, err := proto.Marshal(&commonpb.KeyValueList{Values: attrs})
			if err != nil {
				b.Fatal(err)
			}
			b.Run("json-encode", func(b *testing.B) {
				b.ReportAllocs()
				for b.Loop() {
					if _, err := MarshalProtoJSONs(attrs); err != nil {
						b.Fatal(err)
					}
				}
			})
			b.Run("native-encode", func(b *testing.B) {
				b.ReportAllocs()
				for b.Loop() {
					if _, err := proto.Marshal(&commonpb.KeyValueList{Values: attrs}); err != nil {
						b.Fatal(err)
					}
				}
			})
			b.Run("json-decode", func(b *testing.B) {
				b.ReportAllocs()
				for b.Loop() {
					var out []*commonpb.KeyValue
					if err := unmarshalProtoJSONsOptimized(jsonBytes, &commonpb.KeyValue{}, &out); err != nil {
						b.Fatal(err)
					}
				}
			})
			b.Run("native-decode", func(b *testing.B) {
				b.ReportAllocs()
				for b.Loop() {
					var out commonpb.KeyValueList
					if err := proto.Unmarshal(nativeBytes, &out); err != nil {
						b.Fatal(err)
					}
				}
			})
		})
	}
	// Match the existing large call-frame payload scale without benchmarking
	// base64 generation or constructing the input inside the timed loop.
	b.Run("large-call", func(b *testing.B) {
		attrs := []*commonpb.KeyValue{strAttr("dagger.io/dag.call", string(bytes.Repeat([]byte("a"), 64*1024)))}
		b.Run("json", func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				if _, err := MarshalProtoJSONs(attrs); err != nil {
					b.Fatal(err)
				}
			}
		})
		b.Run("native", func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				if _, err := proto.Marshal(&commonpb.KeyValueList{Values: attrs}); err != nil {
					b.Fatal(err)
				}
			}
		})
	})
}
