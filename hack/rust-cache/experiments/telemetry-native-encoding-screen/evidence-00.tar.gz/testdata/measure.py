from pathlib import Path
import json
import os
import re
import statistics
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
assert 'PASS' in (p / 'compatibility.log').read_text()
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8')
rows = []
for pair in range(4):
    order = ['json', 'native'] if pair % 2 == 0 else ['native', 'json']
    for arm in order:
        command = [go, 'test', '-p=2', '-count=1', '-run=^$',
                   '-bench=^BenchmarkNativeAttributeEncodingScreen$/.*/' + arm + '.*$',
                   '-benchtime=250ms', '-benchmem',
                   '-modfile=/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
                   '-overlay=' + str(p / 'test-overlay.json'), './engine/clientdb']
        start = time.monotonic()
        log = p / f'{pair}-{arm}.log'
        with log.open('w') as output:
            result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds',
                                    env=env, stdout=output, stderr=subprocess.STDOUT)
        row = dict(pair=pair, arm=arm, command=command, exit_code=result.returncode,
                   seconds=time.monotonic()-start, log=log.name, benchmarks=[])
        for line in log.read_text().splitlines():
            match = re.match(r'^BenchmarkNativeAttributeEncodingScreen/(.*)-8\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op', line)
            if match:
                name = match[1].replace('/json', '/codec').replace('/native', '/codec')
                row['benchmarks'].append(dict(name=name, iterations=int(match[2]),
                    ns=float(match[3]), bytes=int(match[4]), allocations=int(match[5])))
        rows.append(row)
        (p / 'samples.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps(dict(pair=pair, arm=arm, exit_code=result.returncode,
                              cases=len(row['benchmarks']))), flush=True)
        assert result.returncode == 0 and len(row['benchmarks']) == 5, log.read_text()[-4000:]

summary = {}
for name in sorted({case['name'] for row in rows for case in row['benchmarks']}):
    values = {arm: [next(case for case in row['benchmarks'] if case['name']==name)
                    for row in rows if row['arm']==arm] for arm in ['json', 'native']}
    summary[name] = dict(
        medians={arm: {field: statistics.median(case[field] for case in cases)
                       for field in ['ns', 'bytes', 'allocations']} for arm, cases in values.items()},
        faster_pairs=sum(a['ns']>b['ns'] for a,b in zip(values['json'], values['native'])))
(p / 'summary.json').write_text(json.dumps(dict(
    scope='Offline component screen: four alternating fresh-process pairs. No production storage, engine change or complete-command performance claim.',
    pairs=4, results=summary), indent=2)+'\n')
print(json.dumps(summary, indent=2), flush=True)
