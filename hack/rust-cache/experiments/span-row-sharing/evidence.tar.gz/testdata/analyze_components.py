from pathlib import Path
import json
import re
import statistics

p=Path(__file__).parent
pattern=re.compile(r'^BenchmarkSpanRowFanout/destinations=(\d+)/spans=(\d+)/shared=(false|true)-\d+\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',re.M)
out={}
for cohort in ['component-closed-store','component-open-store']:
 root=p/cohort
 values={}
 for file in sorted(root.glob('*.log')):
  if cohort=='component-closed-store' and not file.name.startswith('component-'): continue
  if cohort=='component-open-store' and not re.match(r'\d+-(before|after)\.log$',file.name): continue
  for width,count,shared,n,ns,allocated,allocs in pattern.findall(file.read_text()):
   key=(int(width),int(count))
   arm='after' if shared=='true' else 'before'
   pair=int(file.name.split('-')[1 if cohort=='component-closed-store' else 0])
   values.setdefault(key,{}).setdefault(arm,{})[pair]=dict(ns=float(ns),bytes=int(allocated),allocs=int(allocs))
 rows=[]
 for (width,count),arms in sorted(values.items()):
  assert all(len(arms[arm])==4 for arm in ['before','after']), (cohort,width,count,arms)
  row=dict(destinations=width,spans=count,
           medians={arm:{metric:statistics.median(v[metric] for v in runs.values()) for metric in ['ns','bytes','allocs']} for arm,runs in arms.items()},
           faster_pairs=sum(arms['after'][pair]['ns']<arms['before'][pair]['ns'] for pair in range(4)),
           lower_allocation_pairs=sum(arms['after'][pair]['bytes']<arms['before'][pair]['bytes'] for pair in range(4)),
           samples=arms)
  rows.append(row)
  print(cohort,width,count,json.dumps({k:row[k] for k in ['medians','faster_pairs','lower_allocation_pairs']}))
 out[cohort]=rows
(p/'component-summary.json').write_text(json.dumps(out,indent=2)+'\n')
