package server

import (
	"context"
	"fmt"
	"slices"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/dagger/dagger/engine/clientdb"
	"github.com/dagger/dagger/engine/telemetryattrs"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/sdk/trace/tracetest"
	"go.opentelemetry.io/otel/trace"
)

func spanSharingFixture(tb testing.TB, width int) (sessionSpanExporter, *clientdb.DBs, []string) {
	tb.Helper()
	dbs := clientdb.NewDBs(tb.TempDir())
	tb.Cleanup(func() { require.NoError(tb, dbs.Close()) })
	sess := &daggerSession{clientRecords: map[string]*clientRecord{}}
	var clients []string
	for i := range width {
		id := fmt.Sprintf("client-%d", i)
		sess.clientRecords[id] = &clientRecord{daggerSession: sess, clientID: id, parentClientIDs: slices.Clone(clients)}
		clients = append(clients, id)
	}
	return sessionSpanExporter{sess: sess, ps: NewPubSub(&Server{clientDBs: dbs})}, dbs, clients
}

func sharingSpan(origin string, id int, name string, finished bool) sdktrace.ReadOnlySpan {
	sc := trace.NewSpanContext(trace.SpanContextConfig{TraceID: trace.TraceID{1}, SpanID: trace.SpanID{byte(id >> 8), byte(id)}, TraceFlags: trace.FlagsSampled})
	stub := tracetest.SpanStub{
		Name: name, SpanContext: sc,
		Parent:    trace.NewSpanContext(trace.SpanContextConfig{TraceID: trace.TraceID{1}, SpanID: trace.SpanID{7}}),
		StartTime: time.Unix(10, 0),
		Attributes: []attribute.KeyValue{
			attribute.String(telemetryattrs.TelemetryOriginClientIDAttr, origin),
			attribute.String("operation", "listing"), attribute.Int("index", id),
			attribute.StringSlice("values", []string{"a", "b"}),
		},
		Events:            []sdktrace.Event{{Name: "progress", Time: time.Unix(11, 0), Attributes: []attribute.KeyValue{attribute.Int("step", 1)}}},
		Links:             []sdktrace.Link{{SpanContext: sc, Attributes: []attribute.KeyValue{attribute.String("purpose", "test")}}},
		Resource:          resource.NewSchemaless(attribute.String("service.name", "engine")),
		DroppedAttributes: 2, DroppedEvents: 3, DroppedLinks: 4,
	}
	if finished {
		stub.EndTime = time.Unix(12, 0)
	}
	return stub.Snapshot()
}

type countedEncodingSpan struct {
	sdktrace.ReadOnlySpan
	names atomic.Int64
}

func (s *countedEncodingSpan) Name() string {
	s.names.Add(1)
	return s.ReadOnlySpan.Name()
}

func equivalentStoredSpan(t *testing.T, want, got clientdb.Span) {
	t.Helper()
	for _, pair := range [][2][]byte{
		{want.Attributes, got.Attributes}, {want.Events, got.Events}, {want.Links, got.Links},
		{want.InstrumentationScope, got.InstrumentationScope}, {want.Resource, got.Resource},
	} {
		require.JSONEq(t, string(pair[0]), string(pair[1]))
	}
	want.ID, got.ID = 0, 0
	want.Attributes, got.Attributes = nil, nil
	want.Events, got.Events = nil, nil
	want.Links, got.Links = nil, nil
	want.InstrumentationScope, got.InstrumentationScope = nil, nil
	want.Resource, got.Resource = nil, nil
	require.Equal(t, want, got)
}

func TestSpanRowSharingEncodesOncePerRoute(t *testing.T) {
	exp, dbs, clients := spanSharingFixture(t, 4)
	origin := clients[len(clients)-1]
	// Give one destination a different next row ID before sharing the payload.
	require.NoError(t, exp.ps.Spans(clients[0]).ExportSpans(t.Context(), []sdktrace.ReadOnlySpan{sharingSpan(origin, 9, "seed", true)}))
	first := &countedEncodingSpan{ReadOnlySpan: sharingSpan(origin, 1, "running", false)}
	last := &countedEncodingSpan{ReadOnlySpan: sharingSpan(origin, 1, "finished", true)}
	require.NoError(t, exp.ExportSpans(t.Context(), []sdktrace.ReadOnlySpan{first, last}))
	require.EqualValues(t, 1, first.names.Load(), "serialize once for all four destinations")
	require.EqualValues(t, 1, last.names.Load(), "keep separate snapshots of the same span")

	golden := clientSpans{PubSub: exp.ps, clientID: "golden"}
	require.NoError(t, golden.exportSpansOriginal(t.Context(), []sdktrace.ReadOnlySpan{withoutSpanOrigin(first), withoutSpanOrigin(last)}))
	want, _ := clientRows(t, dbs, "golden")
	require.Len(t, want, 2)
	for i, client := range clients {
		got, _ := clientRows(t, dbs, client)
		skip := 0
		if i == 0 {
			skip = 1
		}
		require.Len(t, got, 2+skip)
		for j, row := range got[skip:] {
			require.EqualValues(t, j+skip+1, row.ID)
			equivalentStoredSpan(t, want[j], row)
		}
	}
}

func TestSpanRowSharingRefreshesEachExport(t *testing.T) {
	exp, dbs, clients := spanSharingFixture(t, 3)
	origin := clients[len(clients)-1]
	for _, finished := range []bool{false, true} {
		require.NoError(t, exp.ExportSpans(t.Context(), []sdktrace.ReadOnlySpan{sharingSpan(origin, 1, fmt.Sprint(finished), finished)}))
	}
	for _, client := range clients {
		rows, _ := clientRows(t, dbs, client)
		require.Len(t, rows, 2)
		require.Equal(t, "false", rows[0].Name)
		require.False(t, rows[0].EndTime.Valid)
		require.Equal(t, "true", rows[1].Name)
		require.True(t, rows[1].EndTime.Valid)
	}
}

func TestSpanRowSharingPanicFailsEveryDestination(t *testing.T) {
	exp, dbs, clients := spanSharingFixture(t, 3)
	origin := clients[len(clients)-1]
	require.ErrorContains(t, exp.ExportSpans(t.Context(), []sdktrace.ReadOnlySpan{panickySpan{sharingSpan(origin, 1, "bad", true)}}), "lazy decode exploded")
	for _, client := range clients {
		rows, _ := clientRows(t, dbs, client)
		require.Empty(t, rows)
	}
	require.NoError(t, exp.ExportSpans(t.Context(), []sdktrace.ReadOnlySpan{sharingSpan(origin, 1, "retry", true)}))
	for _, client := range clients {
		rows, _ := clientRows(t, dbs, client)
		require.Len(t, rows, 1)
		require.Equal(t, "retry", rows[0].Name)
	}
}

func TestSpanRowSharingConcurrentExports(t *testing.T) {
	exp, dbs, clients := spanSharingFixture(t, 3)
	origin := clients[len(clients)-1]
	var wg sync.WaitGroup
	errs := make(chan error, 8)
	for i := range 8 {
		wg.Go(func() {
			errs <- exp.ExportSpans(context.Background(), []sdktrace.ReadOnlySpan{sharingSpan(origin, i+1, fmt.Sprint(i), true)})
		})
	}
	wg.Wait()
	close(errs)
	for err := range errs {
		require.NoError(t, err)
	}
	for _, client := range clients {
		rows, _ := clientRows(t, dbs, client)
		require.Len(t, rows, 8)
		names := make(map[string]bool)
		for i, row := range rows {
			require.EqualValues(t, i+1, row.ID)
			names[row.Name] = true
		}
		require.Len(t, names, 8)
	}
}

func BenchmarkSpanRowFanout(b *testing.B) {
	for _, width := range []int{1, 3} {
		for _, count := range []int{1, 128} {
			for _, shared := range []bool{false, true} {
				b.Run(fmt.Sprintf("destinations=%d/spans=%d/shared=%t", width, count, shared), func(b *testing.B) {
					previous := spanRowSharingEnabled.Swap(shared)
					defer spanRowSharingEnabled.Store(previous)
					exp, _, clients := spanSharingFixture(b, width)
					// A live client runtime holds its store open between exports.
					for _, client := range clients {
						db, err := exp.ps.srv.clientDBs.Open(b.Context(), client)
						require.NoError(b, err)
						b.Cleanup(func() { require.NoError(b, db.Close()) })
					}
					origin := clients[len(clients)-1]
					spans := make([]sdktrace.ReadOnlySpan, count)
					for i := range spans {
						spans[i] = sharingSpan(origin, i+1, "compile", true)
					}
					b.ReportAllocs()
					for b.Loop() {
						if err := exp.ExportSpans(b.Context(), spans); err != nil {
							b.Fatal(err)
						}
					}
				})
			}
		}
	}
}
