from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p=Path(__file__).parent
components=json.loads((p/'component-summary.json').read_text())['component-open-store']
bulk=next(row for row in components if row['destinations']==3 and row['spans']==128)
assert bulk['lower_allocation_pairs']==4 and bulk['faster_pairs']==4
assert len(json.loads((p/'component-open-store/validation.json').read_text()))==8
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
         '-overlay',str(p/'after-test-overlay.json'),'-race','-count=1','-v',
         '-run','^Test(SpanRowSharing|TelemetryRoutesClientsAndAncestorsExactlyOnce|SessionSpanExporter|TelemetryExport|TelemetryStream|TracesHandlerToleratesMissingResource|CallPayloadWriteOwnershipAndRelease)',
         './engine/server']
tick=time.monotonic()
with (p/'refined-race.log').open('w') as output:
    result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=output,stderr=subprocess.STDOUT)
row=dict(command=command,seconds=time.monotonic()-tick,exit_code=result.returncode,
         source_sha256={name:hashlib.sha256((p/name).read_bytes()).hexdigest()
                        for name in ['controlled-telemetry.go','span_row_sharing.go','span_row_sharing_test.go']})
(p/'refined-validation.json').write_text(json.dumps(row,indent=2)+'\n')
print('refined-race',result.returncode,flush=True)
assert result.returncode==0,(p/'refined-race.log').read_text()[-5000:]
result=subprocess.run(['python3',str(p/'deploy-profile.py')],env=env)
raise SystemExit(result.returncode)
