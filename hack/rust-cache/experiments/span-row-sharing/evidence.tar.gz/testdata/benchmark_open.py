from pathlib import Path
import json
import os
import subprocess
import time

p=Path(__file__).parent
out=p/'component-open-store'
out.mkdir(exist_ok=False)
(out/'span_row_sharing_test.go').write_bytes((p/'span_row_sharing_test.go').read_bytes())
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for pair in range(4):
 for shared in ([False,True] if pair%2 == 0 else [True,False]):
  label=f'{pair}-'+('after' if shared else 'before')
  command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
           '-overlay',str(p/'after-test-overlay.json'),'-run','^$','-count=1','-benchmem','-benchtime=100x',
           '-bench','^BenchmarkSpanRowFanout$/^destinations=.*$/^spans=.*$/^shared='+str(shared).lower()+'$','./engine/server']
  tick=time.monotonic()
  with (out/(label+'.log')).open('w') as output:
   result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=output,stderr=subprocess.STDOUT)
  row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=result.returncode)
  rows.append(row)
  (out/'validation.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(json.dumps(row),flush=True)
  assert result.returncode==0,(out/(label+'.log')).read_text()[-4000:]
