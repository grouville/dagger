package server
func init() { spanRowSharingEnabled.Store(true) }
