from pathlib import Path
import json
import textwrap

p = Path('/tmp/rust-cache-sipsma-review/span-row-sharing')
p.mkdir(exist_ok=True)
base = Path('/tmp/dagger-filesync-snapshot-seeds')
old = Path('/tmp/rust-cache-sipsma-review/span-resource-batches/controlled-telemetry.go').read_text()
start = old.index('func (ps clientSpans) exportSpansOriginal(')
end = old.index('\nfunc (ps clientSpans) exportSpansResourceBatches(', start)
original = old[start:end]
loop_start = original.index('\tfor _, span := range spans {\n')
loop_end = original.index('\n\trecordSpanResourceBatch(', loop_start)
body = original[loop_start + len('\tfor _, span := range spans {\n'):loop_end]
assert body.endswith('\t}\n')
body = body[:-len('\t}\n')]
body = '\n'.join(line[1:] if line.startswith('\t') else line for line in body.splitlines()) + '\n'
body = body.replace('\t\tcontinue', '\t\treturn clientdb.Span{}, false')
body = body.replace('\tinserts = append(inserts, clientdb.Span{', '\treturn clientdb.Span{')
assert body.endswith('\t})\n')
body = body[:-len('\t})\n')] + '\t}, true\n'
shared = original[:loop_start] + '''\tfor _, span := range spans {
\t\tvar row clientdb.Span
\t\tvar ok bool
\t\tif shared, cached := span.(*sharedEncodedSpan); cached {
\t\t\trow, ok = shared.row()
\t\t} else {
\t\t\trow, ok = encodeSpanRow(span)
\t\t}
\t\tif ok {
\t\t\tinserts = append(inserts, row)
\t\t}
\t}
''' + original[loop_end:]
shared = shared.replace('exportSpansOriginal(', 'exportSpansSharedRows(', 1)
helper = '''package server

import (
    "context"
    "database/sql"
    "fmt"
    "sync"
    "time"

    "github.com/dagger/dagger/engine/clientdb"
    "github.com/dagger/dagger/engine/slog"
    telemetry "github.com/dagger/otel-go"
    sdktrace "go.opentelemetry.io/otel/sdk/trace"
    "google.golang.org/protobuf/encoding/protojson"
)

// One export may send the same span to several immutable client histories.
// Keep its encoded blobs within that export; stores assign their own row IDs.
// Encoding stays inside exportSpansRecovered, including lazy-decoder panics.
type sharedEncodedSpan struct {
    sdktrace.ReadOnlySpan
    row func() (clientdb.Span, bool)
}

func shareSpanEncoding(span sdktrace.ReadOnlySpan) sdktrace.ReadOnlySpan {
    return &sharedEncodedSpan{
        ReadOnlySpan: span,
        row: sync.OnceValues(func() (clientdb.Span, bool) { return encodeSpanRow(span) }),
    }
}

func encodeSpanRow(span sdktrace.ReadOnlySpan) (clientdb.Span, bool) {
    recordSpanRowEncoding()
''' + body + '}\n\n' + shared
(p / 'span_row_sharing.go').write_text(helper)
controlled = old.replace('\t\tspan = withoutSpanOrigin(span)\n', '''\t\tspan = withoutSpanOrigin(span)
\t\trecordSpanRowRoute(len(route))
\t\tif spanRowSharingEnabled.Load() && len(route) > 1 {
\t\t\tspan = shareSpanEncoding(span)
\t\t}
''', 1)
controlled = controlled.replace('func (ps clientSpans) ExportSpans(ctx context.Context, spans []sdktrace.ReadOnlySpan) error {\n', '''func (ps clientSpans) ExportSpans(ctx context.Context, spans []sdktrace.ReadOnlySpan) error {
\tif spanRowSharingEnabled.Load() {
\t\tfor _, span := range spans {
\t\t\tif _, shared := span.(*sharedEncodedSpan); shared {
\t\t\t\treturn ps.exportSpansSharedRows(ctx, spans)
\t\t\t}
\t\t}
\t}
''', 1)
original_instrumented = original.replace('\tfor _, span := range spans {\n', '\tfor _, span := range spans {\n\t\trecordSpanRowEncoding()\n', 1)
controlled = controlled.replace(original, original_instrumented, 1)
(p / 'controlled-telemetry.go').write_text(controlled)
overlay = json.loads(Path('/tmp/rust-cache-sipsma-review/restored-data-list-projection/engine-overlay.json').read_text())
overlay['Replace'][str(base / 'engine/server/telemetry.go')] = str(p / 'controlled-telemetry.go')
for name in ['span_row_sharing.go', 'span_row_sharing_mode.go']:
    overlay['Replace'][str(base / 'engine/server' / name)] = str(p / name)
(p / 'engine-overlay.json').write_text(json.dumps(overlay, indent=2) + '\n')
print(p)
