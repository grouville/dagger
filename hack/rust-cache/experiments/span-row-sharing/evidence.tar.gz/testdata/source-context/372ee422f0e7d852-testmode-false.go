package server
func init() { spanRowSharingEnabled.Store(false) }
