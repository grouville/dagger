package server

import (
	"context"
	"database/sql"
	"fmt"
	"sync"
	"time"

	"github.com/dagger/dagger/engine/clientdb"
	"github.com/dagger/dagger/engine/slog"
	telemetry "github.com/dagger/otel-go"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"google.golang.org/protobuf/encoding/protojson"
)

// One export may send the same span to several immutable client histories.
// Keep its encoded blobs within that export; stores assign their own row IDs.
// Encoding stays inside exportSpansRecovered, including lazy-decoder panics.
type sharedEncodedSpan struct {
	sdktrace.ReadOnlySpan
	row func() (clientdb.Span, bool)
}

func shareSpanEncoding(span sdktrace.ReadOnlySpan) sdktrace.ReadOnlySpan {
	return &sharedEncodedSpan{
		ReadOnlySpan: span,
		row:          sync.OnceValues(func() (clientdb.Span, bool) { return encodeSpanRow(span) }),
	}
}

func encodeSpanRow(span sdktrace.ReadOnlySpan) (clientdb.Span, bool) {
	recordSpanRowEncoding()
	traceID := span.SpanContext().TraceID().String()
	spanID := span.SpanContext().SpanID().String()
	traceState := span.SpanContext().TraceState().String()
	parentSpanID := span.Parent().SpanID().String()
	flags := int64(span.SpanContext().TraceFlags())
	name := span.Name()
	kind := span.SpanKind().String()
	startTime := span.StartTime().UnixNano()
	endTime := sql.NullInt64{
		Int64: span.EndTime().UnixNano(),
		Valid: !span.EndTime().IsZero(),
	}
	if span.EndTime().Before(span.StartTime()) {
		endTime.Int64 = 0
		endTime.Valid = false
	}
	attributes, err := clientdb.MarshalProtoJSONs(telemetry.KeyValues(span.Attributes()))
	if err != nil {
		slog.Warn("failed to marshal attributes", "error", err)
		return clientdb.Span{}, false
	}
	droppedAttributesCount := int64(span.DroppedAttributes())
	events, err := clientdb.MarshalProtoJSONs(telemetry.SpanEventsToPB(span.Events()))
	if err != nil {
		slog.Warn("failed to marshal events", "error", err)
		return clientdb.Span{}, false
	}
	droppedEventsCount := int64(span.DroppedEvents())
	links, err := clientdb.MarshalProtoJSONs(telemetry.SpanLinksToPB(span.Links()))
	if err != nil {
		slog.Warn("failed to marshal links", "error", err)
		return clientdb.Span{}, false
	}
	droppedLinksCount := int64(span.DroppedLinks())
	statusCode := int64(span.Status().Code)
	statusMessage := span.Status().Description
	instrumentationScope, err := protojson.Marshal(telemetry.InstrumentationScopeToPB(span.InstrumentationScope()))
	if err != nil {
		slog.Warn("failed to marshal instrumentation scope", "error", err)
		return clientdb.Span{}, false
	}
	resource, err := protojson.Marshal(telemetry.ResourcePtrToPB(span.Resource()))
	if err != nil {
		slog.Warn("failed to marshal resource", "error", err)
		return clientdb.Span{}, false
	}

	return clientdb.Span{
		TraceID:    traceID,
		SpanID:     spanID,
		TraceState: traceState,
		ParentSpanID: sql.NullString{
			String: parentSpanID,
			Valid:  span.Parent().IsValid(),
		},
		Flags:                  flags,
		Name:                   name,
		Kind:                   kind,
		StartTime:              startTime,
		EndTime:                endTime,
		Attributes:             attributes,
		DroppedAttributesCount: droppedAttributesCount,
		Events:                 events,
		DroppedEventsCount:     droppedEventsCount,
		Links:                  links,
		DroppedLinksCount:      droppedLinksCount,
		StatusCode:             statusCode,
		StatusMessage:          statusMessage,
		InstrumentationScope:   instrumentationScope,
		Resource:               resource,
	}, true
}

func (ps clientSpans) exportSpansSharedRows(ctx context.Context, spans []sdktrace.ReadOnlySpan) error {
	slog.ExtraDebug("pubsub exporting spans", "client", ps.clientID, "count", len(spans))
	start := time.Now()

	var inserts []clientdb.Span
	for _, span := range spans {
		var row clientdb.Span
		var ok bool
		if shared, cached := span.(*sharedEncodedSpan); cached {
			row, ok = shared.row()
		} else {
			row, ok = encodeSpanRow(span)
		}
		if ok {
			inserts = append(inserts, row)
		}
	}

	recordSpanResourceBatch(len(inserts), len(inserts))

	db, err := ps.srv.clientDBs.Open(ctx, ps.clientID)
	if err != nil {
		return fmt.Errorf("get telemetry db: %w", err)
	}
	defer db.Close()

	appendStart := time.Now()
	stats, appendErr := db.AppendSpans(inserts)
	logTelemetryWrite(ps.clientID, "spans", len(inserts), start, appendStart, stats, appendErr)
	if appendErr != nil {
		return appendErr
	}

	return nil
}
