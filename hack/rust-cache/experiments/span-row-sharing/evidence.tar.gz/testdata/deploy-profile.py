from pathlib import Path
import json
import subprocess
import time

p = Path(__file__).parent
steps = [
    ('build-driver', ['python3', str(p/'build-engine.py')]),
    ('install-driver', ['python3', str(p/'install-engine.py')]),
    ('preflight-driver', ['python3', str(p/'capture.py'), '--output', str(p/'preflight'), '--languages', 'go']),
]
rows = []
for label, command in steps:
    started = time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, seconds=time.monotonic()-started, exit_code=result.returncode))
    (p/'deployment-validation.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p/(label+'.log')).read_text()[-5000:]
print('PASS: native cache preserved; real full listing exercises shared span serialization with correct output and destination counts', flush=True)
