from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
base = [go, 'test', '-p', '2', '-buildvcs=false', '-modfile', '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod']
steps = [
    ('before-regression', ['-overlay', str(p/'before-test-overlay.json'), '-count=1', '-v', '-run', '^TestSpanRowSharingEncodesOncePerRoute$', './engine/server'], 1),
    ('after-race', ['-overlay', str(p/'after-test-overlay.json'), '-race', '-count=1', '-v', '-run', '^Test(SpanRowSharing|TelemetryRoutesClientsAndAncestorsExactlyOnce|SessionSpanExporter|TelemetryExport|TelemetryStream|TracesHandlerToleratesMissingResource|CallPayloadWriteOwnershipAndRelease)', './engine/server'], 0),
]
rows = []
for label, args, expected in steps:
    tick = time.monotonic()
    command = base + args
    with (p/(label+'.log')).open('w') as output:
        result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds', env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, seconds=time.monotonic()-tick, exit_code=result.returncode, expected_exit_code=expected)
    rows.append(row)
    (p/'validation.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    assert result.returncode == expected, (p/(label+'.log')).read_text()[-5000:]
    if expected == 1:
        assert 'serialize once for all four destinations' in (p/(label+'.log')).read_text()

for pair in range(4):
    order = [False, True] if pair%2 == 0 else [True, False]
    for shared in order:
        label = f'component-{pair}-'+('after' if shared else 'before')
        command = base + ['-overlay', str(p/'after-test-overlay.json'), '-run', '^$', '-count=1', '-benchmem', '-benchtime=30x',
                          '-bench', '^BenchmarkSpanRowFanout$/^destinations=.*$/^spans=.*$/^shared='+str(shared).lower()+'$', './engine/server']
        tick = time.monotonic()
        with (p/(label+'.log')).open('w') as output:
            result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds', env=env, stdout=output, stderr=subprocess.STDOUT)
        row = dict(label=label, command=command, seconds=time.monotonic()-tick, exit_code=result.returncode)
        rows.append(row)
        (p/'validation.json').write_text(json.dumps(rows, indent=2)+'\n')
        print(json.dumps(row), flush=True)
        assert result.returncode == 0, (p/(label+'.log')).read_text()[-5000:]
