from pathlib import Path
import json

p=Path(__file__).parent
previous=Path('/tmp/rust-cache-sipsma-review/restored-data-list-projection')

def replace(text, old, new, count=1):
    assert text.count(old)==count,(old,text.count(old),count)
    return text.replace(old,new)

build=(previous/'build-engine.py').read_text()
build=replace(build,"assert len(validation)==3 and all(x['exit_code']==x['expected_exit_code'] for x in validation)",
              "assert len(validation)==10 and all(x['exit_code']==x.get('expected_exit_code',0) for x in validation)\nassert json.loads((p/'refined-validation.json').read_text())['exit_code']==0\ncomponents=json.loads((p/'component-summary.json').read_text())['component-open-store']\nassert next(row for row in components if row['destinations']==3 and row['spans']==128)['lower_allocation_pairs']==4")
build=build.replace('restored-data-list-projection-before','span-row-sharing-before')
(p/'build-engine.py').write_text(build)

install=(previous/'install-engine.py').read_text()
install=install.replace("row['exit_code'] == row['expected_exit_code']", "row['exit_code'] == row.get('expected_exit_code',0)")
install=replace(install,'c07402078e15e3f8db04c4cbe26ed755b578e6d808a514be7304df8b9df75604',
                'b9bcd30902a5c80f42781ac2cd3c513c1ebddbfc088268d820769c215931579f')
install=replace(install,'/tmp/rust-cache-sipsma-review/native-search-data-projection/activation.json',str(previous/'activation.json'))
install=replace(install,"mode('native-search-projection', True)\nmode('restored-data-list-projection', True)",
                "mode('native-search-projection', False)\nmode('restored-data-list-projection', False)\nmode('span-row-sharing', True)")
install=replace(install,"routes + ['restored-data-list-projection']", "routes + ['span-row-sharing']")
install=install.replace('restored-data-list-projection-first-after','span-row-sharing-first-after')
install=replace(install,"native_search_projection=get('native-search-projection'),", "span_row_sharing=get('span-row-sharing'),\n    native_search_projection=get('native-search-projection'),")
(p/'install-engine.py').write_text(install)

capture=(previous/'capture.py').read_text()
capture=replace(capture,"'native-search-projection','restored-data-list-projection']", "'native-search-projection','restored-data-list-projection','span-row-sharing']")
capture=replace(capture,"'scalar-list-projection','native-search-projection','restored-data-list-projection','restored-posting-removal']", "'scalar-list-projection','span-row-sharing','restored-posting-removal']")
capture=replace(capture,'Diagnostic complete Go listing with fresh and restored native SearchResult metadata projection and selected data-only key projection.',
                'Diagnostic complete Go listing with one encoded span row per routed source snapshot, shared only within its export batch. Both unsuccessful search projection switches stay off; selected data-only key projection remains on.')
capture=capture.replace('Native search metadata profile','Shared span row profile')
capture=replace(capture," metadata['flags_during']", " get('span-row-sharing?record=true',b'');get('span-resource-batches?record=true',b'')\n metadata['flags_during']")
capture=replace(capture,"result=dict(seconds=elapsed", "span_rows=get('span-row-sharing');stored_rows=get('span-resource-batches')\nget('span-row-sharing?record=false',b'');get('span-resource-batches?record=false',b'')\nresult=dict(span_row_sharing=span_rows,span_destination_writes=stored_rows,seconds=elapsed")
capture += "\nassert span_rows['encodings']==span_rows['routed_spans']\nassert stored_rows['rows']==span_rows['destinations']\nassert span_rows['destinations']>span_rows['encodings']\n"
(p/'capture.py').write_text(capture)

measure=(previous/'measure_listing.py').read_text()
measure=replace(measure,"'native-search-projection','restored-data-list-projection']", "'native-search-projection','restored-data-list-projection','span-row-sharing']")
measure=replace(measure,"Only projection of native SearchResult scalar metadata, including safely borrowed restored values, differs.",
                'Only sharing encoded span rows within one export differs. All route destinations, stored rows, telemetry delivery barriers and independent row IDs remain intact. Both search projection switches stay disabled.')
measure=replace(measure,'This extends the existing data-only projection policy to a native immutable metadata type; no module or collection UX changes.',
                'This removes repeated serialization across client destinations; no stored format, module or collection UX changes.')
measure=replace(measure,"mode('native-search-projection',arm=='after')\n            mode('restored-data-list-projection',arm=='after')", "mode('native-search-projection',False)\n            mode('restored-data-list-projection',False)\n            mode('span-row-sharing',arm=='after')\n            get('span-row-sharing?record=false',b'')")
measure=replace(measure,"assert get('native-search-projection')['enabled'] == (arm=='after')\n            assert get('restored-data-list-projection')['enabled'] == (arm=='after')", "assert not get('native-search-projection')['enabled']\n            assert not get('restored-data-list-projection')['enabled']\n            assert get('span-row-sharing')['enabled'] == (arm=='after')\n            assert not get('span-row-sharing')['record']")
measure=replace(measure,"row=dict(restored_projection_before=", "row=dict(span_row_sharing=get('span-row-sharing'),restored_projection_before=")
(p/'measure_listing.py').write_text(measure)

deploy=(previous/'deploy-profile.py').read_text()
deploy=replace(deploy,"    ('analyze-preflight', ['python3', str(p/'analyze-preflight.py')]),\n", '')
deploy=deploy.replace('real full listing exercises native search projection with correct output','real full listing exercises shared span serialization with correct output and destination counts')
(p/'deploy-profile.py').write_text(deploy)

for file in ['build-engine.py','install-engine.py','capture.py','measure_listing.py','deploy-profile.py']:
    compile((p/file).read_text(),str(p/file),'exec')
print('Prepared gated build, same-volume deployment, mechanism capture and complete listing comparison.')
