package main

import (
	"encoding/json"
	"os"
	"strings"

	"github.com/google/pprof/profile"
)

func main() {
	out := make([]any, 0, len(os.Args)-1)
	for _, path := range os.Args[1:] {
		file, err := os.Open(path)
		if err != nil { panic(err) }
		p, err := profile.Parse(file)
		file.Close()
		if err != nil { panic(err) }
		valueIndex := -1
		for i, typ := range p.SampleType { if typ.Unit == "nanoseconds" { valueIndex = i } }
		if valueIndex < 0 { panic("profile has no nanosecond sample") }
		groups := map[string]int64{}
		total := int64(0)
		for _, sample := range p.Sample {
			value := sample.Value[valueIndex]
			total += value
			found := map[string]bool{}
			for _, location := range sample.Location {
				for _, line := range location.Line {
					if line.Function == nil { continue }
					name := line.Function.Name
					for group, match := range map[string]bool{
						"filesync_handler": strings.Contains(name, "engine/client.FilesyncSource.DiffCopy"),
						"grpc_http_adapter": strings.Contains(name, "google.golang.org/grpc.(*Server).ServeHTTP"),
						"xnet_http2_server": strings.Contains(name, "golang.org/x/net/http2.(*serverConn)."),
						"native_grpc_http2_server": strings.Contains(name, "google.golang.org/grpc/internal/transport.(*http2Server)."),
						"trace_extract": strings.Contains(name, "engine/client.extractTraceContext"),
						"import_opts": strings.Contains(name, "engine.LocalImportOptsFromContext"),
						"go_gc_mark": strings.Contains(name, "runtime.gcBgMarkWorker"),
					} { if match { found[group] = true } }
				}
			}
			for group := range found { groups[group] += value }
		}
		seconds := map[string]float64{}
		for group, value := range groups { seconds[group] = float64(value)/1e9 }
		out = append(out, map[string]any{"path":path, "sample_type":p.SampleType[valueIndex].Type, "total_seconds":float64(total)/1e9,"duration_seconds":float64(p.DurationNanos)/1e9,"overlapping_cumulative_groups":seconds})
	}
	if err := json.NewEncoder(os.Stdout).Encode(out); err != nil { panic(err) }
}
