from pathlib import Path
import json
import os
import subprocess
import time

p=Path(__file__).parent
out=p/'context-deadline-review'
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='local',GOMAXPROCS='8')
rows=[]
for label, overlay, expected, message in [
    ('before',p/'test-before-overlay.json',0,''),
    ('after',p/'test-after-overlay.json',0,''),
    ('missing-values',p/'missing-context-overlay.json',1,'lost root context'),
    ('missing-deadline',out/'missing-deadline-overlay.json',1,'lost root deadline'),
]:
    command=[go,'test','-p=2','-race','-count=1','-timeout=30s','-overlay='+str(overlay),'-run=^TestAttachablesTransportPreservesContextAndPeerClose$','./engine/client']
    start=time.monotonic()
    with (out/(label+'.log')).open('w') as log:
        result=subprocess.run(command,cwd='/tmp/dagger-filesync-literal-pathwalk',env=env,stdout=log,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,seconds=time.monotonic()-start,exit_code=result.returncode,expected_exit_code=expected)
    rows.append(row)
    (out/'validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==expected,(out/(label+'.log')).read_text()[-4000:]
    if message: assert message in (out/(label+'.log')).read_text()
