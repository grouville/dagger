from pathlib import Path
import hashlib
import io
import json
import tarfile

p=Path(__file__).parent
dest=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/native-grpc-attachables')
assert json.loads((p/'paired/summary.json').read_text())['all_commands_succeeded']
assert json.loads((p/'correctness-restoration.json').read_text())==dict(fixture_restored=True,completed=35,planned=35)
assert json.loads((p/'retained-restoration.json').read_text())['exit_code']==0
state=json.loads((p/'screen-final-state.json').read_text())
assert state['engine_sha256']=='4080ad95b40b58e334380119836d0ebffcea871c9d67d6786f7c425994d73c56'
assert not state['selected']
context_validation=json.loads((p/'context-deadline-review/validation.json').read_text())
assert len(context_validation)==4 and all(row['exit_code']==row['expected_exit_code'] for row in context_validation)
dest.mkdir(parents=True,exist_ok=True)
archive=dest/'evidence.tar.gz'
records=[]
with tarfile.open(archive,'w:gz',compresslevel=6) as out:
 for source in sorted(p.rglob('*')):
  if not source.is_file() or source.name=='dagger-after' or source.name=='cli-cpu.pprof.trace' or '__pycache__' in source.parts:
   continue
  if 'confirmation' in source.relative_to(p).parts:
   continue
  name=source.relative_to(p).as_posix()
  data=source.read_bytes()
  entry=tarfile.TarInfo(name);entry.mode=0o644;entry.mtime=0;entry.size=len(data)
  out.addfile(entry,io.BytesIO(data))
  records.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(archive,'r:gz') as inp:
 for record in records:
  data=inp.extractfile(record['path']).read()
  assert len(data)==record['size'] and hashlib.sha256(data).hexdigest()==record['sha256']
manifest=dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=records,
 engine_sha256=state['engine_sha256'],cli_sha256=dict(before=state['selected_cli_sha256'],after=state['candidate_cli_sha256']),
 scope='First four-pair screen, all correctness checks and diagnostic profiles. Opposite-order confirmation is prepared separately and excluded from this archive. No PR, standalone upstream branch or selection claimed.')
(dest/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(members=len(records),archive_bytes=archive.stat().st_size)))
