package client

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/dagger/dagger/engine"
	"github.com/dagger/dagger/internal/buildkit/session/filesync"
	fstypes "github.com/dagger/dagger/internal/fsutil/types"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/peer"
	"google.golang.org/grpc/status"
)

func attachablesTransportPeer(t testing.TB, ctx context.Context, attachables ...SessionAttachable) (*grpc.ClientConn, <-chan struct{}, context.CancelFunc) {
	t.Helper()
	// Use the real loopback transport for measurements, rather than net.Pipe's
	// synchronous writes. The session still owns exactly one connection.
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	t.Cleanup(func() { _ = ln.Close() })
	clientConn, err := net.Dial("tcp", ln.Addr().String())
	require.NoError(t, err)
	serverConn, err := ln.Accept()
	require.NoError(t, err)
	require.NoError(t, ln.Close())
	ctx, cancel := context.WithCancel(ctx)
	srv := NewSessionAttachablesServer(context.Background(), serverConn, attachables...)
	done := make(chan struct{})
	go func() { defer close(done); srv.Run(ctx) }()
	var mu sync.Mutex
	used := false
	cc, err := grpc.NewClient("passthrough:///attachables-transport",
		grpc.WithTransportCredentials(insecure.NewCredentials()),
		grpc.WithContextDialer(func(context.Context, string) (net.Conn, error) {
			mu.Lock()
			defer mu.Unlock()
			if used {
				return nil, errors.New("session connection already used")
			}
			used = true
			return clientConn, nil
		}))
	require.NoError(t, err)
	t.Cleanup(func() {
		cancel()
		_ = cc.Close()
		_ = clientConn.Close()
		select {
		case <-done:
		case <-time.After(2 * time.Second):
			t.Error("attachables server did not stop")
		}
	})
	return cc, done, cancel
}

type transportContextKey struct{}
type transportContextProbe struct {
	grpc_health_v1.UnimplementedHealthServer
	wantDeadline time.Time
}

func (p *transportContextProbe) Register(srv *grpc.Server) {
	grpc_health_v1.RegisterHealthServer(srv, p)
}
func (p *transportContextProbe) Check(ctx context.Context, _ *grpc_health_v1.HealthCheckRequest) (*grpc_health_v1.HealthCheckResponse, error) {
	if ctx.Value(transportContextKey{}) != "root" {
		return nil, status.Error(codes.Internal, "lost root context")
	}
	if _, ok := peer.FromContext(ctx); !ok {
		return nil, status.Error(codes.Internal, "lost peer context")
	}
	md, _ := metadata.FromIncomingContext(ctx)
	if len(md.Get("transport-test")) != 1 || md.Get("transport-test")[0] != "request" {
		return nil, status.Error(codes.Internal, "lost request metadata")
	}
	deadline, ok := ctx.Deadline()
	if !ok || !deadline.Equal(p.wantDeadline) {
		return nil, status.Error(codes.Internal, "lost root deadline")
	}
	return &grpc_health_v1.HealthCheckResponse{Status: grpc_health_v1.HealthCheckResponse_SERVING}, nil
}

func TestAttachablesTransportPreservesContextAndPeerClose(t *testing.T) {
	root, cancel := context.WithTimeout(context.WithValue(t.Context(), transportContextKey{}, "root"), 2*time.Second)
	defer cancel()
	deadline, _ := root.Deadline()
	// NewSessionAttachablesServer already registers health, so use a separate
	// service registration for the probe below.
	cc, done, _ := attachablesTransportPeer(t, root, transportProbeAttachable{probe: &transportContextProbe{wantDeadline: deadline}})
	ctx := metadata.NewOutgoingContext(context.Background(), metadata.Pairs("transport-test", "request"))
	ctx, cancelRPC := context.WithTimeout(ctx, 5*time.Second)
	defer cancelRPC()
	var response grpc_health_v1.HealthCheckResponse
	require.NoError(t, cc.Invoke(ctx, "/transport.Probe/Check", &grpc_health_v1.HealthCheckRequest{}, &response, grpc.WaitForReady(true)))
	require.Equal(t, grpc_health_v1.HealthCheckResponse_SERVING, response.Status)
	require.NoError(t, cc.Close())
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("peer close left the session server running")
	}
}

type transportProbeAttachable struct{ probe *transportContextProbe }

func (a transportProbeAttachable) Register(srv *grpc.Server) {
	srv.RegisterService(&grpc.ServiceDesc{
		ServiceName: "transport.Probe", HandlerType: (*grpc_health_v1.HealthServer)(nil),
		Methods: []grpc.MethodDesc{{MethodName: "Check", Handler: func(srv any, ctx context.Context, decode func(any) error, _ grpc.UnaryServerInterceptor) (any, error) {
			var req grpc_health_v1.HealthCheckRequest
			if err := decode(&req); err != nil {
				return nil, err
			}
			return srv.(*transportContextProbe).Check(ctx, &req)
		}}},
	}, a.probe)
}

func transportRequest(ctx context.Context, cc *grpc.ClientConn, opts engine.LocalImportOpts, out any) error {
	ctx, cancel := context.WithCancel(opts.AppendToOutgoingContext(ctx))
	defer cancel()
	stream, err := filesync.NewFileSyncClient(cc).DiffCopy(ctx)
	if err != nil {
		return err
	}
	defer stream.CloseSend()
	return stream.RecvMsg(out)
}

func TestAttachablesTransportKeepsFileReadsFresh(t *testing.T) {
	root := t.TempDir()
	file := filepath.Join(root, "dagger.toml")
	require.NoError(t, os.WriteFile(file, []byte("old"), 0o600))
	cc, _, _ := attachablesTransportPeer(t, t.Context(), FilesyncSource{})
	ctx, cancel := context.WithTimeout(t.Context(), 3*time.Second)
	defer cancel()
	read := func() string {
		var out filesync.BytesMessage
		require.NoError(t, transportRequest(ctx, cc, engine.LocalImportOpts{Path: file, ReadSingleFileOnly: true, MaxFileSize: 1 << 20}, &out))
		return string(out.Data)
	}
	require.Equal(t, "old", read())
	require.NoError(t, os.WriteFile(file, []byte("new"), 0o600))
	require.Equal(t, "new", read())
	var stat fstypes.Stat
	err := transportRequest(ctx, cc, engine.LocalImportOpts{Path: filepath.Join(root, "missing"), StatPathOnly: true}, &stat)
	require.Equal(t, codes.NotFound, status.Code(err))
	var out filesync.BytesMessage
	err = transportRequest(ctx, cc, engine.LocalImportOpts{Path: file, ReadSingleFileOnly: true, MaxFileSize: 1}, &out)
	require.ErrorContains(t, err, "file contents too large")
	// Exercise flow control with a response larger than an initial HTTP/2 window.
	data := bytes.Repeat([]byte("x"), 1<<20)
	require.NoError(t, os.WriteFile(file, data, 0o600))
	require.NoError(t, transportRequest(ctx, cc, engine.LocalImportOpts{Path: file, ReadSingleFileOnly: true, MaxFileSize: 2 << 20}, &out))
	require.Equal(t, data, out.Data)
}

func TestAttachablesTransportCancelsOneStream(t *testing.T) {
	cc, _, _ := attachablesTransportPeer(t, t.Context())
	health := grpc_health_v1.NewHealthClient(cc)
	ctx, cancel := context.WithTimeout(t.Context(), 2*time.Second)
	defer cancel()
	watchCtx, cancelWatch := context.WithCancel(ctx)
	watch, err := health.Watch(watchCtx, &grpc_health_v1.HealthCheckRequest{}, grpc.WaitForReady(true))
	require.NoError(t, err)
	_, err = watch.Recv()
	require.NoError(t, err)
	cancelWatch()
	_, err = watch.Recv()
	require.Equal(t, codes.Canceled, status.Code(err))
	_, err = health.Check(ctx, &grpc_health_v1.HealthCheckRequest{})
	require.NoError(t, err)
}

func BenchmarkAttachablesTransportStatRead(b *testing.B) {
	file := filepath.Join(b.TempDir(), "dagger.toml")
	require.NoError(b, os.WriteFile(file, bytes.Repeat([]byte("x"), 1649), 0o600))
	cc, _, _ := attachablesTransportPeer(b, b.Context(), FilesyncSource{})
	ctx, cancel := context.WithTimeout(b.Context(), time.Minute)
	defer cancel()
	health := grpc_health_v1.NewHealthClient(cc)
	_, err := health.Check(ctx, &grpc_health_v1.HealthCheckRequest{}, grpc.WaitForReady(true))
	require.NoError(b, err)
	for _, workers := range []int{1, 16} {
		b.Run(fmt.Sprintf("parallelism=%d", workers), func(b *testing.B) {
			b.SetParallelism(workers)
			b.ReportAllocs()
			b.RunParallel(func(pb *testing.PB) {
				for pb.Next() {
					var stat fstypes.Stat
					if err := transportRequest(ctx, cc, engine.LocalImportOpts{Path: file, StatPathOnly: true}, &stat); err != nil {
						b.Error(err)
						return
					}
					var out filesync.BytesMessage
					if err := transportRequest(ctx, cc, engine.LocalImportOpts{Path: file, ReadSingleFileOnly: true, MaxFileSize: 1 << 20}, &out); err != nil {
						b.Error(err)
						return
					}
					if len(out.Data) != 1649 {
						b.Error(io.ErrUnexpectedEOF)
						return
					}
				}
			})
		})
	}
}
