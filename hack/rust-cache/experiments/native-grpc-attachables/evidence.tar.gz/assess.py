from pathlib import Path
import json
import statistics

p=Path(__file__).parent
rows=json.loads((p/'paired/samples.json').read_text())
summary=json.loads((p/'paired/summary.json').read_text())
assert summary['pairs']==4 and summary['all_commands_succeeded'] and summary['same_rows']
measured=[row for row in rows if row['pair']>0]
pairs=[]
for number in range(1,5):
    pair={row['arm']:row for row in measured if row['pair']==number}
    before,after=pair['before'],pair['after']
    pairs.append(dict(pair=number,before_seconds=before['seconds'],after_seconds=after['seconds'],
        saving_seconds=before['seconds']-after['seconds'],
        class_slots={arm:[pair[arm]['gc_before']['metadata_estimate']['ClassSlotCount'],pair[arm]['gc_after']['metadata_estimate']['ClassSlotCount']] for arm in pair},
        host_io_pressure={arm:pair[arm]['pressure']['host.io.some'] for arm in pair}))
result=dict(scope='Four fixed pairs, warm engine, fresh CLI and source edit. Exact ordered rows, ordinary GC/maintenance, telemetry and cleanup remain. First long control overlaps a large class-slot reduction and cannot be assigned entirely to transport. Every observation remains. Confirmation is pending.',
    pairs=pairs,medians=dict(seconds=summary['median_seconds_all_attempts'],
        cli_cpu={arm:statistics.median(row['cli_resources']['user_seconds']+row['cli_resources']['system_seconds'] for row in measured if row['arm']==arm) for arm in ['before','after']},
        engine_cpu=summary['median_engine_cpu'],allocated_bytes=summary['median_allocated_bytes']),
    median_paired_saving_seconds=statistics.median(pair['saving_seconds'] for pair in pairs),
    selected=False,confirmation_required=True,engine_replaced=False,pr_opened=False)
(p/'assessment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
