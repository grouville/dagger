from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess

p=Path(__file__).parent
cap=p/'capture'
old=Path('/tmp/rust-cache-sipsma-review/go-listing-cli-cpu/capture')
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='local',GOMAXPROCS='8')
raw=cap/'cli-cpu.pprof.trace'
compressed=cap/'cli-cpu.pprof.trace.gz'
if not raw.exists():
    raw.write_bytes(gzip.decompress(compressed.read_bytes()))
for kind in ['sched','sync']:
    with (cap/(kind+'.pprof')).open('wb') as out,(cap/(kind+'-trace.log')).open('w') as err:
        result=subprocess.run([go,'tool','trace','-pprof='+kind,str(raw)],env=env,stdout=out,stderr=err)
    assert result.returncode==0
    with (cap/(kind+'-top.log')).open('w') as out:
        subprocess.run([go,'tool','pprof','-top','-cum','-nodecount=30',str(cap/(kind+'.pprof'))],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
with (cap/'cpu-cumulative.log').open('w') as out:
    subprocess.run([go,'tool','pprof','-top','-cum','-nodecount=50',str(p/'dagger-after'),str(cap/'cli-cpu.pprof')],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
profiles=[str(old/'cli-cpu.pprof'),str(cap/'cli-cpu.pprof'),str(p/'sched.pprof'),str(cap/'sched.pprof'),str(p/'sync.pprof'),str(cap/'sync.pprof')]
with (p/'profile-stats.json').open('w') as out,(p/'profile-stats-build.log').open('w') as err:
    result=subprocess.run([go,'run',str(p/'profile_stats.go'),*profiles],cwd='/tmp/dagger-filesync-literal-pathwalk',env=env,stdout=out,stderr=err)
assert result.returncode==0
compressed.write_bytes(gzip.compress(raw.read_bytes(),compresslevel=6,mtime=0))
assert hashlib.sha256(gzip.decompress(compressed.read_bytes())).digest()==hashlib.sha256(raw.read_bytes()).digest()
(cap/'trace-archive.json').write_text(json.dumps(dict(raw_bytes=raw.stat().st_size,raw_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),gzip_bytes=compressed.stat().st_size),indent=2)+'\n')
