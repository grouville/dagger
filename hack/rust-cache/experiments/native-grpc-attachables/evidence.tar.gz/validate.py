from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
root = '/tmp/dagger-filesync-literal-pathwalk'
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1', _EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
steps = [
    ('before-race', ['test', '-p=2', '-count=1', '-race', '-timeout=120s', '-overlay='+str(p/'test-before-overlay.json'), '-run=^Test(SessionAttachables|AttachablesTransport)', './engine/client'], 0),
    ('after-race', ['test', '-p=2', '-count=1', '-race', '-timeout=120s', '-overlay='+str(p/'test-after-overlay.json'), '-run=^Test(SessionAttachables|AttachablesTransport)', './engine/client'], 0),
    ('missing-context-control', ['test', '-p=2', '-count=1', '-race', '-timeout=120s', '-overlay='+str(p/'missing-context-overlay.json'), '-run=^TestAttachablesTransportPreservesContextAndPeerClose$', './engine/client'], 1),
]
rows=[]
def run(label, args, expected=0):
    command=[go,*args]
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,exit_code=result.returncode,expected_exit_code=expected,seconds=time.monotonic()-start)
    rows.append(row)
    (p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==expected,(p/(label+'.log')).read_text()[-5000:]
    if label=='missing-context-control':
        assert 'lost root context' in (p/(label+'.log')).read_text()

for label, args, expected in steps:
    if label == "before-race":
        rows.append(json.loads((p/"initial-overlay-build-failure/validation.json").read_text())[0])
        continue
    run(label,args,expected)
for pair in range(4):
    for arm in (['before','after'] if pair%2==0 else ['after','before']):
        run(f'component-{pair+1}-{arm}', ['test','-p=2','-run=^$','-overlay='+str(p/('test-'+arm+'-overlay.json')),'-bench=^BenchmarkAttachablesTransportStatRead$','-benchtime=500ms','-count=1','./engine/client'])
run('cli-build', ['build','-p=2','-buildvcs=false','-overlay='+str(p/'cli-after-overlay.json'),'-o',str(p/'dagger-after'),'./cmd/dagger'])
(p/'candidate-build.json').write_text(json.dumps(dict(sha256=hashlib.sha256((p/'dagger-after').read_bytes()).hexdigest(),base_cli_sha256=hashlib.sha256(Path('/tmp/rust-cache-sipsma-review/filesync-literal-pathwalk/dagger-after').read_bytes()).hexdigest()),indent=2)+'\n')
