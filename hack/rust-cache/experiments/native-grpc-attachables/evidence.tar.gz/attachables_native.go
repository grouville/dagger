package client

import (
	"context"
	"net"
	"sync"

	"google.golang.org/grpc/stats"
)

// A session has one already-upgraded connection. Keep Accept blocked until
// that connection closes so Serve has the same lifetime as ServeConn.
type attachablesListener struct {
	conn     net.Conn
	accepted bool
	done     chan struct{}
	once     sync.Once
}

func newAttachablesListener(conn net.Conn) *attachablesListener {
	return &attachablesListener{conn: conn, done: make(chan struct{})}
}

func (l *attachablesListener) Accept() (net.Conn, error) {
	if !l.accepted {
		l.accepted = true
		return &attachablesConn{Conn: l.conn, listener: l}, nil
	}
	<-l.done
	return nil, net.ErrClosed
}

func (l *attachablesListener) Close() error {
	l.once.Do(func() { close(l.done) })
	return l.conn.Close()
}

func (l *attachablesListener) Addr() net.Addr { return l.conn.LocalAddr() }

type attachablesConn struct {
	net.Conn
	listener *attachablesListener
}

func (c *attachablesConn) Close() error { return c.listener.Close() }

// Native gRPC starts connection contexts from Background. Preserve the Run
// context previously supplied through http2.ServeConnOpts, while retaining
// gRPC's connection and peer values. Each RPC still owns its cancellation.
type attachablesContext struct{ root context.Context }

func (h *attachablesContext) TagConn(ctx context.Context, _ *stats.ConnTagInfo) context.Context {
	return attachablesBaseContext{Context: h.root, values: ctx}
}

func (*attachablesContext) HandleConn(context.Context, stats.ConnStats) {}
func (*attachablesContext) TagRPC(ctx context.Context, _ *stats.RPCTagInfo) context.Context {
	return ctx
}
func (*attachablesContext) HandleRPC(context.Context, stats.RPCStats) {}

type attachablesBaseContext struct {
	context.Context
	values context.Context
}

func (ctx attachablesBaseContext) Value(key any) any {
	if value := ctx.values.Value(key); value != nil {
		return value
	}
	return ctx.Context.Value(key)
}
