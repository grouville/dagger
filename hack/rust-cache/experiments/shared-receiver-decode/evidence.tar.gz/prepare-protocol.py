from pathlib import Path
import json
p=Path(__file__).parent;old=p.parent/'native-collection-items'
plan=json.loads((old/'engine-plan.json').read_text())
plan={k:plan[k] for k in ['image','command','cli_sha256','flags']}
plan.update(new_engine='dagger-collection-receiver-decode-oct18',ports=dict(runner=16280,debug=16108),module_commit='a3d0e4bf562b834c31135bff24e5931fd32b3acc',scenario='Unchanged function-getter Go module, shared JSON decoder disabled versus enabled on one isolated engine; independent cache initialized before measured edits.')
plan['flags']['shared-receiver-decode']=False
(p/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for workload in ['test','source']:
 s=(old/f'measure-{workload}-edits.py').read_text()
 s=s.replace('dagger-collection-native-items-oct18','dagger-collection-receiver-decode-oct18').replace(':16107',':16108').replace(':16279',':16280')
 s=s.replace("'combined':Path('/tmp/dagger-go-native-collection-items')","'combined':Path('/tmp/dagger-go-snapshot-test-directories')")
 s=s.replace("'shared-function-metadata']","'shared-function-metadata','shared-receiver-decode']")
 s=s.replace("assert engine_sha==next(r['sha256'] for r in json.loads(Path('/tmp/rust-cache-sipsma-review/native-collection-items/engine-build-steps.json').read_text()) if r['label']=='engine-build')","assert engine_sha==json.loads(Path('/tmp/rust-cache-sipsma-review/dang-shared-receiver-decode/engine-build.json').read_text())['sha256']")
 start=s.index("scope='Complete CLI comparison")
 end=s.index("',orders=orders",start)
 s=s[:start]+"scope='Complete CLI comparison of identical function-getter module sources and engine binary. Only shared JSON receiver decoding changes. Actual getters, class initialization, per-key caching, nested-client setup and telemetry remain. Both arms complete initial test addition/removal before measured pairs; fresh CLI and ordinary-source edit every command, also a fresh test-file comment in the test-edit cohort. All retained engines and cache volumes stay untouched."+s[end:]
 s=s.replace("mode('shared-function-metadata',False)","mode('shared-function-metadata',False)\n            mode('shared-receiver-decode',arm=='combined')")
 s=s.replace("gc_before=get('snapshot-collection');tick=time.monotonic()","gc_before=get('snapshot-collection');decode_before=get('shared-receiver-decode');tick=time.monotonic()")
 s=s.replace("native_stored_items=arm=='combined'","native_stored_items=False,shared_receiver_decode=arm=='combined',receiver_decode_before=decode_before,receiver_decode_after=get('shared-receiver-decode')")
 (p/f'measure-{workload}-edits.py').write_text(s)
s=(old/'capture.py').read_text().replace('dagger-collection-native-items-oct18','dagger-collection-receiver-decode-oct18').replace(':16107',':16108').replace(':16279',':16280')
s=s.replace("'candidate':Path('/tmp/dagger-go-native-collection-items')","'candidate':Path('/tmp/dagger-go-snapshot-test-directories')")
s=s.replace("'shared-function-metadata']","'shared-function-metadata','shared-receiver-decode']")
s=s.replace("mode('shared-function-metadata',False)","mode('shared-function-metadata',False)\n    mode('shared-receiver-decode',options.arm=='candidate')")
(p/'capture.py').write_text(s)
(p/'analyze.py').write_bytes((old/'analyze.py').read_bytes())
