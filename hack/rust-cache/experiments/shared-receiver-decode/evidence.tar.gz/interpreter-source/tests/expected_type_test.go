package tests

import (
	"context"

	"github.com/Khan/genqlient/graphql"
	"github.com/dagger/testctx"
	"github.com/stretchr/testify/require"
	"github.com/vito/dang/v2/pkg/dang"
	"github.com/vito/dang/v2/pkg/ioctx"
	"github.com/vito/dang/v2/tests/gqlserver"
)

func (DangSuite) TestExpectedTypeDirectivesFromIntrospection(ctx context.Context, t *testctx.T) {
	// Use a client-only import instead of tests/dang.toml's SDL-backed import so
	// Dang has to introspect the live server. This exercises the test server's
	// extended introspection path for applied directives such as @expectedType.
	testGraphQLServer, err := gqlserver.StartServer()
	require.NoError(t, err)
	t.Cleanup(func() { _ = testGraphQLServer.Stop() })

	client := graphql.NewClient(testGraphQLServer.QueryURL(), nil)
	ctx = ioctx.StdoutToContext(ctx, NewTWriter(t))
	ctx = dang.ContextWithImportConfigs(ctx, dang.ImportConfig{
		Name:   "Test",
		Client: client,
		// The test server implements Dagger's extended introspection, which
		// exposes applied directives such as @expectedType.
		Dagger: true,
	})

	require.NoError(t, dang.RunFile(ctx, "test_expected_type.dang", false))
}
