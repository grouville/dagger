# Standard Library: Strings, Collections, JSON/YAML, Builtins

The built-in surface of Dang itself (everything here is available without any
`import`). Most functionality lives as **methods** on values — `"hi".toUpper`,
`users.length`, `"a,b".split(",")` — rather than global functions.

## Top-level functions
- `assert { Boolean! } -> Null` — runs the block; raises an `AssertionError` if not truthy. Block, not parens: `assert { x == 1 }`. The failure message includes the source expression and sub-values.
- `assert(message: String! = null) { Boolean! } -> Null` — optional named `message`.
- `loop { ... } -> r` — Dang's only loop: calls the block repeatedly forever; exit via `break` (the loop yields the break value, non-null if the break value is), `return`, or `raise`. See control-flow.md.
- `Path(path: String!) -> Path!` — constructs a normalized Path from any String expression (see the [`Path!` scalar](#path-scalar) below).
- `print(value: a) -> Null` — write a value to stdout (newline-terminated).
- `toString(value: a) -> String!` — pass strings, enum values, and custom scalar values (Path, Regexp, URL, ...) through as their bare string; JSON-encode everything else.

`print` and `assert` return `null` — there is no `Void` type.

JSON/YAML/TOML conversions are **not** top-level functions — they live in the `JSON`/`YAML`/`TOML` codec namespaces (`.encode` / `.decode`; see [JSON, YAML, and TOML](#json-yaml-and-toml) below). base64 lives on `String!` (`.toBase64` / `.fromBase64`).

## `String!` methods

Strings have **no** `.length` / `.isEmpty` — those are list-only. Use the predicates below.

- `.toUpper -> String!`, `.toLower -> String!`
- `.toBase64 -> String!` — standard padded base64 of the string's bytes; `.fromBase64 -> String!` — decode standard padded base64 (raises on invalid input)
- `.contains(substring: String!) -> Boolean!`
- `.hasPrefix(prefix: String!) -> Boolean!`, `.hasSuffix(suffix: String!) -> Boolean!`
- `.trim(cutset: String!)`, `.trimLeft(cutset)`, `.trimRight(cutset)`, `.trimSpace`
- `.trimPrefix(prefix)`, `.trimSuffix(suffix)`
- `.padLeft(width: Int!)`, `.padRight(width)`, `.center(width)` — space-padded; no-op if already ≥ width
- `.split(separator: String!, limit: Int = 0) -> [String!]!` — empty separator splits into characters; `limit` caps parts (last keeps remainder)
- `.replace(old: String!, new: String!, count: Int = -1) -> String!` — `count = -1` replaces all; empty `old` inserts between characters

Conversion: `toString(value)` (JSON-encodes non-strings) or `value :: String!` (explicit cast where types align).

### `String!` regex methods
Backtick templates auto-coerce to the `Regexp` scalar, so a pattern is usually `` `\d+` ``. Go `regexp/syntax` (RE2); named groups use `(?P<name>...)`.

- `.containsMatch(pattern: Regexp!) -> Boolean!`
- `.match(pattern: Regexp!) -> Match` — first match, or null
- `.matchAll(pattern: Regexp!) -> [Match!]!`
- `.replaceMatches(pattern: Regexp!, with: String!, count: Int = -1) -> String!` — `$0`/`$1`/`$name`/`${name}` backref expansion
- `.rewriteMatches(pattern: Regexp!, count: Int = -1) { match => String! } -> String!`
- `.splitMatches(pattern: Regexp!, limit: Int = 0) -> [String!]!`

```dang
"call 555-1212".containsMatch(`\d+`)
"a1 b22".matchAll(`\d+`)
"555-1212".replaceMatches(`(?P<area>\d{3})-(?P<num>\d{4})`, with: "$area.$num")   # "555.1212"
"hello world".rewriteMatches(`\w+`) { m => m.string.toUpper }                     # "HELLO WORLD"
```

### `Match` object
- `.string -> String!` — whole matched substring
- `.start -> Int!`, `.end -> Int!` — byte offsets
- `.captures -> [String!]!` — positional groups (`captures[0]` is `$1`); unmatched optional groups surface as `""`
- `.named -> Map[String]!` — named groups by name (`m.named["area"]`); a key reads as null if that group didn't match, and is absent for an unknown name

## `Path!` scalar and methods {#path-scalar}

`Path` is a slash-separated path **scalar, normalized on construction**: every
way a Path comes to exist runs `path.Clean`-style normalization, so an
un-clean Path cannot exist (there is no `.clean`) and equality is semantic —
`Path("a//b/./c") == Path("a/b/c")`, and `Path("a//b") == "a/b"` (custom
scalars compare with plain strings by their underlying string). Path is
defined in Dang itself (the interpreter's embedded prelude,
`pkg/dang/prelude/path.dang`) using the scalar-body syntax — see types.md.

Ways in: the `Path(s)` constructor (any String expression); a string
*literal*/template in a `Path!`-typed slot (`let p: Path! = "src"`,
`build(src: Path! = "src")`, case-clause values); an explicit `s :: Path!`
cast; `JSON`/`YAML`/`TOML.decode` into a `Path!`-typed field. Way out: a Path
**degrades to `String!` automatically at value-handoff boundaries** (see
types.md, Coercion rules), plus `.string` for an explicit exit; interpolation
and `toString` yield the bare path string.

- `.name -> String!` — last element (`Path("/").name` is `"/"`, `Path(".").name` is `"."`)
- `.stem -> String!` — `name` minus extension
- `.extension -> String` — after the last dot in `name`, dot excluded; **null** when none; a leading dot alone (`.bashrc`) is not an extension
- `.parent -> Path!` — parent of `/` is `/`; of a bare name is `.`
- `.parts -> [String!]!` — segments, root excluded; `.` has no segments
- `.isAbsolute -> Boolean!`
- `.join(other: Path!) -> Path!` — lexical concat + normalize; chain for multiple; literals coerce (`p.join("bin")`)
- `.relativeTo(base: Path!) -> Path` — **null** when not expressible (mixed abs/rel, or base escaping via `..`)
- `.contains(other: Path!) -> Boolean!` — inclusive lexical containment; mixed abs/rel is never containment
- `.matches(pattern: String!) -> Boolean!` — shell glob; raises on invalid pattern
- `.string -> String!` — the normalized string

A String *variable* does not auto-coerce into a `Path!` slot (the literal-only
rule applies to every scalar) — wrap it: `Path(dir)`. There is no `+` on
Paths; use `.join` or interpolation.

## `[T]!` methods (lists)

Lists are the **only collection type today** (no maps/sets). Block params shown as `x`/`i`.

### Construction / access
- literal `[1, 2, 3]`; empty needs a type hint `[] :: [Int!]!` or annotation `let xs: [Int!]! = []`
- concatenation `[1, 2] + [3, 4]`
- `xs[0]` — element access; **out-of-bounds yields `null`** (result is `T`, not `T!`); chained `matrix[0][1]`
- `.length -> Int!`, `.isEmpty -> Boolean!`

### Transform / select / aggregate
- `.map { x, i => ... } -> [U]!`
- `.filter { x => Boolean! } -> [T]!`, `.reject { x => Boolean! } -> [T]!`
- `.reduce(initial: U) { acc, x => ... } -> U` — `initial` positional or named `initial:`
- `.uniq -> [T]!` — drop duplicates, keep first-occurrence order; uses Dang equality (works on nested lists)
- `.each { x, i => ... } -> [T]!` — returns the original list (for chaining / side effects)
- `.any { x => Boolean! } -> Boolean!`, `.all { x => Boolean! } -> Boolean!`
- `.contains(element: T) -> Boolean!`

### Slice
- `.takeFirst(count: Int = 1)`, `.takeLast(count: Int = 1)`, `.dropFirst(count: Int = 1)`, `.dropLast(count: Int = 1)`
- `.takeWhile { x => Boolean! }`, `.dropWhile { x => Boolean! }`

### Join
- `.join(separator: String!) -> String!` — works on any list; non-string elements are JSON-encoded

### Nullable lists vs. lists of nullables
- `[T]` — list might be null; `[T]!` — non-null list, elements might be null; `[T!]!` — both non-null.
- List methods work on `[T]` (nullable) receivers; null propagates: `nullList.map { ... } == null`, `nullList.length == null`.

### Heterogeneous element inference
- `[Cat, Dog]` where both implement `Animal` → `[Animal!]` (common supertype/interface; first common one found).
- Mixing `null` widens elements to nullable.

## JSON, YAML, and TOML

Each format is a codec namespace — `JSON`, `YAML`, `TOML` — with static `encode` / `decode` methods. The names double as scalar types (`:: JSON`) and are owned by Dang, so they work with **no `import`**; an in-scope scalar of the same name (e.g. Dagger's `scalar JSON`) merges with the codec rather than colliding.

Parsing is **type-driven** — `JSON.decode` / `YAML.decode` / `TOML.decode` produce values of the *expected* type, which comes from a `::` cast, an annotation, or the parameter/return type at the call site:
```dang
let summary: Summary! = JSON.decode("""{"name": "test", "count": 42}""")
let status: Status! = JSON.decode("\"PASSED\"")
let s = JSON.decode(...) :: Status!
f(d: String!): Summary! { JSON.decode(d) }
let cfg: Settings! = TOML.decode("count = 1")   # TOML's top level is always a table
```
- Works for primitives, lists, records, custom types, enums.
- Unknown/extra fields in the input are ignored, not errors. `decode` rejects trailing data after the first value.
- Empty input differs by format: `JSON.decode("")` errors (invalid JSON); `YAML.decode("")` is `null` (an empty YAML document), so it won't materialize into a non-null record; `TOML.decode("")` is an empty table, so it fills declared defaults.

### Coercion during parsing
- Enum values decode from their string names (`"PASSED"` → `Status.PASSED`).
- Custom scalars decode from their string forms.
- Record/object fields fall back to declared defaults when absent; nullable fields absent from input decode to `null`.

### Serialization
- `JSON.encode(value) -> String!`, `YAML.encode(value)`, `TOML.encode(value)` — object/record keys emitted in **alphabetical** order. `TOML.encode` requires a table (record) at the top level and drops null fields (TOML has no null); JSON/YAML keep them.
- `toString(value)` — pass-through for strings, JSON-encode otherwise.

### Errors (all recoverable with `rescue`)
- invalid input → `<Format>.decode: invalid <Format>: ...` (e.g. `JSON.decode: invalid JSON: ...`, `YAML.decode: invalid YAML: ...`)
- missing required field → `<path>: missing required field`
- wrong type for field → raises
- invalid enum value → `<path>: invalid enum value "X" for <Enum>`

## `Random` module
- `Random.int(min: Int!, max: Int!) -> Int!` — `min` inclusive, `max` exclusive (errors if `min >= max`)
- `Random.float -> Float!` — `[0.0, 1.0)`
- `Random.string -> String!` — cryptographically random base32, ≥128 bits entropy

## `UUID` module
- `UUID.v4 -> String!` — random UUID v4
- `UUID.v7 -> String!` — time-ordered UUID v7

## Error types
- `Error` — interface with `message: String!`
- `BasicError` — concrete type behind `raise "msg"`, and nothing else; implements `Error`
- `AssertionError` — a failed `assert` block (`message` carries the offending expression and sub-values)
- `RuntimeError` — interpreter faults: division by zero, failed non-null assertions/casts, invalid enum values
- `GraphQLError` — a GraphQL response reporting errors; adds `path: [String!]!` (failing field) and `extensions: String!` (extensions object as JSON text, `"{}"` when absent)
