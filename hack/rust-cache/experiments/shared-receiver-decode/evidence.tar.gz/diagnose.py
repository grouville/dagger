from pathlib import Path
import subprocess,sys,json,time
p=Path(__file__).parent;rows=[]
for script in ['profile.py','verify-module.py']:
 tick=time.monotonic();command=[sys.executable,str(p/script)]
 result=subprocess.run(command)
 row=dict(script=script,seconds=time.monotonic()-tick,exit_code=result.returncode);rows.append(row);(p/'diagnostic-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
