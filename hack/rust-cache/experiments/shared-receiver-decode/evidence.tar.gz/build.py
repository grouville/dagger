from pathlib import Path
import subprocess,os,time,json,hashlib
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
subprocess.run(['python3',str(p/'validate.py')],check=True)
env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',DANG_BENCH_COERCED_METHOD_HOISTING='true',DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT='true',DANG_BENCH_SHARED_FUNCTION_METADATA='false')
command=[go,'build','-p=2','-buildvcs=false','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod','-overlay='+str(p/'overlay.json'),'-o',str(p/'dagger-engine'),'./cmd/engine']
tick=time.monotonic()
with (p/'engine-build.log').open('w') as out:
 result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=subprocess.STDOUT)
row=dict(command=command,seconds=time.monotonic()-tick,exit_code=result.returncode)
if not result.returncode:row['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
(p/'engine-build.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
if result.returncode:print((p/'engine-build.log').read_text()[-3500:]);raise SystemExit(result.returncode)
