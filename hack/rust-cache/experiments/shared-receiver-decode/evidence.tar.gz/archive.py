from pathlib import Path
import json,hashlib,shutil,subprocess,difflib,tarfile,io,gzip,time
p=Path(__file__).parent;root=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/shared-receiver-decode');root.mkdir()
overlay=json.loads((p/'overlay.json').read_text());sources=p/'engine-source';sources.mkdir()
source_map={}
for index,(original,replacement) in enumerate(sorted(overlay['Replace'].items())):
 src=Path(replacement)
 if not src.exists():continue
 target=sources/(f'{index:03d}-'+src.name);shutil.copy2(src,target)
 source_map[original]=str(target.relative_to(p))
(sources/'replacement-map.json').write_text(json.dumps(source_map,indent=2)+'\n')
for name in ['engine.go.mod','engine.go.sum']:
 shutil.copy2(p.parent/'log-flush-buffer'/name,sources/name)
shutil.copytree(p.parent/'dang-module-blueprint-content-key',p/'interpreter-source',ignore=shutil.ignore_patterns('__pycache__','.git'))
with (p/'module-source.tar').open('wb') as out:
 subprocess.run(['git','archive','--format=tar','HEAD'],cwd='/tmp/dagger-go-snapshot-test-directories',stdout=out,check=True)
patch=[]
for original,before,after in [
 ('core/sdk/dang/v2/helpers.go',p/'before-helpers.go',p/'helpers.go'),
 ('core/sdk/dang/v2/shared_receiver_decode.go',None,p/'shared_receiver_decode.go'),
 ('core/sdk/dang/v2/shared_receiver_decode_test.go',None,p/'shared_receiver_decode_test.go'),
 ('cmd/engine/debug.go',p.parent/'dang-shared-function-metadata/engine-debug.go',p/'engine-debug.go')]:
 patch.extend(difflib.unified_diff(before.read_text().splitlines(keepends=True) if before else [],after.read_text().splitlines(keepends=True),fromfile='a/'+original if before else '/dev/null',tofile='b/'+original))
(p/'engine-prototype.patch').write_text(''.join(patch));shutil.copy2(p/'engine-prototype.patch',root/'engine-prototype.patch')
streams={}
for arm in ['before','candidate']:
 capture=p/('capture-'+arm);events=[]
 for f in sorted(capture.glob('chunk-*.ndjson.gz')):
  lines=gzip.decompress(f.read_bytes()).splitlines();header=json.loads(lines[0]);assert header['dropped_events']==0;events.extend(lines[1:])
 assert not header.get('open_ops')
 combined=dict(header,event_count=len(events));reconstructed=(json.dumps(combined)+'\n').encode()+b'\n'.join(events)+b'\n'
 original=(capture/'wcprof-complete.ndjson').read_bytes();assert reconstructed==original
 streams[arm]=dict(bytes=len(original),sha256=hashlib.sha256(original).hexdigest(),events=len(events),lossless=True)
files=[f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name not in ['dagger-engine','wcprof-complete.ndjson','evidence.tar.gz']]
manifest=dict(status='unselected; diagnostic flag disabled',scope='Unchanged function-getter Go module; shared JSON data only; fresh invocation objects and normal getter execution. Prototype patch applies to the inherited experimental overlay, not standalone upstream main.',module_commit='a3d0e4bf562b834c31135bff24e5931fd32b3acc',engine=json.loads((p/'engine-build.json').read_text()),source_identity=json.loads((p/'source-identity.json').read_text()),wcprof_streams=streams,initial_component_note='Initial component logs precede the final cache-lookup refinement; final figures use the top-level scaling logs and current sources.',files={str(f.relative_to(p)):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(files)})
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copy2(p/'assessment.json',root/'summary.json')
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();tick=time.monotonic()
with (root/'evidence.tar.gz').open('wb') as output:
 with gzip.GzipFile(filename='',mode='wb',fileobj=output,compresslevel=6,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|') as archive:
   for f in sorted(files):
    info=archive.gettarinfo(str(f),arcname=str(f.relative_to(p)));info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
    with f.open('rb') as data:archive.addfile(info,data)
   info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mtime=0;archive.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(root/'evidence.tar.gz','r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(files)+1
 for member in members:
  data=archive.extractfile(member).read()
  if member.name=='manifest.json':assert data==manifest_bytes
  else:assert hashlib.sha256(data).hexdigest()==manifest['files'][member.name]['sha256']
artifact=root/'evidence.tar.gz';record=dict(bytes=artifact.stat().st_size,sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),members=len(files)+1,all_member_hashes_verified=True,wcprof_streams_reconstructed=True,archive_seconds=time.monotonic()-tick)
(root/'archive.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
