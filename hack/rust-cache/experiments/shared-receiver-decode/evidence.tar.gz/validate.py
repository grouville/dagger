from pathlib import Path
import subprocess,os,time,json
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
common=[go,'test','-p=2','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod','-overlay='+str(p/'overlay.json')]
env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',DANG_BENCH_COERCED_METHOD_HOISTING='true',DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT='true',DANG_BENCH_SHARED_FUNCTION_METADATA='false')
rows=[]
steps=[('sdk-race',common+['-count=1','-race','-timeout=120s','./core/sdk/dang/v2'],False)]
for arm in ['before','after']:
 steps.append((arm+'-scaling',common+['-run=^$','-bench=^BenchmarkSharedReceiverDecode$','-benchtime=1x','-count=4','-timeout=120s','./core/sdk/dang/v2'],arm=='after'))
for label,command,enabled in steps:
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as output:
  result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=dict(env,DAGGER_BENCH_SHARED_RECEIVER_DECODE=str(enabled).lower()),stdout=output,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,enabled=enabled,seconds=time.monotonic()-tick,exit_code=result.returncode)
 rows.append(row);(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:
  print((p/(label+'.log')).read_text()[-3500:]);raise SystemExit(result.returncode)
