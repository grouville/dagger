from pathlib import Path
import json,subprocess,urllib.request,hashlib
p=Path(__file__).parent;activation=json.loads((p/'activation.json').read_text())
def get(route):
 with urllib.request.urlopen('http://127.0.0.1:16108/debug/'+route,timeout=10) as f:return json.load(f)
assert not get('shared-receiver-decode')['enabled']
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
lifecycle=get('client-lifecycle');assert lifecycle['active_requests']==0 and not lifecycle.get('sessions')
retained={}
for name,expected in {activation['engine']:activation['sha256'],**activation['retained_engines']}.items():
 actual=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==expected;retained[name]=actual
for workload in ['test','source']:
 restoration=json.loads((p/(workload+'-edit-paired/restoration.json')).read_text())
 assert restoration['source_restored'] and restoration['test_restored'] and restoration['config_restored']
 expected=json.loads((p/(workload+'-edit-paired/metadata.json')).read_text())
 for relative,key in [('dagql/types.go','source_hash'),('dagql/cache_test.go','source_test_hash')]:
  assert hashlib.sha256((Path('/tmp/dagger-go-real-repository-main')/relative).read_bytes()).hexdigest()==expected[key]
checks=json.loads((p/'checks.json').read_text());assert len(checks)==6 and all(c['exit_code']==0 for c in checks)
module=Path('/tmp/dagger-go-snapshot-test-directories')
assert subprocess.check_output(['git','status','--porcelain'],cwd=module,text=True)==''
identity={}
for name,path in [('module',module),('engine',Path('/tmp/dagger-filesync-snapshot-seeds')),('repository',Path('/tmp/dagger-go-real-repository-main')),('interpreter',Path('/tmp/rust-cache-sipsma-review/dang-module-blueprint-content-key'))]:
 if name=='interpreter':
  identity[name]=dict(path=str(path),git_checkout=False,module_file_sha256=hashlib.sha256((path/'go.mod').read_bytes()).hexdigest(),note='Locally modified source directory; exact replacement sources are archived with their hashes.')
 else:
  identity[name]=dict(path=str(path),commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip())
assert identity['module']['commit']=='a3d0e4bf562b834c31135bff24e5931fd32b3acc'
(p/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
state=dict(retained_engines_unchanged=retained,shared_receiver_decode=get('shared-receiver-decode'),lifecycle=lifecycle,wcprof=get('wcprof/enabled'),lock_profiler=get('lock-profiler'),all_module_checks_pass=True,ordinary_gc=True,telemetry_enabled=True)
plan=json.loads((p/'engine-plan.json').read_text());flags={r:get(r)['enabled'] for r in plan['flags']}
assert flags==plan['flags'];state['flags']=flags
(p/'final-state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(retained_engines_unchanged=True,active_requests=lifecycle['active_requests'],shared_decode_enabled=state['shared_receiver_decode']['enabled'],checks=len(checks))),flush=True)
