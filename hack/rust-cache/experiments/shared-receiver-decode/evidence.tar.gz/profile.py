from pathlib import Path
import subprocess,sys,json,time
p=Path(__file__).parent
rows=[]
for arm in ['before','candidate']:
 command=[sys.executable,str(p/'capture.py'),'--arm',arm,'--output',str(p/('capture-'+arm)),'--edit-test-body','--cpu-profile']
 tick=time.monotonic()
 with (p/('capture-'+arm+'-driver.log')).open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(arm=arm,seconds=time.monotonic()-tick,exit_code=result.returncode,command=command)
 rows.append(row);(p/'capture-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:print((p/('capture-'+arm+'-driver.log')).read_text()[-4500:]);raise SystemExit(result.returncode)
