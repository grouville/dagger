package dangv2

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	"github.com/dagger/dagger/core"
	"github.com/vito/dang/v2/pkg/dang"
	"github.com/vito/dang/v2/pkg/ioctx"
)

func sharedReceiverFixture(tb testing.TB, packages, owners int) (dang.ValueScope, *core.FunctionCall) {
	tb.Helper()
	dir := tb.TempDir()
	source := `type Owner {
  path: String!
  name(): String! { path }
}
type Group {
  paths: [String!]!
  owners: [Owner!]!
  get(path: String!): String! {
    if (path == "fail") { raise "requested failure" }
    path + ":" + owners.map { owner => owner.name() }.join(",")
  }
}`
	if err := os.WriteFile(filepath.Join(dir, "main.dang"), []byte(source), 0600); err != nil {
		tb.Fatal(err)
	}
	env, err := dang.RunDir(context.Background(), dir, false)
	if err != nil {
		tb.Fatal(err)
	}
	paths := make([]string, packages)
	for i := range paths {
		paths[i] = fmt.Sprintf("package/%04d", i)
	}
	rows := make([]map[string]string, owners)
	for i := range rows {
		rows[i] = map[string]string{"path": fmt.Sprintf("module/%04d", i)}
	}
	parent, err := json.Marshal(map[string]any{"paths": paths, "owners": rows})
	if err != nil {
		tb.Fatal(err)
	}
	return env, &core.FunctionCall{ParentName: "Group", Name: "get", Parent: core.JSON(parent)}
}

func TestSharedReceiverDecodePreservesGetterCalls(t *testing.T) {
	previous := sharedReceiverDecodeEnabled.Load()
	sharedReceiverDecodeEnabled.Store(true)
	t.Cleanup(func() { sharedReceiverDecodeEnabled.Store(previous) })
	env, template := sharedReceiverFixture(t, 16, 2)
	var wg sync.WaitGroup
	for i := range 24 {
		wg.Go(func() {
			key := fmt.Sprintf("selected/%d", i)
			arg, _ := json.Marshal(key)
			call := &core.FunctionCall{ParentName: template.ParentName, Name: template.Name, Parent: template.Parent,
				InputArgs: []*core.FunctionCallArgValue{{Name: "path", Value: core.JSON(arg)}}}
			result, err := callDangFunction(t.Context(), env, call, dangModule{})
			if err != nil {
				t.Error(err)
				return
			}
			if got := result.(dang.StringValue).Val; got != key+":module/0000,module/0001" {
				t.Errorf("getter returned %q for %q", got, key)
			}
		})
	}
	wg.Wait()
	call := &core.FunctionCall{ParentName: template.ParentName, Name: template.Name, Parent: template.Parent,
		InputArgs: []*core.FunctionCallArgValue{{Name: "path", Value: core.JSON(`"fail"`)}}}
	if _, err := callDangFunction(t.Context(), env, call, dangModule{}); err == nil || !strings.Contains(err.Error(), "requested failure") {
		t.Fatalf("getter error was lost: %v", err)
	}
}

func TestSharedReceiverDecodePreservesInitializerEffects(t *testing.T) {
	previous := sharedReceiverDecodeEnabled.Load()
	sharedReceiverDecodeEnabled.Store(true)
	t.Cleanup(func() { sharedReceiverDecodeEnabled.Store(previous) })
	dir := t.TempDir()
	source := `type Group {
  name: String!
  let prefix: String! = { print("initialize " + name); name }
  get(path: String!): String! { print("get " + path); prefix + ":" + path }
}`
	if err := os.WriteFile(filepath.Join(dir, "main.dang"), []byte(source), 0600); err != nil {
		t.Fatal(err)
	}
	env, err := dang.RunDir(t.Context(), dir, false)
	if err != nil {
		t.Fatal(err)
	}
	for _, item := range []struct{ key, owner string }{{"first", "owner"}, {"second", "owner"}, {"third", "edited"}} {
		key, owner := item.key, item.owner
		var stdout bytes.Buffer
		arg, _ := json.Marshal(key)
		parent, _ := json.Marshal(map[string]string{"name": owner})
		ctx := ioctx.StdoutToContext(t.Context(), &stdout)
		call := &core.FunctionCall{ParentName: "Group", Name: "get", Parent: core.JSON(parent),
			InputArgs: []*core.FunctionCallArgValue{{Name: "path", Value: core.JSON(arg)}}}
		result, err := callDangFunction(ctx, env, call, dangModule{})
		if err != nil {
			t.Fatal(err)
		}
		if got := result.(dang.StringValue).Val; got != owner+":"+key {
			t.Fatalf("getter returned %q", got)
		}
		if got := stdout.String(); !strings.Contains(got, "initialize "+owner) || !strings.Contains(got, "get "+key) {
			t.Fatalf("call %s lost its own initializer/getter output: %q", key, got)
		}
	}
}

func BenchmarkSharedReceiverDecode(b *testing.B) {
	for _, packages := range []int{64, 256, 800} {
		b.Run(fmt.Sprintf("packages=%d", packages), func(b *testing.B) {
			env, template := sharedReceiverFixture(b, packages, max(1, packages/10))
			calls := make([]*core.FunctionCall, packages)
			for i := range calls {
				arg, _ := json.Marshal(fmt.Sprintf("selected/%d", i))
				calls[i] = &core.FunctionCall{ParentName: template.ParentName, Name: template.Name, Parent: template.Parent,
					InputArgs: []*core.FunctionCallArgValue{{Name: "path", Value: core.JSON(arg)}}}
			}
			b.ReportAllocs()
			b.ResetTimer()
			for range b.N {
				for _, call := range calls {
					if _, err := callDangFunction(b.Context(), env, call, dangModule{}); err != nil {
						b.Fatal(err)
					}
				}
			}
		})
	}
}
