from pathlib import Path
import json,os,subprocess
p=Path(__file__).parent;root=p/'capture';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';binary=p.parent/'sealed-metadata-json-engine/dagger-engine';env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off')
with (root/'analysis.log').open('w') as out:r=subprocess.run(['python3',str(p/'analyze.py'),str(root)],stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0
for suffix,options in [('flat',['-alloc_space']),('cumulative',['-alloc_space','-cum']),('objects',['-alloc_objects'])]:
 command=[go,'tool','pprof',*options,'-top','-nodecount=80','-nodefraction=0','-edgefraction=0','-base='+str(root/'alloc-before.pprof'),str(binary),str(root/'alloc-after.pprof')]
 with (root/('allocation-'+suffix+'.txt')).open('w') as out:r=subprocess.run(command,env=env,stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==0
print((root/'allocation-flat.txt').read_text()[:4700],flush=True)
print((root/'allocation-cumulative.txt').read_text()[:4700],flush=True)
