from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
base=Path('/tmp/rust-cache-sipsma-review');dest=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def ignore(d,names):return [n for n in names if n in {'__pycache__','.git','dagger-engine','wcprof-complete.ndjson','evidence-root','archive-driver.log'} or n.endswith('.test')]
def pack(root,out):
 out.mkdir(exist_ok=False);files=[f for f in sorted(root.rglob('*')) if f.is_file()];manifest=[dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files];mbytes=(json.dumps(manifest,indent=2)+'\n').encode();arc=out/'evidence.tar.gz'
 with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
  for f in files:
   info=tar.gettarinfo(str(f),arcname=str(f.relative_to(root)));info.mtime=0
   with f.open('rb') as stream:tar.addfile(info,stream)
  info=tarfile.TarInfo('manifest.json');info.size=len(mbytes);info.mtime=0;tar.addfile(info,io.BytesIO(mbytes))
 with tarfile.open(arc,'r:gz') as tar:
  assert len(tar.getmembers())==len(files)+1
  for row in manifest:
   b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 (out/'manifest.json').write_bytes(mbytes);record=dict(bytes=arc.stat().st_size,sha256=sha(arc.read_bytes()),members=len(files)+1,all_member_hashes_verified=True,binaries_excluded=True);write(out/'archive.json',record);print(out.name,record,flush=True)

p=base/'parallel-admission-local-discovery';root=p/'evidence-root';root.mkdir(exist_ok=False);reconstruction=[]
for label,source in [('admission',p),('allocations',base/'go-getter-allocation-current')]:
 for complete in sorted(source.rglob('wcprof-complete.ndjson')):
  if 'evidence-root' in complete.parts:continue
  folder=complete.parent;events=[];chunks=sorted(folder.glob('chunk-*.ndjson.gz'));assert chunks
  for chunk in chunks:
   with gzip.open(chunk,'rb') as stream:header=json.loads(stream.readline());events.extend(stream.readlines())
   assert header['dropped_events']==0
  assert not header.get('open_ops');header['event_count']=len(events);rebuilt=(json.dumps(header)+'\n').encode()+b''.join(events);assert rebuilt==complete.read_bytes()
  reconstruction.append(dict(capture=label+'/'+str(folder.relative_to(source)),events=len(events),chunks=[c.name for c in chunks],sha256=sha(rebuilt),exact_bytes_verified=True))
 shutil.copytree(source,root/label,ignore=ignore)
assert len(reconstruction)==5;write(root/'wcprof-reconstruction.json',reconstruction)
parent=dest/'go-generation-discovery';record=json.loads((parent/'archive.json').read_text());assert sha((parent/'evidence.tar.gz').read_bytes())==record['sha256'];write(root/'source-parent.json',dict(path='../go-generation-discovery/evidence.tar.gz',**record))
pack(root,dest/'parallel-admission-local-discovery')
for name in ['assessment.json','final-state.json']:(dest/'parallel-admission-local-discovery'/name).write_bytes((p/name).read_bytes())
for name in ['wcprof-reconstruction.json','source-parent.json']:(dest/'parallel-admission-local-discovery'/name).write_bytes((root/name).read_bytes())

p=base/'dang-list-element-types';repo=Path('/tmp/dagger-dang-list-element-types');identity=json.loads((p/'identity.json').read_text());patch=subprocess.check_output(['git','diff','--binary',identity['base'],'HEAD'],cwd=repo);(p/'fix.patch').write_bytes(patch)
for name in ['helpers.go','list_conversion_test.go']:(p/name).write_bytes((repo/'core/sdk/dang/v2'/name).read_bytes())
(p/'upstream-identity.json').write_bytes((base/'go-getter-allocation-current/upstream-identity.json').read_bytes())
root=p/'evidence-root';shutil.copytree(p,root,ignore=ignore);pack(root,dest/'dang-list-element-types')
for name in ['identity.json','steps.json','fix.patch']:(dest/'dang-list-element-types'/name).write_bytes((p/name).read_bytes())
