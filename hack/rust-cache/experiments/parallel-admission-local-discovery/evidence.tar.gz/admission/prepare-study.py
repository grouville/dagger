from pathlib import Path
import json,subprocess
base=Path('/tmp/rust-cache-sipsma-review');p=base/'parallel-admission-local-discovery';p.mkdir(exist_ok=True);parent=base/'go-discovery-generate-matches';engine=base/'sealed-metadata-json-engine'
for name in ['measure-source-edits.py','measure-test-edits.py','measure.py','capture.py','capture-all.py','analyze.py','analyze-all.py','verify-module.py']:
 s=(parent/name).read_text()
 # Both modes use the selected module. Only the client admission lock policy changes.
 s=s.replace('/tmp/dagger-go-indexed-owner-facts','/tmp/dagger-go-discovery-generate-matches')
 s=s.replace("'interface-field-snapshots','metadata-snapshot-json']","'interface-field-snapshots','metadata-snapshot-json','parallel-client-admission']")
 s=s.replace("'metadata-snapshot-json']).lower()","'metadata-snapshot-json','parallel-client-admission']).lower()")
 if name.startswith('measure-'):
  marker="            mode('metadata-snapshot-json',False)";assert marker in s;s=s.replace(marker,marker+"\n            mode('parallel-client-admission',arm=='combined')")
  s=s.replace('parallel_client_admission=False','parallel_client_admission=arm==\'combined\'')
  s=s.replace('discovery_generate_matches=arm==\'combined\'','discovery_generate_matches=True')
  s=s.replace('Generation patterns are matched once inside the existing Go.packages discovery invocation and reused by its transient module-discovery objects. Every module still selects its own discovered generation directories. No extra Dagger API or builtin, no getter state or logic change. Both arms retain metadata, telemetry and cleanup settings.','Both modes use Go module 511d381 with local generation matching. Only parallel nested-client admission changes; per-client serialization, initialization, permissions, leases, telemetry and full cleanup remain. The old cache fields and all other selected modes are identical.')
 if name=='capture.py':
  marker="    mode('metadata-snapshot-json',False)";assert marker in s;s=s.replace(marker,marker+"\n    mode('parallel-client-admission',options.arm=='candidate')")
  s=s.replace("discovery_generate_matches=options.arm=='candidate'","discovery_generate_matches=True,parallel_client_admission=options.arm=='candidate'")
 if name=='verify-module.py':
  marker=" for arm,repo in repos.items():";assert marker in s;s=s.replace(marker,marker+"\n  get('parallel-client-admission?enabled='+str(arm=='candidate').lower(),b'')",1)
  s=s.replace("'go-dev:selection-check']:run(arm,repo,check)","'go-dev:selection-check','go-dev:generation-discovery-check']:run(arm,repo,check)")
 s=s.replace('TestDiscoveryGenerateMatches','TestParallelAdmissionCurrent')
 (p/name).write_text(s)
# The existing Rust behavior harness changes only the same mode; same engine,
# actual selected execution, expected failures and native compilation cache.
s=(engine/'verify-rust.py').read_text().replace('metadata-snapshot-json-pipeline-oct19','parallel-admission-local-pipeline-oct19')
s=s.replace("'interface-field-snapshots','metadata-snapshot-json']","'interface-field-snapshots','metadata-snapshot-json','parallel-client-admission']")
s=s.replace("'metadata-snapshot-json']).lower()","'metadata-snapshot-json','parallel-client-admission']).lower()")
s=s.replace("get('metadata-snapshot-json?enabled='+str(arm=='candidate').lower(),b'')","get('metadata-snapshot-json?enabled=false',b'')\n  get('parallel-client-admission?enabled='+str(arm=='candidate').lower(),b'')")
(p/'verify-rust.py').write_text(s);(p/'rust-cache-query.py').write_bytes((engine/'rust-cache-query.py').read_bytes())
identity=dict(module_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/tmp/dagger-go-discovery-generate-matches',text=True).strip(),engine=json.loads((engine/'engine-build.json').read_text()),scenario='Same selected Go module in both modes; no source or binary changes. Retest existing parallel admission because current test-edit critical path includes 1.77s lifecycle lock wait after the generation-matching improvement.',prior_result='Earlier cohorts remain separate and unselected; no result will be pooled.',new_pr_opened=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-parallel-admission-local.py').read_bytes())
# Run functional checks first, then fixed paired latency and profiles, sequentially.
code='''from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for label,name in [('go-checks','verify-module.py'),('rust-checks','verify-rust.py'),('timings','measure.py'),('profiles','capture-all.py'),('analysis','analyze-all.py')]:
 command=['python3',str(p/name)];tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-2500:],flush=True);raise SystemExit(r.returncode)
'''
(p/'run.py').write_text(code)
import ast
for f in p.glob('*.py'):ast.parse(f.read_text())
for name in ['measure-source-edits.py','measure-test-edits.py','capture.py']:
 s=(p/name).read_text();assert "'parallel-client-admission']" in s;assert '/tmp/dagger-go-indexed-owner-facts' not in s
print(p)
