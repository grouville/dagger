from pathlib import Path
import gzip,json,shutil,subprocess,time,urllib.request
p=Path(__file__).parent;failed=p/'initial-profile-cleanup-error';failed.mkdir(exist_ok=False)
# Preserve the failed capture, including its original script and command output.
for name in ['capture-before','capture-before-driver.log','profiles-driver.log','capture-steps.json']:
 path=p/name
 if path.exists():shutil.move(str(path),failed/name)
root=failed/'capture-before'
with urllib.request.urlopen('http://127.0.0.1:16112/debug/wcprof/dump',timeout=60) as response:payload=response.read()
header=json.loads(payload.split(b'\n',1)[0]);assert header['dropped_events']==0 and not header.get('open_ops')
(root/'recovered-final.ndjson.gz').write_bytes(gzip.compress(payload,mtime=0))
for raw in root.glob('chunk-*.ndjson'):
 data=raw.read_bytes();h=json.loads(data.split(b'\n',1)[0]);assert h['dropped_events']==0 and h['epoch_unix_nano']==header['epoch_unix_nano'];(root/(raw.name+'.gz')).write_bytes(gzip.compress(data,mtime=0));raw.unlink()
(root/'recovery-note.json').write_text(json.dumps(dict(failed_script_not_counted_as_successful_capture=True,command_exit_status_not_persisted=True,raw_chunks_preserved=True,remaining_buffer_drained=True,dropped_events=header['dropped_events'],open_ops=len(header.get('open_ops',[]))),indent=2)+'\n')
rows=[]
for label,name in [('profiles','capture-all.py'),('analysis','analyze-all.py')]:
 command=['python3',str(p/name)];tick=time.monotonic()
 with (p/(label+'-resume.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'resume-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-resume.log')).read_text()[-2500:]);raise SystemExit(r.returncode)
