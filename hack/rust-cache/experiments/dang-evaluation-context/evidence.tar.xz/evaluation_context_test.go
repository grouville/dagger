package dang

import (
	"context"
	"errors"
	"fmt"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

type evaluationCountingContext struct {
	context.Context
	reads *atomic.Int64
}

func (ctx evaluationCountingContext) Value(key any) any {
	ctx.reads.Add(1)
	return ctx.Context.Value(key)
}

func TestEvaluationContextLookupDoesNotWalkInitializerAncestors(t *testing.T) {
	for _, present := range []bool{false, true} {
		t.Run(fmt.Sprint(present), func(t *testing.T) {
			var reads atomic.Int64
			var ctx context.Context = context.Background()
			var eval *EvalContext
			if present {
				eval = NewEvalContext("main.dang", "")
				ctx = WithEvalContext(ctx, eval)
			}
			for range 128 {
				ctx = withForceChain(evaluationCountingContext{Context: ctx, reads: &reads}, &pendingInit{})
			}
			reads.Store(0)
			for range 10 {
				require.Same(t, eval, GetEvalContext(ctx))
			}
			require.LessOrEqual(t, reads.Load(), int64(10), "state lookup must not rewalk the initializer ancestry")
		})
	}
}

func TestEvaluationContextPreservesParentAndCycleState(t *testing.T) {
	type userKey struct{}
	parent, cancel := context.WithCancelCause(context.Background())
	defer cancel(nil)
	deadline := time.Now().Add(time.Minute)
	parent, stop := context.WithDeadline(parent, deadline)
	defer stop()
	parent = context.WithValue(parent, userKey{}, "outer")
	first, second := &pendingInit{}, &pendingInit{}
	outer := NewEvalContext("outer.dang", "outer")
	ctx := withForceChain(WithEvalContext(parent, outer), first)
	ctx = context.WithValue(ctx, userKey{}, "inner")
	inner := NewEvalContext("inner.dang", "inner")
	ctx = withForceChain(WithEvalContext(ctx, inner), second)
	require.Same(t, inner, GetEvalContext(ctx))
	require.Equal(t, "inner", ctx.Value(userKey{}))
	require.True(t, forcingInChain(ctx, first))
	require.True(t, forcingInChain(ctx, second))
	require.False(t, forcingInChain(ctx, &pendingInit{}))
	actual, ok := ctx.Deadline()
	require.True(t, ok)
	require.Equal(t, deadline, actual)
	cause := errors.New("cancelled by caller")
	cancel(cause)
	require.ErrorIs(t, ctx.Err(), context.Canceled)
	require.ErrorIs(t, context.Cause(ctx), cause)
	require.Equal(t, "outer.dang", outer.Filename)
}

func TestEvaluationContextPreservesRawPrivateValues(t *testing.T) {
	for _, raw := range []any{nil, (*EvalContext)(nil), "foreign", NewEvalContext("source.dang", "")} {
		var ctx context.Context = context.Background()
		if raw != nil {
			ctx = context.WithValue(ctx, evalContextKey{}, raw)
		}
		forced := withForceChain(ctx, &pendingInit{})
		require.Equal(t, raw, forced.Value(evalContextKey{}))
	}
	for _, raw := range []any{nil, (*forceChain)(nil), "foreign"} {
		var ctx context.Context = context.Background()
		if raw != nil {
			ctx = context.WithValue(ctx, forceChainKey{}, raw)
		}
		eval := WithEvalContext(ctx, NewEvalContext("source.dang", ""))
		require.Equal(t, raw, eval.Value(forceChainKey{}))
		nilEval := WithEvalContext(eval, nil)
		require.Nil(t, GetEvalContext(nilEval))
		require.Equal(t, any((*EvalContext)(nil)), nilEval.Value(evalContextKey{}))
	}
}

var evaluationContextBenchmarkSink *EvalContext

func BenchmarkEvaluationContextLookupDepth(b *testing.B) {
	for _, depth := range []int{8, 64, 512} {
		for _, present := range []bool{false, true} {
			b.Run(fmt.Sprintf("depth=%d/present=%t", depth, present), func(b *testing.B) {
				var ctx context.Context = context.Background()
				if present {
					ctx = WithEvalContext(ctx, NewEvalContext("source.dang", ""))
				}
				for range depth {
					ctx = withForceChain(ctx, &pendingInit{})
				}
				b.ReportAllocs()
				b.ResetTimer()
				for range b.N {
					evaluationContextBenchmarkSink = GetEvalContext(ctx)
				}
			})
		}
	}
}
