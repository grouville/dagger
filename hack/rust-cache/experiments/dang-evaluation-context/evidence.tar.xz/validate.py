from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent;lang=Path('/tmp/rust-cache-sipsma-review/dang-module-blueprint-content-key');go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1');rows=[]
steps=[('before-control','before',False,'^TestEvaluationContextLookupDoesNotWalkInitializerAncestors$',1),('after-focused','after',True,'^TestEvaluationContext',0),('after-package-race','after',True,'',0)]
source={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.go')};(p/'validation-source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
for label,arm,race,pattern,expected in steps:
 cmd=[go,'test','-p=2','-mod=mod','-modfile='+str(p/'dang.go.mod'),'-overlay='+str(p/(arm+'-overlay.json')),'-count=1','-timeout=180s']
 if pattern:cmd.append('-run='+pattern)
 if race:cmd.append('-race')
 cmd.append('./pkg/dang');start=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=lang,env=env,stdout=out,stderr=subprocess.STDOUT)
 text=(p/(label+'.log')).read_text();row=dict(label=label,command=cmd,seconds=time.monotonic()-start,exit_code=r.returncode,expected_exit_code=expected);rows.append(row);(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==expected,(label,text[-4000:])
 if expected:assert 'state lookup must not rewalk the initializer ancestry' in text and '[build failed]' not in text
 assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in source.items())
