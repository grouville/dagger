from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent;lang=Path('/tmp/rust-cache-sipsma-review/dang-module-blueprint-content-key');engine=Path('/tmp/dagger-filesync-snapshot-seeds');go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1');overlay='-overlay='+str(p/'engine-overlay.json')
steps=[('controlled-context-race',[go,'test','-p=2','-mod=mod','-modfile='+str(p/'dang.go.mod'),overlay,'-count=1','-race','-timeout=120s','-run=^TestEvaluationContext','./pkg/dang'],lang,'true',0),('disabled-control',[go,'test','-p=2','-mod=mod','-modfile='+str(p/'dang.go.mod'),overlay,'-count=1','-race','-timeout=120s','-run=^TestEvaluationContextLookupDoesNotWalkInitializerAncestors$','./pkg/dang'],lang,'false',1),('engine-build',[go,'build','-p=2','-buildvcs=false','-modfile=/tmp/rust-cache-sipsma-review/log-flush-buffer/engine.go.mod',overlay,'-o',str(p/'dagger-engine'),'./cmd/engine'],engine,'false',0)]
files=json.loads((p/'engine-overlay.json').read_text())['Replace'].values();hashes={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files};(p/'engine-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');rows=[]
for label,cmd,cwd,enabled,expected in steps:
 start=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=cwd,env=dict(env,DANG_BENCH_EVAL_CONTEXT=enabled),stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=cmd,seconds=time.monotonic()-start,exit_code=r.returncode,expected_exit_code=expected,feature_enabled=enabled=='true')
 if label=='engine-build' and r.returncode==0:row['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
 rows.append(row);(p/'build-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==expected,(label,(p/(label+'.log')).read_text()[-4000:])
 if expected:assert 'state lookup must not rewalk the initializer ancestry' in (p/(label+'.log')).read_text()
 assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in hashes.items())
