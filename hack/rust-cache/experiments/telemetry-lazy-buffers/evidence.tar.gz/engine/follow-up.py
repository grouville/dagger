from pathlib import Path
import json,statistics,subprocess,time
p=Path(__file__).parent;steps=[]
for work in ['source','test']:
 command=['python3',str(p/f'measure-{work}-edits.py'),'--output',str(p/(work+'-edit-follow-up')),'--fixture','real','--arms','before','combined','--pairs','8'];tick=time.monotonic()
 with (p/(work+'-follow-up-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=work,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'follow-up-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(work,(p/(work+'-follow-up-driver.log')).read_text()[-2200:])
 samples=json.loads((p/(work+'-edit-follow-up/samples.json')).read_text());pairs=[]
 for block in range(2,10):
  arms={r['arm']:r for r in samples if r['block']==block};pairs.append(arms['before']['seconds']-arms['combined']['seconds'])
 d=dict(medians=json.loads((p/(work+'-edit-follow-up/summary.json')).read_text()),paired_seconds=pairs,median_paired_saving=statistics.median(pairs),faster_pairs=sum(v>0 for v in pairs),commands=len(samples),all_correct=all(r['exit_code']==0 and r['correct_names'] and r['same_full_rows'] for r in samples),reason='Fixed eight-pair follow-ups in both workloads after initial source latency regressed slightly and test latency varied despite consistent allocation savings. Preserve all cohorts separately; no forced GC, cache reset or budget changes.')
 a=json.loads((p/'assessment.json').read_text());a.setdefault('follow_up',{})[work]=d;(p/'assessment.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(d),flush=True)
command=['python3',str(p.parent/'telemetry-lazy-buffers-component/run-write-control.py')];tick=time.monotonic()
with (p/'write-control-driver.log').open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
steps.append(dict(label='first-write-control',command=command,seconds=time.monotonic()-tick,exit_code=r.returncode));(p/'follow-up-steps.json').write_text(json.dumps(steps,indent=2)+'\n');assert r.returncode==0
