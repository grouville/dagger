from pathlib import Path
import ast,json
b=Path('/tmp/rust-cache-sipsma-review');p=b/'lazy-spill-buffers-engine';p.mkdir(exist_ok=False);parent=b/'linear-map-merge-engine'
s=(b/'telemetry-native-storage/engine__clientdb__store_spill.go').read_text()
s=s.replace('''		file:      file,
		codec:     codec,
		committed: size,
''','''		file:        file,
		codec:       codec,
		committed:   size,
		writeOffset: size,
''',1)
old='\tspill.writer = bufio.NewWriterSize(spillWriterFunc(spill.write), spillBufferSize)';assert s.count(old)==1;s=s.replace(old,'\tif !lazySpillBuffersEnabled.Load() {\n'+old+'\n\t}',1)
s=s.replace('func (s *spillFile[Row]) recover(ctx context.Context, size int64, onRecover func(Row)) error {\n','''func (s *spillFile[Row]) recover(ctx context.Context, size int64, onRecover func(Row)) error {
	if lazySpillBuffersEnabled.Load() && size == 1 {
		return nil
	}
''',1)
s=s.replace('\tstart := s.writeOffset\n','''\tif s.writer == nil {
		s.writer = bufio.NewWriterSize(spillWriterFunc(s.write), spillBufferSize)
	}

	start := s.writeOffset
''',1)
s=s.replace('''func (s *spillFile[Row]) close() error {
	return errors.Join(s.writer.Flush(), s.file.Close())
}''','''func (s *spillFile[Row]) close() error {
	var flushErr error
	if s.writer != nil {
		flushErr = s.writer.Flush()
	}
	return errors.Join(flushErr, s.file.Close())
}''',1);(p/'store_spill.go').write_text(s)
(p/'mode.go').write_text('''package clientdb
import("encoding/json";"net/http";"os";"strconv";"sync/atomic")
var lazySpillBuffersEnabled atomic.Bool
func init(){lazySpillBuffersEnabled.Store(os.Getenv("DAGGER_TEST_LAZY_SPILL_BUFFERS")=="true")}
func LazySpillBuffersDiagnostic(w http.ResponseWriter,r *http.Request){
 if r.Method==http.MethodPost {v,e:=strconv.ParseBool(r.URL.Query().Get("enabled"));if e!=nil{http.Error(w,e.Error(),400);return};lazySpillBuffersEnabled.Store(v)} else if r.Method!=http.MethodGet {http.Error(w,"GET or POST required",405);return}
 w.Header().Set("Content-Type","application/json");_ = json.NewEncoder(w).Encode(map[string]any{"enabled":lazySpillBuffersEnabled.Load()})
}
''')
s=(parent/'engine-debug.go').read_text();needle='\tm.HandleFunc("/debug/linear-map-merge", dang.LinearMapMergeDiagnostic)';assert needle in s;s=s.replace(needle,needle+'\n\tm.HandleFunc("/debug/lazy-spill-buffers", clientdb.LazySpillBuffersDiagnostic)');(p/'engine-debug.go').write_text(s)
o=json.loads((parent/'overlay.json').read_text());key=next(k for k,v in o['Replace'].items() if k.endswith('/engine/clientdb/store_spill.go'));o['Replace'][key]=str(p/'store_spill.go');o['Replace'][key.replace('store_spill.go','lazy_spill_buffers_mode.go')]=str(p/'mode.go');o['Replace'][key.replace('store_spill.go','store_lazy_buffers_test.go')]='/tmp/dagger-telemetry-lazy-buffers/engine/clientdb/store_lazy_buffers_test.go';o['Replace'][next(k for k,v in o['Replace'].items() if k.endswith('/cmd/engine/debug.go'))]=str(p/'engine-debug.go');(p/'overlay.json').write_text(json.dumps(o,indent=2)+'\n')
plan=json.loads((parent/'engine-plan.json').read_text());plan.update(new_engine='dagger-collection-lazy-spill-oct19',ports={'runner':16288,'debug':16116},scenario='Controlled lazy spill buffers; Go module 720a525 in both arms. Native telemetry storage remains enabled.');plan['flags']['lazy-spill-buffers']=False;(p/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(parent/'build-engine.py').read_text().replace("DANG_TEST_LINEAR_MAP_MERGE='true'","DAGGER_TEST_LAZY_SPILL_BUFFERS='true'").replace("'DANG_TEST_LINEAR_MAP_MERGE'","'DAGGER_TEST_LAZY_SPILL_BUFFERS'").replace("'interpreter-race'","'clientdb-race'").replace("'github.com/vito/dang/v2/pkg/dang'","'./engine/clientdb'");(p/'build-engine.py').write_text(s)
s=(parent/'start-engine.py').read_text().replace(':16287',':16288').replace(':16115',':16116').replace('codex.task=linear-map-merge','codex.task=lazy-spill-buffers')
start=s.index('retained={}');end=s.index('container=subprocess.check_output',start)
s=s[:start]+'''retained={}
prior=json.loads(Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-directory-membership/final-state.json').read_text())['binaries']
for retained_name,expected_sha in prior.items():
 actual=subprocess.check_output(['docker','exec',retained_name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==expected_sha;retained[retained_name]=actual
'''+s[end:];(p/'start-engine.py').write_text(s)
# Reuse completed protocols. Both arms use the selected Go module and original map merging.
proto=b/'go-generation-native-membership'
for name in ['measure-source-edits.py','measure-test-edits.py','measure.py','capture.py','capture-all.py','analyze.py','analyze-all.py','verify-module.py']:
 s=(proto/name).read_text().replace(':16287',':16288').replace(':16115',':16116').replace('dagger-collection-linear-merge-oct19','dagger-collection-lazy-spill-oct19')
 s=s.replace("Path('/tmp/dagger-go-discovery-generate-matches')","Path('/tmp/dagger-go-generation-native-membership')")
 s=s.replace("'parallel-client-admission','linear-map-merge']","'parallel-client-admission','linear-map-merge','lazy-spill-buffers']")
 s=s.replace("mode('linear-map-merge',False)","mode('linear-map-merge',False)\n"+('    ' if name=='capture.py' else '            ')+"mode('lazy-spill-buffers',"+("options.arm=='candidate'" if name=='capture.py' else "arm=='combined'")+")")
 s=s.replace("get('linear-map-merge?enabled=false',b'')","get('linear-map-merge?enabled=false',b'')\n  get('lazy-spill-buffers?enabled='+str(arm=='candidate').lower(),b'')")
 s=s.replace("'metadata-snapshot-json','parallel-client-admission','linear-map-merge']).lower()","'metadata-snapshot-json','parallel-client-admission','linear-map-merge','lazy-spill-buffers']).lower()")
 s=s.replace("generation_native_membership=arm=='combined'","generation_native_membership=True,lazy_spill_buffers=arm=='combined'").replace("generation_native_membership=options.arm=='candidate'","generation_native_membership=True,lazy_spill_buffers=options.arm=='candidate'")
 s=s.replace('Both modes use Go module 511d381 with local generation matching. Both modes use the original native map merging. Directory membership uses the existing List.contains instead of a pure equality callback inside List.any; both use the same string equality implementation.','Both modes use Go module 720a525 and original map merging. Only empty spill recovery and first-write buffer allocation change; files, headers, telemetry records, flushing and cleanup remain.')
 s=s.replace("str(p.parent/'linear-map-merge-engine/dagger-engine')","str(p/'dagger-engine')").replace("Path('/tmp/rust-cache-sipsma-review/linear-map-merge-engine/engine-build.json')","Path('/tmp/rust-cache-sipsma-review/lazy-spill-buffers-engine/engine-build.json')")
 (p/name).write_text(s)
for name in ['verify-rust.py','rust-cache-query.py']:
 s=(parent/name).read_text().replace(':16287',':16288').replace(':16115',':16116').replace('dagger-collection-linear-merge-oct19','dagger-collection-lazy-spill-oct19')
 s=s.replace("'parallel-client-admission','linear-map-merge']","'parallel-client-admission','linear-map-merge','lazy-spill-buffers']")
 s=s.replace("'metadata-snapshot-json','parallel-client-admission','linear-map-merge']).lower()","'metadata-snapshot-json','parallel-client-admission','linear-map-merge','lazy-spill-buffers']).lower()")
 s=s.replace("get('linear-map-merge?enabled='+str(arm=='candidate').lower(),b'')","get('linear-map-merge?enabled=false',b'')\n  get('lazy-spill-buffers?enabled='+str(arm=='candidate').lower(),b'')")
 s=s.replace('linear-map-merge-pipeline-oct19','lazy-spill-buffers-pipeline-oct19');(p/name).write_text(s)
(p/'run.py').write_bytes((parent/'run.py').read_bytes());(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-lazy-spill-engine.py').read_bytes())
for f in p.glob('*.py'):ast.parse(f.read_text())
print(p)
