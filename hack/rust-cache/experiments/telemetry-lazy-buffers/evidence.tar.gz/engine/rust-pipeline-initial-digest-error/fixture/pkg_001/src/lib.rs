pub fn invalid() -> u64 { "excluded crate" }
