pub fn edited_value() -> u64 { 123 }
#[test]
fn fresh_before_a() { assert_eq!(edited_value(), 123); }
#[test]
fn must_fail() { panic!("pipeline-required-failure-before_a"); }
