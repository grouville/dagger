from pathlib import Path
import json
p=Path(__file__).parent;b=p.parent;dest=Path('/home/dagger/dagger_otra/hack/rust-cache');a=json.loads((p/'assessment.json').read_text());component=json.loads((b/'telemetry-lazy-buffers-component/assessment.json').read_text());identity=json.loads((b/'telemetry-lazy-buffers-component/identity.json').read_text())
def values(work):
 d=a['follow_up'][work];return d['medians']['before'],d['medians']['combined'],d
x,y,t=values('test');s0,s1,s=values('source');url='https://github.com/grouville/dagger/commit/'+identity['commit']
text=f'''# Allocate telemetry spill buffers when needed

A small engine candidate reduces allocation after a test edit, while complete-command latency remains modest and mixed:

| Complete listing, fixed eight-pair follow-up | Before | Lazy buffers | Faster pairs |
| --- | ---: | ---: | ---: |
| Test-file edit | {x['median_seconds']:.2f} s | {y['median_seconds']:.2f} s | {t['faster_pairs']}/8 |
| Ordinary-source edit | {s0['median_seconds']:.2f} s | {s1['median_seconds']:.2f} s | {s['faster_pairs']}/8 |

| Engine work, same cohorts | Test edit, before → after | Ordinary edit, before → after |
| --- | ---: | ---: |
| Allocated bytes, decimal GB | {x['median_allocated_bytes']/1e9:.3f} → {y['median_allocated_bytes']/1e9:.3f} | {s0['median_allocated_bytes']/1e9:.3f} → {s1['median_allocated_bytes']/1e9:.3f} |
| CPU-seconds | {x['median_engine_cpu']:.2f} → {y['median_engine_cpu']:.2f} | {s0['median_engine_cpu']:.2f} → {s1['median_engine_cpu']:.2f} |

Both modes use Go module `720a525`, the same development engine binary and the same selected settings. A fresh CLI receives a real edit on a warm engine. Timings include normal telemetry, ordinary GC, output, final flushing and successful cleanup. Each cohort completes test addition and removal before its measured pairs. All 64 real-repository timing commands across the initial screen and follow-ups return the correct ordered rows. The stable listing has 4,398 rows. These are separate cohorts, without pooling or additive savings; current cold, released-engine and Rust latency effects are unmeasured.

The initial four-pair screen measured test edits **6.91 → 6.72 s**, faster in 3/4 pairs, and ordinary edits **4.08 → 4.17 s**, faster in 1/4. The fixed follow-ups test that source slowdown and variable test latency. All samples, including slower runs and the large baseline outlier, remain in the evidence. This is primarily an allocation proposal, not a three-second breakthrough. Its experimental mode is restored to off.

The earlier serialization hypothesis did not justify an implementation: recursive `Object.Bindings` accounts for only 2.50 MB in the preceding 5,076.57 MB allocation sample. New combined CPU, allocation, mutex and wcprof captures instead identify telemetry-store buffers among the major allocation callers. Allocation profiles can lag by up to two natural GC cycles, as documented by Go 1.26.6 `runtime.MemProfile`; use the paired `TotalAlloc` counter for command-level savings rather than treating sampled deltas as exact per-command attribution. No GC was forced. Mutex waiting is aggregate across concurrent callers, not elapsed time saved; the already-rejected parallel-admission mode stays off.

Opening a spill file currently reserves a 64 KiB reader for recovery and a 64 KiB writer, including for empty files. The candidate recognizes a validated header-only file without allocating a scanner and creates its writer on the first valid nonempty append. Files are still opened, headers validated, populated stores recovered and writes flushed before committed offsets are published. Closing an unused store still closes its descriptor and reports errors. The existing single spiller owns the writer; no new lock, shared pool, asynchronous flushing, storage format or public API is added. Private module state and all collection logic remain.

Standalone component comparisons on current main `ff0b029`, four alternating fresh-process pairs with Go 1.26.6 and eight available processors:

| Operation | Before | Lazy buffers | Allocated bytes, before → after |
| --- | ---: | ---: | ---: |
'''
labels={'BenchmarkSpillFileOpenClose/empty':'Open/close empty','BenchmarkSpillFileOpenClose/one-row':'Open/close one stored row','BenchmarkSpillFileOpenClose/256-rows':'Open/close 256 stored rows','BenchmarkSpillFileOpenAppendClose':'Open, first append, close'}
for key,label in labels.items():
 d=component[key];before=d['medians']['before'];after=d['medians']['candidate'];text+=f"| {label} | {before['ns']/1000:.2f} µs | {after['ns']/1000:.2f} µs | {before['bytes']:,.0f} → {after['bytes']:,.0f} |\n"
text+='''
The first-write control includes resetting the same file to its header in both modes, then opening it, appending a real row, flushing and closing. It checks the cost where the delayed writer is actually needed, rather than timing open alone. The new lifecycle test verifies empty close, reopen, first append and recovery through observable rows. Existing corruption, cancellation, rollback, stream, concurrency and registry tests pass under race detection with both standalone implementations. The exact diagnostic engine's clientdb race suite also passes.

All 27 Go check invocations and 28 corrected Rust/native-cache cases have their expected outcomes. They exercise selected execution, required failures, edited/restored sources and native compilation-action hits. Lossless before/after captures retain all 800 authored getters and 799 unchanged discoveries after a test edit; ordinary-source captures retain all getter and discovery hits. SDK request counts stay at 1,415 and 493. Telemetry and final cleanup stay in the pipeline.

The first Rust gate failed in its harness: replacing a port number also altered a substring in the image digest. The source digest was restored and address replacements were narrowed to include their colon. That failed attempt and correction are retained. The completed engine build and Go checks were not rerun; only the failed gate and subsequent phases resumed. No production-code failure is inferred from that attempt.

'''
text+=f'''[Standalone source]({url}) is based directly on verified upstream main `ff0b029a4d270a651b9a8c7286babc79089066e4`. The [PR description](PR_TELEMETRY_LAZY_BUFFERS.md) is prepared for review; no PR is open. [Evidence](experiments/telemetry-lazy-buffers/) includes all attempts, benchmarks, timings, race checks, six lossless captures and exact engine-input deltas. All twelve engines and cache volumes remain intact, workspaces are restored, and capture switches are off; the lazy buffer experiment is restored to off. The broader three-second collection and native Rust-cache performance goals remain unfinished.
'''
(dest/'NATIVE_TELEMETRY_LAZY_BUFFERS.md').write_text(text)
pr=f'''# perf(clientdb): allocate spill buffers when needed

Opening a telemetry spill file allocates a 64 KiB recovery reader and a 64 KiB writer, including when the file contains only its header. Recognize that empty case without a scanner and create the writer on the first valid nonempty append.

File creation, header validation, populated-file recovery and append flushing keep their existing behavior. Closing an unused store still closes the file. The existing single writer owns buffer initialization; no lock or storage-format change is needed.

Four alternating benchmark pairs on Go 1.26.6: empty open/close improves **25.10 → 7.54 µs**, with allocation **131,920 → 536 bytes**. Opening populated stores also allocates about 64 KiB less. The first-append control measures open, a real write, flush and close; see the complete results below.

On the experimental collection stack, fixed eight-pair complete-command comparisons are **{x['median_seconds']:.2f} → {y['median_seconds']:.2f} s** after a test edit ({t['faster_pairs']}/8 faster), and **{s0['median_seconds']:.2f} → {s1['median_seconds']:.2f} s** after an ordinary-source edit ({s['faster_pairs']}/8). Test-edit allocation falls **{x['median_allocated_bytes']/1e9:.2f} → {y['median_allocated_bytes']/1e9:.2f} GB**. This is primarily an allocation improvement; the latency effect is not uniform. Timings include telemetry and successful cleanup.

The full clientdb race suite passes before and after, including an empty close/reopen/append recovery test. The diagnostic engine also passes its exact-overlay race suite, 27 Go checks and 28 Rust/native-cache cases with their expected outcomes. [Source, all cohorts and first-write measurements](NATIVE_TELEMETRY_LAZY_BUFFERS.md).
'''
(dest/'PR_TELEMETRY_LAZY_BUFFERS.md').write_text(pr)
print('Wrote report and review description.')
