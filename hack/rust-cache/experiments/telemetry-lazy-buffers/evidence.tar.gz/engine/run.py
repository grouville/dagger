from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for label,name in [('build','build-engine.py'),('start','start-engine.py'),('go-checks','verify-module.py'),('rust-checks','verify-rust.py'),('timings','measure.py'),('profiles','capture-all.py'),('analysis','analyze-all.py')]:
 command=['python3',str(p/name)];tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-2500:],flush=True);raise SystemExit(r.returncode)
