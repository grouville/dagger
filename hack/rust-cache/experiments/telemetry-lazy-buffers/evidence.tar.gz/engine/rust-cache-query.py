import base64,json,os,sys,urllib.request,urllib.error
from pathlib import Path
endpoint='http://127.0.0.1:'+os.environ['DAGGER_SESSION_PORT']+'/query'
headers={'Content-Type':'application/json','Authorization':'Basic '+base64.b64encode((os.environ['DAGGER_SESSION_TOKEN']+':').encode()).decode()}
def query(document,variables=None):
 request=urllib.request.Request(endpoint,json.dumps(dict(query=document,variables=variables or {})).encode(),headers)
 try:
  with urllib.request.urlopen(request,timeout=240) as response:result=json.load(response)
 except urllib.error.HTTPError as error:raise RuntimeError(error.read().decode()) from error
 if result.get('errors'):raise RuntimeError(result['errors'])
 return result['data']
source=query('{ currentWorkspace { directory(path: "/", exclude: [".git", "target", "dagger.toml", "dagger.lock"]) { id } } }')['currentWorkspace']['directory']['id']
print(json.dumps(query(Path(sys.argv[1]).read_text(),dict(source=source))))
