#[test]
fn other_package() { assert_eq!(2 + 2, 4); }
