from pathlib import Path
import ast,json
b=Path('/tmp/rust-cache-sipsma-review');p=b/'go-current-pipeline-profile';p.mkdir(exist_ok=False)
s=(b/'go-generation-native-membership/capture.py').read_text()
s=s.replace("    (root/'prepared-declarations-before.json').write_text", "    lock_settings=get('lock-profiler?enabled=true',b'');assert lock_settings==dict(mutex_fraction=10,block_profile_rate_ns=1000000)\n    for profile in ['allocs','mutex','block']:(root/(profile+'-before.pprof')).write_bytes(raw('pprof/'+profile))\n    (root/'prepared-declarations-before.json').write_text",1)
s=s.replace("    get('upstream-log-queue',b'');seconds=time.monotonic()-tick;after=heap();after_cpu=cpu()", "    get('upstream-log-queue',b'');seconds=time.monotonic()-tick;after=heap();after_cpu=cpu()\n    for profile in ['allocs','mutex','block']:(root/(profile+'-after.pprof')).write_bytes(raw('pprof/'+profile))")
s=s.replace("    get('wcprof/enabled',b'off')", "    get('wcprof/enabled',b'off')\n    get('lock-profiler?enabled=false',b'')\n    assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)",1)
s=s.replace("    (root/'metadata.json').write_text", "    metadata['lock_profiles']=dict(mutex_fraction=10,block_profile_rate_ns=1000000)\n    assert metadata['engine_sha256']==json.loads(Path('/tmp/rust-cache-sipsma-review/linear-map-merge-engine/engine-build.json').read_text())['sha256']\n    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=module,text=True).strip()=='720a5258ad8212ab643bbeaa4084127b2e866800'\n    (root/'metadata.json').write_text",1)
(p/'capture.py').write_text(s);ast.parse(s);(p/'analyze.py').write_bytes((b/'go-generation-native-membership/analyze.py').read_bytes())
(p/'run.py').write_text('''from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;steps=[]
for label,edit in [('test',True),('source',False)]:
 command=['python3',str(p/'capture.py'),'--arm','candidate','--output',str(p/('capture-'+label)),'--cpu-profile']+(['--edit-test-body'] if edit else []);tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'steps.json').write_text(json.dumps(steps,indent=2)+'\\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(label,(p/(label+'-driver.log')).read_text()[-2000:])
''')
(p/'parent-source.json').write_text(json.dumps(dict(engine_sha256='7bf6fc847e7ff2d23054262049e05af1bc56578de2625e1a189c9ad6dcf5c79d',go_commit='720a5258ad8212ab643bbeaa4084127b2e866800',parent='hack/rust-cache/experiments/go-directory-membership',parent_archive_sha256='80663a4529b43cf1839810627ce4cb9c359d7c4d962f894819c47c73deedc608',reason='Attribute current edited-listing CPU, allocation, locks and critical paths before changing representation. Recursive Bindings accounts for only 2.50 MB of the preceding 5076.57 MB allocation sample.',forced_gc=False,diagnostic_only=True),indent=2)+'\n')
(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-current-pipeline-profile.py').read_bytes())
print(p)
