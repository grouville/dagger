from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;steps=[]
for label,edit in [('test',True),('source',False)]:
 command=['python3',str(p/'capture.py'),'--arm','candidate','--output',str(p/('capture-'+label)),'--cpu-profile']+(['--edit-test-body'] if edit else []);tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(label,(p/(label+'-driver.log')).read_text()[-2000:])
