from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';binary=p.parent/'linear-map-merge-engine/dagger-engine';steps=[]
def run(label,command,path):
 tick=time.monotonic()
 with path.open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 steps.append(dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode));(p/'analysis-steps.json').write_text(json.dumps(steps,indent=2)+'\n');assert r.returncode==0,(label,path.read_text()[-1500:])
for name in ['test','source']:
 root=p/('capture-'+name);run(name+'-wcprof',['python3',str(p/'analyze.py'),str(root)],root/'analysis.log')
 for profile,index in [('allocs','alloc_space'),('allocs','inuse_space'),('allocs','alloc_objects'),('mutex','delay'),('block','delay')]:
  for cumulative in [False,True]:
   filename=f'{profile}-{index}-'+('cumulative' if cumulative else 'flat')+'.txt'
   command=[go,'tool','pprof','-sample_index='+index,'-base='+str(root/(profile+'-before.pprof')),'-top','-nodefraction=0','-nodecount=70']+(['-cum'] if cumulative else [])+[str(binary),str(root/(profile+'-after.pprof'))]
   run(name+'-'+filename,command,root/filename)
 for cumulative in [False,True]:
  filename='cpu-'+('cumulative' if cumulative else 'flat')+'.txt'
  command=[go,'tool','pprof','-top','-nodefraction=0','-nodecount=90']+(['-cum'] if cumulative else [])+[str(binary),*[str(f) for f in sorted(root.glob('engine-cpu-*.pprof'))]]
  run(name+'-'+filename,command,root/filename)
print(json.dumps(dict(analysis_commands=len(steps),all_successful=True)),flush=True)
