from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;repo=Path('/tmp/dagger-telemetry-lazy-buffers');go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');steps=[]
def run(label,args):
 command=[go,*args];tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'write-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(label,(p/(label+'.log')).read_text()[-2200:])
for pair in range(4):
 for arm in (['before','candidate'] if pair%2==0 else ['candidate','before']):
  extra=['-overlay='+str(p/'before-overlay.json')] if arm=='before' else []
  run(f'write-bench-{pair}-{arm}',['test','-p=2',*extra,'-run=^$','-bench=^BenchmarkSpillFileOpenAppendClose$','-benchtime=200ms','-benchmem','-count=1','./engine/clientdb'])
