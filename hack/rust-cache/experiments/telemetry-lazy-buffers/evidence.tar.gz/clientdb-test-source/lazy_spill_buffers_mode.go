package clientdb
import("encoding/json";"net/http";"os";"strconv";"sync/atomic")
var lazySpillBuffersEnabled atomic.Bool
func init(){lazySpillBuffersEnabled.Store(os.Getenv("DAGGER_TEST_LAZY_SPILL_BUFFERS")=="true")}
func LazySpillBuffersDiagnostic(w http.ResponseWriter,r *http.Request){
 if r.Method==http.MethodPost {v,e:=strconv.ParseBool(r.URL.Query().Get("enabled"));if e!=nil{http.Error(w,e.Error(),400);return};lazySpillBuffersEnabled.Store(v)} else if r.Method!=http.MethodGet {http.Error(w,"GET or POST required",405);return}
 w.Header().Set("Content-Type","application/json");_ = json.NewEncoder(w).Encode(map[string]any{"enabled":lazySpillBuffersEnabled.Load()})
}
