from pathlib import Path
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
rows = []
assert json.loads((p / 'retained-first-after.json').read_text())['exit_code'] == 0


def mode(enabled):
    request = urllib.request.Request('http://127.0.0.1:16104/debug/lazy-schema-candidates?enabled=' + str(enabled).lower(), data=b'')
    with urllib.request.urlopen(request, timeout=20) as response:
        assert json.load(response)['enabled'] == enabled


def run(label, command):
    start = time.monotonic()
    with (p / (label + '-driver.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start))
    (p / 'profile-pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
    assert result.returncode == 0, label


try:
    mode(True)
    run('go-correctness', ['python3', str(p / 'verify-checks.py')])
finally:
    mode(False)
run('capture', ['python3', str(p / 'capture.py'), '--output', str(p / 'capture'), '--languages', 'go'])
run('causal-analysis', ['python3', str(p / 'analyze.py')])
run('work-analysis', ['python3', str(p / 'analyze-work.py')])
