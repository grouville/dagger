package core

func init() { lazySchemaCandidatesEnabled.Store(true) }
