from pathlib import Path
import hashlib
import json
import os
import re
import statistics
import subprocess
import time

p = Path(__file__).parent
cwd = Path('/tmp/dagger-lazy-schema-candidates')
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8')
stages = []
assert 'ok  ' in (p / 'after-race.log').read_text()


def run(label, command, expected=0):
    started = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - started)
    stages.append(row)
    (p / 'component-pipeline.json').write_text(json.dumps(stages, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    assert result.returncode == expected, label


run('before-current-regression', [go, 'test', '-p=2', '-overlay=' + str(p / 'before-overlay.json'), '-count=1', '-run=^TestModDepsForCallCoreOnly$', './core'], expected=1)
assert 'Should be zero, but was 1' in (p / 'before-current-regression.log').read_text()
for arm in ['before', 'after']:
    command = [go, 'test', '-c', '-p=2', '-buildvcs=false', '-o', str(p / (arm + '.test'))]
    if arm == 'before':
        command.append('-overlay=' + str(p / 'before-overlay.json'))
    run('build-' + arm, [*command, './core'])

source = Path('/tmp/rust-cache-sipsma-review/dang-inprocess-transport-screen/measure.py').read_text()
namespace = {'__file__': str(p / 'component-admission.py')}
exec(source.split('metadata = dict(')[0], namespace)
idle = namespace['idle']
orders = [['before', 'after'] if i % 2 == 0 else ['after', 'before'] for i in range(4)]
metadata = dict(pairs=4, modules=[0, 2, 64], kinds=['core', 'module'], orders=orders, gomaxprocs=8, normal_go_gc=True, benchtime='500ms',
                binaries={arm: hashlib.sha256((p / (arm + '.test')).read_bytes()).hexdigest() for arm in ['before', 'after']},
                scope='Actual Query.ModDepsForCall with real DagQL cache and installed Module values. Scoped rows are warm. Core-only recipes avoid candidate traversal; module-bearing recipes retain it. This is a component measurement, not a full listing speedup.')
(p / 'component-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
rows = []
for modules in metadata['modules']:
    for kind in metadata['kinds']:
        for pair, order in enumerate(orders):
            for arm in order:
                label = f'component-{kind}-{modules}-{pair}-{arm}'
                idle(label)
                command = [str(p / (arm + '.test')), '-test.run=^$', f'-test.bench=^BenchmarkModDepsForCallCandidates/{kind}/{modules}$', '-test.benchtime=500ms', '-test.count=1', '-test.timeout=30s']
                run(label, command)
                line = next(line for line in (p / (label + '.log')).read_text().splitlines() if line.startswith('BenchmarkModDepsForCallCandidates'))
                metrics = {name: float(re.search(r'([\d.]+) ' + re.escape(unit), line)[1]) for name, unit in [('ns_per_op', 'ns/op'), ('bytes_per_op', 'B/op'), ('allocations', 'allocs/op')]}
                rows.append(dict(modules=modules, kind=kind, pair=pair, arm=arm, **metrics))
                (p / 'component-samples.json').write_text(json.dumps(rows, indent=2) + '\n')

summary = {}
for modules in metadata['modules']:
    for kind in metadata['kinds']:
        group = [r for r in rows if r['modules'] == modules and r['kind'] == kind]
        values = {arm: {metric: statistics.median(r[metric] for r in group if r['arm'] == arm) for metric in ['ns_per_op', 'bytes_per_op', 'allocations']} for arm in ['before', 'after']}
        values['faster_pairs'] = sum(next(r['ns_per_op'] for r in group if r['pair'] == pair and r['arm'] == 'after') < next(r['ns_per_op'] for r in group if r['pair'] == pair and r['arm'] == 'before') for pair in range(4))
        summary[f'{kind}-{modules}'] = values
(p / 'component-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
