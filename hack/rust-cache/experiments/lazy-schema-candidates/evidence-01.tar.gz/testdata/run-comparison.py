from pathlib import Path
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
rows = []
work = json.loads((p / 'capture/work-reduction.json').read_text())
assert work['skipped_successful_calls'] > 0 and work['result']['same_rows']
assert work['result']['exit_code'] == 0 and not work['result']['recorder']['dropped']
assert all(row['exit_code'] == 0 for row in json.loads((p / 'profile-pipeline.json').read_text()))
checks = json.loads((p / 'correctness.json').read_text())
assert len(checks) == 35 and all(row['exit_code'] == 0 for row in checks)


def mode(enabled):
    request = urllib.request.Request('http://127.0.0.1:16104/debug/lazy-schema-candidates?enabled=' + str(enabled).lower(), data=b'')
    with urllib.request.urlopen(request, timeout=20) as response:
        assert json.load(response)['enabled'] == enabled


def run(label, command):
    start = time.monotonic()
    with (p / (label + '-driver.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start))
    (p / 'comparison-pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
    assert result.returncode == 0, label


mode(False)
run('whole-command', ['python3', str(p / 'measure-listing.py'), '--output', str(p / 'paired'), '--pairs', '9', '--languages', 'go'])
try:
    mode(True)
    run('retained-after-pairs', ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py', 'lazy-schema-candidates-after-pairs'])
finally:
    mode(False)
