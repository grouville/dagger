from collections import Counter
from pathlib import Path
import json

p = Path(__file__).parent / 'capture'
ops = {}
with (p / 'wcprof-complete.ndjson').open() as stream:
    header = json.loads(next(stream))
    names = header['strings']
    for line in stream:
        event = json.loads(line)
        if event['e'] == 'op':
            event['class'] = names[event['c']]
            ops[event['id']] = event
assert not header['dropped_events'] and not header.get('open_ops')
recoveries = {key: value for key, value in ops.items() if value['class'] == 'core.recoverModuleSchema'}
scans = [value for value in ops.values() if value['class'] == 'core.scanInstalledModules']
children = Counter(value.get('p', 0) for value in scans)
assert recoveries and all(parent in recoveries for parent in children)
assert max(children.values(), default=0) <= 1
successful = {key: value for key, value in recoveries.items() if value.get('o') == 'ok'}
assert successful
skipped = sum(not children[key] for key in successful)
result = dict(recovery_calls=len(recoveries), successful_calls=len(successful), failed_calls=len(recoveries) - len(successful),
              candidate_scans=len(scans), skipped_successful_calls=skipped,
              skipped_fraction=skipped / len(successful), all_scan_parents_are_recovery=True,
              maximum_scans_per_call=max(children.values(), default=0),
              operation_counts=dict(Counter(value['class'] for value in ops.values())),
              result=json.loads((p / 'result.json').read_text()),
              scope='Exact parent links between recovery and candidate-scan markers. Positive control: eager recovery prepares candidates once per successful call. No timing inference or cross-capture subtraction.')
(p / 'work-reduction.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['operation_counts', 'result']}, indent=2))
