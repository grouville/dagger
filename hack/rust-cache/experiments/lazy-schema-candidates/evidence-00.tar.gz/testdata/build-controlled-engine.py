from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
component=json.loads((p/'component-summary.json').read_text())
assert component['core-2']['faster_pairs']==4 and component['core-64']['faster_pairs']==4
rows = []
for enabled in ['before','after']:
    label='actual-overlay-race-'+enabled
    command=[go,'test','-p','2','-buildvcs=false','-modfile',
        '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',
        str(p/('actual-'+enabled+'-overlay.json')),'-race','-count=1','-run=^Test(ModDepsForCall|SchemaBuilder|PersistedDecodeDefaultDeps|ModuleObject|ModuleOwnership)',*(['-skip=^TestModDepsForCallCoreOnly$'] if enabled=='before' else []),'./core']
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=output,stderr=subprocess.STDOUT)
    rows.append(dict(label=label,command=command,enabled=enabled,exit_code=result.returncode,seconds=time.monotonic()-start))
    (p/'actual-overlay-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(label,result.returncode,flush=True)
    assert result.returncode==0, (p/(label+'.log')).read_text()[-5000:]

steps = [
    ('retained-before', ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py', 'lazy-schema-candidates-before'], None),
    ('engine-build', [go, 'build', '-p', '2', '-buildvcs=false', '-modfile',
        '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod', '-overlay',
        str(p / 'engine-overlay.json'), '-o', str(p / 'dagger-engine'), './cmd/engine'], '/tmp/dagger-filesync-snapshot-seeds'),
]
rows = []
for label, command, cwd in steps:
    start = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start)
    if label == 'engine-build' and result.returncode == 0:
        row['sha256'] = hashlib.sha256((p / 'dagger-engine').read_bytes()).hexdigest()
    rows.append(row)
    (p / 'engine-builds.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]
