package main

import (
    "context"
    "encoding/json"
    "fmt"
    "net/http"
    "os"
    "strconv"
    "time"

    dagger "dagger.io/dagger"
    core "dagger.io/dagger/core"
    "github.com/dagger/querybuilder"
)

func main() { if err:=run();err!=nil {fmt.Fprintln(os.Stderr,err);os.Exit(1)} }
func run() error {
    ctx:=context.Background()
    c,err:=dagger.Connect(ctx);if err!=nil{return err};defer c.Close()
    q:=core.NewQuery(c)
    source:=q.Host().Directory("/tmp/rust-native-config-entry-1026-before",core.HostDirectoryOpts{Exclude:[]string{".git","target","dagger.toml","dagger.lock"}})
    var rows []map[string]any
    nonce:=strconv.FormatInt(time.Now().UnixNano(),10)
    for _,count:=range []int{1,130,1026} {
        paths:=[]string{"app"}
        if count>1 {paths=append(paths,"shared")}
        for i:=0;len(paths)<count;i++ {paths=append(paths,fmt.Sprintf("leaf_%04d",i))}
        for pair:=0;pair<6;pair++ {
            order:=[]bool{false,true};if pair%2==1 {order=[]bool{true,false}}
            for _,enabled:=range order {
                req,_:=http.NewRequest(http.MethodPost,"http://127.0.0.1:16104/debug/digest-paths-mount?enabled="+strconv.FormatBool(enabled),nil)
                res,err:=http.DefaultClient.Do(req);if err!=nil{return err};res.Body.Close();if res.StatusCode!=200{return fmt.Errorf("mode: %d",res.StatusCode)}
                parent:=source.WithNewFile(".batch-probe-generation",fmt.Sprintf("%s/%d/%d/%t",nonce,count,pair,enabled))
                // Force source evaluation and checksum loading outside the timer.
                if _,err:=parent.Digest(ctx);err!=nil{return err}
                id,err:=parent.ID(ctx);if err!=nil{return err}
                var got []string
                tick:=time.Now()
                err=querybuilder.Query().Client(c.GraphQLClient()).Select("node").Arg("id",id).InlineFragment("Directory").
                    Select("digests").Arg("paths",paths).Bind(&got).Execute(ctx)
                elapsed:=time.Since(tick).Seconds()
                if err!=nil{return err};if len(got)!=count{return fmt.Errorf("got %d digests want %d",len(got),count)}
                for _,digest:=range got {if digest=="" {return fmt.Errorf("empty digest")}}
                rows=append(rows,map[string]any{"count":count,"pair":pair,"enabled":enabled,"seconds":elapsed})
            }
        }
    }
    return json.NewEncoder(os.Stdout).Encode(map[string]any{"rows":rows,"preparation_outside_timer":true,"each_query_has_fresh_parent":true})
}
