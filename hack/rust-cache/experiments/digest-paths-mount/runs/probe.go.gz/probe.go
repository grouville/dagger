package main

import (
    "context"
    "encoding/json"
    "fmt"
    "os"
    "slices"
    "time"

    dagger "dagger.io/dagger"
    core "dagger.io/dagger/core"
    "github.com/dagger/querybuilder"
)

func main() {
    if err := run(); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
}

func run() error {
    if len(os.Args) != 2 { return fmt.Errorf("usage: probe LABEL") }
    ctx := context.Background()
    c, err := dagger.Connect(ctx)
    if err != nil { return err }
    defer c.Close()
    q := core.NewQuery(c)
    constructed := q.Directory().
        WithNewDirectory("empty", core.DirectoryWithNewDirectoryOpts{Permissions:0751}).
        WithNewDirectory("space \"héllo\"", core.DirectoryWithNewDirectoryOpts{Permissions:0701}).
        WithNewFile("outer/nested/file", "héllo", core.DirectoryWithNewFileOpts{Permissions:0600}).
        WithNewFile("root-file", "root").
        WithSymlink("outer", "link").
        WithSymlink("root-file", "file-link").
        WithSymlink("absent", "broken").
        WithSymlink("loop", "loop")
    root, err := os.MkdirTemp("", "digest-paths-probe-")
    if err != nil { return err }
    defer os.RemoveAll(root)
    if _, err := constructed.Export(ctx, root); err != nil { return err }
    sources := []struct{name string; source *core.Directory}{
        {"constructed", constructed},
        {"imported", q.Host().Directory(root)},
    }
    rows := []map[string]any{}
    for _, entry := range sources {
        for _, selected := range []string{".", "outer"} {
            parent := entry.source.Directory(selected).WithNewFile(".generation", os.Args[1])
            id, err := parent.ID(ctx)
            if err != nil { return err }
            read := func(paths []string) ([]string,error) {
                var got []string
                err := querybuilder.Query().Client(c.GraphQLClient()).Select("node").Arg("id",id).InlineFragment("Directory").
                    Select("digests").Arg("paths",paths).Bind(&got).Execute(ctx)
                return got,err
            }
            paths := []string{"", ".", "/", "outer", "outer/nested", "empty", "space \"héllo\"", "link", "missing", "root-file", "file-link", "broken", "loop"}
            if selected == "outer" { paths = []string{".", "nested", "../empty", "nested/file", "missing", "../link", "../broken", "../loop"} }
            valid, expected := []string{},[]string{}
            for _, p := range paths {
                want, wantErr := parent.Directory(p).Digest(ctx)
                got, gotErr := read([]string{".",p})
                if (wantErr == nil) != (gotErr == nil) { return fmt.Errorf("%s/%s/%q error differs: want %v got %v",entry.name,selected,p,wantErr,gotErr) }
                if wantErr == nil {
                    if len(got) != 2 || got[1] != want { return fmt.Errorf("%s/%s/%q digest differs: %q / %q",entry.name,selected,p,want,got) }
                    valid=append(valid,p);expected=append(expected,want)
                }
                rows=append(rows,map[string]any{"source":entry.name,"selected":selected,"path":p,"error":wantErr!=nil})
            }
            slices.Reverse(valid);slices.Reverse(expected)
            valid=append(valid,valid[0]);expected=append(expected,expected[0])
            got,err:=read(valid)
            if err!=nil || !slices.Equal(got,expected) { return fmt.Errorf("ordered batch %s/%s: %v",entry.name,selected,err) }
            got,err=read([]string{})
            if err!=nil || len(got)!=0 { return fmt.Errorf("empty batch: %v",err) }
        }
    }
    return json.NewEncoder(os.Stdout).Encode(map[string]any{"label":os.Args[1],"passed":len(rows),"cases":rows,"time":time.Now().UTC()})
}
