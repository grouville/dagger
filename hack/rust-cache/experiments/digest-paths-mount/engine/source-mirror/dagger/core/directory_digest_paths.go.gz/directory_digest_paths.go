package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net/http"
	"os"
	"path"
	"strconv"
	"sync/atomic"
	"syscall"

	"github.com/containerd/containerd/v2/core/mount"
	containerdfs "github.com/containerd/continuity/fs"
	"github.com/dagger/dagger/dagql"
	bkcontenthash "github.com/dagger/dagger/engine/contenthash"
)

var digestPathsOneMount atomic.Bool

// DigestPaths shares snapshot evaluation and stat mounts across a batch.
// Results preserve DigestPath's order, validation and canonical hash format.
func (dir *Directory) DigestPaths(ctx context.Context, self dagql.ObjectResult[*Directory], paths []string) ([]string, error) {
	if !digestPathsOneMount.Load() || len(paths) < 2 {
		digests := make([]string, len(paths))
		for i, subdir := range paths {
			digest, err := dir.DigestPath(ctx, self, subdir)
			if err != nil {
				return nil, err
			}
			digests[i] = digest
		}
		return digests, nil
	}
	snapshot, err := dir.Snapshot.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, fmt.Errorf("failed to evaluate directory: %w", err)
	}
	if snapshot == nil {
		return nil, fmt.Errorf("failed to evaluate null directory")
	}
	base, err := dir.Dir.GetOrEval(ctx, self.Result)
	if err != nil {
		return nil, fmt.Errorf("failed to get directory path: %w", err)
	}
	parentCall, err := self.ResultCall()
	if err != nil {
		return nil, err
	}
	digests := make([]string, len(paths))
	err = MountRef(ctx, snapshot, func(root string, _ *mount.Mount) error {
		for i, subdir := range paths {
			if err := ctx.Err(); err != nil {
				return err
			}
			selected := base
			if cleanDotsAndSlashes(subdir) != "" {
				selected = path.Join(base, subdir)
				resolved, statErr := containerdfs.RootPath(root, selected)
				if statErr == nil {
					info, err := os.Stat(resolved)
					statErr = TrimErrPathPrefix(err, root)
					if statErr == nil && !info.IsDir() {
						return notADirectoryError{fmt.Errorf("path %s is a file, not a directory", subdir)}
					}
				}
				if statErr != nil {
					if errors.Is(statErr, fs.ErrNotExist) {
						statErr = &os.PathError{Op: "stat", Path: subdir, Err: syscall.ENOENT}
					}
					return RestoreErrPath(statErr, subdir)
				}
				if parentCall.ContentDigest() != "" {
					digest, err := GetContentHashFromDirectory(ctx, snapshot, selected)
					if err != nil {
						return err
					}
					digests[i] = digest.String()
					continue
				}
			}
			digest, err := bkcontenthash.Checksum(ctx, snapshot, selected, bkcontenthash.ChecksumOpts{})
			if err != nil {
				return fmt.Errorf("failed to compute digest: %w", err)
			}
			digests[i] = digest.String()
		}
		return nil
	})
	return digests, err
}

func DigestPathsMountDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		digestPathsOneMount.Store(enabled)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": digestPathsOneMount.Load()})
}
