from pathlib import Path
import json
import os
import subprocess
import sys
import time

p=Path(__file__).parent
phase=sys.argv[1]
assert phase in ['before','after']
base=p.parent
env={k:v for k,v in os.environ.items() if k not in {'DAGGER_SESSION_PORT','DAGGER_SESSION_TOKEN','SSH_AUTH_SOCK','DAGGER_CLOUD_TOKEN','DAGGER_CLOUD_URL','DAGGER_ENGINE','DAGGER_CLOUD_ENGINE','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'} and not k.startswith('OTEL_EXPORTER_')}
env.update(GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',DAGGER_CLOUD_URL='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',DAGGER_CLOUD_TOKEN='local-benchmark-token',XDG_CONFIG_HOME='/tmp/rust-cache-oct13-filter/local-client-config',NO_PROXY='*',_EXPERIMENTAL_DAGGER_RUNNER_HOST='tcp://127.0.0.1:16276',_EXPERIMENTAL_DAGGER_CLI_BIN=str(base/'filesync-literal-pathwalk/dagger-after'),_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
command=[go,'test','-p','2','-buildvcs=false','-count=1','-parallel','1','-v','-run','^TestLockfile$/^TestSearchOverlayPaths$','./core/integration']
started=time.monotonic()
with (p/(phase+'-integration.log')).open('w') as output:
 result=subprocess.run(command,cwd='/tmp/dagger-workspace-search-overlay-paths',env=env,stdout=output,stderr=subprocess.STDOUT)
row=dict(label=phase+'-engine-integration',command=command,seconds=time.monotonic()-started,exit_code=result.returncode,expected_exit_code=1 if phase=='before' else 0)
rows=json.loads((p/'validation.json').read_text());rows.append(row);(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
assert result.returncode==row['expected_exit_code'],(p/(phase+'-integration.log')).read_text()[-5000:]
log=(p/(phase+'-integration.log')).read_text()
if phase=='before':
 assert '--- FAIL: TestLockfile/TestSearchOverlayPaths/overlay_file' in log, log[-5000:]
 assert '--- PASS: TestLockfile/TestSearchOverlayPaths/unrelated_missing_path' in log, log[-5000:]
else:
 assert '--- PASS: TestLockfile/TestSearchOverlayPaths' in log, log[-5000:]
