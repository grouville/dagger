# Shutdown observation, not a listing result

During the graceful replacement, goroutine 1 spends the 30-second sample preparing an INSERT in modernc SQLite. The active call is persistdb.InsertMirrorEqClassDigest -> Queries.exec -> sql.Tx.ExecContext -> sqlite3_prepare_v2, inside Cache.applyPersistStateSnapshot. The mirror row methods pass nil prepared statements; persistdb.Prepare currently prepares only the two metadata statements. Current main has the same code. The state snapshot inserts many rows one by one in a single transaction.

A concrete later experiment is transaction-scoped prepared mirror statements, preserving bindings, transaction boundaries, rollback and storage format. No such change is implemented or measured here. This observation concerns save/checkpoint and shutdown, not the complete-command listing critical path. No speedup claim or new proposal follows from a stack sample. Do not mix a benchmark of this work with the current Go discovery comparison.
