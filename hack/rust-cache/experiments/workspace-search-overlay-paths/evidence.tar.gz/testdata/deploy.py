from pathlib import Path
import json
import subprocess
import time

p=Path(__file__).parent
module=p.parent/'go-workspace-package-test-search'
steps=[('build-driver',['python3',str(p/'build-engine.py')]),
       ('install-driver',['python3',str(p/'install-engine.py')]),
       ('after-integration',['python3',str(p/'integration.py'),'after']),
       ('go-module-checks',['python3',str(module/'verify.py')])]
rows=[]
for label,command in steps:
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,seconds=time.monotonic()-start,exit_code=result.returncode)
    rows.append(row)
    (p/'deployment-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(row,flush=True)
    assert result.returncode==0,(p/(label+'.log')).read_text()[-5000:]
print('PASS: scoped upstream regression and real Go collection checks pass; retained Rust compilations remain reusable.',flush=True)
