from pathlib import Path
import subprocess

p=Path(__file__).parent
root=Path('/tmp/dagger-workspace-search-overlay-paths')
source=root/'core/schema/workspace.go'
s=source.read_text()
old='\t\tif _, ok := ws.OverlayChanges(); ok && ws.ClientLocalBase() {\n\t\t\toverlayResults, err := s.overlaySearchResults(ctx, ws, args)\n\t\t\tif err != nil {\n\t\t\t\treturn nil, fmt.Errorf("search: %w", err)\n\t\t\t}\n\t\t\tresults = mergeSearchResults(results, overlayResults, ws.OverlayPathTouched, args.Limit)\n\t\t}\n'
assert s.count(old)==1
s=s.replace(old,'')
anchor='\n\t// Mounted content is readable through the normal workspace file tools, so'
addition='\n\t// The overlay may be the only source for every requested path.\n\tif _, ok := ws.OverlayChanges(); ok && ws.ClientLocalBase() {\n\t\toverlayResults, err := s.overlaySearchResults(ctx, ws, args)\n\t\tif err != nil {\n\t\t\treturn nil, fmt.Errorf("search: %w", err)\n\t\t}\n\t\tresults = mergeSearchResults(results, overlayResults, ws.OverlayPathTouched, args.Limit)\n\t}\n'
start=s.index('func (s *workspaceSchema) search(')
end=s.index('\n}',start)+2
body=s[start:end]
assert body.count(anchor)==1
s=s[:start]+body.replace(anchor, addition+anchor)+s[end:]
anchor='\n\tif ws.HostPath() != "" && ws.ClientLocalBase() {'
start=s.index('func (s *workspaceSchema) workspaceReadPathExists(')
end=s.index('\n}',start)+2
body=s[start:end]
assert body.count(anchor)==1
replacement="\n\treturn s.workspaceBasePathExists(ctx, ws, resolvedPath)\n}\n\n// workspaceBasePathExists excludes host overlay edits: a path created only\n// in the overlay must not become an operand of the host's ripgrep process.\nfunc (s *workspaceSchema) workspaceBasePathExists(\n\tctx context.Context,\n\tws *core.Workspace,\n\tresolvedPath string,\n) (bool, error) {\n\trp := filepath.ToSlash(resolvedPath)"
body=body.replace(anchor,replacement+anchor)
s=s[:start]+body+s[end:]
start=s.index('func (s *workspaceSchema) searchSourcePaths(')
end=s.index('\n}',start)+2
body=s[start:end]
anchor='\n\tsourcePaths := make([]string, 0, len(paths))'
assert body.count(anchor)==1
body=body.replace(anchor,'\n\thostOverlay := ws.ClientLocalBase() && len(ws.OverlayTouchedPaths()) > 0'+anchor)
old='\t\tif ws.HasMountsUnder(scope) {\n\t\t\texists, err := s.workspaceReadPathExists(ctx, ws, scope)'
new='\t\toverlayUnder := false\n\t\tif hostOverlay {\n\t\t\tif ws.OverlayPathTouched(scope) {\n\t\t\t\tcontinue\n\t\t\t}\n\t\t\tfor _, touched := range ws.OverlayTouchedPaths() {\n\t\t\t\tif scope == "." || strings.HasPrefix(cleanSearchScope(touched), scope+"/") {\n\t\t\t\t\toverlayUnder = true\n\t\t\t\t\tbreak\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t\tif ws.HasMountsUnder(scope) || overlayUnder {\n\t\t\texists, err := s.workspaceBasePathExists(ctx, ws, scope)'
assert body.count(old)==1
body=body.replace(old,new)
s=s[:start]+body+s[end:]
s=s.replace('// Paths uninvolved with mounts pass through untouched, so a genuinely', '// Host overlay edits also shadow the base. Their explicit paths are dropped,\n// and ancestors created only by the overlay are omitted from the host search.\n// Paths uninvolved with mounts or overlays pass through untouched, so a genuinely')
s=s.replace('// search entirely to mounted content.', '// search entirely to mounted or host-overlay content.')
source.write_text(s)
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/gofmt'
subprocess.run([go,'-w',str(source)],check=True)
(p/'standalone.patch').write_text(subprocess.check_output(['git','diff','--','core/schema/workspace.go','core/schema/workspace_overlay_search_test.go'],cwd=root,text=True))
print('Applied scoped source routing fix.',flush=True)
