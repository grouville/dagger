from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for arm in ['before','after']:
 command=[go,'test','-p','2','-buildvcs=false','-mod=readonly','-overlay',str(p/('main-'+arm+'-overlay.json')),'-race','-count=1','-run','^(Test.*(EqClass|Egraph|Metadata).*|TestCompactEqClassesKeepsTheLiveContents)$','./dagql']
 tick=time.monotonic()
 with (p/('main-'+arm+'-race.log')).open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-cache-compaction-digest-sets',env=env,stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(arm=arm,command=command,exit_code=r.returncode,seconds=time.monotonic()-tick));(p/'main-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(arm,r.returncode,flush=True)
 if r.returncode:print((p/('main-'+arm+'-race.log')).read_text()[-5000:],flush=True)
 assert r.returncode==0
