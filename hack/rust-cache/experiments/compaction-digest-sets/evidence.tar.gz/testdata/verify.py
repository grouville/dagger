from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
subprocess.run([str(Path(go).with_name('gofmt')),'-w',*[str(p/name) for name in ['before-cache_egraph.go','after-cache_egraph.go','benchmark_test.go']]],check=True)
rows=[]
for arm in ['before','after']:
 command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/(arm+'-overlay.json')),'-race','-count=1','-run','^(Test.*(EqClass|Egraph|Metadata).*|TestCompactEqClassesKeepsTheLiveContents)$','./dagql']
 tick=time.monotonic()
 with (p/(arm+'-race.log')).open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(arm=arm,command=command,exit_code=r.returncode,seconds=time.monotonic()-tick));(p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(arm,r.returncode,flush=True)
 if r.returncode:print((p/(arm+'-race.log')).read_text()[-5000:],flush=True)
 assert r.returncode==0
