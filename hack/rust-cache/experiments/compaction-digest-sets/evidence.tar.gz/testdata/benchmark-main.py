from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
assert all(r['exit_code']==0 for r in json.loads((p/'main-validation.json').read_text()))
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
subprocess.run([str(Path(go).with_name('gofmt')),'-w',str(p/'benchmark_test.go')],check=True)
rows=[]
for pair in range(4):
 for arm in (['after','before'] if pair%2==0 else ['before','after']):
  label=f'main-{pair}-{arm}'
  command=[go,'test','-p','2','-buildvcs=false','-mod=readonly','-overlay',str(p/('main-'+arm+'-overlay.json')),'-run=^$','-bench=^BenchmarkCompactLiveDigestSets$','-benchtime=1x','-count=1','-cpu=8','-benchmem','./dagql']
  tick=time.monotonic()
  with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-cache-compaction-digest-sets',env=env,stdout=out,stderr=subprocess.STDOUT)
  record=dict(label=label,pair=pair,arm=arm,command=command,exit_code=r.returncode,process_seconds=time.monotonic()-tick);rows.append(record);(p/'main-benchmark-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True)
  assert r.returncode==0,(p/(label+'.log')).read_text()[-3000:]
results=[]
for r in rows:
 for line in (p/(r['label']+'.log')).read_text().splitlines():
  if not line.startswith('BenchmarkCompactLiveDigestSets/'):continue
  words=line.split();metrics={words[i+1]:float(words[i]) for i in range(2,len(words)-1,2)}
  results.append(dict(pair=r['pair'],arm=r['arm'],case=words[0].split('/')[1].removesuffix('-8'),metrics=metrics))
assert len(results)==16,results
summary={case:{arm:{field:statistics.median(r['metrics'][field] for r in results if r['case']==case and r['arm']==arm) for field in ['ns/op','write-lock-ns/op','B/op','allocs/op']} for arm in ['before','after']} for case in sorted({r['case'] for r in results})}
(p/'main-component-results.json').write_text(json.dumps(results,indent=2)+'\n');(p/'main-component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
