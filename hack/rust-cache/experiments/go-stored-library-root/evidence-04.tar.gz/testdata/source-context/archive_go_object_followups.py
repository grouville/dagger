from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

base = Path('/tmp/rust-cache-sipsma-review')
repo = Path('/home/dagger/dagger_otra/hack/rust-cache')
studies = {
    'go-stored-library-root': ('Native library objects and complete Go listing comparisons', 'NATIVE_GO_OBJECT_SCHEMAS.md'),
    'recovered-schema-templates': ('Recovered-schema sharing: component gain, no full-command gain', 'NATIVE_GO_OBJECT_SCHEMAS.md'),
    'recovered-schema-stable-core': ('Stable core-provider identity and recovered schemas', 'NATIVE_GO_OBJECT_SCHEMAS.md'),
}
allowed = {'.go', '.py', '.json', '.jsonl', '.log', '.pprof', '.gz', '.txt',
           '.stdout', '.stderr', '.md', '.mod', '.sum', '.dang', '.patch', '.peg',
           '.ndjson', '.sh', '.toml'}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


# Timing must be complete before copying, compressing or verifying evidence.
isolation = base / 'go-stored-library-root/paired-engine-only'
assert (isolation / 'summary.json').exists(), 'Engine-only timing is still active'
restored = json.loads((isolation / 'restored-state.json').read_text())
assert restored['flags_restored'] and restored['source'] and restored['test_source']
assert not restored['profiling']
assert all(row['exit_code'] == 0 for row in json.loads((base / 'recovered-schema-stable-core/pipeline.json').read_text()))

for name, (title, report) in studies.items():
    source = base / name
    out = repo / 'experiments' / name
    assert not out.exists(), out
    context = source / 'source-context'
    context.mkdir()
    overlays = list(dict.fromkeys([*[base / stage / 'engine-overlay.json' for stage in ['go-session-log-controls','recovered-schema-templates','recovered-schema-stable-core']], *sorted(source.glob('*overlay*.json'))]))
    mappings = []
    for overlay in overlays:
        for destination, original in sorted(json.loads(overlay.read_text())['Replace'].items()):
            original = Path(original)
            sha = digest(original)
            target = context / (sha[:16] + '-' + original.name)
            if target.exists():
                assert digest(target) == sha
            else:
                shutil.copyfile(original, target)
            mappings.append(dict(overlay=str(overlay), destination=destination,
                source=str(original), archived_source=str(target.relative_to(source)), sha256=sha))
    (context / 'OVERLAYS.json').write_text(json.dumps(mappings, indent=2) + '\n')
    copies = {
        'engine.go.mod': base / 'otel-evicted-queue/engine.go.mod',
        'engine.go.sum': base / 'otel-evicted-queue/engine.go.sum',
        'listing-protocol.py': base / 'rust-go-test-collections/measure.py',
        'local_cli_collector.py': base / 'local_cli_collector.py',
        'verify_retained_first.py': base / 'trivial-scalar-projection/verify_retained_first.py',
        'restart_owned_engine_clean.py': base / 'restart_owned_engine_clean.py',
        'selected-go.dang': Path('/tmp/dagger-go-module-test-name-index/go.dang'),
        'selected-gomod-main.dang': Path('/tmp/dagger-go-module-test-name-index/gomod/main.dang'),
        'expected-listing.stdout': base / 'glob-literal-prefix/full-command-paired/0-before.stdout',
        'archive_go_object_followups.py': Path(__file__),
        'go-dev-main.dang': Path('/tmp/dagger-go-stored-library-root/.dagger/modules/go-dev/main.dang'),
        'go-module-dagger.toml': Path('/tmp/dagger-go-stored-library-root/dagger.toml'),
    }
    for target, original in copies.items():
        shutil.copyfile(original, context / target)
    runtime = base / 'dang-module-blueprint-content-key'
    for original in [runtime / 'go.mod', runtime / 'go.sum', *sorted((runtime / 'pkg').rglob('*'))]:
        if not original.is_file() or original.suffix not in {'.go', '.dang', '.peg', '.mod', '.sum'}:
            continue
        target = context / 'dang-runtime' / original.relative_to(runtime)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original, target)
    for filename in ['go.mod', 'go.sum']:
        shutil.copyfile(Path('/tmp/dagger-clone-sealed-metadata-outside-lock') / filename,
                        context / ('upstream-main-' + filename))
    histories = sorted([history for prefix in ['recovered-schema-templates','recovered-schema-stable-core'] for history in base.glob('native-discovery-retained-' + prefix + '*')])
    for history in histories:
        assert len(list(history.glob('*.log'))) == 6, history
        for original in sorted(history.rglob('*')):
            if original.is_file() and original.suffix in {'.log', '.json'}:
                target = context / history.name / original.relative_to(history)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(original, target)
    files, omitted = [], []
    for f in sorted(source.rglob('*')):
        if not f.is_file() or f.suffix not in allowed or f.name.startswith('dagger-engine'):
            continue
        if f.name == 'wcprof-complete.ndjson':
            omitted.append(dict(source=str(f), sha256=digest(f), bytes=f.stat().st_size,
                reason='Reconstructable from the archived compressed recorder chunks and capture driver.'))
            continue
        files.append(dict(path='testdata/' + str(f.relative_to(source)), source=str(f),
                          bytes=f.stat().st_size, sha256=digest(f)))
    out.mkdir()
    groups = []
    group = []
    size = 0
    for row in files:
        assert row['bytes'] < 95 * 1024 * 1024, row['path']
        if group and size + row['bytes'] > 80 * 1024 * 1024:
            groups.append(group)
            group, size = [], 0
        group.append(row)
        size += row['bytes']
    if group:
        groups.append(group)
    archives = []
    for index, group in enumerate(groups):
        archive = out / f'evidence-{index:02d}.tar.gz'
        with tarfile.open(archive, 'w:gz', compresslevel=6) as tf:
            for row in group:
                tf.add(row['source'], arcname=row['path'], recursive=False)
        with tarfile.open(archive, 'r:gz') as tf:
            assert len(tf.getmembers()) == len(group)
            for row in group:
                member = tf.extractfile(row['path'])
                h = hashlib.sha256()
                size = 0
                for chunk in iter(lambda: member.read(1024 * 1024), b''):
                    size += len(chunk)
                    h.update(chunk)
                assert size == row['bytes'] and h.hexdigest() == row['sha256'], row['path']
        assert archive.stat().st_size < 100 * 1024 * 1024
        archives.append(dict(path=archive.name, bytes=archive.stat().st_size, sha256=digest(archive), members=len(group)))
        for row in group:
            row['archive'] = archive.name
    manifest = dict(archives=archives, files=files, omitted_reconstructable=omitted,
        all_attempts_retained=True, new_pr_opened=False, new_upstream_proposal=False,
        candidate_selected_in_engine=False, controlled_engine_base='19eda924854e7f22582f3a7430272aa729cbeb5f',
        standalone_main_base='ff0b029a4d270a651b9a8c7286babc79089066e4')
    (out / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (out / 'README.md').write_text('# ' + title + '\n\nSee [the assessment](../../' + report +
        '). The archive preserves sources, overlays, drivers, every observation and failure, analysis, and retained-cache checks. See the assessment for the measured outcome and selection decision. The earlier rejected attempts remain included; no PR is opened. No PR is opened.\n\n' +
        '`MANIFEST.json` records the size and SHA-256 hash of each of the ' + str(len(files)) +
        ' independently verified members across bounded archives. Expanded wcprof data is omitted in favor of the compressed chunks and reconstruction driver. Engine binaries are identified by hash in the build records.\n')
    print(json.dumps(dict(study=name, files=len(files), archives=len(archives), bytes=sum(row['bytes'] for row in archives), verified=True)), flush=True)
