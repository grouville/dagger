from collections import Counter
from pathlib import Path
import json

p = Path(__file__).parent
baseline = p.parent / 'go-query-phase-detail/capture'
candidate = p / 'capture-stable-core'
counts = Counter()
with (candidate / 'wcprof-complete.ndjson').open() as stream:
    header = json.loads(next(stream))
    assert header['dropped_events'] == 0 and not header.get('open_ops')
    for line in stream:
        event = json.loads(line)
        if event['e'] == 'op':
            counts[header['strings'][event['c']]] += 1

before = json.loads((baseline / 'field-preparation-groups.json').read_text())
after = json.loads((candidate / 'field-preparation-groups.json').read_text())
fields = sorted(set(before['fields']) | set(after['fields']))
changes = {name: dict(before=before['fields'].get(name, {}).get('count', 0),
                      after=after['fields'].get(name, {}).get('count', 0))
           for name in fields}
before_requests = json.loads((baseline / 'causal-requests.json').read_text())
after_requests = json.loads((candidate / 'causal-requests.json').read_text())
result = dict(
    scope='Operation counts only. Baseline is the prior lossless selected-module capture on engine 7f821dcf. Candidate runs on the new controlled engine with the same field markers; recovered-schema templates are on, metadata and logging candidates remain off. This is not a matched latency comparison.',
    result=json.loads((candidate / 'result.json').read_text()),
    api_requests=dict(before=before_requests['counts']['api'], after=after_requests['counts']['api']),
    field_preparations=changes,
    candidate_operation_counts={name: count for name, count in counts.most_common(80)},
    exact_parent_links_valid=(after_requests['matched'] == after_requests['counts']['api'] and not after_requests['unmatched']))
(p / 'work-reduction-stable-core.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(api_requests=result['api_requests'],
    constructor=changes.get('gomod:Query.gomod'),
    exact_parent_links_valid=result['exact_parent_links_valid'],
    result=result['result']), indent=2))
