from collections import Counter, defaultdict
from pathlib import Path
import json
import statistics

p = Path(__file__).parent / 'capture-with-template'
ops = {}
children = defaultdict(list)
intervals = defaultdict(list)
with (p / 'wcprof-complete.ndjson').open() as stream:
    header = json.loads(next(stream))
    names = header['strings']
    for line in stream:
        event = json.loads(line)
        if event['e'] == 'op':
            event['cls'] = names[event['c']]
            ops[event['id']] = event
            children[event.get('p', 0)].append(event)
        if event['e'] in ['op', 'wait']:
            intervals[event.get('p', 0)].append((event['s'], event['d']))
assert header['dropped_events'] == 0 and not header.get('open_ops')

def seconds(event):
    return (event['d'] - event['s']) / 1e9

def own_seconds(event):
    spans = sorted((max(event['s'], start), min(event['d'], end))
                   for start, end in intervals[event['id']]
                   if end > event['s'] and start < event['d'])
    covered = 0
    stop = event['s']
    for start, end in spans:
        covered += max(0, end - max(start, stop))
        stop = max(stop, end)
    return max(0, event['d'] - event['s'] - covered) / 1e9

classes = ['dagql.prepareField', 'dagql.invokeField', 'dagql.resolveField',
           'dagql.parseSelections', 'dagql.instantiateResult',
           'dagql.validateOperation', 'dagql.marshalResponse',
           'dagql.releaseOperationLease']
groups = defaultdict(list)
preparation = defaultdict(list)
association = Counter()
for event in ops.values():
    if event['cls'] not in classes:
        continue
    own = own_seconds(event)
    row = dict(id=event['id'], parent=event.get('p', 0), seconds=seconds(event), own_seconds=own)
    groups[event['cls']].append(row)
    if event['cls'] != 'dagql.prepareField':
        continue
    # A GraphQL field has its own resolveField scope. Associate its preparation
    # only with its unique sibling invocation and that invocation's direct call.
    # Concurrent internal selections sharing a context are left unclassified.
    parent = ops.get(event.get('p', 0))
    field = '<unclassified>'
    if parent is not None and parent['cls'] == 'dagql.resolveField':
        invokes = [op for op in children[parent['id']] if op['cls'] == 'dagql.invokeField']
        if len(invokes) == 1:
            calls = [op for op in children[invokes[0]['id']] if op['k'] == 'call']
            if len(calls) == 1:
                field = calls[0]['cls']
    association[field != '<unclassified>'] += 1
    preparation[field].append(row)

def stats(rows):
    durations = sorted(row['seconds'] for row in rows)
    return dict(count=len(rows), summed_seconds=sum(durations),
                summed_own_seconds=sum(row['own_seconds'] for row in rows),
                median_seconds=statistics.median(durations),
                p95_seconds=durations[min(len(durations)-1, int(len(durations)*.95))],
                max_seconds=max(durations),
                longest_own=sorted(rows, key=lambda row: row['own_seconds'], reverse=True)[:12])

assert all(groups[name] for name in classes), [name for name in classes if not groups[name]]
result = dict(scope='Diagnostic phase durations. Sums overlap across concurrent calls and are not command time. Own intervals exclude direct child operations and waits but may still contain uninstrumented blocking.',
              phases={name: stats(rows) for name, rows in groups.items()})
(p / 'phase-details.json').write_text(json.dumps(result, indent=2) + '\n')
fields = {name: stats(rows) for name, rows in preparation.items()}
(p / 'field-preparation-groups.json').write_text(json.dumps(dict(
    scope='Exact unique sibling/direct-child association only; no temporal or argument inference.',
    classified=association[True], unclassified=association[False], fields=fields), indent=2) + '\n')
print(json.dumps({name: {key: value for key, value in stats(rows).items() if key != 'longest_own'}
                  for name, rows in groups.items()}, indent=2))
