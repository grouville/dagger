# Retain one immutable library root per Go tool

The detailed capture records 4333 `gomod:Query.gomod` calls, with substantial preparation while resolving their dynamic module inputs. Both Go.lib and GoModule.lib reconstruct the same dependency root from fixed includeExtraFiles settings. Gomod.new only stores that setting and returns self.

Prototype storing the root in Go.new and passing it into GoModule records. Both bindings become private stored fields. Package keys, test discovery, batching, workspace arguments and current module-layout validation stay the same. This is an ordinary typed dependency result, not an additional cache. Validate SDK client rebinding, dependency retention and retained package objects used with edited workspaces.

Construction becomes eager, so dependency/configuration errors can surface earlier, even when a caller only reads Go.warnings. Treat that as a compatibility tradeoff, not an accepted API change. Do not publish or relax current-error tests for a speedup. The first setup script mistakenly assumed each binding occurred only once; it stopped before changing any running module. Preserve that failed assumption.

After the active engine cohorts finish, create an isolated module worktree and run the established GoDev checks one at a time. Then one lossless diagnostic must prove actual constructor/API work reduction and all 4398 ordered rows. Fewer constructor nodes may not mean fewer HTTP requests because a query can contain several nodes. Only run a fixed complete-command comparison after correctness and work reduction pass. Keep every failure and avoid overlapping workloads.

The first discovery check rejects the initial prototype at module load: an implicit GoModule constructor cannot take the external Gomod type. All sources and the failed check are retained in attempt-0-external-constructor. The refined prototype passes the local Go object instead, as GoPackages and GoPackage already do. Go stores the native dependency root; GoModule reads tool.lib through a computed private accessor. No engine validation is bypassed.

Final status: the refined combined prototype is 38.30 ->35.86 seconds, faster in all four fixed full-command pairs. The independent engine-only isolation is 37.41 ->37.67 seconds, faster in only two of four pairs, and is rejected. The combined result is not a generic engine-only gain, is not additive to earlier cohorts, and adds no upstream proposal or PR. All controls remain off after verification; current default module is unchanged. All rows, exits and source/flag restoration checks pass.
