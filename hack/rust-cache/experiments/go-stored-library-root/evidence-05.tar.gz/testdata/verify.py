from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time
import urllib.request

study = Path(__file__).parent
base = study.parent
module = Path('/tmp/dagger-go-stored-library-root')
debug = 'http://127.0.0.1:16104/debug/'


def get(route):
    with urllib.request.urlopen(debug + route, timeout=30) as response:
        return json.load(response)


assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == dict(mutex_fraction=0, block_profile_rate_ns=0)
for route in ['metadata-snapshot-unlocked', 'upstream-log-queue']:
    assert not get(route)['enabled'], route

env = dict(os.environ,
    RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16276',
    RUST_CACHE_BENCH_CLI=str(base / 'filesync-literal-pathwalk/dagger-after'),
    RUST_CACHE_BENCH_COLLECTOR='http://' + (base / 'otlp-null-address.txt').read_text().strip() + ':43184',
    _EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')

checks = []
for line in (module / '.dagger/modules/go-dev/main.dang').read_text().splitlines():
    if '@check' in line:
        match = re.match(r'^  ([a-zA-Z][a-zA-Z0-9_]*)', line)
        assert match, line
        checks.append(re.sub(r'([A-Z])', r'-\1', match[1]).lower())
priority = ['discovery-check', 'collection-check', 'tests-collection-check',
            'package-layout-rebind-check', 'base-check', 'module-introspection-check']
assert set(priority) <= set(checks)
checks = priority + [check for check in checks if check not in priority]
(study / 'check-plan.json').write_text(json.dumps(dict(
    checks=checks, execution='One check at a time; stop at the first failure.',
    candidate_sha256=hashlib.sha256((module / 'go.dang').read_bytes()).hexdigest(),
    module=str(module)), indent=2) + '\n')

fixture = module / 'testdata/go-module-with-testdata/fixture_test.go'
original = fixture.read_bytes()
rows = []
try:
    fixture.write_bytes(original + ('\n// Stored dependency root verification ' + str(time.time_ns()) + '\n').encode())
    for check in checks:
        tick = time.monotonic()
        with (study / ('go-dev-' + check + '.log')).open('w') as output:
            result = subprocess.run(['python3', str(base / 'local_cli_collector.py'),
                                     'check', 'go-dev:' + check], cwd=module, env=env,
                                    stdout=output, stderr=subprocess.STDOUT)
        row = dict(check=check, exit_code=result.returncode, seconds=time.monotonic() - tick)
        rows.append(row)
        (study / 'correctness.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        assert result.returncode == 0, check
finally:
    fixture.write_bytes(original)
    (study / 'correctness-restoration.json').write_text(json.dumps(dict(
        fixture_restored=fixture.read_bytes() == original,
        candidate_unchanged=(module / 'go.dang').read_bytes() == (study / 'after-go.dang').read_bytes(),
        checks_completed=len(rows), checks_planned=len(checks)), indent=2) + '\n')
