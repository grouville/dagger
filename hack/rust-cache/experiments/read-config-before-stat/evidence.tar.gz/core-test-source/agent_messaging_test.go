package core

import (
	"context"
	"sync"
	"testing"

	"github.com/dagger/dagger/dagql"
	"github.com/stretchr/testify/require"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/sdk/trace/tracetest"

	"github.com/dagger/dagger/engine/telemetryattrs"
)

// TestAttributionHeader pins the deterministic, model-facing header forms
// (hack/designs/agent-messaging.md §4.1). Determinism is load-bearing:
// replay recordings compare wire text byte for byte, which is why headers
// carry per-runtime ordinals rather than minted message IDs.
func TestAttributionHeader(t *testing.T) {
	t.Parallel()

	require.Equal(t, "", (*LLMMessageOrigin)(nil).AttributionHeader())
	require.Equal(t, "", (&LLMMessageOrigin{Kind: LLMMessageOriginUser}).AttributionHeader())
	require.Equal(t,
		`[message #3 from agent "scout"]`,
		(&LLMMessageOrigin{Kind: LLMMessageOriginAgent, AgentName: "scout", Ref: "#3"}).AttributionHeader())
	require.Equal(t,
		`[reply from agent "chief" to your message #2]`,
		(&LLMMessageOrigin{Kind: LLMMessageOriginAgent, AgentName: "chief", Ref: "#5", ReplyTo: "#2"}).AttributionHeader())
	require.Equal(t,
		`[event from agent "scout"]`,
		(&LLMMessageOrigin{Kind: LLMMessageOriginEvent, AgentName: "scout"}).AttributionHeader())
	require.Equal(t,
		`[reply to your message #4]`,
		(&LLMMessageOrigin{Kind: LLMMessageOriginUser, ReplyTo: "#4"}).AttributionHeader())
}

// TestRenderMessagesForModel covers the request-build-time render: the
// stored history keeps clean text plus structured origin, and only the wire
// form carries the header.
func TestRenderMessagesForModel(t *testing.T) {
	t.Parallel()

	plain := &LLMMessage{
		Role:    LLMMessageRoleUser,
		Content: []*LLMContentBlock{{Kind: LLMContentText, Text: "hello"}},
	}
	attributed := &LLMMessage{
		Role:    LLMMessageRoleUser,
		Content: []*LLMContentBlock{{Kind: LLMContentText, Text: "what branch?"}},
		Origin:  &LLMMessageOrigin{Kind: LLMMessageOriginAgent, AgentName: "scout", Ref: "#1"},
	}
	assistant := &LLMMessage{
		Role:    LLMMessageRoleAssistant,
		Content: []*LLMContentBlock{{Kind: LLMContentText, Text: "on it"}},
	}

	rendered := renderMessagesForModel([]*LLMMessage{plain, attributed, assistant})
	require.Len(t, rendered, 3)
	require.Same(t, plain, rendered[0], "messages without headers pass through untouched")
	require.Same(t, assistant, rendered[2])
	require.Equal(t,
		"[message #1 from agent \"scout\"]\n\nwhat branch?",
		rendered[1].TextContent())
	require.Equal(t, "what branch?", attributed.TextContent(),
		"the stored message must keep its clean text")

	// A history with no attributed messages is returned as-is, not copied.
	untouched := []*LLMMessage{plain, assistant}
	require.Equal(t, untouched, renderMessagesForModel(untouched))
}

func TestOriginOmittedFromChain(t *testing.T) {
	t.Parallel()

	// The unmarked common case: a plain user prompt.
	require.True(t, originOmittedFromChain(&LLMMessageOrigin{Kind: LLMMessageOriginUser}, "", "self"))
	// A plain self-send: an agent steering itself.
	require.True(t, originOmittedFromChain(&LLMMessageOrigin{Kind: LLMMessageOriginAgent}, "self", "self"))
	// Another agent's message records.
	require.False(t, originOmittedFromChain(&LLMMessageOrigin{Kind: LLMMessageOriginAgent}, "other", "self"))
	// A reply marker always records, whoever sent it.
	require.False(t, originOmittedFromChain(&LLMMessageOrigin{Kind: LLMMessageOriginUser, ReplyTo: "#2"}, "", "self"))
	// Events always record.
	require.False(t, originOmittedFromChain(&LLMMessageOrigin{Kind: LLMMessageOriginEvent}, "other", "self"))
}

// twoAgentRegistry builds a registry holding runtimes for two named agents
// and returns caller contexts for each — the harness for waits-for guard
// tests.
func twoAgentRegistry(t *testing.T) (ars *AgentRuntimes, rtA, rtB *AgentRuntime, ctxA, ctxB context.Context) {
	t.Helper()
	base := context.Background()
	ctxA = testAgentContext(t, base, "agent-a", "chief")
	ctxB = testAgentContext(t, base, "agent-b", "scout")
	agentA, ok := AgentFromContext(ctxA)
	require.True(t, ok)
	agentB, ok := AgentFromContext(ctxB)
	require.True(t, ok)

	ars = NewAgentRuntimes()
	var err error
	rtA, err = ars.Create(base, agentA, AgentStateIdle, "", false, "")
	require.NoError(t, err)
	rtB, err = ars.Create(base, agentB, AgentStateIdle, "", false, "")
	require.NoError(t, err)
	return ars, rtA, rtB, ctxA, ctxB
}

func TestAgentSendContent(t *testing.T) {
	for _, state := range []string{"idle", "mid-turn", "paused"} {
		t.Run(state, func(t *testing.T) {
			ars, _, rt, _, receiverCtx := twoAgentRegistry(t)
			receiver, ok := AgentFromContext(receiverCtx)
			require.True(t, ok)
			// Hold the loop at a deterministic boundary without a provider.
			rt.started = true
			rt.turnOpen = state == "mid-turn"
			rt.stepping = state == "mid-turn"
			rt.paused = state == "paused"
			image := &LLMContentBlock{Kind: LLMContentImage, MIMEType: "image/png", Data: []byte("hello")}
			blocks := []*LLMContentBlock{image, {Kind: LLMContentText, Text: "after"},
				{Kind: LLMContentAudio, MIMEType: "audio/wav", Data: image.Data},
				{Kind: LLMContentDocument, MIMEType: "application/pdf", Data: image.Data}}
			want := append([]*LLMContentBlock{{Kind: LLMContentText, Text: "before"}}, cloneLLMContent(blocks)...)
			msg, err := ars.Send(context.Background(), receiver, "before", "#9", blocks...)
			require.NoError(t, err)
			mediaOnly, err := ars.Send(context.Background(), receiver, "", "", image)
			require.NoError(t, err)
			legacy, err := ars.Send(context.Background(), receiver, "legacy", "")
			require.NoError(t, err)
			empty, err := ars.Send(context.Background(), receiver, "", "")
			require.NoError(t, err)
			require.Equal(t, []string{msg.Ref, mediaOnly.Ref, legacy.Ref, empty.Ref}, rt.mailbox)
			// Mutating caller-owned pointers and the input slice cannot alter queued data.
			image.Data = []byte("other")
			blocks[1].Text = "mutated"
			blocks[0] = nil
			rec := rt.messages[msg.Ref]
			require.Equal(t, want, rec.content)
			require.Equal(t, msg.Ref, rec.origin.Ref)
			require.Equal(t, "#9", rec.origin.ReplyTo)
			hint := AgentMessageStarted
			switch state {
			case "mid-turn":
				hint = AgentMessageSteered
			case "paused":
				hint = AgentMessageQueued
			}
			require.Equal(t, hint, rec.deliveryHint)
			require.False(t, rec.consumed)

			// This is the exact selector drainMailbox records at the next boundary.
			sel, err := rec.selector(rt.key)
			require.NoError(t, err)
			require.Equal(t, "withContent", sel.Field)
			inputs := sel.Args[0].Value.(dagql.ArrayInput[dagql.InputObject[LLMContentBlockInput]])
			restored := make([]*LLMContentBlock, len(inputs))
			for i, input := range inputs {
				restored[i], err = input.Value.Resolve(context.Background())
				require.NoError(t, err)
			}
			origin := sel.Args[1].Value.(dagql.Optional[dagql.InputObject[LLMMessageOriginInput]]).Value.Value.ToLLMMessageOrigin()
			require.Equal(t, rec.origin, origin)
			llm := (&LLM{endpointMtx: &sync.Mutex{}, mcp: &MCP{}}).WithContent(restored, origin)
			require.Len(t, llm.Messages, 1)
			require.Equal(t, want, llm.Messages[0].Content)
			require.Len(t, rt.messages[mediaOnly.Ref].content, 1)
			require.Equal(t, want[1], rt.messages[mediaOnly.Ref].content[0])
			for ref, text := range map[string]string{legacy.Ref: "legacy", empty.Ref: ""} {
				sel, err := rt.messages[ref].selector(rt.key)
				require.NoError(t, err)
				require.Equal(t, dagql.Selector{Field: "withPrompt", Args: []dagql.NamedInput{{Name: "prompt", Value: dagql.NewString(text)}}}, sel)
			}
		})
	}
}

func TestAgentSendContentValidationBeforeReply(t *testing.T) {
	ars, sender, receiver, senderCtx, receiverCtx := twoAgentRegistry(t)
	to, ok := AgentFromContext(receiverCtx)
	require.True(t, ok)
	receiver.started = true
	ref, err := sender.enqueue("question", nil, "")
	require.NoError(t, err)
	sender.messages[ref].consumed = true
	large := &LLMContentBlock{Kind: LLMContentImage, MIMEType: "image/png", Data: make([]byte, MaxLLMMediaBytes/2+1)}
	for name, blocks := range map[string][]*LLMContentBlock{
		"nil":            {nil},
		"tool call":      {{Kind: LLMContentToolCall}},
		"tool result":    {{Kind: LLMContentToolResult, Text: "not user content"}},
		"thinking":       {{Kind: LLMContentThinking, Text: "private"}},
		"invalid media":  {{Kind: LLMContentImage, MIMEType: "text/plain", Data: []byte("bad")}},
		"aggregate size": {large, large},
	} {
		t.Run(name, func(t *testing.T) {
			_, err := ars.Send(senderCtx, to, "answer", ref, blocks...)
			require.Error(t, err)
			require.Empty(t, receiver.mailbox)
			require.Empty(t, receiver.messages)
			require.Zero(t, receiver.msgSeq)
			require.False(t, sender.messages[ref].resolved, "invalid sends must not resolve replyTo")
		})
	}
	msg, err := ars.Send(senderCtx, to, "answer", ref, &LLMContentBlock{Kind: LLMContentText, Text: "details"})
	require.NoError(t, err)
	require.True(t, sender.messages[ref].resolved)
	require.Equal(t, (&LLMMessage{Content: receiver.messages[msg.Ref].content}).TextContent(), sender.messages[ref].reply)
	sel, err := receiver.messages[msg.Ref].selector(receiver.key)
	require.NoError(t, err)
	origin := sel.Args[1].Value.(dagql.Optional[dagql.InputObject[LLMMessageOriginInput]]).Value.Value.ToLLMMessageOrigin()
	require.Equal(t, LLMMessageOriginAgent, origin.Kind)
	require.Equal(t, "chief", origin.AgentName)
	require.Equal(t, msg.Ref, origin.Ref)
	require.Equal(t, ref, origin.ReplyTo)
}

// TestAgentWaitGuard covers hack/designs/agent-messaging.md §4.5: self-waits
// are refused unconditionally, a cycle-closing wait is refused with the named
// path, and releasing an edge reopens it.
func TestAgentWaitGuard(t *testing.T) {
	t.Parallel()

	ars, rtA, rtB, ctxA, ctxB := twoAgentRegistry(t)

	// Self-wait: always refused (async-agents §8's hazard, enforced).
	_, err := ars.beginAgentWait(ctxA, rtA, "awaiting the reply to message #1")
	require.ErrorContains(t, err, `agent "chief" cannot block on itself`)

	// A non-agent caller registers nothing and is never refused.
	release, err := ars.beginAgentWait(context.Background(), rtA, "waiting for IDLE")
	require.NoError(t, err)
	release()

	// chief → scout: fine.
	releaseA, err := ars.beginAgentWait(ctxA, rtB, "awaiting the reply to message #1")
	require.NoError(t, err)

	// scout → chief would close the cycle: refused, naming the whole path.
	_, err = ars.beginAgentWait(ctxB, rtA, "awaiting the reply to message #2")
	require.ErrorContains(t, err, "would deadlock")
	require.ErrorContains(t, err, `agent "scout" → agent "chief" (awaiting the reply to message #2)`)
	require.ErrorContains(t, err, `agent "scout" (awaiting the reply to message #1)`)

	// Releasing the chief's wait reopens the edge.
	releaseA()
	releaseB, err := ars.beginAgentWait(ctxB, rtA, "awaiting the reply to message #2")
	require.NoError(t, err)
	releaseB()
	// Release is idempotent.
	releaseB()
}

// TestResolveReply covers §4.2's reply correlation: an explicit reply
// settles the replied-to record in the SENDER's runtime, whichever token
// form names it, and a mistyped ref is refused loudly.
func TestResolveReply(t *testing.T) {
	t.Parallel()

	ars, rtA, _, _, _ := twoAgentRegistry(t) //nolint:dogsled

	// A question from scout sits consumed in chief's runtime, mid-turn.
	msgID, err := rtA.enqueue("what branch?", &LLMMessageOrigin{
		Kind: LLMMessageOriginAgent, AgentName: "scout",
	}, "agent-b")
	require.NoError(t, err)
	rtA.mu.Lock()
	rec := rtA.messages[msgID]
	rec.consumed = true
	require.Equal(t, "#1", rec.origin.Ref)
	rtA.mu.Unlock()

	// The chief replies: the record resolves with the reply text, so an
	// awaiter of the question gets the direct answer, not the turn end.
	chiefOrigin := &LLMMessageOrigin{Kind: LLMMessageOriginAgent, AgentName: "chief"}
	ref, err := ars.resolveReply("agent-a", chiefOrigin, "#1", "main")
	require.NoError(t, err)
	require.Equal(t, "#1", ref)
	rtA.mu.Lock()
	require.True(t, rec.resolved)
	require.Equal(t, "main", rec.reply)
	rtA.mu.Unlock()

	// Token forms: bare ordinal and the ref itself both resolve.
	ref, err = ars.resolveReply("agent-a", chiefOrigin, "1", "again")
	require.NoError(t, err)
	require.Equal(t, "#1", ref)
	ref, err = ars.resolveReply("agent-a", chiefOrigin, msgID, "again")
	require.NoError(t, err)
	require.Equal(t, "#1", ref)

	// A ref naming nothing is a model mistyping — refused loudly.
	_, err = ars.resolveReply("agent-a", chiefOrigin, "#7", "answer")
	require.ErrorContains(t, err, `agent "chief" has no message #7 to reply to`)

	// A non-agent sender has no runtime to resolve within: the marker
	// passes through for the recipient's pairing only.
	ref, err = ars.resolveReply("", &LLMMessageOrigin{Kind: LLMMessageOriginUser}, "#9", "answer")
	require.NoError(t, err)
	require.Equal(t, "#9", ref)
}

// TestEventDelivery covers §4.3's delivery rules at the runtime level: a
// subscribed transition enqueues an event message with EVENT origin into the
// subscriber's mailbox, the subscribe-time level check fires for an
// already-reached state, and a stopped subscriber drops events rather than
// relaunching.
func TestEventDelivery(t *testing.T) {
	t.Parallel()

	base := context.Background()
	ctxA := testAgentContext(t, base, "agent-a", "chief")
	ctxB := testAgentContext(t, base, "agent-b", "scout")
	agentA, ok := AgentFromContext(ctxA)
	require.True(t, ok)
	agentB, ok := AgentFromContext(ctxB)
	require.True(t, ok)

	ars := NewAgentRuntimes()
	chief, err := ars.Create(base, agentA, AgentStateIdle, "", false, "")
	require.NoError(t, err)
	scout, err := ars.Create(base, agentB, AgentStateIdle, "", false, "")
	require.NoError(t, err)

	// Subscribe the chief to scout completions. Scout is inert (projects
	// IDLE), so the level check fires immediately — the guard against a
	// fast worker settling before the subscription lands.
	require.NoError(t, ars.Notify(base, agentB, agentA, []AgentState{AgentStateIdle, AgentStateFailed}))
	waitForMailbox(t, chief, 1)
	chief.mu.Lock()
	rec := chief.messages[chief.mailbox[0]]
	require.Equal(t, LLMMessageOriginEvent, rec.origin.Kind)
	require.Equal(t, "agent-b", rec.sender)
	require.Equal(t, "scout", rec.origin.AgentName)
	require.Contains(t, rec.text, `Agent "scout" is now idle.`)
	chief.mu.Unlock()

	// An edge into a subscribed state fires once; unsubscribed states are
	// silent. RUNNING (via a fact mutation) is not subscribed; the return
	// to IDLE is. The turn's commit is what makes the idle edge news —
	// idleEventDue is set here exactly as a real drain's commitLast would.
	scout.testTransition(func() { scout.idleEventDue = true; scout.turnOpen = true })
	scout.testTransition(func() { scout.turnOpen = false })
	waitForMailbox(t, chief, 2)

	// An idle edge with NO new committed work — a tombstone relaunch that
	// found nothing to retry, a bare fact toggle — is suppressed: it would
	// re-announce a final reply the subscriber already heard (the stale
	// idle event of the resume-retry flow).
	scout.testTransition(func() { scout.turnOpen = true })
	scout.testTransition(func() { scout.turnOpen = false })
	waitForEventQueueDrained(t, scout)
	chief.mu.Lock()
	require.Len(t, chief.mailbox, 2, "an idle edge without new committed work must not re-announce the old reply")
	chief.mu.Unlock()

	// Self-subscription is refused.
	require.ErrorContains(t, ars.Notify(base, agentB, agentB, []AgentState{AgentStateIdle}),
		`agent "scout" cannot subscribe to its own lifecycle`)

	// A stopped subscriber drops events instead of relaunching: the
	// mailbox count stays put and the tombstone stays STOPPED.
	chief.mu.Lock()
	chief.transitionLocked(func() {
		chief.done = true
		chief.sealed = true
		chief.stopRequested = true
	})
	chief.mu.Unlock()
	scout.testTransition(func() { scout.idleEventDue = true; scout.turnOpen = true })
	scout.testTransition(func() { scout.turnOpen = false })
	waitForEventQueueDrained(t, scout)
	chief.mu.Lock()
	require.Len(t, chief.mailbox, 2, "a stopped subscriber must not receive events")
	require.Equal(t, AgentStateStopped, chief.stateLocked())
	chief.mu.Unlock()
}

// TestDrainWindowProjectsRunning pins the projection across the drain's
// pop-to-commit window: the mailbox empties at the pop but the turn opens
// only after the unlocked withPrompt Select, and the draining fact is what
// keeps the projection from transiently claiming IDLE mid-progress — a lie
// that let wait return a stale reply and Reseed race the drain's
// commit. Pause still outranks it: an interrupt mid-drain parks.
func TestDrainWindowProjectsRunning(t *testing.T) {
	t.Parallel()

	base := context.Background()
	ctx := testAgentContext(t, base, "agent-d", "drainer")
	agent, ok := AgentFromContext(ctx)
	require.True(t, ok)

	ars := NewAgentRuntimes()
	rt, err := ars.Create(base, agent, AgentStateIdle, "", false, "")
	require.NoError(t, err)

	rt.mu.Lock()
	defer rt.mu.Unlock()
	require.Equal(t, AgentStateIdle, rt.stateLocked())
	rt.draining = true
	require.Equal(t, AgentStateRunning, rt.stateLocked(),
		"the pop-to-commit drain window must project RUNNING")
	rt.paused = true
	require.Equal(t, AgentStatePaused, rt.stateLocked(),
		"pause takes priority over the drain window")
}

func waitForMailbox(t *testing.T, rt *AgentRuntime, want int) {
	t.Helper()
	require.Eventually(t, func() bool {
		rt.mu.Lock()
		defer rt.mu.Unlock()
		return len(rt.mailbox) >= want
	}, 5e9, 1e6, "expected %d mailbox entries", want)
}

func waitForEventQueueDrained(t *testing.T, rt *AgentRuntime) {
	t.Helper()
	require.Eventually(t, func() bool {
		rt.mu.Lock()
		defer rt.mu.Unlock()
		return len(rt.eventQueue) == 0 && !rt.eventDispatchRunning
	}, 5e9, 1e6, "expected the event queue to drain")
}

// TestEmitUserMessageSpanRecordsOrigin covers the telemetry half of §4.1's
// client-facing promise: a consumed message's recorded origin rides its
// "LLM prompt" span as dagger.io/llm.origin.* attributes, so frontends can
// attribute another agent's words (and render events compactly) for agents
// they merely observe. A plain user prompt stamps nothing, keeping
// pre-provenance spans unchanged.
func TestEmitUserMessageSpanRecordsOrigin(t *testing.T) {
	_, ctx := stateRecorderCtx(t)
	spans := tracetest.NewSpanRecorder()
	tp := sdktrace.NewTracerProvider(
		sdktrace.WithSampler(sdktrace.AlwaysSample()),
		sdktrace.WithSpanProcessor(spans),
	)
	ctx, parent := tp.Tracer("origin-attrs-test").Start(ctx, "turn")
	defer parent.End()

	emitUserMessageSpan(ctx, &LLMMessage{
		Role:    LLMMessageRoleUser,
		Content: []*LLMContentBlock{{Kind: LLMContentText, Text: "what branch?"}},
		Origin: &LLMMessageOrigin{
			Kind: LLMMessageOriginAgent, AgentName: "scout", Ref: "#3",
		},
	}, "")
	emitUserMessageSpan(ctx, &LLMMessage{
		Role:    LLMMessageRoleUser,
		Content: []*LLMContentBlock{{Kind: LLMContentText, Text: "hello"}},
	}, "")

	ended := spans.Ended()
	require.Len(t, ended, 2)

	attrsOf := func(span sdktrace.ReadOnlySpan) map[string]string {
		attrs := map[string]string{}
		for _, attr := range span.Attributes() {
			attrs[string(attr.Key)] = attr.Value.AsString()
		}
		return attrs
	}

	attributed := attrsOf(ended[0])
	require.Equal(t, telemetryattrs.LLMMessageOriginKindAgent, attributed[telemetryattrs.LLMMessageOriginKindAttr])
	require.Equal(t, "scout", attributed[telemetryattrs.LLMMessageOriginAgentNameAttr])
	require.Equal(t, "#3", attributed[telemetryattrs.LLMMessageOriginRefAttr])
	require.NotContains(t, attributed, telemetryattrs.LLMMessageOriginReplyToAttr)

	plain := attrsOf(ended[1])
	require.NotContains(t, plain, telemetryattrs.LLMMessageOriginKindAttr)
}
