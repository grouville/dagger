package core

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"regexp"
	"sync/atomic"
	"testing"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine"
	"github.com/dagger/dagger/engine/clientdb"
	"github.com/dagger/dagger/internal/cloud"
	"github.com/dagger/dagger/internal/cloud/auth"
	"github.com/dagger/dagger/internal/cloud/otlpstream"
	telemetry "github.com/dagger/otel-go"
	"github.com/stretchr/testify/require"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	collogspb "go.opentelemetry.io/proto/otlp/collector/logs/v1"
	colmetricspb "go.opentelemetry.io/proto/otlp/collector/metrics/v1"
	coltracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
	otlpcommonv1 "go.opentelemetry.io/proto/otlp/common/v1"
	tracepb "go.opentelemetry.io/proto/otlp/trace/v1"
	"golang.org/x/oauth2"
	"google.golang.org/protobuf/proto"
)

func TestLoadTraceInspectionTools(t *testing.T) {
	const traceID = "000102030405060708090a0b0c0d0e0f"
	const rootID = "0000000000000001"
	const callID = "0000000000000002"
	const unfinishedID = "0000000000000003"
	const secret = "test-cloud-credential-never-in-output"
	fixture, digest, _ := callInspectStore(t, callInspectRecipe(t))
	rows, err := fixture.SelectSpansLatest(t.Context(), fixture.SpanIDs())
	require.NoError(t, err)
	var spans []sdktrace.ReadOnlySpan
	for i := range rows {
		spans = append(spans, rows[i].ReadOnly())
	}
	spanReq := &coltracepb.ExportTraceServiceRequest{ResourceSpans: telemetry.SpansToPB(spans)}
	for _, resource := range spanReq.ResourceSpans {
		for _, scope := range resource.ScopeSpans {
			for _, span := range scope.Spans {
				span.StartTimeUnixNano = 100
				span.EndTimeUnixNano = 200
				key, value := telemetry.CheckNameAttr, "cloud:check"
				if hex.EncodeToString(span.SpanId) == callID {
					key, value = "test.case.name", "TestCloud"
				}
				span.Attributes = append(span.Attributes, &otlpcommonv1.KeyValue{Key: key, Value: stringLogBody(value)})
			}
		}
	}
	tid, err := hex.DecodeString(traceID)
	require.NoError(t, err)
	sid, err := hex.DecodeString(unfinishedID)
	require.NoError(t, err)
	parent, err := hex.DecodeString(rootID)
	require.NoError(t, err)
	spanReq.ResourceSpans[0].ScopeSpans[0].Spans = append(spanReq.ResourceSpans[0].ScopeSpans[0].Spans,
		&tracepb.Span{TraceId: tid, SpanId: sid, ParentSpanId: parent, Name: "left running", StartTimeUnixNano: 150})
	_, err = fixture.AppendLogs([]clientdb.Log{persistedCaptureLog(t, traceID, callID, "stdout", stringLogBody("cloud build output\n"))})
	require.NoError(t, err)
	logs, err := fixture.SelectLogsSince(t.Context(), clientdb.SelectLogsSinceParams{Limit: 100})
	require.NoError(t, err)
	require.Len(t, logs, 5)
	for i := range logs {
		if len(logs[i].Resource) == 0 {
			logs[i].Resource = []byte("{}")
		}
		if len(logs[i].InstrumentationScope) == 0 {
			logs[i].InstrumentationScope = []byte("{}")
		}
	}
	logReq := &collogspb.ExportLogsServiceRequest{ResourceLogs: clientdb.LogsToPB(logs)}
	var requests atomic.Int32
	var denied atomic.Bool
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		if r.Header.Get("Authorization") != "Bearer "+secret {
			http.Error(w, "missing credential", http.StatusUnauthorized)
			return
		}
		if denied.Load() {
			http.Error(w, secret, http.StatusForbidden)
			return
		}
		var msg proto.Message
		switch r.URL.Path {
		case "/v1/traces/" + traceID:
			msg = spanReq
		case "/v1/logs/" + traceID:
			msg = logReq
		case "/v1/metrics/" + traceID:
			msg = &colmetricspb.ExportMetricsServiceRequest{}
		default:
			http.NotFound(w, r)
			return
		}
		data, err := proto.Marshal(msg)
		if err != nil {
			t.Error(err)
			return
		}
		w.Header().Set("Content-Type", otlpstream.ContentType)
		fw := otlpstream.NewFrameWriter(w)
		if err := fw.WriteData(data); err != nil {
			t.Error(err)
			return
		}
		if err := fw.WriteTerminal(); err != nil {
			t.Error(err)
		}
	}))
	defer server.Close()
	t.Setenv("DAGGER_CLOUD_URL", server.URL)
	dbs := clientdb.NewDBs(t.TempDir())
	live, err := dbs.Open(t.Context(), "capture-test")
	require.NoError(t, err)
	defer live.Close()
	_, err = live.AppendSpans([]clientdb.Span{{TraceID: "11111111111111111111111111111111", SpanID: "1111111111111111", Name: "live session", Attributes: []byte("[]"), Events: []byte("[]"), Links: []byte("[]"), Resource: []byte("{}"), InstrumentationScope: []byte("{}")}})
	require.NoError(t, err)
	meta := &engine.ClientMetadata{CloudAuth: &auth.Cloud{Token: &oauth2.Token{TokenType: "Bearer", AccessToken: secret}}}
	ctx := ContextWithQuery(t.Context(), &Query{Server: &logCaptureTestServer{mockServer: &mockServer{clientMetadata: meta}, dbs: dbs}})
	m := newMCP()
	tools := NewLLMToolSet()
	m.loadBuiltins(&dagql.Server{}, tools)
	invoke := func(name string, args map[string]any) string {
		t.Helper()
		tool, err := m.LookupTool(name, tools.Order)
		require.NoError(t, err)
		result, err := tool.Call(ctx, args)
		require.NoError(t, err, name)
		text := fmt.Sprint(result)
		require.NotContains(t, text, secret)
		return text
	}
	loadTool, err := m.LookupTool("LoadTrace", tools.Order)
	require.NoError(t, err)
	mcpTool, err := genMcpTool(*loadTool)
	require.NoError(t, err)
	require.Equal(t, "LoadTrace", mcpTool.Name)
	_, err = loadTool.Call(ctx, map[string]any{"trace": "not a trace"})
	require.ErrorContains(t, err, "invalid trace")
	require.Zero(t, requests.Load())
	loaded := invoke("LoadTrace", map[string]any{"trace": "dagger trace " + traceID})
	require.Contains(t, loaded, rootID)
	require.Contains(t, loaded, "3 spans")
	require.Equal(t, int32(3), requests.Load())
	require.Equal(t, loaded, invoke("LoadTrace", map[string]any{"trace": traceID}))
	require.Equal(t, int32(3), requests.Load(), "repeated loads must not duplicate logs or fetch again")
	require.Contains(t, invoke("FindSpans", map[string]any{}), "live session")
	require.Contains(t, invoke("FindSpans", map[string]any{"query": "Container"}), callID)
	require.NotContains(t, invoke("FindSpans", map[string]any{"span": rootID}), "live session")
	require.Contains(t, invoke("ReadTrace", map[string]any{"span": rootID, "view": "inspect"}), rootID)
	require.Contains(t, invoke("ReadTrace", map[string]any{"span": callID, "view": "inspect"}), callID)
	callDetail := invoke("ReadTrace", map[string]any{"span": callID, "view": "inspect"})
	require.Contains(t, callDetail, digest)
	require.Contains(t, callDetail, "duration: 100ns (own span wall interval)")
	unfinishedDetail := invoke("ReadTrace", map[string]any{"span": unfinishedID, "view": "inspect"})
	require.Contains(t, unfinishedDetail, "ended:    (completion unrecorded; synthetic end:")
	require.Contains(t, unfinishedDetail, "duration: unknown (own span wall interval; completion unrecorded)")
	require.Contains(t, unfinishedDetail, "leftRunning")
	require.NotContains(t, unfinishedDetail, "still running")
	for _, minDuration := range []string{"0s", "1h"} {
		timings := invoke("ReadTrace", map[string]any{"span": rootID, "view": "timings", "minDuration": minDuration})
		require.Contains(t, timings, "Scope: raw parent edges only")
		require.Contains(t, timings, unfinishedID+"  "+rootID+"  50ns  unknown (completion unrecorded)  \"left running\"")
		require.NotContains(t, timings, "(so far)")
	}
	require.Contains(t, invoke("ReadTrace", map[string]any{"span": rootID}), "cloud:check")
	require.Contains(t, invoke("ReadTrace", map[string]any{"span": callID}), "cloud build output")
	require.Contains(t, invoke("ReadLogs", map[string]any{"span": rootID}), "1→[span="+callID+" stream=0 time=unknown] cloud build output")
	require.Contains(t, invoke("ReadLogs", map[string]any{"span": unfinishedID}), "no logs recorded beneath")
	require.Contains(t, invoke("FindCalls", map[string]any{"query": "example.com/repo"}), "git(")
	require.Contains(t, invoke("InspectCall", map[string]any{"span": callID, "view": "tree"}), "https://example.com/repo")
	require.Contains(t, invoke("InspectCall", map[string]any{"digest": digest, "view": "stats"}), "distinct calls: 5")
	imported := inspectionStoreForSpan(live, unfinishedID)
	importedRows, err := imported.SelectSpansLatest(ctx, map[string]struct{}{unfinishedID: {}})
	require.NoError(t, err)
	require.True(t, importedRows[0].EndTime.Valid, "historical work must not remain live")
	require.Contains(t, string(importedRows[0].Attributes), telemetry.CanceledAttr)
	// The export cursors see only this run. Neither historical spans nor binary
	// call payloads are re-exported, and a different client's store sees nothing.
	liveRows, err := live.SelectSpansSince(ctx, clientdb.SelectSpansSinceParams{Limit: 100})
	require.NoError(t, err)
	require.Len(t, liveRows, 1)
	liveLogs, err := live.SelectLogsSince(ctx, clientdb.SelectLogsSinceParams{Limit: 100})
	require.NoError(t, err)
	require.Empty(t, liveLogs)
	other, err := dbs.Open(ctx, "other-session")
	require.NoError(t, err)
	defer other.Close()
	require.Len(t, other.InspectionStores(), 1)
	require.False(t, inspectionStoreForSpan(other, rootID).HasSpan(rootID))

	// Credentials and Cloud response bodies must not reach the model on errors.
	denied.Store(true)
	freshDBs := clientdb.NewDBs(t.TempDir())
	fresh, err := freshDBs.Open(ctx, "capture-test")
	require.NoError(t, err)
	defer fresh.Close()
	freshCtx := ContextWithQuery(t.Context(), &Query{Server: &logCaptureTestServer{mockServer: &mockServer{clientMetadata: meta}, dbs: freshDBs}})
	_, err = m.loadTraceTool(&dagql.Server{})(freshCtx, map[string]any{"trace": traceID})
	require.ErrorContains(t, err, "no data was imported")
	require.NotContains(t, err.Error(), secret)
	require.Len(t, fresh.InspectionStores(), 1)
	meta.CloudAuth = nil
	_, err = m.loadTraceTool(&dagql.Server{})(freshCtx, map[string]any{"trace": traceID})
	require.ErrorContains(t, err, "dagger login")
}

func TestLoadTracePreservesOrdinaryWorkInReport(t *testing.T) {
	const traceID = "000102030405060708090a0b0c0d0e0f"
	const rootID = "0000000000000001"
	for _, revealed := range []bool{false, true} {
		t.Run(fmt.Sprintf("revealed=%v", revealed), func(t *testing.T) {
			ctx := t.Context()
			original, err := clientdb.NewDBs(t.TempDir()).Open(ctx, "original")
			require.NoError(t, err)
			defer original.Close()
			live, err := clientdb.NewDBs(t.TempDir()).Open(ctx, "live")
			require.NoError(t, err)
			defer live.Close()
			rows := []clientdb.Span{
				{SpanID: rootID, Name: "ordinary root"},
				{SpanID: "0000000000000002", ParentSpanID: validSpanID(rootID), Name: "ordinary successful work"},
				{SpanID: "0000000000000003", ParentSpanID: validSpanID(rootID), Name: "other work"},
			}
			var spans []sdktrace.ReadOnlySpan
			for i := range rows {
				rows[i].TraceID = traceID
				rows[i].StartTime = 1000000000
				rows[i].EndTime.Valid = true
				rows[i].EndTime.Int64 = 2000000000
				rows[i].Attributes = marshalSpanAttrs(t)
				rows[i].Events = []byte("[]")
				rows[i].Links = []byte("[]")
				rows[i].Resource = []byte("{}")
				rows[i].InstrumentationScope = []byte("{}")
				if revealed && i == 2 {
					rows[i].Attributes = marshalSpanAttrs(t, &otlpcommonv1.KeyValue{
						Key:   telemetry.UIRevealAttr,
						Value: &otlpcommonv1.AnyValue{Value: &otlpcommonv1.AnyValue_BoolValue{BoolValue: true}},
					})
				}
				spans = append(spans, rows[i].ReadOnly())
			}
			_, err = original.AppendSpans(rows)
			require.NoError(t, err)
			render := func(store *clientdb.DB) string {
				t.Helper()
				session, err := loadTraceReportSession(ctx, store, rootID)
				require.NoError(t, err)
				report, err := renderTraceReportSession(session, rootID, readTraceReportOpts())
				require.NoError(t, err)
				return report.body
			}
			before := render(original)
			require.Contains(t, before, "ordinary successful work")
			_, err = loadCloudTrace(ctx, live, traceID, func(ctx context.Context, _ string, sink cloud.TraceImportSink) error {
				return sink.ImportSpans(ctx, &coltracepb.ExportTraceServiceRequest{ResourceSpans: telemetry.SpansToPB(spans)})
			})
			require.NoError(t, err)
			after := render(inspectionStoreForSpan(live, rootID))
			t.Logf("original report:\n%s\nloaded report:\n%s", before, after)
			require.Contains(t, after, "ordinary successful work", "loading a trace must not drop unrevealed work")
			require.Equal(t, before, after)
		})
	}
}

func TestImportedTraceCannotOverrideLive(t *testing.T) {
	ctx := t.Context()
	live, digest, frames := callInspectStore(t, callInspectRecipe(t))
	rows, err := live.SelectSpansLatest(ctx, live.SpanIDs())
	require.NoError(t, err)
	for i := range rows {
		rows[i].Name = "historical impostor"
		if rows[i].SpanID == "0000000000000002" {
			frame := frames["withDirectory"]
			frame.Field = "impostor"
			encoded, err := frame.Encode()
			require.NoError(t, err)
			rows[i].Attributes = marshalSpanAttrs(t,
				&otlpcommonv1.KeyValue{Key: telemetry.DagDigestAttr, Value: stringLogBody(digest)},
				&otlpcommonv1.KeyValue{Key: telemetry.DagCallAttr, Value: stringLogBody(encoded)})
		}
	}
	imported, err := live.ImportTrace(ctx, "historical", func(dst *clientdb.DB) error {
		_, err := dst.AppendSpans(rows)
		return err
	})
	require.NoError(t, err)
	require.Same(t, live, inspectionStoreForSpan(live, "0000000000000002"))
	got, err := findSpansIn(ctx, live, "", "", 100, imported)
	require.NoError(t, err)
	require.Contains(t, got, "Container.withDirectory")
	require.NotContains(t, got, "impostor")
	got, err = findSpansIn(ctx, live, "impostor", "", 100, imported)
	require.NoError(t, err)
	require.Contains(t, got, "no spans matching")
	got, err = findCallsIn(ctx, live, regexp.MustCompile(".*"), 100)
	require.NoError(t, err)
	require.Contains(t, got, "withDirectory")
	require.NotContains(t, got, "impostor")
	got, err = inspectCallIn(ctx, live, digest, callInspectOpts{View: callViewTree})
	require.NoError(t, err)
	require.Contains(t, got, "withDirectory")
	require.NotContains(t, got, "impostor")
}

func TestLoadTraceFailedImportIsRetryable(t *testing.T) {
	live, err := clientdb.NewDBs(t.TempDir()).Open(t.Context(), "live")
	require.NoError(t, err)
	defer live.Close()
	const id = "000102030405060708090a0b0c0d0e0f"
	partial := func(ctx context.Context, sink cloud.TraceImportSink) error {
		tid, err := hex.DecodeString(id)
		require.NoError(t, err)
		return sink.ImportSpans(ctx, &coltracepb.ExportTraceServiceRequest{ResourceSpans: []*tracepb.ResourceSpans{{ScopeSpans: []*tracepb.ScopeSpans{{Spans: []*tracepb.Span{{TraceId: tid, SpanId: []byte{0, 0, 0, 0, 0, 0, 0, 1}, Name: "partial", StartTimeUnixNano: 100}}}}}}})
	}
	for _, failure := range []error{errors.New("secret response"), context.Canceled} {
		ctx := t.Context()
		var cancel context.CancelFunc
		if errors.Is(failure, context.Canceled) {
			ctx, cancel = context.WithCancel(ctx)
		}
		_, err := loadCloudTrace(ctx, live, id, func(ctx context.Context, _ string, sink cloud.TraceImportSink) error {
			require.NoError(t, partial(ctx, sink))
			if cancel != nil {
				cancel()
			}
			return failure
		})
		require.Error(t, err)
		require.NotContains(t, err.Error(), "secret response")
		require.Len(t, live.InspectionStores(), 1)
	}
	result, err := loadCloudTrace(t.Context(), live, id, func(ctx context.Context, _ string, sink cloud.TraceImportSink) error {
		if err := partial(ctx, sink); err != nil {
			return err
		}
		return sink.Seal(ctx)
	})
	require.NoError(t, err)
	require.Contains(t, result, "1 spans")
	require.Len(t, live.InspectionStores(), 2)
}
