package core

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var readConfigBeforeStatEnabled atomic.Bool

func init() {
	readConfigBeforeStatEnabled.Store(os.Getenv("DAGGER_TEST_READ_CONFIG_BEFORE_STAT") == "true")
}
func ReadConfigBeforeStatDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		v, e := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if e != nil {
			http.Error(w, e.Error(), 400)
			return
		}
		readConfigBeforeStatEnabled.Store(v)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": readConfigBeforeStatEnabled.Load()})
}
