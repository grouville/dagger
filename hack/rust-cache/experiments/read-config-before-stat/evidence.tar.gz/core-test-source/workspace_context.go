package core

import (
	"context"
	"fmt"
	"slices"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine"
	"github.com/vektah/gqlparser/v2/ast"
)

type workspaceContextKey struct{}

// WorkspaceToContext binds a Workspace into the context so that module function
// execution resolves against it: contextual (+defaultPath) arguments and
// Workspace-typed arguments are resolved from this Workspace rather than the
// ambient current workspace.
//
// Artifact evaluation binds the workspace that supplied the artifact. Every
// target receives the same workspace ID, including its overlay edits.
//
// It is also threaded at LLM tool dispatch when the LLM is bound to
// a Workspace (via LLM.withWorkspace), letting the agent operate on its own
// (possibly overlaid) Workspace.
func WorkspaceToContext(ctx context.Context, ws dagql.ObjectResult[*Workspace]) context.Context {
	return context.WithValue(ctx, workspaceContextKey{}, ws)
}

// WorkspaceFromContext returns the Workspace bound into the context by
// [WorkspaceToContext], if any.
//
// Unlike [EnvFromContext] there is no server-side fallback: a Workspace only
// enters the context through an explicit in-process binding at tool dispatch.
// Ordinary, non-bound calls return ok=false and continue resolving context the
// existing way (an Env, or the module source).
func WorkspaceFromContext(ctx context.Context) (dagql.ObjectResult[*Workspace], bool) {
	if ws, ok := ctx.Value(workspaceContextKey{}).(dagql.ObjectResult[*Workspace]); ok && ws.Self() != nil {
		return ws, true
	}
	return dagql.ObjectResult[*Workspace]{}, false
}

// workspaceArgValue resolves the Workspace that a framework-built call should
// pass for a required Workspace argument: the one an enclosing group bound into
// the context, else the session's ambient current workspace. Returns a nil
// input when neither applies, leaving the argument off so dagql reports it as
// missing by name.
//
// This mirrors [ModuleFunction.loadWorkspaceArg], which fills the same argument
// for calls that can rely on dagql's injection hook. A required argument can't:
// preselect rejects a missing non-null argument before the hook runs, so the
// value has to be on the selector instead.
func workspaceArgValue(ctx context.Context, srv *dagql.Server) (dagql.Input, error) {
	if ws, ok := WorkspaceFromContext(ctx); ok {
		wsID, err := ws.ID()
		if err != nil {
			return nil, fmt.Errorf("get bound workspace ID: %w", err)
		}
		return dagql.NewID[*Workspace](wsID), nil
	}
	if srv == nil {
		return nil, nil
	}
	// A running module function must pass a Workspace to its dependencies
	// explicitly, so it doesn't silently inherit its caller's.
	if inModuleFunction, err := callerInModuleFunction(ctx); err != nil {
		return nil, err
	} else if inModuleFunction {
		return nil, nil
	}
	var ws dagql.ObjectResult[*Workspace]
	if err := srv.Select(ctx, srv.Root(), &ws, dagql.Selector{
		Field: "currentWorkspace",
	}); err != nil {
		return nil, fmt.Errorf("load current workspace: %w", err)
	}
	wsID, err := ws.ID()
	if err != nil {
		return nil, fmt.Errorf("get current workspace ID: %w", err)
	}
	return dagql.NewID[*Workspace](wsID), nil
}

// WithBoundWorkspaceArgs supplies the workspace for any required Workspace
// argument in specs that named doesn't already carry.
//
// Callers that assemble a selector themselves — the entrypoint proxies building
// their inner constructor call, like ModTreeNode.DagqlValue — have to fill a
// required Workspace before selecting, since dagql's injection hook runs after
// the non-null check.
func WithBoundWorkspaceArgs(
	ctx context.Context,
	srv *dagql.Server,
	specs []dagql.InputSpec,
	named []dagql.NamedInput,
) []dagql.NamedInput {
	for _, spec := range specs {
		if slices.ContainsFunc(named, func(n dagql.NamedInput) bool { return n.Name == spec.Name }) {
			continue
		}
		if val, ok := boundWorkspaceInput(ctx, srv, spec); ok {
			named = append(named, dagql.NamedInput{Name: spec.Name, Value: val})
		}
	}
	return named
}

// inputSpecIsWorkspace reports whether spec is a Workspace-typed argument.
//
// A module function's object args are published as plain ID scalars — checking
// spec.Type.Type().Name() would compare against "ID" and never match — so the
// @expectedType directive is where the object type survives on the input spec.
// This is the same identification [isWorkspaceArg] makes against the AST.
func inputSpecIsWorkspace(spec dagql.InputSpec) bool {
	d := ast.DirectiveList(spec.Directives).ForName("expectedType")
	if d == nil {
		return false
	}
	name := d.Arguments.ForName("name")
	return name != nil && name.Value != nil && name.Value.Raw == workspaceTypeName
}

// boundWorkspaceInput returns the Workspace to pass for arg, if arg is a
// required Workspace-typed argument the caller left unset. Optional ones are
// left to dagql's injection hook.
func boundWorkspaceInput(ctx context.Context, srv *dagql.Server, arg dagql.InputSpec) (dagql.Input, bool) {
	if !arg.Type.Type().NonNull || !inputSpecIsWorkspace(arg) {
		return nil, false
	}
	val, err := workspaceArgValue(ctx, srv)
	if err != nil || val == nil {
		return nil, false
	}
	return val, true
}

// workspaceHostRoutingContext stamps the Workspace owner's immutable metadata
// onto ctx for record and host-routing operations. It deliberately does not
// replace the held ClientScope: metadata is not runtime execution authority, so
// schema/module operations continue to execute under the caller's leased scope.
// Synthetic/value workspaces have no owning client and leave ctx unchanged.
//
// This mirrors core/schema's withWorkspaceClientContext without a core→schema
// import.
func workspaceHostRoutingContext(ctx context.Context, ws *Workspace) (context.Context, error) {
	if ws.ClientID == "" {
		return ctx, nil
	}
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	clientMetadata, err := query.SpecificClientMetadata(ctx, ws.ClientID)
	if err != nil {
		return nil, fmt.Errorf("workspace client metadata: %w", err)
	}
	return engine.ContextWithClientMetadata(ctx, clientMetadata), nil
}

// loadWorkspaceOwnerContext switches to a live Workspace's owning client and
// loads its served modules. MCP.baseServer calls this only for live workspaces;
// value workspaces use core directly and never load the caller's modules.
//
// The load is best-effort: a module that cannot load is skipped rather than
// failing every LLM step, so the FindArtifacts builtin (via Workspace.artifacts)
// can still report it as a failing <module>/load check.
func loadWorkspaceOwnerContext(ctx context.Context, ws dagql.ObjectResult[*Workspace]) (context.Context, error) {
	wsCtx, err := workspaceHostRoutingContext(ctx, ws.Self())
	if err != nil {
		return nil, err
	}
	query, err := CurrentQuery(ctx)
	if err != nil {
		return nil, err
	}
	if _, err := query.EnsureWorkspaceModules(wsCtx, nil, ModuleLoadBestEffort); err != nil {
		return nil, fmt.Errorf("ensure workspace modules: %w", err)
	}
	return wsCtx, nil
}
