package core

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os/exec"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine/wcprof"
	"github.com/dagger/dagger/util/gitutil"
	telemetry "github.com/dagger/otel-go"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
)

const MaxWorkspacePullCommits = 1000
const workspacePullSelectionWindow = 10000
const WorkspacePullTimeout = 2 * time.Minute
const workspacePullOutputLimit = 16 << 20

type WorkspacePullOpts struct {
	// FromSHA excludes previously exported source history, independently of
	// destination hashes (which may have changed through cherry-picking).
	FromSHA                       string
	Commits                       []string
	MaxCommits                    int
	CommitterName, CommitterEmail string
}

// Validate requires canonical hashes for deterministic recorded pull operations.
func (opts WorkspacePullOpts) Validate() error {
	if err := opts.ValidateSelection(); err != nil {
		return err
	}
	for _, sha := range opts.Commits {
		if !IsFullGitSHA(sha) {
			return fmt.Errorf("commits must contain full lowercase commit hashes, got %q", sha)
		}
	}
	return nil
}

// ValidateSelection checks public inputs before resolving abbreviated hashes.
// Call Validate again after resolution to reject aliases of the same commit.
func (opts WorkspacePullOpts) ValidateSelection() error {
	if opts.MaxCommits < 1 || opts.MaxCommits > MaxWorkspacePullCommits {
		return fmt.Errorf("maxCommits must be between 1 and %d", MaxWorkspacePullCommits)
	}
	if len(opts.Commits) > opts.MaxCommits {
		return fmt.Errorf("selected commits exceed maxCommits (%d)", opts.MaxCommits)
	}
	seen := map[string]bool{}
	for _, sha := range opts.Commits {
		if !IsFullGitSHA(sha) && !gitutil.IsCommitSHAPrefix(sha) {
			return fmt.Errorf("commits must contain full lowercase commit hashes or unambiguous lowercase hex prefixes (4-40 characters), got %q", sha)
		}
		if seen[sha] {
			return fmt.Errorf("duplicate selected commit %s", sha)
		}
		seen[sha] = true
	}
	return nil
}

// IsFullGitSHA reports whether sha is a full lowercase hex commit hash
// (SHA-1 or SHA-256). Recorded workspace Git operations demand full hashes:
// public APIs must resolve any abbreviations before recording recipes.
func IsFullGitSHA(sha string) bool {
	if len(sha) != 40 && len(sha) != 64 {
		return false
	}
	_, err := hex.DecodeString(sha)
	return err == nil && sha == strings.ToLower(sha)
}

type WorkspacePullPick struct {
	SHA           string
	Status        WorkspaceCommitPickStatus
	Reason        WorkspaceCommitPickReason
	ConflictPaths []string
}

// WorkspacePullCommits uses the same speculative fold for planning and apply.
// All Git writes are confined to a scratch snapshot; even a late conflict
// leaves both input workspaces intact. Only source HEAD is fetched, not its
// working tree or overlay. The result contains the integrated HEAD and the
// receiver's remaining uncommitted changes, merged against that HEAD.
//
//nolint:gocyclo // plan and apply share one fold over the source's commits; splitting hides the order of its steps
func WorkspacePullCommits(ctx context.Context, base dagql.ObjectResult[*Directory], source *GitRef, dirty *Changeset, opts WorkspacePullOpts, apply bool) (*Directory, []WorkspacePullPick, error) {
	if err := opts.Validate(); err != nil {
		return nil, nil, err
	}
	ctx, cancel := context.WithTimeout(ctx, WorkspacePullTimeout)
	defer cancel()
	paths, err := dirty.ComputePaths(ctx)
	if err != nil {
		return nil, nil, err
	}
	dirtyPaths := pullDirtyPaths(paths)
	content, err := dirty.content(ctx)
	if err != nil {
		return nil, nil, err
	}
	var picks []WorkspacePullPick
	dir, err := withGitMergeWorkspace(ctx, base, "Workspace pull commits", func(ws *gitMergeWorkspace) (rerr error) {
		ctx, span := Tracer(ctx).Start(ctx, "git workspace pull", telemetry.Internal())
		defer telemetry.EndWithCause(span, &rerr)
		start := wcprof.NowNS()
		err := source.Repo.Self().Backend.mount(ctx, 0, false, []GitRefBackend{source.Backend}, func(ctx context.Context, git *gitutil.GitCLI) error {
			url, err := git.URL(ctx)
			if err != nil {
				return err
			}
			// The base checkout has a detached HEAD and no refs, and fetch
			// negotiates only from refs unless told otherwise: without the tip,
			// it would claim to have nothing and receive the whole history.
			_, err = runWorkspacePullGit(ctx, ws.workDir, nil, "fetch", "--no-tags", "--no-write-fetch-head", "--no-recurse-submodules", "--negotiation-tip=HEAD", url, source.Ref.SHA)
			return err
		})
		if err != nil {
			return fmt.Errorf("fetch source commits: %w", err)
		}
		start = recordWorkspacePullPhase(ctx, span, "fetch", "", start)
		base, err := runWorkspacePullGit(ctx, ws.workDir, nil, "rev-parse", "HEAD")
		if err != nil {
			return err
		}
		base = strings.TrimSpace(base)
		// The base is a retained checkout, whose index carries no stat data
		// (finishGitCheckout normalizes it with read-tree): every entry looks
		// modified, so `add -A` below would re-hash every file (writing each
		// existing object again, which freshens, and so copies up, the
		// inherited packs) and each `reset --hard`/`read-tree -u` would
		// rewrite every file of the tree into the new layer. Refreshing
		// compares content instead (stat data cannot match), only reading.
		refreshed := refreshWorkspacePullIndex(ctx, ws.workDir)
		span.SetAttributes(attribute.Bool("dagger.git.pull.index_refreshed", refreshed))
		start = recordWorkspacePullPhase(ctx, span, "refresh", "", start)
		var dirtySHA string
		if workspaceExportContentEmpty(content) {
			// Nothing to carry over: the worktree is already the base tree,
			// and so is its snapshot.
			dirtySHA, err = workspaceSnapshotTreeCommit(ctx, ws.workDir, base+"^{tree}")
			if err != nil {
				return err
			}
			span.SetAttributes(attribute.Bool("dagger.git.pull.dirty", false))
			start = recordWorkspacePullPhase(ctx, span, "dirty", "clean", start)
		} else {
			if err := ws.applyContent(ctx, content); err != nil {
				return err
			}
			dirtySHA, err = workspaceSnapshotCommit(ctx, ws.workDir, base)
			if err != nil {
				return err
			}
			if _, err := runWorkspacePullGit(ctx, ws.workDir, nil, "reset", "--hard", base); err != nil {
				return err
			}
			span.SetAttributes(attribute.Bool("dagger.git.pull.dirty", true))
			start = recordWorkspacePullPhase(ctx, span, "dirty", "snapshot", start)
		}
		// File contents are merged after folding committed history. Identical
		// pre-existing dirt can thus be incorporated into incoming commits.
		// Empty directories still need explicit obstruction checks: Git cannot
		// represent them in a tree.
		var directories []string
		for _, p := range slices.Concat(paths.Added, paths.Modified) {
			if strings.HasSuffix(p, "/") && slices.Contains(dirtyPaths, strings.TrimSuffix(p, "/")) {
				directories = append(directories, strings.TrimSuffix(p, "/"))
			}
		}
		picks, err = foldWorkspacePull(ctx, ws.workDir, source.Ref.SHA, directories, opts)
		if err != nil {
			return err
		}
		start = recordWorkspacePullPhase(ctx, span, "fold", "", start)
		defer func() { recordWorkspacePullPhase(ctx, span, "merge", "", start) }()
		merged, mergeErr := runWorkspacePullGit(ctx, ws.workDir, nil, "merge-tree", "--write-tree", "--merge-base="+base, "HEAD", dirtySHA)
		if mergeErr != nil {
			mergeErr = fmt.Errorf("merge uncommitted changes: %w\n%s", mergeErr, strings.TrimSpace(merged))
			var exit *exec.ExitError
			if !errors.As(mergeErr, &exit) || exit.ExitCode() != 1 || merged == "" {
				return mergeErr
			}
			// Preserve per-commit diagnostics when the conflict can be
			// attributed through overlapping paths.
			attributed := false
			for i := range picks {
				if picks[i].Status != WorkspaceCommitPickable {
					continue
				}
				touched, err := pullCommitPaths(ctx, ws.workDir, picks[i].SHA)
				if err != nil {
					return err
				}
				if conflicts := pullOverlappingPaths(touched, dirtyPaths); len(conflicts) > 0 {
					picks[i].Status, picks[i].Reason, picks[i].ConflictPaths = WorkspaceCommitConflict, WorkspaceCommitPickReasonDirty, conflicts
					attributed = true
				}
			}
			// Directory renames can conflict with additions at paths that no
			// source commit touched. Fail planning too rather than report an
			// entirely pickable plan after failing to restore pending edits.
			if !attributed {
				return fmt.Errorf("cannot pull commits: %w", mergeErr)
			}
		} else {
			tree := strings.Fields(merged)[0]
			if _, err := runWorkspacePullGit(ctx, ws.workDir, nil, "read-tree", "--reset", "-u", tree); err != nil {
				return err
			}
		}
		if apply {
			var conflicts []error
			for _, pick := range picks {
				if pick.Status == WorkspaceCommitConflict {
					conflicts = append(conflicts, fmt.Errorf("commit %s: %s conflict on %s", pick.SHA, pick.Reason, strings.Join(pick.ConflictPaths, ", ")))
				}
			}
			// A failed merge must never produce a workspace, independently of
			// whether its conflicts were attributed to individual picks.
			if mergeErr != nil {
				conflicts = append(conflicts, mergeErr)
			}
			if len(conflicts) > 0 {
				return fmt.Errorf("cannot pull commits: %w", errors.Join(conflicts...))
			}
		}
		return normalizeGitDirAfterCommit(ctx, ws.workDir)
	})
	return dir, picks, err
}

// refreshWorkspacePullIndex records the worktree's stat data in the index of
// the scratch checkout at dir, comparing each file's content with its blob
// where the stat data does not match (a retained checkout's index has none).
// It writes no objects and no worktree file. Failing to refresh only loses the
// shortcut: later commands then re-hash and rewrite what they must. Reports
// whether the refresh succeeded.
func refreshWorkspacePullIndex(ctx context.Context, dir string) bool {
	_, err := runWorkspacePullGit(ctx, dir, nil, "update-index", "-q", "--unmerged", "--refresh")
	return err == nil
}

// recordWorkspacePullPhase records a phase of a pull that ran from start
// until now, as dagger.git.pull.<phase>_ms on span and a wcprof io op
// "git.pull.<phase>[<detail>]", and returns now: the next phase's start.
func recordWorkspacePullPhase(ctx context.Context, span trace.Span, phase, detail string, start int64) int64 {
	end := wcprof.NowNS()
	span.SetAttributes(attribute.Int64("dagger.git.pull."+phase+"_ms", (end-start)/int64(time.Millisecond)))
	class := "git.pull." + phase
	if detail != "" {
		class += "[" + detail + "]"
	}
	wcprof.RecordOp(ctx, wcprof.OpKindIO, class, wcprof.OpOpts{}, start, end, wcprof.OutcomeOK)
	return end
}

func pullGitList(ctx context.Context, dir string, limit int, revisions ...string) ([]string, error) {
	args := append([]string{"rev-list", "--topo-order", "--max-count=" + strconv.Itoa(limit+1)}, revisions...)
	out, err := runWorkspacePullGit(ctx, dir, nil, args...)
	if err != nil {
		return nil, err
	}
	shas := strings.Fields(out)
	if len(shas) > limit {
		return nil, fmt.Errorf("pull history exceeds maxCommits (%d); narrow the source ref or increase maxCommits (maximum %d)", limit, MaxWorkspacePullCommits)
	}
	slices.Reverse(shas)
	return shas, nil
}

func pullSelectedCommits(ctx context.Context, dir, source, target string, opts WorkspacePullOpts) ([]string, error) {
	if len(opts.Commits) == 0 {
		revisions := []string{source, "^" + target}
		if opts.FromSHA != "" {
			revisions = append(revisions, "^"+opts.FromSHA)
		}
		return pullGitList(ctx, dir, opts.MaxCommits, revisions...)
	}
	// Explicit selection is also bounded: never walk arbitrarily far back to
	// find a requested hash. A nearer source ref lets callers select older work.
	out, err := runWorkspacePullGit(ctx, dir, nil, "rev-list", "--topo-order", "--max-count="+strconv.Itoa(workspacePullSelectionWindow), source)
	if err != nil {
		return nil, err
	}
	wanted := map[string]bool{}
	for _, sha := range opts.Commits {
		wanted[sha] = true
	}
	var selected []string
	for _, sha := range strings.Fields(out) {
		if wanted[sha] {
			selected = append(selected, sha)
			delete(wanted, sha)
		}
	}
	if len(wanted) != 0 {
		return nil, fmt.Errorf("selected commits are not within the source's latest %d commits; use a nearer source ref", workspacePullSelectionWindow)
	}
	slices.Reverse(selected)
	return selected, nil
}

func pullIsAncestor(ctx context.Context, dir, ancestor, tip string) (bool, error) {
	_, err := runWorkspacePullGit(ctx, dir, nil, "merge-base", "--is-ancestor", ancestor, tip)
	if err == nil {
		return true, nil
	}
	var exit *exec.ExitError
	if errors.As(err, &exit) && exit.ExitCode() == 1 {
		return false, nil
	}
	return false, err
}

// foldWorkspacePull advances a clean speculative HEAD after each pickable
// commit. Dirty paths remain a separate, invariant set and cannot be swept into
// someone else's commit. Conflicting candidates do not advance the fold.
func foldWorkspacePull(ctx context.Context, dir, source string, dirty []string, opts WorkspacePullOpts) ([]WorkspacePullPick, error) {
	targetOut, err := runWorkspacePullGit(ctx, dir, nil, "rev-parse", "HEAD")
	if err != nil {
		return nil, err
	}
	target := strings.TrimSpace(targetOut)
	selected, err := pullSelectedCommits(ctx, dir, source, target, opts)
	if err != nil {
		return nil, err
	}
	picks := make([]WorkspacePullPick, len(selected))
	var newCommits []string
	for i, sha := range selected {
		picks[i] = WorkspacePullPick{SHA: sha, Status: WorkspaceCommitPickable, Reason: WorkspaceCommitPickReasonNone, ConflictPaths: []string{}}
		present, err := pullIsAncestor(ctx, dir, sha, target)
		if err != nil {
			return nil, err
		}
		if present {
			picks[i].Status = WorkspaceCommitPicked
		} else {
			newCommits = append(newCommits, sha)
		}
	}
	if len(newCommits) == 0 {
		return picks, nil
	}
	// A selected prefix (including merge ancestry) can fast-forward too, but
	// only when it includes every new ancestor of the selected tip.
	ffTip := newCommits[len(newCommits)-1]
	fastForward, err := pullIsAncestor(ctx, dir, target, ffTip)
	if err != nil {
		return nil, err
	}
	if fastForward {
		rangeSHAs, err := pullGitList(ctx, dir, opts.MaxCommits, ffTip, "^"+target)
		if err != nil {
			return nil, err
		}
		a, b := slices.Clone(rangeSHAs), slices.Clone(newCommits)
		slices.Sort(a)
		slices.Sort(b)
		fastForward = slices.Equal(a, b)
	}
	origins := map[string]bool{}
	// Only deduplicate against history present before the fold. Incoming
	// commits may intentionally reapply the same patch after a revert.
	targetPatchIDs := map[string]bool{}
	if !fastForward {
		local, err := pullGitList(ctx, dir, opts.MaxCommits, target, "^"+source)
		if err != nil {
			return nil, err
		}
		for _, sha := range local {
			message, err := runWorkspacePullGit(ctx, dir, nil, "show", "-s", "--format=%B", sha)
			if err != nil {
				return nil, err
			}
			for _, origin := range pullCommitOrigins(message) {
				origins[origin] = true
			}
			id, err := workspacePullPatchID(ctx, dir, sha)
			if err != nil {
				return nil, err
			}
			if id != "" {
				targetPatchIDs[id] = true
			}
		}
	}
	for i := range picks {
		pick := &picks[i]
		if pick.Status == WorkspaceCommitPicked {
			continue
		}
		if fastForward {
			paths, err := pullCommitPaths(ctx, dir, pick.SHA)
			if err != nil {
				return nil, err
			}
			if conflicts := pullOverlappingPaths(paths, dirty); len(conflicts) > 0 {
				pick.Status, pick.Reason, pick.ConflictPaths = WorkspaceCommitConflict, WorkspaceCommitPickReasonDirty, conflicts
			}
			continue
		}
		if err := foldWorkspacePullCommit(ctx, dir, pick, dirty, opts, origins, targetPatchIDs); err != nil {
			return nil, err
		}
	}
	if fastForward && !slices.ContainsFunc(picks, func(p WorkspacePullPick) bool { return p.Status == WorkspaceCommitConflict }) {
		if _, err := runWorkspacePullGit(ctx, dir, nil, "reset", "--hard", ffTip); err != nil {
			return nil, err
		}
	}
	return picks, nil
}

func foldWorkspacePullCommit(ctx context.Context, dir string, pick *WorkspacePullPick, dirty []string, opts WorkspacePullOpts, origins, targetPatchIDs map[string]bool) error {
	sha := pick.SHA
	if origins[sha] {
		pick.Status = WorkspaceCommitPicked
		return nil
	}
	out, err := runWorkspacePullGit(ctx, dir, nil, "show", "-s", "--format=%P%x00%an%x00%ae%x00%aI%x00%cI%x00%B", sha)
	if err != nil {
		return err
	}
	meta := strings.SplitN(out, "\x00", 6)
	if len(meta) != 6 {
		return fmt.Errorf("invalid metadata for source commit %s", sha)
	}
	for _, origin := range pullCommitOrigins(meta[5]) {
		if origins[origin] {
			pick.Status = WorkspaceCommitPicked
			return nil
		}
		// Origin objects need not be present in the joined repositories.
		if _, err := runWorkspacePullGit(ctx, dir, nil, "cat-file", "-e", origin+"^{commit}"); err != nil {
			continue
		}
		present, err := pullIsAncestor(ctx, dir, origin, "HEAD")
		if err != nil {
			return err
		}
		if present {
			pick.Status = WorkspaceCommitPicked
			return nil
		}
	}
	if len(strings.Fields(meta[0])) > 1 {
		return fmt.Errorf("cannot cherry-pick merge commit %s without a mainline; pull its complete ancestry as a fast-forward or integrate it with git", sha)
	}
	id, err := workspacePullPatchID(ctx, dir, sha)
	if err != nil {
		return err
	}
	if id != "" && targetPatchIDs[id] {
		pick.Status = WorkspaceCommitRedundant
		return nil
	}
	paths, err := pullCommitPaths(ctx, dir, sha)
	if err != nil {
		return err
	}
	if conflicts := pullOverlappingPaths(paths, dirty); len(conflicts) > 0 {
		pick.Status, pick.Reason, pick.ConflictPaths = WorkspaceCommitConflict, WorkspaceCommitPickReasonDirty, conflicts
		return nil
	}
	_, pickErr := runWorkspacePullGit(ctx, dir, nil, "cherry-pick", "--no-commit", sha)
	if pickErr != nil {
		conflicts, err := runWorkspacePullGit(ctx, dir, nil, "diff", "--name-only", "--diff-filter=U", "-z")
		if err != nil {
			return err
		}
		pick.ConflictPaths = splitPullPaths(conflicts)
		if len(pick.ConflictPaths) == 0 {
			return fmt.Errorf("cherry-pick %s: %w", sha, pickErr)
		}
		pick.Status, pick.Reason = WorkspaceCommitConflict, WorkspaceCommitPickReasonContent
		_, err = runWorkspacePullGit(ctx, dir, nil, "reset", "--hard", "HEAD")
		return err
	}
	changed, err := runWorkspacePullGit(ctx, dir, nil, "diff", "--cached", "--name-only", "-z")
	if err != nil {
		return err
	}
	if changed == "" {
		pick.Status = WorkspaceCommitRedundant
		return nil
	}
	name, email := opts.CommitterName, opts.CommitterEmail
	if name == "" {
		name = "Dagger"
	}
	if email == "" {
		email = "dagger@localhost"
	}
	env := []string{"GIT_AUTHOR_NAME=" + meta[1], "GIT_AUTHOR_EMAIL=" + meta[2], "GIT_AUTHOR_DATE=" + meta[3], "GIT_COMMITTER_NAME=" + name, "GIT_COMMITTER_EMAIL=" + email, "GIT_COMMITTER_DATE=" + meta[4]}
	// git show adds a newline after %B; remove only that separator to preserve
	// the source message verbatim, without adding cherry-pick provenance.
	message := strings.TrimSuffix(meta[5], "\n")
	if _, err := runWorkspacePullGit(ctx, dir, env, "commit", "--no-verify", "--no-gpg-sign", "--cleanup=verbatim", "-m", message); err != nil {
		return err
	}
	origins[sha] = true
	for _, origin := range pullCommitOrigins(meta[5]) {
		origins[origin] = true
	}
	return nil
}

func pullCommitOrigins(message string) []string {
	var origins []string
	for _, line := range strings.Split(message, "\n") {
		sha, ok := strings.CutPrefix(line, "(cherry picked from commit ")
		if !ok {
			continue
		}
		sha, ok = strings.CutSuffix(sha, ")")
		if ok && IsFullGitSHA(sha) {
			origins = append(origins, sha)
		}
	}
	return origins
}

func pullCommitPaths(ctx context.Context, dir, sha string) ([]string, error) {
	out, err := runWorkspacePullGit(ctx, dir, nil, "diff-tree", "--root", "-m", "--no-commit-id", "--no-renames", "--name-only", "-r", "-z", sha, "--")
	return splitPullPaths(out), err
}

func splitPullPaths(out string) []string {
	paths := strings.Split(strings.TrimSuffix(out, "\x00"), "\x00")
	paths = slices.DeleteFunc(paths, func(p string) bool { return p == "" })
	slices.Sort(paths)
	return slices.Compact(paths)
}

func pullOverlappingPaths(touched, dirty []string) []string {
	var conflicts []string
	for _, p := range touched {
		for _, d := range dirty {
			if p == d || strings.HasPrefix(p, d+"/") || strings.HasPrefix(d, p+"/") {
				conflicts = append(conflicts, p)
				break
			}
		}
	}
	slices.Sort(conflicts)
	return slices.Compact(conflicts)
}

// Keep empty-directory changes too: overlaying one onto an incoming file would
// hide committed content. Ignore structural parent entries when a more precise
// child path is available, so unrelated edits under that parent can still pull.
func pullDirtyPaths(paths *ChangesetPaths) []string {
	all := slices.Concat(paths.Added, paths.Modified, paths.AllRemoved)
	slices.Sort(all)
	all = slices.Compact(all)
	var dirty []string
	for i, p := range all {
		if strings.HasSuffix(p, "/") && i+1 < len(all) && strings.HasPrefix(all[i+1], p) {
			continue
		}
		p = strings.TrimSuffix(p, "/")
		if p != "" && p != "." {
			dirty = append(dirty, p)
		}
	}
	return dirty
}

func runWorkspacePullGit(ctx context.Context, dir string, env []string, args ...string) (_ string, rerr error) {
	operation := args[0]
	ctx, span := Tracer(ctx).Start(ctx, "git "+operation, telemetry.Internal())
	defer func() {
		// Command output and arguments can contain file contents or credentials.
		// Keep subprocess telemetry limited to the verb and success/failure.
		var spanErr error
		if rerr != nil {
			spanErr = fmt.Errorf("git %s failed", operation)
		}
		telemetry.EndWithCause(span, &spanErr)
	}()
	args = append([]string{"--no-replace-objects", "-c", "core.hooksPath=/dev/null", "-c", "commit.gpgsign=false", "-c", "rerere.enabled=false", "-c", "submodule.recurse=false"}, args...)
	cmd := gitCmd(ctx, dir, args...)
	cmd.Env = append(cmd.Env, env...)
	var stdout, stderr workspacePullOutput
	cmd.Stdout, cmd.Stderr = &stdout, &stderr
	err := cmd.Run()
	if stdout.exceeded || stderr.exceeded {
		return "", fmt.Errorf("git %s: pull command output exceeds %d bytes", operation, workspacePullOutputLimit)
	}
	if err != nil {
		return stdout.String(), fmt.Errorf("git %s: %w: %s", operation, err, stderr.String())
	}
	return stdout.String(), nil
}

type workspacePullOutput struct {
	buf      bytes.Buffer
	exceeded bool
}

func (out *workspacePullOutput) String() string { return out.buf.String() }

func (out *workspacePullOutput) Write(p []byte) (int, error) {
	if len(p) > workspacePullOutputLimit-out.buf.Len() {
		out.exceeded = true
		return 0, fmt.Errorf("pull command output limit exceeded")
	}
	return out.buf.Write(p)
}

// Stream patches to patch-id, rather than buffering potentially large binary
// diffs in the engine. The outer pull deadline bounds both subprocesses.
func workspacePullPatchID(ctx context.Context, dir, sha string) (string, error) {
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	show := gitCmd(ctx, dir, "--no-replace-objects", "show", "--format=", "--no-ext-diff", "--no-textconv", "--no-renames", "--binary", sha, "--")
	pipe, err := show.StdoutPipe()
	if err != nil {
		return "", err
	}
	var stderr workspacePullOutput
	show.Stderr = &stderr
	patch := gitCmd(ctx, dir, "patch-id", "--stable")
	patch.Stdin = pipe
	if err := show.Start(); err != nil {
		return "", err
	}
	out, patchErr := patch.Output()
	if patchErr != nil {
		cancel()
	}
	showErr := show.Wait()
	if patchErr != nil {
		return "", fmt.Errorf("patch-id for %s: %w", sha, patchErr)
	}
	if showErr != nil {
		return "", fmt.Errorf("show patch for %s: %w: %s", sha, showErr, stderr.String())
	}
	fields := strings.Fields(string(out))
	if len(fields) == 0 {
		return "", nil
	}
	return fields[0], nil
}

// ComputeWorkspacePull integrates source's commits into parent's Git checkout
// with parent's uncommitted changes on top. Both workspaces must be frozen.
// With apply unset, it only reports the commits it would pick.
func ComputeWorkspacePull(ctx context.Context, parent, source dagql.ObjectResult[*Workspace], opts WorkspacePullOpts, apply bool) (*Directory, []WorkspacePullPick, dagql.ObjectResult[*GitRef], error) {
	ctx, cancel := context.WithTimeout(ctx, WorkspacePullTimeout)
	defer cancel()
	var head dagql.ObjectResult[*GitRef]
	if !parent.Self().IsValueWorkspace() || !source.Self().IsValueWorkspace() {
		return nil, nil, head, fmt.Errorf("pulling requires frozen workspaces; call snapshot first")
	}
	srv, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, nil, head, err
	}
	var base dagql.ObjectResult[*Directory]
	if err := srv.Select(ctx, parent, &base, dagql.Selector{Field: "git"}, dagql.Selector{Field: "__checkout"}); err != nil {
		return nil, nil, head, err
	}
	if err := srv.Select(ctx, source, &head, dagql.Selector{Field: "git"}, dagql.Selector{Field: "head"}); err != nil {
		return nil, nil, head, err
	}
	var changes dagql.ObjectResult[*Changeset]
	if err := srv.Select(ctx, parent, &changes, dagql.Selector{Field: "git"}, dagql.Selector{Field: "uncommitted"}); err != nil {
		return nil, nil, head, err
	}
	dir, picks, err := WorkspacePullCommits(ctx, base, head.Self(), changes.Self(), opts, apply)
	return dir, picks, head, err
}

const persistedDirectoryLazyKindWorkspacePull = "workspace.pull"

// DirectoryWorkspacePullLazy produces Workspace.__pullDirectory: parent's
// checkout with source's selected commits applied. Commit identity and dates
// come from the source commits and Opts, so a rerun produces the same history.
type DirectoryWorkspacePullLazy struct {
	LazyState
	Parent dagql.ObjectResult[*Workspace]
	Source dagql.ObjectResult[*Workspace]
	Opts   WorkspacePullOpts
}

type persistedDirectoryWorkspacePullLazy struct {
	ParentResultID uint64            `json:"parentResultID"`
	SourceResultID uint64            `json:"sourceResultID"`
	Opts           WorkspacePullOpts `json:"opts"`
}

func (lazy *DirectoryWorkspacePullLazy) Evaluate(ctx context.Context, dir *Directory) error {
	return evaluateDirectoryOutput(ctx, &lazy.LazyState, "Workspace.__pullDirectory", dir, func(ctx context.Context) (*Directory, error) {
		out, _, _, err := ComputeWorkspacePull(ctx, lazy.Parent, lazy.Source, lazy.Opts, true)
		return out, err
	})
}

func (lazy *DirectoryWorkspacePullLazy) AttachDependencies(ctx context.Context, attach func(dagql.AnyResult) (dagql.AnyResult, error)) ([]dagql.AnyResult, error) {
	parent, err := attachLazyInput(attach, lazy.Parent, "DirectoryWorkspacePullLazy.Parent")
	if err != nil {
		return nil, err
	}
	source, err := attachLazyInput(attach, lazy.Source, "DirectoryWorkspacePullLazy.Source")
	if err != nil {
		return nil, err
	}
	lazy.Parent = parent
	lazy.Source = source
	return []dagql.AnyResult{parent, source}, nil
}

func (lazy *DirectoryWorkspacePullLazy) EncodePersisted(ctx context.Context, enc *dagql.PersistEncodeContext) (json.RawMessage, error) {
	parentID, err := encodePersistedObjectRef(enc, lazy.Parent, "workspace pull parent")
	if err != nil {
		return nil, err
	}
	sourceID, err := encodePersistedObjectRef(enc, lazy.Source, "workspace pull source")
	if err != nil {
		return nil, err
	}
	return json.Marshal(persistedDirectoryWorkspacePullLazy{ParentResultID: parentID, SourceResultID: sourceID, Opts: lazy.Opts})
}

func decodeDirectoryWorkspacePullLazy(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (Lazy[*Directory], error) {
	var persisted persistedDirectoryWorkspacePullLazy
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted workspace pull lazy: %w", err)
	}
	parent, err := loadPersistedObjectResultByResultID[*Workspace](ctx, dec, persisted.ParentResultID, "workspace pull parent")
	if err != nil {
		return nil, err
	}
	source, err := loadPersistedObjectResultByResultID[*Workspace](ctx, dec, persisted.SourceResultID, "workspace pull source")
	if err != nil {
		return nil, err
	}
	return &DirectoryWorkspacePullLazy{LazyState: NewLazyState(), Parent: parent, Source: source, Opts: persisted.Opts}, nil
}
