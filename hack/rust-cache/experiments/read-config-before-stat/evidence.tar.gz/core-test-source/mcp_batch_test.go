package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"github.com/dagger/dagger/dagql"
)

// batchFS is an in-memory stand-in for the agent's workspace: its write and
// edit tools are sequential steps that change it, its read tool is pure. It
// logs when each call starts and ends, so tests can assert on scheduling.
type batchFS struct {
	mu    sync.Mutex
	files map[string]string
	log   []string
}

func newBatchFS(files map[string]string) *batchFS {
	if files == nil {
		files = map[string]string{}
	}
	return &batchFS{files: files}
}

func (fs *batchFS) record(event string) {
	fs.mu.Lock()
	defer fs.mu.Unlock()
	fs.log = append(fs.log, event)
}

func (fs *batchFS) file(path string) (string, bool) {
	fs.mu.Lock()
	defer fs.mu.Unlock()
	contents, ok := fs.files[path]
	return contents, ok
}

// logged wraps a tool func with start/end events named after its "id"
// argument, or the tool name when there is none.
func (fs *batchFS) logged(name string, fn LLMToolFunc) LLMToolFunc {
	return func(ctx context.Context, rawArgs any) (any, error) {
		args, _ := rawArgs.(map[string]any)
		id, _ := args["id"].(string)
		if id == "" {
			id = name
		}
		fs.record("start " + id)
		defer fs.record("end " + id)
		return fn(ctx, args)
	}
}

func (fs *batchFS) tools() []LLMTool {
	str := func(args any, key string) string {
		s, _ := args.(map[string]any)[key].(string)
		return s
	}
	return []LLMTool{
		{
			Name: "write",
			Call: fs.logged("write", func(_ context.Context, args any) (any, error) {
				fs.mu.Lock()
				defer fs.mu.Unlock()
				fs.files[str(args, "path")] = str(args, "contents")
				return "wrote " + str(args, "path"), nil
			}),
		},
		{
			Name: "edit",
			Call: fs.logged("edit", func(_ context.Context, args any) (any, error) {
				fs.mu.Lock()
				defer fs.mu.Unlock()
				path, oldText := str(args, "path"), str(args, "oldText")
				contents, ok := fs.files[path]
				if !ok {
					return nil, fmt.Errorf("%s does not exist", path)
				}
				if n := strings.Count(contents, oldText); n != 1 {
					return nil, fmt.Errorf("search string found %d times", n)
				}
				fs.files[path] = strings.Replace(contents, oldText, str(args, "newText"), 1)
				return "edited " + path, nil
			}),
		},
		{
			Name:     "read",
			ReadOnly: true,
			Call: fs.logged("read", func(_ context.Context, args any) (any, error) {
				if d := str(args, "delay"); d != "" {
					delay, err := time.ParseDuration(d)
					if err != nil {
						return nil, err
					}
					time.Sleep(delay)
				}
				contents, ok := fs.file(str(args, "path"))
				if !ok {
					return nil, fmt.Errorf("%s does not exist", str(args, "path"))
				}
				return contents, nil
			}),
		},
	}
}

// batchCall builds a tool call numbered by its position in the batch.
func batchCall(t *testing.T, i int, name string, args map[string]any) *LLMToolCall {
	t.Helper()
	encoded, err := json.Marshal(args)
	require.NoError(t, err)
	return &LLMToolCall{CallID: fmt.Sprintf("call_%d", i), Name: name, Arguments: JSON(encoded)}
}

type batchResult struct {
	CallID  string
	Text    string
	Errored bool
}

func batchResults(t *testing.T, msgs []*LLMMessage) []batchResult {
	t.Helper()
	out := make([]batchResult, len(msgs))
	for i, msg := range msgs {
		require.NotNil(t, msg, "result %d is missing", i)
		require.Len(t, msg.Content, 1)
		block := msg.Content[0]
		require.Equal(t, LLMContentToolResult, block.Kind)
		out[i] = batchResult{CallID: block.CallID, Text: block.Text, Errored: block.Errored}
	}
	return out
}

// runBatch runs a batch that adopts no continuation, so every call runs.
func runBatch(ctx context.Context, t *testing.T, m *MCP, tools []LLMTool, calls []*LLMToolCall) []batchResult {
	t.Helper()
	results, rest := m.CallBatch(ctx, tools, calls, nil, nil)
	require.Empty(t, rest, "no continuation was adopted, so every call runs")
	return batchResults(t, results)
}

func TestCallBatchWriteThenReadSeesTheWrite(t *testing.T) {
	fs := newBatchFS(nil)
	calls := []*LLMToolCall{
		batchCall(t, 1, "write", map[string]any{"path": "a.txt", "contents": "hello"}),
		batchCall(t, 2, "read", map[string]any{"path": "a.txt"}),
	}
	results := runBatch(t.Context(), t, newMCP(), fs.tools(), calls)
	require.Equal(t, []batchResult{
		{CallID: "call_1", Text: "wrote a.txt"},
		{CallID: "call_2", Text: "hello"},
	}, results)
}

func TestCallBatchPreservesWriteOrder(t *testing.T) {
	// Each edit's oldText only exists once the edit before it has landed.
	fs := newBatchFS(map[string]string{"a.txt": "one"})
	calls := []*LLMToolCall{
		batchCall(t, 1, "edit", map[string]any{"path": "a.txt", "oldText": "one", "newText": "two"}),
		batchCall(t, 2, "edit", map[string]any{"path": "a.txt", "oldText": "two", "newText": "three"}),
		batchCall(t, 3, "write", map[string]any{"path": "b.txt", "contents": "b"}),
		batchCall(t, 4, "edit", map[string]any{"path": "b.txt", "oldText": "b", "newText": "bee"}),
	}
	results := runBatch(t.Context(), t, newMCP(), fs.tools(), calls)
	for _, res := range results {
		require.False(t, res.Errored, "%s: %s", res.CallID, res.Text)
	}
	a, _ := fs.file("a.txt")
	require.Equal(t, "three", a)
	b, _ := fs.file("b.txt")
	require.Equal(t, "bee", b)
}

func TestCallBatchRunsConsecutivePureCallsConcurrently(t *testing.T) {
	const n = 3
	var started sync.WaitGroup
	started.Add(n)
	allStarted := make(chan struct{})
	go func() {
		started.Wait()
		close(allStarted)
	}()
	tools := []LLMTool{{
		Name:     "wait",
		ReadOnly: true,
		Call: func(ctx context.Context, _ any) (any, error) {
			// Each call only returns once all of them are running at once.
			started.Done()
			select {
			case <-allStarted:
				return "ok", nil
			case <-time.After(10 * time.Second):
				return nil, errors.New("pure calls did not run concurrently")
			}
		},
	}}
	var calls []*LLMToolCall
	for i := 1; i <= n; i++ {
		calls = append(calls, batchCall(t, i, "wait", nil))
	}
	for _, res := range runBatch(t.Context(), t, newMCP(), tools, calls) {
		require.False(t, res.Errored, "%s: %s", res.CallID, res.Text)
	}
}

func TestCallBatchSequentialStepIsABarrier(t *testing.T) {
	fs := newBatchFS(map[string]string{"a.txt": "a"})
	calls := []*LLMToolCall{
		batchCall(t, 1, "read", map[string]any{"id": "r1", "path": "a.txt", "delay": "20ms"}),
		batchCall(t, 2, "read", map[string]any{"id": "r2", "path": "a.txt", "delay": "10ms"}),
		batchCall(t, 3, "write", map[string]any{"id": "w", "path": "a.txt", "contents": "A"}),
		batchCall(t, 4, "read", map[string]any{"id": "r3", "path": "a.txt"}),
		batchCall(t, 5, "read", map[string]any{"id": "r4", "path": "a.txt"}),
	}
	results := runBatch(t.Context(), t, newMCP(), fs.tools(), calls)
	require.Equal(t, []string{"a", "a", "wrote a.txt", "A", "A"}, []string{
		results[0].Text, results[1].Text, results[2].Text, results[3].Text, results[4].Text,
	})

	idx := func(event string) int {
		for i, e := range fs.log {
			if e == event {
				return i
			}
		}
		t.Fatalf("event %q not logged: %v", event, fs.log)
		return -1
	}
	// Everything before the write finished before it started, and nothing
	// after it started before it finished.
	require.Less(t, idx("end r1"), idx("start w"), fs.log)
	require.Less(t, idx("end r2"), idx("start w"), fs.log)
	require.Less(t, idx("end w"), idx("start r3"), fs.log)
	require.Less(t, idx("end w"), idx("start r4"), fs.log)
}

func TestCallBatchReturnsResultsInCallOrder(t *testing.T) {
	fs := newBatchFS(map[string]string{"a.txt": "a"})
	// The pure calls finish in the reverse of the order they were written.
	calls := []*LLMToolCall{
		batchCall(t, 1, "read", map[string]any{"path": "a.txt", "delay": "30ms"}),
		batchCall(t, 2, "read", map[string]any{"path": "a.txt", "delay": "15ms"}),
		batchCall(t, 3, "read", map[string]any{"path": "a.txt"}),
		batchCall(t, 4, "write", map[string]any{"path": "b.txt", "contents": "b"}),
		batchCall(t, 5, "nonexistent", nil),
		batchCall(t, 6, "read", map[string]any{"path": "b.txt"}),
	}
	results := runBatch(t.Context(), t, newMCP(), fs.tools(), calls)
	require.Len(t, results, len(calls))
	for i, res := range results {
		require.Equal(t, calls[i].CallID, res.CallID)
	}
}

func TestCallBatchFailedStepDoesNotStopTheBatch(t *testing.T) {
	fs := newBatchFS(map[string]string{"a.txt": "one one"})
	calls := []*LLMToolCall{
		batchCall(t, 1, "write", map[string]any{"path": "b.txt", "contents": "b"}),
		// Ambiguous: "one" occurs twice.
		batchCall(t, 2, "edit", map[string]any{"path": "a.txt", "oldText": "one", "newText": "two"}),
		batchCall(t, 3, "read", map[string]any{"path": "a.txt"}),
		batchCall(t, 4, "write", map[string]any{"path": "c.txt", "contents": "c"}),
	}
	results := runBatch(t.Context(), t, newMCP(), fs.tools(), calls)

	require.False(t, results[0].Errored)
	require.True(t, results[1].Errored)
	require.Contains(t, results[1].Text, "search string found 2 times")
	// Every call reports its own outcome: the ones after the failure still
	// ran, and read the tree as the failure left it.
	require.False(t, results[2].Errored)
	require.Equal(t, "one one", results[2].Text)
	require.False(t, results[3].Errored)

	b, _ := fs.file("b.txt")
	require.Equal(t, "b", b)
	c, _ := fs.file("c.txt")
	require.Equal(t, "c", c)
}

func TestCallBatchUnevaluableChangesetFailsItsOwnCall(t *testing.T) {
	ctx, cache, srv := containerPersistenceTestCache(t, "", newContainerPersistenceTestSnapshots(), "batch")
	srv.InstallObject(dagql.NewClass[*Changeset](srv))

	// A lazy changeset that fails once evaluated, as an edit with an ambiguous
	// search string does: its After directory is an operation nobody has run
	// yet, and running it is what finds the second match.
	evalErr := errors.New("search string found multiple times")
	before := attachStoredSnapshotTestValue(t, ctx, cache, srv, "batch", "before",
		storedSnapshotTestValue("Directory", "before", "/", false), false).(dagql.ObjectResult[*Directory])
	afterDir := storedSnapshotTestValue("Directory", "after", "/", false).(*Directory)
	afterDir.Lazy = &storedSnapshotTestLazy[*Directory]{LazyState: NewLazyState(), run: func(*Directory) error { return evalErr }}
	after := attachStoredSnapshotTestValue(t, ctx, cache, srv, "batch", "after", afterDir, false).(dagql.ObjectResult[*Directory])
	broken, err := NewChangeset(ctx, before, after)
	require.NoError(t, err)
	changes, err := dagql.NewObjectResultForCall(broken, srv, &dagql.ResultCall{
		Kind:        dagql.ResultCallKindSynthetic,
		SyntheticOp: "broken-edit",
		Type:        dagql.NewResultCallType(broken.Type()),
	})
	require.NoError(t, err)

	m := newMCP()
	fs := newBatchFS(nil)
	tools := append(fs.tools(), LLMTool{
		Name: "brokenEdit",
		Call: func(ctx context.Context, _ any) (any, error) {
			handled, out, err := m.applyStateReturn(ctx, srv, changes)
			require.True(t, handled)
			return out, err
		},
	})
	calls := []*LLMToolCall{
		batchCall(t, 1, "write", map[string]any{"path": "a.txt", "contents": "a"}),
		batchCall(t, 2, "brokenEdit", nil),
		batchCall(t, 3, "write", map[string]any{"path": "b.txt", "contents": "b"}),
	}
	results := runBatch(ctx, t, m, tools, calls)

	require.False(t, results[0].Errored)
	// The evaluation error is the call's own failure — it was never handed to
	// applyChangeset, which would have failed differently here (no workspace
	// is bound).
	require.True(t, results[1].Errored)
	require.Contains(t, results[1].Text, "search string found multiple times")
	require.NotContains(t, results[1].Text, "no workspace bound")
	require.False(t, results[2].Errored)

	a, _ := fs.file("a.txt")
	require.Equal(t, "a", a, "the write before the broken edit stays applied")
	b, _ := fs.file("b.txt")
	require.Equal(t, "b", b, "the write after it still runs")
}

// testContinuation is a stand-in for an LLM a tool returned.
func testContinuation(t *testing.T) dagql.ObjectResult[*LLM] {
	t.Helper()
	srv := newCoreDagqlServerForTest(t, &Query{})
	srv.InstallObject(dagql.NewClass(srv, dagql.ClassOpts[*LLM]{Typed: &LLM{}}))
	cont, err := dagql.NewObjectResultForCall(&LLM{}, srv, &dagql.ResultCall{
		Kind:        dagql.ResultCallKindSynthetic,
		SyntheticOp: "continuation",
		Type:        dagql.NewResultCallType((&LLM{}).Type()),
	})
	require.NoError(t, err)
	return cont
}

func TestCallBatchStopsAtContinuation(t *testing.T) {
	fs := newBatchFS(nil)
	cont := testContinuation(t)
	// continuationTools adds a "reload" tool returning an LLM to fs's tools:
	// adopting cont on m when adopt is true, failing otherwise.
	continuationTools := func(m *MCP, adopt bool) []LLMTool {
		return append(fs.tools(), LLMTool{
			Name:       "reload",
			ReturnsLLM: true,
			Call: fs.logged("reload", func(context.Context, any) (any, error) {
				if !adopt {
					return nil, errors.New("reload failed")
				}
				m.mu.Lock()
				defer m.mu.Unlock()
				m.continuation = cont
				return "reloaded", nil
			}),
		})
	}

	t.Run("in its position, with the calls before it folded in", func(t *testing.T) {
		fs.log = nil
		m := newMCP()
		calls := []*LLMToolCall{
			batchCall(t, 1, "write", map[string]any{"path": "a.txt", "contents": "a"}),
			batchCall(t, 2, "reload", nil),
			batchCall(t, 3, "read", map[string]any{"path": "a.txt"}),
			batchCall(t, 4, "write", map[string]any{"path": "b.txt", "contents": "b"}),
		}
		results, rest := m.CallBatch(t.Context(), continuationTools(m, true), calls, nil, func(context.Context) error {
			fs.record("fold")
			return nil
		})
		require.Equal(t, []string{"start write", "end write", "fold", "start reload", "end reload"}, fs.log)
		require.Equal(t, []batchResult{
			{CallID: "call_1", Text: "wrote a.txt"},
			{CallID: "call_2", Text: "reloaded"},
		}, batchResults(t, results))
		// The calls after it are written against the continued conversation,
		// so they are left for it to run.
		require.Equal(t, calls[2:], rest)
	})

	t.Run("a failed continuation does not stop the batch", func(t *testing.T) {
		fs.log = nil
		m := newMCP()
		calls := []*LLMToolCall{
			batchCall(t, 1, "reload", nil),
			batchCall(t, 2, "write", map[string]any{"path": "c.txt", "contents": "c"}),
		}
		var folded bool
		results, rest := m.CallBatch(t.Context(), continuationTools(m, false), calls, nil, func(context.Context) error {
			folded = true
			return nil
		})
		require.True(t, folded)
		require.Empty(t, rest)
		res := batchResults(t, results)
		require.True(t, res[0].Errored)
		require.Equal(t, batchResult{CallID: "call_2", Text: "wrote c.txt"}, res[1])
	})

	t.Run("not when the calls before it can't be folded in", func(t *testing.T) {
		fs.log = nil
		m := newMCP()
		calls := []*LLMToolCall{
			batchCall(t, 1, "reload", nil),
			batchCall(t, 2, "write", map[string]any{"path": "d.txt", "contents": "d"}),
		}
		results, rest := m.CallBatch(t.Context(), continuationTools(m, true), calls, nil, func(context.Context) error {
			return errors.New("boom")
		})
		require.Empty(t, rest)
		res := batchResults(t, results)
		require.True(t, res[0].Errored)
		require.Contains(t, res[0].Text, "boom")
		require.NotContains(t, fs.log, "start reload")
		require.False(t, res[1].Errored, res[1].Text)
	})

	t.Run("wrapped in Timeout", func(t *testing.T) {
		m := newMCP()
		allTools := NewLLMToolSet()
		for _, tool := range continuationTools(m, true) {
			require.True(t, allTools.Add(tool))
		}
		m.loadBuiltins(nil, allTools)
		tools := allTools.Order
		require.True(t, m.isContinuationCall(batchCall(t, 1, "reload", nil), tools))
		require.True(t, m.isContinuationCall(batchCall(t, 2, "Timeout", map[string]any{"duration": "1s", "tool": "reload", "arguments": map[string]any{}}), tools))
		require.False(t, m.isContinuationCall(batchCall(t, 3, "Timeout", map[string]any{"duration": "1s", "tool": "write", "arguments": map[string]any{}}), tools))
		require.False(t, m.isContinuationCall(batchCall(t, 4, "missing", nil), tools))
	})
}

func TestPlanBatchTimeoutPlansAsTheWrappedTool(t *testing.T) {
	fs := newBatchFS(map[string]string{"a.txt": "a"})
	m := newMCP()
	allTools := NewLLMToolSet()
	for _, tool := range fs.tools() {
		require.True(t, allTools.Add(tool))
	}
	m.loadBuiltins(nil, allTools)
	tools := allTools.Order

	timeout := func(i int, tool string, args map[string]any) *LLMToolCall {
		return batchCall(t, i, "Timeout", map[string]any{"duration": "1s", "tool": tool, "arguments": args})
	}
	calls := []*LLMToolCall{
		batchCall(t, 1, "read", map[string]any{"path": "a.txt"}),
		timeout(2, "read", map[string]any{"path": "a.txt"}),
		timeout(3, "write", map[string]any{"path": "b.txt", "contents": "b"}),
		timeout(4, "nonexistent", nil),
		batchCall(t, 5, "read", map[string]any{"path": "a.txt"}),
	}
	steps := m.planBatch(tools, calls)
	require.Len(t, steps, 4)
	// A timed-out read joins the reads around it...
	require.True(t, steps[0].pure)
	require.Equal(t, calls[0:2], steps[0].calls)
	// ...a timed-out write is the barrier the write would be...
	require.False(t, steps[1].pure)
	require.Equal(t, calls[2:3], steps[1].calls)
	// ...and one wrapping nothing known is sequential, the safe default.
	require.False(t, steps[2].pure)
	require.Equal(t, calls[3:4], steps[2].calls)
	require.True(t, steps[3].pure)

	// The plan is only scheduling: the calls still run through Timeout.
	results := runBatch(t.Context(), t, m, tools, calls)
	require.Equal(t, "a", results[1].Text)
	require.False(t, results[2].Errored, results[2].Text)
	require.True(t, results[3].Errored)
	b, _ := fs.file("b.txt")
	require.Equal(t, "b", b)
}

// mcpServerBatchFS registers fs's tools as the tools of a fake MCP server:
// registered with a session, but with no service container to sync a
// workspace into.
func mcpServerBatchFS(t *testing.T, m *MCP, server string, fs *batchFS) []LLMTool {
	t.Helper()
	m.mcpServers[server] = &MCPServerConfig{Name: server}
	m.mcpSessions[server] = nil
	var tools []LLMTool
	for _, tool := range fs.tools() {
		tool.Name = server + "_" + tool.Name
		tool.Server = server
		tools = append(tools, tool)
	}
	return tools
}

func TestPlanBatchGroupsMCPServerCalls(t *testing.T) {
	m := newMCP()
	local := newBatchFS(nil)
	tools := local.tools()
	tools = append(tools, mcpServerBatchFS(t, m, "fs", newBatchFS(nil))...)
	tools = append(tools, mcpServerBatchFS(t, m, "other", newBatchFS(nil))...)

	calls := []*LLMToolCall{
		batchCall(t, 1, "read", map[string]any{"path": "a"}),
		// A server's reads join its run: they read the server's working
		// directory, which only mirrors the workspace during the sync.
		batchCall(t, 2, "fs_read", map[string]any{"path": "a"}),
		batchCall(t, 3, "fs_write", map[string]any{"path": "a", "contents": "a"}),
		batchCall(t, 4, "fs_read", map[string]any{"path": "a"}),
		batchCall(t, 5, "other_read", map[string]any{"path": "a"}),
		batchCall(t, 6, "fs_read", map[string]any{"path": "a"}),
		batchCall(t, 7, "write", map[string]any{"path": "b", "contents": "b"}),
		batchCall(t, 8, "fs_read", map[string]any{"path": "a"}),
		batchCall(t, 9, "fs_read", map[string]any{"path": "a"}),
	}
	steps := m.planBatch(tools, calls)
	require.Len(t, steps, 6)
	require.Equal(t, batchStep{calls: calls[0:1], pure: true}, steps[0])
	require.Equal(t, batchStep{calls: calls[1:4], mcpServer: "fs"}, steps[1])
	require.Equal(t, batchStep{calls: calls[4:5], mcpServer: "other"}, steps[2])
	require.Equal(t, batchStep{calls: calls[5:6], mcpServer: "fs"}, steps[3])
	require.Equal(t, batchStep{calls: calls[6:7]}, steps[4])
	require.Equal(t, batchStep{calls: calls[7:9], mcpServer: "fs"}, steps[5])

	// Within a server's run, the calls are planned by purity alone.
	inner := m.planCalls(tools, steps[1].calls, false)
	require.Equal(t, []batchStep{
		{calls: calls[1:2], pure: true},
		{calls: calls[2:3]},
		{calls: calls[3:4], pure: true},
	}, inner)
}

func TestCallBatchMCPServerRunsCallsOnceWithoutSync(t *testing.T) {
	m := newMCP()
	fs := newBatchFS(nil)
	tools := mcpServerBatchFS(t, m, "fs", fs)

	// Registered, but nothing to sync with: no service container, no bound
	// workspace.
	require.False(t, m.mcpServerSyncsWorkspace("fs"))
	require.False(t, m.mcpServerSyncsWorkspace("unknown"))

	var runs int
	synced, err := m.callBatchMCPServer(t.Context(), "fs", func() { runs++ })
	require.NoError(t, err)
	require.False(t, synced)
	require.Equal(t, 1, runs, "the calls run exactly once, unsynced")

	// And through CallBatch: the server's calls take effect in order, each
	// executing once, with nothing to annotate.
	calls := []*LLMToolCall{
		batchCall(t, 1, "fs_write", map[string]any{"id": "w1", "path": "a.txt", "contents": "one"}),
		batchCall(t, 2, "fs_read", map[string]any{"id": "r1", "path": "a.txt"}),
		batchCall(t, 3, "fs_edit", map[string]any{"id": "e", "path": "a.txt", "oldText": "one", "newText": "two"}),
		batchCall(t, 4, "fs_read", map[string]any{"id": "r2", "path": "a.txt"}),
	}
	results := runBatch(t.Context(), t, m, tools, calls)
	require.Equal(t, []batchResult{
		{CallID: "call_1", Text: "wrote a.txt"},
		{CallID: "call_2", Text: "one"},
		{CallID: "call_3", Text: "edited a.txt"},
		{CallID: "call_4", Text: "two"},
	}, results)
	require.Equal(t, []string{
		"start w1", "end w1",
		"start r1", "end r1",
		"start e", "end e",
		"start r2", "end r2",
	}, fs.log)
}

func TestAnnotateMCPSyncFailure(t *testing.T) {
	read := &LLMToolCall{CallID: "read", Name: "read_file"}
	write := &LLMToolCall{CallID: "write", Name: "write_file"}
	plan := []batchStep{
		{calls: []*LLMToolCall{read}, pure: true},
		{calls: []*LLMToolCall{write}},
	}
	fresh := func() map[*LLMToolCall]*LLMContentBlock {
		return map[*LLMToolCall]*LLMContentBlock{
			read:  {Kind: LLMContentToolResult, CallID: "read", Text: "contents"},
			write: {Kind: LLMContentToolResult, CallID: "write", Text: "wrote"},
		}
	}
	syncErr := errors.New("mount failed")

	t.Run("sync failed after the calls ran", func(t *testing.T) {
		results := fresh()
		annotateMCPSyncFailure("fs", plan, results, true, syncErr)
		// The read stands; the write's effect never reached the workspace.
		require.False(t, results[read].Errored)
		require.Equal(t, "contents", results[read].Text)
		require.True(t, results[write].Errored)
		require.Contains(t, results[write].Text, "wrote\n\nWARNING")
		require.Contains(t, results[write].Text, "could not be carried back into the workspace: mount failed")
	})

	t.Run("calls ran unsynced", func(t *testing.T) {
		results := fresh()
		annotateMCPSyncFailure("fs", plan, results, false, syncErr)
		// Both are suspect: the server never saw the workspace.
		for _, call := range []*LLMToolCall{read, write} {
			require.True(t, results[call].Errored, call.CallID)
			require.Contains(t, results[call].Text, "ran against a stale tree")
			require.Contains(t, results[call].Text, "mount failed")
		}
	})
}
