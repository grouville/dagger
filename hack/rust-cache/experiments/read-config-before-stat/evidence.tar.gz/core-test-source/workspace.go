package core

import (
	"context"
	"encoding/json"
	"fmt"
	"path"
	"path/filepath"
	"slices"
	"strings"

	workspacepkg "github.com/dagger/dagger/core/workspace"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/util/gitutil"
	"github.com/vektah/gqlparser/v2/ast"
)

// workspaceInvalidator drops the cached per-client workspace detection so the
// next access re-detects from the host. Set by engine/server (which owns the
// per-client cache); nil in contexts without a server, where invalidation is a
// no-op.
var workspaceInvalidator func(context.Context) error

// SetWorkspaceInvalidator registers the hook used to drop the current client's
// cached workspace detection. Mirrors SetModuleSourceSDKLoader.
func SetWorkspaceInvalidator(fn func(context.Context) error) {
	workspaceInvalidator = fn
}

// InvalidateCurrentWorkspace drops the calling client's cached workspace
// detection so the next access re-detects it from the host. Used after writing
// workspace config files to the host (e.g. applying a migration changeset),
// since the per-client cache would otherwise keep serving the pre-write view
// for the lifetime of the client — which, under nested execution, spans more
// than one session.
func InvalidateCurrentWorkspace(ctx context.Context) error {
	if workspaceInvalidator == nil {
		return nil
	}
	return workspaceInvalidator(ctx)
}

// workspaceReadEpoch hooks expose the calling client's "workspace read epoch":
// a monotonically bumped token folded into cached host reads (Workspace.file /
// Workspace.directory) so a single long-lived session can invalidate them when
// the workspace's on-disk content changes out from under it.
//
// host.directory reads are cached per client for the client's whole lifetime
// (dagql.PerClientInput), so within one session — such as a `dagger agent`
// conversation — a file read earlier in the session keeps returning its
// original snapshot even after the agent's edits are exported to disk. Bumping
// the epoch on Workspace.export gives subsequent reads (and the host baseline
// the next export diffs against) a fresh per-client cache namespace, so they
// re-read the (now updated) host instead of the stale snapshot.
//
// Both hooks are registered by engine/server (which owns the per-client cache);
// nil in contexts without a server, where the epoch is empty and bumping is a
// no-op.
var (
	workspaceReadEpochGetter func(context.Context) (string, error)
	workspaceReadEpochBumper func(context.Context) error
)

// SetWorkspaceReadEpochHooks registers the getter/bumper used to scope and
// invalidate a client's cached workspace host reads. Mirrors
// SetWorkspaceInvalidator.
func SetWorkspaceReadEpochHooks(
	get func(context.Context) (string, error),
	bump func(context.Context) error,
) {
	workspaceReadEpochGetter = get
	workspaceReadEpochBumper = bump
}

// WorkspaceReadEpoch returns the calling client's current workspace read epoch,
// or "" when no server has registered the hook (nothing to scope by).
func WorkspaceReadEpoch(ctx context.Context) (string, error) {
	if workspaceReadEpochGetter == nil {
		return "", nil
	}
	return workspaceReadEpochGetter(ctx)
}

// BumpWorkspaceReadEpoch advances the calling client's workspace read epoch so
// cached host reads made before the bump are no longer served. A no-op when no
// server has registered the hook.
func BumpWorkspaceReadEpoch(ctx context.Context) error {
	if workspaceReadEpochBumper == nil {
		return nil
	}
	return workspaceReadEpochBumper(ctx)
}

// Workspace represents a detected workspace in the dagql schema.
type Workspace struct {
	// source is the private backing source for workspace filesystem and git
	// behavior. It is intentionally not exposed through GraphQL.
	source WorkspaceSource

	// rootfs is the pre-fetched root filesystem for remote workspaces.
	// Internal only — not exposed in GraphQL. Local workspaces resolve
	// directories lazily via per-call host.directory() instead.
	rootfs dagql.ObjectResult[*Directory]

	// mounts is an in-engine directory tree holding content attached read-only
	// via Workspace.withMountedDirectory/withMountedFile, keyed by
	// workspace-root-relative mount path. Internal only — not a GraphQL field,
	// but persisted and dependency-tracked like rootfs. Nil when the workspace
	// has no mounts. It is intentionally kept separate from the overlay
	// changeset so mounted content is readable through the normal workspace
	// file tools but is never treated as a pending change or exported.
	mounts dagql.ObjectResult[*Directory]

	// mountPoints lists the workspace-root-relative paths at which content is
	// mounted, sorted and deduplicated. Reads at or under a mount point
	// resolve from mounts (shadowing the source), and overlay edits there are
	// rejected, keeping mounted content read-only.
	mountPoints []string

	// compatWorkspace stores the originating compat-workspace projection when
	// this workspace was loaded from a legacy dagger.json instead of an explicit
	// dagger.toml. Internal only.
	compatWorkspace *workspacepkg.CompatWorkspace

	// userConfigKey is the normalized Git remote key identifying this
	// workspace in user-level config. Empty when the workspace has no usable
	// remote. Internal only.
	userConfigKey string

	// userConfigOverlay is the user-level config overlay matched for this
	// workspace by userConfigKey. Not a GraphQL field: a live workspace reads
	// it once at session load, and value workspaces carry it in their recipe
	// via Workspace.__withUserConfigOverlay (see Workspace.withUserConfig).
	userConfigOverlay *workspacepkg.UserWorkspaceOverlay

	// selectedEnv is the dagger.toml environment selected when this workspace
	// was loaded. It travels with the workspace when the workspace is passed to
	// an SDK, whose nested client does not inherit the parent client's ambient
	// workspace selection.
	selectedEnv string

	// moduleClients maps a module scope path to the local client targets its
	// config declares, as read when this workspace was loaded. Internal only.
	moduleClients map[string][]string

	Address    string `field:"true" doc:"Canonical Dagger address of the workspace location, or an opaque identity for synthetic workspaces."`
	Cwd        string
	ConfigFile string

	// LockFile is the selected lockfile path relative to the workspace root.
	// It is independent from ConfigFile: compat config and missing native config
	// can still have a writable local lockfile.
	LockFile string

	// ClientID is the ID of the client that created this workspace.
	// Used to route host filesystem operations through the correct session
	// when the workspace is passed to a module function.
	ClientID string

	// hostPath is the host filesystem path for the workspace boundary.
	// Internal only (not in GraphQL schema). Empty for remote workspaces.
	// Used by workspace filesystem operations that need host access.
	hostPath string
}

// WorkspaceSource is the private backing source for a Workspace.
//
// It is exported only so schema/server packages can pass source values around;
// the unexported method keeps implementations local to core.
type WorkspaceSource interface {
	workspaceSource()
}

type WorkspaceSourceClientLocal struct {
	HostPath string
}

func (*WorkspaceSourceClientLocal) workspaceSource() {}

type WorkspaceSourceRootlessLocal struct {
	HostPath string
}

func (*WorkspaceSourceRootlessLocal) workspaceSource() {}

type WorkspaceSourceDirectory struct {
	Root dagql.ObjectResult[*Directory]
}

func (*WorkspaceSourceDirectory) workspaceSource() {}

type WorkspaceSourceGitRef struct {
	Ref dagql.Result[*GitRef]
	// ExplicitCommit distinguishes a workspace requested by immutable commit SHA
	// from a mutable ref that happens to resolve to the same commit.
	ExplicitCommit bool
}

func (*WorkspaceSourceGitRef) workspaceSource() {}

type WorkspaceSourceOverlay struct {
	Base WorkspaceSource
	// TouchedPaths is the cumulative set of workspace-relative paths the
	// overlay's edits affect. Set only for host-backed (client-local) overlays,
	// where it sizes the sparse diff base: Changes.After is the accumulated
	// edits applied to an empty base (the delta root — it never references the
	// host tree) and Changes.Before is host.directory including only these
	// paths, so forcing the changeset syncs just the touched files instead of
	// uploading the whole workspace. Value/git/rootless overlays leave this nil
	// and diff full in-engine trees (nothing to upload).
	TouchedPaths []string
	// SeededPaths is the subset of TouchedPaths whose pre-existing workspace
	// content the overlay folded into Changes.After, for edits that build on
	// what a path already holds (see overlayEdit's readsExisting). Every later
	// edit re-seeds them from the base it diffs against: content the caller
	// never wrote, left pinned here, comes back reported as modified the moment
	// they edit that file on disk.
	SeededPaths []string
	Changes     dagql.ObjectResult[*Changeset]
}

func (*WorkspaceSourceOverlay) workspaceSource() {}

func NewWorkspaceSourceClientLocal(hostPath string) WorkspaceSource {
	return &WorkspaceSourceClientLocal{
		HostPath: hostPath,
	}
}

func NewWorkspaceSourceRootlessLocal(hostPath string) WorkspaceSource {
	return &WorkspaceSourceRootlessLocal{
		HostPath: hostPath,
	}
}

func NewWorkspaceSourceDirectory(root dagql.ObjectResult[*Directory]) WorkspaceSource {
	return &WorkspaceSourceDirectory{
		Root: root,
	}
}

func NewWorkspaceSourceGitRef(ref dagql.Result[*GitRef], explicitCommit bool) WorkspaceSource {
	return &WorkspaceSourceGitRef{
		Ref:            ref,
		ExplicitCommit: explicitCommit,
	}
}

func NewWorkspaceSourceOverlay(
	base WorkspaceSource,
	touchedPaths []string,
	seededPaths []string,
	changes dagql.ObjectResult[*Changeset],
) WorkspaceSource {
	if overlay, ok := base.(*WorkspaceSourceOverlay); ok {
		base = overlay.Base
	}
	// The caller accumulates TouchedPaths and SeededPaths (union with the
	// parent overlay's) before constructing, so they are already cumulative
	// here.
	return &WorkspaceSourceOverlay{
		Base:         base,
		TouchedPaths: touchedPaths,
		SeededPaths:  seededPaths,
		Changes:      changes,
	}
}

func (ws *Workspace) Source() WorkspaceSource {
	if ws == nil {
		return nil
	}
	if ws.source != nil {
		return ws.source
	}
	if ws.hostPath != "" {
		return NewWorkspaceSourceClientLocal(ws.hostPath)
	}
	if ws.rootfs.Self() != nil {
		return NewWorkspaceSourceDirectory(ws.rootfs)
	}
	return nil
}

func (ws *Workspace) SetSource(src WorkspaceSource) {
	ws.source = src
}

func (ws *Workspace) SourceDirectory() (dagql.ObjectResult[*Directory], bool) {
	if ws == nil {
		return dagql.ObjectResult[*Directory]{}, false
	}
	switch src := ws.Source().(type) {
	case *WorkspaceSourceDirectory:
		if src.Root.Self() != nil {
			return src.Root, true
		}
	case *WorkspaceSourceGitRef:
		if ws.rootfs.Self() != nil {
			return ws.rootfs, true
		}
	case *WorkspaceSourceOverlay:
		if _, local := src.Base.(*WorkspaceSourceClientLocal); local {
			// Host-backed overlays store no full tree: Changes.After is the
			// edits applied to an empty base (sparse), not host + edits.
			// Reads resolve per-call against the host instead (see
			// schema.resolveHostOverlayRootfs).
			return dagql.ObjectResult[*Directory]{}, false
		}
		if changes := src.Changes.Self(); changes != nil && changes.After.Self() != nil {
			return changes.After, true
		}
	}
	if ws.rootfs.Self() != nil {
		return ws.rootfs, true
	}
	return dagql.ObjectResult[*Directory]{}, false
}

func (ws *Workspace) SourceGitRef() (dagql.Result[*GitRef], bool) {
	ref, ok := workspaceSourceGitRef(ws.Source())
	return ref, ok
}

func workspaceSourceGitRef(src WorkspaceSource) (dagql.Result[*GitRef], bool) {
	switch src := src.(type) {
	case *WorkspaceSourceGitRef:
		if src.Ref.Self() != nil {
			return src.Ref, true
		}
	case *WorkspaceSourceOverlay:
		return workspaceSourceGitRef(src.Base)
	}
	return dagql.Result[*GitRef]{}, false
}

func (ws *Workspace) OverlayChanges() (dagql.ObjectResult[*Changeset], bool) {
	overlay, ok := ws.Source().(*WorkspaceSourceOverlay)
	if !ok || overlay.Changes.Self() == nil {
		return dagql.ObjectResult[*Changeset]{}, false
	}
	return overlay.Changes, true
}

// ClientLocalBase reports whether the workspace's base source is the client's
// local git-rooted host directory. False for rootless local workspaces (which
// also carry a host path but must not read through it) and for value/git
// workspaces.
func (ws *Workspace) ClientLocalBase() bool {
	if ws == nil {
		return false
	}
	_, ok := ws.BaseSource().(*WorkspaceSourceClientLocal)
	return ok
}

// OverlayDeltaRoot returns a host-backed overlay's accumulated edits applied to
// an empty base — the changeset's After side, which never references the host
// tree — or false if this workspace has no such overlay (a pristine workspace,
// or a value/git/rootless overlay whose After is a full tree).
func (ws *Workspace) OverlayDeltaRoot() (dagql.ObjectResult[*Directory], bool) {
	if !ws.ClientLocalBase() {
		return dagql.ObjectResult[*Directory]{}, false
	}
	overlay, ok := ws.Source().(*WorkspaceSourceOverlay)
	if !ok {
		return dagql.ObjectResult[*Directory]{}, false
	}
	changes := overlay.Changes.Self()
	if changes == nil || changes.After.Self() == nil {
		return dagql.ObjectResult[*Directory]{}, false
	}
	return changes.After, true
}

// OverlayTouchedPaths returns the cumulative set of workspace-relative paths the
// overlay's edits affect, used to size the sparse diff base.
func (ws *Workspace) OverlayTouchedPaths() []string {
	overlay, ok := ws.Source().(*WorkspaceSourceOverlay)
	if !ok {
		return nil
	}
	return overlay.TouchedPaths
}

// OverlaySeededPaths returns the cumulative set of workspace-relative paths
// whose pre-existing content the overlay folded into its changeset's after
// side, which every later edit has to refresh from the base it diffs against.
func (ws *Workspace) OverlaySeededPaths() []string {
	overlay, ok := ws.Source().(*WorkspaceSourceOverlay)
	if !ok {
		return nil
	}
	return overlay.SeededPaths
}

// OverlayPathTouched reports whether the overlay's edits affect the given
// workspace-relative path, either directly or via a touched parent directory.
func (ws *Workspace) OverlayPathTouched(p string) bool {
	p = path.Clean(filepath.ToSlash(p))
	for _, touched := range ws.OverlayTouchedPaths() {
		touched = path.Clean(filepath.ToSlash(touched))
		if p == touched || strings.HasPrefix(p, touched+"/") {
			return true
		}
	}
	return false
}

func (ws *Workspace) BaseSource() WorkspaceSource {
	src := ws.Source()
	if overlay, ok := src.(*WorkspaceSourceOverlay); ok {
		return overlay.Base
	}
	return src
}

func (ws *Workspace) LocalSourceHostPath() (string, bool) {
	if ws == nil {
		return "", false
	}
	switch src := ws.BaseSource().(type) {
	case *WorkspaceSourceClientLocal:
		return src.HostPath, src.HostPath != ""
	case *WorkspaceSourceRootlessLocal:
		return src.HostPath, src.HostPath != ""
	default:
		return "", false
	}
}

func (ws *Workspace) ExportHostPath() (string, error) {
	if ws == nil {
		return "", fmt.Errorf("workspace is required")
	}
	switch src := ws.BaseSource().(type) {
	case *WorkspaceSourceClientLocal:
		if src.HostPath == "" {
			return "", fmt.Errorf("workspace export requires a local Git workspace")
		}
		return src.HostPath, nil
	case *WorkspaceSourceRootlessLocal:
		return "", fmt.Errorf("workspace export requires a local Git workspace")
	case *WorkspaceSourceGitRef:
		return "", fmt.Errorf("cannot export a remote Git workspace")
	case *WorkspaceSourceDirectory:
		return "", fmt.Errorf("cannot export a synthetic workspace")
	case nil:
		return "", fmt.Errorf("workspace export requires a local Git workspace")
	default:
		return "", fmt.Errorf("cannot export workspace source %T", src)
	}
}

func (ws *Workspace) IsValueWorkspace() bool {
	if ws == nil || ws.ClientID != "" {
		return false
	}
	switch ws.Source().(type) {
	case *WorkspaceSourceDirectory, *WorkspaceSourceGitRef, *WorkspaceSourceOverlay:
		return true
	default:
		return false
	}
}

// Rootfs returns the pre-fetched root filesystem directory for remote workspaces.
// Returns a zero value for local workspaces (they resolve lazily).
func (ws *Workspace) Rootfs() dagql.ObjectResult[*Directory] {
	if root, ok := ws.SourceDirectory(); ok {
		return root
	}
	return ws.rootfs
}

// SetRootfs sets the pre-fetched root filesystem (used by remote workspace setup).
func (ws *Workspace) SetRootfs(r dagql.ObjectResult[*Directory]) {
	ws.rootfs = r
}

// HostPath returns the internal host filesystem path for the workspace boundary.
// Returns empty string for remote workspaces (read-only).
func (ws *Workspace) HostPath() string {
	return ws.hostPath
}

// SetHostPath sets the internal host filesystem path.
func (ws *Workspace) SetHostPath(p string) {
	ws.hostPath = p
}

func (ws *Workspace) UserConfigKey() string {
	if ws == nil {
		return ""
	}
	return ws.userConfigKey
}

func (ws *Workspace) SetUserConfigKey(key string) {
	ws.userConfigKey = key
}

func (ws *Workspace) UserConfigOverlay() *workspacepkg.UserWorkspaceOverlay {
	if ws == nil {
		return nil
	}
	return ws.userConfigOverlay
}

func (ws *Workspace) SetUserConfigOverlay(overlay *workspacepkg.UserWorkspaceOverlay) {
	ws.userConfigOverlay = overlay
}

func (ws *Workspace) SelectedEnv() string {
	if ws == nil {
		return ""
	}
	return ws.selectedEnv
}

func (ws *Workspace) SetSelectedEnv(name string) {
	ws.selectedEnv = name
}

// ModuleClients returns the local client targets the workspace config declares
// for the module scope at modulePath, both workspace-root-relative.
func (ws *Workspace) ModuleClients(modulePath string) []string {
	if ws == nil {
		return nil
	}
	return ws.moduleClients[modulePath]
}

func (ws *Workspace) SetModuleClients(clients map[string][]string) {
	ws.moduleClients = clients
}

// MountsDir returns the read-only directory tree holding mounted content,
// keyed by workspace-root-relative mount path, or false when the workspace has
// no mounts.
func (ws *Workspace) MountsDir() (dagql.ObjectResult[*Directory], bool) {
	if ws == nil || ws.mounts.Self() == nil {
		return dagql.ObjectResult[*Directory]{}, false
	}
	return ws.mounts, true
}

// WithMounted returns a copy of the workspace with the given read-only
// mounted content tree and the workspace-root-relative path recorded as a
// mount point, keeping the mount point list sorted and deduplicated.
func (ws *Workspace) WithMounted(newMounts dagql.ObjectResult[*Directory], path string) *Workspace {
	cp := ws.Clone()
	cp.mounts = newMounts
	p := filepath.ToSlash(path)
	if i, found := slices.BinarySearch(cp.mountPoints, p); !found {
		cp.mountPoints = slices.Insert(cp.mountPoints, i, p)
	}
	return cp
}

// WithoutMountedAt returns a copy of the workspace with the given mounts tree
// and every mount point at or under the workspace-root-relative path removed.
func (ws *Workspace) WithoutMountedAt(newMounts dagql.ObjectResult[*Directory], path string) *Workspace {
	cp := ws.Clone()
	cp.mounts = newMounts
	p := filepath.ToSlash(path)
	cp.mountPoints = slices.DeleteFunc(cp.mountPoints, func(target string) bool {
		return p == "." || target == p || strings.HasPrefix(target, p+"/")
	})
	if len(cp.mountPoints) == 0 {
		cp.mounts = dagql.ObjectResult[*Directory]{}
	}
	return cp
}

// MountPoints returns the sorted workspace-root-relative mount paths.
func (ws *Workspace) MountPoints() []string {
	if ws == nil {
		return nil
	}
	return slices.Clone(ws.mountPoints)
}

// MountedPath reports whether a workspace-root-relative path is at or under
// one of the workspace's mount points.
func (ws *Workspace) MountedPath(resolvedPath string) bool {
	if ws == nil {
		return false
	}
	p := filepath.ToSlash(resolvedPath)
	for _, mp := range ws.mountPoints {
		if p == mp || strings.HasPrefix(p, mp+"/") {
			return true
		}
	}
	return false
}

// HasMountsUnder reports whether any mount point lies strictly below the given
// workspace-root-relative path.
func (ws *Workspace) HasMountsUnder(resolvedPath string) bool {
	if ws == nil || len(ws.mountPoints) == 0 {
		return false
	}
	p := filepath.ToSlash(resolvedPath)
	if p == "." || p == "" {
		return true
	}
	for _, mp := range ws.mountPoints {
		if strings.HasPrefix(mp, p+"/") {
			return true
		}
	}
	return false
}

// CompatWorkspace returns the internal compat-workspace provenance for this
// workspace. Nil means this workspace was not loaded from legacy compat mode.
func (ws *Workspace) CompatWorkspace() *workspacepkg.CompatWorkspace {
	return ws.compatWorkspace
}

// SetCompatWorkspace sets the internal compat-workspace provenance.
func (ws *Workspace) SetCompatWorkspace(compat *workspacepkg.CompatWorkspace) {
	ws.compatWorkspace = compat
}

func (*Workspace) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Workspace",
		NonNull:   true,
	}
}

func (*Workspace) TypeDescription() string {
	return "A Dagger workspace detected from the current working directory or constructed from a Directory."
}

var _ dagql.PersistedObject = (*Workspace)(nil)
var _ dagql.PersistedObjectDecoder = (*Workspace)(nil)
var _ dagql.HasDependencyResults = (*Workspace)(nil)

type persistedWorkspacePayload struct {
	RootfsResultID  uint64                        `json:"rootfsResultID,omitempty"`
	MountsResultID  uint64                        `json:"mountsResultID,omitempty"`
	MountPoints     []string                      `json:"mountPoints,omitempty"`
	Source          *persistedWorkspaceSource     `json:"source,omitempty"`
	CompatWorkspace *workspacepkg.CompatWorkspace `json:"compatWorkspace,omitempty"`
	Address         string                        `json:"address,omitempty"`
	Cwd             string                        `json:"cwd,omitempty"`
	ConfigFile      string                        `json:"configFile,omitempty"`
	LockFile        string                        `json:"lockFile,omitempty"`
	ClientID        string                        `json:"clientID,omitempty"`
	HostPath        string                        `json:"hostPath,omitempty"`
	SelectedEnv     string                        `json:"selectedEnv,omitempty"`
	ModuleClients   map[string][]string           `json:"moduleClients,omitempty"`

	// Decode-only names from main's pre-workspace-selection payload.
	LegacyPath       string `json:"path,omitempty"`
	LegacyConfigPath string `json:"configPath,omitempty"`
}

type persistedWorkspaceSource struct {
	Kind           string                    `json:"kind"`
	RootResultID   uint64                    `json:"rootResultID,omitempty"`
	GitRefResultID uint64                    `json:"gitRefResultID,omitempty"`
	ExplicitCommit bool                      `json:"explicitCommit,omitempty"`
	ChangesID      uint64                    `json:"changesID,omitempty"`
	TouchedPaths   []string                  `json:"touchedPaths,omitempty"`
	SeededPaths    []string                  `json:"seededPaths,omitempty"`
	HostPath       string                    `json:"hostPath,omitempty"`
	Base           *persistedWorkspaceSource `json:"base,omitempty"`
}

const (
	persistedWorkspaceSourceClientLocal = "clientLocal"
	persistedWorkspaceSourceRootless    = "rootlessLocal"
	persistedWorkspaceSourceDirectory   = "directory"
	persistedWorkspaceSourceGitRef      = "gitRef"
	persistedWorkspaceSourceOverlay     = "overlay"
)

func encodePersistedWorkspaceSource(enc *dagql.PersistEncodeContext, src WorkspaceSource) (*persistedWorkspaceSource, error) {
	switch src := src.(type) {
	case *WorkspaceSourceClientLocal:
		return &persistedWorkspaceSource{Kind: persistedWorkspaceSourceClientLocal}, nil
	case *WorkspaceSourceRootlessLocal:
		return &persistedWorkspaceSource{
			Kind:     persistedWorkspaceSourceRootless,
			HostPath: src.HostPath,
		}, nil
	case *WorkspaceSourceDirectory:
		payload := &persistedWorkspaceSource{Kind: persistedWorkspaceSourceDirectory}
		if src.Root.Self() != nil {
			rootID, err := encodePersistedObjectRef(enc, src.Root, "workspace directory source")
			if err != nil {
				return nil, err
			}
			payload.RootResultID = rootID
		}
		return payload, nil
	case *WorkspaceSourceGitRef:
		refID, err := encodePersistedObjectRef(enc, src.Ref, "workspace git ref source")
		if err != nil {
			return nil, err
		}
		return &persistedWorkspaceSource{
			Kind:           persistedWorkspaceSourceGitRef,
			GitRefResultID: refID,
			ExplicitCommit: src.ExplicitCommit,
		}, nil
	case *WorkspaceSourceOverlay:
		payload := &persistedWorkspaceSource{Kind: persistedWorkspaceSourceOverlay}
		if src.Base != nil {
			base, err := encodePersistedWorkspaceSource(enc, src.Base)
			if err != nil {
				return nil, err
			}
			payload.Base = base
		}
		payload.TouchedPaths = src.TouchedPaths
		payload.SeededPaths = src.SeededPaths
		if src.Changes.Self() != nil {
			changesID, err := encodePersistedObjectRef(enc, src.Changes, "workspace overlay changes")
			if err != nil {
				return nil, err
			}
			payload.ChangesID = changesID
		}
		return payload, nil
	default:
		return nil, fmt.Errorf("encode persisted workspace source: unsupported source %T", src)
	}
}

func decodePersistedWorkspaceSource(
	ctx context.Context,
	dec *dagql.PersistDecodeContext,
	persisted *persistedWorkspaceSource,
	rootfs dagql.ObjectResult[*Directory],
	hostPath string,
) (WorkspaceSource, error) {
	if persisted == nil {
		return nil, nil
	}
	switch persisted.Kind {
	case persistedWorkspaceSourceClientLocal:
		return NewWorkspaceSourceClientLocal(hostPath), nil
	case persistedWorkspaceSourceRootless:
		rootlessHostPath := persisted.HostPath
		if rootlessHostPath == "" {
			rootlessHostPath = hostPath
		}
		return NewWorkspaceSourceRootlessLocal(rootlessHostPath), nil
	case persistedWorkspaceSourceDirectory:
		root := rootfs
		if persisted.RootResultID != 0 {
			var err error
			root, err = loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.RootResultID, "workspace directory source")
			if err != nil {
				return nil, err
			}
		}
		return NewWorkspaceSourceDirectory(root), nil
	case persistedWorkspaceSourceGitRef:
		if persisted.GitRefResultID == 0 {
			return nil, fmt.Errorf("decode persisted workspace source: gitRef missing result ID")
		}
		ref, err := loadPersistedObjectResultByResultID[*GitRef](ctx, dec, persisted.GitRefResultID, "workspace git ref source")
		if err != nil {
			return nil, err
		}
		return NewWorkspaceSourceGitRef(ref.Result, persisted.ExplicitCommit), nil
	case persistedWorkspaceSourceOverlay:
		base, err := decodePersistedWorkspaceSource(ctx, dec, persisted.Base, rootfs, hostPath)
		if err != nil {
			return nil, err
		}
		var changes dagql.ObjectResult[*Changeset]
		if persisted.ChangesID != 0 {
			changes, err = loadPersistedObjectResultByResultID[*Changeset](ctx, dec, persisted.ChangesID, "workspace overlay changes")
			if err != nil {
				return nil, err
			}
		}
		return NewWorkspaceSourceOverlay(base, persisted.TouchedPaths, persisted.SeededPaths, changes), nil
	default:
		return nil, fmt.Errorf("decode persisted workspace source: unsupported source kind %q", persisted.Kind)
	}
}

func (ws *Workspace) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	_ = ctx
	if ws == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted workspace: nil workspace")
	}

	payload := persistedWorkspacePayload{
		CompatWorkspace: ws.compatWorkspace,
		Address:         ws.Address,
		Cwd:             ws.Cwd,
		ConfigFile:      ws.ConfigFile,
		LockFile:        ws.LockFile,
		ClientID:        ws.ClientID,
		HostPath:        ws.hostPath,
		SelectedEnv:     ws.selectedEnv,
		ModuleClients:   ws.moduleClients,
	}
	if ws.rootfs.Self() != nil {
		rootfsID, err := encodePersistedObjectRef(enc, ws.rootfs, "workspace rootfs")
		if err != nil {
			return dagql.PersistedObjectEncoding{}, err
		}
		payload.RootfsResultID = rootfsID
	}
	if ws.mounts.Self() != nil {
		mountsID, err := encodePersistedObjectRef(enc, ws.mounts, "workspace mounts")
		if err != nil {
			return dagql.PersistedObjectEncoding{}, err
		}
		payload.MountsResultID = mountsID
		payload.MountPoints = ws.mountPoints
	}
	if ws.Source() != nil {
		source, err := encodePersistedWorkspaceSource(enc, ws.Source())
		if err != nil {
			return dagql.PersistedObjectEncoding{}, err
		}
		payload.Source = source
	}

	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("marshal persisted workspace payload: %w", err)
	}
	return encodePersistedObjectRawJSON(payloadBytes), nil
}

func (*Workspace) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	var persisted persistedWorkspacePayload
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted workspace payload: %w", err)
	}

	var rootfs dagql.ObjectResult[*Directory]
	if persisted.RootfsResultID != 0 {
		var err error
		rootfs, err = loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.RootfsResultID, "workspace rootfs")
		if err != nil {
			return nil, err
		}
	}

	var mounts dagql.ObjectResult[*Directory]
	if persisted.MountsResultID != 0 {
		var err error
		mounts, err = loadPersistedObjectResultByResultID[*Directory](ctx, dec, persisted.MountsResultID, "workspace mounts")
		if err != nil {
			return nil, err
		}
	}

	cwd := persisted.Cwd
	if cwd == "" {
		cwd = persisted.LegacyPath
	}
	configFile := persisted.ConfigFile
	if configFile == "" {
		configFile = persisted.LegacyConfigPath
	}
	lockFile := persisted.LockFile
	if lockFile == "" && configFile != "" {
		lockFile = filepath.Join(filepath.Dir(configFile), workspacepkg.LockFileName)
	}
	lockFile = workspacepkg.CanonicalLockFilePath(lockFile)

	ws := &Workspace{
		rootfs:          rootfs,
		mounts:          mounts,
		mountPoints:     persisted.MountPoints,
		compatWorkspace: persisted.CompatWorkspace,
		Address:         persisted.Address,
		Cwd:             cwd,
		ConfigFile:      configFile,
		LockFile:        lockFile,
		ClientID:        persisted.ClientID,
		hostPath:        persisted.HostPath,
		selectedEnv:     persisted.SelectedEnv,
		moduleClients:   persisted.ModuleClients,
	}
	if persisted.Source != nil {
		src, err := decodePersistedWorkspaceSource(ctx, dec, persisted.Source, rootfs, persisted.HostPath)
		if err != nil {
			return nil, err
		}
		ws.source = src
	}
	return ws, nil
}

func (ws *Workspace) AttachDependencyResults(
	ctx context.Context,
	_ dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.AnyResult, error) {
	_ = ctx
	if ws == nil {
		return nil, nil
	}

	var deps []dagql.AnyResult
	if ws.rootfs.Self() != nil {
		attached, err := attach(ws.rootfs)
		if err != nil {
			return nil, fmt.Errorf("attach workspace rootfs: %w", err)
		}
		typed, ok := attached.(dagql.ObjectResult[*Directory])
		if !ok {
			return nil, fmt.Errorf("attach workspace rootfs: unexpected result %T", attached)
		}
		ws.rootfs = typed
		deps = append(deps, typed)
	}

	if ws.source != nil {
		sourceDeps, err := attachWorkspaceSource(attach, ws.source)
		if err != nil {
			return nil, err
		}
		deps = append(deps, sourceDeps...)
	}

	if ws.mounts.Self() != nil {
		attached, err := attach(ws.mounts)
		if err != nil {
			return nil, fmt.Errorf("attach workspace mounts: %w", err)
		}
		typed, ok := attached.(dagql.ObjectResult[*Directory])
		if !ok {
			return nil, fmt.Errorf("attach workspace mounts: unexpected result %T", attached)
		}
		ws.mounts = typed
		deps = append(deps, typed)
	}

	return deps, nil
}

func attachWorkspaceSource(
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
	src WorkspaceSource,
) ([]dagql.AnyResult, error) {
	switch src := src.(type) {
	case nil, *WorkspaceSourceClientLocal, *WorkspaceSourceRootlessLocal:
		return nil, nil
	case *WorkspaceSourceDirectory:
		if src.Root.Self() == nil {
			return nil, nil
		}
		attached, err := attach(src.Root)
		if err != nil {
			return nil, fmt.Errorf("attach workspace directory source: %w", err)
		}
		root, ok := attached.(dagql.ObjectResult[*Directory])
		if !ok {
			return nil, fmt.Errorf("attach workspace directory source: unexpected result %T", attached)
		}
		src.Root = root
		return []dagql.AnyResult{root}, nil
	case *WorkspaceSourceGitRef:
		if src.Ref.Self() == nil {
			return nil, nil
		}
		attached, err := attach(src.Ref)
		if err != nil {
			return nil, fmt.Errorf("attach workspace git ref source: %w", err)
		}
		switch ref := attached.(type) {
		case dagql.Result[*GitRef]:
			src.Ref = ref
			return []dagql.AnyResult{ref}, nil
		case dagql.ObjectResult[*GitRef]:
			src.Ref = ref.Result
			return []dagql.AnyResult{ref}, nil
		default:
			return nil, fmt.Errorf("attach workspace git ref source: unexpected result %T", attached)
		}
	case *WorkspaceSourceOverlay:
		var deps []dagql.AnyResult
		baseDeps, err := attachWorkspaceSource(attach, src.Base)
		if err != nil {
			return nil, err
		}
		deps = append(deps, baseDeps...)
		if src.Changes.Self() != nil {
			attached, err := attach(src.Changes)
			if err != nil {
				return nil, fmt.Errorf("attach workspace overlay changes: %w", err)
			}
			changes, ok := attached.(dagql.ObjectResult[*Changeset])
			if !ok {
				return nil, fmt.Errorf("attach workspace overlay changes: unexpected result %T", attached)
			}
			src.Changes = changes
			deps = append(deps, changes)
		}
		return deps, nil
	default:
		return nil, fmt.Errorf("attach workspace source: unsupported source %T", src)
	}
}

func (ws *Workspace) Clone() *Workspace {
	cp := *ws
	cp.mountPoints = slices.Clone(ws.mountPoints)
	return &cp
}

// WorkspaceRelationKind classifies how two workspaces relate, so a caller
// swapping one for the other can decide what "what changed" should mean: a
// file diff only describes anything when the two share a base.
type WorkspaceRelationKind int

const (
	// WorkspaceRelationUnrelated: nothing ties the two workspaces together
	// (different repositories, or a synthetic directory on either side).
	WorkspaceRelationUnrelated WorkspaceRelationKind = iota
	// WorkspaceRelationSameOrigin: different bases that come from the same
	// git remote — a branch switch, a checkout of an older commit, a local
	// clone replaced by a remote ref of the same repository.
	WorkspaceRelationSameOrigin
	// WorkspaceRelationSameBase: the same underlying source, differing at
	// most in overlay edits (and cwd or mounts).
	WorkspaceRelationSameBase
)

func (k WorkspaceRelationKind) String() string {
	switch k {
	case WorkspaceRelationSameBase:
		return "same-base"
	case WorkspaceRelationSameOrigin:
		return "same-origin"
	default:
		return "unrelated"
	}
}

// WorkspaceRelation classifies next relative to prev. Overlays are stripped
// to their base on both sides: a workspace plus its own edits is SameBase
// with itself. Bases compare by what identifies them — host path (and client)
// for local checkouts, root content for directories, repository and commit
// for git refs. Anything short of that falls through to origin matching, and
// an unknown origin (see WorkspaceOrigin) matches nothing.
func WorkspaceRelation(ctx context.Context, prev, next *Workspace) WorkspaceRelationKind {
	if prev == nil || next == nil {
		return WorkspaceRelationUnrelated
	}
	if sameWorkspaceBase(ctx, prev, next) {
		return WorkspaceRelationSameBase
	}
	if origin := WorkspaceOrigin(prev); origin != "" && origin == WorkspaceOrigin(next) {
		return WorkspaceRelationSameOrigin
	}
	return WorkspaceRelationUnrelated
}

func sameWorkspaceBase(ctx context.Context, prev, next *Workspace) bool {
	switch a := prev.BaseSource().(type) {
	case *WorkspaceSourceClientLocal:
		b, ok := next.BaseSource().(*WorkspaceSourceClientLocal)
		return ok && sameLocalWorkspaceBase(prev, next, a.HostPath, b.HostPath)
	case *WorkspaceSourceRootlessLocal:
		b, ok := next.BaseSource().(*WorkspaceSourceRootlessLocal)
		return ok && sameLocalWorkspaceBase(prev, next, a.HostPath, b.HostPath)
	case *WorkspaceSourceDirectory:
		b, ok := next.BaseSource().(*WorkspaceSourceDirectory)
		return ok && sameDirectoryResult(ctx, a.Root, b.Root)
	case *WorkspaceSourceGitRef:
		b, ok := next.BaseSource().(*WorkspaceSourceGitRef)
		return ok && sameGitRefBase(a.Ref.Self(), b.Ref.Self())
	default:
		return false
	}
}

// sameLocalWorkspaceBase compares two host-backed bases. The client matters as
// much as the path: the same path on two clients is two different trees.
func sameLocalWorkspaceBase(prev, next *Workspace, prevPath, nextPath string) bool {
	if prevPath == "" {
		prevPath = prev.HostPath()
	}
	if nextPath == "" {
		nextPath = next.HostPath()
	}
	return prevPath != "" && prevPath == nextPath && prev.ClientID == next.ClientID
}

// sameDirectoryResult reports whether two directory results denote the same
// tree: by content when the cache can tell, else by result handle, else (for
// detached results) by value identity.
func sameDirectoryResult(ctx context.Context, a, b dagql.ObjectResult[*Directory]) bool {
	if a.Self() == nil || b.Self() == nil {
		return false
	}
	if aDig, err := a.ContentPreferredDigest(ctx); err == nil {
		if bDig, err := b.ContentPreferredDigest(ctx); err == nil {
			return aDig == bDig
		}
	}
	if aID, err := a.ID(); err == nil {
		if bID, err := b.ID(); err == nil {
			return stableIDDigest(aID) == stableIDDigest(bID)
		}
	}
	return a.Self() == b.Self()
}

// sameGitRefBase reports whether two git refs denote the same commit of the
// same repository. Repository URLs compare in normalized form so spellings of
// one remote match; a remote that does not normalize (a local path) compares
// verbatim rather than colliding with every other such remote.
func sameGitRefBase(a, b *GitRef) bool {
	if a == nil || b == nil || a.Ref == nil || b.Ref == nil {
		return false
	}
	if a.Ref.SHA == "" || a.Ref.SHA != b.Ref.SHA {
		return false
	}
	aURL, bURL := gitRefRepoURL(a), gitRefRepoURL(b)
	if aNorm, bNorm := workspacepkg.NormalizeGitRemote(aURL), workspacepkg.NormalizeGitRemote(bURL); aNorm != "" || bNorm != "" {
		return aNorm == bNorm
	}
	return aURL == bURL
}

func gitRefRepoURL(ref *GitRef) string {
	if ref == nil || ref.Repo.Self() == nil || !ref.Repo.Self().URL.Valid {
		return ""
	}
	return ref.Repo.Self().URL.Value.String()
}

// WorkspaceOrigin returns the normalized git remote a workspace comes from
// (the same key user-level config is matched on), or "" when unknown: a
// synthetic directory, a checkout without a usable origin, or a client that
// resolved no user-config key. Unknown origins are never treated as equal.
func WorkspaceOrigin(ws *Workspace) string {
	if ws == nil {
		return ""
	}
	if ref, ok := ws.SourceGitRef(); ok {
		return workspacepkg.NormalizeGitRemote(gitRefRepoURL(ref.Self()))
	}
	return ws.UserConfigKey()
}

// WorkspaceIdentity describes where a workspace comes from in terms a reader
// can act on, for notices about a workspace being swapped out.
type WorkspaceIdentity struct {
	// Address is the workspace's canonical address: file:// for local
	// checkouts, a git address for remote ones, or an opaque digest-based
	// identity for synthetic workspaces.
	Address string
	// Origin is the normalized git remote (see WorkspaceOrigin), or "".
	Origin string
	// Repo is the raw repository URL when the workspace is a git ref, kept
	// for remotes that have no normalized form (local paths).
	Repo string
	// SHA is the commit the workspace was built from, when known.
	SHA string
	// Ref is the short branch or tag name the commit was resolved from, when
	// it was not requested by bare SHA.
	Ref string
}

// DescribeWorkspace returns the identity of a workspace from what the
// workspace value itself carries; it makes no calls. Local checkouts get no
// SHA here — see WorkspaceIdentity.WithGitRef for filling one in from
// Workspace.git.head.
func DescribeWorkspace(ws *Workspace) WorkspaceIdentity {
	if ws == nil {
		return WorkspaceIdentity{}
	}
	id := WorkspaceIdentity{
		Address: ws.Address,
		Origin:  WorkspaceOrigin(ws),
	}
	if ref, ok := ws.SourceGitRef(); ok {
		id = id.WithGitRef(ref.Self())
	}
	return id
}

// WithGitRef fills in the repository, commit and ref name from a git ref,
// e.g. the checkout's HEAD for a local workspace.
func (id WorkspaceIdentity) WithGitRef(ref *GitRef) WorkspaceIdentity {
	if ref == nil {
		return id
	}
	if url := gitRefRepoURL(ref); url != "" {
		id.Repo = url
		if id.Origin == "" {
			id.Origin = workspacepkg.NormalizeGitRemote(url)
		}
	}
	if ref.Ref != nil {
		id.SHA = ref.Ref.SHA
		id.Ref = ""
		if ref.Ref.Name != "" && !gitutil.IsCommitSHA(ref.Ref.Name) {
			id.Ref = ref.Ref.ShortName()
		}
	}
	return id
}

// Location names the repository or place the workspace comes from, without
// its revision: the origin when known, else the raw repository URL, else the
// address.
func (id WorkspaceIdentity) Location() string {
	switch {
	case id.Origin != "":
		return id.Origin
	case id.Repo != "":
		return id.Repo
	case id.Address != "":
		return id.Address
	default:
		return "(unknown)"
	}
}

// Revision renders the commit and ref name, e.g. "@abc123 (main)", or "" when
// no commit is known.
func (id WorkspaceIdentity) Revision() string {
	if id.SHA == "" {
		return ""
	}
	if id.Ref != "" {
		return fmt.Sprintf("@%s (%s)", id.SHA, id.Ref)
	}
	return "@" + id.SHA
}

// String renders the full identity: the location, the revision when known,
// and the address when it adds information (a local path alongside its
// origin).
func (id WorkspaceIdentity) String() string {
	out := id.Location()
	if rev := id.Revision(); rev != "" {
		out += " " + rev
	}
	if id.Address != "" && id.Address != id.Location() {
		out += " [" + id.Address + "]"
	}
	return out
}

// WorkspaceGit represents the git state associated with a workspace.
type WorkspaceGit struct {
	Workspace dagql.ObjectResult[*Workspace]
}

var _ dagql.HasDependencyResults = (*WorkspaceGit)(nil)

func (*WorkspaceGit) Type() *ast.Type {
	return &ast.Type{
		NamedType: "WorkspaceGit",
		NonNull:   true,
	}
}

func (*WorkspaceGit) TypeDescription() string {
	return "Local git state for a workspace."
}

func (wg *WorkspaceGit) AttachDependencyResults(
	ctx context.Context,
	_ dagql.AnyResult,
	attach func(dagql.AnyResult) (dagql.AnyResult, error),
) ([]dagql.AnyResult, error) {
	if wg == nil || wg.Workspace.Self() == nil {
		return nil, nil
	}
	attached, err := attach(wg.Workspace)
	if err != nil {
		return nil, fmt.Errorf("attach workspace git workspace: %w", err)
	}
	typed, ok := attached.(dagql.ObjectResult[*Workspace])
	if !ok {
		return nil, fmt.Errorf("attach workspace git workspace: unexpected result %T", attached)
	}
	wg.Workspace = typed
	return []dagql.AnyResult{typed}, nil
}

var (
	_ dagql.PersistedObject        = (*WorkspaceGit)(nil)
	_ dagql.PersistedObjectDecoder = (*WorkspaceGit)(nil)
)

// persistedWorkspaceGitPayload is the on-disk encoding of a WorkspaceGit. Its
// only state is a reference to the Workspace it wraps, which is itself
// persistable, so persistence reduces to encoding that one ref.
type persistedWorkspaceGitPayload struct {
	WorkspaceResultID uint64 `json:"workspaceResultID,omitempty"`
}

func (wg *WorkspaceGit) EncodePersistedObject(ctx context.Context, enc *dagql.PersistEncodeContext) (dagql.PersistedObjectEncoding, error) {
	_ = ctx
	if wg == nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("encode persisted workspace git: nil workspace git")
	}
	var payload persistedWorkspaceGitPayload
	if wg.Workspace.Self() != nil {
		wsID, err := encodePersistedObjectRef(enc, wg.Workspace, "workspace git workspace")
		if err != nil {
			return dagql.PersistedObjectEncoding{}, err
		}
		payload.WorkspaceResultID = wsID
	}
	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		return dagql.PersistedObjectEncoding{}, fmt.Errorf("marshal persisted workspace git payload: %w", err)
	}
	return encodePersistedObjectRawJSON(payloadBytes), nil
}

func (*WorkspaceGit) DecodePersistedObject(ctx context.Context, dec *dagql.PersistDecodeContext, payload json.RawMessage) (dagql.Typed, error) {
	var persisted persistedWorkspaceGitPayload
	if err := json.Unmarshal(payload, &persisted); err != nil {
		return nil, fmt.Errorf("decode persisted workspace git payload: %w", err)
	}
	wg := &WorkspaceGit{}
	if persisted.WorkspaceResultID != 0 {
		ws, err := loadPersistedObjectResultByResultID[*Workspace](ctx, dec, persisted.WorkspaceResultID, "workspace git workspace")
		if err != nil {
			return nil, err
		}
		wg.Workspace = ws
	}
	return wg, nil
}
