from pathlib import Path
import ast,json
b=Path('/tmp/rust-cache-sipsma-review');p=b/'read-config-before-stat-engine';p.mkdir(exist_ok=False);parent=b/'lazy-spill-buffers-engine'
original=(b/'config-preflight-phases/module_git_clients.go').read_text();standalone=Path('/tmp/dagger-read-config-before-stat/core/module_git_clients.go').read_text();factory=standalone[standalone.index('type hostTreeReaderClient'):]
factory=factory.replace('''		data, readErr := client.ReadCallerHostFile(ctx, abs)''','''		readCtx, readPhase := wcprof.BeginOp(ctx, wcprof.OpKindInternal, "core.config.read", wcprof.OpOpts{Ident: abs})
		data, readErr := client.ReadCallerHostFile(readCtx, abs)
		readPhase.EndErr(readErr)''',1)
factory=factory.replace('''		stat, err := client.StatCallerHostPath(ctx, abs, false)''','''		statCtx, statPhase := wcprof.BeginOp(ctx, wcprof.OpKindInternal, "core.config.stat", wcprof.OpOpts{Ident: abs})
		stat, err := client.StatCallerHostPath(statCtx, abs, false)
		statPhase.EndErr(err)''',1)
needle='\t\tabs := filepath.Join(root, filepath.FromSlash(rel))\n';assert factory.count(needle)==1
control='''		if !readConfigBeforeStatEnabled.Load() {
			statCtx, statPhase := wcprof.BeginOp(ctx, wcprof.OpKindInternal, "core.config.stat", wcprof.OpOpts{Ident: abs})
			stat, err := client.StatCallerHostPath(statCtx, abs, false)
			statPhase.EndErr(err)
			if status.Code(err) == codes.NotFound { return nil, false, nil }
			if err != nil || stat.IsDir() { return nil, false, err }
			readCtx, readPhase := wcprof.BeginOp(ctx, wcprof.OpKindInternal, "core.config.read", wcprof.OpOpts{Ident: abs})
			data, err := client.ReadCallerHostFile(readCtx, abs)
			readPhase.EndErr(err)
			if err != nil { return nil, false, err }
			return data, true, nil
		}
'''
factory=factory.replace(needle,needle+control,1)
start=original.index('\treturn func(rel string) ([]byte, bool, error) {',original.index('func hostFileReader('));text=original[:start]+'\treturn hostTreeFileReader(hostCtx, root, bk), nil\n}\n\n'+factory;text=text.replace('"github.com/dagger/dagger/engine/wcprof"','"github.com/dagger/dagger/engine/wcprof"\n fstypes "github.com/dagger/dagger/internal/fsutil/types"');(p/'module_git_clients.go').write_text(text)
(p/'mode.go').write_text('''package core
import("encoding/json";"net/http";"os";"strconv";"sync/atomic")
var readConfigBeforeStatEnabled atomic.Bool
func init(){readConfigBeforeStatEnabled.Store(os.Getenv("DAGGER_TEST_READ_CONFIG_BEFORE_STAT")=="true")}
func ReadConfigBeforeStatDiagnostic(w http.ResponseWriter,r *http.Request){
 if r.Method==http.MethodPost {v,e:=strconv.ParseBool(r.URL.Query().Get("enabled"));if e!=nil{http.Error(w,e.Error(),400);return};readConfigBeforeStatEnabled.Store(v)} else if r.Method!=http.MethodGet {http.Error(w,"GET or POST required",405);return}
 w.Header().Set("Content-Type","application/json");_ = json.NewEncoder(w).Encode(map[string]any{"enabled":readConfigBeforeStatEnabled.Load()})
}
''')
s=(parent/'engine-debug.go').read_text();needle='\tm.HandleFunc("/debug/lazy-spill-buffers", clientdb.LazySpillBuffersDiagnostic)';assert needle in s;s=s.replace(needle,needle+'\n\tm.HandleFunc("/debug/read-config-before-stat", core.ReadConfigBeforeStatDiagnostic)');(p/'engine-debug.go').write_text(s)
o=json.loads((parent/'overlay.json').read_text());key=next(k for k,v in o['Replace'].items() if k.endswith('/core/module_git_clients.go'));o['Replace'][key]=str(p/'module_git_clients.go');o['Replace'][key.replace('module_git_clients.go','read_config_before_stat_mode.go')]=str(p/'mode.go');o['Replace'][key.replace('module_git_clients.go','module_git_clients_host_test.go')]='/tmp/dagger-read-config-before-stat/core/module_git_clients_host_test.go';o['Replace'][next(k for k,v in o['Replace'].items() if k.endswith('/cmd/engine/debug.go'))]=str(p/'engine-debug.go');(p/'overlay.json').write_text(json.dumps(o,indent=2)+'\n')
plan=json.loads((parent/'engine-plan.json').read_text());plan.update(new_engine='dagger-collection-read-config-oct19',ports={'runner':16289,'debug':16117},scenario='Read module-host config before redundant stat. Live reads, missing/dir/error handling and all declaration guards remain; no data cache.');plan['flags']['read-config-before-stat']=False;(p/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(parent/'build-engine.py').read_text().replace('DAGGER_TEST_LAZY_SPILL_BUFFERS','DAGGER_TEST_READ_CONFIG_BEFORE_STAT').replace("'clientdb-race'","'core-race'").replace("'./engine/clientdb'","'./core'");s=s.replace("'-race','-count=1','./core'","'-race','-count=1','-run=^(TestHostTreeFileReader.*|TestModuleTreeReaderWithoutTree)$','./core'");(p/'build-engine.py').write_text(s)
s=(parent/'start-engine.py').read_text().replace(':16288',':16289').replace(':16116',':16117').replace('codex.task=lazy-spill-buffers','codex.task=read-config-before-stat').replace('go-directory-membership/final-state.json','telemetry-lazy-buffers/final-state.json');(p/'start-engine.py').write_text(s)
for name in ['measure-source-edits.py','measure-test-edits.py','measure.py','capture.py','capture-all.py','analyze.py','analyze-all.py','verify-module.py','verify-rust.py','rust-cache-query.py']:
 s=(parent/name).read_text().replace(':16288',':16289').replace(':16116',':16117').replace('dagger-collection-lazy-spill-oct19','dagger-collection-read-config-oct19')
 s=s.replace("'linear-map-merge','lazy-spill-buffers']","'linear-map-merge','lazy-spill-buffers','read-config-before-stat']")
 s=s.replace("mode('lazy-spill-buffers',arm=='combined')","mode('lazy-spill-buffers',False)\n            mode('read-config-before-stat',arm=='combined')").replace("mode('lazy-spill-buffers',options.arm=='candidate')","mode('lazy-spill-buffers',False)\n    mode('read-config-before-stat',options.arm=='candidate')")
 s=s.replace("get('lazy-spill-buffers?enabled='+str(arm=='candidate').lower(),b'')","get('lazy-spill-buffers?enabled=false',b'')\n  get('read-config-before-stat?enabled='+str(arm=='candidate').lower(),b'')")
 s=s.replace("'linear-map-merge','lazy-spill-buffers']).lower()","'linear-map-merge','lazy-spill-buffers','read-config-before-stat']).lower()")
 s=s.replace("lazy_spill_buffers=arm=='combined'","lazy_spill_buffers=False,read_config_before_stat=arm=='combined'").replace("lazy_spill_buffers=options.arm=='candidate'","lazy_spill_buffers=False,read_config_before_stat=options.arm=='candidate'")
 s=s.replace('Only empty spill recovery and first-write buffer allocation change; files, headers, telemetry records, flushing and cleanup remain.','Only redundant host config stat changes: read first, retain fallback stat for failed non-missing reads. Config parsing, current bytes, declaration guards, errors and cleanup remain.')
 s=s.replace("Path('/tmp/rust-cache-sipsma-review/lazy-spill-buffers-engine/engine-build.json')","Path('/tmp/rust-cache-sipsma-review/read-config-before-stat-engine/engine-build.json')").replace('lazy-spill-buffers-pipeline-oct19','read-config-before-stat-pipeline-oct19')
 (p/name).write_text(s)
(p/'run.py').write_bytes((parent/'run.py').read_bytes());(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-read-config-engine.py').read_bytes())
for f in p.glob('*.py'):ast.parse(f.read_text())
print(p)
