from pathlib import Path
from collections import defaultdict
import json
p=Path(__file__).parent;source=p.parent/'lazy-spill-buffers-engine/capture-root-candidate/wcprof-complete.ndjson';stats=defaultdict(lambda:dict(count=0,aggregate_seconds=0));events={}
with source.open() as f:
 h=json.loads(next(f));strings=h['strings']
 for line in f:
  e=json.loads(line)
  if e.get('e')!='op':continue
  events[e['id']]=e
  if strings[e.get('c',0)]=='core.config.stat':
   key=(strings[e.get('i',0)],e['o']);stats[key]['count']+=1;stats[key]['aggregate_seconds']+=(e['d']-e['s'])/1e9
rows=[dict(path=k[0],outcome=k[1],**v) for k,v in stats.items()];rows.sort(key=lambda r:r['count'],reverse=True)
parents=[]
for e in sorted((e for e in events.values() if strings[e.get('c',0)]=='core.config.stat'),key=lambda e:e['d']-e['s'],reverse=True)[:4]:
 chain=[]
 for _ in range(8):
  chain.append(dict(id=e['id'],kind=e['k'],name=strings[e.get('c',0)],ident=strings[e.get('i',0)],seconds=(e['d']-e['s'])/1e9))
  e=events.get(e.get('p'))
  if e is None:break
 parents.append(chain)
(p/'preflight-audit.json').write_text(json.dumps(dict(source=str(source),parent_archive='../telemetry-lazy-buffers/evidence.tar.gz',scope='Diagnostic parallel waiting; aggregate seconds are not command wall time or savings.',stats=rows,parent_chains=parents),indent=2)+'\n');print(rows[:2])
