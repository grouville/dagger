from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent;command=['/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go','build','-p=2','-buildvcs=false','-o',str(p/'dagger-static'),'./cmd/dagger'];env=dict(os.environ,CGO_ENABLED='0',GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');tick=time.monotonic()
with (p/'static-cli-build.log').open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-read-config-before-stat',env=env,stdout=out,stderr=subprocess.STDOUT)
record=dict(command=command,cwd='/tmp/dagger-read-config-before-stat',cgo_enabled=False,seconds=time.monotonic()-tick,exit_code=r.returncode,scope='Static clean-main CLI only for integration tests in Alpine. Timings retain CLI 97f7d82d.')
if not r.returncode:record['sha256']=hashlib.sha256((p/'dagger-static').read_bytes()).hexdigest()
(p/'static-cli-build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert r.returncode==0
