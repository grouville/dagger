from pathlib import Path
import json,os,subprocess,time,urllib.request
p=Path(__file__).parent;b=p.parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';debug='http://127.0.0.1:16117/debug/'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=15) as f:return json.load(f)
before=get('read-config-before-stat')['enabled'];rows=[]
env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',_EXPERIMENTAL_DAGGER_CLI_BIN=str(p/'dagger-static'),_EXPERIMENTAL_DAGGER_RUNNER_HOST='tcp://127.0.0.1:16289',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15',OTEL_EXPORTER_OTLP_ENDPOINT='http://'+(b/'otlp-null-address.txt').read_text().strip()+':43184',OTEL_EXPORTER_OTLP_PROTOCOL='http/protobuf',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='commit.gpgsign',GIT_CONFIG_VALUE_0='false')
env.pop('DAGGER_CLOUD_TOKEN',None)
try:
 for arm in ['before','candidate']:
  get('read-config-before-stat?enabled='+str(arm=='candidate').lower(),b'')
  command=[go,'test','-overlay='+str(p/'integration-fixture-overlay.json'),'-p=2','-parallel=1','-count=1','-timeout=15m','-run=^TestModuleLoading/TestServeModuleDeclaredGitClient$','-v','./core/integration'];tick=time.monotonic()
  with (p/(arm+'-declarations.log')).open('w') as out:r=subprocess.run(command,cwd='/tmp/dagger-read-config-before-stat',env=env,stdout=out,stderr=subprocess.STDOUT)
  row=dict(arm=arm,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'declarations-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  if r.returncode:print((p/(arm+'-declarations.log')).read_text()[-3000:],flush=True);raise SystemExit(r.returncode)
finally:
 get('read-config-before-stat?enabled='+str(before).lower(),b'')
 (p/'declarations-restoration.json').write_text(json.dumps(dict(mode=get('read-config-before-stat'),lifecycle=get('client-lifecycle')),indent=2)+'\n')
