from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
p=Path(__file__).parent;b=p.parent;root=p/'evidence-root';out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/read-config-before-stat')
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def ignore(directory,names):return [n for n in names if n in {'__pycache__','.git','dagger-engine','dagger-static','wcprof-complete.ndjson','evidence-root','archive-driver.log'} or n.endswith('.test')]
root.mkdir(exist_ok=False);out.mkdir(exist_ok=False);reconstruction=[]
for label,source in [('standalone-validation',b/'read-config-before-stat'),('engine',p)]:
 for complete in sorted(source.glob('capture-*/wcprof-complete.ndjson')):
  folder=complete.parent;events=[];chunks=sorted(folder.glob('chunk-*.ndjson.gz'));assert chunks
  for chunk in chunks:
   with gzip.open(chunk,'rb') as stream:header=json.loads(stream.readline());events.extend(stream.readlines())
   assert header['dropped_events']==0
  assert not header.get('open_ops');header['event_count']=len(events);rebuilt=(json.dumps(header)+'\n').encode()+b''.join(events);assert rebuilt==complete.read_bytes()
  reconstruction.append(dict(capture=label+'/'+folder.name,chunks=[f.name for f in chunks],events=len(events),sha256=sha(rebuilt),exact_bytes_verified=True))
 shutil.copytree(source,root/label,ignore=ignore)
assert len(reconstruction)==4,len(reconstruction);write(root/'wcprof-reconstruction.json',reconstruction)
parent=out.parent/'telemetry-lazy-buffers';metadata=json.loads((parent/'archive.json').read_text());assert sha((parent/'evidence.tar.gz').read_bytes())==metadata['sha256'];write(root/'source-parent.json',dict(path='../telemetry-lazy-buffers/evidence.tar.gz',**metadata))
original=json.loads((b/'lazy-spill-buffers-engine/evidence-root/build-source-manifest.json').read_text());old_overlay=json.loads((b/'lazy-spill-buffers-engine/overlay.json').read_text())['Replace'];new_overlay=json.loads((p/'overlay.json').read_text())['Replace'];dest=root/'engine-source-delta';dest.mkdir();changed=[];full=[]
for row in original:
 actual=Path(new_overlay.get(row['original'],row['actual']));data=actual.read_bytes();entry=dict(row,actual=str(actual),sha256=sha(data),bytes=len(data))
 if entry['sha256']!=row['sha256']:
  filename=f'{len(changed):04d}-'+actual.name;(dest/filename).write_bytes(data);entry.update(parent_sha256=row['sha256'],archived='engine-source-delta/'+filename);changed.append(entry)
 full.append(entry)
known={r['original'] for r in original}
for key,value in new_overlay.items():
 if key in known:continue
 actual=Path(value);old=Path(old_overlay.get(key,key))
 if old.exists() and actual.read_bytes()==old.read_bytes():continue
 data=actual.read_bytes();filename=f'{len(changed):04d}-'+actual.name;(dest/filename).write_bytes(data);changed.append(dict(original=key,actual=value,bytes=len(data),sha256=sha(data),archived='engine-source-delta/'+filename,additional_test_or_production_input=True))
assert len(changed)==4,len(changed);write(root/'engine-source-delta.json',changed);write(root/'build-source-manifest.json',full)
# Preserve the core package source used to compile the focused overlay race gate.
package=Path('/tmp/dagger-filesync-snapshot-seeds/core');sources={str(f):str(f) for f in package.glob('*.go')}
sources.update({key:value for key,value in new_overlay.items() if str(Path(key).parent)==str(package) and key.endswith('.go')})
unit=root/'core-test-source';unit.mkdir();unit_manifest=[]
for key,value in sorted(sources.items()):
 data=Path(value).read_bytes();name=Path(key).name;(unit/name).write_bytes(data);unit_manifest.append(dict(original=key,actual=value,path=name,bytes=len(data),sha256=sha(data)))
write(unit/'manifest.json',unit_manifest)
for name in ['engine.go.mod','engine.go.sum']:(unit/name).write_bytes((b/'log-flush-buffer'/name).read_bytes())
repo=Path('/tmp/dagger-read-config-before-stat');base='ff0b029a4d270a651b9a8c7286babc79089066e4';source=root/'standalone';source.mkdir();patch=subprocess.check_output(['git','diff','--binary',base,'HEAD'],cwd=repo);(source/'change.patch').write_bytes(patch)
for name in ['module_git_clients.go','module_git_clients_host_test.go']:(source/name).write_bytes((repo/'core'/name).read_bytes())
write(root/'source-identity.json',dict(repository='https://github.com/dagger/dagger',base=base,commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),patch_sha256=sha(patch),status=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)))
files=[f for f in sorted(root.rglob('*')) if f.is_file()];manifest=[dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files];mbytes=(json.dumps(manifest,indent=2)+'\n').encode();arc=out/'evidence.tar.gz'
with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(root)));info.mtime=0
  with f.open('rb') as stream:tar.addfile(info,stream)
 info=tarfile.TarInfo('manifest.json');info.size=len(mbytes);info.mtime=0;tar.addfile(info,io.BytesIO(mbytes))
with tarfile.open(arc,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
(out/'manifest.json').write_bytes(mbytes)
for name in ['source-parent.json','source-identity.json','engine-source-delta.json','build-source-manifest.json','wcprof-reconstruction.json']:(out/name).write_bytes((root/name).read_bytes())
(out/'engine-assessment.json').write_bytes((p/'assessment.json').read_bytes())
(out/'preflight-audit.json').write_bytes((p/'preflight-audit.json').read_bytes())
(out/'final-state.json').write_bytes((p/'final-state.json').read_bytes());(out/'change.patch').write_bytes(patch)
record=dict(bytes=arc.stat().st_size,sha256=sha(arc.read_bytes()),members=len(files)+1,all_member_hashes_verified=True,lossless_streams_reconstructed=len(reconstruction),binaries_excluded=True);write(out/'archive.json',record);print(json.dumps(record),flush=True)
