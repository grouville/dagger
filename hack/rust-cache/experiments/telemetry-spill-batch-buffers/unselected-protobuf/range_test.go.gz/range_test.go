// Copyright 2026 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package order

import (
	"fmt"
	"testing"

	"google.golang.org/protobuf/reflect/protoreflect"
)

type fieldRange []messageField

func (fields fieldRange) Range(visit VisitField) {
	for _, field := range fields {
		if !visit(field.fd, field.v) {
			return
		}
	}
}

func TestRangeFields(t *testing.T) {
	for _, size := range []int{0, 1, 2, 3, 32} {
		fields := make(fieldRange, size)
		for i := range fields {
			number := size - i
			fields[i] = messageField{fd: fieldDesc{number: protoreflect.FieldNumber(number)}, v: protoreflect.ValueOfInt64(int64(-number))}
		}
		for _, sorted := range []bool{false, true} {
			for _, stopEarly := range []bool{false, true} {
				t.Run(fmt.Sprintf("%d/sorted=%v/stop=%v", size, sorted, stopEarly), func(t *testing.T) {
					var less FieldOrder
					if sorted {
						less = NumberFieldOrder
					}
					count := 0
					RangeFields(fields, less, func(fd protoreflect.FieldDescriptor, value protoreflect.Value) bool {
						want := size - count
						if sorted {
							want = count + 1
						}
						if int(fd.Number()) != want || value.Int() != int64(-want) {
							t.Fatalf("field %d: got (%d, %d), want (%d, %d)", count, fd.Number(), value.Int(), want, -want)
						}
						count++
						return !stopEarly
					})
					want := size
					if stopEarly && want > 1 {
						want = 1
					}
					if count != want {
						t.Fatalf("visited %d fields, want %d", count, want)
					}
				})
			}
		}
	}
}

type entryRange []mapEntry

func (entries entryRange) Range(visit VisitEntry) {
	for _, entry := range entries {
		if !visit(entry.k, entry.v) {
			return
		}
	}
}

func TestRangeEntries(t *testing.T) {
	for _, kind := range []string{"bool", "int", "uint", "string"} {
		key := func(number int) protoreflect.MapKey {
			switch kind {
			case "bool":
				return protoreflect.ValueOfBool(number > 1).MapKey()
			case "int":
				return protoreflect.ValueOfInt64(int64(number)).MapKey()
			case "uint":
				return protoreflect.ValueOfUint64(uint64(number)).MapKey()
			default:
				return protoreflect.ValueOfString(fmt.Sprintf("%02d", number)).MapKey()
			}
		}
		for _, size := range []int{0, 1, 2, 3, 32} {
			if kind == "bool" && size > 2 {
				continue
			}
			entries := make(entryRange, size)
			for i := range entries {
				number := size - i
				entries[i] = mapEntry{k: key(number), v: protoreflect.ValueOfInt64(int64(-number))}
			}
			for _, sorted := range []bool{false, true} {
				for _, stopEarly := range []bool{false, true} {
					t.Run(fmt.Sprintf("%s/%d/sorted=%v/stop=%v", kind, size, sorted, stopEarly), func(t *testing.T) {
						var less KeyOrder
						if sorted {
							less = GenericKeyOrder
						}
						count := 0
						RangeEntries(entries, less, func(k protoreflect.MapKey, value protoreflect.Value) bool {
							want := size - count
							if sorted {
								want = count + 1
							}
							if k.Interface() != key(want).Interface() || value.Int() != int64(-want) {
								t.Fatalf("entry %d: got (%v, %d), want (%v, %d)", count, k.Interface(), value.Int(), key(want).Interface(), -want)
							}
							count++
							return !stopEarly
						})
						want := size
						if stopEarly && want > 1 {
							want = 1
						}
						if count != want {
							t.Fatalf("visited %d entries, want %d", count, want)
						}
					})
				}
			}
		}
	}
}
