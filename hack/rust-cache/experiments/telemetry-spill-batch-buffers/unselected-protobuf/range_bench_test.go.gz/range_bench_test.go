package order

import (
	"fmt"
	"testing"

	"google.golang.org/protobuf/reflect/protoreflect"
)

type benchmarkFieldRanger []messageField

func (fields benchmarkFieldRanger) Range(visit VisitField) {
	for _, field := range fields {
		if !visit(field.fd, field.v) {
			return
		}
	}
}

func BenchmarkRangeFields(b *testing.B) {
	for _, size := range []int{0, 1, 2, 8, 32, 128} {
		fields := make(benchmarkFieldRanger, size)
		for i := range fields {
			fields[i] = messageField{
				fd: fieldDesc{number: protoreflect.FieldNumber(size - i)},
				v:  protoreflect.ValueOfInt64(int64(i)),
			}
		}
		b.Run(fmt.Sprint(size), func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				RangeFields(fields, NumberFieldOrder, func(protoreflect.FieldDescriptor, protoreflect.Value) bool { return true })
			}
		})
	}
}
