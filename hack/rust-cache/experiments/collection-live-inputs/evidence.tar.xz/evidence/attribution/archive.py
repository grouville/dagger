from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
import time

p = Path(__file__).parent
sources = {'attribution': p, 'owner-index': p.parent / 'indexed-go-package-owners'}
destination = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/collection-live-inputs')
destination.mkdir(exist_ok=False)
for name in ['capture-allocations', 'capture-child-workspace', 'capture-child-no-workspace']:
    capture = p / name
    trace = capture / 'wcprof-complete.ndjson'
    identity = dict(bytes=trace.stat().st_size, sha256=hashlib.sha256(trace.read_bytes()).hexdigest())
    (capture / 'trace-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    subprocess.run(['python3', str(p / 'assemble-traces.py'), str(capture)], check=True)

members = []
def payload(row):
    data = (sources[row['group']] / row['source_path']).read_bytes()
    return gzip.decompress(data) if row['decoded_gzip'] else data

for group, directory in sources.items():
    for filename in sorted(directory.rglob('*')):
        if not filename.is_file() or '__pycache__' in filename.parts:
            continue
        if filename.name == 'wcprof-complete.ndjson':
            continue
        relative = filename.relative_to(directory)
        decoded = filename.name.startswith('chunk-') and filename.name.endswith('.ndjson.gz')
        name = str(relative)[:-3] if decoded else str(relative)
        row = dict(path=group + '/' + name, group=group, source_path=str(relative), decoded_gzip=decoded)
        data = payload(row)
        row.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        members.append(row)

archive = destination / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as output:
    for row in members:
        data = payload(row)
        info = tarfile.TarInfo('evidence/' + row['path'])
        info.size = len(data)
        info.mode = 0o644
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:*') as stored:
    assert len(stored.getmembers()) == len(members)
    for row in members:
        with stored.extractfile('evidence/' + row['path']) as stream:
            assert hashlib.sha256(stream.read()).hexdigest() == row['sha256']

manifest = dict(
    created_unix=time.time(), archive=archive.name,
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    archive_bytes=archive.stat().st_size, verified_members=len(members),
    uncompressed_member_bytes=sum(row['bytes'] for row in members),
    scope='Frozen-name unused-live-input diagnostic, real owner-index rejection, real CPU/allocation attribution. Every timing, source, setup error, focused check and lossless capture retained. No real-module speedup, engine replacement or new PR.',
    inherited_engine_context='../typed-artifact-metadata/',
    trace_storage='Original dump bytes stored as raw chunk-*.ndjson members inside the xz archive. Duplicate combined files and their outer gzip wrappers are omitted. assemble-traces.py recreates each exact combined trace and verifies byte count and SHA256.',
    members=members,
)
(destination / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
(destination / 'README.md').write_text('''# Live collection inputs

See [the assessment](../../NATIVE_GO_COLLECTION_INPUTS.md). A frozen-name diagnostic changes 11.92 → 1.07 seconds median when an unused child Workspace argument is removed. Lossless captures verify 800 child executions become 800 cache hits. This does not establish fresh-source discovery or a real Go-module improvement.

The archive includes both exact frozen sources, all ten full-command observations, separate lossless captures and execution counts. The real owner-index experiment is rejected after 17.61 → 19.05 seconds; its source patch, four focused passing checks, initial constructor error and all ten observations are retained. A prepared remaining-check driver was not run after rejection. CPU attribution and a separate allocation capture explain why neither an ownership scan nor schema cloning is established as the next major cost. The allocation profile covers fewer bytes than memstats; its percentages are not whole-command shares.

Lossless original dump records are stored as raw `chunk-*.ndjson` files inside this archive. After extraction run `python3 evidence/attribution/assemble-traces.py evidence/attribution/capture-child-no-workspace`, replacing the final directory with `capture-child-workspace` or `capture-allocations` as needed. The combined trace's exact size and SHA256 are checked. Duplicate combined trace files and gzip wrappers are omitted.

MANIFEST.json verifies every archived file. The unchanged engine and CLI sources are in the [typed metadata experiment](../typed-artifact-metadata/); the selected real module is the [batched discovery baseline](../go-batched-discovery-facts/). Original local paths and the telemetry receiver need adapting for replay. Binaries, credentials and the engine volume are excluded. No PR is open.
''')
print(json.dumps({k:manifest[k] for k in ['archive_bytes','verified_members','uncompressed_member_bytes','archive_sha256']}), flush=True)
