module parser-screen

go 1.26.0

require github.com/segmentio/encoding v0.5.4

require (
	github.com/segmentio/asm v1.1.3 // indirect
	golang.org/x/sys v0.0.0-20211110154304-99a53858aa08 // indirect
)
