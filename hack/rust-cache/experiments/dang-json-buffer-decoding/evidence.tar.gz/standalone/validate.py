from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;r=Path('/tmp/dagger-dang-json-buffer-decoding');go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');steps=[];bench=[]
def run(label,command,cwd):
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:result=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,cwd=str(cwd),seconds=time.monotonic()-tick,exit_code=result.returncode);steps.append(row);(p/'validation-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:print((p/(label+'.log')).read_text()[-3500:]);raise SystemExit(result.returncode)
 return (p/(label+'.log')).read_text()
for pair in range(4):
 for fast in ([False,True] if pair%2==0 else [True,False]):
  text=run(f'bench-{pair}-{fast}',[go,'test','-mod=mod','-run=^$','-bench=^BenchmarkDecodeCallJSON/paths[0-9]+/buffer'+str(fast).lower()+'$','-benchmem','-benchtime=100ms','-count=1','.'],p/'screen')
  for line in text.splitlines():
   m=re.match(r'BenchmarkDecodeCallJSON/paths(\d+)/buffer(?:true|false)-\d+\s+\d+\s+([0-9.]+) ns/op\s+[0-9.]+ MB/s\s+(\d+) B/op\s+(\d+) allocs/op',line)
   if m:bench.append(dict(pair=pair,buffer=fast,paths=int(m[1]),ns=float(m[2]),bytes=int(m[3]),allocs=int(m[4])))
  assert len([x for x in bench if x['pair']==pair and x['buffer']==fast])==3,text
(p/'component-pairs.json').write_text(json.dumps(bench,indent=2)+'\n');summary={}
for paths in [1,64,800]:
 summary[paths]={str(fast):{key:statistics.median(x[key] for x in bench if x['paths']==paths and x['buffer']==fast) for key in ['ns','bytes','allocs']} for fast in [False,True]}
(p/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
run('standalone-sdk-race',[go,'test','-p=2','-race','-count=1','./core/sdk/dang/v2'],r)
