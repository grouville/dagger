from pathlib import Path
import json
b=Path(__file__).parent.parent;p=b/'buffer-call-json-engine';old=b/'frozen-core-fields-engine';review=Path('/tmp/dagger-dang-json-buffer-decoding')
assert not p.exists();p.mkdir();overlay=json.loads((old/'overlay.json').read_text());replace=overlay['Replace'];base='/tmp/dagger-filesync-snapshot-seeds'
def add(original,name,text):
 dest=p/name;dest.write_text(text);replace[base+'/'+original]=str(dest)
helpers=(b/'dang-shared-receiver-decode/helpers.go').read_text()
a='\t\tdec := json.NewDecoder(bytes.NewReader(jsonValue))\n\t\tdec.UseNumber()\n\t\tvar val any\n\t\tif err := dec.Decode(&val); err != nil {'
z='\t\tvar val any\n\t\tif err := decodeCallJSON(jsonValue, &val); err != nil {'
assert helpers.count(a)==1;helpers=helpers.replace(a,z);assert helpers.count('bytes.')==0;helpers=helpers.replace('\t"bytes"\n','',1)
add('core/sdk/dang/v2/helpers.go','helpers.go',helpers)
shared=(b/'dang-shared-receiver-decode/shared_receiver_decode.go').read_text()
a='\t\tdecoder := json.NewDecoder(bytes.NewReader(data))\n\t\tdecoder.UseNumber()\n\t\terr := decoder.Decode(&fields)';z='\t\terr := decodeCallJSON(data, &fields)';assert shared.count(a)==1;shared=shared.replace(a,z).replace('\t"bytes"\n','',1)
add('core/sdk/dang/v2/shared_receiver_decode.go','shared_receiver_decode.go',shared)
source=(review/'core/sdk/dang/v2/call_json.go').read_text();assert source.count('func decodeCallJSON(')==1;source=source.replace('func decodeCallJSON(', 'func decodeCallJSONBuffered(',1)
add('core/sdk/dang/v2/call_json.go','call_json.go',source)
replace[base+'/core/sdk/dang/v2/call_json_test.go']=str(review/'core/sdk/dang/v2/call_json_test.go')
mode=Path(__file__).parent/'mode.go';add('core/sdk/dang/v2/buffer_call_json_mode.go','mode.go',mode.read_text())
debug=(old/'engine-debug.go').read_text();a='\tm.HandleFunc("/debug/shared-receiver-decode", dangv2.SharedReceiverDecodeDiagnostic)';assert debug.count(a)==1;debug=debug.replace(a,a+'\n\tm.HandleFunc("/debug/buffer-call-json", dangv2.BufferedCallJSONDiagnostic)')
add('cmd/engine/debug.go','engine-debug.go',debug)
(p/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
plan=json.loads((old/'engine-plan.json').read_text());plan.update(new_engine='dagger-collection-buffer-call-json-oct19',ports=dict(engine=16295,debug=16123),scenario='Parse existing SDK call JSON directly from bytes, preserving numbers, ownership, errors and the complete collection pipeline.',candidate_route='buffer-call-json',candidate_commit=None,cli_sha256='ca716780a17686774e2df72e69f10116e41b1f195426f9eaa6f6f5bc35a2efe2');plan['flags']['buffer-call-json']=False
(p/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=(old/'start-engine.py').read_text().replace('experiments/class-fork-cow/final-state.json','experiments/frozen-core-fields/final-state.json').replace('codex.task=frozen-core-fields','codex.task=buffer-call-json').replace(':16294',':16295').replace(':16122',':16123').replace('127.0.0.1:16294','127.0.0.1:16295').replace('127.0.0.1:16122','127.0.0.1:16123')
(p/'start-engine.py').write_text(start)
