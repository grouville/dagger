from pathlib import Path
import re
p=Path(__file__).parent.parent/'buffer-call-json-engine';old=p.parent/'frozen-core-fields-engine'
files=['measure-source-edits.py','measure-test-edits.py','verify-module.py','verify-rust.py','rust-cache-query.py','run-pipeline.py','capture.py','run-captures.py','analyze-captures.py','analyze-allocations.py','analyze-timings.py','finalize.py']
for name in files:
 s=(old/name).read_text().replace('frozen-core-fields-engine','buffer-call-json-engine').replace('dagger-collection-frozen-core-fields-oct19','dagger-collection-buffer-call-json-oct19').replace(':16122',':16123').replace(':16294',':16295')
 if name.startswith('measure-'):
  s=s.replace("'class-fork-cow','frozen-core-fields']","'class-fork-cow','frozen-core-fields','buffer-call-json']")
  s=s.replace("assert not get('frozen-core-fields')['record']","assert not get('frozen-core-fields')['record']\nassert not get('buffer-call-json')['record']")
  a="mode('frozen-core-fields',arm=='engine')";assert s.count(a)==1;s=s.replace(a,"mode('frozen-core-fields',True)\n            mode('buffer-call-json',arm=='engine')")
  s=s.replace("frozen_core_fields=arm=='engine'","frozen_core_fields=True,buffer_call_json=arm=='engine'")
  s,n=re.subn("scope='[^']*'", "scope='Two-arm SDK JSON decoding experiment. Same immutable core field definitions and private clients in both arms. Parse the same in-memory call JSON with the existing streaming decoder or the existing Segmentio parser. Exact numbers, fresh values, errors, validation, every getter, telemetry and full cleanup remain. Counters/profilers off; real edits, two initialization blocks and four alternating pairs.'",s);assert n==1
 elif name in ['verify-module.py','verify-rust.py']:
  s=s.replace("'class-fork-cow','frozen-core-fields']","'class-fork-cow','frozen-core-fields','buffer-call-json']")
  a="get('frozen-core-fields?enabled='+str(arm=='candidate').lower(),b'')";assert s.count(a)==1;s=s.replace(a,"get('frozen-core-fields?enabled=true',b'')\n  get('buffer-call-json?enabled='+str(arm=='candidate').lower(),b'')")
 elif name=='run-pipeline.py':
  s=s.replace('frozen-core-fields?record','buffer-call-json?record').replace("diagnostic('frozen-core-fields')","diagnostic('buffer-call-json')").replace('gate-field-snapshot-stats.json','gate-call-json-stats.json').replace("stats['reused_fields']>0 and stats['fresh_fields']>0","stats['buffered_calls']>0 and stats['streamed_calls']>0")
 elif name=='capture.py':
  s=s.replace("'class-fork-cow','frozen-core-fields']","'class-fork-cow','frozen-core-fields','buffer-call-json']")
  s=s.replace("frozen_record_before=get('frozen-core-fields')['record']","json_record_before=get('buffer-call-json')['record']\nassert not get('frozen-core-fields')['record']")
  s=s.replace("mode('frozen-core-fields',options.arm=='candidate')","mode('frozen-core-fields',True)\n    mode('buffer-call-json',options.arm=='candidate')")
  s=s.replace("get('frozen-core-fields?record=true&reset=true',b'')","get('buffer-call-json?record=true&reset=true',b'')")
  s=s.replace("frozen_core_fields=options.arm=='candidate'","frozen_core_fields=True,buffer_call_json=options.arm=='candidate'")
  s=s.replace("(root/'frozen-field-stats.json').write_text(json.dumps(get('frozen-core-fields')","(root/'call-json-stats.json').write_text(json.dumps(get('buffer-call-json')")
  s=s.replace("get('frozen-core-fields?record='+str(frozen_record_before).lower(),b'')","get('buffer-call-json?record='+str(json_record_before).lower(),b'')")
 elif name=='analyze-timings.py':
  s=s.replace("r['frozen_core_fields'] == (r['arm'] == 'engine')","r['frozen_core_fields'] and r['buffer_call_json'] == (r['arm'] == 'engine')")
 elif name=='finalize.py':
  s=s.replace('experiments/class-fork-cow/final-state.json','experiments/frozen-core-fields/final-state.json')
  s=s.replace("assert not get('frozen-core-fields')['record'];","assert not get('buffer-call-json')['record'];assert not get('frozen-core-fields')['record'];")
 (p/name).write_text(s)
 compile(s,str(p/name),'exec')
print('Prepared independent pipeline, timing, capture and preservation scripts.')
