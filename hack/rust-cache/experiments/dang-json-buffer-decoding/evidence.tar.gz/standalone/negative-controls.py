from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[]
for label,test in [('number','^TestDecodeCallJSONMatchesDecoder$'),('ownership','^TestDecodeCallJSONKeepsInputPrivate$')]:
 command=[go,'test','-overlay='+str(p/('negative-'+label+'-overlay.json')),'-count=1','-run='+test,'.'];tick=time.monotonic()
 with (p/('negative-'+label+'.log')).open('w') as out:result=subprocess.run(command,cwd=p/'screen',env=env,stdout=out,stderr=subprocess.STDOUT)
 output=(p/('negative-'+label+'.log')).read_text();assert result.returncode==1 and '--- FAIL: TestDecodeCallJSON' in output,(label,result.returncode,output)
 rows.append(dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=result.returncode,expected=1));(p/'negative-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
