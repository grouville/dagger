package dangv2

import (
	"context"
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync"
	"sync/atomic"

	lru "github.com/hashicorp/golang-lru/v2"
)

// This screen shares JSON data only. Every call still converts fresh Dang
// values, evaluates class initializers, binds methods and invokes the getter.
// Neither a client, a context nor a converted object is retained here.
var sharedReceiverDecodeEnabled atomic.Bool
var receiverDecodeHits, receiverDecodeMisses atomic.Uint64

func init() {
	sharedReceiverDecodeEnabled.Store(os.Getenv("DAGGER_BENCH_SHARED_RECEIVER_DECODE") == "true")
}

type decodedReceiver struct {
	mu     sync.Mutex
	fields map[string]any
	ready  bool
}

var decodedReceivers, _ = lru.New[string, *decodedReceiver](32)

func decodeDangParent(ctx context.Context, data []byte) (map[string]any, error) {
	decode := func() (map[string]any, error) {
		var fields map[string]any
		err := decodeCallJSON(data, &fields)
		return fields, err
	}
	if !sharedReceiverDecodeEnabled.Load() || len(data) > 256*1024 {
		return decode()
	}
	key := string(data)
	entry, exists := decodedReceivers.Get(key)
	if !exists {
		entry = &decodedReceiver{}
		previous, exists, _ := decodedReceivers.PeekOrAdd(key, entry)
		if exists {
			entry = previous
		}
	}
	entry.mu.Lock()
	defer entry.mu.Unlock()
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if !entry.ready {
		receiverDecodeMisses.Add(1)
		fields, err := decode()
		if err != nil {
			return nil, err
		}
		entry.fields, entry.ready = fields, true
	} else {
		receiverDecodeHits.Add(1)
	}
	// The converter reads these maps and slices, constructing new values rather
	// than exposing the decoded containers to evaluated module code.
	return entry.fields, nil
}

func SharedReceiverDecodeDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		sharedReceiverDecodeEnabled.Store(enabled)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"enabled": sharedReceiverDecodeEnabled.Load(), "entries": decodedReceivers.Len(),
		"hits": receiverDecodeHits.Load(), "misses": receiverDecodeMisses.Load(),
	})
}
