package dangv2

import (
	"bytes"
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var bufferedCallJSON atomic.Bool
var recordCallJSON atomic.Bool
var bufferedCallJSONCalls, streamedCallJSONCalls, callJSONInputBytes atomic.Uint64

func init() {
	bufferedCallJSON.Store(os.Getenv("DAGGER_TEST_BUFFER_CALL_JSON") == "true")
}

func decodeCallJSON(data []byte, dest any) error {
	buffered := bufferedCallJSON.Load()
	if recordCallJSON.Load() {
		callJSONInputBytes.Add(uint64(len(data)))
		if buffered {
			bufferedCallJSONCalls.Add(1)
		} else {
			streamedCallJSONCalls.Add(1)
		}
	}
	if buffered {
		return decodeCallJSONBuffered(data, dest)
	}
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.UseNumber()
	return decoder.Decode(dest)
}

func BufferedCallJSONDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		for key, value := range map[string]*atomic.Bool{"enabled": &bufferedCallJSON, "record": &recordCallJSON} {
			if raw := r.URL.Query().Get(key); raw != "" {
				parsed, err := strconv.ParseBool(raw)
				if err != nil {
					http.Error(w, err.Error(), http.StatusBadRequest)
					return
				}
				value.Store(parsed)
			}
		}
		if r.URL.Query().Get("reset") == "true" {
			bufferedCallJSONCalls.Store(0)
			streamedCallJSONCalls.Store(0)
			callJSONInputBytes.Store(0)
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"enabled": bufferedCallJSON.Load(), "record": recordCallJSON.Load(),
		"buffered_calls": bufferedCallJSONCalls.Load(), "streamed_calls": streamedCallJSONCalls.Load(), "input_bytes": callJSONInputBytes.Load(),
	})
}
