from pathlib import Path
import json,re,subprocess
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';rows=[]
for step in json.loads((p/'capture-steps.json').read_text()):
 d=p/step['label'];command=[go,'tool','pprof','-sample_index=alloc_space','-top','-cum','-nodecount=0','-nodefraction=0','-base='+str(d/'allocs-before.pprof'),str(p/'dagger-engine'),str(d/'allocs-after.pprof')]
 text=subprocess.check_output(command,text=True);(d/'engine-allocation-cumulative.txt').write_text(text);metrics={}
 for line in text.splitlines():
  fields=line.split()
  if len(fields)>5:
   for key,func in [('call_json','github.com/dagger/dagger/core/sdk/dang/v2.decodeCallJSON'),('buffered_json','github.com/dagger/dagger/core/sdk/dang/v2.decodeCallJSONBuffered'),('parent','github.com/dagger/dagger/core/sdk/dang/v2.decodeDangParent'),('read_buffer','encoding/json.(*Decoder).refill'),('fork','github.com/dagger/dagger/dagql.Class[go.shape.*uint8].ForkObjectType'),('maps','maps.clone'),('schema','github.com/dagger/dagger/dagql.(*Server).SchemaForView')]:
    if fields[5]==func:metrics[key]=fields[3]
 r=json.loads((d/'result.json').read_text());rows.append(dict(label=step['label'],arm=step['arm'],sampled_allocation=metrics,total_alloc=r['heap_delta']['TotalAlloc'],sampling_caveat='Allocation samples can lag GC cycles and carry preceding-mode work; exact per-command TotalAlloc counters are authoritative.'))
(p/'allocation-attribution.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows),flush=True)
