from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

p = Path(__file__).parent
unit = p.parent / 'dang-json-buffer-decoding'
root = p / 'evidence-root-final'
out = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/dang-json-buffer-decoding')
parent = out.parent / 'frozen-core-fields'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def ignore(directory, names):
    return [n for n in names if n in {'__pycache__', '.git', 'wcprof-complete.ndjson', 'dagger', 'dagger-engine', 'archive.log'} or n.endswith('.test') or n.startswith('evidence-root')]

assert not root.exists() and not (out / 'evidence.tar.gz').exists()
root.mkdir()
out.mkdir(exist_ok=True)
streams = []
for complete in sorted(p.glob('capture-*/wcprof-complete.ndjson')):
    events = []
    chunks = sorted(complete.parent.glob('chunk-*.ndjson.gz'))
    assert chunks
    for chunk in chunks:
        with gzip.open(chunk, 'rb') as f:
            header = json.loads(f.readline())
            events.extend(f.readlines())
        assert header['dropped_events'] == 0
    assert not header.get('open_ops')
    header['event_count'] = len(events)
    raw = (json.dumps(header) + '\n').encode() + b''.join(events)
    assert raw == complete.read_bytes()
    streams.append(dict(capture=complete.parent.name, chunks=[x.name for x in chunks], events=len(events), sha256=sha(raw), exact_bytes_verified=True))
assert len(streams) == 4
shutil.copytree(p, root / 'engine', ignore=ignore)
shutil.copytree(unit, root / 'standalone', ignore=ignore)
write(root / 'wcprof-reconstruction.json', streams)
meta = json.loads((parent / 'archive.json').read_text())
assert sha((parent / 'evidence.tar.gz').read_bytes()) == meta['sha256']
write(root / 'source-parents.json', [dict(kind='engine-and-common-cli', path='../frozen-core-fields/evidence.tar.gz', **meta)])

old_rows = {r['original']: r for r in json.loads((parent / 'build-source-manifest.json').read_text())}
with tarfile.open(parent / 'evidence.tar.gz', 'r:gz') as tar:
    for row in json.loads((parent / 'engine-source-delta.json').read_text()):
        old_rows[row['original']] = row
    old_overlay = json.loads((p.parent / 'frozen-core-fields-engine/overlay.json').read_text())['Replace']
    supplement = root / 'common-source-supplement'
    supplement.mkdir()
    common = []
    # Older manifests omitted some additional overlay files. Archive those
    # common bytes explicitly rather than mislabeling them as changed inputs.
    for key, value in sorted(old_overlay.items()):
        if key in old_rows:
            continue
        actual = Path(value)
        data = actual.read_bytes()
        name = f'{len(common):04d}-' + actual.name
        (supplement / name).write_bytes(data)
        row = dict(original=key, actual=value, sha256=sha(data), bytes=len(data), archived='common-source-supplement/' + name,
                   basis='Unchanged parent overlay input absent from the inherited manifest; bytes explicitly retained here.')
        common.append(row)
        old_rows[key] = row
    write(root / 'common-source-supplement.json', common)
    new = json.loads((p / 'overlay.json').read_text())['Replace']
    dest = root / 'engine-source-delta'
    dest.mkdir()
    changed, full = [], []
    for key in sorted(set(old_rows) | set(new)):
        prior = old_rows.get(key)
        actual = Path(new.get(key, prior['actual'] if prior else key))
        data = actual.read_bytes()
        entry = dict(original=key, actual=str(actual), sha256=sha(data), bytes=len(data))
        if prior is None or entry['sha256'] != prior['sha256']:
            name = f'{len(changed):04d}-' + actual.name
            (dest / name).write_bytes(data)
            entry.update(parent_sha256=prior['sha256'] if prior else None, archived='engine-source-delta/' + name)
            changed.append(entry)
        full.append(entry)
assert len(changed) == 6, [r['original'] for r in changed]
write(root / 'engine-source-delta.json', changed)
write(root / 'build-source-manifest.json', full)
source = root / 'review-source'
source.mkdir()
identity = json.loads((unit / 'source-identity.json').read_text())
for row in identity['production_and_test_files']:
    data = (Path('/tmp/dagger-dang-json-buffer-decoding') / row['path']).read_bytes()
    assert sha(data) == row['sha256']
    path = source / row['path']
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

files = [f for f in sorted(root.rglob('*')) if f.is_file()]
manifest = [dict(path=str(f.relative_to(root)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())) for f in files]
mbytes = (json.dumps(manifest, indent=2) + '\n').encode()
arc = out / 'evidence.tar.gz'
with arc.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
    for f in files:
        info = tar.gettarinfo(str(f), arcname=str(f.relative_to(root)))
        info.mtime = 0
        with f.open('rb') as stream:
            tar.addfile(info, stream)
    info = tarfile.TarInfo('manifest.json')
    info.size, info.mtime = len(mbytes), 0
    tar.addfile(info, io.BytesIO(mbytes))
with tarfile.open(arc, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(files) + 1
    for row in manifest:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
(out / 'manifest.json').write_bytes(mbytes)
for name in ['wcprof-reconstruction.json', 'source-parents.json', 'engine-source-delta.json', 'build-source-manifest.json', 'common-source-supplement.json']:
    (out / name).write_bytes((root / name).read_bytes())
for name in ['timing-analysis.json', 'allocation-attribution.json', 'attribution.json', 'final-state.json', 'gate-call-json-stats.json']:
    (out / name).write_bytes((p / name).read_bytes())
for name in ['source-identity.json', 'change.patch', 'component-summary.json']:
    (out / name).write_bytes((unit / name).read_bytes())
record = dict(bytes=arc.stat().st_size, sha256=sha(arc.read_bytes()), members=len(files)+1, all_member_hashes_verified=True, lossless_streams_reconstructed=len(streams), binaries_excluded=True)
write(out / 'archive.json', record)
print(json.dumps(record), flush=True)
