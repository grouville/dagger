package clientdb

func init() {
 attributeArrayDecodeEnabled.Store(true)
 batchMetadataFast.Store(true)
}
