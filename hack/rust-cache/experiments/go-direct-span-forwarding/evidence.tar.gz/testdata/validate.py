from pathlib import Path
import json,os,subprocess,time
root=Path(__file__).parent;base=root.parent
common=['/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go','test','-p','2','-buildvcs=false','-modfile',str(base/'otel-evicted-queue/engine.go.mod')]
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
steps=[('clientdb-default-race',common+['-overlay',str(root/'unit-default-overlay.json'),'-race','-count=1','./engine/clientdb'],'/tmp/dagger-filesync-snapshot-seeds'),('clientdb-selected-race',common+['-overlay',str(root/'unit-selected-overlay.json'),'-race','-count=1','./engine/clientdb'],'/tmp/dagger-filesync-snapshot-seeds'),('strict-control-retained',['python3',str(root/'verify_retained_mode.py'),'go-direct-span-control-first','false'],None),('strict-candidate-retained',['python3',str(root/'verify_retained_mode.py'),'go-direct-span-candidate-first','true'],None)]
rows=[]
for label,command,cwd in steps:
 begin=time.monotonic()
 with (root/(label+'.log')).open('w') as stream:result=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
 rows.append(row);(root/'validation.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(label,result.returncode,round(row['seconds'],3),flush=True)
 if result.returncode:print((root/(label+'.log')).read_text()[-6000:],flush=True)
 assert result.returncode==0
