package core

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"sync"

	"github.com/containerd/containerd/v2/core/content"
	bkcache "github.com/dagger/dagger/engine/snapshots"
	"github.com/dagger/dagger/internal/buildkit/executor/oci"
	"github.com/moby/locker"
	"github.com/vektah/gqlparser/v2/ast"

	"github.com/dagger/dagger/auth"
	workspacepkg "github.com/dagger/dagger/core/workspace"
	"github.com/dagger/dagger/dagql"
	"github.com/dagger/dagger/engine"
	engineclient "github.com/dagger/dagger/engine/client"
	"github.com/dagger/dagger/engine/clientdb"
	"github.com/dagger/dagger/engine/engineutil"
	serverresolver "github.com/dagger/dagger/engine/server/resolver"
	"google.golang.org/grpc"
)

// Query forms the root of the DAG and houses all necessary state and
// dependencies for evaluating queries.
type Query struct {
	Server

	// ConstructorArgs stores arguments to pass to the entrypoint module's
	// constructor. Set by the `with` field on Query so that entrypoint
	// proxy resolvers can forward them to the constructor.
	ConstructorArgs map[string]dagql.Input

	cacheVolumeStoreMu sync.Mutex
	cacheVolumeStore   *cacheVolumeStore

	// Optional capture-approved donors belong to this client's Query, never
	// the engine or persisted recipes. They contain capabilities, not objects.
	// Clones share the registry.
	hostHistoryMu sync.Mutex
	hostHistory   *hostHistoryRegistry
}

var (
	ErrNoCurrentModule       = fmt.Errorf("no current module")
	ErrNoCurrentFunctionCall = fmt.Errorf("no current function call")
	ErrNoCurrentWorkspace    = fmt.Errorf("no current workspace")
)

type SpecificClientAttachableConnOpts struct {
	// IfAvailable returns ok=false instead of waiting when the client currently
	// has no active session attachables.
	IfAvailable bool
}

// APIs from the server+session+client that are needed by core APIs
type Server interface {
	// Register a unique nested transport using the creating context's held
	// client scope before the proxy begins serving.
	RegisterNestedClientTransport(context.Context, *engine.ClientMetadata, string) (*engine.NestedClientTransport, error)

	// Handle an HTTP request from a registered nested Dagger client. When
	// inertAttachables is true, host session attachable access is denied rather
	// than inherited from the parent or awaited on the synthetic client.
	ServeHTTPToNestedClient(w http.ResponseWriter, r *http.Request, transport *engine.NestedClientTransport, metadata *engine.ClientMetadata, callerClientID string, inertAttachables bool, moduleContext dagql.AnyObjectResult, functionCall dagql.Typed)

	// Stitch in the given module to the list being served to the current client
	ServeModule(ctx context.Context, mod dagql.ObjectResult[*Module], includeDependencies bool, entrypoint bool) error

	// If the current client is coming from a function, return the module that function is from
	CurrentModule(context.Context) (dagql.ObjectResult[*Module], error)

	// If the current client is a module client or a client created by a module function, returns that module.
	ModuleParent(context.Context) (dagql.ObjectResult[*Module], error)

	// If the current client is coming from a function, return the function call metadata
	CurrentFunctionCall(context.Context) (*FunctionCall, error)

	// Return the modules being served to the current client
	CurrentServedDeps(context.Context) (*SchemaBuilder, error)

	// The Client metadata of the main client caller (i.e. the one who created
	// the session, typically the CLI invoked by the user)
	MainClientCallerMetadata(context.Context) (*engine.ClientMetadata, error)

	// Metadata about the main client, aka "non-module parent client", aka "NMPC".
	//
	// The NMPC is the nearest ancestor client that is not a module.
	// It is either a caller from the host like the CLI or a nested exec.
	// Useful for figuring out where local sources should be resolved from through
	// chains of dependency modules.
	NonModuleParentClientMetadata(context.Context) (*engine.ClientMetadata, error)

	// The client whose host the module ModuleParent returns was loaded from:
	// the nearest non-module client above that module.
	ModuleParentHostClientMetadata(context.Context) (*engine.ClientMetadata, error)

	// AuthorizeGitPush resolves optional owner URL routing and checks permission
	// before any destination credentials are used. Its result stays operation-local.
	AuthorizeGitPush(context.Context, string, string, bool, bool) (*GitPushAuthorization, error)

	// AuthorizeGitRead returns the client whose Git credentials may
	// authenticate a read of the remote that an agent's model supplied as a
	// tool argument, asking that owner first when a module drives the agent.
	AuthorizeGitRead(context.Context, string) (*engine.ClientMetadata, error)

	// The cached workspace result from ensureWorkspaceLoaded.
	CurrentWorkspace(context.Context) (*Workspace, error)

	// Load pending workspace modules on demand; include narrows to the modules
	// its patterns name ("module" or "module:item"), empty or unrecognized
	// loads all. In a best-effort mode, modules that fail to load are skipped with a
	// warning instead of failing the operation, and their failure messages are
	// returned for the caller to surface (e.g. failed module artifacts) —
	// for operations like generate that may be exactly what repairs the module.
	EnsureWorkspaceModules(ctx context.Context, include []string, mode ModuleLoadMode) (loadFailures []ModuleLoadFailure, _ error)

	// A snapshot of the current workspace lockfile. When requireWritable is
	// true, returns ok=false for read-only workspace lock sources.
	CurrentWorkspaceLock(ctx context.Context, requireWritable bool) (*workspacepkg.Lock, bool, error)

	// Stage a lockfile value for the current workspace's live lock state.
	SetCurrentWorkspaceLookup(context.Context, string, string, []any, string) error

	// The Client metadata of a specific client ID within the same session as the
	// current client.
	SpecificClientMetadata(context.Context, string) (*engine.ClientMetadata, error)

	// The default deps of every user module (currently just core)
	DefaultDeps(context.Context) (*SchemaBuilder, error)

	// The current client's memo of schema builders by module set, shared by
	// its handle loads (see Query.ModDepsForCall). Nil disables memoization.
	SchemaBuilderMemo(context.Context) (*SchemaBuilderMemo, error)

	// The current session's memo of module dependency schemas, shared by
	// all of the session's clients and dropped with the session. Nil
	// disables memoization.
	SessionSchemaBuilderMemo(context.Context) (*SchemaBuilderMemo, error)

	// The telemetry seen-key store for the current client's session.
	TelemetrySeenKeyStore(context.Context) (dagql.TelemetrySeenKeyStore, error)

	// The claim store for call-payload telemetry, scoped to the current
	// client's delivery route — the client and its ancestors, the DBs its
	// telemetry actually fans out to — rather than the whole session. See
	// core/dag_call_telemetry.go for why the scopes must differ.
	CallPayloadSeenKeyStore(context.Context) (dagql.CallPayloadSeenKeyStore, error)

	// The DagQL server for the current client's session
	Server(context.Context) (*dagql.Server, error)

	// Mix in this http endpoint+handler to the current client's session
	MuxEndpoint(context.Context, string, http.Handler) error

	// The session attachables connection for a specific client ID within the
	// same session as the current client. Returns ok=false only when
	// opts.IfAvailable is set and the client has no active session attachables.
	SpecificClientAttachableConn(context.Context, string, SpecificClientAttachableConnOpts) (*grpc.ClientConn, bool, error)

	// The auth provider for the current client
	Auth(context.Context) (*auth.RegistryAuthProvider, error)

	// The session-owned engine utility gateway for the current executable scope.
	// Caller-facing operations route from immutable ClientMetadata in context.
	Engine(context.Context) (*engineutil.Client, error)

	// The session-owned registry resolver for the current client.
	RegistryResolver(context.Context) (*serverresolver.Resolver, error)

	// The services for the current client's session
	Services(context.Context) (*Services, error)

	// The agent runtimes for the current client's session
	Agents(context.Context) (*AgentRuntimes, error)

	// The default platform for the engine as a whole
	Platform() Platform

	// The content store for the engine as a whole
	OCIStore() content.Store

	// The builtin engine OCI source store.
	BuiltinOCIStore() content.Store

	// The dns configuration for the engine as a whole
	DNS() *oci.DNSConfig

	// The lease manager for the engine as a whole
	LeaseManager() *bkcache.LeaseManager

	// Return all the cache entries in the local cache. No support for filtering yet.
	EngineLocalCacheEntries(context.Context) (*EngineCacheEntrySet, error)

	// Prune releaseable local-cache entries using explicit disk and/or structural
	// controls, or the enabled engine-wide default policies when requested.
	PruneEngineLocalCacheEntries(context.Context, EngineCachePruneOptions) (*EngineCacheEntrySet, error)

	// The default local cache policy to use for automatic local cache GC.
	EngineLocalCachePolicy() *dagql.CachePrunePolicy

	// Gets the engine snapshot manager.
	SnapshotManager() bkcache.SnapshotManager

	// A global lock for the engine, can be used to synchronize access to
	// shared resources between multiple potentially concurrent calls.
	Locker() *locker.Locker

	// A shared engine-wide salt used when creating cache keys for secrets based on their plaintext
	SecretSalt() []byte

	// EngineVolumeState returns the engine-local configuration needed to
	// resolve operator-managed volumes at exec time.
	EngineVolumeState() EngineVolumeState

	// Flush telemetry for all clients in the current session.
	FlushSessionTelemetry(ctx context.Context) error

	// Name the current session: its trace and, for agent sessions, its engine
	// archive. Only the session's main client may set it.
	SetSessionTitle(ctx context.Context, title string) error

	// SessionScopedContext returns a context that lives for the remainder of
	// the current client's session: it is detached from the given context's
	// cancellation and is canceled when the session begins closing. Use it
	// for background work that serves the session as a whole rather than a
	// single call.
	SessionScopedContext(ctx context.Context) (context.Context, error)

	// Open a client's telemetry database.
	ClientTelemetry(ctc context.Context, sessID, clientID string) (*clientdb.DB, error)

	// The name of the engine
	EngineName() string

	// The list of connected client IDs
	Clients() []string

	// Return a client connected to a cloud engine. If bool return is false, the local engine should be used. Session attachables for the returned client will be proxied back to the calling client.
	CloudEngineClient(
		ctx context.Context,
		module string,
		function string,
		execCmd []string,
	) (
		cloudClient *engineclient.Client,
		useCloudClient bool,
		err error,
	)

	// A mount namespace guaranteed to not have any mounts created by engine operations.
	// Should be used when creating goroutines/processes that unshare a mount namespace,
	// otherwise those unshared mnt namespaces may inherit mounts from engine operations
	// and leak them.
	CleanMountNS() *os.File
}

type queryKey struct{}

func ContextWithQuery(ctx context.Context, q *Query) context.Context {
	return context.WithValue(ctx, queryKey{}, q)
}

func CurrentQuery(ctx context.Context) (*Query, error) {
	q, ok := ctx.Value(queryKey{}).(*Query)
	if !ok {
		return nil, fmt.Errorf("no query in context")
	}
	return q, nil
}

func CurrentDagqlServer(ctx context.Context) (*dagql.Server, error) {
	// Prefer the dagql server explicitly attached to this resolver context.
	// This is required for dynamic schemas (e.g. SDKs implemented as modules)
	// that run selections against a server different from the session's default.
	if srv := dagql.CurrentDagqlServer(ctx); srv != nil {
		return srv, nil
	}

	q, err := CurrentQuery(ctx)
	if err != nil {
		return nil, fmt.Errorf("current query: %w", err)
	}
	srv, err := q.Server.Server(ctx)
	if err != nil {
		return nil, fmt.Errorf("query server: %w", err)
	}
	return srv, nil
}

func NewRoot(srv Server) *Query {
	return &Query{Server: srv}
}

func (*Query) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Query",
		NonNull:   true,
	}
}

func (*Query) TypeDescription() string {
	return "The root of the DAG."
}

func (q *Query) Clone() *Query {
	cp := &Query{
		Server: q.Server,
	}
	if q.ConstructorArgs != nil {
		cp.ConstructorArgs = make(map[string]dagql.Input, len(q.ConstructorArgs))
		for k, v := range q.ConstructorArgs {
			cp.ConstructorArgs[k] = v
		}
	}

	q.cacheVolumeStoreMu.Lock()
	cp.cacheVolumeStore = q.cacheVolumeStore
	q.cacheVolumeStoreMu.Unlock()

	// Allocate the donor registry before sharing it, so a registration through
	// either the original or the clone is visible to both.
	cp.hostHistory = q.hostHistories()

	return cp
}

func (q *Query) WithPipeline(name, desc string) *Query {
	return q.Clone()
}

func (q *Query) NewHost() *Host {
	return &Host{}
}

func (q *Query) NewModule() *Module {
	return &Module{
		Deps: NewSchemaBuilder(q, nil),
	}
}

// ModDepsForCall loads the module dependencies referenced by the given result call.
func (q *Query) ModDepsForCall(ctx context.Context, rootCall *dagql.ResultCall) (*SchemaBuilder, error) {
	defaultDeps, err := q.DefaultDeps(ctx)
	if err != nil {
		return nil, fmt.Errorf("default deps: %w", err)
	}
	dag, err := CurrentDagqlServer(ctx)
	if err != nil {
		return nil, fmt.Errorf("bootstrap schema: %w", err)
	}

	deps := defaultDeps
	seenModuleResultIDs := map[uint64]struct{}{}

	appendModule := func(inst dagql.ObjectResult[*Module]) error {
		if inst.Self() == nil {
			return nil
		}
		if !inst.Self().Source.Valid {
			// Bare dag.module() builder shells are intermediate construction results,
			// not source-backed dependency modules to install into a schema.
			return nil
		}
		instID, err := inst.ID()
		if err != nil {
			return fmt.Errorf("module %q handle ID: %w", inst.Self().Name(), err)
		}
		if instID == nil || instID.EngineResultID() == 0 {
			return fmt.Errorf("module %q is not attached", inst.Self().Name())
		}
		if _, seen := seenModuleResultIDs[instID.EngineResultID()]; seen {
			return nil
		}
		seenModuleResultIDs[instID.EngineResultID()] = struct{}{}
		deps = deps.Append(NewUserMod(inst))
		return nil
	}

	cache, err := dagql.EngineCache(ctx)
	if err != nil {
		return nil, fmt.Errorf("engine cache: %w", err)
	}
	clientMetadata, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return nil, fmt.Errorf("current client metadata: %w", err)
	}
	if clientMetadata.SessionID == "" {
		return nil, fmt.Errorf("empty session ID")
	}
	installed, err := q.installedSchemaModuleCandidates(ctx, cache)
	if err != nil {
		return nil, err
	}
	decisions := map[uint64]dagql.ObjectResult[*Module]{}
	if err := cache.WalkResultCall(rootCall, func(ref *dagql.ResultCallRef, frame *dagql.ResultCall) error {
		if ref == nil || ref.ResultID == 0 || frame == nil || frame.Type == nil || frame.Type.NamedType != "Module" {
			return nil
		}
		if inst, ok := decisions[ref.ResultID]; ok {
			return appendModule(inst)
		}
		res, err := cache.LoadResultByResultIDForSchema(ctx, clientMetadata.SessionID, dag, ref.ResultID, installed)
		if err != nil {
			return fmt.Errorf("load module result %d: %w", ref.ResultID, err)
		}
		modInst, ok := res.(dagql.ObjectResult[*Module])
		if !ok {
			return fmt.Errorf("result %d is %T, not module result", ref.ResultID, res)
		}
		decisions[ref.ResultID] = modInst
		return appendModule(modInst)
	}); err != nil {
		return nil, err
	}
	// Share one schema server per module set: without this, every handle
	// load (node(id:), interface loads) rebuilds a server and reinstalls
	// every referenced module.
	memo, err := q.SchemaBuilderMemo(ctx)
	if err != nil {
		return nil, fmt.Errorf("schema builder memo: %w", err)
	}
	if recoveredSchemaTemplates.Load() {
		return memo.getForClient(deps, currentSessionSchemaBuilderMemo(ctx)), nil
	}
	return memo.Get(deps), nil
}

func (q *Query) RequireMainClient(ctx context.Context) error {
	clientMetadata, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return fmt.Errorf("failed to get client metadata: %w", err)
	}
	mainClientCallerMetadata, err := q.MainClientCallerMetadata(ctx)
	if err != nil {
		return fmt.Errorf("failed to get main client caller ID: %w", err)
	}
	if clientMetadata.ClientID != mainClientCallerMetadata.ClientID {
		return fmt.Errorf("only the main client can call this function")
	}
	return nil
}
