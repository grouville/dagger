# Follow-up from the lossless real-repository capture

With native library-object retention plus shared recovered schemas, the listing returns all 4398 ordered rows and exits successfully. Periodic recorder drains retain 2744897 events, with zero dropped or open. All 8621 SDK requests have exact admission/query parent links. Library-root preparations fall from 4333 to 396 versus the previous selected-module capture, but requests rise from 7820 to 8621. Those captures use different engine binaries and are diagnostic counts, not matched timing evidence.

Substantial repeated registration remains: the capture records 157299 Query.typeDef calls. The generic component's stable provider instance does not fully model the engine's core provider. CoreSchemaBase.CoreMod(view) allocates a fresh immutable wrapper on each call; SchemaBuilder.memoKey keys non-user modules by their instance pointer. The active server obtains core providers for individual clients. Consequently, otherwise identical registries can receive different keys. Inspect actual key components before claiming this explains all remaining registration.

A potential refinement is to canonicalize the immutable core-provider wrapper by its existing schema base and API view, preserving separate bases and views. CoreMod has only base and view fields, and its methods do not mutate them. Such a refinement needs a realistic provider regression, concurrency checks and a new complete-command comparison. Do not change the active candidate during the fixed timing cohort and do not merge arbitrary providers by name.

The current fixed four-pair comparison is running with profiling disabled. Its outcome remains unknown; no new gain, selected change or upstream proposal is established yet.
