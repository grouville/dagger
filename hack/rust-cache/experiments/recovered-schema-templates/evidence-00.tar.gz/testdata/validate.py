from pathlib import Path
import json
import os
import re
import statistics
import subprocess
import time

p = Path(__file__).parent
module = '/tmp/dagger-recovered-schema-templates'
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
rows = []


def run(label, arm, flags):
    command = [go, 'test', '-p', '2', '-buildvcs=false', '-overlay', str(p / (arm + '-overlay.json')), *flags]
    tick = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=module, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, arm=arm, command=command, exit_code=result.returncode, seconds=time.monotonic() - tick)
    rows.append(row)
    (p / 'validation.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    return result.returncode


code = run('regression-before', 'before', ['-race', '-count=1', '-run', '^TestRecoveredSchemasShareInstallationAcrossClients$', './core'])
assert code != 0
text = (p / 'regression-before.log').read_text()
assert 'one installation for the session' in text and 'actual' in text and 'expected' in text, text[-6000:]
assert run('core-schema-after', 'after', ['-race', '-count=1', '-run', '^Test(SchemaBuilder|RecoveredSchemas|ArtifactSchema|ModDepsForCall)', './core', './core/schema']) == 0

benchmarks = []
for pair in range(4):
    for arm in (['before', 'after'] if pair % 2 == 0 else ['after', 'before']):
        label = f'{pair}-{arm}'
        assert run(label, arm, ['-run', '^$', '-bench', '^BenchmarkRecoveredModuleSchemas$', '-benchmem', '-benchtime=300ms', '-count=1', './core']) == 0
        text = (p / (label + '.log')).read_text()
        match = re.search(r'^BenchmarkRecoveredModuleSchemas-\d+\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op', text, re.M)
        assert match, text
        benchmarks.append(dict(pair=pair, arm=arm, ns_per_op=int(match[1]), bytes_per_op=int(match[2]), allocations_per_op=int(match[3])))
        (p / 'component-samples.json').write_text(json.dumps(benchmarks, indent=2) + '\n')

summary = dict(scope='Warm code; each operation reconstructs module schemas for 64 fresh client roots, with 128 functions. Each operation creates fresh session and client memos. Actual Query.ModDepsForCall and schema preparation are included. No engine command timing claim.',
               pairs=4,
               medians={arm: {key: statistics.median(row[key] for row in benchmarks if row['arm'] == arm)
                              for key in ['ns_per_op', 'bytes_per_op', 'allocations_per_op']} for arm in ['before', 'after']},
               faster_pairs=sum(next(row['ns_per_op'] for row in benchmarks if row['pair'] == pair and row['arm'] == 'after') <
                                next(row['ns_per_op'] for row in benchmarks if row['pair'] == pair and row['arm'] == 'before') for pair in range(4)),
               selected=False, new_upstream_proposal=False)
(p / 'component-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
