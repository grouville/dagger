from pathlib import Path
import json,subprocess
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';rows=[]
for step in json.loads((p/'capture-steps.json').read_text()):
 d=p/step['label']
 with (d/'analysis.log').open('w') as out:r=subprocess.run(['python3',str(p/'analyze.py'),str(d)],stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==0,(d/'analysis.log').read_text()[-3500:]
 a=json.loads((d/'attribution.json').read_text());r=json.loads((d/'result.json').read_text());row=dict(label=step['label'],arm=step['arm'],seconds=r['seconds'],engine_cpu=r['engine_cpu'],total_alloc=r['heap_delta']['TotalAlloc'],function_evaluations=a['function_evaluations'],getters=a['selected_calls']['go:GoPackages.get'],discovery=a['selected_calls']['go:GoPackage.tests'],sdk_requests=a['sdk_requests'],dropped=a['dropped'],open_ops=a['open_ops'])
 assert row['function_evaluations']==804 and row['getters']=={'executed':800} and row['discovery']=={'executed':1,'hit':799} and not row['dropped'] and not row['open_ops'],row
 rows.append(row)
 for cumulative in [False,True]:
  with (d/('alloc-cumulative.txt' if cumulative else 'alloc-flat.txt')).open('w') as out:r=subprocess.run([go,'tool','pprof','-sample_index=alloc_space','-top','-nodecount=70']+(['-cum'] if cumulative else [])+['-base='+str(d/'allocs-before.pprof'),str(p/'dagger-engine'),str(d/'allocs-after.pprof')],stdout=out,stderr=subprocess.STDOUT)
  assert r.returncode==0
 print(json.dumps(row),flush=True)
(p/'capture-attribution.json').write_text(json.dumps(rows,indent=2)+'\n')
