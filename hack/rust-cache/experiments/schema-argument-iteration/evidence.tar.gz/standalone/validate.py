from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;repo='/tmp/dagger-schema-argument-iteration';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[]
command=[go,'test','-p=2','-race','-count=1','./dagql'];tick=time.monotonic()
with (p/'after-race.log').open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
(p/'after-race.json').write_text(json.dumps(dict(command=command,seconds=time.monotonic()-tick,exit_code=r.returncode),indent=2)+'\n');assert r.returncode==0,(p/'after-race.log').read_text()[-3500:]
for block in range(4):
 for arm in (['after','before'] if block%2==0 else ['before','after']):
  command=[go,'test','-p=2']+(['-overlay='+str(p/'before-overlay.json')] if arm=='before' else [])+['-run=^$','-bench=^BenchmarkInputDefinitionIteration$','-benchmem','-benchtime=100ms','-count=1','./dagql'];label=f'{block}-{arm}';tick=time.monotonic()
  with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
  assert r.returncode==0,(label,(p/(label+'.log')).read_text()[-3000:])
  cases=[dict(count=int(n),kind=kind,ns=float(ns),bytes=int(b),allocs=int(allocs)) for n,kind,ns,b,allocs in re.findall(r'BenchmarkInputDefinitionIteration/(\d+)/(definitions|inputs)-\d+\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',(p/(label+'.log')).read_text())];assert len(cases)==8
  row=dict(block=block,arm=arm,command=command,seconds=time.monotonic()-tick,cases=cases);rows.append(row);(p/'paired.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
summary={}
for count in [1,8,16,64]:
 for kind in ['definitions','inputs']:
  key=f'{count}-{kind}';summary[key]={}
  for arm in ['before','after']:
   cases=[c for r in rows if r['arm']==arm for c in r['cases'] if c['count']==count and c['kind']==kind];summary[key][arm]={k:statistics.median(c[k] for c in cases) for k in ['ns','bytes','allocs']}
  summary[key]['faster_pairs']=sum(next(c['ns'] for r in rows if r['arm']=='after' and r['block']==block for c in r['cases'] if c['count']==count and c['kind']==kind)<next(c['ns'] for r in rows if r['arm']=='before' and r['block']==block for c in r['cases'] if c['count']==count and c['kind']==kind) for block in range(4))
(p/'paired-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
