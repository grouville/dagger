from pathlib import Path
import json,os,subprocess
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';binary='/tmp/rust-cache-sipsma-review/native-glob-prefix-engine/dagger-engine';rows=[]
def run(args,out):
 with out.open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(out,out.read_text()[-3000:])
for i in range(4):
 d=p/f'capture-{i}';run(['python3',str(p/'analyze.py'),str(d)],d/'analysis.log')
 r=json.loads((d/'result.json').read_text());a=json.loads((d/'attribution.json').read_text());rows.append(dict(iteration=i,seconds=r['seconds'],engine_cpu=r['engine_cpu'],total_alloc=r['heap_delta']['TotalAlloc'],gc_cycles=r['heap_delta'].get('NumGC'),evaluations=a['function_evaluations'],getter=a['selected_calls']['go:GoPackages.get'],discovery=a['selected_calls']['go:GoPackage.tests'],dropped=a['dropped'],open=a['open_ops']))
 for cumulative in [False,True]:run([go,'tool','pprof','-sample_index=alloc_space','-top','-nodecount=80']+(['-cum'] if cumulative else [])+['-base='+str(d/'allocs-before.pprof'),binary,str(d/'allocs-after.pprof')],d/('alloc-cumulative.txt' if cumulative else 'alloc-flat.txt'))
 print(json.dumps(rows[-1]),flush=True)
for cumulative in [False,True]:
 run([go,'tool','pprof','-sample_index=alloc_space','-top','-nodecount=100']+(['-cum'] if cumulative else [])+['-base='+str(p/'capture-0/allocs-before.pprof'),binary,str(p/'capture-3/allocs-after.pprof')],p/('aggregate-alloc-cumulative.txt' if cumulative else 'aggregate-alloc-flat.txt'))
 windows=sorted(p.glob('capture-*/engine-cpu-*.pprof'))
 run([go,'tool','pprof','-top','-nodecount=100']+(['-cum'] if cumulative else [])+[binary,*[str(x) for x in windows]],p/('aggregate-cpu-cumulative.txt' if cumulative else 'aggregate-cpu-flat.txt'))
(p/'allocation-captures.json').write_text(json.dumps(dict(commands=rows,total_alloc=sum(r['total_alloc'] for r in rows),engine_cpu=sum(r['engine_cpu'] for r in rows),sampling_caveat='pprof allocation records may lag two GC cycles; aggregate contains bracketing profile request work and boundary lag. TotalAlloc counters are authoritative for exact per-command bytes.'),indent=2)+'\n')
