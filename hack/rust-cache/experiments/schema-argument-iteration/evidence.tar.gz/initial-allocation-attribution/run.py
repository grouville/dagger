from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for i in range(4):
 command=['python3',str(p/'capture.py'),'--arm','candidate','--module','current','--output',str(p/f'capture-{i}'),'--edit-test-body','--cpu-profile'];tick=time.monotonic()
 with (p/f'capture-{i}-driver.log').open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(iteration=i,seconds=time.monotonic()-tick,command=command,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/f'capture-{i}-driver.log').read_text()[-4000:]);raise SystemExit(r.returncode)
