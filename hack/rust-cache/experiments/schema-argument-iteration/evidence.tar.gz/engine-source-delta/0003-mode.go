package dagql

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var schemaArgumentIterationEnabled atomic.Bool

func init() {
	schemaArgumentIterationEnabled.Store(os.Getenv("DAGGER_TEST_SCHEMA_ARGUMENT_ITERATION") == "true")
}
func SchemaArgumentIterationDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		v, e := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if e != nil {
			http.Error(w, e.Error(), 400)
			return
		}
		schemaArgumentIterationEnabled.Store(v)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": schemaArgumentIterationEnabled.Load()})
}
