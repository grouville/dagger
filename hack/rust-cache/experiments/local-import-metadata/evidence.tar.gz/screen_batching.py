from collections import Counter, defaultdict
from pathlib import Path
import json
import statistics

out = Path(__file__).parent
capture = Path('/tmp/rust-cache-sipsma-review/telemetry-native-storage/capture/wcprof-complete.ndjson')
parents = {}
guards = {}
phases = defaultdict(list)
with capture.open() as stream:
    header = json.loads(next(stream))
    names = header['strings']
    assert header['dropped_events'] == 0 and not header.get('open_ops')
    for line in stream:
        event = json.loads(line)
        if event['e'] != 'op':
            continue
        parents[event['id']] = event.get('p', 0)
        cls = names[event['c']]
        if cls == 'core.readGitClientDeclarations':
            guards[event['id']] = event
        elif cls in ('core.config.stat', 'core.config.ownerMetadata', 'core.config.backendClient'):
            phases[cls].append(event)

indexed = {}
for cls, events in phases.items():
    by_guard = {}
    for event in events:
        parent = event.get('p', 0)
        while parent and parent not in guards:
            parent = parents.get(parent, 0)
        assert parent, event
        if parent not in by_guard or event['s'] < by_guard[parent]['s']:
            by_guard[parent] = event
    assert len(by_guard) == len(guards) == 15003
    indexed[cls] = by_guard
first = indexed['core.config.stat']

by_path = defaultdict(list)
for ident, event in guards.items():
    stat = first[ident]
    assert event['s'] <= stat['s'] < event['d']
    owner = indexed['core.config.ownerMetadata'][ident]
    backend = indexed['core.config.backendClient'][ident]
    assert event['s'] <= owner['s'] <= owner['d'] <= backend['s'] <= backend['d'] <= stat['s']
    by_path[(names[stat.get('cl', 0)], names[stat.get('i', 0)])].append((event['s'], owner['d'], backend['d'], stat['s']))

screens = []
for admission_index, admission_name in enumerate(('guard-entry', 'owner-ready', 'backend-ready')):
 for delay_us in (0, 25, 100, 250, 1000):
    batch_sizes = []
    per_path = []
    for (_, path), events in by_path.items():
        sizes = []
        seal = -1
        for arrived, initial_stat_start in sorted((e[admission_index], e[3]) for e in events):
            if arrived < seal:
                sizes[-1] += 1
            else:
                sizes.append(1)
                seal = initial_stat_start + delay_us * 1000
        batch_sizes.extend(sizes)
        per_path.append(dict(path=path, requests=len(events), batches=len(sizes)))
    screens.append(dict(admission=admission_name, additional_window_us=delay_us, requests=len(guards),
        batches=len(batch_sizes), followers=len(guards)-len(batch_sizes),
        median_batch_size=statistics.median(batch_sizes), maximum_batch_size=max(batch_sizes),
        singleton_batches=Counter(batch_sizes)[1], paths=per_path))

result = dict(scope='Fixed-schedule diagnostic screen, not an implementation, concurrency proof, new benchmark, or elapsed-time prediction. Requests are hypothetically grouped only before the first recorded stat begins, with optional extra windows. The initial guard-to-stat interval includes work before a production batching key is available. Actual CLI filesystem-read instants are not recorded. A changed schedule can change these group sizes. The older in-progress sharing remains rejected.',
    capture=str(capture), engine='4080ad95', events=header['event_count'], screens=screens)
(out/'batching-screen.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps([{k: v for k, v in screen.items() if k != 'paths'} for screen in screens], indent=2))
