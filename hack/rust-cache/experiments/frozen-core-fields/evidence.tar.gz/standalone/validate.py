from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;repo='/tmp/dagger-frozen-core-field-definitions';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');steps=[];rows=[]
def run(label,command):
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'validation-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert not r.returncode,(p/(label+'.log')).read_text()[-3500:]
 return (p/(label+'.log')).read_text()
run('full-dagql-race',[go,'test','-p=2','-race','-count=1','./dagql'])
for block in range(4):
 # Go's benchmark order is fixed, so run each arm separately and alternate it.
 for frozen in ([True,False] if block%2==0 else [False,True]):
  label=f'bench-{block}-{frozen}';command=[go,'test','-p=2','-run=^$','-bench=^BenchmarkFrozenFieldSchema/types[0-9]+/frozen'+str(frozen).lower()+'$','-benchmem','-benchtime=100ms','-count=1','./dagql'];log=run(label,command)
  cases=[dict(types=int(n),frozen=state=='true',ns=float(ns),bytes=int(bs),allocs=int(al)) for n,state,ns,bs,al in re.findall(r'BenchmarkFrozenFieldSchema/types(\d+)/frozen(true|false)-\d+\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',log)];assert len(cases)==2,(label,log)
  rows.append(dict(block=block,frozen=frozen,cases=cases));(p/'component-pairs.json').write_text(json.dumps(rows,indent=2)+'\n')
summary={}
for count in [16,64]:
 summary[str(count)]={str(frozen):{k:statistics.median(c[k] for r in rows if r['frozen']==frozen for c in r['cases'] if c['types']==count) for k in ['ns','bytes','allocs']} for frozen in [False,True]}
 summary[str(count)]['faster_pairs']=sum(next(c['ns'] for r in rows if r['block']==b and r['frozen'] for c in r['cases'] if c['types']==count)<next(c['ns'] for r in rows if r['block']==b and not r['frozen'] for c in r['cases'] if c['types']==count) for b in range(4))
(p/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
