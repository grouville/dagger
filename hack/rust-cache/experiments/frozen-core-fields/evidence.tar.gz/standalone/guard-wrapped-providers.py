from pathlib import Path
p=Path('/tmp/dagger-frozen-core-field-definitions');f=p/'dagql/objects.go';s=f.read_text();anchor='func (class Class[T]) freezeFieldDefinitions(view call.View) {';assert s.count(anchor)==1;s=s.replace(anchor,'''func (class Class[T]) schemaClassType() reflect.Type {
	return reflect.TypeFor[Class[T]]()
}

'''+anchor,1);f.write_text(s)
f=p/'dagql/server.go';s=f.read_text();a='''		if class, ok := object.(interface{ freezeFieldDefinitions(call.View) }); ok {''';assert s.count(a)==1;s=s.replace(a,'\t\tif class, ok := schemaClassFor(object); ok {',1)
a='''	if class, ok := val.(interface{ schemaTypeDefinition(call.View) *ast.Definition }); ok {''';assert s.count(a)==1;s=s.replace(a,'\tif class, ok := schemaClassFor(val); ok {',1)
a='func schemaDefinition(kind ast.DefinitionKind';i=s.index(a);helper='''type immutableSchemaClass interface {
	freezeFieldDefinitions(call.View)
	schemaTypeDefinition(call.View) *ast.Definition
	schemaClassType() reflect.Type
}

func schemaClassFor(val Type) (immutableSchemaClass, bool) {
	class, ok := val.(immutableSchemaClass)
	if !ok {
		return nil, false
	}
	// A wrapper can promote these methods while overriding TypeDefinition.
	// Only the concrete Class (or its pointer) owns this metadata contract.
	typ, classType := reflect.TypeOf(val), class.schemaClassType()
	if typ != classType && typ != reflect.PointerTo(classType) {
		return nil, false
	}
	return class, true
}

''';s=s[:i]+helper+s[i:];f.write_text(s)
