from pathlib import Path
import json,re
p=Path(__file__).parent;prior=p.parent/'class-fork-cow-engine';out=p.parent/'frozen-core-fields-engine';out.mkdir(exist_ok=True);repo=Path('/tmp/dagger-frozen-core-field-definitions');overlay=json.loads((prior/'overlay.json').read_text())
old=(p/'before-objects.go').read_text();new=(repo/'dagql/objects.go').read_text();key='/tmp/dagger-filesync-snapshot-seeds/dagql/objects.go';active=Path(overlay['Replace'][key]).read_text()
def method(source,name):
 a=source.index('func (class Class[T]) '+name+'(');i=source.index('{',a);level=0
 for j in range(i,len(source)):
  level+=(source[j]=='{')-(source[j]=='}')
  if level==0:return source[a:j+1]
 raise AssertionError(name)
active=active.replace('\tshared     atomic.Bool','\tshared     atomic.Bool\n\tfrozen *frozenClassFields',1)
a=new.index('// frozenClassFields stores');b=new.index('// ownFieldsLocked',a);extra=new[a:b];active=active.replace('// ownFieldsLocked',extra+'// ownFieldsLocked',1)
for name in ['Install','Extend','fieldLocked','TypeDefinition']:
 before=method(old,name);after=method(new,name)
 if name=='Install':
  anchor='\t\t\tfield.Spec = &newSpec';proof=anchor+'\n\t\t\t// A replacement resolver does not inherit the generated accessor proof.\n\t\t\tfield.Spec.readData = nil';before=before.replace(anchor,proof,1);after=after.replace(anchor,proof,1)
 assert active.count(before)==1,name;active=active.replace(before,after,1)
for header,end in [('func fieldForView[','func (class Class[T]) Install'),('func (class Class[T]) schemaTypeDefinition','// ParseField parses')]:
 a=new.index(header);b=new.index(end,a);block=new[a:b]
 if header.startswith('func (class'):
  block=block.replace('if useFrozen && class.frozen != nil','if useFrozen && frozenCoreFieldsEnabled.Load() && class.frozen != nil',1)
  block=block.replace('\tif useFrozen && frozenCoreFieldsEnabled.Load()', '\tbeforeFields := len(def.Fields)\n\treused := false\n\tif useFrozen && frozenCoreFieldsEnabled.Load()',1)
  block=block.replace('\t\tdef.Fields = append(def.Fields, class.frozen.definitions()...)','\t\treused = true\n\t\tdef.Fields = append(def.Fields, class.frozen.definitions()...)',1)
  block=block.replace('\t// Populate interface names on the definition.','\tif useFrozen { recordFrozenFieldDefinitions(reused, len(def.Fields)-beforeFields) }\n\t// Populate interface names on the definition.',1)
  active=active.replace('// ParseField parses',block+'// ParseField parses',1)
 else:
  i=active.index('func (class Class[T]) Install');active=active[:i]+block+active[i:]
# Carry only metadata across both diagnostic fork paths.
for anchor in ['\t\t\tinterfaces: maps.Clone(class.interfaces),','\t\tinterfaces: class.interfaces,']:
 assert active.count(anchor)==1,anchor;active=active.replace(anchor,anchor+'\n\t\t\tfrozen: class.frozen,',1)
(out/'objects.go').write_text(active);overlay['Replace'][key]=str(out/'objects.go')
key='/tmp/dagger-filesync-snapshot-seeds/dagql/server.go';active=Path(overlay['Replace'][key]).read_text();source=(repo/'dagql/server.go').read_text()
a=source.index('// FreezeFieldDefinitions prepares');b=source.index('// Schema returns',a);active=active.replace('// Schema returns',source[a:b]+'// Schema returns',1)
active=active.replace('def := definition(ast.Object, t, view)','def := schemaDefinition(ast.Object, t, view)',1)
a=active.index('\t\t// A directive hidden in this view');b=active.index('\n\t\ts.schemas[view] = schema',a);c=source.index('\t\t// Filter without editing');d=source.index('\n\t\th := xxh3.New()',c);active=active[:a]+source[c:d]+active[b:]
a=source.index('// withoutDefinitionDirectives copies');b=source.index('// withoutDirectives returns',a);active=active.replace('// withoutDirectives returns',source[a:b]+'// withoutDirectives returns',1);(out/'server.go').write_text(active);overlay['Replace'][key]=str(out/'server.go')
key='/tmp/dagger-filesync-snapshot-seeds/core/schema/coremod.go';active=Path(overlay['Replace'].get(key,key)).read_text();anchor='\tbase.views[view] = state';assert active.count(anchor)==1;active=active.replace(anchor,'\tsrv.FreezeFieldDefinitions(view)\n'+anchor,1);(out/'coremod.go').write_text(active);overlay['Replace'][key]=str(out/'coremod.go')
for name in ['frozen_field_definitions_test.go','schema_definition_ownership_test.go']:overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/dagql/'+name]=str(repo/'dagql'/name)
# The preceding source branch moved this test into its independent parent fix.
overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/dagql/class_fork_storage_test.go']=str(Path('/tmp/rust-cache-sipsma-review/class-fork-copy-on-write/measured-class-fork-storage-test.go'))
s=(prior/'engine-debug.go').read_text();anchor='\tm.HandleFunc("/debug/class-fork-cow", dagql.ClassForkCowDiagnostic)';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n\tm.HandleFunc("/debug/frozen-core-fields", dagql.FrozenCoreFieldsDiagnostic)');(out/'engine-debug.go').write_text(s);overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/cmd/engine/debug.go']=str(out/'engine-debug.go')
overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/dagql/frozen_core_fields_mode.go']=str(out/'mode.go');(out/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
s=(prior/'build-engine.py').read_text().replace("DAGGER_TEST_CLASS_FORK_COW='true'","DAGGER_TEST_CLASS_FORK_COW='true',DAGGER_TEST_FROZEN_CORE_FIELDS='true'");(out/'build-engine.py').write_text(s)
plan=json.loads((prior/'engine-plan.json').read_text());plan.update(new_engine='dagger-collection-frozen-core-fields-oct19',ports=dict(engine=16294,debug=16122),candidate_route='frozen-core-fields',scenario='Reuse sealed core field descriptors; keep current headers, view filtering, private clients and all getter execution.');plan['flags']['frozen-core-fields']=False;(out/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(prior/'start-engine.py').read_text().replace('experiments/schema-argument-iteration/final-state.json','experiments/class-fork-cow/final-state.json').replace('codex.task=class-fork-cow','codex.task=frozen-core-fields').replace(':16293:',':16294:').replace(':16121:',':16122:').replace(':16121/',':16122/');(out/'start-engine.py').write_text(s)
(out/'mode.go').write_bytes((p/'mode-template.go').read_bytes())
print('experimental sources prepared')
