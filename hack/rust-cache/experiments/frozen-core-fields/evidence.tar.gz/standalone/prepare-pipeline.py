from pathlib import Path
p=Path(__file__).parent.parent/'frozen-core-fields-engine';prior=p.parent/'class-fork-cow-engine'
for original,name in [('measure-source-edits-quiet.py','measure-source-edits.py'),('measure-test-edits-quiet.py','measure-test-edits.py')]:
 s=(prior/original).read_text().replace('dagger-collection-class-fork-cow-oct19','dagger-collection-frozen-core-fields-oct19').replace(':16121',':16122').replace(':16293',':16294').replace('/class-fork-cow-engine/engine-build.json','/frozen-core-fields-engine/engine-build.json')
 s=s.replace("'schema-argument-iteration','class-fork-cow']","'schema-argument-iteration','class-fork-cow','frozen-core-fields']")
 s=s.replace("mode('class-fork-cow',arm=='engine')","mode('class-fork-cow',True)\n            mode('frozen-core-fields',arm=='engine')")
 s=s.replace("class_fork_cow=arm=='engine'","class_fork_cow=True,frozen_core_fields=arm=='engine'")
 start=s.index("scope='Two-arm immutable class storage experiment.");end=s.index("',orders=orders",start)
 s=s[:start]+"scope='Two-arm sealed core field-definition experiment. Same COW class storage, non-mutating view filter, private clients, schema validation, current headers, Go720 module, suffix-optimized CLI, and all 800 authored getters in both modes. Only consumption of prepared immutable core field definitions changes. Metadata counters and profilers off during timings; real edits and complete cleanup. Two initialization blocks, four alternating measured pairs, pre-command host CPU admission below 10 percent"+s[end:]
 s=s.replace("assert not get('wcprof/enabled')['global_enabled']","assert not get('frozen-core-fields')['record']\nassert not get('wcprof/enabled')['global_enabled']",1)
 (p/name).write_text(s);compile(s,str(p/name),'exec')
for name in ['verify-module.py','verify-rust.py']:
 s=(prior/name).read_text().replace(':16121',':16122').replace(':16293',':16294')
 s=s.replace("'schema-argument-iteration','class-fork-cow']","'schema-argument-iteration','class-fork-cow','frozen-core-fields']")
 s=s.replace("get('class-fork-cow?enabled='+str(arm=='candidate').lower(),b'')","get('class-fork-cow?enabled=true',b'')\n  get('frozen-core-fields?enabled='+str(arm=='candidate').lower(),b'')")
 (p/name).write_text(s);compile(s,str(p/name),'exec')
for name in ['rust-cache-query.py','run-pipeline.py','run-captures.py']:(p/name).write_bytes((prior/name).read_bytes())
s=(prior/'capture.py').read_text().replace('dagger-collection-class-fork-cow-oct19','dagger-collection-frozen-core-fields-oct19').replace(':16121',':16122').replace(':16293',':16294')
s=s.replace("'schema-argument-iteration','class-fork-cow']","'schema-argument-iteration','class-fork-cow','frozen-core-fields']")
s=s.replace("mode('class-fork-cow',options.arm=='candidate')","mode('class-fork-cow',True)\n    mode('frozen-core-fields',options.arm=='candidate')\n    get('frozen-core-fields?record=true&reset=true',b'')")
s=s.replace("class_fork_cow=options.arm=='candidate'","class_fork_cow=True,frozen_core_fields=options.arm=='candidate'")
s=s.replace("metadata_record_before=get('metadata-snapshot-json')['record']","metadata_record_before=get('metadata-snapshot-json')['record']\nfrozen_record_before=get('frozen-core-fields')['record']")
s=s.replace("(root/'metadata-snapshot-stats.json').write_text", "(root/'frozen-field-stats.json').write_text(json.dumps(get('frozen-core-fields'),indent=2)+'\\n')\n    (root/'metadata-snapshot-stats.json').write_text")
s=s.replace("get('wcprof/enabled',b'off')", "get('wcprof/enabled',b'off')\n    get('frozen-core-fields?record='+str(frozen_record_before).lower(),b'')")
(p/'capture.py').write_text(s);compile(s,str(p/'capture.py'),'exec')
s=(prior/'analyze-captures.py').read_text().replace("engine='/tmp/rust-cache-sipsma-review/class-fork-cow-engine/dagger-engine'","engine='/tmp/rust-cache-sipsma-review/frozen-core-fields-engine/dagger-engine'");(p/'analyze-captures.py').write_text(s)
s=(prior/'analyze-allocations.py').read_text();(p/'analyze-allocations.py').write_text(s)
s=(prior/'finalize.py').read_text().replace('experiments/schema-argument-iteration/final-state.json','experiments/class-fork-cow/final-state.json').replace("expected['dagger-collection-class-fork-cow-oct19']","expected['dagger-collection-frozen-core-fields-oct19']").replace(':16121',':16122').replace('/class-fork-cow-engine/engine-plan.json','/frozen-core-fields-engine/engine-plan.json');s=s.replace("assert not get('metadata-snapshot-json')['record'];","assert not get('frozen-core-fields')['record'];assert not get('metadata-snapshot-json')['record'];");(p/'finalize.py').write_text(s)
print('full-pipeline drivers prepared')
