package dagql

import (
 "encoding/json"
 "net/http"
 "os"
 "strconv"
 "sync/atomic"
)

var frozenCoreFieldsEnabled atomic.Bool
var frozenCoreFieldsRecording atomic.Bool
var frozenCoreFreshClasses atomic.Uint64
var frozenCoreReusedClasses atomic.Uint64
var frozenCoreFreshFields atomic.Uint64
var frozenCoreReusedFields atomic.Uint64

func init() { frozenCoreFieldsEnabled.Store(os.Getenv("DAGGER_TEST_FROZEN_CORE_FIELDS")=="true") }
func recordFrozenFieldDefinitions(reused bool, count int) {
 if !frozenCoreFieldsRecording.Load() { return }
 if reused { frozenCoreReusedClasses.Add(1);frozenCoreReusedFields.Add(uint64(count)) } else { frozenCoreFreshClasses.Add(1);frozenCoreFreshFields.Add(uint64(count)) }
}
func FrozenCoreFieldsDiagnostic(w http.ResponseWriter,r *http.Request) {
 if r.Method==http.MethodPost {
  for name,flag:=range map[string]*atomic.Bool{"enabled":&frozenCoreFieldsEnabled,"record":&frozenCoreFieldsRecording} {
   if text,ok:=r.URL.Query()[name];ok {
    value,err:=strconv.ParseBool(text[0]);if err!=nil { http.Error(w,err.Error(),400);return };flag.Store(value)
   }
  }
  if r.URL.Query().Get("reset")=="true" { frozenCoreFreshClasses.Store(0);frozenCoreReusedClasses.Store(0);frozenCoreFreshFields.Store(0);frozenCoreReusedFields.Store(0) }
 } else if r.Method!=http.MethodGet { http.Error(w,"GET or POST required",405);return }
 w.Header().Set("Content-Type","application/json")
 _=json.NewEncoder(w).Encode(map[string]any{"enabled":frozenCoreFieldsEnabled.Load(),"record":frozenCoreFieldsRecording.Load(),"fresh_classes":frozenCoreFreshClasses.Load(),"reused_classes":frozenCoreReusedClasses.Load(),"fresh_fields":frozenCoreFreshFields.Load(),"reused_fields":frozenCoreReusedFields.Load()})
}
