from pathlib import Path
import json,subprocess,time,urllib.request
p=Path(__file__).parent;rows=[]
steps=[('go-checks',['python3',str(p/'verify-module.py')]),('rust-checks',['python3',str(p/'verify-rust.py')]),('source-timings',['python3',str(p/'measure-source-edits.py'),'--fixture','real','--output',str(p/'source-timings'),'--pairs','4']),('test-timings',['python3',str(p/'measure-test-edits.py'),'--fixture','real','--output',str(p/'test-timings'),'--pairs','4'])]
def diagnostic(route,data=None):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16122/debug/'+route,data=data),timeout=15) as response:return json.load(response)
for label,command in steps:
 tick=time.monotonic()
 if label=='go-checks':diagnostic('frozen-core-fields?record=true&reset=true',b'')
 try:
  with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 finally:
  if label=='go-checks':
   stats=diagnostic('frozen-core-fields');(p/'gate-field-snapshot-stats.json').write_text(json.dumps(stats,indent=2)+'\n');diagnostic('frozen-core-fields?record=false',b'')
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'pipeline-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-3500:]);raise SystemExit(r.returncode)
 if label=='go-checks':assert stats['reused_fields']>0 and stats['fresh_fields']>0,stats
