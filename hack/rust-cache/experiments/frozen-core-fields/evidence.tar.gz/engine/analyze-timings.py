from pathlib import Path
import json
import statistics

p = Path(__file__).parent
result = {}
for workload in ['source', 'test']:
    d = p / (workload + '-timings')
    samples = json.loads((d / 'samples.json').read_text())
    assert len(samples) == 12
    assert all(r['exit_code'] == 0 and not r['cancelled'] and r['same_full_rows'] and r['correct_names'] for r in samples)
    assert all(r['class_fork_cow'] and r['frozen_core_fields'] == (r['arm'] == 'engine') for r in samples)
    pairs = []
    measured = [r for r in samples if not r['warmup']]
    for block in sorted({r['block'] for r in measured}):
        arms = {r['arm']: r for r in measured if r['block'] == block}
        before, after = arms['before'], arms['engine']
        assert before['rows'] == after['rows'] == 4398
        pairs.append(dict(block=block, before_seconds=before['seconds'], after_seconds=after['seconds'],
                          seconds=before['seconds'] - after['seconds'],
                          engine_cpu=before['engine_cpu'] - after['engine_cpu'],
                          allocated_bytes=before['heap_delta']['TotalAlloc'] - after['heap_delta']['TotalAlloc']))
    result[workload] = dict(medians=json.loads((d / 'summary.json').read_text()), pairs=pairs,
                            faster_pairs=sum(r['seconds'] > 0 for r in pairs),
                            lower_cpu_pairs=sum(r['engine_cpu'] > 0 for r in pairs),
                            lower_alloc_pairs=sum(r['allocated_bytes'] > 0 for r in pairs),
                            median_paired_seconds=statistics.median(r['seconds'] for r in pairs),
                            median_paired_allocated_bytes=statistics.median(r['allocated_bytes'] for r in pairs),
                            all_commands_correct=True, timed_invocations=len(samples),
                            max_host_cpu_pressure=max(r['pressure']['host.cpu.some'] for r in samples),
                            max_host_memory_pressure=max(r['pressure']['host.memory.some'] for r in samples),
                            max_engine_memory_pressure=max(r['pressure']['engine.memory.some'] for r in samples))
(p / 'timing-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
