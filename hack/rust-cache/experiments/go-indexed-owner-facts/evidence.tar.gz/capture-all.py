from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent
rows=[]
for arm in ['before','candidate']:
 command=['python3',str(p/'capture.py'),'--arm',arm,'--output',str(p/('capture-'+arm)),'--edit-test-body','--cpu-profile']
 tick=time.monotonic()
 with (p/('capture-'+arm+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(arm=arm,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'capture-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/('capture-'+arm+'-driver.log')).read_text()[-5000:]);raise SystemExit(r.returncode)
 print((p/('capture-'+arm)/'result.json').read_text(),flush=True)
