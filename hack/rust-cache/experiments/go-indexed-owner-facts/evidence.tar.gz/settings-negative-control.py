from pathlib import Path
import json,subprocess
p=Path(__file__).parent;source=Path('/tmp/dagger-go-indexed-owner-facts/go.dang');original=source.read_bytes()
needle=b'tool.goModuleAt(root ?? path, mountPath, owner.prefix, owner.skipTest)'
assert original.count(needle)==1
bad=original.replace(needle,b'Go(version: "1.26.1").goModuleAt(root ?? path, mountPath, owner.prefix, owner.skipTest)')
(p/'negative-owner-default-settings.dang').write_bytes(bad)
try:
 source.write_bytes(bad)
 with (p/'settings-negative-driver.log').open('w') as out:r=subprocess.run(['python3',str(p/'verify-settings-negative.py')],stdout=out,stderr=subprocess.STDOUT)
 log=(p/'go-dev-package-owner-settings-check-negative.log').read_text()
 assert r.returncode!=0,'negative control unexpectedly passed'
 assert 'build constraints exclude all Go files' in log or 'no Go files' in log,log[-4000:]
 result=dict(expected_failure=True,exit_code=r.returncode,reason='Constructing the owner with default settings loses the selected build tag; the real test execution rejects the package.')
finally:
 source.write_bytes(original)
 assert source.read_bytes()==original
result['main_source_restored']=True
(p/'settings-negative-control.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
