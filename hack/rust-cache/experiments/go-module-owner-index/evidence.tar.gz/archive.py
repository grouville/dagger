from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
p=Path(__file__).parent
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-module-owner-index')
out.mkdir(parents=True,exist_ok=False)
with (p/'baseline-module.tar').open('wb') as f:subprocess.run(['git','archive','--format=tar','a3d0e4bf562b834c31135bff24e5931fd32b3acc'],cwd='/tmp/dagger-go-snapshot-test-directories',stdout=f,check=True)
for arm in ['before','candidate']:
 d=p/('capture-'+arm);chunks=sorted(d.glob('chunk-*.ndjson.gz'));events=[]
 for f in chunks:
  lines=gzip.decompress(f.read_bytes()).splitlines();header=json.loads(lines[0]);events.extend(lines[1:]);assert header['dropped_events']==0
 complete=(json.dumps(dict(header,event_count=len(events)))+'\n').encode()+b'\n'.join(events)+b'\n'
 assert complete==(d/'wcprof-complete.ndjson').read_bytes()
 assert not header.get('open_ops')
files=[f for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.name not in ['wcprof-complete.ndjson','baseline-module.tar']]
files.append(p/'baseline-module.tar')
manifest=[dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in files]
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(p)));info.mtime=0
  with f.open('rb') as source:tar.addfile(info,source)
 info=tarfile.TarInfo('manifest.json');info.size=len(manifest_bytes);info.mtime=0;tar.addfile(info,io.BytesIO(manifest_bytes))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  payload=tar.extractfile(row['path']).read();assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
 assert tar.extractfile('manifest.json').read()==manifest_bytes
(out/'manifest.json').write_bytes(manifest_bytes)
for name in ['assessment.json','final-state.json','source-references.json']: (out/name).write_bytes((p/name).read_bytes())
metadata=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files)+1,all_member_hashes_verified=True,both_wcprof_streams_reconstructed_losslessly=True)
(out/'archive.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata),flush=True)
