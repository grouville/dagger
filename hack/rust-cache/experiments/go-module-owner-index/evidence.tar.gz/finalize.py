from pathlib import Path
import hashlib,json,subprocess,urllib.request
p=Path(__file__).parent;base=p.parent;previous=base/'dang-shared-receiver-decode'
def get(route):
 with urllib.request.urlopen('http://127.0.0.1:16108/debug/'+route,timeout=15) as f:return json.load(f)
state=get('client-lifecycle');assert state['active_requests']==0 and not state.get('sessions')
plan=json.loads((previous/'engine-plan.json').read_text());flags={r:get(r)['enabled'] for r in plan['flags']};assert flags==plan['flags']
assert not get('prepared-schema')['enabled'];assert not get('wcprof/enabled')['global_enabled'];assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
activation=json.loads((previous/'activation.json').read_text());binaries={activation['engine']:activation['sha256'],**activation['retained_engines']}
for name,expected in binaries.items():
 actual=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==expected
for workload in ['test','source']:
 restoration=json.loads((p/(workload+'-edit-paired/restoration.json')).read_text());assert restoration['source_restored'] and restoration['test_restored'] and restoration['config_restored']
 samples=json.loads((p/(workload+'-edit-paired/samples.json')).read_text());assert len(samples)==12 and all(r['exit_code']==0 and not r['cancelled'] and r['correct_names'] and r['same_full_rows'] for r in samples)
for name in ['before','candidate']:
 d=p/('capture-'+name);r=json.loads((d/'result.json').read_text());assert r['exit_code']==0 and r['same_names'] and not r['cancelled'] and r['recorder']['dropped']==0 and r['recorder']['open']==0
 r=json.loads((d/'restoration.json').read_text());assert r['source_restored'] and r['test_restored'] and r['config_restored']
checks=json.loads((p/'checks.json').read_text())+json.loads((p/'owner-checks.json').read_text());assert len(checks)==8 and all(r['exit_code']==0 for r in checks)
identity={}
for name,path in [('baseline',Path('/tmp/dagger-go-snapshot-test-directories')),('candidate',Path('/tmp/dagger-go-module-owner-index')),('rust',Path('/tmp/dagger-rust-test-collection-granularity')),('repository',Path('/tmp/dagger-go-real-repository-main'))]:
 identity[name]=dict(path=str(path),commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=path,text=True).splitlines())
 if name!='candidate':assert not identity[name]['status']
assert identity['baseline']['commit']=='a3d0e4bf562b834c31135bff24e5931fd32b3acc'
assert identity['candidate']['status']==[' M .dagger/modules/go-dev/main.dang',' M go.dang']
for name in ['go.dang','.dagger/modules/go-dev/main.dang']:
 data=(Path('/tmp/dagger-go-module-owner-index')/name).read_bytes();assert data==(p/'candidate-source'/name).read_bytes()
(p/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(p/'final-state.json').write_text(json.dumps(dict(binaries=binaries,flags=flags,lifecycle=state,wcprof=get('wcprof/enabled'),lock_profiler=get('lock-profiler'),validation_cases=8,complete_correct_timing_commands=24,candidate_selected=False,cold_performance_unmeasured=True,rust_latency_gain_unmeasured=True,engine_cache_retained=True),indent=2)+'\n')
print(json.dumps(dict(flags_restored=True,retained_engines_unchanged=True,active_requests=state['active_requests'],validation_cases=8,complete_correct_timing_commands=24,candidate_selected=False)),flush=True)
