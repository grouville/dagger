from pathlib import Path
import json
import subprocess
import time

p = Path(__file__).parent
module = p.parent/'go-workspace-package-test-search'
assert json.loads((p/'comparison-exit.json').read_text())['exit_code'] == 0
steps = [
    ('finish', ['python3',str(p/'finish.py')]),
    ('archive', ['python3',str(p/'archive.py')]),
    ('prepare-go-module', ['python3',str(module/'prepare.py')]),
    ('check-go-module', ['python3',str(module/'verify.py')]),
]
rows=[]
for label,command in steps:
    started=time.monotonic()
    with (p/(label+'-driver.log')).open('w') as output:
        result=subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,seconds=time.monotonic()-started,exit_code=result.returncode)
    rows.append(row)
    (p/'continuation-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(row,flush=True)
    assert result.returncode==0, (p/(label+'-driver.log')).read_text()[-5000:]
    if label=='finish':
        state=json.loads((p/'STATUS.json').read_text())
        selected=json.loads((p/'selected-state.json').read_text())
        state.update(status='complete-selected' if selected['span_row_sharing'] else 'complete-unselected',full_command_measured=True,selected=selected['span_row_sharing'],summary=selected['latest_matched_cohort'])
        (p/'STATUS.json').write_text(json.dumps(state,indent=2)+'\n')
print('Completed telemetry decision and next Go-module checks.',flush=True)
