from collections import Counter
from pathlib import Path
import json

p = Path(__file__).parent


def summarize(path):
    counts = Counter()
    parents = {}
    classes = {}
    publications = []
    interesting = []
    with path.open() as stream:
        header = json.loads(next(stream))
        names = header['strings']
        for line in stream:
            event = json.loads(line)
            if event.get('e') != 'op':
                continue
            cls = names[event['c']]
            kind = event['k']
            counts[(kind, cls)] += 1
            parents[event['id']] = event.get('p', 0)
            classes[event['id']] = (kind, cls)
            if cls == 'dagql.publishResult':
                publications.append(event.get('p', 0))
            if cls in ['session.serveQuery', 'Artifacts.items', 'go:Go.packages', 'go:GoPackage.tests']:
                interesting.append(dict(event, cls=cls))
    by_field = Counter()
    for parent in publications:
        while parent and parent in classes:
            kind, cls = classes[parent]
            if kind in ['call', 'call_exec']:
                by_field[cls] += 1
                break
            parent = parents.get(parent, 0)
    main = max((e for e in interesting if e['cls'] == 'session.serveQuery'), key=lambda e: e['d']-e['s'])
    fields = ['Workspace.glob', 'Workspace.findRoots', 'String.glob', 'gomod:GomodGoMod.ownFiles',
              'SearchResult.search', 'SearchResult.filePath', 'SearchResult.matchedLines',
              'Artifact.items', 'ArtifactDimensionKey.dimensionKeys',
              'ArtifactDimensionKey.dimension', 'ArtifactDimensionKey.key']
    return dict(header={k: v for k, v in header.items() if k != 'strings'}, main_query=main,
                publications=len(publications), publications_by_field=dict(by_field),
                fields={f: {kind: counts[(kind, f)] for kind in ['call', 'call_exec']} for f in fields},
                longest_intervals={cls: sorted([
                    dict(id=e['id'], seconds=(e['d']-e['s'])/1e9)
                    for e in interesting if e['cls'] == cls
                ], key=lambda e: e['seconds'], reverse=True)[:4]
                    for cls in ['Artifacts.items', 'go:Go.packages', 'go:GoPackage.tests']})


import os
import subprocess

current = summarize(p/'preflight/wcprof-complete.ndjson')
(p/'profile-derived.json').write_text(json.dumps(current, indent=2)+'\n')
assert not current['header']['dropped_events'] and not current['header'].get('open_ops')
assert current['fields']['Artifact.items']['call'] == 4398
root = current['main_query']['id']
report = '/tmp/rust-cache-wcprof-report-current'
commands = [
    ('critical-path', [report, '-view', 'critpath', '-op', str(root), '-depth', '9', '-top', '35', '-limit', '190', str(p/'preflight/wcprof-complete.ndjson')]),
    ('classes', [report, '-view', 'classes', '-top', '45', '-limit', '75', str(p/'preflight/wcprof-complete.ndjson')]),
]
windows=json.loads((p/'preflight/engine-cpu-windows.json').read_text())
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
profiles=[str(p/'preflight'/row['path']) for row in windows]
for label, flags in [('cpu-cumulative', ['-cum']), ('cpu-flat', [])]:
    commands.append((label, [go,'tool','pprof','-top','-nodecount=45',*flags,str(p/'dagger-engine'),*profiles]))
rows=[]
for label, command in commands:
    with (p/(label+'.log')).open('w') as output:
        result=subprocess.run(command, env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off'), stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode))
    (p/'profile-analysis.json').write_text(json.dumps(rows, indent=2)+'\n')
    assert result.returncode==0, label
print(json.dumps(dict(main_query_seconds=(current['main_query']['d']-current['main_query']['s'])/1e9,publications=current['publications'],reports=[r['label'] for r in rows]),indent=2),flush=True)
