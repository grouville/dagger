from pathlib import Path
import json
import os
import subprocess
import time

p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
base=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod']
rows=[]
for label,overlay,pattern,expected,race in [
 ('before-regression','before-test-overlay.json','^TestSpanRowSharingEncodesOncePerRoute$',1,False),
 ('after-race','after-test-overlay.json','^Test(SpanRowSharing|TelemetryRoutesClientsAndAncestorsExactlyOnce|SessionSpanExporter|TelemetryExport|TelemetryStream|TracesHandlerToleratesMissingResource|CallPayloadWriteOwnershipAndRelease)',0,True),
]:
 command=base+['-overlay',str(p/overlay),'-count=1','-v','-run',pattern]
 if race:command+=['-race']
 command+=['./engine/server']
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as output:
  result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=output,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=result.returncode,expected_exit_code=expected)
 rows.append(row)
 (p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 assert result.returncode==expected,(p/(label+'.log')).read_text()[-4000:]
 if expected:assert 'serialize once for all four destinations' in (p/(label+'.log')).read_text()
result=subprocess.run(['python3',str(p/'benchmark_open.py')],env=env)
raise SystemExit(result.returncode)
