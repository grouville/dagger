from collections import Counter
from pathlib import Path
import json

p = Path(__file__).parent
captures = {'before': p.parent / 'go-query-phase-detail/capture', 'after': p / 'capture'}
counts = {}
headers = {}
for arm, capture in captures.items():
    values = Counter()
    with (capture / 'wcprof-complete.ndjson').open() as stream:
        header = json.loads(next(stream))
        assert header['dropped_events'] == 0 and not header.get('open_ops')
        for line in stream:
            event = json.loads(line)
            if event['e'] == 'op':
                values[header['strings'][event['c']]] += 1
    counts[arm] = values
    headers[arm] = dict(events=header['event_count'], dropped=header['dropped_events'])
causal = {arm: json.loads((capture / 'causal-requests.json').read_text()) for arm, capture in captures.items()}
classes = ['Host.directory', 'Workspace.file', 'Workspace.directory', 'Directory.file',
           'gomod:Query.gomod', 'gomod:Gomod.modules', 'dang.apiRequest', 'Query.typeDef']
result = dict(
    scope='Lossless operation counts only. Before is the selected-module capture on engine 7f821dcf; after uses engine 5be8cc29 with all unselected controls off. Not a matched latency comparison.',
    result=json.loads((p / 'capture/result.json').read_text()),
    operation_counts={name: {arm: counts[arm][name] for arm in captures} for name in classes},
    recorder=headers,
    exact_parent_links_valid=all(value['matched'] == value['counts']['api'] and not value['unmatched'] for value in causal.values()),
    all_after_operation_counts=dict(counts['after']))
(p / 'work-reduction.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(operation_counts=result['operation_counts'], result=result['result']), indent=2))
