from pathlib import Path
import json
import subprocess
import time

p = Path(__file__).parent
rows = []
for label, command in [
    ('causal-analysis', ['python3', str(p / 'analyze-synced.py')]),
    ('work-counts', ['python3', str(p / 'analyze-work-synced.py')]),
    ('whole-command', ['python3', str(p / 'measure-synced.py'), '--output',
                        str(p / 'paired-synced'), '--pairs', '5', '--languages', 'go']),
    ('retained-native', ['python3', str(p.parent / 'trivial-scalar-projection/verify_retained_first.py'),
                         'go-module-marker-snapshot-after']),
]:
    if label == 'whole-command':
        work = json.loads((p / 'work-reduction-synced.json').read_text())
        assert work['result']['exit_code'] == 0 and work['result']['same_rows']
        assert work['exact_parent_links_valid']
        assert work['operation_counts']['Host.directory']['after'] < work['operation_counts']['Host.directory']['before']
    begin = time.monotonic()
    with (p / (label + '-driver.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - begin))
    (p / 'pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '-driver.log')).read_text()[-5000:]
