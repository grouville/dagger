from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
module = Path('/tmp/dagger-go-module-marker-snapshot')
target = module / 'gomod/main.dang'
candidate = target.read_bytes()
(p / 'after-main-unformatted.dang').write_bytes((p / 'after-main.dang').read_bytes())
(p / 'after-main.dang').write_bytes(candidate)
(p / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', 'gomod/main.dang', 'gomod/.dagger/modules/e2e/main.dang'], cwd=module))
env = dict(os.environ, RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16276',
    RUST_CACHE_BENCH_CLI=str(p.parent / 'filesync-literal-pathwalk/dagger-after'),
    RUST_CACHE_BENCH_COLLECTOR='http://' + (p.parent / 'otlp-null-address.txt').read_text().strip() + ':43184',
    _EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows = []
try:
    for arm, source in [('before', p / 'before-main.dang'), ('after', p / 'after-main.dang')]:
        target.write_bytes(source.read_bytes())
        start = time.monotonic()
        with (p / ('marker-semantics-' + arm + '.log')).open('w') as output:
            result = subprocess.run(['python3', str(p.parent / 'local_cli_collector.py'),
                'check', 'gomod-checks:marker-snapshot-check'], cwd=module, env=env,
                stdout=output, stderr=subprocess.STDOUT)
        rows.append(dict(arm=arm, exit_code=result.returncode, seconds=time.monotonic() - start,
                         sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
        (p / 'format-and-semantics.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(rows[-1], flush=True)
        assert result.returncode == 0
finally:
    target.write_bytes(candidate)
    assert target.read_bytes() == (p / 'after-main.dang').read_bytes()
