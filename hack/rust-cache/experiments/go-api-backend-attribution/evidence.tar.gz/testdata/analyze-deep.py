from pathlib import Path
import json
import os
import subprocess

p=Path(__file__).parent/'deep-candidate'
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
engine='/tmp/rust-cache-sipsma-review/workspace-search-overlay-paths/dagger-engine'
cli='/tmp/rust-cache-sipsma-review/filesync-literal-pathwalk/dagger-after'
result=json.loads((p/'result.json').read_text());assert result['exit_code']==0 and result['same_rows'] and not result['errors']
windows=json.loads((p/'engine-cpu-windows.json').read_text())
cli_windows=json.loads((p/'cli-allocation-windows.json').read_text())['windows']
commands=[]
for label,flags,profiles,binary in [
 ('engine-cpu-flat',[],[str(p/r['path']) for r in windows],engine),
 ('engine-cpu-cumulative',['-cum'],[str(p/r['path']) for r in windows],engine),
 ('engine-alloc-flat',['-sample_index=alloc_space','-base',str(p/'engine-allocs-before.pprof')],[str(p/'engine-allocs-after.pprof')],engine),
 ('engine-alloc-cumulative',['-cum','-sample_index=alloc_space','-base',str(p/'engine-allocs-before.pprof')],[str(p/'engine-allocs-after.pprof')],engine),
 ('engine-mutex',['-cum','-sample_index=delay','-base',str(p/'engine-mutex-before.pprof')],[str(p/'engine-mutex-after.pprof')],engine),
 ('engine-block',['-cum','-sample_index=delay','-base',str(p/'engine-block-before.pprof')],[str(p/'engine-block-after.pprof')],engine),
 ('cli-alloc-flat',['-sample_index=alloc_space'],[str(p/r['path']) for r in cli_windows],cli),
 ('cli-alloc-cumulative',['-cum','-sample_index=alloc_space'],[str(p/r['path']) for r in cli_windows],cli),
 ]:
 commands.append((label,[go,'tool','pprof','-top','-nodecount=45',*flags,binary,*profiles]))
rows=[]
for label,command in commands:
 with (p/(label+'.log')).open('w') as output:
  r=subprocess.run(command,env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off'),stdout=output,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,command=command,exit_code=r.returncode));(p/'analysis-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.returncode==0, (p/(label+'.log')).read_text()[-3000:]
print('PASS: CPU, allocation, mutex and block profiles decoded.',flush=True)
