from pathlib import Path
from collections import Counter,defaultdict
from bisect import bisect_left,bisect_right
import json

p=Path(__file__).parent
source=Path('/tmp/rust-cache-sipsma-review/go-workspace-package-test-search/profile-after/wcprof-complete.ndjson')
ops={};links=defaultdict(list)
with source.open() as f:
 header=json.loads(next(f));names=header['strings']
 for line in f:
  e=json.loads(line)
  if e['e']=='op':
   e['cls']=names[e['c']];ops[e['id']]=e
  elif e.get('lk')=='nested_client':links[e['p']].append(e)
by_client=defaultdict(list)
for e in ops.values():
 if e['cls']=='session.serveQuery':by_client[e.get('cl',0)].append(e)
for items in by_client.values():items.sort(key=lambda e:e['s'])
starts={client:[e['s'] for e in items] for client,items in by_client.items()}
counts=Counter();matches=[];problems=[]
for api in (e for e in ops.values() if e['cls']=='dang.apiRequest'):
 parent=api.get('p');seen=set()
 while parent and parent not in links and parent in ops and parent not in seen:
  seen.add(parent);parent=ops[parent].get('p')
 if parent not in links:
  counts['no_client_link']+=1;problems.append(dict(api=api['id'],reason='no-client-link'));continue
 client_links=links[parent]
 candidates=[]
 for link in client_links:
  client=link['i'];items=by_client.get(client,[]);begin=bisect_left(starts.get(client,[]),api['s']);end=bisect_right(starts.get(client,[]),api['d'])
  candidates.extend(q for q in items[begin:end] if q['d']<=api['d'])
 if len(candidates)!=1:
  counts['zero_queries' if not candidates else 'ambiguous_queries']+=1
  problems.append(dict(api=api['id'],seconds=(api['d']-api['s'])/1e9,reason='query-count',candidate_ids=[q['id'] for q in candidates],link_count=len(client_links)));continue
 q=candidates[0];counts['unique']+=1
 matches.append(dict(api_id=api['id'],api_parent=api.get('p'),api_start_ns=api['s'],api_end_ns=api['d'],api_seconds=(api['d']-api['s'])/1e9,serve_id=q['id'],serve_seconds=(q['d']-q['s'])/1e9,pre_serve_seconds=(q['s']-api['s'])/1e9,post_serve_seconds=(api['d']-q['d'])/1e9))
result=dict(scope='Offline temporal correlation using the recorded invocation-to-client link and fully-contained serveQuery intervals. This is inference, not a new causal profiling edge. Ambiguous matches are retained and excluded.',source=str(source),counts=dict(counts),unique_server_ids=len({m['serve_id'] for m in matches}),matches=matches,problems=problems)
(p/'correlation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(counts=dict(counts),unique_server_ids=result['unique_server_ids'],longest=sorted(matches,key=lambda m:m['api_seconds'],reverse=True)[:14],problem_examples=problems[:3]),indent=2))
