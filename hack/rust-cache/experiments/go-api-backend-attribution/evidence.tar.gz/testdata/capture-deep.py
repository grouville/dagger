from pathlib import Path
import gzip,hashlib,json,os,signal,socket,subprocess,threading,time,urllib.request
protocol=Path('/tmp/rust-cache-sipsma-review/rust-go-test-collections/measure.py')
exec(protocol.read_text().split('fixtures = [f for f')[0])
cli=base/'filesync-literal-pathwalk/dagger-after'
arm=os.environ.get('GO_WORKSPACE_SEARCH_ARM','after')
assert arm in ['before','after']
workspace=Path('/tmp/dagger-go-real-repository-main');module=Path('/tmp/dagger-go-module-test-name-index' if arm=='before' else '/tmp/dagger-go-workspace-package-test-search')
source=workspace/'dagql/types.go';original=source.read_bytes()
configs={name:(workspace/name).read_bytes() if (workspace/name).exists() else None for name in ['dagger.toml','dagger.lock']}
routes=['batch-metadata','attribute-array-decode','reusable-declarations','span-lookup-fanout','usage-sampling','builtin-receivers','config-declarations','trivial-scalar-fields','direct-span-protobuf','span-resource-batches','lazy-type-maps','telemetry-flush-coalescing','callback-caller-reuse','otel-evicted-queue','single-toml-parse','parallel-client-admission','prepared-schema','restored-posting-removal','scalar-list-projection','upstream-leaf-arrays','native-search-projection','restored-data-list-projection','span-row-sharing']
flags={route:get(route)['enabled'] for route in routes}
env['_EXPERIMENTAL_DAGGER_VERSION']='v1.0.0-beta.15'
for name in ['CPUPROFILE','PPROF']:env.pop(name,None)
def raw(route,timeout=30):
 with urllib.request.urlopen(debug+route,timeout=timeout) as response:return response.read()
stop=threading.Event();windows=[];errors=[];thread=None
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
idle('deep-api-allocation-profile')
metadata=dict(scope='One diagnostic edited Go collection listing with wcprof, engine CPU windows, engine allocation/mutex/block deltas and CLI allocation windows. Not a timing comparison. Same native cache, ordinary GC and telemetry. No runtime trace or forced GC. The higher-memory native workspace-search prototype is used only for attribution.',arm=arm,module=str(module),engine_sha256=subprocess.check_output(['docker','exec',record['Id'],'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0],cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),warm_engine=True,fresh_cli=True,fresh_source_edit=True,ordinary_gc=True,telemetry=True,flags_before=flags)
cli_windows=[];cli_tail=[]
with socket.socket() as probe:
 probe.bind(('127.0.0.1',0));cli_port=probe.getsockname()[1]
cli_debug=f'http://127.0.0.1:{cli_port}/debug/'
env['PPROF']=f'127.0.0.1:{cli_port}'
metadata['cli_pprof_port']=cli_port
cli_thread=None
(root/'driver.py').write_bytes(Path(__file__).read_bytes())
try:
 for route in routes:mode(route,route in ['batch-metadata','attribute-array-decode','reusable-declarations','span-lookup-fanout','usage-sampling','builtin-receivers','config-declarations','trivial-scalar-fields','scalar-list-projection','restored-posting-removal'])
 get('span-lookup-fanout?record=false',b'');get('builtin-receivers?enabled=true&record=false',b'');get('config-declarations?enabled=true&record=false',b'')
 assert get('collection-expansion-limit')['limit']==0
 get('span-row-sharing?record=false',b'');get('span-resource-batches?record=false',b'')
 metadata['flags_during']={route:get(route)['enabled'] for route in routes}
 (root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
 source.write_bytes(original+f'\n// Shared span row profile {time.time_ns()}\n'.encode())
 (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n')
 get('lock-profiler?enabled=true',b'')
 for kind in ['allocs','mutex','block']:(root/('engine-'+kind+'-before.pprof')).write_bytes(raw('pprof/'+kind))
 gc_before=get('snapshot-collection')
 get('wcprof/enabled',b'on');raw('wcprof/dump')
 tick=time.monotonic();before=heap();before_cpu=cpu();before_pressure=pressure()
 def sample_cpu():
  index=0
  while not stop.is_set():
   begin=time.monotonic()
   try:
    payload=raw('pprof/profile?seconds=5',20)
    filename=f'engine-cpu-{index:03d}.pprof';(root/filename).write_bytes(payload)
    windows.append(dict(path=filename,start_seconds=begin-tick,end_seconds=time.monotonic()-tick,bytes=len(payload)))
   except Exception as error:
    errors.append(str(error));break
   index+=1
 def sample_cli_allocs():
  deadline=time.monotonic()+15
  while not stop.is_set():
   try:
    with urllib.request.urlopen(cli_debug+'pprof/allocs?seconds=3',timeout=8) as response:payload=response.read()
    end=time.monotonic();filename=f'cli-allocs-{len(cli_windows):03d}.pprof';(root/filename).write_bytes(payload)
    cli_windows.append(dict(path=filename,end_seconds=end-tick,bytes=len(payload),interval_seconds=3))
    deadline=end+8
   except Exception as error:
    if stop.is_set():
     cli_tail.append(dict(seconds=time.monotonic()-tick,error=type(error).__name__,expected='CLI process has exited; final incomplete allocation window is not used.'));break
    if time.monotonic()>deadline:
     errors.append('CLI allocation endpoint unavailable: '+type(error).__name__);break
    stop.wait(.05)
 thread=threading.Thread(target=sample_cpu);thread.start()
 cli_thread=threading.Thread(target=sample_cli_allocs);cli_thread.start()
 command=[str(cli),'check','--module','go','--check','test','--list','--all']
 timed=['/usr/bin/time','-f','{"user_seconds":%U,"system_seconds":%S,"max_rss_kib":%M}','-o',str(root/'cli-resources.json'),'--',*command]
 with (root/'command.stdout').open('w') as out,(root/'command.stderr').open('w') as err:
  process=subprocess.Popen(timed,cwd=workspace,env=env,stdout=out,stderr=err,start_new_session=True)
  cancelled=False
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait()
 elapsed=time.monotonic()-tick;after=heap();after_cpu=cpu();after_pressure=pressure()
finally:
 stop.set()
 if thread is not None:thread.join()
 if cli_thread is not None:cli_thread.join()
 get('wcprof/enabled',b'off')
 get('lock-profiler?enabled=false',b'')
 for kind in ['allocs','mutex','block']:(root/('engine-'+kind+'-after.pprof')).write_bytes(raw('pprof/'+kind))
 gc_after=get('snapshot-collection')
 source.write_bytes(original)
 for name,data in configs.items():
  if data is None:(workspace/name).unlink(missing_ok=True)
  else:(workspace/name).write_bytes(data)
 for route,enabled in flags.items():mode(route,enabled)
(root/'engine-cpu-windows.json').write_text(json.dumps(windows,indent=2)+'\n')
(root/'cli-allocation-windows.json').write_text(json.dumps(dict(windows=cli_windows,tail=cli_tail),indent=2)+'\n')
(root/'collection-state.json').write_text(json.dumps(dict(before=gc_before,after=gc_after),indent=2)+'\n')
headers=[];events=[];deadline=time.monotonic()+120
while True:
 payload=raw('wcprof/dump',45)
 (root/f'wcprof-{len(headers)}.ndjson.gz').write_bytes(gzip.compress(payload,mtime=0))
 lines=payload.splitlines();header=json.loads(lines[0]);headers.append(header);events.extend(lines[1:])
 if not header.get('open_ops'):break
 assert time.monotonic()<deadline,'open wcprof operations did not finish'
 time.sleep(1)
header=dict(headers[-1]);header['event_count']=len(events)
(root/'wcprof-complete.ndjson').write_bytes((json.dumps(header)+'\n').encode()+b'\n'.join(events)+b'\n')
listed=[line for line in (root/'command.stdout').read_text().splitlines() if line.startswith('go ')]
expected=[line for line in (base/'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
span_rows=get('span-row-sharing');stored_rows=get('span-resource-batches')
get('span-row-sharing?record=false',b'');get('span-resource-batches?record=false',b'')
result=dict(span_row_sharing=span_rows,span_destination_writes=stored_rows,seconds=elapsed,exit_code=code,cancelled=cancelled,rows=len(listed),same_rows=listed==expected,engine_cpu=after_cpu-before_cpu,heap_delta={k:after[k]-before[k] for k in before},pressure={k:(after_pressure[k]-before_pressure[k])/(elapsed*1e6) for k in before_pressure},cli_resources=json.loads((root/'cli-resources.json').read_text().splitlines()[-1]),cpu_windows=len(windows),errors=errors,recorder=dict(events=len(events),dropped=header['dropped_events'],open=len(header.get('open_ops',[]))),source_restored=source.read_bytes()==original)
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
assert code==0 and not cancelled and listed==expected and len(listed)==4398
assert header['dropped_events']==0 and not header.get('open_ops')
assert not errors
assert len(cli_windows)>=5
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)

assert not get('span-row-sharing')['enabled']
