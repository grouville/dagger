from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[];steps=[]
def run(label,command,cwd,network=False):
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=cwd,env=(dict(env,GOPROXY="https://proxy.golang.org",GOSUMDB="sum.golang.org") if network else env),stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,cwd=cwd,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'fixed-baseline-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True);assert not r.returncode,(p/(label+'.log')).read_text()[-3000:]
 return (p/(label+'.log')).read_text()
run('standalone-history-fix-race',[go,'test','-p=2','-race','-count=1','-run=^TestClassForkHistoryIsolation$','./dagql'],'/tmp/dagger-class-fork-history-isolation',network=True)
for block in range(4):
 for arm in (['after','before'] if block%2==0 else ['before','after']):
  command=[go,'test','-p=2']+(['-overlay='+str(p/'fixed-baseline-overlay.json')] if arm=='before' else [])+['-run=^$','-bench=^BenchmarkClassForkStorage$','-benchmem','-benchtime=100ms','-count=1','./dagql'];log=run(f'fixed-bench-{block}-{arm}',command,'/tmp/dagger-class-fork-copy-on-write')
  cases=[dict(fields=int(n),mutate=mutate=='true',ns=float(ns),bytes=int(bs),allocs=int(al)) for n,mutate,ns,bs,al in re.findall(r'BenchmarkClassForkStorage/fields(\d+)/mutate(true|false)-\d+\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',log)];assert len(cases)==6;rows.append(dict(block=block,arm=arm,cases=cases));(p/'fixed-component-pairs.json').write_text(json.dumps(rows,indent=2)+'\n')
summary={}
for fields in [1,16,128]:
 for mutate in [False,True]:
  key=f'{fields}-mutate{mutate}';summary[key]={arm:{k:statistics.median(c[k] for r in rows if r['arm']==arm for c in r['cases'] if c['fields']==fields and c['mutate']==mutate) for k in ['ns','bytes','allocs']} for arm in ['before','after']}
  summary[key]['faster_pairs']=sum(next(c['ns'] for r in rows if r['block']==block and r['arm']=='after' for c in r['cases'] if c['fields']==fields and c['mutate']==mutate)<next(c['ns'] for r in rows if r['block']==block and r['arm']=='before' for c in r['cases'] if c['fields']==fields and c['mutate']==mutate) for block in range(4))
(p/'fixed-component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
