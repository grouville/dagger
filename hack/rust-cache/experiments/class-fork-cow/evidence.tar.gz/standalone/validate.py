from pathlib import Path
import json,os,re,statistics,subprocess,time
p=Path(__file__).parent;repo='/tmp/dagger-class-fork-copy-on-write';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');steps=[];rows=[]
def run(label,command,expected=0):
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 record=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode,expected_exit_code=expected);steps.append(record);(p/'validation-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(record),flush=True)
 assert r.returncode==expected,(label,(p/(label+'.log')).read_text()[-3500:])
 return (p/(label+'.log')).read_text()
run('baseline-compatibility',[go,'test','-p=2','-overlay='+str(p/'before-overlay.json'),'-count=1','-run=^TestClass(ForkStorage|FieldDeclarationOrder)','./dagql'])
run('baseline-history-negative',[go,'test','-p=2','-overlay='+str(p/'before-overlay.json'),'-count=1','-run=^TestClassForkHistoryIsolation$','./dagql'],expected=1)
run('full-race',[go,'test','-p=2','-race','-count=1','./dagql'])
for block in range(4):
 for arm in (['after','before'] if block%2==0 else ['before','after']):
  command=[go,'test','-p=2']+(['-overlay='+str(p/'before-overlay.json')] if arm=='before' else [])+['-run=^$','-bench=^BenchmarkClassForkStorage$','-benchmem','-benchtime=100ms','-count=1','./dagql'];log=run(f'bench-{block}-{arm}',command)
  cases=[dict(fields=int(n),mutate=mutate=='true',ns=float(ns),bytes=int(bs),allocs=int(al)) for n,mutate,ns,bs,al in re.findall(r'BenchmarkClassForkStorage/fields(\d+)/mutate(true|false)-\d+\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',log)];assert len(cases)==6
  rows.append(dict(block=block,arm=arm,cases=cases));(p/'component-pairs.json').write_text(json.dumps(rows,indent=2)+'\n')
summary={}
for fields in [1,16,128]:
 for mutate in [False,True]:
  key=f'{fields}-mutate{mutate}';summary[key]={arm:{k:statistics.median(c[k] for r in rows if r['arm']==arm for c in r['cases'] if c['fields']==fields and c['mutate']==mutate) for k in ['ns','bytes','allocs']} for arm in ['before','after']}
  summary[key]['faster_pairs']=sum(next(c['ns'] for r in rows if r['block']==block and r['arm']=='after' for c in r['cases'] if c['fields']==fields and c['mutate']==mutate)<next(c['ns'] for r in rows if r['block']==block and r['arm']=='before' for c in r['cases'] if c['fields']==fields and c['mutate']==mutate) for block in range(4))
(p/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
