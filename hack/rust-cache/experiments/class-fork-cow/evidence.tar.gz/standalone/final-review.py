from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;fix='/tmp/dagger-class-fork-history-isolation';repo='/tmp/dagger-class-fork-copy-on-write';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[]
def run(label,command,cwd,expected=0):
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,cwd=cwd,seconds=time.monotonic()-tick,exit_code=r.returncode,expected=expected);rows.append(row);(p/'final-review-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==expected,(p/(label+'.log')).read_text()[-3500:]
run('history-final-before',[go,'test','-p=2','-overlay='+str(p/'history-before-overlay.json'),'-count=1','-run=^TestClassForkHistoryIsolation$','./dagql'],fix,1)
assert 'TestClassForkHistoryIsolation/extend=false' in (p/'history-final-before.log').read_text() and 'TestClassForkHistoryIsolation/extend=true' in (p/'history-final-before.log').read_text()
run('history-final-after-race',[go,'test','-p=2','-race','-count=1','-run=^TestClassForkHistoryIsolation$','./dagql'],fix)
run('history-amend',['git','-c','gc.auto=0','add','dagql/class_fork_history_test.go'],fix)
run('history-commit',['git','-c','gc.auto=0','-c','commit.gpgsign=false','commit','--amend','--no-edit'],fix)
# Preserve exact measured inputs before creating the clean review stack.
Path(repo+'/dagql/objects.go').write_bytes((p/'before-objects.go').read_bytes())
source=(p/'measured-class-fork-storage-test.go').read_text();a=source.index('func TestClassForkHistoryIsolation');b=source.index('\nvar classForkStorageSink',a);Path(repo+'/dagql/class_fork_storage_test.go').write_text(source[:a]+source[b:])
run('cow-rebase',['git','-c','gc.auto=0','-c','commit.gpgsign=false','rebase','refs/remotes/perf-review/current-main'],repo)
run('cow-history-base',['git','-c','gc.auto=0','merge','--ff-only','fix/class-fork-history-isolation'],repo)
Path(repo+'/dagql/objects.go').write_bytes((p/'measured-objects.go').read_bytes())
run('cow-final-full-race',[go,'test','-p=2','-race','-count=1','./dagql'],repo)
run('cow-whitespace',['git','diff','--check'],repo)
run('cow-stage',['git','-c','gc.auto=0','add','dagql/objects.go','dagql/class_fork_storage_test.go'],repo)
run('cow-commit',['git','-c','gc.auto=0','-c','commit.gpgsign=false','commit','-m','dagql: share immutable class fields until a fork mutates'],repo)
