from pathlib import Path
import json,re
p=Path(__file__).parent;prior=p.parent/'schema-argument-engine';dest=p.parent/'class-fork-cow-engine';dest.mkdir(exist_ok=True)
old=(p/'before-objects.go').read_text();new=Path('/tmp/dagger-class-fork-copy-on-write/dagql/objects.go').read_text();overlay=json.loads((prior/'overlay.json').read_text());key='/tmp/dagger-filesync-snapshot-seeds/dagql/objects.go';active=Path(overlay['Replace'][key]).read_text();active=active.replace('"sync"','"sync"\n\t"sync/atomic"',1)
a=re.search(r'^\tfields\s+map\[string\]\[\]\*Field\[T\]',active,re.M).start();b=active.index('\n\t// server is the server',a);active=active[:a]+'\t*classFields[T]\n\tview ViewFilter\n'+active[b:]
start=new.index('// classFields is shared');end=new.index('var _ ObjectType = Class[Typed]{}',start);helper=new[start:end];active=active.replace('var _ ObjectType = Class[Typed]{}',helper+'var _ ObjectType = Class[Typed]{}',1)
# Copy changed methods only when they match the original, retaining other experiments.
def method(source,name):
 a=source.index('func (class Class[T]) '+name+'(');start=source.index('{',a);depth=0
 for i in range(start,len(source)):
  depth += (source[i]=='{')-(source[i]=='}')
  if depth==0:return source[a:i+1]
 raise AssertionError(name)
for name in ['ForkObjectType','Install','Extend','ImplementInterfaceUnchecked','Implements']:
 before=method(old,name);after=method(new,name)
 if name=='Install':
  original='			field.Spec = &newSpec'
  proof=original+'\n			// A replacement resolver does not inherit the generated accessor proof.\n			field.Spec.readData = nil'
  before=before.replace(original,proof,1);after=after.replace(original,proof,1)

 assert active.count(before)==1,name
 if name=='ForkObjectType':
  anchor='\tforked := class';fallback='''
	if !classForkCowEnabled.Load() {
		order := slices.Clone(*class.fieldOrder)
		forked.classFields = &classFields[T]{
			fields: maps.Clone(class.fields),
			fieldOrder: &order,
			interfaces: maps.Clone(class.interfaces),
		}
		forked.server = srv.self
		return forked, nil
	}
''';after=after.replace(anchor,anchor+fallback,1)
 active=active.replace(before,after,1)
# The constructor also contains a development-only PureData field.
a='\t\tfields:     map[string][]*Field[T]{},\n\t\tfieldsL:    new(sync.RWMutex),\n\t\tfieldOrder: new([]string),\n\t\tinterfaces: map[string]*Interface{},';b='\t\tclassFields: &classFields[T]{fields: map[string][]*Field[T]{}, fieldOrder: new([]string), interfaces: map[string]*Interface{}},';assert active.count(a)==1;active=active.replace(a,b)
(dest/'objects.go').write_text(active);overlay['Replace'][key]=str(dest/'objects.go');overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/dagql/class_fork_storage_test.go']='/tmp/dagger-class-fork-copy-on-write/dagql/class_fork_storage_test.go'
s=(prior/'mode.go').read_text().replace('schemaArgumentIteration','classForkCow').replace('SchemaArgumentIteration','ClassForkCow').replace('DAGGER_TEST_SCHEMA_ARGUMENT_ITERATION','DAGGER_TEST_CLASS_FORK_COW');(dest/'mode.go').write_text(s);overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/dagql/class_fork_cow_mode.go']=str(dest/'mode.go')
s=(prior/'engine-debug.go').read_text();anchor='\tm.HandleFunc("/debug/schema-argument-iteration", dagql.SchemaArgumentIterationDiagnostic)';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n\tm.HandleFunc("/debug/class-fork-cow", dagql.ClassForkCowDiagnostic)');(dest/'engine-debug.go').write_text(s);overlay['Replace']['/tmp/dagger-filesync-snapshot-seeds/cmd/engine/debug.go']=str(dest/'engine-debug.go');(dest/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
s=(prior/'build-engine.py').read_text().replace("DAGGER_TEST_SCHEMA_ARGUMENT_ITERATION='true'","DAGGER_TEST_SCHEMA_ARGUMENT_ITERATION='true',DAGGER_TEST_CLASS_FORK_COW='true'");(dest/'build-engine.py').write_text(s)
plan=json.loads((prior/'engine-plan.json').read_text());plan.update(new_engine='dagger-collection-class-fork-cow-oct19',ports=dict(engine=16293,debug=16121),candidate_route='class-fork-cow',scenario='Share immutable class field storage until a mutation; keep private state and schema generation.');plan['flags']['class-fork-cow']=False;(dest/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(prior/'start-engine.py').read_text().replace('experiments/native-glob-prefix/final-state.json','experiments/schema-argument-iteration/final-state.json').replace('codex.task=schema-argument-iteration','codex.task=class-fork-cow').replace(':16292:',':16293:').replace(':16120:',':16121:').replace(':16120/',':16121/');(dest/'start-engine.py').write_text(s)
print('engine source prepared')
