from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
steps=[('go-checks',['python3',str(p/'verify-module.py')]),('rust-checks',['python3',str(p/'verify-rust.py')]),('source-timings',['python3',str(p/'measure-source-edits.py'),'--fixture','real','--output',str(p/'source-timings'),'--pairs','4']),('test-timings',['python3',str(p/'measure-test-edits.py'),'--fixture','real','--output',str(p/'test-timings'),'--pairs','4'])]
for label,command in steps:
 tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'pipeline-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-3500:]);raise SystemExit(r.returncode)
