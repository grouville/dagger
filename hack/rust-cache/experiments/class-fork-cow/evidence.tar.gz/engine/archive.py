from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile
p=Path(__file__).parent;b=p.parent;unit=b/'class-fork-copy-on-write';root=p/'evidence-root';out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/class-fork-cow')
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def ignore(directory,names):return [n for n in names if n in {'__pycache__','.git','evidence-root','wcprof-complete.ndjson','dagger','dagger-engine','archive.log'} or n.endswith('.test')]
assert not root.exists() and not out.exists();root.mkdir();out.mkdir();streams=[]
for complete in sorted(p.glob('capture-*/wcprof-complete.ndjson')):
 events=[];chunks=sorted(complete.parent.glob('chunk-*.ndjson.gz'));assert chunks
 for chunk in chunks:
  with gzip.open(chunk,'rb') as f:header=json.loads(f.readline());events.extend(f.readlines())
  assert header['dropped_events']==0
 assert not header.get('open_ops');header['event_count']=len(events);raw=(json.dumps(header)+'\n').encode()+b''.join(events);assert raw==complete.read_bytes()
 streams.append(dict(capture=complete.parent.name,chunks=[x.name for x in chunks],events=len(events),sha256=sha(raw),exact_bytes_verified=True))
assert len(streams)==4;shutil.copytree(p,root/'engine',ignore=ignore);shutil.copytree(unit,root/'standalone',ignore=ignore);write(root/'wcprof-reconstruction.json',streams)
parents=[]
for label,name in [('engine','schema-argument-iteration'),('cli','glob-literal-suffix')]:
 parent=out.parent/name;meta=json.loads((parent/'archive.json').read_text());assert sha((parent/'evidence.tar.gz').read_bytes())==meta['sha256'];parents.append(dict(kind=label,path='../'+name+'/evidence.tar.gz',**meta))
write(root/'source-parents.json',parents)
original=json.loads((b/'schema-argument-engine/evidence-root/build-source-manifest.json').read_text());old=json.loads((b/'schema-argument-engine/overlay.json').read_text())['Replace'];new=json.loads((p/'overlay.json').read_text())['Replace'];dest=root/'engine-source-delta';dest.mkdir();changed=[];full=[]
for row in original:
 actual=Path(new.get(row['original'],row['actual']));data=actual.read_bytes();entry=dict(row,actual=str(actual),sha256=sha(data),bytes=len(data))
 if entry['sha256']!=row['sha256']:
  name=f'{len(changed):04d}-'+actual.name;(dest/name).write_bytes(data);entry.update(parent_sha256=row['sha256'],archived='engine-source-delta/'+name);changed.append(entry)
 full.append(entry)
known={r['original'] for r in original}
for key,value in new.items():
 if key in known:continue
 actual=Path(value);prior=Path(old.get(key,key))
 if prior.exists() and actual.read_bytes()==prior.read_bytes():continue
 snapshot=unit/'measured-class-fork-storage-test.go' if key.endswith('/class_fork_storage_test.go') else actual
 data=snapshot.read_bytes();name=f'{len(changed):04d}-'+actual.name;(dest/name).write_bytes(data);changed.append(dict(original=key,actual=value,archived_input=str(snapshot),bytes=len(data),sha256=sha(data),archived='engine-source-delta/'+name,additional_test_or_production_input=True))
assert len(changed)==4,len(changed);write(root/'engine-source-delta.json',changed);write(root/'build-source-manifest.json',full)
source=root/'review-source';source.mkdir()
for name in ['objects.go','class_fork_storage_test.go','class_fork_history_test.go']:(source/name).write_bytes((Path('/tmp/dagger-class-fork-copy-on-write/dagql')/name).read_bytes())
files=[f for f in sorted(root.rglob('*')) if f.is_file()];manifest=[dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files];mbytes=(json.dumps(manifest,indent=2)+'\n').encode();arc=out/'evidence.tar.gz'
with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(root)));info.mtime=0
  with f.open('rb') as stream:tar.addfile(info,stream)
 info=tarfile.TarInfo('manifest.json');info.size=len(mbytes);info.mtime=0;tar.addfile(info,io.BytesIO(mbytes))
with tarfile.open(arc,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
(out/'manifest.json').write_bytes(mbytes)
for name in ['wcprof-reconstruction.json','source-parents.json','engine-source-delta.json','build-source-manifest.json']:(out/name).write_bytes((root/name).read_bytes())
for name in ['timing-analysis.json','quiet-timing-analysis.json','allocation-attribution.json','attribution.json','final-state.json']:(out/name).write_bytes((p/name).read_bytes())
for name in ['source-identity.json','change.patch','fixed-component-summary.json']:(out/name).write_bytes((unit/name).read_bytes())
record=dict(bytes=arc.stat().st_size,sha256=sha(arc.read_bytes()),members=len(files)+1,all_member_hashes_verified=True,lossless_streams_reconstructed=len(streams),binaries_excluded=True);write(out/'archive.json',record);print(json.dumps(record),flush=True)
