from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for i,arm in enumerate(['before','candidate','candidate','before']):
 label=f'capture-{i}-{arm}';command=['python3',str(p/'capture.py'),'--arm',arm,'--module','current','--output',str(p/label),'--edit-test-body','--cpu-profile'];tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,arm=arm,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'capture-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-3500:]);raise SystemExit(r.returncode)
