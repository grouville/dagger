from pathlib import Path
import json
import os
import subprocess
import time

p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='local',GOMAXPROCS='8')
rows=[]
for label, overlay, expected in [
    ('before-race',p/'test-before-overlay.json',0),
    ('after-race',p/'test-after-overlay.json',0),
    ('missing-owned-close',p/'missing-owned-close-overlay.json',1),
]:
    pattern='^Test(SessionAttachables|AttachablesTransport)' if expected==0 else '^TestAttachablesTransportStopsDuringIncompleteHandshake$'
    command=[go,'test','-p=2','-race','-count=1','-timeout=45s','-overlay='+str(overlay),'-run='+pattern,'./engine/client']
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        result=subprocess.run(command,cwd='/tmp/dagger-filesync-literal-pathwalk',env=env,stdout=output,stderr=subprocess.STDOUT)
    row=dict(label=label,command=command,seconds=time.monotonic()-start,exit_code=result.returncode,expected_exit_code=expected)
    rows.append(row)
    (p/'validation.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==expected,(p/(label+'.log')).read_text()[-4000:]
    if expected:
        assert "Run cancellation waited for the stalled peer's handshake" in (p/(label+'.log')).read_text()
