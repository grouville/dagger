package client

import (
	"context"
	"io"
	"net"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/health/grpc_health_v1"
)

type handshakeReadConn struct {
	net.Conn
	readStarted chan struct{}
	once        sync.Once
}

func (c *handshakeReadConn) Read(p []byte) (int, error) {
	c.once.Do(func() { close(c.readStarted) })
	return c.Conn.Read(p)
}

func TestAttachablesTransportStopsDuringIncompleteHandshake(t *testing.T) {
	peer, owned := net.Pipe()
	observed := &handshakeReadConn{Conn: owned, readStarted: make(chan struct{})}
	ctx, cancel := context.WithCancel(t.Context())
	done := make(chan struct{})
	t.Cleanup(func() {
		cancel()
		_ = peer.Close()
		_ = owned.Close()
		select {
		case <-done:
		case <-time.After(time.Second):
			t.Error("session server did not stop after the connection closed")
		}
	})
	srv := NewSessionAttachablesServer(ctx, observed)
	go func() { defer close(done); srv.Run(ctx) }()
	// Accept server settings but never send the client's HTTP/2 preface.
	// This lets either transport reach its blocking handshake read.
	go func() { _, _ = io.Copy(io.Discard, peer) }()
	select {
	case <-observed.readStarted:
	case <-time.After(time.Second):
		t.Fatal("server did not start the handshake")
	}
	cancel()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("Run cancellation waited for the stalled peer's handshake")
	}
}

func TestAttachablesTransportStopsActiveCallback(t *testing.T) {
	cc, done, cancelServer := attachablesTransportPeer(t, t.Context())
	ctx, cancel := context.WithTimeout(t.Context(), 3*time.Second)
	defer cancel()
	watch, err := grpc_health_v1.NewHealthClient(cc).Watch(ctx, &grpc_health_v1.HealthCheckRequest{}, grpc.WaitForReady(true))
	require.NoError(t, err)
	_, err = watch.Recv()
	require.NoError(t, err)
	cancelServer()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("Run cancellation waited for an active callback")
	}
	_, err = watch.Recv()
	require.Error(t, err, "the active callback must end when the session closes")
}
