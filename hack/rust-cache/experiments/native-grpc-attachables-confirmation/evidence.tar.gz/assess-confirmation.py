from pathlib import Path
import datetime
import json
import statistics

p=Path(__file__).parent
cohorts=[]
all_pairs=[]
for name,count in [('paired',4),('confirmation',8)]:
    folder=p/name
    rows=json.loads((folder/'samples.json').read_text())
    assert len(rows)==2*(count+1) and all(row['exit_code']==0 and row['same_rows'] and not row['cancelled'] for row in rows)
    arms={arm:{row['pair']:row for row in rows if row['arm']==arm and row['pair']>0} for arm in ['before','after']}
    pairs=[]
    for i in range(1,count+1):
        before,after=arms['before'][i],arms['after'][i]
        detail={}
        for arm,row in [('before',before),('after',after)]:
            start=row['gc_before']['metadata_estimate'];end=row['gc_after']['metadata_estimate']
            overlaps=[]
            for event in row['gc_after']['events']:
                a=datetime.datetime.fromisoformat(event['start'].replace('Z','+00:00')).timestamp()
                b=datetime.datetime.fromisoformat(event['end'].replace('Z','+00:00')).timestamp()
                if b>row['unix_start'] and a<row['unix_end']:
                    overlaps.append(dict(duration_seconds=b-a,metadata_seconds=event['metadata_ns']/1e9))
            detail[arm]=dict(seconds=row['seconds'],cli_cpu=row['cli_resources']['user_seconds']+row['cli_resources']['system_seconds'],
                engine_cpu=row['engine_cpu'],class_slots=[start['ClassSlotCount'],end['ClassSlotCount']],
                estimated_metadata_bytes=[start['EstimatedBytes'],end['EstimatedBytes']],result_count=[start['ResultCount'],end['ResultCount']],
                host_io_pressure=row['pressure']['host.io.some'],snapshot_gc_overlaps=overlaps)
        pairs.append(dict(pair=i,saved_seconds=before['seconds']-after['seconds'],arms=detail))
    all_pairs.extend(pairs)
    cohorts.append(dict(name=name,pairs=pairs,medians={arm:{metric:statistics.median(pair['arms'][arm][metric] for pair in pairs) for metric in ['seconds','cli_cpu','engine_cpu']} for arm in arms},
        faster_pairs=sum(pair['saved_seconds']>0 for pair in pairs),lower_cli_cpu_pairs=sum(pair['arms']['after']['cli_cpu']<pair['arms']['before']['cli_cpu'] for pair in pairs)))
result=dict(scope='All 12 fixed pairs and four initialization commands succeed with exact rows. Warm engine, fresh CLI and source edits, normal GC/maintenance, telemetry and cleanup. Confirmation fails to reproduce an elapsed-time improvement; CPU reduction is consistent. Maintenance and pressure differences are retained, not filtered.',
    cohorts=cohorts,total_pairs=len(all_pairs),faster_pairs=sum(pair['saved_seconds']>0 for pair in all_pairs),
    lower_cli_cpu_pairs=sum(pair['arms']['after']['cli_cpu']<pair['arms']['before']['cli_cpu'] for pair in all_pairs),
    elapsed_time_confirmed=False,cli_cpu_reduction_confirmed=True,selected=False,no_new_upstream_proposal=True,pr_opened=False,
    next='Profile actual cache-metadata pruning and compaction near the recorded 4 GiB estimate. Snapshot-GC intervals do not account for the entire long-command gap; class-slot reductions and estimates do not establish the exact cause.')
(p/'confirmation-assessment.json').write_text(json.dumps(result,indent=2)+'\n')
(p/'decision.json').write_text(json.dumps({key:result[key] for key in ['elapsed_time_confirmed','cli_cpu_reduction_confirmed','selected','no_new_upstream_proposal','pr_opened','next']},indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='cohorts'},indent=2))
print(json.dumps([{key:cohort[key] for key in ['name','medians','faster_pairs','lower_cli_cpu_pairs']} for cohort in cohorts],indent=2))
