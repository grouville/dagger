from pathlib import Path
import hashlib
import io
import json
import tarfile

p=Path(__file__).parent
dest=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/native-grpc-attachables-confirmation')
assessment=json.loads((p/'confirmation-assessment.json').read_text())
assert not assessment['elapsed_time_confirmed'] and not assessment['selected']
assert assessment['total_pairs']==12 and assessment['lower_cli_cpu_pairs']==12
assert json.loads((p/'confirmation/summary.json').read_text())['all_commands_succeeded']
checks=json.loads((p/'lifecycle-audit/validation.json').read_text())
assert len(checks)==3 and all(row['exit_code']==row['expected_exit_code'] for row in checks)
assert json.loads((p/'retained-confirmation-restoration.json').read_text())['exit_code']==0
names=['measure-confirmation.py','assess-confirmation.py','archive_confirmation.py','confirmation-assessment.json','confirmation-assessment.log','decision.json',
       'confirmation-final-state.json','confirmation-log-read.json','confirmation-metadata-prune.log','retained-confirmation.log','retained-confirmation-restoration.json',
       'before-client.go','after-client.go','attachables_native.go','attachables_transport_test.go','source-map.json','candidate-build.json']
sources=[p/name for name in names]
for folder in ['confirmation','lifecycle-audit','confirmation-retained-histories']:
    sources.extend(source for source in (p/folder).rglob('*') if source.is_file() and '__pycache__' not in source.parts)
dest.mkdir(parents=True,exist_ok=True)
archive=dest/'evidence.tar.gz'
records=[]
with tarfile.open(archive,'w:gz',compresslevel=6) as out:
    for source in sorted(sources):
        data=source.read_bytes();name=source.relative_to(p).as_posix()
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0
        out.addfile(entry,io.BytesIO(data))
        records.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(archive,'r:gz') as inp:
    for record in records:
        data=inp.extractfile(record['path']).read()
        assert len(data)==record['size'] and hashlib.sha256(data).hexdigest()==record['sha256']
manifest=dict(archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=records,
              selected=False,elapsed_time_confirmed=False,cli_cpu_reduction_confirmed=True,pr_opened=False)
(dest/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'README.md').write_text('# Opposite-order native gRPC confirmation\n\nSee the [assessment](../../NATIVE_GRPC_ATTACHABLES.md). The eight-pair confirmation does not reproduce the command-time improvement: 34.04 → 34.16 seconds, faster in four pairs. CLI CPU decreases in all eight pairs and all twelve pairs across both cohorts. Every observation and maintenance overlap is retained. The candidate remains off and no PR is open.\n\nThe archive contains the exact confirmation driver and outputs, combined decision, supported shutdown race checks and expected failure, retained Rust-cache histories, source context and restoration state. MANIFEST.json records the verified size and SHA-256 of every member. The initial cohort and diagnostic profiles remain in the [first archive](../native-grpc-attachables/). Adapt original absolute paths for replay. No binary or cache volume is included.\n')
print(json.dumps(dict(members=len(records),archive_bytes=archive.stat().st_size)))
