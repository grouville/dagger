from pathlib import Path
import os,subprocess,time,json
p=Path(__file__).parent;repo=Path('/tmp/dagger-dang-list-element-types');source=repo/'core/sdk/dang/v2/helpers.go';original=source.read_bytes();(p/'before-helpers.go').write_bytes(original)
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[]
def run(label,selector=None):
 command=[go,'test','-p=2','-race','-count=1']+(['-run='+selector] if selector else [])+['./core/sdk/dang/v2'];tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);return r.returncode
code=run('baseline-regression','^TestConvertListPreservesElementType$');text=(p/'baseline-regression.log').read_text();assert code!=0 and 'TestConvertListPreservesElementType/' in text and 'Error:      ' in text,text[-2000:]
old=b'listVal := dang.ListValue{ElemType: listT}';new=b'listVal := dang.ListValue{ElemType: listT.Type}';assert original.count(old)==1;source.write_bytes(original.replace(old,new))
assert run('candidate-regression','^TestConvertListPreservesElementType$')==0
assert run('candidate-sdk-race')==0
print('Baseline fails on list type; fixed converter and complete SDK race suite pass',flush=True)
