package clientdb

import (
	"fmt"
	"github.com/stretchr/testify/require"
	"testing"
)

var fanoutMixedLookupSink *spanLookup

func BenchmarkSpanLookupFanoutMixedIDs(b *testing.B) {
	for _, kind := range []string{"parent", "cause"} {
		for _, count := range []int{1, 16, 128, 1026, 4096} {
			b.Run(fmt.Sprintf("%s/%d", kind, count), func(b *testing.B) {
				rows := make([]Span, count)
				var targets []string
				if kind == "cause" {
					targets = []string{"root"}
				}
				for i := range rows {
					rows[i] = Span{ID: int64(i + 1), TraceID: "trace", SpanID: fmt.Sprintf("%016x", uint64(i+1)*0x9e3779b97f4a7c15)}
					if kind == "parent" {
						rows[i].ParentSpanID = validString("root")
					}
				}
				b.ReportAllocs()
				b.ResetTimer()
				for range b.N {
					lookup := newSpanLookup()
					for _, row := range rows {
						lookup.addLocked(row, targets)
					}
					fanoutMixedLookupSink = lookup
				}
				b.StopTimer()
				if kind == "parent" {
					require.Len(b, fanoutMixedLookupSink.children["root"], count)
				} else {
					require.Len(b, fanoutMixedLookupSink.causalChildren["root"], count)
				}
			})
		}
	}
}
