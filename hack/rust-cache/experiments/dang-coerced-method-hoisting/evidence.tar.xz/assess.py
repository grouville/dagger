from pathlib import Path
import hashlib
import json
import statistics

study = Path(__file__).resolve().parent
results = {}
for family in ("test", "source"):
    directory = study / (family + "-edit-paired")
    rows = json.loads((directory / "samples.json").read_text())
    assert len(rows) == 10
    assert all(row["exit_code"] == 0 and not row["cancelled"] for row in rows)
    assert all(row["correct_names"] and row["same_full_rows"] for row in rows)
    assert all(row["rows"] == (4399 if row["warmup"] else 4398) for row in rows)
    assert all(row["coerced_method_hoisting"] == (row["arm"] == "combined") for row in rows)
    assert all(row["collection_item_content"] for row in rows)
    pairs = []
    for block in range(1, 5):
        pair = {row["arm"]: row for row in rows if row["block"] == block}
        assert set(pair) == {"before", "combined"}
        pairs.append(pair["before"]["seconds"] - pair["combined"]["seconds"])
    restoration = json.loads((directory / "restoration.json").read_text())
    assert all(restoration[key] for key in ("source_restored", "test_restored", "config_restored"))
    assert not restoration["flags_after"]["coerced-method-hoisting"]["enabled"]
    results[family] = dict(
        summary=json.loads((directory / "summary.json").read_text()),
        faster_pairs=sum(saving > 0 for saving in pairs),
        paired_savings_seconds=pairs,
        median_paired_saving_seconds=statistics.median(pairs),
        maximum_host_cpu_pressure=max(row["pressure"]["host.cpu.some"] for row in rows),
    )

for arm in ("before", "candidate"):
    directory = study / ("capture-" + arm)
    result = json.loads((directory / "result.json").read_text())
    assert result["exit_code"] == 0 and result["same_names"] and result["rows"] == 4398
    assert not result["cancelled"] and not result["errors"]
    assert result["recorder"]["dropped"] == result["recorder"]["open"] == 0
    attribution = json.loads((directory / "attribution.json").read_text())
    assert attribution["function_evaluations"] == 804
    assert attribution["sdk_requests"] == 2293
    assert attribution["selected_calls"]["go:GoPackage.tests"] == {"executed": 1, "hit": 799}
    trace = (directory / "wcprof-complete.ndjson").read_bytes()
    identity = dict(bytes=len(trace), sha256=hashlib.sha256(trace).hexdigest())
    (directory / "trace-identity.json").write_text(json.dumps(identity, indent=2) + "\n")
    results["capture-" + arm] = dict(result=result, trace=identity)

(study / "assessment.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps({family: {key: value for key, value in results[family].items() if key != "paired_savings_seconds"} for family in ("test", "source")}))
