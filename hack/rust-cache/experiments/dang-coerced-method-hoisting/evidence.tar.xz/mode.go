package dang

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var coercedMethodHoistingEnabled atomic.Bool

func init() {
	coercedMethodHoistingEnabled.Store(os.Getenv("DANG_BENCH_COERCED_METHOD_HOISTING") == "true")
}
func CoercedMethodHoistingDiagnostic(w http.ResponseWriter, r *http.Request) {
	if value := r.URL.Query().Get("enabled"); value != "" {
		enabled, err := strconv.ParseBool(value)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		coercedMethodHoistingEnabled.Store(enabled)
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": coercedMethodHoistingEnabled.Load()})
}
