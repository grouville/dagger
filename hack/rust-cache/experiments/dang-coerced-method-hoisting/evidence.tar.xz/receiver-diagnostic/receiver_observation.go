package dangv2

import (
	"encoding/json"
	"net/http"
	"strconv"
	"sync"
	"sync/atomic"

	"github.com/dagger/dagger/core"
)

// Diagnostic only: no receiver, client, context, or field contents are retained.
var receiverObservationEnabled atomic.Bool
var receiverObservations = struct {
	sync.Mutex
	Rows map[string]receiverObservationRow
}{Rows: make(map[string]receiverObservationRow)}

type receiverObservationRow struct {
	Calls            uint64         `json:"calls"`
	ParentBytes      uint64         `json:"parent_bytes"`
	MaxParentBytes   uint64         `json:"max_parent_bytes"`
	ConvertedValues  uint64         `json:"converted_values"`
	ConvertedObjects uint64         `json:"converted_objects"`
	ConvertedLists   uint64         `json:"converted_lists"`
	ListElements     uint64         `json:"list_elements"`
	StringBytes      uint64         `json:"string_bytes"`
	MaxFieldList     map[string]int `json:"max_field_list"`
}

type receiverObservation struct {
	key string
	row receiverObservationRow
}

func beginReceiverObservation(call *core.FunctionCall, module dangModule) *receiverObservation {
	if !receiverObservationEnabled.Load() {
		return nil
	}
	return &receiverObservation{
		key: module.name + ":" + call.ParentName + "." + call.Name,
		row: receiverObservationRow{Calls: 1, ParentBytes: uint64(len(call.Parent)), MaxParentBytes: uint64(len(call.Parent)), MaxFieldList: make(map[string]int)},
	}
}

func (o *receiverObservation) decoded(fields map[string]any) {
	if o == nil {
		return
	}
	for name, value := range fields {
		if list, ok := value.([]any); ok {
			o.row.MaxFieldList[name] = len(list)
		}
	}
}

func (o *receiverObservation) converted(value any) {
	if o == nil {
		return
	}
	o.row.ConvertedValues++
	switch value := value.(type) {
	case map[string]any:
		o.row.ConvertedObjects++
	case []any:
		o.row.ConvertedLists++
		o.row.ListElements += uint64(len(value))
	case string:
		o.row.StringBytes += uint64(len(value))
	}
}

func (o *receiverObservation) finish() {
	if o == nil {
		return
	}
	receiverObservations.Lock()
	defer receiverObservations.Unlock()
	row := receiverObservations.Rows[o.key]
	row.Calls += o.row.Calls
	row.ParentBytes += o.row.ParentBytes
	row.MaxParentBytes = max(row.MaxParentBytes, o.row.MaxParentBytes)
	row.ConvertedValues += o.row.ConvertedValues
	row.ConvertedObjects += o.row.ConvertedObjects
	row.ConvertedLists += o.row.ConvertedLists
	row.ListElements += o.row.ListElements
	row.StringBytes += o.row.StringBytes
	if row.MaxFieldList == nil {
		row.MaxFieldList = make(map[string]int)
	}
	for name, size := range o.row.MaxFieldList {
		row.MaxFieldList[name] = max(row.MaxFieldList[name], size)
	}
	receiverObservations.Rows[o.key] = row
}

func ReceiverPreparationDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		receiverObservationEnabled.Store(enabled)
		if r.URL.Query().Get("reset") == "true" {
			receiverObservations.Lock()
			receiverObservations.Rows = make(map[string]receiverObservationRow)
			receiverObservations.Unlock()
		}
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	receiverObservations.Lock()
	defer receiverObservations.Unlock()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(struct {
		Enabled bool                              `json:"enabled"`
		Rows    map[string]receiverObservationRow `json:"rows"`
	}{receiverObservationEnabled.Load(), receiverObservations.Rows})
}
