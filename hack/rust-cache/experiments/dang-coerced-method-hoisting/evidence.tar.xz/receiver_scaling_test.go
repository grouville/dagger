package dangv2

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/dagger/dagger/core"
	"github.com/vito/dang/v2/pkg/dang"
)

func receiverPreparationFixture(tb testing.TB, packages, owners int) (dang.ValueScope, *core.FunctionCall) {
	tb.Helper()
	directory := tb.TempDir()
	ownerMethods := ""
	for i := range 32 {
		ownerMethods += fmt.Sprintf(" method%d(prefix: String! = \"default\"): String! { prefix + path }\n", i)
	}
	source := "type Owner { path: String!\n" + ownerMethods + "}\n" + `type Group {
  paths: [String!]!
  owners: [Owner!]!
  get(path: String!): String! { path }
}`
	if err := os.WriteFile(filepath.Join(directory, "main.dang"), []byte(source), 0600); err != nil {
		tb.Fatal(err)
	}
	env, err := dang.RunDir(context.Background(), directory, false)
	if err != nil {
		tb.Fatal(err)
	}
	paths := make([]string, packages)
	for i := range paths {
		paths[i] = fmt.Sprintf("package/%04d", i)
	}
	moduleOwners := make([]map[string]string, owners)
	for i := range moduleOwners {
		moduleOwners[i] = map[string]string{"path": fmt.Sprintf("module/%04d", i)}
	}
	parent, err := json.Marshal(map[string]any{"paths": paths, "owners": moduleOwners})
	if err != nil {
		tb.Fatal(err)
	}
	return env, &core.FunctionCall{
		ParentName: "Group", Name: "get", Parent: core.JSON(parent),
		InputArgs: []*core.FunctionCallArgValue{{Name: "path", Value: core.JSON(`"selected"`)}},
	}
}

func TestReceiverPreparationObservesUnusedCollectionState(t *testing.T) {
	previous := receiverObservationEnabled.Load()
	receiverObservationEnabled.Store(true)
	t.Cleanup(func() { receiverObservationEnabled.Store(previous) })
	env, call := receiverPreparationFixture(t, 128, 16)
	constructor, _, _ := env.Lookup(t.Context(), "Group")
	for _, form := range constructor.(*dang.ConstructorFunction).ObjectBodyForms {
		if field, ok := form.(*dang.FieldDecl); ok {
			t.Logf("%s value=%T type=%T", field.Name.Name, field.Value, field.Type_)
		}
	}
	result, err := callDangFunction(t.Context(), env, call, dangModule{name: "observation-test"})
	if err != nil {
		t.Fatal(err)
	}
	if result.(dang.StringValue).Val != "selected" {
		t.Fatal("getter result changed")
	}
	receiverObservations.Lock()
	row := receiverObservations.Rows["observation-test:Group.get"]
	receiverObservations.Unlock()
	if row.Calls != 1 || row.ParentBytes != uint64(len(call.Parent)) || row.MaxFieldList["paths"] != 128 || row.MaxFieldList["owners"] != 16 {
		t.Fatalf("unexpected observation: %+v", row)
	}
	if row.ConvertedObjects != 16 || row.ConvertedLists != 2 || row.ListElements != 144 {
		t.Fatalf("unused state was not measured correctly: %+v", row)
	}
}

func TestReceiverPreparationObservationIsDisabled(t *testing.T) {
	previous := receiverObservationEnabled.Load()
	receiverObservationEnabled.Store(false)
	t.Cleanup(func() { receiverObservationEnabled.Store(previous) })
	if beginReceiverObservation(&core.FunctionCall{}, dangModule{}) != nil {
		t.Fatal("disabled observation retains invocation state")
	}
	var observation *receiverObservation
	observation.decoded(nil)
	observation.converted(nil)
	observation.finish()
}

func BenchmarkReceiverPreparation(b *testing.B) {
	for _, packages := range []int{16, 64, 256, 800} {
		b.Run(fmt.Sprintf("packages=%d", packages), func(b *testing.B) {
			env, call := receiverPreparationFixture(b, packages, max(1, packages/10))
			ctx := context.Background()
			b.ReportAllocs()
			b.ReportMetric(float64(packages*len(call.Parent)), "parent-bytes/expansion")
			b.ResetTimer()
			for range b.N {
				for range packages {
					if _, err := callDangFunction(ctx, env, call, dangModule{}); err != nil {
						b.Fatal(err)
					}
				}
			}
		})
	}
}
