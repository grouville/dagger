from pathlib import Path
import json, subprocess, time, urllib.request
p=Path(__file__).resolve().parent
route='http://127.0.0.1:16105/debug/'
def get(name,data=None):
 with urllib.request.urlopen(urllib.request.Request(route+name,data=data),timeout=10) as response:return json.load(response)
saved=get('collection-item-content')['enabled']
assert not get('coerced-method-hoisting')['enabled']
assert not get('receiver-preparation')['enabled']
assert not get('evaluation-context')['enabled']
assert get('collection-item-content?enabled=true',b'')['enabled']
rows=[]
try:
 for name in ['verify-library.py','verify.py']:
  tick=time.monotonic()
  with (p/(name+'.log')).open('w') as out:r=subprocess.run(['python3',str(p/name)],stdout=out,stderr=subprocess.STDOUT)
  row=dict(driver=name,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row)
  (p/'go-verification.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  assert r.returncode==0,(p/(name+'.log')).read_text()[-3000:]
finally:
 (p/'go-verification-restoration.json').write_text(json.dumps(get('collection-item-content?enabled='+str(saved).lower(),b''),indent=2)+'\n')
assert not get('coerced-method-hoisting')['enabled']
rows=[]
for family in ['test','source']:
 cmd=['python3',str(p/('measure-'+family+'-edits.py')),'--output',str(p/(family+'-edit-paired')),'--fixture','real','--arms','before','combined','--pairs','4']
 tick=time.monotonic()
 with (p/(family+'-edit-driver.log')).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 row=dict(family=family,command=cmd,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row)
 (p/'timing-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(p/(family+'-edit-driver.log')).read_text()[-3500:]
