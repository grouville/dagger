package dang

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"github.com/stretchr/testify/require"
)

type argumentNames struct {
	BuiltinFunction
	names []string
	reads int
}

func (f *argumentNames) ParameterNames() []string {
	f.reads++
	return f.names
}

type argumentExpression struct {
	ValueNode
	eval func() (Value, error)
}

func (e *argumentExpression) Eval(context.Context, ValueScope) (Value, error) {
	return e.eval()
}

func TestArgumentBindingPreservesEvaluationAndErrors(t *testing.T) {
	type arg struct {
		key        string
		positional bool
	}
	for _, tc := range []struct {
		name      string
		args      []arg
		failAt    int
		want      map[string]string
		wantOrder []int
		wantError string
	}{
		{name: "empty", failAt: -1, want: map[string]string{}},
		{name: "positional", args: []arg{{positional: true}, {positional: true}}, failAt: -1,
			want: map[string]string{"first": "0", "second": "1"}, wantOrder: []int{0, 1}},
		{name: "named", args: []arg{{key: "second"}, {key: "first"}}, failAt: -1,
			want: map[string]string{"first": "1", "second": "0"}, wantOrder: []int{0, 1}},
		{name: "mixed", args: []arg{{positional: true}, {key: "second"}}, failAt: -1,
			want: map[string]string{"first": "0", "second": "1"}, wantOrder: []int{0, 1}},
		{name: "invalid order", args: []arg{{key: "second"}, {positional: true}}, failAt: -1,
			wantError: "positional arguments must come before named arguments"},
		{name: "positional collision", args: []arg{{positional: true}, {key: "first"}}, failAt: -1,
			wantOrder: []int{0, 1}, wantError: `argument "first" specified both positionally and by name`},
		{name: "named collision", args: []arg{{key: "first"}, {key: "first"}}, failAt: -1,
			wantOrder: []int{0, 1}, wantError: `argument "first" specified multiple times`},
		{name: "too many positional", args: []arg{{positional: true}, {positional: true}, {positional: true}}, failAt: -1,
			wantOrder: []int{0, 1, 2}, wantError: "too many positional arguments: got 3, expected at most 2"},
		{name: "expression fails before duplicate", args: []arg{{positional: true}, {key: "first"}}, failAt: 1,
			wantOrder: []int{0, 1}, wantError: "argument expression failed"},
		{name: "expression failure stops later arguments", args: []arg{{positional: true}, {positional: true}}, failAt: 0,
			wantOrder: []int{0}, wantError: "argument expression failed"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var order []int
			call := &FunCall{}
			for i, a := range tc.args {
				call.Args = append(call.Args, Keyed[Node]{Key: a.key, Positional: a.positional,
					Value: &argumentExpression{eval: func() (Value, error) {
						order = append(order, i)
						if i == tc.failAt {
							return nil, errors.New("argument expression failed")
						}
						return StringValue{Val: fmt.Sprint(i)}, nil
					}},
				})
			}
			fn := &argumentNames{names: []string{"first", "second"}}
			got, err := call.evaluateArguments(t.Context(), NewObject(NewType("test", ObjectKind)), fn)
			require.Equal(t, tc.wantOrder, order)
			if tc.name == "invalid order" {
				require.Zero(t, fn.reads, "invalid ordering must fail before querying the callable")
			} else {
				require.Equal(t, 1, fn.reads)
			}
			if tc.wantError != "" {
				require.ErrorContains(t, err, tc.wantError)
				return
			}
			require.NoError(t, err)
			actual := make(map[string]string, len(got))
			for k, v := range got {
				actual[k] = v.(StringValue).Val
			}
			require.Equal(t, tc.want, actual)
		})
	}
}

func TestArgumentBindingTracksActualPositionalNames(t *testing.T) {
	// A Go callable may expose its parameter slice. Argument evaluation can
	// change it, so duplicate diagnostics must describe the binding already made.
	fn := &argumentNames{names: []string{"first", "second"}}
	call := &FunCall{Args: Record{
		{Positional: true, Value: &ValueNode{Val: StringValue{Val: "original"}}},
		{Key: "first", Value: &argumentExpression{eval: func() (Value, error) {
			fn.names[0] = "changed"
			return StringValue{Val: "duplicate"}, nil
		}}},
	}}
	_, err := call.evaluateArguments(t.Context(), NewObject(NewType("test", ObjectKind)), fn)
	require.ErrorContains(t, err, `argument "first" specified both positionally and by name`)
}

func BenchmarkArgumentBinding(b *testing.B) {
	for _, shape := range []struct {
		name       string
		positional int
		named      int
	}{
		{"empty", 0, 0}, {"positional-1", 1, 0}, {"positional-2", 2, 0},
		{"positional-8", 8, 0}, {"named-2", 0, 2}, {"mixed-2", 1, 1},
	} {
		b.Run(shape.name, func(b *testing.B) {
			fn := &argumentNames{}
			call := &FunCall{}
			for i := range shape.positional + shape.named {
				name := fmt.Sprintf("arg%d", i)
				fn.names = append(fn.names, name)
				call.Args = append(call.Args, Keyed[Node]{Key: name, Positional: i < shape.positional,
					Value: &ValueNode{Val: StringValue{Val: name}}})
			}
			scope := NewObject(NewType("benchmark", ObjectKind))
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				got, err := call.evaluateArguments(b.Context(), scope, fn)
				if err != nil || len(got) != len(call.Args) {
					b.Fatalf("bound %d arguments: %v", len(got), err)
				}
			}
		})
	}
}
