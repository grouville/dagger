package dang

import (
	"context"
	"testing"
)

func BenchmarkCallbackDispatch(b *testing.B) {
	_, value := callbackTestFunction(b)
	function := value.(FunctionValue)
	for _, shape := range []struct {
		name string
		fn   Value
	}{
		{"native", function},
		{"native-pointer", &function},
		{"custom", &mutableCallback{}},
	} {
		b.Run(shape.name, func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				if _, err := callFunc(context.Background(), shape.fn, IntValue{Val: 1}); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
