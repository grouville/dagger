package dang

import (
	"context"
	"testing"
)

type retainingCallback struct {
	mutableCallback
	arguments []map[string]Value
}

func (f *retainingCallback) Call(ctx context.Context, scope ValueScope, args map[string]Value) (Value, error) {
	value, err := f.mutableCallback.Call(ctx, scope, args)
	f.arguments = append(f.arguments, args)
	return value, err
}

func TestCallbackDispatchPreservesRetainedCustomArguments(t *testing.T) {
	fn := &retainingCallback{}
	for i := range 3 {
		if _, err := callFunc(t.Context(), fn, IntValue{Val: i}); err != nil {
			t.Fatal(err)
		}
	}
	for i, args := range fn.arguments {
		if got := args["value"].(IntValue).Val; got != i {
			t.Fatalf("retained call %d changed to %d", i, got)
		}
	}
}
