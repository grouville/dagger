from pathlib import Path
import json
import os
import subprocess
import time

p = Path(__file__).parent
repo = p/'standalone'
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOMAXPROCS='8', GOTOOLCHAIN='local', GOWORK='off')
steps = []
def run(label, args):
    tick = time.monotonic()
    with (p/(label+'.log')).open('w') as out:
        result = subprocess.run(args, cwd=repo, env=env, stdout=out, stderr=subprocess.STDOUT)
    row = dict(label=label, command=args, seconds=time.monotonic()-tick, exit_code=result.returncode)
    steps.append(row)
    (p/'dispatch-control-steps.json').write_text(json.dumps(steps, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        print((p/(label+'.log')).read_text()[-4000:], flush=True)
        raise SystemExit(result.returncode)

for arm in ['before','candidate']:
    extra = ['-overlay='+str(p/'baseline-overlay.json')] if arm=='before' else []
    run(arm+'-escape-compile',[go,'test','-p=2','-buildvcs=false',*extra,'-gcflags=github.com/vito/dang/v2/pkg/dang=-m=2','-c','-o',str(p/(arm+'.test')),'./pkg/dang'])
for pair in range(4):
    for arm in (['before','candidate'] if pair%2==0 else ['candidate','before']):
        run(f'controls-{pair}-{arm}',[str(p/(arm+'.test')),'-test.run=^$','-test.bench=^BenchmarkCallbackDispatch$','-test.benchmem','-test.benchtime=150ms','-test.cpu=8'])
