from pathlib import Path
import json
import subprocess
import time
import urllib.request

p=Path(__file__).parent
record=json.loads(subprocess.check_output(['docker','inspect','dagger-rust-parser-state-pool-oct14']))[0]
cgroup=Path('/sys/fs/cgroup')/Path(f"/proc/{record['State']['Pid']}/cgroup").read_text().split(':',2)[2].strip().lstrip('/')
def sample():
    return dict(cpu=int(next(line.split()[1] for line in (cgroup/'cpu.stat').read_text().splitlines() if line.startswith('usage_usec '))),
                io=int(Path('/proc/pressure/io').read_text().splitlines()[0].split('total=')[1]),tick=time.monotonic())

started=time.monotonic()
consecutive=0
while True:
    before=sample();time.sleep(1);after=sample();seconds=after['tick']-before['tick']
    with urllib.request.urlopen('http://127.0.0.1:16104/debug/client-lifecycle',timeout=20) as response:
        state=json.load(response)
    row=dict(seconds=time.monotonic()-started,engine_cpu_cores=(after['cpu']-before['cpu'])/(seconds*1e6),
             host_io_pressure=(after['io']-before['io'])/(seconds*1e6),sessions=len(state.get('sessions') or []),active_requests=state['active_requests'])
    quiet=row['engine_cpu_cores']<.15 and row['host_io_pressure']<.05 and not row['sessions'] and not row['active_requests']
    consecutive=consecutive+1 if quiet else 0
    row['consecutive_quiet_samples']=consecutive
    with (p/'quiet-wait.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
    if consecutive>=3:break
    assert time.monotonic()-started<300,'Host did not meet the existing idle criteria within five minutes.'
print('Host met existing idle criteria for three consecutive samples; running the comparison.',flush=True)
command=['python3',str(p/'measure_listing.py'),'--output',str(p/'full-command-paired'),'--pairs','5','--languages','go']
with (p/'full-command-driver.log').open('w') as output:
    result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
(p/'comparison-exit.json').write_text(json.dumps(dict(command=command,exit_code=result.returncode),indent=2)+'\n')
raise SystemExit(result.returncode)
