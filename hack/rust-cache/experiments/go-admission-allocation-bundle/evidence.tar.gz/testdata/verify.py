from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import urllib.request

p=Path(__file__).parent;base=p.parent
routes=['prepared-schema','callback-caller-reuse','lazy-type-maps','interface-field-snapshots','parallel-client-admission']
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16104/debug/'+route,data=data),timeout=20) as response:return json.load(response)
def set_mode(route,enabled):
 result=get(route+'?enabled='+str(enabled).lower(),b'');assert result['enabled']==enabled
before={r:get(r) for r in routes}
assert all(not s['enabled'] for s in before.values())
assert get('reusable-declarations')['enabled']
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
module=Path('/tmp/dagger-go-module-test-name-index')
fixture=module/'testdata/go-module-no-packages/constrained_test.go';original=fixture.read_bytes()
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16276',RUST_CACHE_BENCH_CLI=str(base/'filesync-literal-pathwalk/dagger-after'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows=[]
try:
 for r in routes:set_mode(r,True)
 fixture.write_bytes(original+f'\n// Admission and allocation correctness input {time.time_ns()}\n'.encode())
 commands=[('retained-bundle',['python3',str(base/'trivial-scalar-projection/verify_retained_first.py'),'go-admission-allocation-bundle-before'],None),
           ('tests-collection-check',['python3',str(base/'local_cli_collector.py'),'check','go-dev:tests-collection-check'],str(module)),
           ('package-layout-rebind-check',['python3',str(base/'local_cli_collector.py'),'check','go-dev:package-layout-rebind-check'],str(module))]
 for label,command,cwd in commands:
  assert all(get(r)['enabled'] for r in routes)
  tick=time.monotonic()
  with (p/(label+'.log')).open('w') as output:
   result=subprocess.run(command,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT)
  row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=result.returncode,modes={r:get(r) for r in routes});rows.append(row);(p/'correctness.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
  assert result.returncode==0,(p/(label+'.log')).read_text()[-5000:]
finally:
 fixture.write_bytes(original)
 for r,s in before.items():set_mode(r,s['enabled'])
 (p/'correctness-restored.json').write_text(json.dumps(dict(fixture_restored=fixture.read_bytes()==original,modes={r:get(r) for r in routes}),indent=2)+'\n')
