package dang

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestMapMerge(t *testing.T) {
	t.Parallel()
	require.NoError(t, evalExample(`
let left = ["a": 1, "b": 2]
let right = ["b": 20, "c": 3]
let merged = left.merge(right)
assert { merged.keys == ["a", "b", "c"] }
assert { merged.values == [1, 20, 3] }
assert { left.keys == ["a", "b"] and left.values == [1, 2] }
assert { right.keys == ["b", "c"] and right.values == [20, 3] }
let empty: Map[Int!]! = [:]
assert { left.merge(empty) == left }
assert { empty.merge(right) == right }
assert { left.merge(left) == left }
`))
}

func TestMapMergeDoesNotAliasInputs(t *testing.T) {
	t.Parallel()
	left := MapValue{Keys: []string{"a", "b"}, Entries: map[string]Value{"a": IntValue{Val: 1}, "b": IntValue{Val: 2}}, ValType: IntValue{}.Type()}
	right := MapValue{Keys: []string{"b", "c"}, Entries: map[string]Value{"b": IntValue{Val: 20}, "c": IntValue{Val: 3}}, ValType: left.ValType}
	merged := left.Merge(right)
	require.Equal(t, []string{"a", "b", "c"}, merged.Keys)
	require.Equal(t, left.ValType, merged.ValType)
	merged.Keys[0] = "changed"
	merged.Entries["a"] = IntValue{Val: 100}
	merged.Entries["b"] = IntValue{Val: 200}
	require.Equal(t, []string{"a", "b"}, left.Keys)
	require.Equal(t, IntValue{Val: 1}, left.Entries["a"])
	require.Equal(t, IntValue{Val: 2}, left.Entries["b"])
	require.Equal(t, []string{"b", "c"}, right.Keys)
	require.Equal(t, IntValue{Val: 20}, right.Entries["b"])
	fromZero := (MapValue{}).Merge(right)
	require.Equal(t, right.Keys, fromZero.Keys)
	require.Equal(t, right.Entries, fromZero.Entries)
	require.Nil(t, fromZero.ValType)
}

var benchmarkMapMerge MapValue

func BenchmarkMapMerge(b *testing.B) {
	for _, count := range []int{8, 128, 512} {
		for _, overlap := range []bool{false, true} {
			left := MapValue{Entries: map[string]Value{}, ValType: IntValue{}.Type()}
			right := MapValue{Entries: map[string]Value{}, ValType: left.ValType}
			for i := range count {
				key := fmt.Sprintf("key-%05d", i)
				left.Keys = append(left.Keys, key)
				left.Entries[key] = IntValue{Val: i}
				if !overlap {
					key = fmt.Sprintf("other-%05d", i)
				}
				right.Keys = append(right.Keys, key)
				right.Entries[key] = IntValue{Val: -i}
			}
			b.Run(fmt.Sprintf("keys=%d/overlap=%t", count, overlap), func(b *testing.B) {
				got := left.Merge(right)
				wantLen := 2 * count
				if overlap {
					wantLen = count
				}
				require.Len(b, got.Entries, wantLen)
				require.Equal(b, left.Keys, got.Keys[:count])
				if !overlap {
					require.Equal(b, right.Keys, got.Keys[count:])
				}
				for _, key := range right.Keys {
					require.Equal(b, right.Entries[key], got.Entries[key])
				}
				b.ReportAllocs()
				b.ResetTimer()
				for b.Loop() {
					benchmarkMapMerge = left.Merge(right)
				}
			})
		}
	}
}
