package dang

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var linearMapMergeEnabled atomic.Bool

func init() { linearMapMergeEnabled.Store(os.Getenv("DANG_TEST_LINEAR_MAP_MERGE") == "true") }
func LinearMapMergeDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		v, e := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if e != nil {
			http.Error(w, e.Error(), 400)
			return
		}
		linearMapMergeEnabled.Store(v)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", 405)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": linearMapMergeEnabled.Load()})
}
