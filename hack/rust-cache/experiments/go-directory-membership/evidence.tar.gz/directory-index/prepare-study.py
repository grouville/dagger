from pathlib import Path
import json
base=Path('/tmp/rust-cache-sipsma-review');p=base/'go-generation-directory-index';p.mkdir(exist_ok=False);parent=base/'linear-map-merge-engine'
for name in ['measure-source-edits.py','measure-test-edits.py','measure.py','capture.py','capture-all.py','analyze.py','analyze-all.py','verify-module.py']:
 s=(parent/name).read_text().replace("'combined':Path('/tmp/dagger-go-discovery-generate-matches')","'combined':Path('/tmp/dagger-go-generation-directory-index')").replace("'candidate':Path('/tmp/dagger-go-discovery-generate-matches')","'candidate':Path('/tmp/dagger-go-generation-directory-index')")
 s=s.replace("mode('linear-map-merge',arm=='combined')","mode('linear-map-merge',True)").replace("mode('linear-map-merge',options.arm=='candidate')","mode('linear-map-merge',True)").replace("get('linear-map-merge?enabled='+str(arm=='candidate').lower(),b'')","get('linear-map-merge?enabled=true',b'')")
 s=s.replace("linear_map_merge=arm=='combined'","linear_map_merge=True,generation_directory_index=arm=='combined'").replace("linear_map_merge=options.arm=='candidate'","linear_map_merge=True,generation_directory_index=options.arm=='candidate'")
 s=s.replace('Only native map merging changes; client admission, initialization, permissions, leases, telemetry and full cleanup remain.','Both modes use linear native map merging. Only directory-match membership changes from list scanning to a balanced-built map. Globs, selection, getters, client lifecycle, telemetry and full cleanup remain.')
 s=s.replace("str(p/'dagger-engine')","str(p.parent/'linear-map-merge-engine/dagger-engine')")
 (p/name).write_text(s)
# Small fixtures remain separate checks for new construction cost.
s=(base/'go-discovery-generate-matches/prepare-small.py').read_text().replace('go-discovery-generate-matches','go-generation-directory-index');(p/'prepare-small.py').write_text(s)
(p/'identity.json').write_text(json.dumps(dict(baseline='/tmp/dagger-go-discovery-generate-matches',candidate='/tmp/dagger-go-generation-directory-index',dependency='Both modes require linear Map.merge; current engine main still copies per right-hand key.',scope='Directory membership only; no extra SDK query, cache or getter change.'),indent=2)+'\n')
(p/'run.py').write_text('''from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for label,name in [('go-checks','verify-module.py'),('timings','measure.py'),('profiles','capture-all.py'),('analysis','analyze-all.py')]:
 command=['python3',str(p/name)];tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-2500:],flush=True);raise SystemExit(r.returncode)
''')
(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-directory-index-study.py').read_bytes())
import ast
for f in p.glob('*.py'):ast.parse(f.read_text())
print(p)
