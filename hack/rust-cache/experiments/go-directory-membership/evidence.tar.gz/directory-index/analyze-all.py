from pathlib import Path
import json,subprocess,time,statistics
p=Path(__file__).parent
rows=[]
for arm in ['before','candidate','root-before','root-candidate']:
 capture=p/('capture-'+arm)
 command=['python3',str(p/'analyze.py'),str(capture)]
 tick=time.monotonic()
 with (capture/'analysis.log').open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 assert result.returncode==0
 windows=sorted(capture.glob('engine-cpu-*.pprof'))
 for cumulative in [False,True]:
  command=['/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go','tool','pprof','-top','-nodecount=100']+(['-cum'] if cumulative else [])+[str(p.parent/'linear-map-merge-engine/dagger-engine'),*[str(f) for f in windows]]
  with (capture/('cpu-cumulative.txt' if cumulative else 'cpu-flat.txt')).open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
  assert result.returncode==0
 record=json.loads((capture/'attribution.json').read_text());rows.append(dict(arm=arm,analysis_seconds=time.monotonic()-tick,command_seconds=json.loads((capture/'result.json').read_text())['seconds'],module_evaluations=record['function_evaluations'],sdk_requests=record['sdk_requests'],main_query=record['main_query'],dropped=record['dropped'],open=record['open_ops']))
 print(json.dumps(rows[-1]),flush=True)
summary={}
for workload in ['test','source']:
 samples=json.loads((p/(workload+'-edit-paired/samples.json')).read_text())
 pairs=[]
 for block in range(2,6):
  pair={r['arm']:r for r in samples if r['block']==block}
  pairs.append(pair['before']['seconds']-pair['combined']['seconds'])
 summary[workload]=dict(medians=json.loads((p/(workload+'-edit-paired/summary.json')).read_text()),paired_seconds=pairs,median_paired_saving=statistics.median(pairs),faster_pairs=sum(v>0 for v in pairs),commands=len(samples),all_correct=all(r['exit_code']==0 and r['correct_names'] and r['same_full_rows'] for r in samples))
(p/'assessment.json').write_text(json.dumps(dict(timings=summary,diagnostics=rows),indent=2)+'\n');print(json.dumps(summary),flush=True)
