from pathlib import Path
import subprocess
p=Path(__file__).parent
for count in [1,16]:
 root=p/'small-fixtures'/str(count);root.mkdir(parents=True,exist_ok=False);subprocess.run(['git','init','--quiet',str(root)],check=True)
 (root/'go.mod').write_text('module example.com/sharedmatches\n\ngo 1.26.6\n')
 expected=[]
 for i in range(count):
  rel='.' if count==1 else f'mod_{i:03d}';d=root/rel;d.mkdir(exist_ok=True)
  if count!=1:(d/'go.mod').write_text(f'module example.com/mod{i}\n\ngo 1.26.6\n')
  (d/'value.go').write_text('package fixture\n\nfunc Value() int { return 42 }\n')
  (d/'value_test.go').write_text('package fixture\n\nimport "testing"\n\nfunc TestValue(t *testing.T) { if Value() != 42 { t.Fatal("value") } }\n')
  expected.append((rel,'TestValue'))
 text=(p/'measure-source-edits.py').read_text();text=text.replace("workspace=Path('/tmp/dagger-go-real-repository-main')",f'workspace=Path({str(root)!r})')
 rel='' if count==1 else 'mod_000/'
 text=text.replace("workspace/'dagql/types.go'",f"workspace/{(rel+'value.go')!r}").replace("workspace/'dagql/cache_test.go'",f"workspace/{(rel+'value_test.go')!r}")
 text='\n'.join('expected='+repr(expected) if line.startswith('expected=') else line for line in text.splitlines())+'\n'
 text=text.replace("[('dagql',test_name)]",f'[{(expected[0][0],"PLACEHOLDER")!r}]'.replace("'PLACEHOLDER'",'test_name'))
 text=text.replace('test = ["."]','test = ["**"]')
 text=text.replace("metadata=dict(fixture=options.fixture,","metadata=dict(fixture=options.fixture,module_count="+str(count)+",small_fixture=True,")
 (p/f'measure-small-{count}.py').write_text(text)
print('prepared one- and sixteen-module source-edit cohorts')
