from pathlib import Path
import json
base=Path('/tmp/rust-cache-sipsma-review');p=base/'go-binding-source-profile';p.mkdir(exist_ok=False);parent=base/'go-reduction-source-profile';engine=base/'sealed-metadata-json-engine'
src=base/'dang-lazy-eval-error-context/controlled-eval.go';s=src.read_text();marker='func (f FunctionValue) BindArgs(ctx context.Context, fnScope ValueScope, args map[string]Value) error {';assert s.count(marker)==1;s=s.replace(marker,marker+'\n\trecordArgumentBinding(f)');(p/'eval.go').write_text(s)
(p/'argument_profile.go').write_text('''package dang

import (
 "encoding/json"
 "net/http"
 "os"
 "sort"
 "sync"
 "sync/atomic"
)

// Diagnostic only. Keys identify declarations, never argument values or clients.
var argumentProfileEnabled = os.Getenv("DANG_PROFILE_ARGUMENT_BINDINGS") == "true"
var argumentProfiles sync.Map

type argumentProfileKey struct {
 location *SourceLocation
 parameters int
 block bool
}

type argumentProfileCount struct {
 file string
 line, column int
 names []string
 block bool
 calls atomic.Uint64
}

func recordArgumentBinding(fn FunctionValue) {
 if !argumentProfileEnabled { return }
 var loc *SourceLocation
 if fn.Body != nil { loc = fn.Body.GetSourceLocation() }
 key := argumentProfileKey{loc, len(fn.Args), fn.IsBlockArg}
 value, found := argumentProfiles.Load(key)
 if !found {
  entry := &argumentProfileCount{names: append([]string(nil), fn.Args...), block: fn.IsBlockArg}
  if loc != nil { entry.file, entry.line, entry.column = loc.Filename, loc.Line, loc.Column }
  value, _ = argumentProfiles.LoadOrStore(key, entry)
 }
 value.(*argumentProfileCount).calls.Add(1)
}

func ArgumentBindingProfileDiagnostic(w http.ResponseWriter, r *http.Request) {
 if r.Method != http.MethodGet { http.Error(w, "GET required", http.StatusMethodNotAllowed); return }
 type row struct {
  File string `json:"file"`
  Line int `json:"line"`
  Column int `json:"column"`
  Parameters []string `json:"parameters"`
  Block bool `json:"block"`
  Calls uint64 `json:"calls"`
  ParameterSlots uint64 `json:"parameter_slots"`
 }
 rows := []row{}
 argumentProfiles.Range(func(_, value any) bool {
  count := value.(*argumentProfileCount)
  calls := count.calls.Load()
  rows = append(rows, row{count.file,count.line,count.column,count.names,count.block,calls,calls*uint64(len(count.names))})
  return true
 })
 sort.Slice(rows,func(i,j int)bool{return rows[i].ParameterSlots>rows[j].ParameterSlots})
 w.Header().Set("Content-Type","application/json")
 _ = json.NewEncoder(w).Encode(map[string]any{"enabled":argumentProfileEnabled,"rows":rows})
}
''')
o=json.loads((engine/'overlay.json').read_text());original=next(k for k,v in o['Replace'].items() if v==str(src));o['Replace'][original]=str(p/'eval.go');o['Replace'][str(Path(original).parent/'argument_profile.go')]=str(p/'argument_profile.go')
s=(engine/'engine-debug.go').read_text();marker='m.HandleFunc("/debug/evaluation-context", dang.EvaluationContextDiagnostic)';assert marker in s;s=s.replace(marker,marker+'\n\tm.HandleFunc("/debug/argument-bindings", dang.ArgumentBindingProfileDiagnostic)');(p/'engine-debug.go').write_text(s);debugkey=next(k for k,v in o['Replace'].items() if v==str(engine/'engine-debug.go'));o['Replace'][debugkey]=str(p/'engine-debug.go');(p/'overlay.json').write_text(json.dumps(o,indent=2)+'\n')
plan=json.loads((engine/'engine-plan.json').read_text());plan.update(new_engine='dagger-collection-bind-profile-oct19',ports={'runner':16286,'debug':16114},environment={'DANG_PROFILE_ARGUMENT_BINDINGS':'true'},scenario='Count FunctionValue.BindArgs by declaration source. Diagnostic only; unchanged getter/initializer execution. No latency claims.')
(p/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(parent/'build-engine.py').read_text().replace('DANG_PROFILE_LIST_REDUCTIONS','DANG_PROFILE_ARGUMENT_BINDINGS');(p/'build-engine.py').write_text(s)
s=(parent/'start-engine.py').read_text().replace('16285','16286').replace('16113','16114').replace('DANG_PROFILE_LIST_REDUCTIONS','DANG_PROFILE_ARGUMENT_BINDINGS').replace('codex.task=reduction-source-profile','codex.task=binding-source-profile');(p/'start-engine.py').write_text(s)
s=(base/'parallel-admission-local-discovery/capture.py').read_text().replace('16284','16286').replace('16112','16114').replace('dagger-collection-metadata-json-oct19','dagger-collection-bind-profile-oct19')
s=s.replace("mode('parallel-client-admission',options.arm=='candidate')","mode('parallel-client-admission',False)")
marker="    before=heap();before_cpu=cpu();gc_before=get('snapshot-collection');tick=time.monotonic()";assert marker in s;s=s.replace(marker,"    (root/'bindings-before.json').write_text(json.dumps(get('argument-bindings'),indent=2)+'\\n')\n"+marker)
marker="    (root/'metadata-snapshot-stats.json').write_text";assert marker in s;s=s.replace(marker,"    (root/'bindings-after.json').write_text(json.dumps(get('argument-bindings'),indent=2)+'\\n')\n"+marker)
(p/'capture.py').write_text(s);(p/'analyze.py').write_bytes((parent/'analyze.py').read_bytes())
(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-binding-source-profile.py').read_bytes())
run='''from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
steps=[('build',['python3',str(p/'build-engine.py')]),('start',['python3',str(p/'start-engine.py')]),('first-use',['python3',str(p/'capture.py'),'--arm','before','--output',str(p/'capture-first-use')]),('warm-test',['python3',str(p/'capture.py'),'--arm','before','--output',str(p/'capture-warm-test'),'--edit-test-body']),('warm-source',['python3',str(p/'capture.py'),'--arm','before','--output',str(p/'capture-warm-source')])]
for label,command in steps:
 tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-2500:],flush=True);raise SystemExit(r.returncode)
'''
(p/'run.py').write_text(run)
import ast
for f in p.glob('*.py'):ast.parse(f.read_text())
print(p)
