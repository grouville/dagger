from pathlib import Path
import hashlib,json,subprocess,time,urllib.request
p=Path(__file__).parent
plan=json.loads((p/'engine-plan.json').read_text());build=json.loads((p/'engine-build.json').read_text())
assert build['exit_code']==0
binary=p/'dagger-engine';sha=hashlib.sha256(binary.read_bytes()).hexdigest();assert sha==build['sha256']
import socket
for port in plan['ports'].values():
 probe=socket.socket();probe.bind(('127.0.0.1',port));probe.close()
name=plan['new_engine'];assert not subprocess.check_output(['docker','ps','-aq','--filter','name=^/'+name+'$'],text=True).strip()
assert name not in subprocess.check_output(['docker','volume','ls','--format','{{.Name}}'],text=True).splitlines()
retained={}
for other,expected in [('dagger-collection-interface-index-oct18','0df377c84e39ae7f85914fa1eb6b8eeb425c7e50454cb55db8e4742db5c8e856'),('dagger-collection-recovery-reader-oct19','620a8bb52a9cce36604a9c5089453a8eada0f50c5a6f2e7653eb073004fedaa6'),('dagger-collection-direct-callback-oct19','c845d44dd9575f7e255924882eac445b4b7ffa2df702ab2cf685d7b380af94c0'),('dagger-collection-receiver-decode-oct18','3d1c4deeef3ca394ac64302263ff1d9a30b4b6e18c740ecb5b9d55ef64a784b1'),('dagger-collection-native-items-oct18','71fb69deb9262822ac5d989536000fb6176b9cfaa29b0143e4e4eaa5141f86fd'),('dagger-collection-content-oct18','053e9d5db9959b04259d48b8fc635721cfc7375652b43953010f767f7bf16118'),('dagger-rust-parser-state-pool-oct14','1a514c536c6bf10d2463faab2d4e4329f187dd4c0af5f46aba1cbe91460e2fb7')]:
 actual=subprocess.check_output(['docker','exec',other,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==expected;retained[other]=actual
assert subprocess.check_output(['docker','exec','dagger-collection-metadata-json-oct19','sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0]=='e5d9d9c9957bc9989cae8d0fbf9bbbfd559ace982be823431236486aace06cf6'
container=subprocess.check_output(['docker','create','--name',name,'--label','codex.task=binding-source-profile','--env','DANG_PROFILE_ARGUMENT_BINDINGS=true','--privileged','-p','127.0.0.1:16286:1234','-p','127.0.0.1:16114:6060','--mount','type=volume,source='+name+',target=/var/lib/dagger',plan['image'],*plan['command']],text=True).strip()
subprocess.run(['docker','cp',str(binary),name+':/usr/local/bin/dagger-engine'],check=True)
subprocess.run(['docker','cp',str(p.parent/'go-cold-listing/filesync-snapshot-seeds-mode'),name+':/tmp/filesync-snapshot-seeds-mode'],check=True)
subprocess.run(['docker','start',name],check=True)
debug='http://127.0.0.1:16114/debug/'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=10) as f:return json.load(f)
deadline=time.monotonic()+90
while True:
 try:assert not get('wcprof/enabled')['global_enabled'];break
 except OSError:assert time.monotonic()<deadline;time.sleep(.1)
for route,enabled in plan['flags'].items():assert get(route+'?enabled='+str(enabled).lower(),b'')['enabled']==enabled
actual=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==sha
record=dict(engine=name,container_id=container,sha256=sha,volume=name,new_empty_volume=True,retained_engines=retained,flags={r:get(r)['enabled'] for r in plan['flags']})
(p/'activation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(engine=name,sha256=sha,ready=True)),flush=True)
