from pathlib import Path
from collections import Counter
import json,subprocess
p=Path(__file__).parent;results={}
def key(row):return (row['file'],row['line'],row['column'],tuple(row['parameters'] or []),row['block'])
for label in ['first-use','warm-test','warm-source']:
 root=p/('capture-'+label)
 before={key(r):r for r in json.loads((root/'bindings-before.json').read_text())['rows']};rows=[]
 for row in json.loads((root/'bindings-after.json').read_text())['rows']:
  old=before.get(key(row),{});entry=dict(row);entry['calls']-=old.get('calls',0);entry['parameter_slots']-=old.get('parameter_slots',0)
  if entry['calls']:rows.append(entry)
 rows.sort(key=lambda r:r['parameter_slots'],reverse=True)
 summary=dict(calls=sum(r['calls'] for r in rows),parameter_slots=sum(r['parameter_slots'] for r in rows),rows=rows)
 (root/'binding-delta.json').write_text(json.dumps(summary,indent=2)+'\n')
 with (root/'analysis.log').open('w') as out:r=subprocess.run(['python3',str(p/'analyze.py'),str(root)],stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==0
 attribution=json.loads((root/'attribution.json').read_text());summary['function_evaluations']=attribution['function_evaluations'];summary['getters']=attribution['selected_calls']['go:GoPackages.get'];summary['discoveries']=attribution['selected_calls']['go:GoPackage.tests'];assert attribution['dropped']==0 and attribution['open_ops']==0
 results[label]=summary
 print(label,json.dumps({k:summary[k] for k in ['calls','parameter_slots','function_evaluations','getters','discoveries']}),flush=True)
 for row in rows[:12]:print(json.dumps(row),flush=True)
(p/'assessment.json').write_text(json.dumps(results,indent=2)+'\n')
