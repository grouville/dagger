from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
steps=[('build',['python3',str(p/'build-engine.py')]),('start',['python3',str(p/'start-engine.py')]),('first-use',['python3',str(p/'capture.py'),'--arm','before','--output',str(p/'capture-first-use')]),('warm-test',['python3',str(p/'capture.py'),'--arm','before','--output',str(p/'capture-warm-test'),'--edit-test-body']),('warm-source',['python3',str(p/'capture.py'),'--arm','before','--output',str(p/'capture-warm-source')])]
for label,command in steps:
 tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-2500:],flush=True);raise SystemExit(r.returncode)
