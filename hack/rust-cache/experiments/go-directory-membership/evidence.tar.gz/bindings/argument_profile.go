package dang

import (
	"encoding/json"
	"net/http"
	"os"
	"sort"
	"sync"
	"sync/atomic"
)

// Diagnostic only. Keys identify declarations, never argument values or clients.
var argumentProfileEnabled = os.Getenv("DANG_PROFILE_ARGUMENT_BINDINGS") == "true"
var argumentProfiles sync.Map

type argumentProfileKey struct {
	location   *SourceLocation
	parameters int
	block      bool
}

type argumentProfileCount struct {
	file         string
	line, column int
	names        []string
	block        bool
	calls        atomic.Uint64
}

func recordArgumentBinding(fn FunctionValue) {
	if !argumentProfileEnabled {
		return
	}
	var loc *SourceLocation
	if fn.Body != nil {
		loc = fn.Body.GetSourceLocation()
	}
	key := argumentProfileKey{loc, len(fn.Args), fn.IsBlockArg}
	value, found := argumentProfiles.Load(key)
	if !found {
		entry := &argumentProfileCount{names: append([]string(nil), fn.Args...), block: fn.IsBlockArg}
		if loc != nil {
			entry.file, entry.line, entry.column = loc.Filename, loc.Line, loc.Column
		}
		value, _ = argumentProfiles.LoadOrStore(key, entry)
	}
	value.(*argumentProfileCount).calls.Add(1)
}

func ArgumentBindingProfileDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "GET required", http.StatusMethodNotAllowed)
		return
	}
	type row struct {
		File           string   `json:"file"`
		Line           int      `json:"line"`
		Column         int      `json:"column"`
		Parameters     []string `json:"parameters"`
		Block          bool     `json:"block"`
		Calls          uint64   `json:"calls"`
		ParameterSlots uint64   `json:"parameter_slots"`
	}
	rows := []row{}
	argumentProfiles.Range(func(_, value any) bool {
		count := value.(*argumentProfileCount)
		calls := count.calls.Load()
		rows = append(rows, row{count.file, count.line, count.column, count.names, count.block, calls, calls * uint64(len(count.names))})
		return true
	})
	sort.Slice(rows, func(i, j int) bool { return rows[i].ParameterSlots > rows[j].ParameterSlots })
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": argumentProfileEnabled, "rows": rows})
}
