from pathlib import Path
import json,statistics,subprocess,time
p=Path(__file__).parent;steps=[];assessment={}
for count in [1,16]:
 command=['python3',str(p/f'measure-small-{count}.py'),'--output',str(p/f'small-{count}'),'--fixture','real','--arms','before','combined','--pairs','4'];tick=time.monotonic()
 with (p/f'small-{count}-driver.log').open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(modules=count,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'small-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(count,(p/f'small-{count}-driver.log').read_text()[-1500:])
 samples=json.loads((p/f'small-{count}/samples.json').read_text());pairs=[]
 for block in range(2,6):
  by_arm={r['arm']:r for r in samples if r['block']==block};pairs.append(by_arm['before']['seconds']-by_arm['combined']['seconds'])
 assessment[str(count)]=dict(medians=json.loads((p/f'small-{count}/summary.json').read_text()),paired_seconds=pairs,faster_pairs=sum(s>0 for s in pairs),all_correct=all(r['exit_code']==0 and r['correct_names'] and r['same_full_rows'] for r in samples),commands=len(samples))
 (p/'small-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');print(json.dumps(assessment[str(count)]),flush=True)
