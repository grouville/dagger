from pathlib import Path
import json,subprocess,urllib.request
base=Path('/tmp/rust-cache-sipsma-review');p=base/'go-generation-native-membership'
previous=json.loads((base/'parallel-admission-local-discovery/final-state.json').read_text())
expected=dict(previous['binaries'])
for name,study in [('dagger-collection-bind-profile-oct19','go-binding-source-profile'),('dagger-collection-linear-merge-oct19','linear-map-merge-engine')]:
 expected[name]=json.loads((base/study/'engine-build.json').read_text())['sha256']
binaries={};volumes={}
for name,want in expected.items():
 actual=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==want,name;binaries[name]=actual
 record=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
 volumes[name]=[dict(name=m.get('Name'),destination=m['Destination']) for m in record['Mounts'] if m['Type']=='volume']
 assert volumes[name]==previous['volumes'].get(name,[dict(name=name,destination='/var/lib/dagger')]),name

def get(port,route):
 with urllib.request.urlopen(f'http://127.0.0.1:{port}/debug/{route}',timeout=15) as f:return json.load(f)
states={}
for label,port in [('previous-benchmark',16112),('reduction-diagnostic',16113),('binding-diagnostic',16114),('merge-benchmark',16115)]:
 flags={r:get(port,r) for r in previous['states']['benchmark']['flags']}
 for route,want in previous['states']['benchmark']['flags'].items():assert flags[route]['enabled']==want['enabled'],(label,route,flags[route],want)
 assert not flags['metadata-snapshot-json']['record']
 if port==16115:flags['linear-map-merge']=get(port,'linear-map-merge');assert not flags['linear-map-merge']['enabled']
 lifecycle=get(port,'client-lifecycle');assert lifecycle['active_requests']==0 and lifecycle['runtimes']==0,(label,lifecycle)
 assert all(s['state']=='removed' for s in (lifecycle.get('sessions') or [])),label
 assert not get(port,'wcprof/enabled')['global_enabled'];assert get(port,'lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
 states[label]=dict(flags=flags,lifecycle=lifecycle,wcprof=get(port,'wcprof/enabled'),lock_profiler=get(port,'lock-profiler'))
for repo in ['/tmp/dagger-go-real-repository-main','/tmp/dagger-go-discovery-generate-matches','/tmp/dang-map-merge-linear']:
 assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b'',repo
state=dict(binaries=binaries,volumes=volumes,states=states,real_workspace_clean=True,selected_module_clean=True,all_engines_and_volumes_retained=True,no_pr_opened=True,diagnostic_environment_retained=['DANG_PROFILE_LIST_REDUCTIONS=true','DANG_PROFILE_ARGUMENT_BINDINGS=true'])
(p/'final-state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(engines=len(binaries),restored=True,active_requests=0)),flush=True)
