from pathlib import Path
import json,statistics,subprocess,time
p=Path(__file__).parent;steps=[]
for label,command in [('test-eight-pairs',['python3',str(p/'measure-test-edits.py'),'--output',str(p/'test-edit-follow-up'),'--fixture','real','--arms','before','combined','--pairs','8']),('small-fixtures',['python3',str(p/'run-small.py')])]:
 tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'follow-up-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert r.returncode==0,(label,(p/(label+'-driver.log')).read_text()[-2000:])
 if label=='test-eight-pairs':
  samples=json.loads((p/'test-edit-follow-up/samples.json').read_text());pairs=[]
  for block in range(2,10):
   arm={r['arm']:r for r in samples if r['block']==block};pairs.append(arm['before']['seconds']-arm['combined']['seconds'])
  d=dict(medians=json.loads((p/'test-edit-follow-up/summary.json').read_text()),paired_seconds=pairs,median_paired_saving=statistics.median(pairs),faster_pairs=sum(v>0 for v in pairs),all_correct=all(r['exit_code']==0 and r['correct_names'] and r['same_full_rows'] for r in samples),commands=len(samples),reason='Predeclared fixed eight-pair follow-up because four-pair baseline latency varied relative to earlier cohorts. No samples discarded or pooled.')
  a=json.loads((p/'assessment.json').read_text());a['test_follow_up']=d;(p/'assessment.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(d),flush=True)
