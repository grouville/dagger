from pathlib import Path
import ast,json
base=Path('/tmp/rust-cache-sipsma-review');p=base/'go-generation-native-membership';p.mkdir(exist_ok=False);parent=base/'go-generation-directory-index'
for name in ['measure-source-edits.py','measure-test-edits.py','measure.py','capture.py','capture-all.py','analyze.py','analyze-all.py','verify-module.py','prepare-small.py','run.py']:
 s=(parent/name).read_text().replace('go-generation-directory-index','go-generation-native-membership')
 s=s.replace("mode('linear-map-merge',True)","mode('linear-map-merge',False)").replace("get('linear-map-merge?enabled=true',b'')","get('linear-map-merge?enabled=false',b'')")
 s=s.replace('linear_map_merge=True,generation_directory_index=', 'linear_map_merge=False,generation_native_membership=')
 s=s.replace('Both modes use linear native map merging. Only directory-match membership changes from list scanning to a balanced-built map.', 'Both modes use the original native map merging. Directory membership uses the existing List.contains instead of a pure equality callback inside List.any; both use the same string equality implementation.')
 (p/name).write_text(s);ast.parse(s)
(p/'identity.json').write_text(json.dumps(dict(baseline='/tmp/dagger-go-discovery-generate-matches',candidate='/tmp/dagger-go-generation-native-membership',engine='/tmp/rust-cache-sipsma-review/linear-map-merge-engine/dagger-engine',linear_map_merge=False,scope='Use existing native equality membership for immutable string arrays. Globs, include/exclude rules and all collection getters stay in place.',equality='List.contains and == both use valuesEqual; StringValue compares Val == Val.',new_api=False,new_cache=False),indent=2)+'\n')
(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-native-membership-study.py').read_bytes())
print(p)
