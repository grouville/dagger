from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
base=Path('/tmp/rust-cache-sipsma-review');p=base/'go-generation-native-membership';root=p/'evidence-root'
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-directory-membership')
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def ignore(directory,names):return [n for n in names if n in {'__pycache__','.git','dagger-engine','wcprof-complete.ndjson','evidence-root','archive-driver.log'} or n.endswith('.test')]
import sys
if '--resume-after-captures' in sys.argv:
 reconstruction=json.loads((root/'wcprof-reconstruction.json').read_text());assert len(reconstruction)==15
 assert not (out/'evidence.tar.gz').exists()
else:
 root.mkdir(exist_ok=False);out.mkdir(exist_ok=False);reconstruction=[]
 for label,source in [('bindings',base/'go-binding-source-profile'),('map-component',base/'map-merge-linear-current'),('map-engine',base/'linear-map-merge-engine'),('directory-index',base/'go-generation-directory-index'),('native-membership',p)]:
  for complete in sorted(source.glob('capture-*/wcprof-complete.ndjson')):
   folder=complete.parent;events=[];chunks=sorted(folder.glob('chunk-*.ndjson.gz'));assert chunks
   for chunk in chunks:
    with gzip.open(chunk,'rb') as stream:header=json.loads(stream.readline());events.extend(stream.readlines())
    assert header['dropped_events']==0
   assert not header.get('open_ops');header['event_count']=len(events)
   rebuilt=(json.dumps(header)+'\n').encode()+b''.join(events);assert rebuilt==complete.read_bytes()
   reconstruction.append(dict(capture=label+'/'+folder.name,chunks=[c.name for c in chunks],events=len(events),sha256=sha(rebuilt),exact_bytes_verified=True))
  shutil.copytree(source,root/label,ignore=ignore)
 assert len(reconstruction)==15,len(reconstruction)
 write(root/'wcprof-reconstruction.json',reconstruction)
# The allocation caller reports extend the preceding audit without recopying it.
alloc=root/'binding-callers';alloc.mkdir(exist_ok=True)
for name in ['bindings-callers.txt','derivations-callers.txt','converter-callers.txt','overlay-bind-callers.txt','overlay-derive-callers.txt']:
 shutil.copyfile(base/'go-getter-allocation-current/capture'/name,alloc/name)
parents={}
for name in ['sealed-metadata-json-engine','go-generation-discovery','parallel-admission-local-discovery']:
 d=out.parent/name;record=json.loads((d/'archive.json').read_text());assert sha((d/'evidence.tar.gz').read_bytes())==record['sha256'];parents[name]=dict(path='../'+name+'/evidence.tar.gz',**record)
write(root/'source-parents.json',parents)
parent=base/'sealed-metadata-json-engine';old_overlay=json.loads((parent/'overlay.json').read_text())['Replace']
manifest=json.loads((out.parent/'sealed-metadata-json-engine/build-source-manifest.json').read_text())
for label,study in [('bindings','go-binding-source-profile'),('map-engine','linear-map-merge-engine')]:
 overlay=json.loads((base/study/'overlay.json').read_text())['Replace'];full=[];changed=[];dest=root/'engine-source-deltas'/label;dest.mkdir(parents=True)
 for row in manifest:
  actual=Path(overlay.get(row['original'],row['actual']));data=actual.read_bytes();entry=dict(row,actual=str(actual),sha256=sha(data),bytes=len(data))
  if entry['sha256']!=row['sha256']:
   filename=f'{len(changed):04d}-'+actual.name;(dest/filename).write_bytes(data);entry.update(parent_sha256=row['sha256'],archived=str((dest/filename).relative_to(root)));changed.append(entry)
  full.append(entry)
 known={r['original'] for r in manifest}
 for original,value in overlay.items():
  if original in known:continue
  actual=Path(value);old=Path(old_overlay.get(original,original))
  if old.exists() and actual.read_bytes()==old.read_bytes():continue
  data=actual.read_bytes();filename=f'{len(changed):04d}-'+actual.name;(dest/filename).write_bytes(data)
  changed.append(dict(original=original,actual=value,bytes=len(data),sha256=sha(data),archived=str((dest/filename).relative_to(root)),additional_test_or_production_input=True))
 assert len(changed)==(3 if label=='bindings' else 5),(label,len(changed))
 write(dest/'delta.json',changed);write(dest/'build-source-manifest.json',full)
# Retain standalone sources and review patches independently of large parents.
identities={}
for label,repo,ref,names in [('dang','/tmp/dang-map-merge-linear','da1bed304cb80f8a2f0714f1747e7f64e03297a3',['pkg/dang/eval.go','pkg/dang/stdlib.go','pkg/dang/map_merge_test.go']),('directory-index','/tmp/dagger-go-generation-directory-index','511d38145daf87b531e44ed9b1c3b641fbe89ba3',['go.dang']),('native-membership','/tmp/dagger-go-generation-native-membership','511d38145daf87b531e44ed9b1c3b641fbe89ba3',['go.dang'])]:
 repo=Path(repo);dest=root/'source'/label;dest.mkdir(parents=True)
 patch=subprocess.check_output(['git','diff','--binary',ref],cwd=repo);(dest/'change.patch').write_bytes(patch)
 for name in names:
  f=dest/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((repo/name).read_bytes())
 identities[label]=dict(path=str(repo),base=ref,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),patch_sha256=sha(patch),status=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True))
write(root/'source-identities.json',identities)
files=[f for f in sorted(root.rglob('*')) if f.is_file()];manifest=[dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files];mbytes=(json.dumps(manifest,indent=2)+'\n').encode();arc=out/'evidence.tar.gz'
with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(root)));info.mtime=0
  with f.open('rb') as stream:tar.addfile(info,stream)
 info=tarfile.TarInfo('manifest.json');info.size=len(mbytes);info.mtime=0;tar.addfile(info,io.BytesIO(mbytes))
with tarfile.open(arc,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
(out/'manifest.json').write_bytes(mbytes)
for name in ['wcprof-reconstruction.json','source-identities.json','source-parents.json']:(out/name).write_bytes((root/name).read_bytes())
for label in ['bindings','map-component','map-engine','directory-index','native-membership']:
 (out/(label+'-assessment.json')).write_bytes((root/label/'assessment.json').read_bytes())
(out/'final-state.json').write_bytes((p/'final-state.json').read_bytes())
(out/'dang.patch').write_bytes((root/'source/dang/change.patch').read_bytes());(out/'module.patch').write_bytes((root/'source/native-membership/change.patch').read_bytes())
record=dict(bytes=arc.stat().st_size,sha256=sha(arc.read_bytes()),members=len(files)+1,all_member_hashes_verified=True,lossless_streams_reconstructed=len(reconstruction),binaries_excluded=True)
write(out/'archive.json',record);print(json.dumps(record),flush=True)
