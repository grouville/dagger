module example.com/mod7

go 1.26.6
