module example.com/mod4

go 1.26.6
