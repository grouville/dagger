module example.com/mod12

go 1.26.6
