module example.com/mod15

go 1.26.6
