module example.com/mod13

go 1.26.6
