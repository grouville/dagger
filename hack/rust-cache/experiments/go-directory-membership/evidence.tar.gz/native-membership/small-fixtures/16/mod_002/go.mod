module example.com/mod2

go 1.26.6
