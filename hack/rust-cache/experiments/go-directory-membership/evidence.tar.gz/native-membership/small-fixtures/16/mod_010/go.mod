module example.com/mod10

go 1.26.6
