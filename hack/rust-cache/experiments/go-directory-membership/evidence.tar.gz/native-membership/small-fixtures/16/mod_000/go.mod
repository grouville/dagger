module example.com/mod0

go 1.26.6
