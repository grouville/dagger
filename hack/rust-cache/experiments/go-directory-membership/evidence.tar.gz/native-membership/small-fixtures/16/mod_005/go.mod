module example.com/mod5

go 1.26.6
