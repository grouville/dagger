module example.com/mod3

go 1.26.6
