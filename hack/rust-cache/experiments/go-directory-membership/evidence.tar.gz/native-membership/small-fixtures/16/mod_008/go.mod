module example.com/mod8

go 1.26.6
