module example.com/sharedmatches

go 1.26.6
