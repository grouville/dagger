from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;repo=Path('/tmp/dang-map-merge-linear');source=repo/'pkg/dang/eval.go';text=source.read_text()
start=text.index('func (m MapValue) Merge(');end=text.index('\nfunc (m MapValue) Without(',start)
original='''func (m MapValue) Merge(other MapValue) MapValue {
 result := m
 for _, key := range other.Keys { result = result.With(key, other.Entries[key]) }
 return result
}
'''
(p/'before-eval.go').write_text(text[:start]+original+text[end:]);(p/'overlay-before.json').write_text(json.dumps({'Replace':{str(source):str(p/'before-eval.go')}},indent=2)+'\n')
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');rows=[]
def run(label,args):
 command=[go,*args];tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'.log')).read_text()[-2500:],flush=True);raise SystemExit(r.returncode)
for arm in ['before','candidate']:
 overlay=['-overlay='+str(p/'overlay-before.json')] if arm=='before' else []
 run(arm+'-race',['test','-p=2',*overlay,'-race','-count=1','./pkg/dang'])
for pair in range(4):
 for arm in (['before','candidate'] if pair%2==0 else ['candidate','before']):
  overlay=['-overlay='+str(p/'overlay-before.json')] if arm=='before' else []
  run(f'bench-{pair}-{arm}',['test','-p=2',*overlay,'-run=^$','-bench=^BenchmarkMapMerge$','-benchtime=100ms','-benchmem','-count=1','./pkg/dang'])
