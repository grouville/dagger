from pathlib import Path
import json,subprocess
repo=Path('/tmp/dang-map-merge-linear');p=Path('/tmp/rust-cache-sipsma-review/map-merge-linear-current');identity={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'repository':'https://github.com/vito/dang','go':'1.26.6'};(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
file=repo/'pkg/dang/eval.go';s=file.read_text();marker='func (m MapValue) Without(';i=s.index(marker)
method='''// Merge returns a new map, preserving left-hand key positions and appending
// new right-hand keys in order. Right-hand values win on overlapping keys.
func (m MapValue) Merge(other MapValue) MapValue {
 if len(other.Keys) == 0 { return m }
 keys := make([]string, len(m.Keys), len(m.Keys)+len(other.Keys))
 copy(keys, m.Keys)
 entries := make(map[string]Value, len(m.Entries)+len(other.Keys))
 for key, value := range m.Entries { entries[key] = value }
 for _, key := range other.Keys {
  if _, exists := entries[key]; !exists { keys = append(keys, key) }
  entries[key] = other.Entries[key]
 }
 return MapValue{Keys: keys, Entries: entries, ValType: m.ValType}
}

'''
s=s[:i]+method+s[i:];file.write_text(s)
file=repo/'pkg/dang/stdlib.go';s=file.read_text();old='''			result := m
			for _, k := range other.Keys {
				result = result.With(k, other.Entries[k])
			}
			return result, nil''';assert s.count(old)==1;s=s.replace(old,'\t\t\treturn m.Merge(other), nil');file.write_text(s)
(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-linear-map-merge.py').read_bytes())
print('Linear merge prepared on',identity['base'])
