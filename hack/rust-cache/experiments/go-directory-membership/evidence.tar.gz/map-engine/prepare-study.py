from pathlib import Path
import json
base=Path('/tmp/rust-cache-sipsma-review');p=base/'linear-map-merge-engine';p.mkdir(exist_ok=False);parent=base/'sealed-metadata-json-engine';diag=base/'go-reduction-source-profile'
src=base/'dang-lazy-eval-error-context/controlled-eval.go';text=src.read_text();candidate=(Path('/tmp/dang-map-merge-linear/pkg/dang/eval.go')).read_text();start=candidate.index('func (m MapValue) Merge(');end=candidate.index('\nfunc (m MapValue) Without(',start);method=candidate[start:end];assert 'func (m MapValue) Merge(' not in text;at=text.index('func (m MapValue) Without(');text=text[:at]+method+'\n'+text[at:];(p/'eval.go').write_text(text)
srcstd=base/'dang-native-string-sort/engine-stdlib-after.go';text=srcstd.read_text();old='''			result := m
			for _, k := range other.Keys {
				result = result.With(k, other.Entries[k])
			}
			return result, nil''';assert text.count(old)==1;text=text.replace(old,'\t\t\tif linearMapMergeEnabled.Load() { return m.Merge(other), nil }\n'+old);(p/'stdlib.go').write_text(text)
(p/'mode.go').write_text('''package dang
import("encoding/json";"net/http";"os";"strconv";"sync/atomic")
var linearMapMergeEnabled atomic.Bool
func init(){linearMapMergeEnabled.Store(os.Getenv("DANG_TEST_LINEAR_MAP_MERGE")=="true")}
func LinearMapMergeDiagnostic(w http.ResponseWriter,r *http.Request){
 if r.Method==http.MethodPost {v,e:=strconv.ParseBool(r.URL.Query().Get("enabled"));if e!=nil{http.Error(w,e.Error(),400);return};linearMapMergeEnabled.Store(v)} else if r.Method!=http.MethodGet {http.Error(w,"GET or POST required",405);return}
 w.Header().Set("Content-Type","application/json");_ = json.NewEncoder(w).Encode(map[string]any{"enabled":linearMapMergeEnabled.Load()})
}
''')
o=json.loads((parent/'overlay.json').read_text());evalkey=next(k for k,v in o['Replace'].items() if v==str(src));stdkey=next(k for k,v in o['Replace'].items() if v==str(srcstd));o['Replace'][evalkey]=str(p/'eval.go');o['Replace'][stdkey]=str(p/'stdlib.go');o['Replace'][str(Path(evalkey).parent/'linear_map_merge_mode.go')]=str(p/'mode.go');o['Replace'][str(Path(evalkey).parent/'map_merge_test.go')]=str(Path('/tmp/dang-map-merge-linear/pkg/dang/map_merge_test.go'))
s=(parent/'engine-debug.go').read_text();marker='m.HandleFunc("/debug/evaluation-context", dang.EvaluationContextDiagnostic)';assert marker in s;s=s.replace(marker,marker+'\n\tm.HandleFunc("/debug/linear-map-merge", dang.LinearMapMergeDiagnostic)');(p/'engine-debug.go').write_text(s);debugkey=next(k for k,v in o['Replace'].items() if v==str(parent/'engine-debug.go'));o['Replace'][debugkey]=str(p/'engine-debug.go');(p/'overlay.json').write_text(json.dumps(o,indent=2)+'\n')
plan=json.loads((parent/'engine-plan.json').read_text());plan.update(new_engine='dagger-collection-linear-merge-oct19',ports={'runner':16287,'debug':16115},scenario='Controlled linear Map.merge. Current Go module 511d381 in both arms; directory index tested separately afterward.');plan['flags']['linear-map-merge']=False;(p/'engine-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(diag/'build-engine.py').read_text().replace("DANG_PROFILE_LIST_REDUCTIONS='true'","DANG_TEST_LINEAR_MAP_MERGE='true'").replace("'DANG_PROFILE_LIST_REDUCTIONS'","'DANG_TEST_LINEAR_MAP_MERGE'");(p/'build-engine.py').write_text(s)
s=(diag/'start-engine.py').read_text().replace('16285','16287').replace('16113','16115').replace("'--env','DANG_PROFILE_LIST_REDUCTIONS=true',",'').replace('codex.task=reduction-source-profile','codex.task=linear-map-merge');(p/'start-engine.py').write_text(s)
# Build-time unit mode is on; runtime mode starts off and is controlled per arm.
old=base/'parallel-admission-local-discovery'
for name in ['measure-source-edits.py','measure-test-edits.py','measure.py','capture.py','capture-all.py','analyze.py','analyze-all.py','verify-module.py','verify-rust.py','rust-cache-query.py']:
 s=(old/name).read_text().replace('16284','16287').replace('16112','16115').replace('dagger-collection-metadata-json-oct19','dagger-collection-linear-merge-oct19')
 # Keep parallel admission off; add the independent map-merge mode to restoration lists.
 s=s.replace("mode('parallel-client-admission',arm=='combined')","mode('parallel-client-admission',False)\n            mode('linear-map-merge',arm=='combined')")
 s=s.replace("mode('parallel-client-admission',options.arm=='candidate')","mode('parallel-client-admission',False)\n    mode('linear-map-merge',options.arm=='candidate')")
 s=s.replace("get('parallel-client-admission?enabled='+str(arm=='candidate').lower(),b'')","get('parallel-client-admission?enabled=false',b'')\n  get('linear-map-merge?enabled='+str(arm=='candidate').lower(),b'')")
 s=s.replace("'metadata-snapshot-json','parallel-client-admission']","'metadata-snapshot-json','parallel-client-admission','linear-map-merge']")
 # The mode is explicitly set per arm, not in the common settings loop.
 s=s.replace("'linear-map-merge']).lower()","'linear-map-merge']).lower()")
 s=s.replace('parallel_client_admission=arm==\'combined\'','parallel_client_admission=False,linear_map_merge=arm==\'combined\'').replace("parallel_client_admission=options.arm=='candidate'","parallel_client_admission=False,linear_map_merge=options.arm=='candidate'")
 s=s.replace('Only parallel nested-client admission changes; per-client serialization, initialization, permissions, leases, telemetry and full cleanup remain.','Only native map merging changes; client admission, initialization, permissions, leases, telemetry and full cleanup remain.')
 s=s.replace("str(p.parent/'sealed-metadata-json-engine/dagger-engine')","str(p/'dagger-engine')")
 s=s.replace("Path('/tmp/rust-cache-sipsma-review/sealed-metadata-json-engine/engine-build.json')","Path('/tmp/rust-cache-sipsma-review/linear-map-merge-engine/engine-build.json')")
 (p/name).write_text(s)
# Profiling metadata counter key must remain scalar.
assert "flags['metadata-snapshot-json','" not in (p/'capture.py').read_text()
# Correct common loops: neither mode is enabled until its arm is selected.
for name in ['verify-module.py','verify-rust.py']:
 f=p/name;s=f.read_text();s=s.replace("'metadata-snapshot-json','parallel-client-admission','linear-map-merge']).lower()","'metadata-snapshot-json','parallel-client-admission','linear-map-merge']).lower()")
 f.write_text(s)
(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-linear-merge-engine.py').read_bytes())
import ast
for f in p.glob('*.py'):ast.parse(f.read_text())
print(p)
