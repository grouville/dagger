from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
import time

p = Path(__file__).parent
sources = {'native-inputs': p, 'layout-key': p.parent / 'go-module-layout-key'}
destination = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/native-go-test-discovery')
destination.mkdir(exist_ok=False)
for group, name in [('native-inputs','capture-reused'), ('native-inputs','capture-test-edit'), ('layout-key','capture-fixed-test-edit')]:
    capture = sources[group] / name
    trace = capture / 'wcprof-complete.ndjson'
    identity = dict(bytes=trace.stat().st_size, sha256=hashlib.sha256(trace.read_bytes()).hexdigest())
    (capture / 'trace-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    subprocess.run(['python3', str(p / 'assemble-traces.py'), str(capture)], check=True)

members = []
def payload(row):
    data = (sources[row['group']] / row['source_path']).read_bytes()
    return gzip.decompress(data) if row['decoded_gzip'] else data

for group, directory in sources.items():
    for filename in sorted(directory.rglob('*')):
        if not filename.is_file() or '__pycache__' in filename.parts:
            continue
        if filename.name == 'wcprof-complete.ndjson':
            continue
        relative = filename.relative_to(directory)
        decoded = filename.name.startswith('chunk-') and filename.name.endswith('.ndjson.gz')
        name = str(relative)[:-3] if decoded else str(relative)
        row = dict(path=group + '/' + name, group=group, source_path=str(relative), decoded_gzip=decoded)
        data = payload(row)
        row.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        members.append(row)

archive = destination / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as output:
    for row in members:
        data = payload(row)
        info = tarfile.TarInfo('evidence/' + row['path'])
        info.size = len(data)
        info.mode = 0o644
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:*') as stored:
    assert len(stored.getmembers()) == len(members)
    for row in members:
        with stored.extractfile('evidence/' + row['path']) as stream:
            assert hashlib.sha256(stream.read()).hexdigest() == row['sha256']

manifest = dict(
    created_unix=time.time(), archive=archive.name,
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    archive_bytes=archive.stat().st_size, verified_members=len(members),
    uncompressed_member_bytes=sum(row['bytes'] for row in members),
    scope='Real native Directory-input prototype and independent ownership-key correction. Four matched ten-command cohorts, all focused and full module checks, failing baseline regression, setup failures, exact source snapshots and commit patches, lossless captures and restoration. Direct API argument type changes; test-file edits remain mixed. No engine replacement or new PR.',
    inherited_engine_context='../typed-artifact-metadata/',
    trace_storage='Original dump bytes stored as raw chunk-*.ndjson members inside the xz archive. Duplicate combined files and their outer gzip wrappers are omitted. assemble-traces.py recreates each exact combined trace and verifies byte count and SHA256.',
    members=members,
)
(destination / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
(destination / 'README.md').write_text("""# Native Go test discovery inputs

See [the assessment](../../NATIVE_GO_NATIVE_TEST_DISCOVERY.md) and [guard review description](../../PR_GO_MODULE_LAYOUT_KEY.md). Complete real listing after ordinary Go source edits improves 19.70 → 9.30 seconds median, faster in all four pairs. Test-file edits remain mixed, with a median paired regression; the repository-wide snapshot is too broad. The direct argument type changes from Workspace to Directory, so the combined prototype remains unselected.

The archive contains all forty commands across four cohorts: the initial Directory-only experiment, the isolated ownership correction, the final ordinary-source comparison, and the final test-file-edit comparison. All source identities, three commit patches, exact source snapshots, twenty-four passing combined Go checks, the six focused standalone guard checks, the failing baseline regression and two setup mistakes are retained.

Separate lossless captures verify 800 child cache hits with a reused snapshot, 800 child executions after a test-file edit, and 800 → 0 fallback ownership calls with the corrected key. Main-query reports distinguish its path from unrelated outer operations. Original dump records are stored as raw chunk-*.ndjson files within the archive. After extraction run `python3 evidence/native-inputs/assemble-traces.py evidence/native-inputs/capture-reused`, substituting `evidence/native-inputs/capture-test-edit` or `evidence/layout-key/capture-fixed-test-edit` as required. Exact combined trace bytes and SHA256 are checked. Duplicate combined files and gzip wrappers are omitted.

MANIFEST.json verifies every member and the archive. Engine and CLI sources are inherited from [typed metadata](../typed-artifact-metadata/). The baseline module is 0b487434; prototype revisions and fork links are in the assessment and source-provenance.json. Original local paths and the telemetry receiver require adapting for replay. Binaries, credentials and the engine volume are excluded. No PR is open.
""")
print(json.dumps({k:manifest[k] for k in ['archive_bytes','verified_members','uncompressed_member_bytes','archive_sha256']}), flush=True)
