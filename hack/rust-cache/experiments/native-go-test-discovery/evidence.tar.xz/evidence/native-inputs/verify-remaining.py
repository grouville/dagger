from pathlib import Path
import json, os, subprocess, time

p=Path(__file__).parent
base=p.parent
module=Path('/tmp/dagger-go-native-test-discovery')
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16276',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows=[]
for check in ['go-dev:discovery-from-subdir-check', 'go-dev:collection-check', 'go-dev:binary-check', 'go-dev:single-module-check', 'go-dev:per-module-directive-check', 'go-dev:nested-module-directive-check', 'go-dev:go-mod-replace-check', 'go-dev:cgo-cxx-check', 'go-dev:goflags-check', 'go-dev:mount-path-check', 'go-dev:named-failure-check', 'go-dev:go-version-check', 'go-dev:skips-non-modules-check', 'go-dev:base-check', 'go-dev:module-introspection-check', 'go-dev:generate-check', 'go-dev:regenerate-check', 'go-dev:generation-globs-check', 'go-dev:selection-check', 'go-dev:generation-container-check', 'go-dev:generation-container-errors-check']:
    tick=time.monotonic();label=check.replace(':','-')
    with (p/('remaining-'+label+'.log')).open('w') as output:result=subprocess.run(['python3',str(base/'local_cli_collector.py'),'check',check],cwd=module,env=env,stdout=output,stderr=subprocess.STDOUT)
    row=dict(check=check,seconds=time.monotonic()-tick,exit_code=result.returncode)
    rows.append(row);(p/'remaining-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==0,check
