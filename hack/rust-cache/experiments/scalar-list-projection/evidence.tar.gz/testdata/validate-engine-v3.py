from pathlib import Path
import json,os,subprocess,time,hashlib
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';modfile='/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
steps=[('v3-retained-before',['python3','/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py','scalar-list-projection-v3-before'],None),
 ('v3-full-dagql-race',[go,'test','-p','2','-buildvcs=false','-modfile',modfile,'-overlay',str(p/'engine-v3-test-overlay.json'),'-race','-count=1','./dagql'],'/tmp/dagger-filesync-snapshot-seeds'),
 ('v3-engine-build',[go,'build','-p','2','-buildvcs=false','-modfile',modfile,'-overlay',str(p/'engine-v3-overlay.json'),'-o',str(p/'dagger-engine-v3'),'./cmd/engine'],'/tmp/dagger-filesync-snapshot-seeds'),
 ('shutdown-cpu-analysis',[go,'tool','pprof','-top','-cum','-nodecount=40','/tmp/rust-cache-sipsma-review/trivial-scalar-projection/dagger-engine',str(p/'v2-graceful-restart/shutdown-cpu.pprof')],None)]
rows=[]
for label,command,cwd in steps:
 begin=time.monotonic()
 with (p/(label+'.log')).open('w') as f:result=subprocess.run(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
 if label=='v3-engine-build' and result.returncode==0:row['sha256']=hashlib.sha256((p/'dagger-engine-v3').read_bytes()).hexdigest()
 rows.append(row);(p/'engine-v3-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,result.returncode,round(row['seconds'],3),flush=True)
 if result.returncode:print((p/(label+'.log')).read_text()[-6000:],flush=True)
 assert result.returncode==0
