from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import urllib.error
import urllib.request

p = Path(__file__).parent
engine = 'dagger-rust-parser-state-pool-oct14'
debug = 'http://127.0.0.1:16104/debug/'
validation = json.loads((p / 'engine-v3-validation.json').read_text())
assert len(validation) == 4 and all(row['exit_code'] == 0 for row in validation)
assert json.loads((p / 'marker-regression.json').read_text())[1]['exit_code'] == 0
binary = p / 'dagger-engine-v3'
candidate_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
assert candidate_sha == validation[2]['sha256']
before_sha = subprocess.check_output(
    ['docker', 'exec', engine, 'sha256sum', '/usr/local/bin/dagger-engine'], text=True).split()[0]
assert before_sha == '92829031bb01fb23c4c786a8a7b67ab7767ad0f7289a9c7484fa75eb162859c5'
before_mounts = json.loads(subprocess.check_output(['docker', 'inspect', engine]))[0]['Mounts']

def get(route, data=None):
    with urllib.request.urlopen(urllib.request.Request(debug + route, data=data), timeout=20) as response:
        return json.load(response)

def mode(route, enabled):
    result = get(route + '?enabled=' + str(enabled).lower(), b'')
    assert result['enabled'] == enabled, (route, result)

assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == {'mutex_fraction': 0, 'block_profile_rate_ns': 0}
saved = json.loads((p / 'modes-before-engine-replacement.json').read_text())
retired = {'dimension-key-fields'}
restart = ['python3', '/tmp/rust-cache-sipsma-review/restart_owned_engine_clean.py',
           '--engine', engine, '--debug-port', '16104', '--binary', str(binary),
           '--output', str(p / 'v3-graceful-restart')]
with (p / 'v3-restart-driver.log').open('w') as out:
    result = subprocess.run(restart, stdout=out, stderr=subprocess.STDOUT)
assert result.returncode == 0, (p / 'v3-restart-driver.log').read_text()[-5000:]
for route, state in saved.items():
    if route in retired or 'enabled' not in state:
        continue
    if state.get('read_at'):
        assert get(route)['enabled'] == state['enabled'], route
    else:
        mode(route, state['enabled'])
get('builtin-receivers?enabled=true&record=false', b'')
get('config-declarations?enabled=true&record=false', b'')
get('span-lookup-fanout?enabled=true&record=false', b'')
assert get('collection-expansion-limit?limit=0', b'')['limit'] == 0
mode('scalar-list-projection', True)
assert get('trivial-scalar-fields')['enabled']
assert not get('direct-span-protobuf')['enabled']
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler') == {'mutex_fraction': 0, 'block_profile_rate_ns': 0}
try:
    get('dimension-key-fields')
    raise AssertionError('retired diagnostic should not be served')
except urllib.error.HTTPError as error:
    assert error.code == 404
after_sha = subprocess.check_output(
    ['docker', 'exec', engine, 'sha256sum', '/usr/local/bin/dagger-engine'], text=True).split()[0]
after_mounts = json.loads(subprocess.check_output(['docker', 'inspect', engine]))[0]['Mounts']
assert after_sha == candidate_sha and before_mounts == after_mounts
activation = dict(before_sha256=before_sha, after_sha256=after_sha, same_mounts=True,
                  telemetry=True, ordinary_gc=True, forced_shutdown=False, volume_reset=False,
                  retired_diagnostic_routes=sorted(retired), scalar_list_projection=True,
                  modes={route:get(route) for route in saved if route not in retired})
(p / 'v3-activation.json').write_text(json.dumps(activation, indent=2) + '\n')
print('PASS: new controlled engine active on the same volume, modes restored, profiling off', flush=True)
command = ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py',
           'scalar-list-projection-v3-first-after']
start = time.monotonic()
with (p / 'v3-retained-first-after.log').open('w') as out:
    result = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT)
(p / 'v3-retained-first-after.json').write_text(json.dumps(dict(
    command=command, seconds=time.monotonic()-start, exit_code=result.returncode,
    scalar_list_projection=get('scalar-list-projection')), indent=2) + '\n')
assert result.returncode == 0, (p / 'v3-retained-first-after.log').read_text()[-5000:]
print((p / 'v3-retained-first-after.log').read_text(), flush=True)
