from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
base=[go,'test','-p','2','-buildvcs=false','-race','-count=1']
work='/tmp/dagger-trivial-scalar-fields-only'
engine='/tmp/dagger-filesync-snapshot-seeds'
modfile='/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod'
steps=[('retained-before',['python3','/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py','scalar-list-projection-before-first'],None),
 ('data-full-dagql-race',base+['-overlay',str(p/'data-candidate-overlay.json'),'./dagql'],work),
 ('data-core-retention-race',[go,'test','-p','1','-buildvcs=false','-race','-count=1','-v','-overlay',str(p/'data-candidate-overlay.json'),'-run','^Test(ModuleObject|LazyStoredResultsWithoutBacking)','./core','./core/schema'],work),
 ('controlled-full-dagql-race',base+['-modfile',modfile,'-overlay',str(p/'engine-test-overlay.json'),'./dagql'],engine),
 ('controlled-engine-build',[go,'build','-p','2','-buildvcs=false','-modfile',modfile,'-overlay',str(p/'engine-overlay.json'),'-o',str(p/'dagger-engine'),'./cmd/engine'],engine)]
rows=[]
for label,command,cwd in steps:
 begin=time.monotonic()
 with (p/(label+'.log')).open('w') as stream:result=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
 if label=='controlled-engine-build' and result.returncode==0:row['sha256']=hashlib.sha256((p/'dagger-engine').read_bytes()).hexdigest()
 rows.append(row);(p/'engine-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,result.returncode,round(row['seconds'],3),flush=True)
 if result.returncode:print((p/(label+'.log')).read_text()[-7000:],flush=True)
 assert result.returncode==0
