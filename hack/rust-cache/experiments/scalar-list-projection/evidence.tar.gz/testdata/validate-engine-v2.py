from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
work='/tmp/dagger-filesync-snapshot-seeds';modfile='/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod'
base=[go,'test','-p','2','-buildvcs=false','-modfile',modfile,'-race','-count=1']
steps=[('v2-baseline-focused-race',base+['-v','-overlay',str(p/'engine-v2-baseline-test-overlay.json'),'-run','^Test(SyncResultSnapshotLeasesRecordsLockWait|ScalarListProjection|TrivialScalarProjection|NthValue|DetachedReceiverSelectionPreservesReceiverLineage).*','./dagql']),
 ('v2-candidate-full-dagql-race',base+['-overlay',str(p/'engine-v2-test-overlay.json'),'./dagql']),
 ('v2-schema-field-race',base+['-v','-overlay',str(p/'engine-v2-overlay.json'),'-run','^Test(ArtifactMetadataFieldsThroughObjectIDs|DimensionKeyFieldsThroughObjectIDs)$','./core/schema']),
 ('v2-engine-build',[go,'build','-p','2','-buildvcs=false','-modfile',modfile,'-overlay',str(p/'engine-v2-overlay.json'),'-o',str(p/'dagger-engine-v2'),'./cmd/engine'])]
rows=[]
for label,command in steps:
 begin=time.monotonic()
 with (p/(label+'.log')).open('w') as out:result=subprocess.run(command,cwd=work,env=env,stdout=out,stderr=subprocess.STDOUT)
 log=(p/(label+'.log')).read_text();row=dict(label=label,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
 if label=='v2-schema-field-race':row['required_tests_executed']=all('--- PASS: '+test in log for test in ['TestArtifactMetadataFieldsThroughObjectIDs','TestDimensionKeyFieldsThroughObjectIDs'])
 if label=='v2-engine-build' and result.returncode==0:row['sha256']=hashlib.sha256((p/'dagger-engine-v2').read_bytes()).hexdigest()
 rows.append(row);(p/'engine-v2-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,result.returncode,round(row['seconds'],3),flush=True)
 if result.returncode:print(log[-7000:],flush=True)
 assert result.returncode==0 and row.get('required_tests_executed',True)
