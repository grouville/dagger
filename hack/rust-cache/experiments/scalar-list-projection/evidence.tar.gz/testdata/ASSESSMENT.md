This file retains chronological working notes. The final accepted result and selected state are in selected-state.json, v3-full-command-derived.json and the linked permanent study.

# Scalar-only projection of inline data lists

The last accepted full listing is 39.20 seconds for 4,398 ordered rows on a warm retained engine with a fresh CLI and source comment edit. No end-to-end result exists for this experiment yet.

The selected capture spends roughly nine seconds projecting collection metadata, including attachment of 17,592 dimension-key list elements. Their two string fields already reside in the parent list.

The broad prototype changes release callback behavior. Its first resource probe incorrectly expected one callback; the unchanged control produces two. The corrected probe passes on the unchanged control and fails on the prototype (one instead of two). Both harness attempts are retained; this is a lifecycle behavior divergence, not evidence of a production leak.

The refined prototype requires explicit data-only classification, scalar-only stored fields and inline plain-value arrays. Resource hooks, cached result elements, identity selections, computed functions, custom scalars and nested object selections use the ordinary path. Each projected getter still runs through normal resolution and telemetry. The parent list stays retained for the entire operation. Only the native ArtifactDimensionKey class, containing two strings, is opted in for the proposed real-command screen.

Both refined arms pass focused race tests. All 32 component processes complete successfully under ordinary GC. Fresh projections of 1,026 objects improve from 33.98 to 20.54 ms, faster in all four pairs, but repeated-parent projections have no clear latency gain and allocate 6.27 MB more. One-object projections improve in every pair. The component comparison is not an end-to-end claim.

The proposed controlled engine retains every previously selected mode. Its older source predates the upstream inline-array marker; a separate compatibility file supplies the same marker and nullable leaf helper. The prototype only changes scalar-only object list selection. Production telemetry and ordinary garbage collection stay enabled. No engine has been replaced yet.

## Real-engine preflight blocker

The retained engine includes an older per-field diagnostic callback on ArtifactDimensionKey.dimension and .key. It sets GetDynamicInput to toggle DoNotCache. The data-list prototype deliberately rejects fields with GetDynamicInput; therefore it would fall back on every real dimension-key field. This is not an end-to-end speed test and must not be timed or advertised as one. Keep the eligibility guard. Resolve the obsolete diagnostic interaction explicitly, without silently weakening resource or cache-policy checks. The old selected engine has not been stopped or replaced. No full listing cohort has started.

The standalone full DagQL race suite and focused core/module-object retention checks pass. Controlled retained-engine DagQL validation has finished with one failure in TestSyncResultSnapshotLeasesRecordsLockWait: its diagnostic lock label is suffixed :1, while the assertion expects the unsuffixed name. The existing driver stopped before building the engine. Do not classify this as a baseline issue without a control reproduction; do not relax the assertion silently. Unified exec session 34878 exited 1 and no further build is running. All previously selected experimental modes have been saved separately.

## Controlled engine v2

The lock-label mismatch also fails on the unchanged selected source. Its existing profiler code deliberately appends the concrete result ID while profiling is enabled. The maintained test now expects that exact ID; it still requires one wait attached to the correct operation. This changes diagnostic test code only.

The obsolete dimension-key diagnostic hook is removed from both arms of the new controlled engine, together with its debug route. The native struct already declares both fields as uncached simple data. This is the same effective policy as the previously selected hook setting (true); the common direct scalar policy remains selected. No eligibility condition is weakened. The timing comparison will vary only the new scalar-list projection switch. The old hook's source and the first stopped validation remain preserved.

## Final v3 result

The complete valid cohort improves 42.24 to 35.90 seconds median, faster in all four measured pairs, with correct ordered rows and successful cleanup for all ten commands. The preflight proves zero indexed dimension-key calls/publications while both getters still run 17,592 times. All six native histories remain fully reusable after the cohort. The controlled mode is selected, and the isolated tested source is pushed as 5a36ffd0e778a2c4301d319d9c00de49ddc0b204 on perf/project-data-list-scalars. No PR is opened.

Final standalone tests all pass. The first counting harness reports a driver assertion because it counts 65 tests including subcases against 32 top-level tests; both underlying Go commands exit zero. Corrected derivation records 32 top-level cases and 65 including subcases. A redundant benchmark copy is removed from the final branch, and every new projection test passes again afterward. The existing benchmark body remains.
