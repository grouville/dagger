# Follow-up evidence from the listing investigation

These are independent hypotheses, not selected production changes or full-command speedups.

## Graceful cache persistence

The original selected engine (9123a6a5) took 173.85 s to stop gracefully, before v2 was installed. This is outside the listing cohort. Every shutdown capture shows continued progress in Cache.applyPersistStateSnapshot. A five-second CPU sample captured during that shutdown attributes 4.99 CPU-seconds to persistence, including 2.47 CPU-seconds in SQLite preparation. See shutdown-cpu-analysis.log and v2-graceful-restart/shutdown-cpu.pprof. The total sampled CPU is 6.05 s including concurrent work; cumulative frames overlap.

The save rewrites the mirror in one transaction. The handwritten mirror methods call q.exec with a nil prepared statement, so Tx.ExecContext prepares identical INSERT statements per row. persistdb.Prepare currently prepares only SelectMeta and UpsertMeta. A transaction-local cache of prepared ExecContext statements can preserve SQL, schema, ordering, locking and transaction boundaries. Tx.Commit/Rollback owns and closes statements prepared on that transaction. Benchmark this on real SQLite with ordinary GC, verify snapshot contents and rollback/connection release, then assess its complexity. Do not claim it improves listing latency: this evidence concerns engine shutdown.

## Bulk ProtoJSON encoding

The existing Go profile attributes 24 cumulative CPU-seconds to ProtoJSON marshaling (overlapping other frames). MarshalProtoJSONs currently initializes MarshalAppend for every element. The selected decoder already wraps a KeyValue array as an OTLP KeyValueList so it can parse the whole list in one call. The matching encoder could marshal one KeyValueList (or a Span containing only Events/Links) and return its array, preserving the current record format and every telemetry value. Compare complete decoded messages against the current encoder, including nil entries, invalid UTF-8, escaped strings, numeric bounds, non-finite numbers, arrays, events and links. Benchmark tiny and large lists before a full command; no bespoke attribute serializer or new dependency is necessary to screen this.

## Current upstream scalar leaf projection

The selected retained engine is based on local 19eda924 (October 15); standalone proofs use ff0b029a (October 16 main). The latter includes aacc932b7d by Alex Suraci, dagql: render leaf list elements directly. Its valueEnumerable marker covers Array[T] and DynamicArrayOutput. The selected engine has an older, specialized primitive-array path. The v3 compatibility correction restores both marker types for object projection; it does not replace that older leaf resolver. A separate controlled comparison should bring the upstream leaf resolver into the selected engine, with attribution to upstream and no duplicate PR. Audit the earlier scalar-array proposal for overlap before opening anything.
