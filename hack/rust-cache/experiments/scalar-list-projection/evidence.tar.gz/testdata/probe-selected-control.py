from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay','/tmp/rust-cache-sipsma-review/trivial-scalar-projection/engine-overlay.json','-race','-v','-count=1','-run','^TestSyncResultSnapshotLeasesRecordsLockWait$','./dagql']
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
start=time.monotonic()
with (p/'selected-control-lock-label.log').open('w') as out:result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=out,stderr=subprocess.STDOUT)
log=(p/'selected-control-lock-label.log').read_text()
(p/'selected-control-lock-label.json').write_text(json.dumps(dict(command=command,seconds=time.monotonic()-start,exit_code=result.returncode,log=log),indent=2)+'\n')
print('selected-control-label',result.returncode,flush=True)
print(log[-4000:],flush=True)
assert result.returncode==1 and 'actual  : []string{"lock dagql.sharedResult.leaseSyncMu:1"}' in log
