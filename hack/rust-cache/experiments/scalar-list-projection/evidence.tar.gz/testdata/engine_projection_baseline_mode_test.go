package dagql

func init() { scalarListProjection.Store(false); directTrivialScalarFields.Store(true) }
