from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent
w='/tmp/dagger-native-data-list-projection';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
steps=[('standalone-full-dagql-race',[go,'test','-p','2','-buildvcs=false','-race','-count=1','./dagql']),
 ('standalone-core-retention-race',[go,'test','-p','1','-buildvcs=false','-race','-count=1','-v','-run','^Test(ModuleObject|LazyStoredResultsWithoutBacking)','./core','./core/schema'])]
for label,command in steps:
 begin=time.monotonic()
 with (p/(label+'.log')).open('w') as out:result=subprocess.run(command,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
 log=(p/(label+'.log')).read_text();row=dict(label=label,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
 if label=='standalone-core-retention-race':row['passing_cases']=sum('--- PASS:' in line for line in log.splitlines())
 rows.append(row);(p/'standalone-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,result.returncode,round(row['seconds'],3),flush=True)
 if result.returncode:print(log[-6000:],flush=True)
 assert result.returncode==0 and row.get('passing_cases',32)==32
