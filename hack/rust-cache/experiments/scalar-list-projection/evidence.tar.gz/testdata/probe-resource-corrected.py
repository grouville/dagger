from pathlib import Path
import json,os,subprocess,time
root=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for arm in ['baseline','candidate']:
 command=[go,'test','-p','2','-buildvcs=false','-overlay',str(root/(arm+'-resource-overlay.json')),'-race','-v','-count=1','-run','^TestScalarListProjectionReleasesResourceItems$','./dagql']
 begin=time.monotonic()
 with (root/(arm+'-resource-corrected.log')).open('w') as out:result=subprocess.run(command,cwd='/tmp/dagger-trivial-scalar-fields-only',env=env,stdout=out,stderr=subprocess.STDOUT)
 log=(root/(arm+'-resource-corrected.log')).read_text();rows.append(dict(arm=arm,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode,log=log));(root/'resource-corrected.json').write_text(json.dumps(rows,indent=2)+'\n');print(arm,result.returncode,flush=True)
 if arm=='baseline':assert result.returncode==0,log[-6000:]
