from pathlib import Path
import json
p=Path(__file__).parent
selected=Path('/tmp/rust-cache-sipsma-review/trivial-scalar-projection')
server=Path('/tmp/rust-cache-sipsma-review/interface-candidate-pruning/controlled-server.go').read_text()
old="\t\t\t// Has subselections - resolve in parallel\n\t\t\tp := pool.New()"
new="\t\t\tprojectScalars := s.canProjectScalarList(val, sel.Subselections)\n"+old
assert server.count(old)==1
server=server.replace(old,new)
start=server.index("\t\t\tprojectScalars :=")
old="\t\t\t\t\telemVal, err := s.loadNthValue(ctx, val, nth, false)"
assert server[start:].count(old)==1
new="""\t\t\t\t\tvar elemVal AnyResult
\t\t\t\t\tvar err error
\t\t\t\t\tif projectScalars {
\t\t\t\t\t\telemVal, err = s.projectScalarListItem(ctx, val, enum, nth)
\t\t\t\t\t} else {
\t\t\t\t\t\telemVal, err = s.loadNthValue(ctx, val, nth, false)
\t\t\t\t\t}"""
server=server[:start]+server[start:].replace(old,new,1)
(p/'controlled-server.go').write_text(server)
helper=(p/'data_scalar_list_projection.go').read_text()
a='func (s *Server) canProjectScalarList(parent AnyResult, sels []Selection) bool {'
assert helper.count(a)==1
helper=helper.replace(a,a+'\n\tif !scalarListProjection.Load() || !directTrivialScalarFields.Load() {\n\t\treturn false\n\t}')
(p/'controlled_scalar_list_projection.go').write_text(helper)
# The retained engine predates the upstream inline-array marker. Keep this
# compatibility code separate from the standalone prototype based on main.
types=Path('/tmp/dagger-trivial-scalar-fields-only/dagql/types.go').read_text()
start=types.index('func leafValue(elem Typed) Typed {')
end=types.index('\n// Array is an array',start)
compat='package dagql\n\ntype valueEnumerable interface { Enumerable; valueEnumerable() }\nfunc (Array[T]) valueEnumerable() {}\n\n'+types[start:end]+'\n'
(p/'engine_array_compat.go').write_text(compat)
(p/'mode.go').write_text((selected/'mode.go').read_text().replace('directTrivialScalarFields','scalarListProjection').replace('TrivialScalarFieldsDiagnostic','ScalarListProjectionDiagnostic'))
debug=(selected/'debug.go').read_text()
a='m.HandleFunc("/debug/trivial-scalar-fields", dagql.TrivialScalarFieldsDiagnostic)'
assert debug.count(a)==1
(p/'debug.go').write_text(debug.replace(a,a+'\n\tm.HandleFunc("/debug/scalar-list-projection", dagql.ScalarListProjectionDiagnostic)'))
core=Path('/tmp/rust-cache-sipsma-review/artifact-metadata-fields/controlled.go').read_text()
a='dagql.NewClass[*core.ArtifactDimensionKey](srv)';assert core.count(a)==1
(p/'controlled-artifacts-schema.go').write_text(core.replace(a,'dagql.NewClass[*core.ArtifactDimensionKey](srv, dagql.ClassOpts[*core.ArtifactDimensionKey]{PureData: true})'))
overlay=json.loads((selected/'engine-overlay.json').read_text());r=overlay['Replace'];base=Path('/tmp/dagger-filesync-snapshot-seeds')
for dest,source in [('dagql/objects.go','controlled-objects.go'),('dagql/server.go','controlled-server.go'),('dagql/scalar_list_projection.go','controlled_scalar_list_projection.go'),('dagql/scalar_list_projection_mode.go','mode.go'),('dagql/scalar_list_projection_compat.go','engine_array_compat.go'),('core/schema/artifacts.go','controlled-artifacts-schema.go'),('cmd/engine/debug.go','debug.go')]:r[str(base/dest)]=str(p/source)
(p/'engine-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
# Unit tests must execute the same enabled path as the proposed engine mode.
(p/'engine_projection_mode_test.go').write_text('package dagql\n\nfunc init() { scalarListProjection.Store(true); directTrivialScalarFields.Store(true) }\n')
for dest,source in [('dagql/scalar_list_projection_test.go','scalar_list_projection_test.go'),('dagql/scalar_list_resource_test.go','scalar_list_resource_test.go'),('dagql/trivial_scalar_projection_test.go','data_trivial_scalar_projection_test.go'),('dagql/scalar_list_projection_mode_test.go','engine_projection_mode_test.go')]:r[str(base/dest)]=str(p/source)
(p/'engine-test-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
print('Prepared controlled engine sources; no live engine mutation')
