from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for arm,overlay in [('v2-marker-missing','engine-v2-marker-probe-overlay.json'),('v3-marker-fixed','engine-v3-test-overlay.json')]:
 command=[go,'test','-p','2','-buildvcs=false','-modfile','/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod','-overlay',str(p/overlay),'-race','-v','-count=1','-run','^TestScalarListProjectionNativeFieldAvoidsItemRows$','./dagql']
 begin=time.monotonic()
 with (p/(arm+'.log')).open('w') as f:result=subprocess.run(command,cwd='/tmp/dagger-filesync-snapshot-seeds',env=env,stdout=f,stderr=subprocess.STDOUT)
 log=(p/(arm+'.log')).read_text();row=dict(arm=arm,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode,log=log);rows.append(row);(p/'marker-regression.json').write_text(json.dumps(rows,indent=2)+'\n');print(arm,result.returncode,round(row['seconds'],3),flush=True)
 print(log[-4500:],flush=True)
 if arm=='v2-marker-missing':assert result.returncode==1 and 'native struct fields must be eligible, not silently fall back' in log
 else:assert result.returncode==0 and '--- PASS: TestScalarListProjectionNativeFieldAvoidsItemRows' in log
