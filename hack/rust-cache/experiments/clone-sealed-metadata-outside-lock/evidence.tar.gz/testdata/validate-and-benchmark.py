from pathlib import Path
import json
import os
import statistics
import subprocess
import time

p = Path(__file__).parent
work = Path('/tmp/dagger-clone-sealed-metadata-outside-lock')
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
bench = work / 'engine/server/client_metadata_snapshot_bench_test.go'
subprocess.run([str(Path(go).with_name('gofmt')), '-w', str(bench), str(work / 'engine/server/client_scope.go')], check=True)
(p / bench.name).write_bytes(bench.read_bytes())
commands = []

def run(label, arm, arguments):
    command = [go, 'test', '-p', '2', '-buildvcs=false', '-mod=readonly',
               '-overlay', str(p / (arm + '-overlay.json')), *arguments, './engine/server']
    tick = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=work, env=env, stdout=output, stderr=subprocess.STDOUT)
    commands.append(dict(label=label, arm=arm, command=command, exit_code=result.returncode, seconds=time.monotonic()-tick))
    (p / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]

for arm in ['before', 'after']:
    run('race-' + arm, arm, ['-race', '-count=1'])
rows = []
for pair in range(4):
    for arm in (['after', 'before'] if pair % 2 == 0 else ['before', 'after']):
        label = f'{pair}-{arm}'
        run(label, arm, ['-run=^$', '-bench=^BenchmarkClientMetadataSnapshot$', '-benchtime=500ms', '-count=1', '-cpu=8', '-benchmem'])
        for line in (p / (label + '.log')).read_text().splitlines():
            if not line.startswith('BenchmarkClientMetadataSnapshot/'):
                continue
            words = line.split()
            rows.append(dict(pair=pair, arm=arm, case=words[0].removeprefix('BenchmarkClientMetadataSnapshot/').removesuffix('-8'),
                             metrics={words[i+1]: float(words[i]) for i in range(2, len(words)-1, 2)}))
        (p / 'component-results.json').write_text(json.dumps(rows, indent=2) + '\n')
assert len(rows) == 32
summary = {}
for case in sorted({row['case'] for row in rows}):
    entry = {arm: {metric: statistics.median(row['metrics'][metric] for row in rows if row['case'] == case and row['arm'] == arm)
                   for metric in ['ns/op', 'B/op', 'allocs/op']} for arm in ['before', 'after']}
    entry['faster_pairs'] = sum(next(row['metrics']['ns/op'] for row in rows if row['case'] == case and row['pair'] == pair and row['arm'] == 'after') <
                                next(row['metrics']['ns/op'] for row in rows if row['case'] == case and row['pair'] == pair and row['arm'] == 'before') for pair in range(4))
    summary[case] = entry
(p / 'component-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
