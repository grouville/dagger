# Sealed metadata ownership and lock scope

- `mergeClientMetadataLocked` first deep-clones incoming wire data. It only writes a previously zero field before sealing; completion or conflict after sealing is rejected.
- `sealClientMetadataLocked` deep-clones the record again before setting `metadataSealed`. That removes aliases retained by bootstrap callers.
- Production writes to the canonical `record.clientMetadata` are its initial registration, pre-seal merge and sealing. The getter requires the sealed state under `scopeMu` and captures that pointer while locked.
- Client scopes serialize metadata into private JSON bytes. `ClientScope.Metadata` independently decodes those bytes. `clientMetadataSnapshot` still invokes the unchanged deep-clone routine before returning, preserving caller mutation isolation and JSON error behavior.
- The candidate retains the sealed guard and pointer read under the same mutex; only the existing clone runs after unlock. It adds no shared mutable data, read cache, atomic publication or ownership lease.
- Full server race suites pass before and after on clean main. Controlled actual-engine metadata, scope, nested-client and lifecycle-lease races pass with the candidate off and on.

The parallel component improves in all four pairs; the larger serial case is about 3% slower. Full-listing impact and any selection decision remain pending the fixed independent cohort.
