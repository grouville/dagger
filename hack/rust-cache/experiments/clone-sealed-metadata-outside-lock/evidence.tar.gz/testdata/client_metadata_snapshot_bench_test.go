package server

import (
	"fmt"
	"testing"

	"github.com/dagger/dagger/engine"
)

func BenchmarkClientMetadataSnapshot(b *testing.B) {
	for _, labels := range []int{0, 32} {
		b.Run(fmt.Sprint(labels), func(b *testing.B) {
			metadata := &engine.ClientMetadata{
				ClientID: "snapshot-client", SessionID: "snapshot-session",
				ClientSecretToken: "test-only-token", ClientVersion: "v1.0.0-beta.15",
				Labels:            map[string]string{},
				AllowedLLMModules: []string{"module-a", "module-b"},
				ExtraModules:      []engine.ExtraModule{{Name: "go", Ref: "github.com/dagger/go"}},
			}
			for i := range labels {
				metadata.Labels[fmt.Sprintf("label-%d", i)] = fmt.Sprintf("value-%d", i)
			}
			sess := &daggerSession{}
			record := &clientRecord{clientID: metadata.ClientID, clientMetadata: metadata, metadataSealed: true}
			b.Run("serial", func(b *testing.B) {
				b.ReportAllocs()
				for b.Loop() {
					got, err := sess.clientMetadataSnapshot(record)
					if err != nil || got.ClientID != metadata.ClientID {
						b.Fatalf("snapshot: %v", err)
					}
				}
			})
			b.Run("parallel", func(b *testing.B) {
				b.ReportAllocs()
				b.RunParallel(func(pb *testing.PB) {
					for pb.Next() {
						got, err := sess.clientMetadataSnapshot(record)
						if err != nil || got.ClientID != metadata.ClientID {
							b.Errorf("snapshot: %v", err)
							return
						}
					}
				})
			})
		})
	}
}
