# Clone sealed metadata outside the session lock

The detailed listing profile locates 9.35 seconds on the main query path in field preparation. The sampled preparation CPU includes 0.87 seconds under `clientMetadataSnapshot`, including JSON cloning. This does not predict elapsed savings. The shared session scope mutex currently stays held through that deep clone.

Sealing deep-copies metadata into the record, then rejects subsequent completion or mutation through bootstrap merge. Client scopes store JSON snapshots; returned metadata is independently decoded. The candidate captures the sealed pointer under the existing lock and performs the existing clone afterward. Unsealed errors, wire semantics, defensive copies, warnings, authentication, ownership and fresh configuration reads remain unchanged. Do not add a cache or an atomic publication mechanism before proving this simpler change.

On clean main with unchanged dependencies, run the server race suite before and after, then four fixed alternating component pairs for serial and parallel snapshots with two metadata sizes. Include complete cloning and caller verification, normal GC and eight scheduler threads. Keep every result. The benchmark is not a full listing or startup measurement. A candidate remains unselected until an independent complete-command comparison establishes value.
