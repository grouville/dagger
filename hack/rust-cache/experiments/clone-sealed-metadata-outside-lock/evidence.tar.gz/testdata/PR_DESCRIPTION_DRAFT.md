# perf: clone sealed client metadata outside the session lock

`clientMetadataSnapshot` holds the session scope mutex through a JSON round trip. Independent callers waiting for metadata serialize behind that copy, including module calls checking their current Git-client declarations.

Keep the sealed-state check and pointer read under the existing lock, then clone the immutable snapshot after unlocking. Sealing already deep-copies the canonical declaration and rejects later bootstrap changes. The existing clone still returns independent maps, slices and pointers and preserves its JSON errors.

Four fixed alternating component pairs on main `ff0b029a`, with unchanged dependencies, Go 1.26.6, eight scheduler threads and normal GC:

| Labels | Serial, before → after | Shared-session parallel, before → after |
| --- | ---: | ---: |
| 0 | 7.731 → 7.733 µs | 12.018 → 2.248 µs |
| 32 | 31.150 → 32.099 µs | 40.214 → 9.999 µs |

Both parallel cases improve in all four pairs. The larger serial case is about 3% slower and improves in only one pair. Each arm starts a fresh process. Allocation is effectively unchanged; the benchmark includes the complete defensive clone and checks the caller result.

The full server race suite passes before and after. The controlled engine's metadata, client-scope, nested-client and lifecycle-lease race checks pass with either mode. Existing tests cover bootstrap replay/conflicts, deep-copy isolation, sealed scopes, transport close and teardown.

Full-command comparison is pending. This draft is private experiment material; do not publish or add it to the review queue before inspecting all end-to-end pairs and the serial tradeoff.
