package dang

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var lazyEvalErrorContextEnabled atomic.Bool

func init() {
	lazyEvalErrorContextEnabled.Store(os.Getenv("DANG_BENCH_LAZY_EVAL_ERROR_CONTEXT") == "true")
}
func LazyEvalErrorContextDiagnostic(w http.ResponseWriter, r *http.Request) {
	if value := r.URL.Query().Get("enabled"); value != "" {
		enabled, err := strconv.ParseBool(value)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		lazyEvalErrorContextEnabled.Store(enabled)
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": lazyEvalErrorContextEnabled.Load()})
}
