package core

import (
	"testing"

	"github.com/stretchr/testify/require"
)

func TestArtifactMetadataOwnsDisplayData(t *testing.T) {
	artifact := &Artifact{
		ModuleName:    "go",
		TypeName:      "Check",
		Path:          []string{"packages", "package", "tests", "function", "test"},
		Node:          &ModTreeNode{Description: "Run this test.\nMore details."},
		DimensionKeys: []*ArtifactDimensionKey{{Dimension: "module", Key: "go"}, {Dimension: "test", Key: "Test_包"}},
	}
	metadata, err := artifact.Metadata(ArtifactURIOpts{DimensionKeys: true, TypeAssertion: true})
	require.NoError(t, err)
	require.Equal(t, "Run this test.\nMore details.", metadata.Description)
	require.Len(t, metadata.DimensionKeys, 2)
	require.Equal(t, "Test_包", metadata.DimensionKeys[1].Key)
	address := metadata.URI
	artifact.Node.Description = "changed"
	artifact.DimensionKeys[1].Key = "Test_changed"
	artifact.Path[0] = "changed"
	require.Equal(t, "Run this test.\nMore details.", metadata.Description)
	require.Equal(t, "Test_包", metadata.DimensionKeys[1].Key)
	require.Equal(t, address, metadata.URI)
	metadata.DimensionKeys[0].Key = "caller mutation"
	require.Equal(t, "go", artifact.DimensionKeys[0].Key)
}

func TestArtifactMetadataKeepsAbsoluteAddressError(t *testing.T) {
	artifact := &Artifact{TypeName: "Check", Path: []string{"test"}}
	_, expected := artifact.URI(ArtifactURIOpts{Absolute: true, DimensionKeys: true})
	require.Error(t, expected)
	metadata, err := artifact.Metadata(ArtifactURIOpts{Absolute: true, DimensionKeys: true})
	require.Error(t, err)
	require.Equal(t, expected.Error(), err.Error())
	require.Nil(t, metadata)
}
