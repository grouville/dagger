package core

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var collectionGetterContentEnabled atomic.Bool

func init() {
	collectionGetterContentEnabled.Store(os.Getenv("DAGGER_BENCH_COLLECTION_ITEM_CONTENT") == "true")
}
func CollectionGetterContentDiagnostic(w http.ResponseWriter, r *http.Request) {
	if value := r.URL.Query().Get("enabled"); value != "" {
		enabled, err := strconv.ParseBool(value)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		collectionGetterContentEnabled.Store(enabled)
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": collectionGetterContentEnabled.Load()})
}
