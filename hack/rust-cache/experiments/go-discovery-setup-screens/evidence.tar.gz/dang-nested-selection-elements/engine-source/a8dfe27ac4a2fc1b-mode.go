package dang

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var sharedFunctionMetadataEnabled atomic.Bool

func init() {
	sharedFunctionMetadataEnabled.Store(os.Getenv("DANG_BENCH_SHARED_FUNCTION_METADATA") == "true")
}
func SharedFunctionMetadataDiagnostic(w http.ResponseWriter, r *http.Request) {
	if value := r.URL.Query().Get("enabled"); value != "" {
		enabled, err := strconv.ParseBool(value)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		sharedFunctionMetadataEnabled.Store(enabled)
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": sharedFunctionMetadataEnabled.Load()})
}
