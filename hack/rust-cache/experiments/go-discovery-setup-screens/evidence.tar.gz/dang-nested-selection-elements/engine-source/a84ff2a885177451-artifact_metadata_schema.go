package schema

import (
	"context"

	"github.com/dagger/dagger/core"
)

func (*artifactsSchema) metadata(ctx context.Context, parent *core.Artifacts, args struct {
	Absolute      bool `default:"false"`
	TypeAssertion bool `default:"false"`
}) ([]*core.ArtifactMetadata, error) {
	expanded, err := expandArtifacts(ctx, parent)
	if err != nil {
		return nil, err
	}
	rows := make([]*core.ArtifactMetadata, len(expanded.Entries))
	for i, artifact := range expanded.Entries {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		row, err := artifact.Metadata(core.ArtifactURIOpts{Absolute: args.Absolute, TypeAssertion: args.TypeAssertion, DimensionKeys: true})
		if err != nil {
			return nil, err
		}
		rows[i] = row
	}
	return rows, nil
}
