package dagql

import (
	"context"
	"fmt"
	"reflect"

	"github.com/dagger/dagger/engine"
	"github.com/dagger/dagger/engine/wcprof"
	"github.com/vektah/gqlparser/v2/ast"
)

// A response plan reads only generated accessors on immutable native data.
// Identity, custom resolvers and resource-bearing values use normal selection.
type responseDataPlan struct {
	array  *responseDataPlan
	scalar string
	fields []responseDataField
	accept func(Typed) bool
}

type responseDataField struct {
	name     string
	typeName string
	read     func(context.Context, Typed) (Typed, bool, error)
	value    *responseDataPlan
}

func (s *Server) responseDataPlan(typ *ast.Type, selections []Selection) *responseDataPlan {
	if typ == nil {
		return nil
	}
	if typ.Elem != nil {
		inner := s.responseDataPlan(typ.Elem, selections)
		if inner == nil {
			return nil
		}
		return &responseDataPlan{array: inner}
	}
	if len(selections) == 0 {
		switch typ.Name() {
		case "String", "Int", "Float", "Boolean":
			return &responseDataPlan{scalar: typ.Name()}
		default:
			return nil
		}
	}
	class, ok := s.ObjectType(typ.Name())
	if !ok {
		return nil
	}
	policy, ok := class.(interface {
		scalarProjectionSafe() bool
		acceptsResponseData(Typed) bool
	})
	if !ok || !policy.scalarProjectionSafe() {
		return nil
	}
	plan := &responseDataPlan{accept: policy.acceptsResponseData}
	for _, selection := range selections {
		selector := selection.Selector
		if len(selection.TypeConditions) != 0 || len(selector.Args) != 0 || selector.Nth != 0 {
			return nil
		}
		if selector.Field == "__typename" {
			plan.fields = append(plan.fields, responseDataField{name: selection.Name(), typeName: typ.Name()})
			continue
		}
		field, ok := class.FieldSpec(selector.Field, selector.View)
		if !ok || !field.Trivial || field.readData == nil || field.GetDynamicInput != nil || len(field.ImplicitInputs) != 0 || len(field.Args.Inputs(selector.View)) != 0 {
			return nil
		}
		inner := s.responseDataPlan(field.Type.Type(), selection.Subselections)
		if inner == nil {
			return nil
		}
		plan.fields = append(plan.fields, responseDataField{name: selection.Name(), read: field.readData, value: inner})
	}
	return plan
}

func (plan *responseDataPlan) project(ctx context.Context, value Typed) (any, bool, error) {
	if err := ctx.Err(); err != nil {
		return nil, true, err
	}
	for value != nil {
		switch value.(type) {
		case AnyResult, HasPartHostBinding, HasPartHost, OnReleaser:
			return nil, false, nil
		}
		if nullable, ok := value.(Derefable); ok {
			var valid bool
			value, valid = nullable.Deref()
			if !valid {
				return nil, true, nil
			}
			continue
		}
		break
	}
	if value == nil {
		return nil, true, nil
	}
	if plan.scalar != "" {
		// A custom scalar can advertise a builtin name and still own resources.
		switch value.(type) {
		case String, Int, Float, Boolean:
			if value.Type().Name() != plan.scalar {
				return nil, false, nil
			}
			return value, true, nil
		default:
			return nil, false, nil
		}
	}
	if plan.array != nil {
		values, ok := value.(valueEnumerable)
		if !ok {
			return nil, false, nil
		}
		output := make([]any, values.Len())
		for i := range output {
			item, err := values.Nth(i + 1)
			if err != nil {
				return nil, true, err
			}
			projected, handled, err := plan.array.project(ctx, item)
			if !handled || err != nil {
				return nil, handled, err
			}
			output[i] = projected
		}
		return output, true, nil
	}
	if v := reflect.ValueOf(value); v.Kind() == reflect.Pointer && v.IsNil() {
		return nil, false, nil
	}
	if !plan.accept(value) {
		return nil, false, nil
	}
	output := make(map[string]any, len(plan.fields))
	for _, field := range plan.fields {
		if field.typeName != "" {
			output[field.name] = field.typeName
			continue
		}
		item, found, err := field.read(ctx, value)
		if !found || err != nil {
			return nil, found, err
		}
		projected, handled, err := field.value.project(ctx, item)
		if !handled || err != nil {
			return nil, handled, err
		}
		output[field.name] = projected
	}
	return output, true, nil
}

func (s *Server) projectResponseData(ctx context.Context, parent AnyResult, selections []Selection) (output any, handled bool, rerr error) {
	if _, ok := parent.Unwrap().(valueEnumerable); !ok {
		return nil, false, nil
	}
	shared := parent.cacheSharedResult()
	if shared == nil || shared.id == 0 {
		return nil, false, nil
	}
	plan := s.responseDataPlan(parent.Type(), selections)
	if plan == nil {
		return nil, false, nil
	}
	ctx, phase := wcprof.BeginOp(ctx, wcprof.OpKindInternal, "dagql.projectResponseData", wcprof.OpOpts{})
	defer func() { phase.EndErr(rerr) }()
	md, err := engine.ClientMetadataFromContext(ctx)
	if err != nil {
		return nil, true, err
	}
	if md.SessionID == "" {
		return nil, true, fmt.Errorf("serialize data array: empty session ID")
	}
	cache, err := EngineCache(ctx)
	if err != nil {
		return nil, true, err
	}
	op, err := cache.beginSessionOperation(md.SessionID)
	if err != nil {
		return nil, true, err
	}
	cache.egraphMu.RLock()
	generation := shared.requiredSessionResourcesGen.Load()
	bound := cache.sessionSatisfiesResourceRequirementsLocked(md.SessionID, shared)
	cache.egraphMu.RUnlock()
	defer func() {
		if rerr == nil && !cache.sessionStillSatisfiesResourceRequirements(md.SessionID, shared, generation) {
			output = nil
			handled = true
			rerr = fmt.Errorf("serialize data array: session %q has not bound the required resources", md.SessionID)
		}
		if op.finish(rerr == nil) {
			output = nil
			handled = true
			rerr = fmt.Errorf("serialize data array: %w", ErrCacheSessionReleased)
		}
	}()
	if !bound {
		return nil, true, fmt.Errorf("serialize data array: session %q has not bound the required resources", md.SessionID)
	}
	output, handled, rerr = plan.project(ctx, parent.Unwrap())
	if handled && rerr == nil && responseDataProjectionRecording.Load() {
		responseDataProjectionHits.Add(1)
	}
	return output, handled, rerr
}
