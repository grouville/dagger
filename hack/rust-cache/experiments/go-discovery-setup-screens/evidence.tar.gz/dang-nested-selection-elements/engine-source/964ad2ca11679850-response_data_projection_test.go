package dagql

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"sync/atomic"
	"testing"

	"github.com/stretchr/testify/require"
	"github.com/vektah/gqlparser/v2/ast"
)

type responseDataKey struct {
	Dimension string `field:"true"`
	Key       string `field:"true"`
}

func (*responseDataKey) Type() *ast.Type {
	return &ast.Type{NamedType: "ResponseDataKey", NonNull: true}
}

type responseDataRecord struct {
	URI         string             `field:"true"`
	Description string             `field:"true"`
	Keys        []*responseDataKey `field:"true"`
	Note        *string            `field:"true"`
	Labels      []string           `field:"true"`
}

func (*responseDataRecord) Type() *ast.Type {
	return &ast.Type{NamedType: "ResponseDataRecord", NonNull: true}
}

func responseDataFixture(t testing.TB, count int) (context.Context, *Server, *atomic.Int64) {
	ctx, srv, _ := scalarProjectionFixture(t, 0)
	srv.InstallObject(NewClass[*responseDataKey](srv, ClassOpts[*responseDataKey]{PureData: true}))
	srv.InstallObject(NewClass[*responseDataRecord](srv, ClassOpts[*responseDataRecord]{PureData: true}))
	Fields[*responseDataKey]{}.Install(srv)
	computed := new(atomic.Int64)
	Fields[*responseDataRecord]{Func("computed", func(_ context.Context, r *responseDataRecord, _ struct{}) (string, error) {
		computed.Add(1)
		return r.URI + "/computed", nil
	})}.Install(srv)
	Fields[*projectionTestQuery]{Func("dataRows", func(_ context.Context, _ *projectionTestQuery, args struct{ Generation int }) ([]*responseDataRecord, error) {
		rows := make([]*responseDataRecord, count)
		for i := range rows {
			uri := fmt.Sprintf("dag://go:packages?package=包-%d&test=Test_%d", args.Generation, i)
			var note *string
			if args.Generation%2 != 0 {
				note = &uri
			}
			rows[i] = &responseDataRecord{URI: uri, Description: "line one\nline \"two\"", Note: note,
				Labels: []string{"a", "b"}, Keys: []*responseDataKey{{Dimension: "module", Key: "go"}, {Dimension: "test", Key: fmt.Sprintf("Test_%d", i)}}}
		}
		return rows, nil
	})}.Install(srv)
	return ctx, srv, computed
}

func responseDataTestMode(t *testing.T) {
	t.Helper()
	previous := responseDataProjectionEnabled.Swap(false)
	previousRecording := responseDataProjectionRecording.Swap(true)
	responseDataProjectionHits.Store(0)
	t.Cleanup(func() {
		responseDataProjectionEnabled.Store(previous)
		responseDataProjectionRecording.Store(previousRecording)
	})
}

func TestResponseDataProjectionPreservesNestedOutput(t *testing.T) {
	responseDataTestMode(t)
	for _, count := range []int{0, 3} {
		ctx, srv, _ := responseDataFixture(t, count)
		query := `query($g:Int!){ result:dataRows(generation:$g){__typename address:uri description note labels dimensions:keys{kind:dimension value:key __typename}} }`
		for generation := range 2 {
			responseDataProjectionEnabled.Store(false)
			before, err := srv.Query(ctx, query, map[string]any{"g": generation})
			require.NoError(t, err)
			responseDataProjectionEnabled.Store(true)
			after, err := srv.Query(ctx, query, map[string]any{"g": generation})
			require.NoError(t, err)
			require.Equal(t, before, after)
			require.Len(t, after["result"], count)
		}
	}
	require.Positive(t, responseDataProjectionHits.Load(), "the optimized path must actually run")
}

func TestResponseDataProjectionKeepsIdentityAndComputedFields(t *testing.T) {
	responseDataTestMode(t)
	ctx, srv, computed := responseDataFixture(t, 3)
	query := `{dataRows(generation:0){id uri computed keys{id dimension key}}}`
	before, err := srv.Query(ctx, query, nil)
	require.NoError(t, err)
	responseDataProjectionEnabled.Store(true)
	after, err := srv.Query(ctx, query, nil)
	require.NoError(t, err)
	require.Equal(t, before, after)
	require.Equal(t, int64(3), computed.Load(), "ordinary computed functions retain cache reuse")
	require.Zero(t, responseDataProjectionHits.Load(), "identity selections must use normal resolution")
}

func TestResponseDataProjectionRejectsCustomScalarOwnership(t *testing.T) {
	responseDataTestMode(t)
	ctx, srv, _ := responseDataFixture(t, 0)
	srv.InstallObject(NewClass[*projectionTestOwnedScalar](srv, ClassOpts[*projectionTestOwnedScalar]{PureData: true}))
	Fields[*projectionTestOwnedScalar]{}.Install(srv)
	Fields[*projectionTestQuery]{Func("ownedRows", func(context.Context, *projectionTestQuery, struct{}) ([]*projectionTestOwnedScalar, error) {
		return []*projectionTestOwnedScalar{{Value: cacheTestOnReleaseInt{Int: Int(7), onRelease: func(context.Context) error { return nil }}}}, nil
	})}.Install(srv)
	before, err := srv.Query(ctx, `{ownedRows{value}}`, nil)
	require.NoError(t, err)
	responseDataProjectionEnabled.Store(true)
	after, err := srv.Query(ctx, `{ownedRows{value}}`, nil)
	require.NoError(t, err)
	beforeJSON, err := json.Marshal(before)
	require.NoError(t, err)
	afterJSON, err := json.Marshal(after)
	require.NoError(t, err)
	require.JSONEq(t, string(beforeJSON), string(afterJSON))
	require.Zero(t, responseDataProjectionHits.Load(), "a builtin scalar name does not establish safe ownership")
}

func TestResponseDataProjectionDoesNotBypassExtendedResolver(t *testing.T) {
	responseDataTestMode(t)
	ctx, srv, _ := responseDataFixture(t, 3)
	object, ok := srv.ObjectType("ResponseDataRecord")
	require.True(t, ok)
	class := object.(Class[*responseDataRecord])
	class.Install(Func("uri", func(context.Context, *responseDataRecord, struct{}) (string, error) {
		return "overridden", nil
	}).Extend())
	before, err := srv.Query(ctx, `{dataRows(generation:0){uri}}`, nil)
	require.NoError(t, err)
	for _, row := range before["dataRows"].([]any) {
		require.Equal(t, String("overridden"), row.(map[string]any)["uri"])
	}
	responseDataProjectionEnabled.Store(true)
	result, err := srv.Query(ctx, `{dataRows(generation:0){uri}}`, nil)
	require.NoError(t, err)
	for _, row := range result["dataRows"].([]any) {
		require.Equal(t, String("overridden"), row.(map[string]any)["uri"])
	}
	require.Zero(t, responseDataProjectionHits.Load())
}

func responseDataParent(t *testing.T) (context.Context, *Cache, *Server, AnyResult, []Selection) {
	t.Helper()
	ctx, srv, _ := responseDataFixture(t, 3)
	cache, err := EngineCache(ctx)
	require.NoError(t, err)
	list, err := srv.Root().Select(ctx, srv, Selector{Field: "dataRows", Args: []NamedInput{{Name: "generation", Value: Int(0)}}})
	require.NoError(t, err)
	selections := []Selection{{Selector: Selector{Field: "uri"}}}
	return ctx, cache, srv, list, selections
}

func TestResponseDataProjectionRequiresBoundLiveSession(t *testing.T) {
	ctx, cache, srv, list, selections := responseDataParent(t)
	handle := cacheTestVolatileSessionResourceHandle("RESPONSE_DATA_OUTPUT")
	require.NoError(t, cache.BindSessionResource(ctx, "scalar-projection", "scalar-projection", handle, "bound"))
	currentEntryTestRequireHandle(t, ctx, cache, srv, "scalar-projection", list, handle)
	output, handled, err := srv.projectResponseData(cacheTestSessionContext(ctx, "unbound"), list, selections)
	require.True(t, handled)
	require.ErrorContains(t, err, "has not bound")
	require.Nil(t, output)
	_, handled, err = srv.projectResponseData(ctx, list, selections)
	require.True(t, handled)
	require.NoError(t, err)
	canceled, cancel := context.WithCancel(ctx)
	cancel()
	_, _, err = srv.projectResponseData(canceled, list, selections)
	require.ErrorIs(t, err, context.Canceled)
	require.NoError(t, cache.ReleaseSession(ctx, "scalar-projection"))
	_, _, err = srv.projectResponseData(ctx, list, selections)
	require.ErrorIs(t, err, ErrCacheSessionReleased)
}

type responseDataCopyContext struct {
	context.Context
	once       sync.Once
	beforeCopy func()
}

func (ctx *responseDataCopyContext) Err() error {
	ctx.once.Do(ctx.beforeCopy)
	return ctx.Context.Err()
}

func TestResponseDataProjectionRechecksGrowingRequirements(t *testing.T) {
	ctx, cache, srv, list, selections := responseDataParent(t)
	other := currentEntryTestSession(ctx, cache, "other-session")
	handle := cacheTestVolatileSessionResourceHandle("RESPONSE_DATA_LATE_RESOURCE")
	require.NoError(t, cache.BindSessionResource(other, "other-session", "other-client", handle, "bound elsewhere"))
	copyContext := &responseDataCopyContext{Context: ctx, beforeCopy: func() {
		currentEntryTestRequireHandle(t, other, cache, srv, "other-session", list, handle)
	}}
	output, handled, err := srv.projectResponseData(copyContext, list, selections)
	require.True(t, handled)
	require.ErrorContains(t, err, "has not bound")
	require.Nil(t, output)
}

func TestResponseDataProjectionRefusesReleaseAtExit(t *testing.T) {
	ctx, cache, srv, list, selections := responseDataParent(t)
	atExit, allowExit := make(chan struct{}), make(chan struct{})
	cache.testBeforeSessionOperationExit = func(session string) {
		if session == "scalar-projection" {
			close(atExit)
			<-allowExit
		}
	}
	type response struct {
		value any
		err   error
	}
	done := make(chan response, 1)
	go func() {
		value, _, err := srv.projectResponseData(ctx, list, selections)
		done <- response{value, err}
	}()
	<-atExit
	require.NoError(t, cache.ReleaseSession(ctx, "scalar-projection"))
	close(allowExit)
	got := <-done
	require.ErrorIs(t, got.err, ErrCacheSessionReleased)
	require.Nil(t, got.value)
}

func BenchmarkResponseDataProjection(b *testing.B) {
	trivialBefore := directTrivialScalarFields.Swap(true)
	listBefore := scalarListProjection.Swap(true)
	b.Cleanup(func() { directTrivialScalarFields.Store(trivialBefore); scalarListProjection.Store(listBefore) })
	for _, enabled := range []bool{false, true} {
		b.Run(fmt.Sprintf("enabled=%t", enabled), func(b *testing.B) {
			previous := responseDataProjectionEnabled.Swap(enabled)
			b.Cleanup(func() { responseDataProjectionEnabled.Store(previous) })
			ctx, srv, _ := responseDataFixture(b, 4398)
			query := `query($g:Int!){dataRows(generation:$g){uri description note keys{dimension key}}}`
			generation := 0
			_, err := srv.Query(ctx, query, map[string]any{"g": generation})
			require.NoError(b, err)
			b.ReportAllocs()
			b.ResetTimer()
			for b.Loop() {
				generation++
				rows, err := srv.Query(ctx, query, map[string]any{"g": generation})
				require.NoError(b, err)
				require.Len(b, rows["dataRows"], 4398)
			}
		})
	}
}
