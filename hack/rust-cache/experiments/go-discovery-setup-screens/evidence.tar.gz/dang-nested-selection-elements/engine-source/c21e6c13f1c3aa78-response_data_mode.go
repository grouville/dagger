package dagql

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var responseDataProjectionEnabled atomic.Bool
var responseDataProjectionRecording atomic.Bool
var responseDataProjectionHits atomic.Int64

func init() {
	if value, ok := os.LookupEnv("DAGGER_BENCH_RESPONSE_DATA"); ok {
		enabled, err := strconv.ParseBool(value)
		if err != nil {
			panic(err)
		}
		responseDataProjectionEnabled.Store(enabled)
	}
}

func ResponseDataProjectionDiagnostic(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		enabled, err := strconv.ParseBool(r.URL.Query().Get("enabled"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		responseDataProjectionEnabled.Store(enabled)
	} else if r.Method != http.MethodGet {
		http.Error(w, "GET or POST required", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"enabled": responseDataProjectionEnabled.Load(), "hits": responseDataProjectionHits.Load()})
}
