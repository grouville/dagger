package dang

import (
	"fmt"
	"github.com/vito/dang/v2/pkg/hm"
	"os"
	"path/filepath"
	"sync"
	"testing"
)

// A default expression must run against the current receiver on every call,
// even though its argument metadata comes from the same compiled declaration.
func TestFunctionMetadataKeepsReceiverDefaultsIndependent(t *testing.T) {
	dir := t.TempDir()
	source := `type Example {
   value: String!
   read(prefix: String! = value): String! { prefix + ":" + value }
 }`
	if err := os.WriteFile(filepath.Join(dir, "main.dang"), []byte(source), 0600); err != nil {
		t.Fatal(err)
	}
	env, err := RunDir(t.Context(), dir, false)
	if err != nil {
		t.Fatal(err)
	}
	found, _, err := env.Lookup(t.Context(), "Example")
	if err != nil {
		t.Fatal(err)
	}
	constructor := found.(*ConstructorFunction)
	var group sync.WaitGroup
	errors := make(chan error, 32)
	for i := range 32 {
		group.Go(func() {
			name := fmt.Sprintf("receiver-%d", i)
			object := NewObject(constructor.ObjectType)
			object.Bind("value", StringValue{Val: name}, PublicVisibility)
			scope := CreateOverlayValueScope(object, constructor.Closure)
			scope.EnterSelf(object)
			if _, err := EvaluateFormsWithPhases(t.Context(), constructor.ObjectBodyForms, scope); err != nil {
				errors <- err
				return
			}
			value, ok, err := object.Lookup(t.Context(), "read")
			if err != nil || !ok {
				errors <- fmt.Errorf("method lookup: %t: %v", ok, err)
				return
			}
			for range 2 {
				result, err := (BoundMethod{Method: value.(FunctionValue), Receiver: object}).Call(t.Context(), env, nil)
				if err != nil {
					errors <- err
					return
				}
				if result.(StringValue).Val != name+":"+name {
					errors <- fmt.Errorf("receiver default changed: %v", result)
					return
				}
			}
		})
	}
	group.Wait()
	close(errors)
	for err := range errors {
		t.Error(err)
	}
}

func TestFunctionMetadataRefreshesAfterInference(t *testing.T) {
	scope := NewObject(NewType("metadata-test", ObjectKind))
	argument := &FieldDecl{Name: &Symbol{Name: "arg"}, Value: &ValueNode{Val: StringValue{Val: "first"}}}
	declaration := &FunctionBase{Args: []*FieldDecl{argument}, Body: &Symbol{Name: "arg"}}
	signature := func() *hm.FunctionType {
		return hm.NewFnType(NewRecordType("", Keyed[*hm.Scheme]{Key: "arg", Value: hm.NewScheme(nil, StringType)}), StringType)
	}
	first := declaration.createFunctionValue(scope, signature())
	argument.Value = &ValueNode{Val: StringValue{Val: "second"}}
	second := declaration.createFunctionValue(scope, signature())
	for _, sample := range []struct {
		function FunctionValue
		want     string
	}{{first, "first"}, {second, "second"}} {
		result, err := sample.function.Call(t.Context(), scope, nil)
		if err != nil {
			t.Fatal(err)
		}
		if result.(StringValue).Val != sample.want {
			t.Fatalf("default changed across inferred signatures: got %v, want %q", result, sample.want)
		}
	}
}
