package core

import "github.com/vektah/gqlparser/v2/ast"

// ArtifactMetadata is immutable display data. It carries no executable value,
// workspace handle, module tree or resource lifecycle.
type ArtifactMetadata struct {
	URI           string                  `field:"true" doc:"The artifact's DAG address."`
	Description   string                  `field:"true" doc:"The description of the artifact field."`
	DimensionKeys []*ArtifactDimensionKey `field:"true" doc:"The artifact's dimension keys, in display order."`
}

func (*ArtifactMetadata) Type() *ast.Type {
	return &ast.Type{NamedType: "ArtifactMetadata", NonNull: true}
}

func (*ArtifactMetadata) TypeDescription() string {
	return "Display metadata for one artifact, without evaluating its value."
}

func (artifact *Artifact) Metadata(opts ArtifactURIOpts) (*ArtifactMetadata, error) {
	uri, err := artifact.URI(opts)
	if err != nil {
		return nil, err
	}
	keys := make([]*ArtifactDimensionKey, len(artifact.DimensionKeys))
	for i, key := range artifact.DimensionKeys {
		if key == nil {
			continue
		}
		copy := *key
		keys[i] = &copy
	}
	return &ArtifactMetadata{URI: uri, Description: artifact.Description(), DimensionKeys: keys}, nil
}
