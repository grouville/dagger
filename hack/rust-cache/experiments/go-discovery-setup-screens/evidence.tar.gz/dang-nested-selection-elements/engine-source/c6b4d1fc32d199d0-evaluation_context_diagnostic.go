package dang

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

var evaluationContextEnabled atomic.Bool

func init() { evaluationContextEnabled.Store(os.Getenv("DANG_BENCH_EVAL_CONTEXT") == "true") }
func EvaluationContextDiagnostic(w http.ResponseWriter, r *http.Request) {
	if value := r.URL.Query().Get("enabled"); value != "" {
		enabled, err := strconv.ParseBool(value)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		evaluationContextEnabled.Store(enabled)
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]bool{"enabled": evaluationContextEnabled.Load()})
}
