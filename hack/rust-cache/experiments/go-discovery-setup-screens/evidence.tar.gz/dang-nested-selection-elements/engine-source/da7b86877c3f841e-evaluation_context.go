package dang

import "context"

// evaluationStateContext keeps the interpreter's two private values near the
// caller. Unknown context values and cancellation still come from the parent.
type evaluationStateContext struct {
	context.Context
	eval  any
	force any
}

func (ctx *evaluationStateContext) Value(key any) any {
	switch key {
	case evalContextKey{}:
		return ctx.eval
	case forceChainKey{}:
		return ctx.force
	default:
		return ctx.Context.Value(key)
	}
}

func withEvaluationState(ctx context.Context, eval, force any) context.Context {
	if previous, ok := ctx.(*evaluationStateContext); ok {
		ctx = previous.Context
	}
	return &evaluationStateContext{Context: ctx, eval: eval, force: force}
}
