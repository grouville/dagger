from pathlib import Path
import json,os,subprocess,time,urllib.request,hashlib
p=Path(__file__).parent;base=p.parent;debug='http://127.0.0.1:16105/debug/'
candidate=Path('/tmp/dagger-go-parallel-test-file-search');control=Path('/tmp/dagger-go-snapshot-test-directories')
control_test=control/'.dagger/modules/go-dev/main.dang';original=control_test.read_bytes()
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=10) as f:return json.load(f)
routes=['collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata'];flags={r:get(r)['enabled'] for r in routes};assert not get('wcprof/enabled')['global_enabled']
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16277',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
rows=[]
def check(arm,repo,name):
 tick=time.monotonic();label=arm+'-'+name.replace(':','-')
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(['python3',str(base/'local_cli_collector.py'),'check',name],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 row=dict(arm=arm,check=name,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'.log')).read_text()[-3500:]);raise SystemExit(r.returncode)
try:
 for route in routes:get(route+'?enabled='+str(route!='shared-function-metadata').lower(),b'')
 check('candidate',candidate,'go-dev:test-snapshot-directories-check')
 control_test.write_bytes((candidate/'.dagger/modules/go-dev/main.dang').read_bytes())
 try:check('control',control,'go-dev:test-snapshot-directories-check')
 finally:control_test.write_bytes(original)
 for name in ['go-dev:discovery-check','go-dev:package-layout-rebind-check','go-dev:tests-collection-check','go-dev:binary-check','go-dev:generate-check']:
  check('candidate',candidate,name)
finally:
 control_test.write_bytes(original)
 for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
 (p/'checks-restoration.json').write_text(json.dumps(dict(control_test_restored=control_test.read_bytes()==original,flags_after={r:get(r) for r in routes}),indent=2)+'\n')
