# Attribute the current warm full-listing cost

The compaction timing screen stays below the metadata-prune threshold; its separate diagnostic records zero compaction calls. That does not establish path activity during unrecorded timing. It does show the earlier pressure-heavy tail cannot explain all current 35–38 second listings.

Profile one fresh-edited listing on the same retained engine and selected Go module, with every unselected optimization off. Preserve telemetry, normal GC, native cache, source semantics and successful cleanup. Capture wcprof exact API/backend parents, engine and CLI CPU windows, and ordinary compaction events. The command must return all 4398 ordered rows and exit 0. This diagnostic is not a latency comparison. Analyze after the scoped cache-usage component cohort finishes; do not overlap workloads.
