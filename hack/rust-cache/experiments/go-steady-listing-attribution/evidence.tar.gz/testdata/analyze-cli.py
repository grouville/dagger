from pathlib import Path
import json
import os
import subprocess

p = Path(__file__).parent / 'capture'
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
cli = '/tmp/rust-cache-sipsma-review/filesync-literal-pathwalk/dagger-after'
windows = json.loads((p / 'cli-cpu-windows.json').read_text())
rows = []
for label, options in [('cli-cpu-cumulative', ['-cum']), ('cli-cpu-flat', [])]:
    command = [go, 'tool', 'pprof', '-top', '-nodecount=60', *options, cli,
               *[str(p / window['path']) for window in windows['windows']]]
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT,
                                env=dict(os.environ, GOTOOLCHAIN='local', GOWORK='off'))
    rows.append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0
(p / 'cli-analysis-validation.json').write_text(json.dumps(rows, indent=2) + '\n')
