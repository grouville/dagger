from pathlib import Path
from collections import Counter,defaultdict
import json,os,re,subprocess
p=Path(__file__).parent/'capture';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';engine='/tmp/rust-cache-sipsma-review/compaction-digest-sets-e2e/dagger-engine'
windows=json.loads((p/'engine-cpu-windows.json').read_text());rows=[]
for label,flags,profiles in [
 ('cpu-cumulative',['-cum'],[str(p/r['path']) for r in windows]),
 ('cpu-flat',[],[str(p/r['path']) for r in windows]),
 ('cpu-preparation',['-cum','-focus','OperationPrepare|clientAdmission|queryResolve'],[str(p/r['path']) for r in windows]),
 ('tail-publication-cpu',['-cum','-focus','initCompletedResult'],[str(p/r['path']) for r in windows if r['start_seconds']>=29]),
 ('mutex-cumulative',['-cum','-sample_index=delay','-base',str(p/'engine-mutex-before.pprof')],[str(p/'engine-mutex-after.pprof')]),
 ('allocation-cumulative',['-cum','-sample_index=alloc_space','-base',str(p/'engine-allocs-before.pprof')],[str(p/'engine-allocs-after.pprof')]),
 ]:
 cmd=[go,'tool','pprof','-top','-nodecount=65',*flags,engine,*profiles]
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off'))
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode));assert r.returncode==0
(p/'forensics-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
summary={}
for window in json.loads((p/'goroutine-windows.json').read_text()):
 text=(p/window['path']).read_text();groups=Counter();examples={};runnable=[]
 for block in text.split('\n\ngoroutine '):
  lines=block.splitlines()
  if not lines:continue
  frames=[line for line in lines[1:] if line and not line.startswith(('\t','created by','goroutine '))]
  state=lines[0].split('[',1)[-1].split(']',1)[0]
  if 'dagql.(*Cache).initCompletedResult' in block:
   for i,line in enumerate(lines):
    if 'dagql.(*Cache).initCompletedResult' in line:
     location=lines[i+1].strip().split(' +',1)[0];break
   key=(state,location,tuple(re.sub(r'\(.*','',f) for f in frames[:4]))
   groups[key]+=1;examples.setdefault(str(key),lines[:18])
  if state=='runnable' and 'dagql.(*Cache)' in block:runnable.append(lines[:18])
 summary[window['path']]=dict(seconds=window['seconds'],publication_waiters=sum(groups.values()),groups=[dict(state=k[0],location=k[1],top=list(k[2]),count=count) for k,count in groups.most_common(12)],examples=examples,runnable_cache_examples=runnable[:8])
(p/'goroutine-derived.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({name:{k:v for k,v in row.items() if k in ['seconds','publication_waiters','groups']} for name,row in summary.items()},indent=2))
