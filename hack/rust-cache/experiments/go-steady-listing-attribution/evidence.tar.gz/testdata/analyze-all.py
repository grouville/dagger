from pathlib import Path
import subprocess

p = Path(__file__).parent
for name in ['analyze.py', 'analyze-forensics.py', 'analyze-cli.py']:
    with (p / (name + '.log')).open('w') as output:
        result = subprocess.run(['python3', str(p / name)], stdout=output, stderr=subprocess.STDOUT)
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, (p / (name + '.log')).read_text()[-4000:]
