from pathlib import Path
from collections import Counter,defaultdict
import json,os,re,subprocess
p=Path(__file__).parent/'capture';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';engine='/tmp/rust-cache-sipsma-review/compaction-digest-sets-e2e/dagger-engine'
windows=json.loads((p/'engine-cpu-windows.json').read_text());rows=[]
for label,flags,profiles in [
 ('cpu-cumulative',['-cum'],[str(p/r['path']) for r in windows]),
 ('cpu-flat',[],[str(p/r['path']) for r in windows]),
 ('cpu-preparation',['-cum','-focus','OperationPrepare|clientAdmission|queryResolve'],[str(p/r['path']) for r in windows]),
 ('tail-publication-cpu',['-cum','-focus','initCompletedResult'],[str(p/r['path']) for r in windows if r['start_seconds']>=29]),
 ('mutex-cumulative',['-cum','-sample_index=delay','-base',str(p/'engine-mutex-before.pprof')],[str(p/'engine-mutex-after.pprof')]),
 ('allocation-cumulative',['-cum','-sample_index=alloc_space','-base',str(p/'engine-allocs-before.pprof')],[str(p/'engine-allocs-after.pprof')]),
 ]:
 cmd=[go,'tool','pprof','-top','-nodecount=65',*flags,engine,*profiles]
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off'))
 rows.append(dict(label=label,command=cmd,exit_code=r.returncode));assert r.returncode==0
(p/'forensics-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
print('CPU, mutex and allocation analyses complete. This capture has no scheduled goroutine dumps.')
