from pathlib import Path
import json
import os
import subprocess

p = Path(__file__).parent / 'capture'
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
engine = '/tmp/rust-cache-sipsma-review/compaction-digest-sets-e2e/dagger-engine'
windows = json.loads((p / 'engine-cpu-windows.json').read_text())
rows = []
for label, flags, profiles in [
    ('cpu-focus-admission', ['-cum', '-focus=getOrInitClient'], [str(p / row['path']) for row in windows]),
    ('cpu-focus-query', ['-cum', '-focus=serveQuery'], [str(p / row['path']) for row in windows]),
    ('cpu-focus-operation', ['-cum', '-focus=CreateOperationContext'], [str(p / row['path']) for row in windows]),
    ('allocation-flat', ['-sample_index=alloc_space', '-base', str(p / 'engine-allocs-before.pprof')], [str(p / 'engine-allocs-after.pprof')]),
]:
    command = [go, 'tool', 'pprof', '-top', '-nodecount=45', *flags, engine, *profiles]
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, env=dict(os.environ, GOTOOLCHAIN='local', GOWORK='off'))
    rows.append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0
(p / 'focused-validation.json').write_text(json.dumps(rows, indent=2) + '\n')
