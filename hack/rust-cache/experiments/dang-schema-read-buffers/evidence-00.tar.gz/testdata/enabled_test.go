package dangv2

func init() { schemaReadBuffersEnabled.Store(true) }
