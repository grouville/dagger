package dangv2

import (
	"bytes"
	"os"
	"testing"
)

func BenchmarkActualSchemaRead(b *testing.B) {
	data, err := os.ReadFile("/tmp/rust-cache-sipsma-review/dang-schema-read-buffers/schema-fixture.json")
	if err != nil {
		b.Fatal(err)
	}
	cache := newDecodedSchemaCache(2)
	if _, err := cache.read(bytes.NewReader(data)); err != nil {
		b.Fatal(err)
	}
	b.SetBytes(int64(len(data)))
	b.ReportAllocs()
	for b.Loop() {
		got, err := cache.read(bytes.NewReader(data))
		if err != nil || got == nil || len(got.Types) < 100 {
			b.Fatalf("invalid schema result: %v", err)
		}
	}
}
