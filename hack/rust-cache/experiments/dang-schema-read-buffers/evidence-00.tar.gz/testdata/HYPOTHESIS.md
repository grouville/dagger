# Reuse the temporary bytes used to read a schema

The current lossless capture allocates about 7.70 GB beneath decodedSchemaCache.read. io.ReadAll grows a temporary input slice before hashing and looking up the existing decoded-schema cache. Current file bytes and the decoded copy remain required. A temporary pooled prefix buffer can remove repeated growth without adding a schema identity cache or skipping reads.

The prototype retains the existing 1 MiB cache threshold, SHA-256 key, bounded eight-entry schema cache, streaming fallback for larger inputs and independent schema copies. It borrows a byte array only until decode/copy completes; no returned value references it. Reader errors, including an unexpected EOF reported with data, remain errors. An ordinary EOF with data remains successful. There is no custom GC or retention policy; sync.Pool may discard temporary buffers.

Validate real schema contents, copy ownership, concurrency, read errors and boundaries. Measure four fixed alternating component pairs on the actual exported schema and normal GC before considering an engine build. An engine comparison must use identical code with a controlled buffer-reader switch, native Rust first-hit checks, ordinary telemetry and fixed complete-command pairs. Component or allocation savings alone do not establish a faster collection listing.
