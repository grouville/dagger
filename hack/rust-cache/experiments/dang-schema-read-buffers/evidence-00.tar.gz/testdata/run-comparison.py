from pathlib import Path
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
rows = []
assert json.loads((p / 'activation.json').read_text())['same_mounts']
assert json.loads((p / 'retained-first-after.json').read_text())['exit_code'] == 0


def mode(enabled):
    url = 'http://127.0.0.1:16104/debug/schema-read-buffers?enabled=' + str(enabled).lower()
    with urllib.request.urlopen(urllib.request.Request(url, data=b''), timeout=20) as response:
        assert json.load(response)['enabled'] == enabled


def run(label, command):
    start = time.monotonic()
    with (p / (label + '-driver.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start))
    (p / 'comparison-pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
    assert result.returncode == 0, label


try:
    mode(True)
    run('go-correctness', ['python3', str(p / 'verify-checks.py')])
finally:
    mode(False)
run('whole-command', ['python3', str(p / 'measure-listing.py'), '--output', str(p / 'paired'), '--pairs', '9', '--languages', 'go'])
try:
    mode(True)
    run('retained-after-pairs', ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py', 'dang-schema-read-buffers-after-pairs'])
finally:
    mode(False)
