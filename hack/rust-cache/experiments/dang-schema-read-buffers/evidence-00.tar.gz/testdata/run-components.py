from pathlib import Path
import hashlib
import json
import os
import re
import statistics
import subprocess
import time

root = Path(__file__).parent
cwd = '/tmp/dagger-filesync-snapshot-seeds'
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8')
common = ['-p=2', '-modfile=/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod']
stages = []


def run(label, command):
    start = time.monotonic()
    with (root / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - start)
    stages.append(row)
    (root / 'component-pipeline.json').write_text(json.dumps(stages, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, label


run('before-race', [go, 'test', '-race', '-count=1', *common, '-overlay=' + str(root / 'before-test-overlay.json'), './core/sdk/dang/v2'])
for arm in ['before', 'after']:
    run('build-' + arm, [go, 'test', '-c', *common, '-overlay=' + str(root / (arm + '-test-overlay.json')), '-o', str(root / (arm + '.test')), './core/sdk/dang/v2'])

# Reuse the same quiet-admission policy as the preceding component screen.
source = Path('/tmp/rust-cache-sipsma-review/dang-inprocess-transport-screen/measure.py').read_text()
namespace = {'__file__': str(root / 'component-admission.py')}
exec(source.split('metadata = dict(')[0], namespace)
idle = namespace['idle']
orders = [['before', 'after'] if pair % 2 == 0 else ['after', 'before'] for pair in range(4)]
metadata = dict(pairs=4, orders=orders, normal_go_gc=True, gomaxprocs=8, benchtime='500ms',
                source={arm: hashlib.sha256((root / (arm + '-schema.go')).read_bytes()).hexdigest() for arm in ['before', 'after']},
                binaries={arm: hashlib.sha256((root / (arm + '.test')).read_bytes()).hexdigest() for arm in ['before', 'after']},
                fixture=json.loads((root / 'source.json').read_text()), scope='Actual exported schema read, hash, cache lookup and independent copy. A component measurement, not a listing speedup.')
(root / 'component-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
rows = []
for pair, order in enumerate(orders):
    for arm in order:
        label = f'component-{pair}-{arm}'
        idle(label)
        command = [str(root / (arm + '.test')), '-test.run=^$', '-test.bench=^BenchmarkActualSchemaRead$', '-test.benchtime=500ms', '-test.count=1', '-test.timeout=30s']
        run(label, command)
        line = next(line for line in (root / (label + '.log')).read_text().splitlines() if line.startswith('BenchmarkActualSchemaRead'))
        metrics = {name: float(re.search(r'([\d.]+) ' + re.escape(unit), line)[1]) for name, unit in [('ns_per_op', 'ns/op'), ('bytes_per_op', 'B/op'), ('allocations', 'allocs/op')]}
        rows.append(dict(pair=pair, arm=arm, **metrics))
        (root / 'component-samples.json').write_text(json.dumps(rows, indent=2) + '\n')
summary = {arm: {metric: statistics.median(row[metric] for row in rows if row['arm'] == arm) for metric in ['ns_per_op', 'bytes_per_op', 'allocations']} for arm in ['before', 'after']}
summary['faster_pairs'] = sum(next(row['ns_per_op'] for row in rows if row['pair'] == pair and row['arm'] == 'after') < next(row['ns_per_op'] for row in rows if row['pair'] == pair and row['arm'] == 'before') for pair in range(4))
(root / 'component-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
