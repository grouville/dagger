from collections import Counter, defaultdict
from pathlib import Path
import json, subprocess

p=Path(__file__).parent/'capture-before'
ops={};children=defaultdict(list)
with (p/'wcprof-complete.ndjson').open() as stream:
 header=json.loads(next(stream));names=header['strings']
 for line in stream:
  event=json.loads(line)
  if event['e']=='op':
   event['cls']=names[event['c']];ops[event['id']]=event
   children[event.get('p',0)].append(event)
assert header['dropped_events']==0 and not header.get('open_ops')
def seconds(e):return (e['d']-e['s'])/1e9
def brief(e):return dict(id=e['id'],parent=e.get('p',0),kind=e['k'],cls=e['cls'],seconds=seconds(e))
def covered(parent,items):
 intervals=sorted((max(parent['s'],e['s']),min(parent['d'],e['d'])) for e in items if e['d']>parent['s'] and e['s']<parent['d'])
 total=0;stop=parent['s']
 for start,end in intervals:
  total+=max(0,end-max(start,stop));stop=max(stop,end)
 return total/1e9
counts=Counter();requests=[];unmatched=[];boundary_inversions=[]
for api in (e for e in ops.values() if e['cls']=='dang.apiRequest'):
 serves=[e for e in children[api['id']] if e['cls']=='session.serveQuery']
 admits=[e for e in children[api['id']] if e['cls']=='session.clientAdmission']
 counts['api']+=1;counts['serve_children']+=len(serves);counts['admission_children']+=len(admits)
 if len(serves)!=1 or len(admits)!=1:
  unmatched.append(dict(api=brief(api),serves=[brief(e) for e in serves],admissions=[brief(e) for e in admits]));continue
 serve=serves[0];admit=admits[0]
 assert api['s']<=admit['s']<=admit['d']<=serve['s']<=serve['d']
 if serve['d']>api['d']:
  stack=list(children[serve['id']]);call_classes=[]
  while stack:
   item=stack.pop()
   if item['k']=='call':call_classes.append(item['cls'])
   stack.extend(children[item['id']])
  boundary_inversions.append(dict(api_id=api['id'],serve_id=serve['id'],backend_end_after_client_ns=serve['d']-api['d'],call_classes=call_classes))
 requests.append(dict(api=brief(api),admission=brief(admit),serve=brief(serve),pre_admission_seconds=(admit['s']-api['s'])/1e9,pre_serve_seconds=(serve['s']-api['s'])/1e9,client_end_minus_backend_end_seconds=(api['d']-serve['d'])/1e9,admission_children=[brief(e) for e in sorted(children[admit['id']],key=seconds,reverse=True)],serve_children=[brief(e) for e in sorted(children[serve['id']],key=seconds,reverse=True)]))
main=max((e for e in ops.values() if e['cls']=='session.serveQuery' and ops.get(e.get('p',0),{}).get('cls')!='dang.apiRequest'),key=seconds)
result=dict(scope='Exact wcprof operation-parent linkage over the private SDK HTTP connection. No temporal/client-ID inference. Durations of concurrent requests overlap and are not elapsed command savings.',counts=dict(counts),matched=len(requests),unmatched=unmatched,http_boundary_inversions=boundary_inversions,http_boundary_note='Exact request header parents establish linkage. A large response can reach the client before the backend finishes deferred instrumentation; server end is not required to precede client end.',main_query=brief(main),requests=requests,longest_api=sorted(requests,key=lambda r:r['api']['seconds'],reverse=True)[:15],longest_admission=sorted(requests,key=lambda r:r['admission']['seconds'],reverse=True)[:15],longest_serve=sorted(requests,key=lambda r:r['serve']['seconds'],reverse=True)[:15])
(p/'causal-requests.json').write_text(json.dumps(result,indent=2)+'\n')
command=['/tmp/rust-cache-wcprof-report-current','-view','critpath','-op',str(main['id']),'-depth','30','-top','65','-limit','200',str(p/'wcprof-complete.ndjson')]
with (p/'critical-path.log').open('w') as output:
 completed=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
assert completed.returncode==0
(p/'analysis-validation.json').write_text(json.dumps(dict(command=command,exit_code=completed.returncode),indent=2)+'\n')
print(json.dumps(dict(counts=dict(counts),matched=len(requests),unmatched=len(unmatched),main=brief(main),longest_api=[{k:r[k] for k in ['api','admission','serve','pre_admission_seconds','client_end_minus_backend_end_seconds']} for r in result['longest_api'][:8]]),indent=2))
assert not unmatched

completed = subprocess.run(['python3', str(Path(__file__).parent / 'analyze-detail-baseline.py')])
assert completed.returncode == 0
