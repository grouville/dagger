package dangv2

import (
	"bytes"
	"errors"
	"io"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"
)

type schemaFinalRead struct {
	data []byte
	err  error
}

func (r *schemaFinalRead) Read(p []byte) (int, error) {
	n := copy(p, r.data)
	r.data = r.data[n:]
	if len(r.data) == 0 {
		return n, r.err
	}
	return n, nil
}

func TestSchemaCacheReadErrorsAndBoundaries(t *testing.T) {
	t.Run("final data and EOF", func(t *testing.T) {
		cache := newDecodedSchemaCache(2)
		got, err := cache.read(&schemaFinalRead{data: []byte(decodedSchemaFixture), err: io.EOF})
		require.NoError(t, err)
		want, err := decodeDangSchema(strings.NewReader(decodedSchemaFixture))
		require.NoError(t, err)
		require.Equal(t, want, got)
	})
	for _, finalErr := range []error{io.ErrUnexpectedEOF, errors.New("schema read failed")} {
		t.Run(finalErr.Error(), func(t *testing.T) {
			cache := newDecodedSchemaCache(2)
			_, err := cache.read(&schemaFinalRead{data: []byte(decodedSchemaFixture), err: finalErr})
			require.ErrorIs(t, err, finalErr)
			require.Zero(t, cache.entries.Len())
		})
	}
	for _, size := range []int{maxCachedSchemaBytes - 1, maxCachedSchemaBytes, maxCachedSchemaBytes + 1, maxCachedSchemaBytes + 4096} {
		data := []byte(decodedSchemaFixture + strings.Repeat(" ", size-len(decodedSchemaFixture)))
		cache := newDecodedSchemaCache(2)
		got, err := cache.read(bytes.NewReader(data))
		require.NoError(t, err)
		require.Equal(t, "Query", got.QueryType.Name)
		if size <= maxCachedSchemaBytes {
			require.Equal(t, 1, cache.entries.Len())
		} else {
			require.Zero(t, cache.entries.Len(), "oversized schema must keep bypassing the cache")
		}
		// A shorter changed input must not observe bytes left in a reused buffer.
		changed := strings.ReplaceAll(decodedSchemaFixture, "Query", "Changed")
		got, err = cache.read(strings.NewReader(changed))
		require.NoError(t, err)
		require.Equal(t, "Changed", got.QueryType.Name)
	}
}
