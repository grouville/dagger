from pathlib import Path
import json,os,re,statistics,subprocess,time,hashlib
p=Path(__file__).parent;repo='/tmp/dagger-glob-literal-suffix';go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';env=dict(os.environ,GOMAXPROCS='8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off');steps=[];rows=[]
def run(label,command,cwd=repo,extra=None):
 tick=time.monotonic()
 with (p/(label+'.log')).open('w') as out:r=subprocess.run(command,cwd=cwd,env=dict(env,**(extra or {})),stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,cwd=cwd,seconds=time.monotonic()-tick,exit_code=r.returncode);steps.append(row);(p/'validation-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'.log')).read_text()[-3500:]);raise SystemExit(r.returncode)
 return (p/(label+'.log')).read_text()
run('baseline-compatibility',[go,'test','-p=2','-overlay='+str(p/'before-overlay.json'),'-count=1','./util/patternmatcher'])
for block in range(4):
 for arm in (['after','before'] if block%2==0 else ['before','after']):
  label=f'bench-{block}-{arm}';command=[go,'test','-p=2']+(['-overlay='+str(p/'before-overlay.json')] if arm=='before' else [])+['-run=^$','-bench=^BenchmarkLiteralSuffix$','-benchmem','-benchtime=100ms','-count=1','./util/patternmatcher'];log=run(label,command)
  cases=[dict(name=name,ns=float(ns),bytes=int(bs),allocs=int(al)) for name,ns,bs,al in re.findall(r'BenchmarkLiteralSuffix/(.+)-\d+\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',log)];assert len(cases)==3,(label,log)
  rows.append(dict(block=block,arm=arm,cases=cases));(p/'component-pairs.json').write_text(json.dumps(rows,indent=2)+'\n')
summary={}
for name in [c['name'] for c in rows[0]['cases']]:
 summary[name]={arm:{k:statistics.median(c[k] for r in rows if r['arm']==arm for c in r['cases'] if c['name']==name) for k in ['ns','bytes','allocs']} for arm in ['before','after']}
 summary[name]['faster_pairs']=sum(next(c['ns'] for r in rows if r['block']==block and r['arm']=='after' for c in r['cases'] if c['name']==name)<next(c['ns'] for r in rows if r['block']==block and r['arm']=='before' for c in r['cases'] if c['name']==name) for block in range(4))
(p/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
base='/tmp/dagger-filesync-literal-pathwalk';overlay='-overlay='+str(p/'cli-overlay.json')
for arm in ['before','after']:
 run('cli-glob-race-'+arm,[go,'test','-p=2',overlay,'-race','-count=1','-run=^TestGlobHostPath','./engine/client'],base,dict(DAGGER_TEST_GLOB_LITERAL_SUFFIX=str(arm=='after').lower()))
run('cli-build',[go,'build','-p=2','-buildvcs=false',overlay,'-o',str(p/'dagger'),'./cmd/dagger'],base)
(p/'cli-identity.json').write_text(json.dumps(dict(sha256=hashlib.sha256((p/'dagger').read_bytes()).hexdigest(),base_cli_sha256='97f7d82dc2f7b3da203aa683971ea3658b6de6a8e9b968a44905e379f499f965',same_diagnostic_binary_both_arms=True,mode_environment='DAGGER_TEST_GLOB_LITERAL_SUFFIX'),indent=2)+'\n')
