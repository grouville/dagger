from pathlib import Path
import json,subprocess,urllib.request
p=Path(__file__).parent;previous=json.loads(Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/schema-argument-iteration/final-state.json').read_text());binaries={};volumes={}
for name,want in previous['binaries'].items():
 actual=subprocess.check_output(['docker','exec',name,'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0];assert actual==want,name;binaries[name]=actual
 record=json.loads(subprocess.check_output(['docker','inspect',name]))[0];volumes[name]=[dict(name=m.get('Name'),destination=m['Destination']) for m in record['Mounts'] if m['Type']=='volume'];assert volumes[name]==previous['volumes'][name],name

def get(route):
 with urllib.request.urlopen('http://127.0.0.1:16120/debug/'+route,timeout=15) as f:return json.load(f)
plan=json.loads(Path('/tmp/rust-cache-sipsma-review/schema-argument-engine/engine-plan.json').read_text());flags={r:get(r) for r in plan['flags']}
for route,expected in plan['flags'].items():assert flags[route]['enabled']==expected,(route,flags[route],expected)
assert not get('metadata-snapshot-json')['record'];assert not get('wcprof/enabled')['global_enabled'];assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
lifecycle=get('client-lifecycle');assert lifecycle['active_requests']==0 and lifecycle['runtimes']==0,lifecycle;assert all(s['state']=='removed' for s in (lifecycle.get('sessions') or []))
for repo in ['/tmp/dagger-go-real-repository-main','/tmp/dagger-go-generation-native-membership','/tmp/dagger-rust-test-collection-granularity']:
 assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b'',repo
record=dict(binaries=binaries,volumes=volumes,current_engine_flags=flags,lifecycle=lifecycle,wcprof=get('wcprof/enabled'),lock_profiler=get('lock-profiler'),all_engines_and_volumes_retained=True,new_engines_created=0,real_workspace_clean=True,go_module_clean=True,rust_module_clean=True,no_pr_opened=True)
(p/'final-state.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(engines=len(binaries),restored=True,active_requests=0)),flush=True)
