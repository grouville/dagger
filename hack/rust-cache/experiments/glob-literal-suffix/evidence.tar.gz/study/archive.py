from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
p=Path(__file__).parent;root=p/'evidence-root';out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/glob-literal-suffix')
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def ignore(directory,names):return [n for n in names if n in {'__pycache__','.git','evidence-root','wcprof-complete.ndjson','dagger','dagger-engine','archive.log'} or n.endswith('.test')]
assert not root.exists() and not out.exists();root.mkdir();out.mkdir();streams=[]
for complete in sorted(p.glob('capture-*/wcprof-complete.ndjson')):
 events=[];chunks=sorted(complete.parent.glob('chunk-*.ndjson.gz'));assert chunks
 for chunk in chunks:
  with gzip.open(chunk,'rb') as f:header=json.loads(f.readline());events.extend(f.readlines())
  assert header['dropped_events']==0
 assert not header.get('open_ops');header['event_count']=len(events);raw=(json.dumps(header)+'\n').encode()+b''.join(events);assert raw==complete.read_bytes()
 streams.append(dict(capture=complete.parent.name,chunks=[x.name for x in chunks],events=len(events),sha256=sha(raw),exact_bytes_verified=True))
assert len(streams)==4;shutil.copytree(p,root/'study',ignore=ignore);write(root/'wcprof-reconstruction.json',streams)
initial=p.parent/'full-pipeline-current-client';dest=root/'initial-client-attribution';dest.mkdir()
for name in ['capture.py','run.py','analyze.py','steps.json','attribution.json']:(dest/name).write_bytes((initial/name).read_bytes())
for d in sorted(initial.glob('capture-*')):
 if not d.is_dir():continue
 target=dest/d.name;target.mkdir()
 for f in d.iterdir():
  if f.is_file() and (f.name.startswith('cli-') or f.name in {'metadata.json','result.json','attribution.json','main-critical-path.txt','engine-cpu-cumulative.txt','engine-cpu-flat.txt'}):shutil.copy2(f,target/f.name)
parent=out.parent/'schema-argument-iteration';meta=json.loads((parent/'archive.json').read_text());assert sha((parent/'evidence.tar.gz').read_bytes())==meta['sha256'];write(root/'source-parent.json',dict(path='../schema-argument-iteration/evidence.tar.gz',**meta))
cli_source=root/'cli-overlay-source';cli_source.mkdir();inputs=[]
for key,value in json.loads((p/'cli-overlay.json').read_text())['Replace'].items():
 data=Path(value).read_bytes();name=f'{len(inputs):03d}-'+Path(key).name;(cli_source/name).write_bytes(data);inputs.append(dict(virtual=key,actual=value,archived='cli-overlay-source/'+name,sha256=sha(data),bytes=len(data)))
write(root/'cli-source-manifest.json',inputs)
repo=Path('/tmp/dagger-glob-literal-suffix');dest=root/'standalone-source';dest.mkdir()
for name in ['patternmatcher.go','literal_suffix_test.go']:(dest/name).write_bytes((repo/'util/patternmatcher'/name).read_bytes())
files=[f for f in sorted(root.rglob('*')) if f.is_file()];manifest=[dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files];mbytes=(json.dumps(manifest,indent=2)+'\n').encode();arc=out/'evidence.tar.gz'
with arc.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(root)));info.mtime=0
  with f.open('rb') as stream:tar.addfile(info,stream)
 info=tarfile.TarInfo('manifest.json');info.size=len(mbytes);info.mtime=0;tar.addfile(info,io.BytesIO(mbytes))
with tarfile.open(arc,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
(out/'manifest.json').write_bytes(mbytes)
for name in ['wcprof-reconstruction.json','source-parent.json','cli-source-manifest.json']:(out/name).write_bytes((root/name).read_bytes())
for name in ['timing-analysis.json','source-identity.json','change.patch','cli-attribution.json','cli-identity.json','attribution.json','component-summary.json','final-state.json']:(out/name).write_bytes((p/name).read_bytes())
record=dict(bytes=arc.stat().st_size,sha256=sha(arc.read_bytes()),members=len(files)+1,all_member_hashes_verified=True,lossless_streams_reconstructed=len(streams),binaries_excluded=True);write(out/'archive.json',record);print(json.dumps(record),flush=True)
