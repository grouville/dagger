from pathlib import Path
import json,subprocess
p=Path(__file__).parent;go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go';cli='/tmp/rust-cache-sipsma-review/typed-artifact-metadata/dagger';engine='/tmp/rust-cache-sipsma-review/schema-argument-engine/dagger-engine';report='/tmp/rust-cache-sipsma-review/schema-argument-engine/analyze.py';rows=[]
def run(command,out):
 with out.open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(out,out.read_text()[-3500:])
for step in json.loads((p/'steps.json').read_text()):
 d=p/step['label'];run(['python3',report,str(d)],d/'analysis.log');r=json.loads((d/'result.json').read_text());a=json.loads((d/'attribution.json').read_text());windows=json.loads((d/'cli-cpu-windows.json').read_text());assert windows,(d,'missing CLI profile')
 for scope,binary in [('cli',cli),('engine',engine)]:
  profiles=sorted(d.glob(scope+'-cpu-*.pprof'));assert profiles
  for cum in [False,True]:run([go,'tool','pprof','-top','-nodecount=65']+(['-cum'] if cum else [])+[binary,*map(str,profiles)],d/(scope+'-cpu-'+('cumulative' if cum else 'flat')+'.txt'))
 if (d/'cli-allocs-latest.pprof').exists():run([go,'tool','pprof','-sample_index=alloc_space','-top','-nodecount=65','-base='+str(d/'cli-allocs-before.pprof'),cli,str(d/'cli-allocs-latest.pprof')],d/'cli-alloc-flat.txt')
 assert not a['dropped'] and not a['open_ops']
 if step['workload']=='test':assert a['function_evaluations']==804 and a['selected_calls']['go:GoPackages.get']=={'executed':800}
 else:assert a['function_evaluations']==3 and a['selected_calls']['go:GoPackages.get']=={'hit':800}
 row=dict(label=step['label'],workload=step['workload'],seconds=r['seconds'],engine_cpu=r['engine_cpu'],main_query=a['main_query'],evaluations=a['function_evaluations'],getters=a['selected_calls']['go:GoPackages.get'],discovery=a['selected_calls']['go:GoPackage.tests'],sdk_requests=a['sdk_requests'],dropped=a['dropped'],open_ops=a['open_ops'],cli_windows=windows,cli_profile_errors=json.loads((d/'cli-profile-errors.json').read_text()));rows.append(row);(p/'attribution.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
