from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
for i,workload in enumerate(['test','source','source','test']):
 label=f'capture-{i}-{workload}';command=['python3',str(p/'capture.py'),'--arm','candidate','--module','current','--output',str(p/label),'--cpu-profile']+(['--edit-test-body'] if workload=='test' else []);tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,workload=workload,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-3500:]);raise SystemExit(r.returncode)
