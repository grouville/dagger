package dagql

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"slices"
	"strconv"
	"strings"

	"github.com/opencontainers/go-digest"
	"github.com/vektah/gqlparser/v2/ast"
	"golang.org/x/exp/constraints"

	"github.com/dagger/dagger/dagql/call"
)

// Typed is any value that knows its GraphQL type.
type Typed interface {
	// Type returns the GraphQL type of the value.
	Type() *ast.Type
}

// Type is an object that defines a new GraphQL type.
type Type interface {
	// TypeName returns the name of the type.
	TypeName() string

	// Typically a Type will optionally define either of the two interfaces:

	// Descriptive
	// Definitive
}

// ObjectType represents a GraphQL Object type.
type ObjectType interface {
	Type
	// Typed returns a Typed value whose Type refers to the object type.
	Typed() Typed
	// IDType returns the scalar type for the object's IDs.
	IDType() (IDType, bool)
	// New creates a new instance of the type.
	New(val AnyResult) (AnyObjectResult, error)
	// ParseField parses the given field and returns a Selector and an expected
	// return type.
	ParseField(ctx context.Context, view call.View, astField *ast.Field, vars map[string]any) (Selector, *ast.Type, error)
	// Extend registers an additional field onto the type.
	//
	// Unlike natively added fields, the extended func is limited to the external
	// Object interface.
	// cacheConfigFunc is optional, if not set the default dagql ID cache key will be used.
	Extend(spec FieldSpec, fun FieldFunc)
	// FieldSpec looks up a field spec by name.
	FieldSpec(name string, view call.View) (FieldSpec, bool)
	// FieldSpecs returns all field specs visible under the given view.
	FieldSpecs(view call.View) []FieldSpec
}

// ForkableObjectType is an installed object type that can be safely cloned
// into another server without sharing mutable server-bound state like field
// tables or schema-cache invalidation callbacks. The clone preserves the
// installed fields and interface membership.
type ForkableObjectType interface {
	ForkObjectType(*Server) (ObjectType, error)
}

// TypeResolver is the minimal schema lookup surface needed by dagql cache and
// persisted-payload reconstruction.
type TypeResolver interface {
	ObjectType(name string) (ObjectType, bool)
	ScalarType(name string) (ScalarType, bool)
}

type IDType interface {
	Input
	IDable
	ScalarType
}

// FieldFunc is a function that implements a field on an object while limited
// to the object's external interface.
type FieldFunc func(context.Context, AnyResult, map[string]Input) (AnyResult, error)

// LoadByIDFunc is the builtin execution path for schema-generated
// load<Type>FromID fields.
type LoadByIDFunc func(context.Context, AnyResult, map[string]Input) (AnyResult, error)

type IDable interface {
	// ID returns the runtime handle ID of the value.
	ID() (*call.ID, error)
}

type RecipeIDable interface {
	// RecipeID returns the semantic recipe ID of the value.
	RecipeID(context.Context) (*call.ID, error)
}

type SessionResourceHandle string

// AnyResult is a Typed value wrapped with an ID constructor. The wrapped value may
// be any graphql type, including scalars, objects, arrays, etc.
// It's a Result but as an interface and without any type params, allowing it
// to be passed around without knowing the concrete type at compile-time.
type AnyResult interface {
	Typed
	Wrapper
	IDable
	RecipeIDable
	Setter

	// RecipeDigest returns the semantic recipe digest of the value.
	RecipeDigest(context.Context) (digest.Digest, error)

	// DerefValue returns an AnyResult when the wrapped value is Derefable and
	// has a value set. If the value is not derefable, it returns itself.
	DerefValue() (AnyResult, bool)

	// NthValue returns the Nth value of the wrapped value when the wrapped value
	// is an Enumerable. If the wrapped value is not Enumerable, it returns an error.
	NthValue(context.Context, int) (AnyResult, error)

	// NullableWrapped returns a nullable view over the same underlying result.
	NullableWrapped() AnyResult

	// WithContentDigest returns a new AnyResult with the given content digest.
	WithContentDigestAny(context.Context, digest.Digest, ...string) (AnyResult, error)
	// WithSessionResourceHandle returns a new AnyResult with the given session resource handle.
	WithSessionResourceHandleAny(context.Context, SessionResourceHandle) (AnyResult, error)

	HitCache() bool
	ResultCall() (*ResultCall, error)

	// cacheSharedResult returns the internal cache-backed shared payload when present.
	// It is intentionally package-private so only dagql-owned result types satisfy AnyResult.
	cacheSharedResult() *sharedResult
}

// AnyObjectResult is an AnyResult that wraps a selectable value (i.e. a graph object)
type AnyObjectResult interface {
	AnyResult

	// ObjectType returns the type of the object.
	ObjectType() ObjectType

	// Receiver resolves the object result referenced by this result call's receiver, if any.
	Receiver(context.Context, *Server) (AnyObjectResult, error)

	// Select evaluates the field selected by the given selector and returns the result.
	//
	// The returned value is the raw Typed value returned from the field; it must
	// be instantiated with a class for further selection.
	//
	// Any Nullable values are automatically unwrapped.
	Select(context.Context, *Server, Selector) (AnyResult, error)
}

// A type that has a callback attached that needs to always run when the result is removed
// from the cache
type OnReleaser interface {
	OnRelease(context.Context) error
}

type LazyEvalFunc func(context.Context) error

// HasLazyEvaluation is implemented by values carrying deferred work that
// Cache.Evaluate forces. A successful callback run consumes the value's
// deferred work; implementations should return nil from LazyEvalFunc
// afterwards. Core types retain their Lazy operation and report completion
// through its state before cache-side bookkeeping finishes.
// The cache enforces the consumption independently: once a callback body has
// succeeded, later attempts retry only cache-side bookkeeping and never
// re-read the value's callback, so an implementation that keeps returning a
// non-nil function cannot cause the body to run twice.
type HasLazyEvaluation interface {
	LazyEvalFunc() LazyEvalFunc
}

// PartKey identifies one separately evaluable piece of a result's value.
// Keys are defined by the value's package; dagql treats them as opaque.
type PartKey string

// LazyGroupKey identifies one evaluation group of a result. Every part
// maps to exactly one group; a group's single body fills all its parts.
type LazyGroupKey string

// LazyGroupWhole is the implicit group of values that do not split their
// deferred work. It fills every part.
const LazyGroupWhole LazyGroupKey = "whole"

// HasLazyEvaluationParts is implemented by values whose deferred work is
// split into independently evaluable groups. Values that implement only
// HasLazyEvaluation have exactly one group, LazyGroupWhole.
type HasLazyEvaluationParts interface {
	HasLazyEvaluation

	// ResolveLazyEvalGroups maps the requested parts to the groups that
	// fill them, in the order they should be evaluated. nil parts means
	// "every group that currently has deferred work". self is the
	// attached result wrapping this value. Resolution may evaluate the
	// value's own metadata part (via the cache) to settle positional
	// parts; it must never evaluate snapshot content. The mapping must be
	// deterministic and stable once metadata is settled.
	ResolveLazyEvalGroups(ctx context.Context, self AnyResult, parts []PartKey) ([]LazyGroupKey, error)

	// LazyEvalFuncForGroup returns the group's remaining deferred work,
	// nil when none remains. Same consumption contract as LazyEvalFunc,
	// per group: a successful body run consumes the group's work, and the
	// cache independently guarantees the body never runs twice.
	LazyEvalFuncForGroup(LazyGroupKey) LazyEvalFunc
}

// HasLazyEvaluationReporting distinguishes remaining computation from opening
// an already computed local part. Operational evaluation and child construction
// still use HasLazyEvaluation. These methods must not perform I/O or evaluation.
type HasLazyEvaluationReporting interface {
	HasPendingLazyComputation() bool

	// LazyGroupStoredPart returns the saved part opened by this group, or the
	// empty key for ordinary computation. The answer remains stable after body
	// consumption and operation clearing, including bookkeeping-only retries.
	LazyGroupStoredPart(LazyGroupKey) PartKey
}

// HasDependencyResults is implemented by resolver-returned values that embed
// dependency results which must be normalized onto attached/cache-backed
// results before lifecycle bookkeeping or persistence.
//
// Implementations must:
//   - use self when they need to rewrite internal references to the attached
//     owner result itself
//   - call attach for each embedded child result that should be normalized
//   - rewrite themselves in place to point at the attached result returned by attach
//   - return only the subset of attached child results that should become
//     explicit non-structural cache dependency edges
//
// Returned deps are treated as owned: the install span of the parent (the API
// span that returned the parent value to a session) is attributed to each
// dep, so failures in the dep's lazy work mark the parent's install span as
// caused-failed. Implementations that want some deps to be liveness-only (no
// failure attribution) should implement HasDependencyResultsKinds instead.
type HasDependencyResults interface {
	AttachDependencyResults(context.Context, AnyResult, func(AnyResult) (AnyResult, error)) ([]AnyResult, error)
}

// HasResultReference restores a value's internal reference to its own attached
// result. The cache calls this before publishing a decoded persisted payload.
// Implementations must preserve references that are already set, and must not
// resolve self: the payload is still being installed.
type HasResultReference interface {
	InitializeResultReference(self AnyResult)
}

// DependencyResult is an attached dependency result with a kind flag.
type DependencyResult struct {
	Result AnyResult
	// Owned is true when the parent's install span should also be attributed
	// to this dep for lazy failure causality. False marks the edge as
	// liveness-only — the dep is kept alive by the parent and preflighted
	// before the parent's lazy callback, but failures in the dep do not
	// short-circuit attribution onto the parent's install span.
	Owned bool
}

// HasDependencyResultsKinds is the kind-aware variant of HasDependencyResults.
// When a value implements both, this one is preferred — the result kind flag
// (Owned) controls install-span propagation for failure attribution.
type HasDependencyResultsKinds interface {
	AttachDependencyResultsKinds(context.Context, AnyResult, func(AnyResult) (AnyResult, error)) ([]DependencyResult, error)
}

// ScalarType represents a GraphQL Scalar type.
type ScalarType interface {
	Type
	InputDecoder
}

// Input represents any value which may be passed as an input.
type Input interface {
	// All Inputs are typed.
	Typed
	// All Inputs are able to be represented as a Literal.
	call.Literate
	// All Inputs now how to decode new instances of themselves.
	Decoder() InputDecoder

	// In principle all Inputs are able to be represented as JSON, but we don't
	// require the interface to be implemented since builtins like strings
	// (Enums) and slices (Arrays) already marshal appropriately.

	// json.Marshaler
}

// Setter allows a type to populate fields of a struct.
//
// This is how builtins are supported.
type Setter interface {
	SetField(reflect.Value) error
}

// InputDecoder is a type that knows how to decode values into Inputs.
type InputDecoder interface {
	// Decode converts a value to the Input type, if possible.
	DecodeInput(any) (Input, error)
}

// Wrapper is an interface for types that wrap another type.
type Wrapper interface {
	Unwrap() Typed
}

// UnwrapAs attempts casting val to T, unwrapping as necessary.
//
// NOTE: the order of operations is important here - it's important to first
// check compatibility with T before unwrapping, since sometimes T also
// implements Wrapper.
func UnwrapAs[T any](val any) (T, bool) {
	t, ok := val.(T)
	if ok {
		return t, true
	}
	if wrapper, ok := val.(Wrapper); ok {
		return UnwrapAs[T](wrapper.Unwrap())
	}
	return t, false
}

// Int is a GraphQL Int scalar.
type Int int64

func NewInt[T constraints.Integer](val T) Int {
	return Int(val)
}

var _ ScalarType = Int(0)

func (Int) TypeName() string {
	return "Int"
}

func (i Int) TypeDefinition(view call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.Scalar,
		Name:        i.TypeName(),
		Description: "The `Int` scalar type represents non-fractional signed whole numeric values. Int can represent values between -(2^31) and 2^31 - 1.",
		BuiltIn:     true,
	}
}

func (Int) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case int:
		return NewInt(x), nil
	case int32:
		return NewInt(x), nil
	case int64:
		return NewInt(x), nil
	case json.Number:
		i, err := x.Int64()
		if err != nil {
			return nil, err
		}
		return NewInt(i), nil
	case float64:
		if math.IsInf(x, 0) || math.IsNaN(x) {
			return nil, fmt.Errorf("cannot create Int from %v", x)
		}
		i := int64(x)
		if float64(i) != x {
			return nil, fmt.Errorf("cannot create Int from %v", x)
		}
		return NewInt(i), nil
	case string: // default struct tags
		i, err := strconv.ParseInt(x, 0, 64)
		if err != nil {
			return nil, err
		}
		return NewInt(i), nil
	default:
		return nil, fmt.Errorf("cannot create Int from %T", x)
	}
}

var _ Input = Int(0)

func (Int) Decoder() InputDecoder {
	return Int(0)
}

func (i Int) Int() int {
	return int(i)
}

func (i Int) Int64() int64 {
	return int64(i)
}

func (i Int) ToLiteral() call.Literal {
	return call.NewLiteralInt(i.Int64())
}

func (Int) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Int",
		NonNull:   true,
	}
}

func (i Int) MarshalJSON() ([]byte, error) {
	return json.Marshal(i.Int())
}

func (i *Int) UnmarshalJSON(p []byte) error {
	var num int
	if err := json.Unmarshal(p, &num); err != nil {
		return err
	}
	*i = Int(num)
	return nil
}

var _ Setter = Int(0)

func (i Int) SetField(v reflect.Value) error {
	switch v.Interface().(type) {
	case int, int64:
		v.SetInt(i.Int64())
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), i)
	}
}

// Float is a GraphQL Float scalar.
type Float float64

func NewFloat[T constraints.Float](val T) Float {
	return Float(val)
}

var _ ScalarType = Float(0)

func (Float) TypeName() string {
	return "Float"
}

func (f Float) TypeDefinition(view call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.Scalar,
		Name:        f.TypeName(),
		Description: "The `Float` scalar type represents signed double-precision fractional values as specified by [IEEE 754](http://en.wikipedia.org/wiki/IEEE_floating_point).",
		BuiltIn:     true,
	}
}

func (Float) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case float32:
		return NewFloat(float64(x)), nil
	case float64:
		return NewFloat(x), nil
	case json.Number:
		i, err := x.Float64()
		if err != nil {
			return nil, err
		}
		return NewFloat(i), nil
	case string: // default struct tags
		i, err := strconv.ParseFloat(x, 64)
		if err != nil {
			return nil, err
		}
		return NewFloat(i), nil
	default:
		return nil, fmt.Errorf("cannot create Float from %T", x)
	}
}

var _ Input = Float(0)

func (Float) Decoder() InputDecoder {
	return Float(0)
}

func (f Float) ToLiteral() call.Literal {
	return call.NewLiteralFloat(f.Float64())
}

func (f Float) Float64() float64 {
	return float64(f)
}

func (Float) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Float",
		NonNull:   true,
	}
}

func (f Float) MarshalJSON() ([]byte, error) {
	return json.Marshal(f.Float64())
}

func (f *Float) UnmarshalJSON(p []byte) error {
	var num float64
	if err := json.Unmarshal(p, &num); err != nil {
		return err
	}
	*f = Float(num)
	return nil
}

var _ Setter = Float(0)

func (f Float) SetField(v reflect.Value) error {
	switch x := v.Interface().(type) {
	case float64:
		v.SetFloat(f.Float64())
		_ = x
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), f)
	}
}

// Boolean is a GraphQL Boolean scalar.
type Boolean bool

func NewBoolean(val bool) Boolean {
	return Boolean(val)
}

var _ Typed = Boolean(false)

func (Boolean) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Boolean",
		NonNull:   true,
	}
}

var _ ScalarType = Boolean(false)

func (Boolean) TypeName() string {
	return "Boolean"
}

func (b Boolean) TypeDefinition(view call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.Scalar,
		Name:        b.TypeName(),
		Description: "The `Boolean` scalar type represents `true` or `false`.",
		BuiltIn:     true,
	}
}

func (Boolean) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case bool:
		return NewBoolean(x), nil
	case string: // from default
		b, err := strconv.ParseBool(x)
		if err != nil {
			return nil, err
		}
		return NewBoolean(b), nil
	default:
		return nil, fmt.Errorf("cannot create Boolean from %T", x)
	}
}

var _ Input = Boolean(false)

func (Boolean) Decoder() InputDecoder {
	return Boolean(false)
}

func (b Boolean) ToLiteral() call.Literal {
	return call.NewLiteralBool(b.Bool())
}

func (b Boolean) Bool() bool {
	return bool(b)
}

func (b Boolean) MarshalJSON() ([]byte, error) {
	return json.Marshal(b.Bool())
}

func (b *Boolean) UnmarshalJSON(p []byte) error {
	var val bool
	if err := json.Unmarshal(p, &val); err != nil {
		return err
	}
	*b = Boolean(val)
	return nil
}

var _ Setter = Boolean(false)

func (b Boolean) SetField(v reflect.Value) error {
	switch v.Interface().(type) {
	case bool:
		v.SetBool(b.Bool())
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), b)
	}
}

// String is a GraphQL String scalar.
type String string

func NewString(val string) String {
	return String(val)
}

var _ Typed = String("")

func (String) Type() *ast.Type {
	return &ast.Type{
		NamedType: "String",
		NonNull:   true,
	}
}

var _ ScalarType = String("")

var _ CachePayloadSizer = String("")

func (s String) CachePayloadBytes() int64 {
	return int64(len(s))
}

func (String) TypeName() string {
	return "String"
}

func (s String) TypeDefinition(view call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.Scalar,
		Name:        s.TypeName(),
		Description: "The `String` scalar type represents textual data, represented as UTF-8 character sequences. The String type is most often used by GraphQL to represent free-form human-readable text.",
		BuiltIn:     true,
	}
}

func (String) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case string:
		return NewString(x), nil
	default:
		return nil, fmt.Errorf("cannot create String from %T", x)
	}
}

var _ Input = String("")

func (String) Decoder() InputDecoder {
	return String("")
}

func (s String) ToLiteral() call.Literal {
	return call.NewLiteralString(string(s))
}

func (s String) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.String())
}

func (s *String) UnmarshalJSON(p []byte) error {
	var str string
	if err := json.Unmarshal(p, &str); err != nil {
		return err
	}
	*s = String(str)
	return nil
}

func (s String) String() string {
	return string(s)
}

var _ Setter = String("")

func (s String) SetField(v reflect.Value) error {
	switch v.Interface().(type) {
	case string:
		v.SetString(s.String())
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), s)
	}
}

// Bytes is a binary-safe GraphQL scalar. It is base64-encoded at GraphQL and
// JSON boundaries and retained as raw bytes in DagQL inputs and call recipes.
type Bytes []byte

func NewBytes(val []byte) Bytes {
	return Bytes(slices.Clone(val))
}

var _ ScalarType = Bytes(nil)

func (Bytes) TypeName() string {
	return "Bytes"
}

func (Bytes) TypeDefinition(_ call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.Scalar,
		Name:        "Bytes",
		Description: "Arbitrary binary data, represented as a base64-encoded string.",
	}
}

func (Bytes) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case string:
		decoded, err := base64.StdEncoding.DecodeString(x)
		if err != nil {
			return nil, fmt.Errorf("cannot decode Bytes from base64: %w", err)
		}
		return NewBytes(decoded), nil
	case []byte:
		return NewBytes(x), nil
	case Bytes:
		return NewBytes(x), nil
	default:
		return nil, fmt.Errorf("cannot create Bytes from %T", x)
	}
}

func (b Bytes) Decoder() InputDecoder {
	return Bytes(nil)
}

func (b Bytes) ToLiteral() call.Literal {
	return call.NewLiteralBytes(b)
}

func (Bytes) Type() *ast.Type {
	return &ast.Type{
		NamedType: "Bytes",
		NonNull:   true,
	}
}

func (b Bytes) MarshalJSON() ([]byte, error) {
	return json.Marshal(base64.StdEncoding.EncodeToString(b))
}

func (b *Bytes) UnmarshalJSON(payload []byte) error {
	var encoded string
	if err := json.Unmarshal(payload, &encoded); err != nil {
		return err
	}
	decoded, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return fmt.Errorf("cannot decode Bytes from base64: %w", err)
	}
	*b = NewBytes(decoded)
	return nil
}

func (b Bytes) Bytes() []byte {
	return slices.Clone(b)
}

func (b Bytes) SetField(v reflect.Value) error {
	switch v.Interface().(type) {
	case Bytes:
		v.Set(reflect.ValueOf(NewBytes(b)))
		return nil
	case []byte:
		v.SetBytes(slices.Clone(b))
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), b)
	}
}

type SerializedString[T any] struct {
	Self T
}

func NewSerializedString[T any](val T) SerializedString[T] {
	return SerializedString[T]{
		Self: val,
	}
}

var _ Typed = SerializedString[any]{}

func (SerializedString[T]) Type() *ast.Type {
	return &ast.Type{
		NamedType: "String",
		NonNull:   true,
	}
}

var _ InputDecoder = SerializedString[any]{}

func (SerializedString[T]) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case string:
		var v T
		err := json.Unmarshal([]byte(x), &v)
		if err != nil {
			return nil, err
		}
		return NewSerializedString(v), nil
	default:
		return nil, fmt.Errorf("cannot create SerializedString from %T", x)
	}
}

var _ Input = SerializedString[any]{}

func (s SerializedString[T]) Decoder() InputDecoder {
	return s
}

func (s SerializedString[T]) ToLiteral() call.Literal {
	return call.NewLiteralString(s.String())
}

func (s SerializedString[T]) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.Self)
}

func (s *SerializedString[T]) UnmarshalJSON(p []byte) error {
	var v T
	if err := json.Unmarshal(p, &v); err != nil {
		return err
	}
	*s = SerializedString[T]{v}
	return nil
}

func (s SerializedString[T]) String() string {
	res, err := s.MarshalJSON()
	if err != nil {
		panic(err)
	}
	return string(res)
}

var _ Setter = SerializedString[any]{}

func (s SerializedString[T]) SetField(v reflect.Value) error {
	switch v.Interface().(type) {
	case SerializedString[T]:
		v.Set(reflect.ValueOf(s))
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), s)
	}
}

type DigestedSerializedString[T any] struct {
	Self   T
	Digest digest.Digest
}

func NewDigestedSerializedString[T any](val T, dig digest.Digest) DigestedSerializedString[T] {
	return DigestedSerializedString[T]{
		Self:   val,
		Digest: dig,
	}
}

var _ Typed = DigestedSerializedString[any]{}

func (DigestedSerializedString[T]) Type() *ast.Type {
	return &ast.Type{
		NamedType: "String",
		NonNull:   true,
	}
}

var _ InputDecoder = DigestedSerializedString[any]{}

func (DigestedSerializedString[T]) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case string:
		var v T
		err := json.Unmarshal([]byte(x), &v)
		if err != nil {
			return nil, err
		}
		return NewDigestedSerializedString(v, ""), nil
	default:
		return nil, fmt.Errorf("cannot create DigestedSerializedString from %T", x)
	}
}

var _ Input = DigestedSerializedString[any]{}

func (s DigestedSerializedString[T]) Decoder() InputDecoder {
	return s
}

func (s DigestedSerializedString[T]) ToLiteral() call.Literal {
	return call.NewLiteralDigestedString(s.String(), s.Digest)
}

func (s DigestedSerializedString[T]) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.Self)
}

func (s *DigestedSerializedString[T]) UnmarshalJSON(p []byte) error {
	var v T
	if err := json.Unmarshal(p, &v); err != nil {
		return err
	}
	*s = DigestedSerializedString[T]{
		Self: v,
	}
	return nil
}

func (s DigestedSerializedString[T]) String() string {
	res, err := s.MarshalJSON()
	if err != nil {
		panic(err)
	}
	return string(res)
}

var _ Setter = DigestedSerializedString[any]{}

func (s DigestedSerializedString[T]) SetField(v reflect.Value) error {
	switch v.Interface().(type) {
	case DigestedSerializedString[T]:
		v.Set(reflect.ValueOf(s))
		return nil
	case SerializedString[T]:
		v.Set(reflect.ValueOf(SerializedString[T]{Self: s.Self}))
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), s)
	}
}

type ScalarValue interface {
	ScalarType
	Input
}

// Scalar is a GraphQL scalar.
type Scalar[T ScalarValue] struct {
	Name  string
	Value T
}

func NewScalar[T ScalarValue](name string, val T) Scalar[T] {
	return Scalar[T]{name, val}
}

var _ Typed = Scalar[ScalarValue]{}

func (s Scalar[T]) Type() *ast.Type {
	return &ast.Type{
		NamedType: s.Name,
		NonNull:   true,
	}
}

var _ ScalarValue = Scalar[ScalarValue]{}

func (s Scalar[T]) TypeName() string {
	return s.Name
}

func (s Scalar[T]) TypeDefinition(view call.View) *ast.Definition {
	def := &ast.Definition{
		Kind: ast.Scalar,
		Name: s.TypeName(),
	}
	var val T
	if isType, ok := any(val).(Descriptive); ok {
		def.Description = isType.TypeDescription()
	}
	return def
}

func (s Scalar[T]) DecodeInput(val any) (Input, error) {
	var empty T
	input, err := empty.DecodeInput(val)
	if err != nil {
		return nil, err
	}
	return NewScalar[T](s.Name, input.(T)), nil
}

var _ Input = Scalar[ScalarValue]{}

var _ Wrapper = Scalar[ScalarValue]{}

// Unwrap exposes the inner scalar value so callers (e.g. UnwrapAs) can
// reach interfaces implemented by T — for instance, when T is AnyID,
// IDable is reachable through the wrapped value.
func (s Scalar[T]) Unwrap() Typed {
	return s.Value
}

func (s Scalar[T]) Decoder() InputDecoder {
	return s
}

func (s Scalar[T]) ToLiteral() call.Literal {
	return s.Value.ToLiteral()
}

func (s Scalar[T]) MarshalJSON() ([]byte, error) {
	return json.Marshal(s.Value)
}

func (s *Scalar[T]) UnmarshalJSON(p []byte) error {
	return json.Unmarshal(p, &s.Value)
}

// AnyID is the schema type for the generic `ID!` scalar used by every object.
// Type-specific expectations are conveyed by @expectedType directives on
// fields and arguments instead of separate per-type ID scalars.
type AnyID struct {
	id *call.ID
}

func NewAnyID(id *call.ID) AnyID {
	return AnyID{id: id}
}

var _ Typed = AnyID{}

func (AnyID) Type() *ast.Type {
	return &ast.Type{
		NamedType: "ID",
		NonNull:   true,
	}
}

func (AnyID) TypeName() string {
	return "ID"
}

func (AnyID) TypeDescription() string {
	return "A unique identifier for an object."
}

var _ IDable = AnyID{}

func (a AnyID) ID() (*call.ID, error) {
	if a.id == nil {
		return nil, fmt.Errorf("nil ID")
	}
	return a.id, nil
}

var _ ScalarType = AnyID{}

func (a AnyID) TypeDefinition(_ call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.Scalar,
		Name:        "ID",
		Description: "A unique identifier for an object.",
		BuiltIn:     true,
	}
}

func (a AnyID) Decoder() InputDecoder {
	return a
}

func (a AnyID) ToLiteral() call.Literal {
	if a.id == nil {
		return call.NewLiteralString("")
	}
	return call.NewLiteralID(a.id)
}

func (AnyID) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case *call.ID:
		return AnyID{id: x}, nil
	case string:
		if x == "" {
			return nil, nil
		}
		var id call.ID
		if err := id.Decode(x); err != nil {
			return nil, fmt.Errorf("invalid ID string: %w", err)
		}
		return AnyID{id: &id}, nil
	default:
		return nil, fmt.Errorf("cannot convert %T to ID", val)
	}
}

func (a AnyID) MarshalJSON() ([]byte, error) {
	if a.id == nil {
		return json.Marshal("")
	}
	enc, err := a.id.Encode()
	if err != nil {
		return nil, err
	}
	return json.Marshal(enc)
}

// ExpectedTypeDirective creates an @expectedType(name: "Foo") directive
// for annotating ID arguments with their expected type.
func ExpectedTypeDirective(typeName string) *ast.Directive {
	return &ast.Directive{
		Name: "expectedType",
		Arguments: ast.ArgumentList{
			{
				Name: "name",
				Value: &ast.Value{
					Kind: ast.StringValue,
					Raw:  typeName,
				},
			},
		},
	}
}

// ID is a type-checked ID scalar.
type ID[T Typed] struct {
	id    *call.ID
	inner T

	// The inner type sourceMap directive so additional type
	// registered by the engine can store also store its origin.
	sourceMap *ast.Directive
}

func NewID[T Typed](id *call.ID) ID[T] {
	return ID[T]{
		id: id,
	}
}

func IDTypeNameFor(t Typed) string {
	return t.Type().Name() + "ID"
}

func IDTypeNameForRawType(t string) string {
	return t + "ID"
}

// TypeName returns "ID" — all typed IDs share the same scalar in the schema.
// The expected type is conveyed via @expectedType directives on arguments.
func (i ID[T]) TypeName() string {
	return "ID"
}

// ExpectedTypeName returns the name of the expected type for this ID,
// e.g. "Container" for ID[*Container]. Used for @expectedType directives
// and runtime validation.
func (i ID[T]) ExpectedTypeName() string {
	return i.inner.Type().Name()
}

var _ Typed = ID[Typed]{}

// Type returns the GraphQL type of the value — always `ID!`.
func (i ID[T]) Type() *ast.Type {
	return &ast.Type{
		NamedType: "ID",
		NonNull:   true,
	}
}

var _ IDable = ID[Typed]{}

// ID returns the ID of the value.
func (i ID[T]) ID() (*call.ID, error) {
	if i.id == nil {
		return nil, fmt.Errorf("nil ID")
	}
	return i.id, nil
}

var _ ScalarType = ID[Typed]{}

// TypeDefinition returns the definition for the ID scalar.
// Since all IDs share the same scalar type, this returns the
// built-in ID definition.
func (i ID[T]) TypeDefinition(view call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.Scalar,
		Name:        "ID",
		Description: "A unique identifier for an object.",
		BuiltIn:     true,
	}
}

// New creates a new ID with the given value.
//
// It accepts either an *call.ID or a string. The string is expected to be
// the base64-encoded representation of an *call.ID.
func (i ID[T]) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case *call.ID:
		if x == nil {
			return nil, fmt.Errorf("cannot create ID[%T] from nil *call.ID", i.inner)
		}
		expectedName := i.inner.Type().Name()
		if x.Type() == nil {
			return nil, fmt.Errorf("expected %q ID, got untyped ID", expectedName)
		}
		if x.Type().NamedType() != expectedName {
			return nil, fmt.Errorf("expected %q ID, got %s ID", expectedName, x.Type().ToAST())
		}
		return ID[T]{id: x, inner: i.inner}, nil
	case string:
		if err := (&i).Decode(x); err != nil {
			return nil, err
		}
		return i, nil
	default:
		return nil, fmt.Errorf("cannot create ID[%T] from %T: %#v", i.inner, x, x)
	}
}

// String returns the ID in TypeName@<encoded-id> debug format.
func (i ID[T]) String() string {
	typeName := i.inner.Type().Name()
	if i.id == nil {
		return fmt.Sprintf("%s@<nil>", typeName)
	}
	enc, err := i.id.Encode()
	if err != nil {
		return fmt.Sprintf("%s@<encode-error:%v>", typeName, err)
	}
	return fmt.Sprintf("%s@%s", typeName, enc)
}

var _ Setter = ID[Typed]{}

func (i ID[T]) SetField(v reflect.Value) error {
	id, err := i.ID()
	if err != nil {
		return err
	}
	switch v.Interface().(type) {
	case *call.ID:
		v.Set(reflect.ValueOf(id))
		return nil
	default:
		return fmt.Errorf("cannot set field of type %T with %T", v.Interface(), i)
	}
}

// For parsing string IDs provided in queries.
var _ Input = ID[Typed]{}

func (i ID[T]) Decoder() InputDecoder {
	return ID[T]{inner: i.inner}
}

func (i ID[T]) ToLiteral() call.Literal {
	if i.id == nil {
		panic("dagql.ID.ToLiteral: nil ID")
	}
	if !i.id.IsHandle() {
		panic("dagql.ID.ToLiteral: recipe-form IDs are not valid inputs")
	}
	enc, err := i.id.Encode()
	if err != nil {
		panic(fmt.Errorf("dagql.ID.ToLiteral: encode handle ID: %w", err))
	}
	return call.NewLiteralString(enc)
}

func (i ID[T]) Encode() (string, error) {
	return i.id.Encode()
}

func (i ID[T]) Display() string {
	return i.id.Display()
}

func (i *ID[T]) Decode(str string) error {
	if str == "" {
		return fmt.Errorf("cannot decode empty string as ID")
	}
	var idp call.ID
	if err := idp.Decode(str); err != nil {
		return err
	}
	// Runtime type validation: check that the ID's embedded type matches
	// the expected type. This catches programming errors where the wrong
	// ID is passed.
	expectedName := i.inner.Type().Name()
	if expectedName != "" && idp.Type() != nil {
		if idp.Type().NamedType() != expectedName {
			return fmt.Errorf("expected %q ID, got %s ID", expectedName, idp.Type().ToAST())
		}
	}
	i.id = &idp
	return nil
}

// For returning responses.
var _ json.Marshaler = ID[Typed]{}

func (i ID[T]) MarshalJSON() ([]byte, error) {
	enc, err := i.Encode()
	if err != nil {
		return nil, err
	}
	return json.Marshal(enc)
}

// Not actually used, but implemented for completeness.
//
// FromValue is what's used in practice.
var _ json.Unmarshaler = (*ID[Typed])(nil)

func (i *ID[T]) UnmarshalJSON(p []byte) error {
	var str string
	if err := json.Unmarshal(p, &str); err != nil {
		return err
	}
	return i.Decode(str)
}

// Load loads the instance with the given ID from the server.
func (i ID[T]) Load(ctx context.Context, server *Server) (res ObjectResult[T], _ error) {
	if i.id == nil {
		return res, fmt.Errorf("load %s: nil ID", i.TypeName())
	}
	val, err := server.Load(ctx, i.id)
	if err != nil {
		return res, fmt.Errorf("load %s: %w", i.String(), err)
	}
	obj, ok := val.(ObjectResult[T])
	if !ok {
		return res, fmt.Errorf("load %s: expected %T, got %T", i.String(), obj, val)
	}
	return obj, nil
}

// Enumerable is a value that has a length and allows indexing.
type Enumerable interface {
	// Element returns the element of the Enumerable.
	Element() Typed
	// Len returns the number of elements in the Enumerable.
	Len() int
	// Nth returns the Nth element of the Enumerable, with 1 representing the
	// first entry.
	Nth(int) (Typed, error)

	NthValue(i int, call *ResultCall) (AnyResult, error)
}

// valueEnumerable is an Enumerable that holds plain values rather than
// results: its NthValue wraps an element in a detached result with a deep copy
// of the list's call frame. Server.resolvePath reads the elements of such a
// list directly when they're leaves of the query, since a leaf element needs
// no result of its own, and copying the frame once per element is quadratic
// when the call has a large list argument.
type valueEnumerable interface {
	Enumerable
	valueEnumerable()
}

// leafValues returns the elements of a valueEnumerable as resolvePath would
// render them as leaves of a query through NthValue: a null nullable is nil,
// and a non-null one is its value.
func leafValues(values valueEnumerable) ([]any, error) {
	results := make([]any, values.Len())
	for nth := 1; nth <= len(results); nth++ {
		elem, err := values.Nth(nth)
		if err != nil {
			return nil, fmt.Errorf("nth %d: %w", nth, err)
		}
		results[nth-1] = leafValue(elem)
	}
	return results, nil
}

// leafValue returns an element of a valueEnumerable as a leaf (see
// leafValues).
func leafValue(elem Typed) Typed {
	if elem == nil {
		return nil
	}
	if derefable, ok := elem.(Derefable); ok {
		inner, valid := derefable.Deref()
		if !valid {
			return nil
		}
		if inner != nil {
			return inner
		}
	}
	return elem
}

// Array is an array of GraphQL values.
type ArrayInput[I Input] []I

func MapArrayInput[T Input, R Typed](opt ArrayInput[T], fn func(T) (R, error)) (Array[R], error) {
	r := make(Array[R], len(opt))
	for i, val := range opt {
		var err error
		r[i], err = fn(val)
		if err != nil {
			return nil, fmt.Errorf("map array[%d]: %w", i, err)
		}
	}
	return r, nil
}

func (a ArrayInput[S]) ToArray() Array[S] {
	return Array[S](a)
}

var _ Typed = ArrayInput[Input]{}

func (a ArrayInput[S]) Type() *ast.Type {
	var elem S
	return &ast.Type{
		Elem:    elem.Type(),
		NonNull: true,
	}
}

var _ Input = ArrayInput[Input]{}

func (a ArrayInput[S]) Decoder() InputDecoder {
	return a
}

func (a ArrayInput[S]) resultCallArrayValues() []Input {
	values := make([]Input, len(a))
	for i, val := range a {
		values[i] = val
	}
	return values
}

var _ InputDecoder = ArrayInput[Input]{}

func (a ArrayInput[I]) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case []any:
		var zero I
		decoder := zero.Decoder()

		arr := make(ArrayInput[I], len(x))
		for i, val := range x {
			elem, err := decoder.DecodeInput(val)
			if err != nil {
				return nil, fmt.Errorf("ArrayInput.New[%d]: %w", i, err)
			}
			arr[i] = elem.(I) // TODO sus
		}
		return arr, nil
	case string: // default
		var vals []any
		dec := json.NewDecoder(strings.NewReader(x))
		dec.UseNumber()
		if err := dec.Decode(&vals); err != nil {
			return nil, fmt.Errorf("decode %q: %w", x, err)
		}
		return a.DecodeInput(vals)
	default:
		return nil, fmt.Errorf("cannot create ArrayInput from %T", x)
	}
}

func (i ArrayInput[S]) ToLiteral() call.Literal {
	lits := make([]call.Literal, 0, len(i))
	for _, elem := range i {
		lits = append(lits, elem.ToLiteral())
	}
	return call.NewLiteralList(lits...)
}

var _ Setter = ArrayInput[Input]{}

func (d ArrayInput[I]) SetField(val reflect.Value) error {
	if val.Kind() != reflect.Slice {
		return fmt.Errorf("expected slice, got %v", val.Kind())
	}
	val.Set(reflect.MakeSlice(val.Type(), len(d), len(d)))
	for i, elem := range d {
		if err := assign(val.Index(i), elem); err != nil {
			return err
		}
	}
	return nil
}

// Array is an array of GraphQL values.
type Array[T Typed] []T

// ToArray creates a new Array by applying the given function to each element
// of the given slice.
func ToArray[A any, T Typed](fn func(A) T, elems ...A) Array[T] {
	arr := make(Array[T], len(elems))
	for i, elem := range elems {
		arr[i] = fn(elem)
	}
	return arr
}

func NewStringArray(elems ...string) Array[String] {
	return ToArray(NewString, elems...)
}

func NewBoolArray(elems ...bool) Array[Boolean] {
	return ToArray(NewBoolean, elems...)
}

func NewIntArray[T constraints.Integer](elems ...T) Array[Int] {
	return ToArray(NewInt, elems...)
}

func NewFloatArray[T constraints.Float](elems ...T) Array[Float] {
	return ToArray(NewFloat, elems...)
}

func NewBooleanArray(elems ...bool) Array[Boolean] {
	return ToArray(NewBoolean, elems...)
}

var _ Typed = Array[Typed]{}

func (i Array[T]) Type() *ast.Type {
	var t T
	return &ast.Type{
		Elem:    t.Type(),
		NonNull: true,
	}
}

var _ Enumerable = Array[Typed]{}

func (arr Array[T]) Element() Typed {
	var t T
	return t
}

func (arr Array[T]) Len() int {
	return len(arr)
}

func (arr Array[T]) nth(i int) (T, error) {
	if i < 1 || i > len(arr) {
		var zero T
		return zero, fmt.Errorf("index %d out of bounds", i)
	}
	return arr[i-1], nil
}

func (arr Array[T]) Nth(i int) (Typed, error) {
	return arr.nth(i)
}

func (arr Array[T]) NthValue(i int, call *ResultCall) (AnyResult, error) {
	t, err := arr.nth(i)
	if err != nil {
		return nil, err
	}

	if call == nil {
		return nil, fmt.Errorf("index %d from %T without call frame", i, arr)
	}
	elemCall := call.clone()
	elemCall.Nth = int64(i)
	if elemCall.Type != nil {
		elemCall.Type = elemCall.Type.Elem
	}
	return newDetachedResult(elemCall, t), nil
}

func (Array[T]) valueEnumerable() {}

type ResultArray[T Typed] []Result[T]

var _ Typed = ResultArray[Typed]{}
var _ Enumerable = ResultArray[Typed]{}

func (i ResultArray[T]) Type() *ast.Type {
	var t T
	return &ast.Type{
		Elem:    t.Type(),
		NonNull: true,
	}
}

func (arr ResultArray[T]) Element() Typed {
	var t T
	return t
}

func (arr ResultArray[T]) Len() int {
	return len(arr)
}

func (arr ResultArray[T]) nth(i int) (res Result[T], _ error) {
	if i < 1 || i > len(arr) {
		return res, fmt.Errorf("index %d out of bounds", i)
	}
	return arr[i-1], nil
}

func (arr ResultArray[T]) Nth(i int) (Typed, error) {
	inst, err := arr.nth(i)
	if err != nil {
		return nil, err
	}
	return inst.Self(), nil
}

func (arr ResultArray[T]) NthValue(i int, _ *ResultCall) (AnyResult, error) {
	inst, err := arr.nth(i)
	if err != nil {
		return nil, err
	}

	return inst, nil
}

type ObjectResultArray[T Typed] []ObjectResult[T]

var _ Typed = ObjectResultArray[Typed]{}
var _ Enumerable = ObjectResultArray[Typed]{}
var _ HasDependencyResults = ObjectResultArray[Typed]{}

func (i ObjectResultArray[T]) Type() *ast.Type {
	var t T
	return &ast.Type{
		Elem:    t.Type(),
		NonNull: true,
	}
}

func (arr ObjectResultArray[T]) Element() Typed {
	var t T
	return t
}

func (arr ObjectResultArray[T]) Len() int {
	return len(arr)
}

func (arr ObjectResultArray[T]) nth(i int) (res ObjectResult[T], _ error) {
	if i < 1 || i > len(arr) {
		return res, fmt.Errorf("index %d out of bounds", i)
	}
	return arr[i-1], nil
}

func (arr ObjectResultArray[T]) Nth(i int) (Typed, error) {
	inst, err := arr.nth(i)
	if err != nil {
		return nil, err
	}
	return inst.Self(), nil
}

func (arr ObjectResultArray[T]) NthValue(i int, _ *ResultCall) (AnyResult, error) {
	inst, err := arr.nth(i)
	if err != nil {
		return nil, err
	}

	return inst, nil
}

func (arr ObjectResultArray[T]) AttachDependencyResults(
	_ context.Context,
	_ AnyResult,
	attach func(AnyResult) (AnyResult, error),
) ([]AnyResult, error) {
	owned := make([]AnyResult, 0, len(arr))
	for i, child := range arr {
		attached, err := attach(child)
		if err != nil {
			return nil, err
		}
		if attached == nil {
			arr[i] = ObjectResult[T]{}
			continue
		}
		typed, ok := attached.(ObjectResult[T])
		if !ok {
			return nil, fmt.Errorf("attach object result array child %d: unexpected result %T", i, attached)
		}
		arr[i] = typed
		owned = append(owned, typed)
	}
	return owned, nil
}

type enumValue interface {
	Input
	~string
}

type EnumValue[T enumValue] struct {
	Value       T
	Underlying  T
	Description string
	View        ViewFilter
}

// EnumValues is a list of possible values for an Enum.
type EnumValues[T enumValue] []EnumValue[T]

// NewEnum creates a new EnumType with the given possible values.
func NewEnum[T enumValue](vals ...T) *EnumValues[T] {
	enum := make(EnumValues[T], 0, len(vals))
	for _, val := range vals {
		enum = append(enum, EnumValue[T]{
			Value: val,
		})
	}
	return &enum
}

func (e *EnumValues[T]) Type() *ast.Type {
	var zero T
	return zero.Type()
}

func (e *EnumValues[T]) TypeName() string {
	return e.Type().Name()
}

func (e *EnumValues[T]) TypeDefinition(view call.View) *ast.Definition {
	def := &ast.Definition{
		Kind:       ast.Enum,
		Name:       e.TypeName(),
		EnumValues: e.PossibleValues(view),
	}
	var val T
	if isType, ok := any(val).(Descriptive); ok {
		def.Description = isType.TypeDescription()
	}
	return def
}

func (e *EnumValues[T]) DecodeInput(val any) (Input, error) {
	if enum, ok := val.(T); ok {
		val = string(enum)
	}

	v, err := (&EnumValueName{Enum: e.TypeName()}).DecodeInput(val)
	if err != nil {
		return nil, err
	}
	return e.Lookup(v.(*EnumValueName).Name)
}

func (e *EnumValues[T]) PossibleValues(view call.View) ast.EnumValueList {
	var values ast.EnumValueList
	for _, val := range *e {
		if val.View != nil && !val.View.Contains(view) {
			continue
		}
		def := &ast.EnumValueDefinition{
			Name:        string(val.Value),
			Description: val.Description,
		}
		if val.Value != val.Underlying {
			def.Directives = append(def.Directives, enumValueDirectives(val.Underlying)...)
		}
		values = append(values, def)
	}

	return values
}

func enumValueDirectives[T enumValue](value T) []*ast.Directive {
	var zero T
	if value == zero {
		return nil
	}

	return []*ast.Directive{
		{
			Name: "enumValue",
			Arguments: ast.ArgumentList{
				{
					Name: "value",
					Value: &ast.Value{
						Kind: ast.StringValue,
						Raw:  string(value),
					},
				},
			},
		},
	}
}

func (e *EnumValues[T]) Literal(val T) call.Literal {
	return call.NewLiteralEnum(string(val))
}

func (e *EnumValues[T]) Lookup(val string) (T, error) {
	var zero T
	for _, possible := range *e {
		if val == string(possible.Value) {
			if possible.Underlying != zero {
				return possible.Underlying, nil
			}
			return possible.Value, nil
		}
	}
	return zero, fmt.Errorf("invalid enum member %q for %T", val, zero)
}

func (e *EnumValues[T]) Register(val T, desc ...string) T {
	return e.RegisterView(val, nil, desc...)
}

func (e *EnumValues[T]) RegisterView(val T, view ViewFilter, desc ...string) T {
	*e = append(*e, EnumValue[T]{
		Value:       val,
		Description: FormatDescription(desc...),
		View:        view,
	})
	return val
}

func (e *EnumValues[T]) Alias(val T, target T) T {
	return e.AliasView(val, target, nil)
}

func (e *EnumValues[T]) AliasView(val T, target T, view ViewFilter) T {
	for _, v := range *e {
		if v.Value == target {
			*e = append(*e, EnumValue[T]{
				Value:       val,
				Underlying:  v.Value,
				Description: v.Description,
				View:        view,
			})
			return val
		}
	}
	panic(fmt.Sprintf("cannot find enum %q", target))
}

func (e *EnumValues[T]) Install(srv *Server, filter ...ViewFilter) {
	srv.InstallScalar(e, filter...)
}

type EnumValueName struct {
	Enum string
	Name string
}

var _ Input = &EnumValueName{}

func (e *EnumValueName) TypeName() string {
	return e.Enum
}

func (e *EnumValueName) Type() *ast.Type {
	return &ast.Type{
		NamedType: e.Enum,
		NonNull:   true,
	}
}

func (e *EnumValueName) TypeDefinition(view call.View) *ast.Definition {
	return &ast.Definition{
		Kind: ast.Enum,
		Name: e.TypeName(),
	}
}

func (e *EnumValueName) ToLiteral() call.Literal {
	return call.NewLiteralEnum(e.Name)
}

func (e *EnumValueName) Decoder() InputDecoder {
	return e
}

func (e *EnumValueName) DecodeInput(val any) (Input, error) {
	switch x := val.(type) {
	case *EnumValueName:
		return &EnumValueName{Enum: e.Enum, Name: x.Name}, nil
	case string:
		return &EnumValueName{Enum: e.Enum, Name: x}, nil
	case bool:
		return nil, fmt.Errorf("invalid enum name %t", x)
	case nil:
		return nil, fmt.Errorf("invalid enum name null")
	default:
		return nil, fmt.Errorf("cannot create enum name from %T", x)
	}
}

func (e *EnumValueName) MarshalJSON() ([]byte, error) {
	return json.Marshal(e.Name)
}

func MustInputSpec(val Type) InputObjectSpec {
	spec := InputObjectSpec{
		Name: val.TypeName(),
	}
	if desc, ok := val.(Descriptive); ok {
		spec.Description = desc.TypeDescription()
	}
	inputs, err := InputSpecsForType(val, true)
	if err != nil {
		panic(fmt.Errorf("input specs for %T: %w", val, err))
	}
	spec.Fields = inputs
	return spec
}

type InputObjectSpec struct {
	Name        string
	Description string
	Fields      InputSpecs
}

func (spec InputObjectSpec) Install(srv *Server, filter ...ViewFilter) {
	srv.InstallTypeDef(spec, filter...)
}

func (spec InputObjectSpec) Type() *ast.Type {
	return &ast.Type{
		NamedType: spec.Name,
		NonNull:   true,
	}
}

func (spec InputObjectSpec) TypeName() string {
	return spec.Name
}

func (spec InputObjectSpec) TypeDefinition(view call.View) *ast.Definition {
	return &ast.Definition{
		Kind:        ast.InputObject,
		Name:        spec.Name,
		Description: spec.Description,
		Fields:      spec.Fields.FieldDefinitions(view),
	}
}
