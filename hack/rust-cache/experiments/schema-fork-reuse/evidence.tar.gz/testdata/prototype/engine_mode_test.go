package dagql

import "testing"

func TestForkInterfaceStateCandidate(t *testing.T) {
	previous := reuseForkInterfaceState.Swap(true)
	t.Cleanup(func() { reuseForkInterfaceState.Store(previous) })
	t.Run("relationships", TestForkInterfaceStatePreservesRelationshipsAndInstalls)
	t.Run("view", TestForkInterfaceStateRechecksChangedView)
	t.Run("fields", TestForkInterfaceStateRechecksClassChanges)
	t.Run("hooks", TestForkInterfaceStateRetainsHookInvalidation)
}
