from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).parent
base=root.parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
common=[go,'test','-p','2','-buildvcs=false']
steps=[('standalone-full-dagql-race',common+['-overlay',str(root/'refined-overlay.json'),'-race','-count=1','./dagql'],'/tmp/dagger-compaction-ownership-only'),
('controlled-candidate-focused-race',common+['-modfile',str(base/'otel-evicted-queue/engine.go.mod'),'-overlay',str(root/'engine-overlay.json'),'-race','-count=1','-v','-run','^TestForkInterfaceStateCandidate$','./dagql'],'/tmp/dagger-filesync-snapshot-seeds'),
('engine-build',[go,'build','-p','2','-buildvcs=false','-modfile',str(base/'otel-evicted-queue/engine.go.mod'),'-overlay',str(root/'engine-overlay.json'),'-o',str(root/'dagger-engine'),'./cmd/engine'],'/tmp/dagger-filesync-snapshot-seeds')]
rows=[]
for name,command,cwd in steps:
 begin=time.monotonic()
 with (root/(name+'.log')).open('w') as stream:result=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row=dict(name=name,command=command,cwd=cwd,seconds=time.monotonic()-begin,exit_code=result.returncode)
 if name=='engine-build' and result.returncode==0:row['sha256']=hashlib.sha256((root/'dagger-engine').read_bytes()).hexdigest()
 rows.append(row);(root/'full-validation-build.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,result.returncode,round(row['seconds'],3),flush=True)
 if result.returncode:print((root/(name+'.log')).read_text()[-6000:],flush=True)
 assert result.returncode==0
