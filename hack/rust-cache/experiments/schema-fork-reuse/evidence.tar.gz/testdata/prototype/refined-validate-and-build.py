from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).parent
go='/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='8',CGO_ENABLED='1')
rows=[]
for phase in ['focused-race','build-component']:
 for arm in ['baseline','refined']:
  command=[go,'test','-p','2','-buildvcs=false','-overlay',str(root/(arm+'-overlay.json'))]
  if phase=='focused-race':command+=['-v','-race','-count=1','-run','^TestForkInterfaceState','./dagql']
  else:command+=['-c','-o',str(root/(arm+'.test')),'./dagql']
  name=arm+'-'+phase
  begin=time.monotonic()
  with (root/(name+'.log')).open('w') as stream:result=subprocess.run(command,cwd='/tmp/dagger-compaction-ownership-only',env=env,stdout=stream,stderr=subprocess.STDOUT)
  row=dict(arm=arm,phase=phase,command=command,seconds=time.monotonic()-begin,exit_code=result.returncode)
  if phase=='build-component' and result.returncode==0:row['sha256']=hashlib.sha256((root/(arm+'.test')).read_bytes()).hexdigest()
  rows.append(row);(root/'refined-validation-and-builds.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(name,result.returncode,round(row['seconds'],3),flush=True)
  if result.returncode:print((root/(name+'.log')).read_text()[-6000:],flush=True)
  assert result.returncode==0
