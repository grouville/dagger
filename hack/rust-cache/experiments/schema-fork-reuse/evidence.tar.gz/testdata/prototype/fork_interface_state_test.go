package dagql

import (
	"fmt"
	"testing"
	"time"

	"github.com/dagger/dagger/dagql/call"
	"github.com/stretchr/testify/require"
	"github.com/vektah/gqlparser/v2/ast"
)

type forkStateType struct{ name string }

func (t *forkStateType) Type() *ast.Type {
	name := "Query"
	if t != nil && t.name != "" {
		name = t.name
	}
	return &ast.Type{NamedType: name, NonNull: true}
}

func forkStateClass(srv *Server, name string, fields ...Field[*forkStateType]) Class[*forkStateType] {
	class := NewClass(srv, ClassOpts[*forkStateType]{Typed: &forkStateType{name: name}})
	class.Install(fields...)
	return srv.InstallObject(class).(Class[*forkStateType])
}

func forkStateField(name string, filter ViewFilter) Field[*forkStateType] {
	return Field[*forkStateType]{Spec: &FieldSpec{Name: name, Type: String(""), ViewFilter: filter}}
}

func forkStateInterface(name, field string) *Interface {
	iface := NewInterface(name, "")
	iface.AddField(InterfaceFieldSpec{FieldSpec: FieldSpec{Name: field, Type: String("")}})
	return iface
}

func forkStateHasInterface(t testing.TB, srv *Server, object, iface string) bool {
	t.Helper()
	obj, ok := srv.ObjectType(object)
	require.True(t, ok)
	for _, candidate := range obj.(objectTypeWithInterfaces).Interfaces() {
		if candidate.TypeName() == iface {
			return true
		}
	}
	return false
}

func TestForkInterfaceStatePreservesRelationshipsAndInstalls(t *testing.T) {
	for _, initiallyResolved := range []bool{false, true} {
		t.Run(fmt.Sprint(initiallyResolved), func(t *testing.T) {
			base := newDagqlServerForTest(t, &forkStateType{name: "Query"})
			forkStateClass(base, "Item", forkStateField("name", nil))
			base.InstallInterface(forkStateInterface("Named", "name"))
			if initiallyResolved {
				require.True(t, forkStateHasInterface(t, base, "Item", "Named"))
			}
			fork, err := base.Fork(t.Context(), &forkStateType{name: "Query"})
			require.NoError(t, err)
			require.True(t, forkStateHasInterface(t, fork, "Item", "Named"))
			forkStateClass(fork, "LaterItem", forkStateField("name", nil))
			require.True(t, forkStateHasInterface(t, fork, "LaterItem", "Named"))
			_, exists := base.ObjectType("LaterItem")
			require.False(t, exists)
			fork.InstallInterface(forkStateInterface("LaterNamed", "name"))
			require.True(t, forkStateHasInterface(t, fork, "Item", "LaterNamed"))
			_, exists = base.InterfaceType("LaterNamed")
			require.False(t, exists)
		})
	}
}

// A schema fork normally keeps the view, but callers can select another API
// version before the first lookup. Reusing the original clean bit alone loses
// relationships that become valid in that view.
func TestForkInterfaceStateRechecksChangedView(t *testing.T) {
	base := newDagqlServerForTest(t, &forkStateType{name: "Query"})
	base.View = call.View("hidden")
	forkStateClass(base, "Item", forkStateField("name", ExactView("visible")))
	base.InstallInterface(forkStateInterface("Named", "name"))
	require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
	fork, err := base.Fork(t.Context(), &forkStateType{name: "Query"})
	require.NoError(t, err)
	fork.View = call.View("visible")
	require.True(t, forkStateHasInterface(t, fork, "Item", "Named"))
	require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
}

func TestForkInterfaceStateRechecksClassChanges(t *testing.T) {
	for _, extend := range []bool{false, true} {
		t.Run(fmt.Sprint(extend), func(t *testing.T) {
			base := newDagqlServerForTest(t, &forkStateType{name: "Query"})
			forkStateClass(base, "Item")
			base.InstallInterface(forkStateInterface("Named", "name"))
			require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
			fork, err := base.Fork(t.Context(), &forkStateType{name: "Query"})
			require.NoError(t, err)
			// InstallObject can retrieve an existing class without a lookup that
			// consumes the fork's pending inference pass.
			class := fork.objects["Item"].(Class[*forkStateType])
			if extend {
				class.Extend(FieldSpec{Name: "name", Type: String("")}, nil)
			} else {
				class.Install(forkStateField("name", nil))
			}
			require.True(t, forkStateHasInterface(t, fork, "Item", "Named"))
			require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
		})
	}
}

type forkStateInstallHook struct{}

func (forkStateInstallHook) InstallObject(ObjectType, ...*ast.Directive)    {}
func (forkStateInstallHook) InstallInterface(*Interface, ...*ast.Directive) {}
func (hook forkStateInstallHook) ForkInstallHook(srv *Server) InstallHook {
	srv.objects["Item"].(Class[*forkStateType]).Install(forkStateField("name", nil))
	return hook
}

func TestForkInterfaceStateRetainsHookInvalidation(t *testing.T) {
	base := newDagqlServerForTest(t, &forkStateType{name: "Query"})
	forkStateClass(base, "Item")
	base.InstallInterface(forkStateInterface("Named", "name"))
	base.AddInstallHook(forkStateInstallHook{})
	require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
	fork, err := base.Fork(t.Context(), &forkStateType{name: "Query"})
	require.NoError(t, err)
	require.True(t, forkStateHasInterface(t, fork, "Item", "Named"))
	require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
}

type forkStateBeforeClone struct {
	Class[*forkStateType]
	before func() error
}

func (class forkStateBeforeClone) ForkObjectType(srv *Server) (ObjectType, error) {
	if err := class.before(); err != nil {
		return nil, err
	}
	return class.Class.ForkObjectType(srv)
}

func TestForkInterfaceStateConcurrentFieldChange(t *testing.T) {
	base := newDagqlServerForTest(t, &forkStateType{name: "Query"})
	class := forkStateClass(base, "Item")
	base.InstallInterface(forkStateInterface("Named", "name"))
	require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
	done := make(chan struct{})
	base.objects["Item"] = forkStateBeforeClone{Class: class, before: func() error {
		go func() {
			class.Install(forkStateField("name", nil))
			close(done)
		}()
		select {
		case <-done:
			return nil
		case <-time.After(5 * time.Second):
			return fmt.Errorf("field update blocked during schema cloning")
		}
	}}
	fork, err := base.Fork(t.Context(), &forkStateType{name: "Query"})
	// A failed fork releases the source lock, so join the updater in both arms.
	<-done
	require.NoError(t, err)
	require.True(t, forkStateHasInterface(t, fork, "Item", "Named"))
}

func TestForkInterfaceStateConcurrentFieldVisibility(t *testing.T) {
	base := newDagqlServerForTest(t, &forkStateType{name: "Query"})
	class := forkStateClass(base, "Item")
	base.InstallInterface(forkStateInterface("Named", "name"))
	require.False(t, forkStateHasInterface(t, base, "Item", "Named"))
	done := make(chan struct{})
	base.objects["Item"] = forkStateBeforeClone{Class: class, before: func() error {
		go func() {
			class.Install(forkStateField("name", nil))
			close(done)
		}()
		deadline := time.NewTimer(5 * time.Second)
		defer deadline.Stop()
		tick := time.NewTicker(time.Millisecond)
		defer tick.Stop()
		for {
			// Wait only for the field to become visible. The updater may still
			// be invalidating inference; cloning never waits for its completion.
			if _, exists := class.FieldSpec("name", ""); exists {
				return nil
			}
			select {
			case <-tick.C:
			case <-deadline.C:
				return fmt.Errorf("field did not become visible during cloning")
			}
		}
	}}
	fork, err := base.Fork(t.Context(), &forkStateType{name: "Query"})
	<-done
	require.NoError(t, err)
	forkedClass := fork.objects["Item"]
	_, exists := forkedClass.FieldSpec("name", "")
	require.True(t, exists, "the clone includes the edited field")
	require.True(t, forkStateHasInterface(t, fork, "Item", "Named"), "relationships must describe the cloned fields")
}
