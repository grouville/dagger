from pathlib import Path
import hashlib,json
root=Path(__file__).parent
base=root.parent
work=Path('/tmp/dagger-filesync-snapshot-seeds')
overlay=json.loads((base/'trivial-scalar-projection/engine-overlay.json').read_text())
server=Path(overlay['Replace'][str(work/'dagql/server.go')]).read_text()
assert server.count('\tinterfacesDirty bool')==1
server=server.replace('\tinterfacesDirty bool','\tinterfacesDirty bool\n\tinterfacesView call.View',1)
needle="\ts.installLock.RLock()\n\tdefer s.installLock.RUnlock()\n\n\tfor name, iface := range s.interfaces {"
replacement="\ts.installLock.RLock()\n\tdefer s.installLock.RUnlock()\n\n\tif reuseForkInterfaceState.Load() {\n\t\tout.interfacesDirty = s.interfacesDirty\n\t\tout.interfacesView = s.interfacesView\n\t}\n\n\tfor name, iface := range s.interfaces {"
assert server.count(needle)==1
server=server.replace(needle,replacement,1)
needle="\t// Forked object types are fresh instances, so reconcile their interface\n\t// implementations on first read rather than assuming the fork carried them.\n\tout.interfacesDirty = true"
assert server.count(needle)==1
server=server.replace(needle,"\tif !reuseForkInterfaceState.Load() {\n\t\tout.interfacesDirty = true\n\t}",1)
needle="func (s *Server) reconcileInterfaceImplsIfDirty() {\n\ts.installLock.RLock()\n\tdirty := s.interfacesDirty"
assert server.count(needle)==1
server=server.replace(needle,"func (s *Server) reconcileInterfaceImplsIfDirty() {\n\treuse := reuseForkInterfaceState.Load()\n\ts.installLock.RLock()\n\tdirty := s.interfacesDirty || (reuse && s.interfacesView != s.View)",1)
needle="\tif s.interfacesDirty {\n\t\ts.interfacesDirty = false\n\t\ts.reconcileInterfaceImplsLocked(s.View)\n\t}"
assert server.count(needle)==1
server=server.replace(needle,"\tif s.interfacesDirty || (reuse && s.interfacesView != s.View) {\n\t\ts.interfacesDirty = false\n\t\ts.reconcileInterfaceImplsLocked(s.View)\n\t\ts.interfacesView = s.View\n\t}",1)
(root/'controlled-server.go').write_text(server)
objects=Path(overlay['Replace'][str(work/'dagql/objects.go')]).read_text()
needle="func (class Class[T]) Install(fields ...Field[T]) {\n\tclass.fieldsL.Lock()\n\tdefer class.fieldsL.Unlock()"
assert objects.count(needle)==1
objects=objects.replace(needle,"func (class Class[T]) Install(fields ...Field[T]) {\n\tclass.fieldsL.Lock()\n\tdefer func() {\n\t\tclass.fieldsL.Unlock()\n\t\tif reuseForkInterfaceState.Load() {\n\t\t\tif srv := class.server.Value(); srv != nil {\n\t\t\t\tsrv.markInterfacesDirty()\n\t\t\t}\n\t\t}\n\t}()",1)
start=objects.index('func (class Class[T]) Extend(')
end=objects.index('\n}\n',start)+3
extend=objects[start:end]
assert extend.count('\tclass.invalidateSchemaCache()')==1
extend=extend.replace('\tclass.invalidateSchemaCache()','\tclass.invalidateSchemaCache()\n\tif reuseForkInterfaceState.Load() {\n\t\tif srv := class.server.Value(); srv != nil {\n\t\t\tsrv.markInterfacesDirty()\n\t\t}\n\t}',1)
objects=objects[:start]+extend+objects[end:]
needle="\tserver.markInterfacesDirty()"
assert objects.count(needle)==1
objects=objects.replace(needle,"\tif !reuseForkInterfaceState.Load() {\n\t\tserver.markInterfacesDirty()\n\t}",1)
(root/'controlled-objects.go').write_text(objects)
mode=(base/'trivial-scalar-projection/mode.go').read_text().replace('directTrivialScalarFields','reuseForkInterfaceState').replace('TrivialScalarFieldsDiagnostic','ForkInterfaceStateDiagnostic')
(root/'mode.go').write_text(mode)
debug=Path(overlay['Replace'][str(work/'cmd/engine/debug.go')]).read_text()
needle='m.HandleFunc("/debug/trivial-scalar-fields", dagql.TrivialScalarFieldsDiagnostic)'
assert debug.count(needle)==1
debug=debug.replace(needle,needle+'\n\tm.HandleFunc("/debug/fork-interface-state", dagql.ForkInterfaceStateDiagnostic)',1)
(root/'debug.go').write_text(debug)
for target,local in [('dagql/server.go','controlled-server.go'),('dagql/objects.go','controlled-objects.go'),('dagql/fork_interface_state_mode.go','mode.go'),('cmd/engine/debug.go','debug.go')]:overlay['Replace'][str(work/target)]=str(root/local)
for name in ['fork_interface_state_test.go','fork_interface_state_bench_test.go']:
 overlay['Replace'][str(work/'dagql'/name)]=str(root/name)
(root/'engine-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
(root/'prepared-engine-identity.json').write_text(json.dumps(dict(base_selected_sha256='9123a6a58dbfe9c584e72d3882d2fc635374542a17a58e9c23f456b991568c08',base_overlay_sha256=hashlib.sha256((base/'trivial-scalar-projection/engine-overlay.json').read_bytes()).hexdigest(),schema_fork_reuse_default=False,other_modes_unchanged=True),indent=2)+'\n')
print('Prepared controlled engine overlay; no build or installation yet.')
