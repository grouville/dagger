from pathlib import Path
import difflib
import json

root=Path(__file__).parent
work=Path('/tmp/dagger-compaction-ownership-only')
original=(work/'dagql/server.go').read_text()
needle='''	// Forked object types are fresh instances, so reconcile their interface
	// implementations on first read rather than assuming the fork carried them.
	out.interfacesDirty = true'''
assert original.count(needle)==1
naive=original.replace(needle,'''\t// ForkObjectType preserves the installed schema, including relationships.
\tout.interfacesDirty = s.interfacesDirty''')
tracked=naive.replace('\tinterfacesDirty bool','\tinterfacesDirty bool\n\tinterfacesView call.View',1)
tracked=tracked.replace('\tout.interfacesDirty = s.interfacesDirty','\tout.interfacesDirty = s.interfacesDirty\n\tout.interfacesView = s.interfacesView',1)
tracked=tracked.replace('\tdirty := s.interfacesDirty\n','\tdirty := s.interfacesDirty || s.interfacesView != s.View\n',1)
tracked=tracked.replace('''	if s.interfacesDirty {
		s.interfacesDirty = false
		s.reconcileInterfaceImplsLocked(s.View)
	}''','''	if s.interfacesDirty || s.interfacesView != s.View {
		s.interfacesDirty = false
		s.reconcileInterfaceImplsLocked(s.View)
		s.interfacesView = s.View
	}''',1)
assert tracked!=naive
for arm,source in [('baseline',original),('naive',naive),('tracked',tracked)]:
    path=root/(arm+'-server.go');path.write_text(source)
    (root/(arm+'.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(True),source.splitlines(True),fromfile='a/dagql/server.go',tofile='b/dagql/server.go')))
    overlay={'Replace':{str(work/'dagql/server.go'):str(path)}}
    for name in ['fork_interface_state_test.go','fork_interface_state_bench_test.go']:
        overlay['Replace'][str(work/'dagql'/name)]=str(root/name)
    (root/(arm+'-overlay.json')).write_text(json.dumps(overlay,indent=2)+'\n')
