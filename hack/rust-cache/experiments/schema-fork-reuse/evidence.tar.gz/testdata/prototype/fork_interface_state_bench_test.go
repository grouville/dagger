package dagql

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/require"
)

func BenchmarkForkInterfaceState(b *testing.B) {
	for _, shape := range []struct{ objects, interfaces int }{{1, 1}, {128, 8}, {512, 16}} {
		b.Run(fmt.Sprintf("%d-%d", shape.objects, shape.interfaces), func(b *testing.B) {
			base := newDagqlServerForTest(b, &forkStateType{name: "Query"})
			for i := range shape.objects {
				forkStateClass(base, fmt.Sprintf("Item%d", i), forkStateField("name", nil))
			}
			for i := range shape.interfaces {
				base.InstallInterface(forkStateInterface(fmt.Sprintf("Named%d", i), "name"))
			}
			require.True(b, forkStateHasInterface(b, base, "Item0", "Named0"))
			b.ReportAllocs()
			for b.Loop() {
				fork, err := base.Fork(b.Context(), &forkStateType{name: "Query"})
				require.NoError(b, err)
				require.True(b, forkStateHasInterface(b, fork, "Item0", "Named0"))
			}
		})
	}
}
