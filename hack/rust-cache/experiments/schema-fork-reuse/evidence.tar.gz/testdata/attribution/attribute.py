from pathlib import Path
import collections
import json

root=Path(__file__).parent
capture=Path('/tmp/rust-cache-sipsma-review/trivial-scalar-projection/capture')
ops={};links=[]
with (capture/'wcprof-complete.ndjson').open() as stream:
    header=json.loads(next(stream));names=header['strings']
    for line in stream:
        e=json.loads(line)
        if e.get('e')=='op':ops[e['id']]=dict(e,cls=names[e.get('c',0)])
        elif e.get('e')=='link' and e.get('lk')=='nested_client':links.append(e)

def chain(op):
    result=[]
    while op in ops:
        result.append(op)
        op=ops[op].get('p',0)
    return result

queries=[e for e in ops.values() if e['cls']=='session.serveQuery']
results=[]
for target in [5660,26865,75915,119857,129835]:
    api=ops[target];ancestors=chain(target)
    candidates=[link for link in links if link.get('p') in ancestors]
    matches=[]
    for link in candidates:
        client=link.get('i',0)
        for query in queries:
            if query.get('cl')==client and query['s']>=api['s'] and query['d']<=api['d']:
                descendants=[e for e in ops.values() if e.get('p')==query['id']]
                matches.append(dict(query=query,client=names[client],children=descendants))
    if not candidates:
        # Keep temporal candidates explicit; they are not attributed by timing alone.
        temporal=sorted([e for e in queries if e['s']>=api['s'] and e['d']<=api['d']],key=lambda e:e['d']-e['s'],reverse=True)[:8]
    else:temporal=[]
    results.append(dict(api=api,ancestor_chain=[dict(id=i,cls=ops[i]['cls'],kind=ops[i]['k']) for i in ancestors],links=candidates,matches=matches,unattributed_temporal_candidates=temporal))
(root/'api-attribution.json').write_text(json.dumps(dict(header={k:v for k,v in header.items() if k!='strings'},results=results),indent=2)+'\n')
for row in results:
    print('API',row['api']['id'],round((row['api']['d']-row['api']['s'])/1e9,3),'s; hosting links',len(row['links']),'matched queries',[(r['query']['id'],round((r['query']['d']-r['query']['s'])/1e9,3)) for r in row['matches']])
    if not row['links']:print(' ancestors',row['ancestor_chain'])
