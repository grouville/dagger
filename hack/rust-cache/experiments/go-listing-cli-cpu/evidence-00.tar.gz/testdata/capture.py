from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

p=Path(__file__).parent
base=p.parent
confirmation=base/'telemetry-native-storage-confirmation'
summary=json.loads((confirmation/'paired/summary.json').read_text())
assert summary['pairs']==8 and summary['all_commands_succeeded'] and summary['same_rows']
restored=json.loads((confirmation/'paired/restored-state.json').read_text())
assert restored['flags_restored'] and restored['source'] and restored['test_source'] and all(restored['configs'].values())
protocol=base/'rust-go-test-collections/measure.py'
exec(protocol.read_text().split('fixtures = [f for f')[0])
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
cli=base/'filesync-literal-pathwalk/dagger-after'
assert hashlib.sha256(cli.read_bytes()).hexdigest()=='e7ba08d0e40f6a46ad3eb8df7397bd6827aa348f491a9cb9a726ff705e1fb122'
workspace=Path('/tmp/dagger-go-real-repository-main')
module=Path('/tmp/dagger-go-module-test-name-index')
source=workspace/'dagql/types.go';original=source.read_bytes()
configs={name:(workspace/name).read_bytes() if (workspace/name).exists() else None for name in ['dagger.toml','dagger.lock']}
routes=list(json.loads((base/'telemetry-native-storage/activation.json').read_text())['modes'])
routes=list(dict.fromkeys(routes+['gc-metadata-read-ahead','native-telemetry-storage']))
flags={route:get(route)['enabled'] for route in routes if 'enabled' in get(route)}
selected={'batch-metadata','attribute-array-decode','reusable-declarations','span-lookup-fanout','usage-sampling','builtin-receivers','config-declarations','trivial-scalar-fields','scalar-list-projection','restored-posting-removal','native-telemetry-storage','shared-restored-postings','scalar-array-restore','artifact-metadata-fields'}
read_at={route for route in flags if get(route).get('read_at')}
idle('full-listing-cli-cpu-profile')
env['_EXPERIMENTAL_DAGGER_VERSION']='v1.0.0-beta.15'
env['CPUPROFILE']=str(root/'cli-cpu.pprof')
env.pop('PPROF',None)
metadata=dict(scope='One full selected-CLI CPU capture using existing CPUPROFILE support, which also emits a runtime trace. Diagnostic only; no elapsed speedup claim. Warm engine, fresh CLI, fresh source edit, native engine writer on during capture, telemetry and ordinary GC/cleanup on. Engine profilers remain off.',
    cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),
    engine_sha256=subprocess.check_output(['docker','exec',record['Id'],'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0],
    source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip(),
    module_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=module,text=True).strip(),
    flags_before=flags,runtime_trace=True,cli_rebuilt=False)
(root/'driver.py').write_bytes(Path(__file__).read_bytes())
try:
    for route in flags:
        if route in read_at:
            assert flags[route]==(route in selected),route
        else:
            mode(route,route in selected)
    get('builtin-receivers?enabled=true&record=false',b'')
    get('config-declarations?enabled=true&record=false',b'')
    get('span-lookup-fanout?record=false',b'')
    metadata['flags_during']={route:get(route)['enabled'] for route in flags}
    (root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    source.write_bytes(original+f'\n// CLI CPU profile {time.time_ns()}\n'.encode())
    (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n')
    command=[str(cli),'check','--module','go','--check','test','--list','--all']
    timed=['/usr/bin/time','-f','{"user_seconds":%U,"system_seconds":%S,"max_rss_kib":%M}','-o',str(root/'cli-resources.json'),'--',*command]
    start=time.monotonic()
    with (root/'command.stdout').open('w') as out,(root/'command.stderr').open('w') as err:
        process=subprocess.Popen(timed,cwd=workspace,env=env,stdout=out,stderr=err,start_new_session=True)
        cancelled=False
        try:code=process.wait(timeout=300)
        except subprocess.TimeoutExpired:
            cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait()
    cli_seconds=time.monotonic()-start
    flush=get('upstream-log-queue',b'')
    seconds=time.monotonic()-start
finally:
    source.write_bytes(original)
    for name,data in configs.items():
        if data is None:(workspace/name).unlink(missing_ok=True)
        else:(workspace/name).write_bytes(data)
    for route,enabled in flags.items():
        if route not in read_at:mode(route,enabled)
listed=[line for line in (root/'command.stdout').read_text().splitlines() if line.startswith('go ')]
expected=[line for line in (base/'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
result=dict(command=command,cli_seconds=cli_seconds,seconds=seconds,exit_code=code,cancelled=cancelled,
    rows=len(listed),same_rows=listed==expected,source_restored=source.read_bytes()==original,
    flags_restored=all(get(route)['enabled']==enabled for route,enabled in flags.items()),
    cli_resources=json.loads((root/'cli-resources.json').read_text().splitlines()[-1]),
    cpu_profile_bytes=(root/'cli-cpu.pprof').stat().st_size,runtime_trace_bytes=(root/'cli-cpu.pprof.trace').stat().st_size,
    engine_log_flush=flush)
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
assert code==0 and not cancelled and listed==expected and len(listed)==4398
assert result['source_restored'] and result['flags_restored'] and result['cpu_profile_bytes']>0
