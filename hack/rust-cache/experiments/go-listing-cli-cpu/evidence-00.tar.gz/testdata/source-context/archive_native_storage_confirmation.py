from pathlib import Path
import hashlib
import json
import shutil
import tarfile

base = Path('/tmp/rust-cache-sipsma-review')
repo = Path('/home/dagger/dagger_otra/hack/rust-cache')
report = 'NATIVE_TELEMETRY_STORAGE.md'
studies = {
    'telemetry-native-storage-confirmation': 'Reversed-order confirmation of complete Go listings',
    'go-listing-cli-cpu': 'CPU profile of the unchanged selected CLI',
}
allowed = {'.go', '.py', '.json', '.jsonl', '.log', '.pprof', '.gz', '.txt',
           '.stdout', '.stderr', '.md', '.mod', '.sum', '.dang', '.patch', '.peg',
           '.ndjson', '.sh', '.toml'}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


study=base/'telemetry-native-storage-confirmation'
summary=json.loads((study/'paired/summary.json').read_text())
assert summary['pairs']==8 and summary['all_commands_succeeded'] and summary['same_rows'] and summary['faster_successful_pairs']==8
combined=json.loads((study/'combined-assessment.json').read_text())
assert combined['total_pairs']==16 and combined['faster_pairs']==14 and combined['lower_allocation_pairs']==16 and combined['lower_engine_cpu_pairs']==16
assert json.loads((study/'retained-after.json').read_text())['exit_code']==0
state=json.loads((study/'final-state.json').read_text())
assert not state['native-telemetry-storage']['enabled'] and not state['wcprof/enabled']['global_enabled']
assert not state['client-lifecycle'].get('sessions') and state['client-lifecycle']['active_requests']==0
assert json.loads((study/'decision.json').read_text())['performance_confirmed']
capture=json.loads((base/'go-listing-cli-cpu/capture/result.json').read_text())
assert capture['exit_code']==0 and capture['rows']==4398 and capture['same_rows'] and capture['source_restored'] and capture['flags_restored']
assert capture['cpu_profile_bytes']>0 and capture['runtime_trace_bytes']>0

for name, title in studies.items():
    source = base / name
    report = 'NATIVE_GO_LISTING_CLI_CPU.md' if name=='go-listing-cli-cpu' else 'NATIVE_TELEMETRY_STORAGE.md'
    out = repo / 'experiments' / name
    assert not out.exists(), out
    context = source / 'source-context'
    context.mkdir(exist_ok=True)
    mappings = []
    for overlay in sorted(source.glob('*overlay*.json')):
        document = json.loads(overlay.read_text())
        if not isinstance(document, dict) or not isinstance(document.get('Replace'), dict):
            continue
        for destination, original in sorted(document['Replace'].items()):
            original = Path(original)
            sha = digest(original)
            target = context / (sha[:16] + '-' + original.name)
            if target.exists():
                assert digest(target) == sha
            else:
                shutil.copyfile(original, target)
            mappings.append(dict(overlay=str(overlay), destination=destination,
                source=str(original), archived_source=str(target.relative_to(source)), sha256=sha))
    (context / 'OVERLAYS.json').write_text(json.dumps(mappings, indent=2)+'\n')
    copies = {
        'engine.go.mod': base / 'otel-evicted-queue/engine.go.mod',
        'engine.go.sum': base / 'otel-evicted-queue/engine.go.sum',
        'listing-protocol.py': base / 'rust-go-test-collections/measure.py',
        'local_cli_collector.py': base / 'local_cli_collector.py',
        'verify_retained_first.py': base / 'trivial-scalar-projection/verify_retained_first.py',
        'restart_owned_engine_clean.py': base / 'restart_owned_engine_clean.py',
        'archive_native_storage_confirmation.py': Path(__file__),
        'selected-go.dang': Path('/tmp/dagger-go-module-test-name-index/go.dang'),
        'selected-gomod-main.dang': Path('/tmp/dagger-go-module-test-name-index/gomod/main.dang'),
        'go-module-dagger.toml': Path('/tmp/dagger-go-module-test-name-index/dagger.toml'),
        'expected-listing.stdout': base / 'glob-literal-prefix/full-command-paired/0-before.stdout',
    }
    for target, original in copies.items():
        shutil.copyfile(original, context / target)
    runtime = base / 'dang-module-blueprint-content-key'
    for original in [runtime/'go.mod', runtime/'go.sum', *sorted((runtime/'pkg').rglob('*'))]:
        if original.is_file() and original.suffix in {'.go', '.dang', '.peg', '.mod', '.sum'}:
            target = context / 'dang-runtime' / original.relative_to(runtime)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
    if name == 'telemetry-native-storage-confirmation':
        for history in sorted(base.glob('native-discovery-retained-' + name + '*')):
            assert len(list(history.glob('*.log'))) == 6
            for original in sorted(history.rglob('*')):
                if original.is_file() and original.suffix in {'.log', '.json'}:
                    target = context / history.name / original.relative_to(history)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(original, target)
    files, omitted = [], []
    for f in sorted(source.rglob('*')):
        if not f.is_file():
            continue
        if f.name.endswith('.pprof.trace'):
            omitted.append(dict(source=str(f), sha256=digest(f), bytes=f.stat().st_size, reason='Original runtime trace preserved losslessly as .trace.gz with verified raw/compressed hashes.'))
            continue
        if f.suffix not in allowed or f.name.startswith('dagger-engine'):
            continue
        if f.name == 'wcprof-complete.ndjson':
            omitted.append(dict(source=str(f), sha256=digest(f), bytes=f.stat().st_size,
                reason='Reconstructable from archived compressed recorder chunks and capture driver.'))
            continue
        files.append(dict(path='testdata/' + str(f.relative_to(source)), source=str(f),
                          bytes=f.stat().st_size, sha256=digest(f)))
    groups, group, size = [], [], 0
    for row in files:
        assert row['bytes'] < 95*1024*1024, row['path']
        if group and size + row['bytes'] > 80*1024*1024:
            groups.append(group)
            group, size = [], 0
        group.append(row)
        size += row['bytes']
    if group:
        groups.append(group)
    out.mkdir()
    archives = []
    for index, group in enumerate(groups):
        archive = out / f'evidence-{index:02d}.tar.gz'
        with tarfile.open(archive, 'w:gz', compresslevel=6) as tf:
            for row in group:
                tf.add(row['source'], arcname=row['path'], recursive=False)
        with tarfile.open(archive, 'r:gz') as tf:
            assert len(tf.getmembers()) == len(group)
            for row in group:
                member = tf.extractfile(row['path'])
                h, size = hashlib.sha256(), 0
                for chunk in iter(lambda: member.read(1024*1024), b''):
                    size += len(chunk)
                    h.update(chunk)
                assert size == row['bytes'] and h.hexdigest() == row['sha256'], row['path']
        assert archive.stat().st_size < 100*1024*1024
        archives.append(dict(path=archive.name, bytes=archive.stat().st_size,
                             sha256=digest(archive), members=len(group)))
        for row in group:
            row['archive'] = archive.name
    (out / 'MANIFEST.json').write_text(json.dumps(dict(
        archives=archives, files=files, omitted_reconstructable=omitted,
        all_attempts_retained=True, new_pr_opened=False, new_upstream_proposal=False,
        optimization_selected=False,
        engine_base='19eda924854e7f22582f3a7430272aa729cbeb5f',
        source_base='ff0b029a4d270a651b9a8c7286babc79089066e4'), indent=2)+'\n')
    (out / 'README.md').write_text('# '+title+'\n\nSee [the assessment](../../'+report+'). These archives retain exact sources and overlays, drivers, diagnostics, every test outcome and any component observations. The reversed-order confirmation improves 8/8 pairs and keeps every observation. The unchanged-CLI CPU capture is separate from timing and makes no new latency claim. Native writing stays disabled pending standalone extraction and migration review. The engine retains dual-format readers and outer-store v2 support. No PR is opened.\n\n`MANIFEST.json` records the size and SHA-256 of each independently verified archive member. Engine binaries are omitted and identified by build hash. Expanded recorder data is reconstructable from the compressed chunks.\n')
    print(json.dumps(dict(study=name, files=len(files), archives=len(archives),
                          bytes=sum(row['bytes'] for row in archives), verified=True)), flush=True)
