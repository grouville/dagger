package dang

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestCustomTransport(t *testing.T) {
	// Create a test server that records headers
	var receivedHeaders http.Header
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		receivedHeaders = r.Header
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("{}"))
	}))
	defer server.Close()

	// Create transport with custom headers
	transport := &customTransport{
		base:          http.DefaultTransport,
		authorization: "Bearer test-token",
		headers: map[string]string{
			"X-API-Key":       "secret-key",
			"X-Custom-Header": "custom-value",
		},
	}

	// Create client with custom transport
	client := &http.Client{Transport: transport}

	// Make request
	req, err := http.NewRequest("GET", server.URL, nil)
	require.NoError(t, err)

	resp, err := client.Do(req)
	require.NoError(t, err)
	defer resp.Body.Close() //nolint:errcheck

	// Verify headers were set
	assert.Equal(t, "Bearer test-token", receivedHeaders.Get("Authorization"))
	assert.Equal(t, "secret-key", receivedHeaders.Get("X-API-Key"))
	assert.Equal(t, "custom-value", receivedHeaders.Get("X-Custom-Header"))
}

func TestSchemaCaching(t *testing.T) {
	// Use a temporary cache directory for testing
	tempDir := t.TempDir()
	originalCacheHome := os.Getenv("XDG_CACHE_HOME")
	_ = os.Setenv("XDG_CACHE_HOME", tempDir)
	defer func() { _ = os.Setenv("XDG_CACHE_HOME", originalCacheHome) }()

	// Track introspection calls
	introspectionCalls := 0

	// Create a mock GraphQL server
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		introspectionCalls++
		// Simple mock introspection response
		mockResponse := `{
			"data": {
				"__schema": {
					"queryType": {"name": "Query"},
					"mutationType": null,
					"subscriptionType": null,
					"types": [
						{
							"kind": "OBJECT",
							"name": "Query",
							"fields": [
								{
									"name": "hello",
									"type": {"kind": "SCALAR", "name": "String"},
									"args": []
								}
							],
							"description": null,
							"interfaces": [],
							"enumValues": null,
							"possibleTypes": null
						}
					],
					"directives": []
				}
			}
		}`
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(mockResponse))
	}))
	defer server.Close()

	ctx := context.Background()

	client, err := makeClient(server.URL, "", nil)
	require.NoError(t, err)

	t.Run("first call should introspect and cache", func(t *testing.T) {
		// Cache miss: introspect and persist.
		_, err := loadCachedSchema(server.URL)
		require.Error(t, err, "schema should not be cached yet")

		schema, err := introspectSchema(ctx, client, false)
		require.NoError(t, err)
		require.NotNil(t, schema)
		require.NoError(t, saveCachedSchema(server.URL, schema))
		assert.Equal(t, 1, introspectionCalls, "should have made 1 introspection call")

		// Verify cache file was created
		cacheFile := filepath.Join(tempDir, "dang", "schemas", getCacheKey(server.URL)+".json")
		_, err = os.Stat(cacheFile)
		assert.NoError(t, err, "cache file should exist")
	})

	t.Run("second call should use cache", func(t *testing.T) {
		schema, err := loadCachedSchema(server.URL)

		require.NoError(t, err)
		require.NotNil(t, schema)
		assert.Equal(t, 1, introspectionCalls, "should still have made only 1 introspection call")
	})
}

func TestClearSchemaCache(t *testing.T) {
	// Use a temporary cache directory for testing
	tempDir := t.TempDir()
	originalCacheHome := os.Getenv("XDG_CACHE_HOME")
	_ = os.Setenv("XDG_CACHE_HOME", tempDir)
	defer func() { _ = os.Setenv("XDG_CACHE_HOME", originalCacheHome) }()

	// Create some dummy cache files
	cacheDir := filepath.Join(tempDir, "dang", "schemas")
	err := os.MkdirAll(cacheDir, 0755)
	require.NoError(t, err)

	// Create test cache files
	testFiles := []string{
		getCacheKey("https://api.example.com/graphql") + ".json",
		getCacheKey("https://api.test.com/graphql") + ".json",
		"not-a-cache-file.txt", // Should be ignored
	}

	for _, filename := range testFiles {
		filePath := filepath.Join(cacheDir, filename)
		err := os.WriteFile(filePath, []byte("test content"), 0644)
		require.NoError(t, err)
	}

	// Verify files exist before clearing
	for _, filename := range testFiles {
		filePath := filepath.Join(cacheDir, filename)
		_, err := os.Stat(filePath)
		assert.NoError(t, err, "file should exist before clearing: %s", filename)
	}

	// Clear the cache
	err = ClearSchemaCache()
	assert.NoError(t, err)

	// Verify JSON cache files are removed but other files remain
	jsonFiles := testFiles[:2] // First two are JSON files
	for _, filename := range jsonFiles {
		filePath := filepath.Join(cacheDir, filename)
		_, err := os.Stat(filePath)
		assert.True(t, os.IsNotExist(err), "JSON cache file should be removed: %s", filename)
	}

	// Non-JSON file should still exist
	nonJsonFile := filepath.Join(cacheDir, testFiles[2])
	_, err = os.Stat(nonJsonFile)
	assert.NoError(t, err, "non-JSON file should remain")

	// Test clearing empty cache directory
	err = ClearSchemaCache()
	assert.NoError(t, err, "clearing empty cache should not error")

	// Test clearing non-existent cache directory
	_ = os.RemoveAll(cacheDir)
	err = ClearSchemaCache()
	assert.NoError(t, err, "clearing non-existent cache should not error")
}
