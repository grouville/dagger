package dang

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/Khan/genqlient/graphql"
	"github.com/vektah/gqlparser/v2/ast"
	"github.com/vektah/gqlparser/v2/gqlerror"
	"github.com/vito/dang/v2/pkg/hm"
	"github.com/vito/dang/v2/pkg/introspection"
	"github.com/vito/dang/v2/pkg/querybuilder"
)

// Grouped represents a parenthesized expression - used to preserve explicit grouping
type Grouped struct {
	InferredTypeHolder
	Expr Node
	Loc  *SourceLocation
}

var _ Node = (*Grouped)(nil)
var _ Evaluator = (*Grouped)(nil)

func (g *Grouped) DeclaredSymbols() []string {
	return g.Expr.DeclaredSymbols()
}

func (g *Grouped) ReferencedSymbols() []string {
	return g.Expr.ReferencedSymbols()
}

func (g *Grouped) Body() hm.Expression { return g.Expr }

func (g *Grouped) GetSourceLocation() *SourceLocation { return g.Loc }

func (g *Grouped) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	t, err := g.Expr.Infer(ctx, env, fresh)
	if err != nil {
		return nil, err
	}
	g.SetInferredType(t)
	return t, nil
}

func (g *Grouped) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return EvalNode(ctx, scope, g.Expr)
}

func (g *Grouped) Walk(fn func(Node) bool) {
	if fn(g) {
		g.Expr.Walk(fn)
	}
}

// FunCall represents a function call expression
type FunCall struct {
	InferredTypeHolder
	Fun      Node
	Args     Record
	BlockArg *BlockArg // Optional block argument for bidirectional inference
	Loc      *SourceLocation
}

var _ Node = (*FunCall)(nil)
var _ Evaluator = (*FunCall)(nil)

func (c *FunCall) DeclaredSymbols() []string {
	return nil // Function calls don't declare anything
}

func (c *FunCall) ReferencedSymbols() []string {
	var symbols []string

	// Add symbols from the function being called
	symbols = append(symbols, c.Fun.ReferencedSymbols()...)

	// Add symbols from arguments
	for _, arg := range c.Args {
		symbols = append(symbols, arg.Value.ReferencedSymbols()...)
	}

	// Add symbols from block arg if present
	if c.BlockArg != nil {
		symbols = append(symbols, c.BlockArg.ReferencedSymbols()...)
	}

	return symbols
}

func (c *FunCall) Body() hm.Expression { return c.Fun }

func (c *FunCall) GetSourceLocation() *SourceLocation { return c.Loc }

func (c *FunCall) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(c, func() (hm.Type, error) {
		fun, err := c.Fun.Infer(ctx, env, fresh)
		if err != nil {
			return nil, err
		}

		switch ft := fun.(type) {
		case *hm.FunctionType:
			t, err := c.inferFunctionType(ctx, env, fresh, ft)
			if err != nil {
				return nil, err
			}

			// If the function came from a nullable receiver (e.g. t.foo()
			// where t is nullable), taint the return type as nullable too.
			if sel, ok := c.Fun.(*Select); ok && sel.NullableReceiver {
				if nnType, ok := t.(hm.NonNullType); ok {
					t = nnType.Type
				}
			}

			c.SetInferredType(t)
			return t, nil
		default:
			return nil, fmt.Errorf("FunCall.Infer: expected function, got %s (%T)", fun, fun)
		}
	})
}

// inferFunctionType handles type inference for FunctionType calls
func (c *FunCall) inferFunctionType(ctx context.Context, env hm.Env, fresh hm.Fresher, ft *hm.FunctionType) (hm.Type, error) {
	// Handle positional argument mapping for type inference
	argMapping, err := c.mapArgumentsForInference(ft)
	if err != nil {
		return nil, err
	}

	// Resolve positional argument keys so downstream consumers (e.g. GraphQL
	// query building in ObjectSelection) can read them off arg.Key directly.
	for i := range c.Args {
		if c.Args[i].Positional && c.Args[i].Key == "" {
			if mapped, ok := argMapping[i]; ok {
				c.Args[i].Key = mapped
			}
		}
	}

	// Type check each argument first, collecting substitutions from unifying
	// actual argument types with expected parameter types. We merge the
	// substitutions without applying them eagerly so repeated type variables are
	// inferred from all arguments order-independently (e.g. (Int!, null) for
	// (a, a) becomes Int). The final substitutions are then available before we
	// infer a block arg, which may depend on those type variables.
	var argSubs hm.Subs
	argRecord, ok := ft.Arg().(*RecordType)
	if !ok {
		return nil, fmt.Errorf("FunCall.Infer: expected record type for arguments, got %T", ft.Arg())
	}
	for i, arg := range c.Args {
		k := c.getArgumentKey(arg, argMapping, i)
		coerced, subs, err := c.checkArgumentTypeWithSubs(ctx, env, fresh, arg.Value, argRecord, k)
		if err != nil {
			return nil, fmt.Errorf("argument %q: %w", k, err)
		}
		c.Args[i].Value = coerced
		if subs != nil {
			if argSubs == nil {
				argSubs = subs
			} else {
				argSubs, err = argSubs.Compose(subs)
				if err != nil {
					return nil, NewInferError(err, arg.Value)
				}
			}
		}
	}

	// Apply argument substitutions to the function type before inferring the
	// block arg, so that type variables resolved from arguments (like 'b' from
	// reduce's initial arg) are concrete in the block's expected param types.
	if argSubs != nil {
		ft = ft.Apply(argSubs).(*hm.FunctionType)
	}

	// Handle block arg if present (needs special bidirectional inference).
	// The block body sees this call as its break target.
	var blockArgSubs hm.Subs
	var blockBreakTarget *InferControlTarget
	if c.BlockArg != nil {
		blockBreakTarget = NewInferControlTarget(BlockCallFrame)
		blockCtx := contextWithInferBreakTarget(ctx, blockBreakTarget)
		subs, err := c.inferBlockArg(blockCtx, env, fresh, ft)
		if err != nil {
			return nil, fmt.Errorf("block argument: %w", err)
		}
		blockArgSubs = subs
	}

	// Check that all required arguments are provided
	err = c.validateRequiredArgumentsInInfer(ft)
	if err != nil {
		return nil, err
	}

	// Check that a block arg is provided if the function requires one
	if ft.Block() != nil && c.BlockArg == nil {
		return nil, NewInferError(fmt.Errorf("function requires a block argument"), c)
	}

	// Apply block arg substitutions to the return type
	retType := ft.Ret(false)
	if blockArgSubs != nil {
		retType = retType.Apply(blockArgSubs).(hm.Type)
	}
	if blockBreakTarget != nil {
		retType = mergeCallBreakTypes(retType, c.BlockArg.BodyNode, blockBreakTarget, blockArgSubs, fresh)
	}
	return retType, nil
}

// inferBlockArg performs bidirectional type inference for block arguments.
// Returns the substitutions produced by unifying the block arg's inferred type
// with the expected function type.
func (c *FunCall) inferBlockArg(ctx context.Context, env hm.Env, fresh hm.Fresher, ft *hm.FunctionType) (hm.Subs, error) {
	// Get the expected block type from the function type
	// The block type is now stored directly on the FunctionType
	expectedFnType := ft.Block()

	// If there's no block type, the function doesn't accept a block argument
	if expectedFnType == nil {
		return nil, fmt.Errorf("function does not accept a block argument")
	}

	// Extract expected parameter types from the function type
	expectedArgRecord, ok := expectedFnType.Arg().(*RecordType)
	if !ok {
		return nil, fmt.Errorf("expected record type for block arg parameters, got %T", expectedFnType.Arg())
	}

	// Set expected parameter types on the block arg
	c.BlockArg.ExpectedParamTypes = make([]hm.Type, len(expectedArgRecord.Fields))
	for i := range expectedArgRecord.Fields {
		expectedField := expectedArgRecord.Fields[i]
		expectedType, _ := expectedField.Value.Type()
		c.BlockArg.ExpectedParamTypes[i] = expectedType
	}

	// Set expected return type on the block arg
	c.BlockArg.ExpectedReturnType = expectedFnType.Ret(false)

	// Now infer the block arg with these constraints
	inferredType, err := c.BlockArg.Infer(ctx, env, fresh)
	if err != nil {
		return nil, err
	}

	// Verify the inferred type matches the expected function type
	// and capture the substitutions produced by unification
	subs, err := hm.Assignable(inferredType, expectedFnType)
	if err != nil {
		return nil, NewInferError(
			fmt.Errorf("block argument has type %s but expected %s", inferredType, expectedFnType),
			c.BlockArg,
		)
	}

	return subs, nil
}

// getArgumentKey determines the argument key for positional or named arguments
func (c *FunCall) getArgumentKey(arg Keyed[Node], argMapping map[int]string, index int) string {
	if arg.Positional {
		return argMapping[index]
	}
	return arg.Key
}

// checkArgumentTypeWithSubs validates an argument's type against the expected
// parameter type and returns the (possibly Coerce-wrapped) argument node along
// with any substitutions produced by unification. The substitutions are used to
// resolve type variables from argument types before inferring block args.
func (c *FunCall) checkArgumentTypeWithSubs(ctx context.Context, env hm.Env, fresh hm.Fresher, value Node, recordType *RecordType, key string) (Node, hm.Subs, error) {
	scheme, has := recordType.SchemeOf(key)
	if !has {
		return value, nil, fmt.Errorf("FunCall.Infer: %q not found in %s", key, recordType)
	}

	dt, isMono := scheme.Type()
	if !isMono {
		return value, nil, fmt.Errorf("FunCall.Infer: %q is not monomorphic", key)
	}

	// Infer the argument type
	it, err := value.Infer(ctx, env, fresh)
	if err != nil {
		return value, nil, fmt.Errorf("FunCall.Infer: %w", err)
	}

	subs, err := assignableForValue(it, dt, value)
	if err != nil {
		return value, nil, NewInferError(err, value)
	}
	return wrapCoerce(value, dt, key), subs, nil
}

var _ hm.Apply = (*FunCall)(nil)

func (c *FunCall) Fn() hm.Expression { return c.Fun }

func (c *FunCall) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, c, func() (Value, error) {
		funVal, err := EvalNode(ctx, scope, c.Fun)
		if err != nil {
			// Don't wrap errors - let the specific node error bubble up
			return nil, err
		}

		if funVal == (NullValue{}) {
			// If the function came from a nullable receiver, short-circuit to null
			if sel, ok := c.Fun.(*Select); ok && sel.NullableReceiver {
				return NullValue{}, nil
			}
			return nil, NewSourceError(fmt.Errorf("cannot call null"), c.Fun.GetSourceLocation(), "")
		}

		// Warn at the call site if the callee is a deprecated builtin.
		if fn, ok := funVal.(BuiltinFunction); ok && fn.Deprecated != "" {
			WarnAtSource(ctx, c.Loc, fmt.Sprintf("%s is deprecated: %s", fn.Name, fn.Deprecated))
		}

		// Evaluate arguments and handle positional/named argument mapping
		argValues, err := c.evaluateArguments(ctx, scope, funVal)
		if err != nil {
			return nil, err
		}

		var blockCallFrame *ControlFrame
		// Evaluate block arg if present and add to context. The frame is captured
		// by the block so a break can exit this whole call expression.
		if c.BlockArg != nil {
			blockCallFrame = NewControlFrame(BlockCallFrame)
			defer blockCallFrame.Deactivate()

			blockCtx := contextWithBlockCallFrame(ctx, blockCallFrame)
			blockVal, err := c.BlockArg.Eval(blockCtx, scope)
			if err != nil {
				return nil, err
			}
			// Store block in context for builtin functions to access
			ctx = context.WithValue(blockCtx, blockArgContextKey, blockVal)
		}

		// Dispatch to appropriate function call handler
		val, err := c.callFunction(ctx, scope, funVal, argValues)
		if err != nil && blockCallFrame != nil {
			var breakEx *BreakException
			if errors.As(err, &breakEx) && controlFrameMatches(breakEx.Target, blockCallFrame) {
				if breakEx.HasValue && breakEx.Value != nil {
					return breakEx.Value, nil
				}
				return NullValue{}, nil
			}
		}
		return val, err
	})
}

// callFunction dispatches function calls to appropriate handlers
func (c *FunCall) callFunction(ctx context.Context, scope ValueScope, funVal Value, argValues map[string]Value) (Value, error) {
	callable, ok := funVal.(Callable)
	if !ok {
		return nil, fmt.Errorf("FunCall.Eval: %T is not callable", funVal)
	}
	return callable.Call(ctx, scope, argValues)
}

// evaluateArguments handles both positional and named arguments
func (c *FunCall) evaluateArguments(ctx context.Context, scope ValueScope, funVal Value) (map[string]Value, error) {
	// Validate argument order first
	if err := c.validateArgumentOrder(); err != nil {
		return nil, err
	}

	argValues := make(map[string]Value)
	positionallySet := make(map[string]bool)
	paramNames := c.getParameterNames(funVal)

	// Process all arguments. Each arg.Value is wrapped in a Coerce by
	// FunCall.checkArgumentTypeWithSubs when types are known, so
	// materialization happens during EvalNode.
	positionalIndex := 0
	for _, arg := range c.Args {
		val, err := EvalNode(ctx, scope, arg.Value)
		if err != nil {
			return nil, err
		}

		if arg.Positional {
			err := c.handlePositionalArgument(arg, val, argValues, positionallySet, paramNames, &positionalIndex)
			if err != nil {
				return nil, err
			}
		} else {
			err := c.handleNamedArgument(arg, val, argValues, positionallySet)
			if err != nil {
				return nil, err
			}
		}
	}

	// Don't add block arg to argValues - it will be handled specially
	// via context and the Args.Block field

	return argValues, nil
}

// validateArgumentOrder ensures positional args come before named args
func (c *FunCall) validateArgumentOrder() error {
	seenNamed := false
	for _, arg := range c.Args {
		if arg.Positional && seenNamed {
			return fmt.Errorf("positional arguments must come before named arguments")
		}
		if !arg.Positional {
			seenNamed = true
		}
	}
	return nil
}

// handlePositionalArgument processes a positional argument
func (c *FunCall) handlePositionalArgument(arg Keyed[Node], val Value, argValues map[string]Value,
	positionallySet map[string]bool, paramNames []string, positionalIndex *int) error {
	if *positionalIndex >= len(paramNames) {
		return fmt.Errorf("too many positional arguments: got %d, expected at most %d",
			*positionalIndex+1, len(paramNames))
	}
	paramName := paramNames[*positionalIndex]
	if _, exists := argValues[paramName]; exists {
		return fmt.Errorf("argument %q specified both positionally and by name", paramName)
	}
	argValues[paramName] = val
	positionallySet[paramName] = true
	*positionalIndex++
	return nil
}

// handleNamedArgument processes a named argument
func (c *FunCall) handleNamedArgument(arg Keyed[Node], val Value, argValues map[string]Value,
	positionallySet map[string]bool) error {
	if _, exists := argValues[arg.Key]; exists {
		if positionallySet[arg.Key] {
			return fmt.Errorf("argument %q specified both positionally and by name", arg.Key)
		} else {
			return fmt.Errorf("argument %q specified multiple times", arg.Key)
		}
	}
	argValues[arg.Key] = val
	return nil
}

// getParameterNames extracts parameter names from a function value
func (c *FunCall) getParameterNames(funVal Value) []string {
	if callable, ok := funVal.(Callable); ok {
		return callable.ParameterNames()
	}
	return nil
}

// mapArgumentsForInference maps positional arguments to parameter names during type inference
func (c *FunCall) mapArgumentsForInference(ft *hm.FunctionType) (map[int]string, error) {
	argMapping := make(map[int]string)

	// Get parameter names from the function type
	paramNames := []string{}
	if rt, ok := ft.Arg().(*RecordType); ok {
		paramNames = make([]string, len(rt.Fields))
		for i, field := range rt.Fields {
			paramNames[i] = field.Key
		}
	}

	// Validate positional args come before named args
	seenNamed := false
	for _, arg := range c.Args {
		if arg.Positional && seenNamed {
			return nil, fmt.Errorf("positional arguments must come before named arguments")
		}
		if !arg.Positional {
			seenNamed = true
		}
	}

	// Map positional arguments to parameter names by index
	positionalIndex := 0
	for i, arg := range c.Args {
		if arg.Positional {
			if positionalIndex >= len(paramNames) {
				return nil, fmt.Errorf("too many positional arguments: got %d, expected at most %d",
					positionalIndex+1, len(paramNames))
			}
			argMapping[i] = paramNames[positionalIndex]
			positionalIndex++
		}
	}

	return argMapping, nil
}

// validateRequiredArgumentsInInfer checks that all required arguments are provided during type inference
func (c *FunCall) validateRequiredArgumentsInInfer(ft *hm.FunctionType) error {
	// Get the record type that represents the function arguments
	rt, ok := ft.Arg().(*RecordType)
	if !ok {
		return nil // Not a record type, no validation needed
	}

	// Build a set of provided argument names for quick lookup
	providedArgs := make(map[string]bool)
	argMapping, err := c.mapArgumentsForInference(ft)
	if err != nil {
		return err
	}

	for i, arg := range c.Args {
		var key string
		if arg.Positional {
			key = argMapping[i]
		} else {
			key = arg.Key
		}
		providedArgs[key] = true
	}

	// Check each parameter in the function signature
	for _, field := range rt.Fields {
		paramName := field.Key
		scheme := field.Value

		// Skip if this argument was provided
		if providedArgs[paramName] {
			continue
		}

		// Get the type of this parameter
		paramType, isMono := scheme.Type()
		if !isMono {
			continue // Skip polymorphic parameters for now
		}

		// Check if this parameter is required (hm.NonNullType)
		// With our transformation, arguments with defaults are now nullable in the signature,
		// so only truly required arguments (without defaults) will be NonNull here
		if _, isNonNull := paramType.(hm.NonNullType); isNonNull {
			return NewInferError(fmt.Errorf("missing required argument: %q", paramName), c)
		}
	}

	return nil
}

func (c *FunCall) Walk(fn func(Node) bool) {
	if !fn(c) {
		return
	}
	c.Fun.Walk(fn)
	for _, arg := range c.Args {
		arg.Value.Walk(fn)
	}
	// Walk block arg if present
	if c.BlockArg != nil {
		c.BlockArg.Walk(fn)
	}
}

// Symbol represents a symbol/variable reference
type Symbol struct {
	InferredTypeHolder
	Name     string
	AutoCall bool
	Loc      *SourceLocation
}

var _ Node = (*Symbol)(nil)
var _ Evaluator = (*Symbol)(nil)

func (s *Symbol) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(s, func() (hm.Type, error) {
		// Check for import conflicts before resolving
		if typeScope, ok := env.(TypeScope); ok {
			if conflicts := typeScope.CheckValueConflict(s.Name); len(conflicts) > 0 {
				return nil, fmt.Errorf("ambiguous reference to %q: provided by imports %v", s.Name, conflicts)
			}
			if conflicts := typeScope.CheckTypeConflict(s.Name); len(conflicts) > 0 {
				return nil, fmt.Errorf("ambiguous reference to %q: provided by imports %v", s.Name, conflicts)
			}
		}

		scheme, found := env.SchemeOf(s.Name)
		if !found {
			return nil, fmt.Errorf("%q not found", s.Name)
		}
		t, _ := scheme.Type()
		if s.AutoCall {
			var err error
			t, _, err = autoCallFnType(t)
			if err != nil {
				return nil, err
			}
		}
		s.SetInferredType(t)
		return t, nil
	})
}

func (s *Symbol) Body() hm.Expression { return s }

func (s *Symbol) GetSourceLocation() *SourceLocation { return s.Loc }

func (s *Symbol) DeclaredSymbols() []string {
	return nil // Symbols don't declare anything
}

func (s *Symbol) ReferencedSymbols() []string {
	return []string{s.Name} // Symbols reference themselves
}

func (s *Symbol) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, s, func() (Value, error) {
		// Check for import conflicts before resolving
		if modVal, ok := scope.(*Object); ok {
			if conflicts := modVal.Mod.CheckValueConflict(s.Name); len(conflicts) > 0 {
				return nil, fmt.Errorf("ambiguous reference to %q: provided by imports %v", s.Name, conflicts)
			}
		}

		val, found, err := scope.Lookup(ctx, s.Name)
		if err != nil {
			return nil, err
		}
		if !found {
			return nil, fmt.Errorf("Symbol.Eval: %q not found in env: %+v", s.Name, scope)
		}

		if val == nil {
			return nil, fmt.Errorf("Symbol: found nil value for %q", s.Name)
		}

		// Auto-call zero-arity functions when accessed as symbols
		if s.AutoCall && isAutoCallableFn(val) {
			return autoCallFn(ctx, scope, val)
		}

		return val, nil
	})
}

func (s *Symbol) Walk(fn func(Node) bool) {
	fn(s)
}

// Select represents field selection or method call
type Select struct {
	InferredTypeHolder
	Receiver         Node
	Field            *Symbol
	AutoCall         bool
	NullableReceiver bool // set during Infer when receiver is nullable
	// staticOwner is set during Infer when this selection resolved to a static
	// member of a type named directly by the receiver (e.g. Regexp.escape). It
	// tells Eval to read the member from the type's statics namespace rather
	// than evaluating the receiver (which would auto-construct an instance).
	staticOwner *Type
	Loc         *SourceLocation
}

var _ Node = (*Select)(nil)
var _ Evaluator = (*Select)(nil)

// staticMemberAccessible reports whether a static member of owner is reachable
// as `Type.member` from the code currently being inferred. Public statics are
// always reachable; a private (`let`) static only from within its declaring
// module. When the module identity is unknown on either side it stays
// unreachable — the pre-visibility behavior — so a private static never leaks
// to an un-instrumented caller (statics fail closed, the reverse of instance
// members, because each preserves its own backward-compatible default).
func staticMemberAccessible(ctx context.Context, owner *Type, name string) bool {
	if owner.StaticVisibility(name) == PublicVisibility {
		return true
	}
	home := owner.HomeModule()
	cur := moduleScopeFromContext(ctx)
	return home != nil && cur != nil && home == cur
}

func (d *Select) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(d, func() (hm.Type, error) {
		// Handle nil receiver (symbol calls) - look up type in environment
		if d.Receiver == nil {
			scheme, found := env.SchemeOf(d.Field.Name)
			if !found {
				return nil, fmt.Errorf("%q not found in env", d.Field.Name)
			}
			t, _ := scheme.Type()
			d.SetInferredType(t)
			return t, nil
		}

		// Static member resolution. When the receiver names a type directly
		// (e.g. `Regexp.escape`) and that type declares the field as a static
		// member (in a self { } block), resolve it against the type's meta-type
		// instead of inferring the receiver as a value. This is deliberately
		// static-first: only a *declared* static short-circuits here, so a bare
		// type name whose field is not a static falls through unchanged — most
		// importantly, `AllDefaults.field` still auto-constructs and reads an
		// instance field, exactly as before this feature existed.
		if sym, ok := d.Receiver.(*Symbol); ok {
			if ts, ok := env.(TypeScope); ok {
				if named, found := ts.NamedType(sym.Name); found {
					if owner, ok := named.(*Type); ok {
						// A public static is reachable as `Type.member`
						// anywhere; a private (let) static only from within its
						// declaring module (module-level visibility, matching
						// let instance members). Outside that, resolution falls
						// through to normal receiver inference.
						if scheme, isStatic := owner.StaticScheme(d.Field.Name); isStatic && staticMemberAccessible(ctx, owner, d.Field.Name) {
							t, mono := scheme.Type()
							if !mono {
								return nil, fmt.Errorf("Select.Infer: static %q of %s is not monomorphic", d.Field.Name, owner.Named)
							}
							if d.AutoCall {
								var err error
								t, _, err = autoCallFnType(t)
								if err != nil {
									return nil, err
								}
							}
							d.staticOwner = owner
							d.SetInferredType(t)
							return t, nil
						}
					}
				}
			}
		}

		// Handle normal receiver
		lt, err := d.Receiver.Infer(ctx, env, fresh)
		if err != nil {
			return nil, err
		}

		// Check if receiver is a list type - handle methods on lists specially.
		// Supports both non-null lists ([T!]!) and nullable lists ([T!]).
		var listElemType hm.Type
		var nullableList bool
		if nn, ok := lt.(hm.NonNullType); ok {
			if listType, ok := nn.Type.(ListType); ok {
				listElemType = listType.Type
			}
		} else if listType, ok := lt.(ListType); ok {
			listElemType = listType.Type
			nullableList = true
		}
		if listElemType != nil {
			// Look up method definition
			def, found := LookupMethod(ListTypeModule, d.Field.Name)
			if !found {
				tv := fresh.Fresh()
				d.SetInferredType(tv)
				return tv, fmt.Errorf("list does not have method %q", d.Field.Name)
			}

			// Build method type with element type substituted for type variable
			methodType := instantiateListMethod(def, listElemType)

			if d.AutoCall {
				var err error
				methodType, _, err = autoCallFnType(methodType)
				if err != nil {
					return nil, err
				}
			}

			// For nullable list receivers, mark as nullable so the call site
			// propagates null and makes the return type nullable.
			if nullableList {
				d.NullableReceiver = true
			}

			d.SetInferredType(methodType)
			return methodType, nil
		}

		// Check if receiver is a map type - handle methods on maps specially.
		// Supports both non-null maps (Map[T!]!) and nullable maps (Map[T!]).
		var mapValType hm.Type
		var nullableMap bool
		if nn, ok := lt.(hm.NonNullType); ok {
			if mapType, ok := nn.Type.(MapType); ok {
				mapValType = mapType.Type
			}
		} else if mapType, ok := lt.(MapType); ok {
			mapValType = mapType.Type
			nullableMap = true
		}
		if mapValType != nil {
			def, found := LookupMethod(MapTypeModule, d.Field.Name)
			if !found {
				tv := fresh.Fresh()
				d.SetInferredType(tv)
				return tv, fmt.Errorf("map does not have method %q", d.Field.Name)
			}

			// Build method type with the value type substituted for 'a'.
			methodType := instantiateListMethod(def, mapValType)

			if d.AutoCall {
				var err error
				methodType, _, err = autoCallFnType(methodType)
				if err != nil {
					return nil, err
				}
			}

			if nullableMap {
				d.NullableReceiver = true
			}

			d.SetInferredType(methodType)
			return methodType, nil
		}

		// GraphQL object lists are not directly iterable: callers must first
		// select fields on the elements (e.g. value.{id}) to convert them
		// into a regular list. Detect this case before falling through to
		// the env path, which would surface a confusing internal error.
		var gqlListReceiver bool
		if nn, ok := lt.(hm.NonNullType); ok {
			_, gqlListReceiver = nn.Type.(GraphQLListType)
		} else {
			_, gqlListReceiver = lt.(GraphQLListType)
		}
		if gqlListReceiver {
			if _, found := LookupMethod(ListTypeModule, d.Field.Name); found {
				return nil, fmt.Errorf("cannot call list method %q directly on a GraphQL object list; select fields first, e.g. value.{id}.%s", d.Field.Name, d.Field.Name)
			}
			return nil, fmt.Errorf("cannot select %q from a GraphQL object list; select fields on its elements first, e.g. value.{id}", d.Field.Name)
		}

		// Check if receiver is nullable or non-null
		var rec TypeScope
		var isNullable bool

		if nn, ok := lt.(hm.NonNullType); ok {
			// Non-null receiver
			envType, ok := nn.Type.(TypeScope)
			if !ok {
				return nil, fmt.Errorf("Select.Infer: expected %T, got %T", envType, nn.Type)
			}
			rec = envType
			isNullable = false
		} else if envType, ok := lt.(TypeScope); ok {
			// Nullable receiver - inherit nullability
			rec = envType
			isNullable = true
			d.NullableReceiver = true
		} else {
			return nil, fmt.Errorf("Select.Infer: expected NonNullType or TypeScope, got %T", lt)
		}

		scheme, found := rec.SchemeOf(d.Field.Name)
		if !found {
			// Return a type variable to allow downstream inference to continue
			tv := fresh.Fresh()
			d.SetInferredType(tv)
			return tv, fmt.Errorf("field %q not found in %s", d.Field.Name, rec)
		}
		// Module-level visibility: a `let` member is private to the module that
		// declares its type — reachable anywhere within that module (any file,
		// sibling type, via self or a local value) but rejected from another
		// module, so user code cannot reach a prelude type's `let` helpers.
		// Enforced only when both the member's home module and the current
		// module are known and differ; nil on either side (builtins, schema
		// types, an un-instrumented entry point) falls open. Bare-name access
		// took the nil-receiver branch far above and is unaffected.
		if recType, ok := rec.(*Type); ok && recType.Visibility(d.Field.Name) == PrivateVisibility {
			if home := recType.HomeModule(); home != nil {
				if cur := moduleScopeFromContext(ctx); cur != nil && home != cur {
					return nil, fmt.Errorf("%q is a private member of %s and cannot be accessed from another module", d.Field.Name, recType.Named)
				}
			}
		}
		t, mono := scheme.Type()
		if !mono {
			return nil, fmt.Errorf("Select.Infer: type of field %q is not monomorphic", d.Field.Name)
		}
		if d.AutoCall {
			var err error
			t, _, err = autoCallFnType(t)
			if err != nil {
				return nil, err
			}
		}

		// If receiver was nullable, make result nullable too
		if isNullable {
			// Remove any existing NonNullType wrapper from the field type
			if nnType, ok := t.(hm.NonNullType); ok {
				d.SetInferredType(nnType.Type)
				return nnType.Type, nil
			}
			// Field type is already nullable, return as-is
			d.SetInferredType(t)
			return t, nil
		}

		d.SetInferredType(t)
		return t, nil
	})
}

func (d *Select) DeclaredSymbols() []string {
	return nil // Select expressions don't declare anything
}

func (d *Select) ReferencedSymbols() []string {
	var symbols []string

	// When Receiver is nil, this is a top-level function call like createPerson()
	if d.Receiver == nil {
		symbols = append(symbols, d.Field.Name)
	} else {
		symbols = append(symbols, d.Receiver.ReferencedSymbols()...)
	}

	return symbols
}

func (d *Select) Body() hm.Expression { return d }

func (d *Select) GetSourceLocation() *SourceLocation { return d.Loc }

func (d *Select) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, d, func() (Value, error) {
		// Static member: Infer resolved this to a static of a named type. Read
		// it from the type's statics namespace directly, without evaluating the
		// receiver — evaluating it would auto-construct an instance and miss the
		// static entirely.
		if d.staticOwner != nil {
			statics := d.staticOwner.Statics()
			if statics == nil {
				return nil, fmt.Errorf("static %q of %s is unavailable", d.Field.Name, d.staticOwner.Named)
			}
			val, found, err := statics.Lookup(ctx, d.Field.Name)
			if err != nil {
				return nil, err
			}
			if !found {
				return nil, fmt.Errorf("static %q not found in %s", d.Field.Name, d.staticOwner.Named)
			}
			// A static method binds the statics namespace as its receiver, so
			// `self` and bare sibling statics resolve within the block.
			if fnVal, isFn := val.(FunctionValue); isFn {
				val = BoundMethod{Method: fnVal, Receiver: statics}
			}
			// Zero-arg statics auto-call, matching the normal selection path.
			if d.AutoCall && isAutoCallableFn(val) {
				return autoCallFn(ctx, scope, val)
			}
			return val, nil
		}

		var receiverVal Value
		var err error

		// Handle normal receiver evaluation
		if d.Receiver != nil {
			receiverVal, err = EvalNode(ctx, scope, d.Receiver)
			if err != nil {
				return nil, fmt.Errorf("evaluating receiver: %w", err)
			}
		} else {
			receiverVal = scope
		}

		val, err := (func() (Value, error) {
			switch rec := receiverVal.(type) {
			case NullValue:
				// Null propagation: if receiver is null, result is null
				return NullValue{}, nil

			case ValueScope:
				if val, found, err := rec.Lookup(ctx, d.Field.Name); err != nil {
					return nil, err
				} else if found {
					// If this is a FunctionValue accessed from a module, bind it to the receiver
					if fnVal, isFunctionValue := val.(FunctionValue); isFunctionValue {
						return BoundMethod{Method: fnVal, Receiver: rec}, nil
					}
					return val, nil
				}
				// this shouldn't happen (should be caught at type checking)
				return nil, fmt.Errorf("module %q does not have a field %q", rec, d.Field.Name)

			case GraphQLValue:
				// Handle GraphQL field selection
				return rec.SelectField(ctx, d.Field.Name)

			case StringValue:
				// Handle methods on string values by looking them up in the evaluation environment
				// The builtin is registered with a special name
				methodKey := fmt.Sprintf("_string_%s_builtin", d.Field.Name)
				if method, found, err := scope.Lookup(ctx, methodKey); err != nil {
					return nil, err
				} else if found {
					if builtinFn, ok := method.(BuiltinFunction); ok {
						// Create a bound method that will pass the string as self
						return BoundBuiltinMethod{Method: builtinFn, Receiver: rec}, nil
					}
				}
				return nil, fmt.Errorf("string value does not have method %q", d.Field.Name)

			case ScalarValue:
				// Methods on custom scalar values (e.g. Path) dispatch through
				// the builtin registry, keyed by the scalar's named type, then
				// through the scalar's Dang-defined methods (scalar bodies).
				if mod, ok := rec.ScalarType.(*Type); ok {
					methodKey := GetMethodKey(mod, d.Field.Name)
					if method, found, err := scope.Lookup(ctx, methodKey); err != nil {
						return nil, err
					} else if found {
						if builtinFn, ok := method.(BuiltinFunction); ok {
							return BoundBuiltinMethod{Method: builtinFn, Receiver: rec}, nil
						}
					}
					if methods := mod.ScalarMethods(); methods != nil {
						if val, found, err := methods.Lookup(ctx, d.Field.Name); err != nil {
							return nil, err
						} else if found {
							if fnVal, ok := val.(FunctionValue); ok {
								return BoundScalarMethod{Method: fnVal, Receiver: rec}, nil
							}
						}
					}
				}
				return nil, fmt.Errorf("%s value does not have method %q", rec.ScalarType.Name(), d.Field.Name)

			case FloatValue:
				// Handle methods on float values by looking them up in the evaluation environment
				// The builtin is registered with a special name
				methodKey := fmt.Sprintf("_float_%s_builtin", d.Field.Name)
				if method, found, err := scope.Lookup(ctx, methodKey); err != nil {
					return nil, err
				} else if found {
					if builtinFn, ok := method.(BuiltinFunction); ok {
						// Create a bound method that will pass the float as self
						return BoundBuiltinMethod{Method: builtinFn, Receiver: rec}, nil
					}
				}
				return nil, fmt.Errorf("float value does not have method %q", d.Field.Name)

			case ListValue:
				// Handle methods on list values by looking them up in the evaluation environment
				// The builtin is registered with a special name
				methodKey := fmt.Sprintf("_list_%s_builtin", d.Field.Name)
				if method, found, err := scope.Lookup(ctx, methodKey); err != nil {
					return nil, err
				} else if found {
					if builtinFn, ok := method.(BuiltinFunction); ok {
						// Create a bound method that will pass the list as self
						return BoundBuiltinMethod{Method: builtinFn, Receiver: rec}, nil
					}
				}
				return nil, fmt.Errorf("list value does not have method %q", d.Field.Name)

			case MapValue:
				// Handle methods on map values by looking them up in the evaluation environment
				// The builtin is registered with a special name
				methodKey := fmt.Sprintf("_map_%s_builtin", d.Field.Name)
				if method, found, err := scope.Lookup(ctx, methodKey); err != nil {
					return nil, err
				} else if found {
					if builtinFn, ok := method.(BuiltinFunction); ok {
						// Create a bound method that will pass the map as self
						return BoundBuiltinMethod{Method: builtinFn, Receiver: rec}, nil
					}
				}
				return nil, fmt.Errorf("map value does not have method %q", d.Field.Name)

			default:
				return nil, fmt.Errorf("Select.Eval: cannot select field %q from %T (value: %q). Expected a record or module value, but got %T", d.Field.Name, receiverVal, receiverVal.String(), receiverVal)
			}
		})()
		if err != nil {
			return nil, err
		}

		// Auto-call zero-arity functions when accessed as symbols
		if d.AutoCall && isAutoCallableFn(val) {
			return autoCallFn(ctx, scope, val)
		}

		return val, nil
	})
}

func (d *Select) Walk(fn func(Node) bool) {
	if !fn(d) {
		return
	}
	if d.Receiver != nil {
		d.Receiver.Walk(fn)
	}
}

// Index represents list indexing operations like foo[0]
type Index struct {
	InferredTypeHolder
	Receiver Node
	Index    Node
	AutoCall bool
	Loc      *SourceLocation
}

var _ Node = (*Index)(nil)
var _ Evaluator = (*Index)(nil)

func (i *Index) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(i, func() (hm.Type, error) {
		// Infer the type of the receiver (should be a list)
		receiverType, err := i.Receiver.Infer(ctx, env, fresh)
		if err != nil {
			return nil, fmt.Errorf("Index.Infer receiver: %w", err)
		}

		// Infer the type of the index
		indexType, err := i.Index.Infer(ctx, env, fresh)
		if err != nil {
			return nil, fmt.Errorf("Index.Infer index: %w", err)
		}

		// Extract element/value type from the receiver. Maps are indexed by
		// String!, lists by Int!.
		var elementType hm.Type
		var isNullable bool

		unwrapped := receiverType
		if nonNull, ok := receiverType.(hm.NonNullType); ok {
			unwrapped = nonNull.Type
		} else {
			isNullable = true
		}

		switch recv := unwrapped.(type) {
		case ListType:
			intType, err := NonNullTypeNode{&NamedTypeNode{nil, "Int", i.Index.GetSourceLocation()}}.Infer(ctx, env, fresh)
			if err != nil {
				return nil, err
			}
			if _, err := hm.Assignable(indexType, intType); err != nil {
				return nil, fmt.Errorf("list index must be Int!, got %s", indexType)
			}
			elementType = recv.Type
		case MapType:
			strType, err := NonNullTypeNode{&NamedTypeNode{nil, "String", i.Index.GetSourceLocation()}}.Infer(ctx, env, fresh)
			if err != nil {
				return nil, err
			}
			if _, err := hm.Assignable(indexType, strType); err != nil {
				return nil, fmt.Errorf("map key must be String!, got %s", indexType)
			}
			elementType = recv.Type
		default:
			return nil, fmt.Errorf("cannot index non-collection type %s", receiverType)
		}

		// Apply auto-call if needed
		if i.AutoCall {
			var err error
			elementType, _, err = autoCallFnType(elementType)
			if err != nil {
				return nil, err
			}
		}

		// Return nullable element type since indexing can fail (out of bounds)
		// or if the original list was nullable
		var resultType hm.Type
		if isNullable {
			// Remove NonNull wrapper if present, since nullable list means nullable result
			if nonNullElem, ok := elementType.(hm.NonNullType); ok {
				resultType = nonNullElem.Type
			} else {
				resultType = elementType
			}
		} else {
			// Even for non-null lists, indexing can fail, so return nullable
			if nonNullElem, ok := elementType.(hm.NonNullType); ok {
				resultType = nonNullElem.Type
			} else {
				resultType = elementType
			}
		}
		i.SetInferredType(resultType)
		return resultType, nil
	})
}

func (i *Index) DeclaredSymbols() []string {
	return nil // Index expressions don't declare anything
}

func (i *Index) ReferencedSymbols() []string {
	var symbols []string
	symbols = append(symbols, i.Receiver.ReferencedSymbols()...)
	symbols = append(symbols, i.Index.ReferencedSymbols()...)
	return symbols
}

func (i *Index) Body() hm.Expression { return i }

func (i *Index) GetSourceLocation() *SourceLocation { return i.Loc }

func (i *Index) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, i, func() (Value, error) {
		// Evaluate the receiver
		receiverVal, err := EvalNode(ctx, scope, i.Receiver)
		if err != nil {
			return nil, fmt.Errorf("evaluating receiver: %w", err)
		}

		// Handle null receiver
		if _, ok := receiverVal.(NullValue); ok {
			return NullValue{}, nil
		}

		// Evaluate the index
		indexVal, err := EvalNode(ctx, scope, i.Index)
		if err != nil {
			return nil, fmt.Errorf("evaluating index: %w", err)
		}

		// Map indexing: look up by string key, null if absent.
		if mapVal, ok := receiverVal.(MapValue); ok {
			keyVal, ok := indexVal.(StringValue)
			if !ok {
				return nil, fmt.Errorf("map key must be a string, got %T", indexVal)
			}
			element, found := mapVal.Get(keyVal.Val)
			if !found {
				return NullValue{}, nil
			}
			if i.AutoCall && isAutoCallableFn(element) {
				return autoCallFn(ctx, scope, element)
			}
			return element, nil
		}

		// Check that receiver is a list
		listVal, ok := receiverVal.(ListValue)
		if !ok {
			return nil, fmt.Errorf("cannot index non-collection value of type %T", receiverVal)
		}

		// Check that index is an integer
		intVal, ok := indexVal.(IntValue)
		if !ok {
			return nil, fmt.Errorf("index must be an integer, got %T", indexVal)
		}

		// Check bounds
		idx := int(intVal.Val)
		if idx < 0 || idx >= len(listVal.Elements) {
			// Return null for out-of-bounds access (nullable behavior)
			return NullValue{}, nil
		}

		// Get the element
		element := listVal.Elements[idx]

		// Auto-call zero-arity functions when accessed
		if i.AutoCall && isAutoCallableFn(element) {
			return autoCallFn(ctx, scope, element)
		}

		return element, nil
	})
}

func (i *Index) Walk(fn func(Node) bool) {
	if !fn(i) {
		return
	}
	i.Receiver.Walk(fn)
	i.Index.Walk(fn)
}

// DotApply is dot-block application: `receiver.{ block }`. It calls the block
// with the receiver as its single argument, so `foo.{ x => bar(x) }` and
// `foo.{ bar(_) }` both mean `bar(foo)`. It sits at `.`'s precedence (a sibling
// of selection and method calls in SelectOrCall), so it interleaves with real
// method calls in a single chain.
type DotApply struct {
	InferredTypeHolder
	Receiver Node
	Block    *BlockArg
	Loc      *SourceLocation
}

var _ Node = (*DotApply)(nil)
var _ Evaluator = (*DotApply)(nil)

func (d *DotApply) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(d, func() (hm.Type, error) {
		receiverType, err := d.Receiver.Infer(ctx, env, fresh)
		if err != nil {
			return nil, err
		}

		// Dot-block supplies exactly one value, so the block must take 0 or 1
		// parameters; 2+ is an error.
		if len(d.Block.Args) > 1 {
			return nil, NewInferError(
				fmt.Errorf("dot-block takes a single value, but the block declares %d parameters",
					len(d.Block.Args)),
				d.Block,
			)
		}

		// The receiver is the block's single argument. Unlike selection,
		// dot-block does not short-circuit on null: the receiver type (nullable
		// or not) passes straight through to the parameter, letting the block
		// decide what to do with null.
		d.Block.ExpectedParamTypes = []hm.Type{receiverType}
		if _, err := d.Block.Infer(ctx, env, fresh); err != nil {
			return nil, err
		}

		result := d.Block.Inferred.Ret(false)
		d.SetInferredType(result)
		return result, nil
	})
}

func (d *DotApply) DeclaredSymbols() []string {
	return nil
}

func (d *DotApply) ReferencedSymbols() []string {
	var symbols []string
	symbols = append(symbols, d.Receiver.ReferencedSymbols()...)
	symbols = append(symbols, d.Block.ReferencedSymbols()...)
	return symbols
}

func (d *DotApply) Body() hm.Expression { return d }

func (d *DotApply) GetSourceLocation() *SourceLocation { return d.Loc }

func (d *DotApply) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, d, func() (Value, error) {
		receiverVal, err := EvalNode(ctx, scope, d.Receiver)
		if err != nil {
			return nil, err
		}

		blockVal, err := d.Block.Eval(ctx, scope)
		if err != nil {
			return nil, err
		}

		fn, ok := blockVal.(Callable)
		if !ok {
			return nil, fmt.Errorf("dot-block did not evaluate to a callable, got %T", blockVal)
		}

		// Apply the block to the receiver as its single argument. The receiver
		// is bound even when null (no short-circuit).
		return callFunc(ctx, fn, receiverVal)
	})
}

func (d *DotApply) Walk(fn func(Node) bool) {
	if !fn(d) {
		return
	}
	d.Receiver.Walk(fn)
	d.Block.Walk(fn)
}

// FieldSelection represents a field name in an object selection
type FieldSelection struct {
	InferredTypeHolder
	Alias     string           // GraphQL-style output name; "" means use Name
	Name      string           // The field actually selected off the receiver
	Args      Record           // For arguments like repositories(first: 100)
	Selection *ObjectSelection // For nested selections like profile.{bio, avatar}
	Loc       *SourceLocation
}

func (f *FieldSelection) GetSourceLocation() *SourceLocation { return f.Loc }

// OutputKey is the name this field is bound to in the resulting record: the
// alias when one is given (`full: name`), otherwise the field name itself
// (`name`, which is sugar for `name: name`). This keeps selection aligned with
// record literals, where `{{ foo }}` is shorthand for `{{ foo: foo }}`.
func (f *FieldSelection) OutputKey() string {
	if f.Alias != "" {
		return f.Alias
	}
	return f.Name
}

// InlineFragment represents a type-conditional selection like ... on User { name, email }
type InlineFragment struct {
	TypeName  *Symbol
	Qualifier string // Optional import/module qualifier (e.g. "Dagger" in ... on Dagger.Editor)
	Fields    []*FieldSelection
	NonNull   bool // Whether the type assertion is non-null (... on Container!)
	Loc       *SourceLocation

	Inferred *Type // The concrete type module for this fragment
}

func (f *InlineFragment) GetSourceLocation() *SourceLocation { return f.Loc }

// ObjectSelection represents multi-field selection like obj.{field1, field2}
// or union selection like obj.{... on User { name }, ... on Post { title }}
type ObjectSelection struct {
	InferredTypeHolder
	Receiver        Node
	Fields          []*FieldSelection
	InlineFragments []*InlineFragment // For union/interface inline fragments
	Loc             *SourceLocation

	Inferred         *Type
	IsList           bool // TODO respect
	ElementIsNonNull bool // Whether list elements are non-null (only used when IsList is true)
}

var _ Node = (*ObjectSelection)(nil)
var _ Evaluator = (*ObjectSelection)(nil)

func (o *ObjectSelection) DeclaredSymbols() []string {
	return nil // Object selections don't declare anything
}

func (o *ObjectSelection) ReferencedSymbols() []string {
	symbols := o.Receiver.ReferencedSymbols()
	for _, frag := range o.InlineFragments {
		symbols = append(symbols, frag.TypeName.Name)
	}
	return symbols
}

func (o *ObjectSelection) Body() hm.Expression { return o }

func (o *ObjectSelection) GetSourceLocation() *SourceLocation { return o.Loc }

func (o *ObjectSelection) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(o, func() (hm.Type, error) {
		// Infer the type of the receiver
		receiverType, err := o.Receiver.Infer(ctx, env, fresh)
		if err != nil {
			return nil, fmt.Errorf("ObjectSelection.Infer: %w", err)
		}

		// Handle inline fragments (union/interface selection)
		if len(o.InlineFragments) > 0 {
			return o.inferInlineFragments(ctx, receiverType, env, fresh)
		}

		// Handle regular object types
		t, err := o.inferSelectionType(ctx, receiverType, env, fresh)
		if err != nil {
			return nil, err
		}

		// If this is a list selection, wrap the result in a list type
		var resultType hm.Type
		if o.IsList {
			// Wrap the element module in NonNullType if elements are non-null
			var elementType hm.Type = t
			if o.ElementIsNonNull {
				elementType = hm.NonNullType{Type: t}
			}

			listType := ListType{Type: elementType}

			// If receiver was nullable, make result nullable too
			if _, ok := receiverType.(hm.NonNullType); ok {
				// Receiver was non-null, result should be non-null list
				resultType = hm.NonNullType{Type: listType}
			} else {
				// Receiver was nullable, result should be nullable list
				resultType = listType
			}
		} else {
			// If receiver was nullable, make result nullable too
			if _, ok := receiverType.(hm.NonNullType); ok {
				// Receiver was non-null, result should be non-null
				resultType = hm.NonNullType{Type: t}
			} else {
				// Receiver was nullable, result should be nullable
				resultType = t
			}
		}
		o.SetInferredType(resultType)
		return resultType, nil
	})
}

// inferInlineFragments validates inline fragment selections on a union or interface type.
// The result type preserves the union/interface type and list wrapping from the receiver.
func (o *ObjectSelection) inferInlineFragments(ctx context.Context, receiverType hm.Type, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	// Unwrap list and non-null to find the element type
	unwrapped := receiverType
	isList := false
	elementIsNonNull := false
	receiverIsNonNull := false
	if nn, ok := unwrapped.(hm.NonNullType); ok {
		receiverIsNonNull = true
		unwrapped = nn.Type
	}
	if lt, ok := unwrapped.(ListType); ok {
		isList = true
		unwrapped = lt.Type
		if nn, ok := unwrapped.(hm.NonNullType); ok {
			elementIsNonNull = true
			unwrapped = nn.Type
		}
	} else if lt, ok := unwrapped.(GraphQLListType); ok {
		isList = true
		unwrapped = lt.Type
		if nn, ok := unwrapped.(hm.NonNullType); ok {
			elementIsNonNull = true
			unwrapped = nn.Type
		}
	}

	// The element type must be a union or interface
	unionOrIface, ok := unwrapped.(*Type)
	if !ok {
		return nil, NewInferError(fmt.Errorf("inline fragments require a union or interface type, got %s", unwrapped), o.Receiver)
	}
	if unionOrIface.Kind != UnionKind && unionOrIface.Kind != InterfaceKind {
		return nil, NewInferError(fmt.Errorf("inline fragments require a union or interface type, got %s type %s", unionOrIface.Kind, unionOrIface), o.Receiver)
	}

	// Create a narrowed union whose members only have the selected fields.
	// This ensures downstream code (e.g. case type patterns) can only access
	// fields that were actually selected in the inline fragment.
	narrowedUnion := NewType(unionOrIface.Name(), UnionKind)
	narrowedUnion.Qualifier = unionOrIface.Qualifier

	// Validate each fragment
	for _, frag := range o.InlineFragments {
		memberMod, err := resolveInlineFragmentMemberType(unionOrIface, frag.TypeName.Name)
		if err != nil {
			return nil, NewInferError(err, frag.TypeName)
		}

		if len(frag.Fields) == 0 {
			// Lazy inline fragment: no field sub-selection, use the full concrete type.
			// This allows chaining further calls on the result as a GraphQLValue.
			narrowedUnion.LinkMember(memberMod)
			frag.Inferred = memberMod
		} else {
			// Create a narrowed module with only the selected fields.
			// Link back to the canonical type for runtime matching.
			narrowedMember := NewType(memberMod.Name(), ObjectKind)
			narrowedMember.Qualifier = memberMod.Qualifier
			narrowedMember.SourceSchema = memberMod.SourceSchema
			narrowedMember.Canonical = memberMod

			// Validate each field in the fragment exists on the concrete type
			// and add it to the narrowed module (including nested selections)
			for _, field := range frag.Fields {
				fieldType, err := o.inferFieldType(ctx, field, memberMod, env, fresh)
				if err != nil {
					return nil, NewInferError(fmt.Errorf("field %s not found on type %s", field.Name, memberMod), field)
				}
				narrowedMember.Add(field.OutputKey(), hm.NewScheme(nil, fieldType))
			}

			narrowedUnion.LinkMember(narrowedMember)
			frag.Inferred = narrowedMember
		}
	}

	o.IsList = isList
	o.ElementIsNonNull = elementIsNonNull

	// For a single lazy fragment (no fields), the result type is the concrete type directly,
	// not wrapped in a union. This enables chaining as a GraphQLValue.
	// Nullability is driven by the fragment's NonNull flag (... on Container!).
	if len(o.InlineFragments) == 1 && len(o.InlineFragments[0].Fields) == 0 {
		frag := o.InlineFragments[0]
		var resultType hm.Type = frag.Inferred
		if frag.NonNull {
			resultType = hm.NonNullType{Type: resultType}
		}
		o.IsList = isList
		o.ElementIsNonNull = elementIsNonNull
		o.SetInferredType(resultType)
		return resultType, nil
	}

	var baseType hm.Type = narrowedUnion

	// The result type preserves list/non-null wrapping from the receiver
	resultType := baseType
	if isList {
		elemType := baseType
		if elementIsNonNull {
			elemType = hm.NonNullType{Type: elemType}
		}
		resultType = ListType{Type: elemType}
	}
	if receiverIsNonNull {
		resultType = hm.NonNullType{Type: resultType}
	}

	o.SetInferredType(resultType)
	return resultType, nil
}

func resolveInlineFragmentMemberType(receiver *Type, typeName string) (*Type, error) {
	switch receiver.Kind {
	case UnionKind:
		if member, found := findMemberModuleByName(receiver.GetMembers(), typeName); found {
			return member, nil
		}
		return nil, fmt.Errorf("type %s is not a member of union %s", typeName, receiver)
	case InterfaceKind:
		if implementer, found := findMemberModuleByName(receiver.GetImplementers(), typeName); found {
			return implementer, nil
		}
		return nil, fmt.Errorf("type %s does not implement interface %s", typeName, receiver)
	default:
		return nil, fmt.Errorf("inline fragments require a union or interface type, got %s type %s", receiver.Kind, receiver)
	}
}

func findMemberModuleByName(members []TypeScope, typeName string) (*Type, bool) {
	for _, member := range members {
		if member.Name() != typeName {
			continue
		}
		memberMod, ok := member.(*Type)
		if !ok {
			return nil, false
		}
		return memberMod, true
	}
	return nil, false
}

func (o *ObjectSelection) inferSelectionType(ctx context.Context, receiverType hm.Type, env hm.Env, fresh hm.Fresher) (*Type, error) {
	// Check if receiver is nullable or non-null
	var rec TypeScope

	// Handle list types - apply selection to each element
	var innerType hm.Type
	var elementIsNonNull bool
	if nonNullType, ok := receiverType.(hm.NonNullType); ok {
		receiverType = nonNullType.Type
	}
	if listType, ok := receiverType.(ListType); ok {
		innerType = listType.Type
		// Check if element type is non-null
		_, elementIsNonNull = innerType.(hm.NonNullType)
	} else if gqlListType, ok := receiverType.(GraphQLListType); ok {
		// GraphQL lists can be converted to regular lists via object selection
		innerType = gqlListType.Type
		// Check if element type is non-null
		_, elementIsNonNull = innerType.(hm.NonNullType)
	}

	if innerType != nil {
		elementType, err := o.inferSelectionType(ctx, innerType, env, fresh)
		if err != nil {
			return nil, err
		}

		// Store both the module and whether elements are non-null
		// We'll use elementIsNonNull in the caller to wrap appropriately
		o.Inferred = elementType
		o.IsList = true
		o.ElementIsNonNull = elementIsNonNull
		return elementType, nil
	}

	if nn, ok := receiverType.(hm.NonNullType); ok {
		// Non-null receiver
		envType, ok := nn.Type.(TypeScope)
		if !ok {
			return nil, fmt.Errorf("ObjectSelection.inferSelectionType: expected TypeScope, got %T", nn.Type)
		}
		rec = envType
	} else if envType, ok := receiverType.(TypeScope); ok {
		// Nullable receiver - we can still infer the selection type from the underlying type
		rec = envType
	} else {
		return nil, fmt.Errorf("ObjectSelection.inferSelectionType: expected NonNullType or TypeScope, got %T", receiverType)
	}

	mod := NewType("", ObjectKind)
	for _, field := range o.Fields {
		fieldType, err := o.inferFieldType(ctx, field, rec, env, fresh)
		if err != nil {
			return nil, err
		}
		mod.Add(field.OutputKey(), hm.NewScheme(nil, fieldType))
	}
	o.Inferred = mod
	return mod, nil
}

func (o *ObjectSelection) inferFieldType(ctx context.Context, field *FieldSelection, rec TypeScope, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	var fieldType hm.Type
	var err error

	if len(field.Args) > 0 {
		// Field has arguments - create a Select then FunCall to infer the type
		// But use a synthetic receiver to get the field from the correct environment
		selectNode := &Select{
			Receiver: nil, // Will be handled by using rec environment directly
			Field:    &Symbol{Name: field.Name, Loc: field.Loc},
			AutoCall: false,
			Loc:      field.Loc,
		}

		funCall := &FunCall{
			Fun:  selectNode,
			Args: field.Args,
			Loc:  field.Loc,
		}

		// Create a synthetic environment that combines rec and env
		// Use rec for symbol lookup, env for argument evaluation
		synthTypeScope := &OverlayTypeScope{
			primary: rec,
			lexical: env.(TypeScope),
		}
		fieldType, err = funCall.Infer(ctx, synthTypeScope, fresh)
		if err != nil {
			return nil, err
		}
	} else {
		// No arguments - use symbol directly as before
		fieldType, err = (&Symbol{
			Name:     field.Name,
			AutoCall: true,
			Loc:      field.Loc,
		}).Infer(ctx, rec, fresh)
		if err != nil {
			return nil, err
		}
	}

	ret, _, err := autoCallFnType(fieldType)
	if err != nil {
		return nil, err
	}

	// Handle nested selections
	if field.Selection != nil {
		// Set the receiver for the nested selection to match the field we're selecting from
		field.Selection.Receiver = nil // Will be inferred from the receiver type

		if len(field.Selection.InlineFragments) > 0 {
			// Nested inline fragments: infer as union/interface type
			t, err := field.Selection.inferInlineFragments(ctx, ret, env, fresh)
			if err != nil {
				return nil, err
			}
			return t, nil
		}

		t, err := field.Selection.inferSelectionType(ctx, ret, env, fresh)
		if err != nil {
			return nil, err
		}

		// If the nested selection is on a list, wrap the result in a list type
		if field.Selection.IsList {
			listType := ListType{Type: t}
			return hm.NonNullType{Type: listType}, nil
		}

		return hm.NonNullType{Type: t}, nil
	}

	return ret, nil
}

func (o *ObjectSelection) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, o, func() (Value, error) {
		receiverVal, err := EvalNode(ctx, scope, o.Receiver)
		if err != nil {
			return nil, fmt.Errorf("ObjectSelection.Eval: %w", err)
		}

		// Handle null values - propagate null
		if _, ok := receiverVal.(NullValue); ok {
			return NullValue{}, nil
		}

		// Handle inline fragments on GraphQL values
		if len(o.InlineFragments) > 0 {
			if gqlVal, ok := receiverVal.(GraphQLValue); ok {
				return o.evalGraphQLInlineFragments(gqlVal, ctx, scope)
			}
			// For Dang-native values, inline fragments work like regular selection
			// but we need to handle lists. `{{ }}` is always parallel, so apply
			// the fragment to the elements concurrently, failing fast and keeping
			// results in source order.
			if listVal, ok := receiverVal.(ListValue); ok {
				results, err := evalParallel(ctx, len(listVal.Elements), func(ctx context.Context, i int) (Value, error) {
					return o.evalInlineFragmentOnValue(listVal.Elements[i], ctx, scope)
				})
				if err != nil {
					return nil, err
				}
				return ListValue{Elements: results, ElemType: o.GetInferredType()}, nil
			}
			return o.evalInlineFragmentOnValue(receiverVal, ctx, scope)
		}

		// Apply the selection. evalSelectionOnValue handles lists (element-wise),
		// GraphQL values (one batched query), objects, and scalar/builtin
		// receivers uniformly.
		return o.evalSelectionOnValue(receiverVal, ctx, scope)
	})
}

// evalInlineFragmentOnValue handles inline fragment selection on a Dang-native value.
// The value passes through with its original type identity — fragments just validate at compile time.
func (o *ObjectSelection) evalInlineFragmentOnValue(val Value, ctx context.Context, _ ValueScope) (Value, error) {
	modVal, ok := val.(*Object)
	if !ok {
		return nil, fmt.Errorf("inline fragment selection requires an object value, got %T", val)
	}

	// Find the matching fragment based on the concrete type name
	mod, ok := modVal.Mod.(*Type)
	if !ok {
		return nil, fmt.Errorf("inline fragment selection: expected Type, got %T", modVal.Mod)
	}

	for _, frag := range o.InlineFragments {
		if frag.TypeName.Name == mod.Name() {
			if len(frag.Fields) == 0 {
				// Lazy inline fragment: return the value as-is (type assertion only)
				return val, nil
			}
			// Build a result with the selected fields, preserving the concrete type
			resultObject := NewObject(frag.Inferred)
			for _, field := range frag.Fields {
				fieldVal, exists, err := modVal.Lookup(ctx, field.Name)
				if err != nil {
					return nil, err
				}
				if !exists {
					return nil, fmt.Errorf("field %s not found on %s", field.Name, mod)
				}
				resultObject.Bind(field.OutputKey(), fieldVal, PublicVisibility)
			}
			return resultObject, nil
		}
	}

	// No fragment matched - check if any fragment requires non-null
	for _, frag := range o.InlineFragments {
		if frag.NonNull {
			return nil, fmt.Errorf("inline fragment type assertion failed: expected one of %s, got %s",
				o.inlineFragmentTypeNames(), mod)
		}
	}

	return NullValue{}, nil
}

// isLazyInlineFragments returns true when all inline fragments have no field
// sub-selections, meaning the result should be a lazy GraphQLValue rather than
// an eagerly-fetched Object.
func (o *ObjectSelection) isLazyInlineFragments() bool {
	for _, frag := range o.InlineFragments {
		if len(frag.Fields) > 0 {
			return false
		}
	}
	return len(o.InlineFragments) > 0
}

// evalGraphQLInlineFragments builds a GraphQL query with __typename and inline fragments,
// executes it, and returns properly-typed results.
func (o *ObjectSelection) evalGraphQLInlineFragments(gqlVal GraphQLValue, ctx context.Context, scope ValueScope) (Value, error) {
	if o.isLazyInlineFragments() {
		return o.evalGraphQLLazyInlineFragments(gqlVal, ctx, scope)
	}

	// Build the query with __typename and inline fragments
	query := gqlVal.QueryChain
	if query == nil {
		return nil, fmt.Errorf("GraphQL inline fragments: no query chain")
	}

	// Build inline fragment query string
	// We need: { __typename ... on User { name email } ... on Post { title author { name } } }
	var fragParts []string
	fragParts = append(fragParts, "__typename")
	for _, frag := range o.InlineFragments {
		var fieldParts []string
		for _, field := range frag.Fields {
			if field.Selection != nil {
				fieldParts = append(fieldParts, field.Name+" "+buildSelectionString(field.Selection))
			} else {
				fieldParts = append(fieldParts, field.Name)
			}
		}
		fragParts = append(fragParts, fmt.Sprintf("... on %s { %s }", frag.TypeName.Name, strings.Join(fieldParts, " ")))
	}

	// Use SelectMultiple to inject the raw fragment selection
	query = query.SelectMultiple(fragParts...)

	// Execute the query
	var result any
	err := query.Client(gqlVal.Client).Bind(&result).Execute(ctx)
	if err != nil {
		return nil, fmt.Errorf("GraphQL inline fragments: executing query: %w", err)
	}

	// Convert results to properly-typed Objects
	return o.convertInlineFragmentResult(result, gqlVal.Schema, gqlVal.TypeScope, gqlVal.Client)
}

// evalGraphQLLazyInlineFragments handles inline fragments with no field sub-selections.
// It queries only __typename to determine the concrete type, then returns a GraphQLValue
// that can be chained further. If the runtime type doesn't match any fragment, returns
// null (for nullable receivers) or an error (for non-null receivers).
func (o *ObjectSelection) evalGraphQLLazyInlineFragments(gqlVal GraphQLValue, ctx context.Context, scope ValueScope) (Value, error) {
	query := gqlVal.QueryChain
	if query == nil {
		return nil, fmt.Errorf("GraphQL lazy inline fragments: no query chain")
	}

	// Handle list types: query __typename for each element, return a list of GraphQLValues
	if o.IsList {
		return o.evalGraphQLLazyInlineFragmentsList(gqlVal, ctx, scope)
	}

	// Query __typename to discover the concrete type
	var typeName string
	err := query.Select("__typename").Client(gqlVal.Client).Bind(&typeName).Execute(ctx)
	if err != nil {
		return nil, fmt.Errorf("GraphQL lazy inline fragments: querying __typename: %w", err)
	}

	return o.matchLazyInlineFragment(gqlVal, typeName, query)
}

// evalGraphQLLazyInlineFragmentsList handles lazy inline fragments on a list-typed GraphQL value.
// It queries __typename for all elements, then returns a list of GraphQLValues.
func (o *ObjectSelection) evalGraphQLLazyInlineFragmentsList(gqlVal GraphQLValue, ctx context.Context, _ ValueScope) (Value, error) {
	query := gqlVal.QueryChain

	// Query __typename for all elements in the list
	var result any
	err := query.Select("__typename").Client(gqlVal.Client).Bind(&result).Execute(ctx)
	if err != nil {
		return nil, fmt.Errorf("GraphQL lazy inline fragments list: querying __typename: %w", err)
	}

	resultSlice, ok := result.([]any)
	if !ok {
		return nil, fmt.Errorf("GraphQL lazy inline fragments list: expected array, got %T", result)
	}

	var elements []Value
	for _, item := range resultSlice {
		itemMap, ok := item.(map[string]any)
		if !ok {
			return nil, fmt.Errorf("GraphQL lazy inline fragments list: expected object in array, got %T", item)
		}
		typeName, ok := itemMap["__typename"].(string)
		if !ok {
			return nil, fmt.Errorf("GraphQL lazy inline fragments list: missing __typename in element")
		}

		val, err := o.matchLazyInlineFragment(gqlVal, typeName, query)
		if err != nil {
			return nil, err
		}
		elements = append(elements, val)
	}

	return ListValue{Elements: elements, ElemType: o.GetInferredType()}, nil
}

// matchLazyInlineFragment finds the matching fragment for a given __typename and returns
// a GraphQLValue for the concrete type, or null/error if no match.
func (o *ObjectSelection) matchLazyInlineFragment(gqlVal GraphQLValue, typeName string, query *querybuilder.Selection) (Value, error) {
	for _, frag := range o.InlineFragments {
		if frag.TypeName.Name == typeName {
			// Look up the concrete type in the schema
			concreteSchemaType := gqlVal.Schema.Types.Get(typeName)
			if concreteSchemaType == nil {
				return nil, fmt.Errorf("type %s not found in GraphQL schema", typeName)
			}

			// Return a GraphQLValue for the concrete type, with an inline fragment
			// added to the query chain so subsequent field selections are scoped
			// to the concrete type (e.g. node(id:...){... on Container{field}}).
			return GraphQLValue{
				Name:       gqlVal.Name,
				TypeName:   typeName,
				Field:      gqlVal.Field,
				ValType:    frag.Inferred,
				Client:     gqlVal.Client,
				Schema:     gqlVal.Schema,
				TypeScope:  gqlVal.TypeScope,
				QueryChain: query.InlineFragment(typeName),
				IsMutation: gqlVal.IsMutation,
			}, nil
		}
	}

	// No fragment matched - check if any fragment requires non-null
	for _, frag := range o.InlineFragments {
		if frag.NonNull {
			return nil, fmt.Errorf("inline fragment type assertion failed: expected one of %s, got %s",
				o.inlineFragmentTypeNames(), typeName)
		}
	}

	return NullValue{}, nil
}

// inlineFragmentTypeNames returns a comma-separated list of type names from inline fragments.
func (o *ObjectSelection) inlineFragmentTypeNames() string {
	names := make([]string, len(o.InlineFragments))
	for i, frag := range o.InlineFragments {
		names[i] = frag.TypeName.Name
	}
	return strings.Join(names, ", ")
}

// convertInlineFragmentResult converts a GraphQL response with __typename into typed Objects.
func (o *ObjectSelection) convertInlineFragmentResult(result any, schema *introspection.Schema, typeScope TypeScope, client graphql.Client) (Value, error) {
	// Handle list results
	if resultSlice, ok := result.([]any); ok {
		var elements []Value
		for _, item := range resultSlice {
			elem, err := o.convertInlineFragmentResult(item, schema, typeScope, client)
			if err != nil {
				return nil, err
			}
			elements = append(elements, elem)
		}
		return ListValue{Elements: elements, ElemType: o.GetInferredType()}, nil
	}

	// Handle single object result
	resultMap, ok := result.(map[string]any)
	if !ok {
		if result == nil {
			return NullValue{}, nil
		}
		return nil, fmt.Errorf("expected map or slice from GraphQL inline fragment query, got %T", result)
	}

	typeName, ok := resultMap["__typename"].(string)
	if !ok {
		return nil, fmt.Errorf("GraphQL inline fragment response missing __typename")
	}

	// Find the matching fragment
	for _, frag := range o.InlineFragments {
		if frag.TypeName.Name == typeName {
			// Look up the concrete type module
			concreteType, found := typeScope.NamedType(typeName)
			if !found {
				return nil, fmt.Errorf("type %s not found in type environment", typeName)
			}

			resultObject := NewObject(concreteType)
			concreteSchemaType := schema.Types.Get(typeName)
			for _, field := range frag.Fields {
				outKey := field.OutputKey()
				if fieldValue, exists := resultMap[outKey]; exists {
					// Handle nested selections recursively
					if field.Selection != nil {
						nestedVal, err := o.convertNestedSelectionResult(fieldValue, field.Selection, schema, typeName, field.Name, typeScope, client)
						if err != nil {
							return nil, fmt.Errorf("converting nested field %s: %w", field.Name, err)
						}
						resultObject.Bind(outKey, nestedVal, PublicVisibility)
						continue
					}

					var schemaField *introspection.Field
					if concreteSchemaType != nil {
						for _, candidate := range concreteSchemaType.Fields {
							if candidate.Name == field.Name {
								schemaField = candidate
								break
							}
						}
					}
					expectedType := ""
					var typeRef *introspection.TypeRef
					if schemaField != nil {
						typeRef = schemaField.TypeRef
						expectedType = schemaField.Directives.ExpectedType()
					}
					dangVal, err := graphQLResultToValue(fieldValue, typeRef, expectedType, schema, typeScope, client)
					if err != nil {
						return nil, fmt.Errorf("converting field %s: %w", field.Name, err)
					}
					resultObject.Bind(outKey, dangVal, PublicVisibility)
				}
			}

			return resultObject, nil
		}
	}

	return nil, fmt.Errorf("no inline fragment matched __typename %q", typeName)
}

// convertNestedSelectionResult converts a nested JSON value using the
// inferred type from a nested ObjectSelection inside an inline fragment.
func (o *ObjectSelection) convertNestedSelectionResult(value any, sel *ObjectSelection, schema *introspection.Schema, parentTypeName string, fieldName string, typeScope TypeScope, client graphql.Client) (Value, error) {
	if value == nil {
		return NullValue{}, nil
	}
	resultMap, ok := value.(map[string]any)
	if !ok {
		return ToValue(value)
	}
	if sel.Inferred == nil {
		return ToValue(value)
	}
	mod := NewObject(sel.Inferred)
	for _, f := range sel.Fields {
		outKey := f.OutputKey()
		if fv, exists := resultMap[outKey]; exists {
			if f.Selection != nil {
				nested, err := o.convertNestedSelectionResult(fv, f.Selection, schema, "", f.Name, typeScope, client)
				if err != nil {
					return nil, err
				}
				mod.Bind(outKey, nested, PublicVisibility)
			} else {
				dv, err := ToValue(fv)
				if err != nil {
					return nil, fmt.Errorf("converting field %s: %w", f.Name, err)
				}
				mod.Bind(outKey, dv, PublicVisibility)
			}
		}
	}
	return mod, nil
}

func (o *ObjectSelection) evalSelectionOnValue(val Value, ctx context.Context, scope ValueScope) (Value, error) {
	switch v := val.(type) {
	case NullValue:
		// Null propagation for individual values in lists
		return NullValue{}, nil
	case ListValue:
		// Apply the selection element-wise. `{{ }}` is always parallel, so the
		// elements are selected concurrently (each forks the scope for isolation)
		// and fail fast; results stay in source order.
		results, err := evalParallel(ctx, len(v.Elements), func(ctx context.Context, i int) (Value, error) {
			return o.evalSelectionOnValue(v.Elements[i], ctx, scope.Derive(true))
		})
		if err != nil {
			return nil, err
		}
		return ListValue{Elements: results}, nil
	case GraphQLValue:
		// GraphQL receivers are special-cased so the whole selection becomes a
		// single batched query — the GraphQL server resolves the sibling fields
		// in parallel, just as it would for a query written by hand.
		return o.evalGraphQLSelection(v, ctx, scope)
	default:
		// Any other selectable value — a Dang object, a String, a Float, a Map,
		// etc. — is handled uniformly by evaluating each field through the same
		// Select machinery that powers single-field selection. This keeps
		// `recv.{{ a, b }}` aligned with `recv.a` / `recv.b` by construction:
		// whatever a single selection can reach, a multi-field selection can too.
		return o.evalFieldsBySelection(v, ctx, scope)
	}
}

// evalFieldsBySelection builds the result object by selecting each field off the
// receiver exactly as a standalone `recv.field` expression would. Delegating to
// Select (and FunCall, for fields with arguments) is what guarantees multi-field
// selection works for every selectable value, not just objects and GraphQL.
func (o *ObjectSelection) evalFieldsBySelection(recv Value, ctx context.Context, scope ValueScope) (Value, error) {
	if o.Inferred == nil {
		return nil, fmt.Errorf("ObjectSelection.evalFieldsBySelection: inferred type is nil")
	}

	// `{{ }}` is always parallel: selected fields are independent reads off the
	// same receiver, so evaluate them concurrently and fail fast. Each field
	// forks the scope so its incidental local writes stay private — the receiver
	// and lexical scope are only read. Results are bound in source order, so the
	// record layout is deterministic regardless of completion order.
	vals, err := evalParallel(ctx, len(o.Fields), func(ctx context.Context, i int) (Value, error) {
		return o.evalFieldSelection(recv, o.Fields[i], ctx, scope.Derive(true))
	})
	if err != nil {
		return nil, err
	}

	resultObject := NewObject(o.Inferred)
	for i, field := range o.Fields {
		resultObject.Bind(field.OutputKey(), vals[i], PublicVisibility)
	}
	return resultObject, nil
}

// evalFieldSelection evaluates a single selected field against the receiver,
// reusing the Select/FunCall evaluation path so the result matches what the
// equivalent standalone selection would produce.
func (o *ObjectSelection) evalFieldSelection(recv Value, field *FieldSelection, ctx context.Context, scope ValueScope) (Value, error) {
	selectNode := &Select{
		Receiver: createValueNode(recv),
		Field:    &Symbol{Name: field.Name, Loc: field.Loc},
		// With no arguments the field is auto-called when it resolves to a
		// zero-arity function, mirroring how the type was inferred.
		AutoCall: len(field.Args) == 0,
		Loc:      field.Loc,
	}

	var node Node = selectNode
	if len(field.Args) > 0 {
		node = &FunCall{
			Fun:  selectNode,
			Args: field.Args,
			Loc:  field.Loc,
		}
	}

	fieldVal, err := EvalNode(ctx, scope, node)
	if err != nil {
		return nil, err
	}

	// Handle nested selections, e.g. profile.{{ bio, avatar }}.
	if field.Selection != nil {
		fieldVal, err = field.Selection.evalSelectionOnValue(fieldVal, ctx, scope)
		if err != nil {
			return nil, err
		}
	}

	return fieldVal, nil
}

func (o *ObjectSelection) evalGraphQLSelection(gqlVal GraphQLValue, ctx context.Context, scope ValueScope) (Value, error) {
	if o.Inferred == nil {
		return nil, fmt.Errorf("ObjectSelection.evalModuleSelection: inferred type is nil")
	}

	// Build optimized GraphQL query for all selected fields
	query, err := o.buildGraphQLQuery(ctx, scope, gqlVal.QueryChain, o.Fields)
	if err != nil {
		return nil, fmt.Errorf("ObjectSelection.evalGraphQLSelection: %w", err)
	}

	// Execute the single optimized query
	var result any
	err = query.Client(gqlVal.Client).Bind(&result).Execute(ctx)
	if err != nil {
		// If the server reports which field failed, highlight that specific
		// field in the source rather than the whole selection.
		if field := o.locateErrorField(graphqlErrorFieldPath(err)); field != nil {
			return nil, CreateEvalError(ctx, fmt.Errorf("executing GraphQL query: %w", err), field)
		}
		return nil, fmt.Errorf("ObjectSelection.evalGraphQLSelection: executing GraphQL query: %w", err)
	}

	// Convert GraphQL result to Object
	return o.convertGraphQLResultToModule(result, o.Fields, gqlVal.Schema, gqlVal.Field, gqlVal.TypeScope, gqlVal.Client)
}

// graphqlErrorFieldPath extracts the field path from a GraphQL execution error
// (e.g. ["viewer", "repositories"]). List indices are ignored since they don't
// correspond to selected fields. Returns nil if the error carries no path.
func graphqlErrorFieldPath(err error) []string {
	var list gqlerror.List
	if !errors.As(err, &list) {
		return nil
	}
	for _, e := range list {
		if e == nil || len(e.Path) == 0 {
			continue
		}
		var names []string
		for _, seg := range e.Path {
			if name, ok := seg.(ast.PathName); ok {
				names = append(names, string(name))
			}
		}
		if len(names) > 0 {
			return names
		}
	}
	return nil
}

// locateErrorField walks the selection tree to find the deepest field matching
// the given GraphQL error path, so its source location can be highlighted. The
// path is absolute from the query root, so any leading segments that don't
// match a selected field (such as the receiver) are skipped. Returns nil if no
// field matches.
func (o *ObjectSelection) locateErrorField(path []string) *FieldSelection {
	if len(path) == 0 {
		return nil
	}

	// GraphQL error paths use response keys, which are the field aliases when
	// present, so match on the output key rather than the field name.
	findField := func(fields []*FieldSelection, name string) *FieldSelection {
		for _, f := range fields {
			if f.OutputKey() == name {
				return f
			}
		}
		return nil
	}

	fields := o.Fields

	// Skip leading path segments (e.g. the receiver) until one matches a
	// selected field at this level.
	start := 0
	for start < len(path) && findField(fields, path[start]) == nil {
		start++
	}

	var deepest *FieldSelection
	for i := start; i < len(path); i++ {
		f := findField(fields, path[i])
		if f == nil {
			break
		}
		deepest = f
		if f.Selection == nil {
			break
		}
		fields = f.Selection.Fields
	}
	return deepest
}

func (o *ObjectSelection) buildGraphQLQuery(ctx context.Context, scope ValueScope, baseQuery *querybuilder.Selection, fields []*FieldSelection) (*querybuilder.Selection, error) {
	// Start with the base query (which contains the context like "serverInfo")
	builder := baseQuery
	if builder == nil {
		builder = querybuilder.Query()
	}

	// Build an ordered, alias-aware selection set. A field with neither
	// arguments nor a nested selection becomes a plain scalar (Sub == nil);
	// otherwise its Sub carries the nested selection and/or arguments. Using an
	// ordered list (rather than a name-keyed map) lets aliases rename fields and
	// lets the same field appear more than once under distinct aliases.
	selections := make([]querybuilder.SelectionField, 0, len(fields))
	for _, field := range fields {
		entry := querybuilder.SelectionField{Name: field.Name}
		// `name` and `name: name` are equivalent, so only emit an explicit
		// GraphQL alias when it actually renames the field.
		if field.Alias != "" && field.Alias != field.Name {
			entry.Alias = field.Alias
		}

		if field.Selection != nil || len(field.Args) > 0 {
			// Field has arguments and/or a nested selection. Build the
			// sub-selection (if any) and attach arguments through the query
			// builder, which owns argument marshalling and formatting.
			var value *querybuilder.Selection
			var err error
			switch {
			case field.Selection == nil:
				// Scalar field that only takes arguments (e.g. avatarUrl(size:
				// 200)); no sub-selection. An empty selection carries the args.
				value = querybuilder.Query().SelectFields()
			case len(field.Selection.InlineFragments) > 0:
				// Nested inline fragments: build __typename + ... on Type { fields }
				value, err = field.Selection.buildInlineFragmentQuery(querybuilder.Query())
			default:
				value, err = field.Selection.buildGraphQLQuery(ctx, scope, querybuilder.Query(), field.Selection.Fields)
			}
			if err != nil {
				return nil, err
			}

			for _, arg := range field.Args {
				argVal, err := EvalNode(ctx, scope, arg.Value)
				if err != nil {
					return nil, fmt.Errorf("evaluating argument %s: %w", arg.Key, err)
				}
				// Convert Dang value to Go value for GraphQL; the builder marshals it.
				goVal, err := dangValueToGo(argVal)
				if err != nil {
					return nil, fmt.Errorf("converting argument %s: %w", arg.Key, err)
				}
				value = value.Arg(arg.Key, goVal)
			}

			entry.Sub = value
		}

		selections = append(selections, entry)
	}

	return builder.SelectAliased(selections), nil
}

// graphQLFieldToken renders a field's GraphQL selection token, prefixing the
// alias when one renames the field: "name" or "alias: name".
func graphQLFieldToken(field *FieldSelection) string {
	if field.Alias != "" && field.Alias != field.Name {
		return field.Alias + ": " + field.Name
	}
	return field.Name
}

// buildInlineFragmentQuery builds a query with __typename and inline fragments
// for use as a nested selection inside a parent field.
func (o *ObjectSelection) buildInlineFragmentQuery(baseQuery *querybuilder.Selection) (*querybuilder.Selection, error) {
	var fragParts []string
	fragParts = append(fragParts, "__typename")
	for _, frag := range o.InlineFragments {
		var fieldParts []string
		for _, field := range frag.Fields {
			if field.Selection != nil {
				// Nested selection: build sub-selection string
				fieldParts = append(fieldParts, graphQLFieldToken(field)+" "+buildSelectionString(field.Selection))
			} else {
				fieldParts = append(fieldParts, graphQLFieldToken(field))
			}
		}
		fragParts = append(fragParts, fmt.Sprintf("... on %s { %s }", frag.TypeName.Name, strings.Join(fieldParts, " ")))
	}
	return baseQuery.SelectMultiple(fragParts...), nil
}

// buildSelectionString recursively builds a GraphQL selection set string
// like "{ name login }" from an ObjectSelection.
func buildSelectionString(sel *ObjectSelection) string {
	var parts []string
	for _, field := range sel.Fields {
		if field.Selection != nil {
			parts = append(parts, graphQLFieldToken(field)+" "+buildSelectionString(field.Selection))
		} else {
			parts = append(parts, graphQLFieldToken(field))
		}
	}
	for _, frag := range sel.InlineFragments {
		var fieldParts []string
		for _, field := range frag.Fields {
			if field.Selection != nil {
				fieldParts = append(fieldParts, graphQLFieldToken(field)+" "+buildSelectionString(field.Selection))
			} else {
				fieldParts = append(fieldParts, graphQLFieldToken(field))
			}
		}
		parts = append(parts, fmt.Sprintf("... on %s { %s }", frag.TypeName.Name, strings.Join(fieldParts, " ")))
	}
	return "{ " + strings.Join(parts, " ") + " }"
}

func (o *ObjectSelection) convertGraphQLResultToModule(result any, fields []*FieldSelection, schema *introspection.Schema, parentField *introspection.Field, typeScope TypeScope, client graphql.Client) (Value, error) {
	// Check if the result is a list/slice
	if resultSlice, ok := result.([]any); ok {
		var elements []Value
		for _, item := range resultSlice {
			itemValue, err := o.convertGraphQLResultToModule(item, fields, schema, parentField, typeScope, client)
			if err != nil {
				return nil, err
			}
			elements = append(elements, itemValue)
		}
		return ListValue{Elements: elements}, nil
	}

	resultObject := NewObject(o.Inferred)

	// Convert GraphQL result to Dang values
	if resultMap, ok := result.(map[string]any); ok {
		for _, field := range fields {
			// The response is keyed by the output name (alias when present),
			// while schema lookups use the underlying field name.
			outKey := field.OutputKey()
			if fieldValue, exists := resultMap[outKey]; exists {
				// Check if fieldValue is a list that needs selection applied to each element
				// Get the field information for the nested selection
				nestedField := o.getFieldFromParent(field.Name, parentField, schema)

				// Handle nested selections
				if field.Selection != nil {
					if len(field.Selection.InlineFragments) > 0 {
						// Nested inline fragments: dispatch to inline fragment result converter
						nestedResult, err := field.Selection.convertInlineFragmentResult(fieldValue, schema, typeScope, client)
						if err != nil {
							return nil, fmt.Errorf("ObjectSelection.convertGraphQLResultToModule: nested field %q inline fragments: %w", field.Name, err)
						}
						resultObject.Bind(outKey, nestedResult, PublicVisibility)
					} else if fieldSlice, isSlice := fieldValue.([]any); isSlice && field.Selection.IsList {
						// Sub-selecting arrays
						var elements []Value
						for _, item := range fieldSlice {
							itemResult, err := field.Selection.convertGraphQLResultToModule(item, field.Selection.Fields, schema, nestedField, typeScope, client)
							if err != nil {
								return nil, fmt.Errorf("ObjectSelection.convertGraphQLResultToModule: nested field %q item: %w", field.Name, err)
							}
							elements = append(elements, itemResult)
						}
						resultObject.Bind(outKey, ListValue{Elements: elements}, PublicVisibility)
					} else {
						// Sub-selecting objects
						nestedResult, err := field.Selection.convertGraphQLResultToModule(fieldValue, field.Selection.Fields, schema, nestedField, typeScope, client)
						if err != nil {
							return nil, fmt.Errorf("ObjectSelection.convertGraphQLResultToModule: nested field %q: %w", field.Name, err)
						}
						resultObject.Bind(outKey, nestedResult, PublicVisibility)
					}
				} else {
					expectedType := ""
					var typeRef *introspection.TypeRef
					if nestedField != nil {
						typeRef = nestedField.TypeRef
						expectedType = nestedField.Directives.ExpectedType()
					}
					dangVal, err := graphQLResultToValue(fieldValue, typeRef, expectedType, schema, typeScope, client)
					if err != nil {
						return nil, fmt.Errorf("ObjectSelection.convertGraphQLResultToModule: converting field %q: %w", field.Name, err)
					}
					resultObject.Bind(outKey, dangVal, PublicVisibility)
				}
			}
		}
	}

	return resultObject, nil
}

// getFieldFromParent finds a field by name in the parent field's return type
func (o *ObjectSelection) getFieldFromParent(fieldName string, parentField *introspection.Field, schema *introspection.Schema) *introspection.Field {
	if parentField == nil || schema == nil {
		return nil
	}

	// Get the return type of the parent field (unwrapping lists and non-nulls)
	returnType := o.unwrapType(parentField.TypeRef)
	if returnType == nil {
		return nil
	}

	// Find the type in the schema
	schemaType := schema.Types.Get(returnType.Name)
	if schemaType == nil {
		return nil
	}

	// Find the field in the type
	for _, field := range schemaType.Fields {
		if field.Name == fieldName {
			return field
		}
	}

	return nil
}

// unwrapType recursively unwraps LIST and NON_NULL wrappers to get the underlying named type
func (o *ObjectSelection) unwrapType(typeRef *introspection.TypeRef) *introspection.TypeRef {
	if typeRef == nil {
		return nil
	}

	switch typeRef.Kind {
	case "NON_NULL", "LIST":
		return o.unwrapType(typeRef.OfType)
	default:
		return typeRef
	}
}

func (o *ObjectSelection) Walk(fn func(Node) bool) {
	if !fn(o) {
		return
	}
	o.Receiver.Walk(fn)
}

// Conditional represents an if-then-else expression
type Conditional struct {
	InferredTypeHolder
	Condition Node
	Then      Node
	Else      Node
	Loc       *SourceLocation
}

var _ Node = (*Conditional)(nil)
var _ Evaluator = (*Conditional)(nil)

func (c *Conditional) DeclaredSymbols() []string {
	return nil // Conditionals don't declare anything
}

func (c *Conditional) ReferencedSymbols() []string {
	var symbols []string
	symbols = append(symbols, c.Condition.ReferencedSymbols()...)
	symbols = append(symbols, c.Then.ReferencedSymbols()...)
	if c.Else != nil {
		symbols = append(symbols, c.Else.ReferencedSymbols()...)
	}
	return symbols
}

func (c *Conditional) Body() hm.Expression { return c }

func (c *Conditional) GetSourceLocation() *SourceLocation { return c.Loc }

func (c *Conditional) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(c, func() (hm.Type, error) {
		condType, err := c.Condition.Infer(ctx, env, fresh)
		if err != nil {
			return nil, err
		}

		if _, err := hm.Assignable(condType, hm.NonNullType{Type: BooleanType}); err != nil {
			return nil, NewInferError(fmt.Errorf("condition must be Boolean, got %s", condType), c.Condition)
		}

		// Apply flow-sensitive narrowings to each branch based on the condition.
		facts := analyzeCondition(c.Condition, env)

		thenEnv := withNarrowings(env, facts.Truthy)
		thenType, err := c.Then.Infer(ctx, thenEnv, fresh)
		if err != nil {
			return nil, err
		}

		if c.Else != nil {
			elseEnv := withNarrowings(env, facts.Falsy)
			elseType, err := c.Else.Infer(ctx, elseEnv, fresh)
			if err != nil {
				return nil, err
			}

			mergedType, subs, err := hm.MergeTypes(thenType, elseType)
			if err != nil {
				// Branches diverge: widen to a union and let downstream usage
				// (or a tail-position type annotation) decide whether that's
				// actually a problem.
				thenType = hm.NewUnionTypeWithSources(
					[]hm.Type{thenType, elseType},
					[]any{nodeOrigin("then branch", c.Then), nodeOrigin("else branch", c.Else)},
				)
			} else {
				// Propagate substitutions backwards to the 'then' branch without
				// widening the branch itself to the merged conditional result.
				c.Then.SetInferredType(thenType.Apply(subs).(hm.Type))
				thenType = mergedType
			}
		}

		if c.Else == nil {
			// A conditional without an else can skip the then branch and
			// evaluate to null. Preserve that fallthrough even when the then
			// branch is a control-flow expression with a fresh result type.
			thenType = nullableControlResultType(thenType)
		}

		return thenType, nil
	})
}

func (c *Conditional) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, c, func() (Value, error) {
		condVal, err := EvalNode(ctx, scope, c.Condition)
		if err != nil {
			return nil, fmt.Errorf("evaluating condition: %w", err)
		}

		boolVal, ok := condVal.(BoolValue)
		if !ok {
			return nil, fmt.Errorf("condition must evaluate to boolean, got %T", condVal)
		}

		if boolVal.Val {
			return EvalNode(ctx, scope, c.Then)
		} else if c.Else != nil {
			return EvalNode(ctx, scope, c.Else)
		} else {
			return NullValue{}, nil
		}
	})
}

func (c *Conditional) Walk(fn func(Node) bool) {
	if !fn(c) {
		return
	}
	c.Condition.Walk(fn)
	c.Then.Walk(fn)
	if c.Else != nil {
		c.Else.Walk(fn)
	}
}

// Break represents a break statement in a block-taking call.
type Break struct {
	InferredTypeHolder
	Value      Node
	ValueType  hm.Type
	HasValue   bool
	Target     *InferControlTarget
	TargetKind ControlFrameKind
	Loc        *SourceLocation
}

var _ Node = (*Break)(nil)
var _ Evaluator = (*Break)(nil)

func (b *Break) DeclaredSymbols() []string {
	return nil // Break doesn't declare anything
}

func (b *Break) ReferencedSymbols() []string {
	if b.Value == nil {
		return nil
	}
	return b.Value.ReferencedSymbols()
}

func (b *Break) Body() hm.Expression { return b }

func (b *Break) GetSourceLocation() *SourceLocation { return b.Loc }

func (b *Break) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(b, func() (hm.Type, error) {
		target := currentInferBreakTarget(ctx)
		if target == nil {
			return nil, NewInferError(fmt.Errorf("break outside of block-taking call"), b)
		}
		b.Target = target
		b.TargetKind = target.Kind
		b.HasValue = b.Value != nil

		if b.Value != nil {
			valueType, err := b.Value.Infer(ctx, env, fresh)
			if err != nil {
				return nil, err
			}
			b.ValueType = valueType
		} else {
			b.ValueType = hm.NullableTypeVariable{TypeVariable: fresh.Fresh()}
		}

		// Break never produces a local value for the surrounding expression.
		t := fresh.Fresh()
		b.SetInferredType(t)
		return t, nil
	})
}

func (b *Break) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	target := currentBreakFrame(ctx)
	if target == nil || !target.Active {
		return nil, &BreakException{Target: target, Location: b.Loc}
	}

	var val Value
	if b.Value != nil {
		var err error
		val, err = EvalNode(ctx, scope, b.Value)
		if err != nil {
			return nil, err
		}
	}

	return nil, &BreakException{Target: target, Value: val, HasValue: b.Value != nil, Location: b.Loc}
}

func (b *Break) Walk(fn func(Node) bool) {
	if !fn(b) {
		return
	}
	if b.Value != nil {
		b.Value.Walk(fn)
	}
}

// Continue represents a continue statement in a block-taking call.
type Continue struct {
	InferredTypeHolder
	Value      Node
	ValueType  hm.Type
	HasValue   bool
	Target     *InferControlTarget
	TargetKind ControlFrameKind
	Loc        *SourceLocation
}

var _ Node = (*Continue)(nil)
var _ Evaluator = (*Continue)(nil)

func (c *Continue) DeclaredSymbols() []string {
	return nil // Continue doesn't declare anything
}

func (c *Continue) ReferencedSymbols() []string {
	if c.Value == nil {
		return nil
	}
	return c.Value.ReferencedSymbols()
}

func (c *Continue) Body() hm.Expression { return c }

func (c *Continue) GetSourceLocation() *SourceLocation { return c.Loc }

func (c *Continue) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(c, func() (hm.Type, error) {
		target := currentInferContinueTarget(ctx)
		if target == nil {
			return nil, NewInferError(fmt.Errorf("continue outside of block-taking call"), c)
		}
		c.Target = target
		c.TargetKind = target.Kind
		c.HasValue = c.Value != nil

		if c.Value != nil {
			valueType, err := c.Value.Infer(ctx, env, fresh)
			if err != nil {
				return nil, err
			}
			c.ValueType = valueType
		} else {
			c.ValueType = hm.NullableTypeVariable{TypeVariable: fresh.Fresh()}
		}

		// Continue never produces a local value for the surrounding expression.
		t := fresh.Fresh()
		c.SetInferredType(t)
		return t, nil
	})
}

func (c *Continue) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	target := currentContinueFrame(ctx)
	if target == nil || !target.Active {
		return nil, &ContinueException{Target: target, Location: c.Loc}
	}

	var val Value
	if c.Value != nil {
		var err error
		val, err = EvalNode(ctx, scope, c.Value)
		if err != nil {
			return nil, err
		}
	}

	return nil, &ContinueException{Target: target, Value: val, HasValue: c.Value != nil, Location: c.Loc}
}

func (c *Continue) Walk(fn func(Node) bool) {
	if !fn(c) {
		return
	}
	if c.Value != nil {
		c.Value.Walk(fn)
	}
}

// BreakException is used to signal a break statement.
type BreakException struct {
	Target   *ControlFrame
	Value    Value
	HasValue bool
	Location *SourceLocation
}

func (e *BreakException) Error() string {
	if e.Target != nil && !e.Target.Active {
		switch e.Target.Kind {
		case BlockCallFrame:
			return "break from expired block call"
		}
	}
	return "break outside of block-taking call"
}

// ContinueException is used to signal a continue statement.
type ContinueException struct {
	Target   *ControlFrame
	Value    Value
	HasValue bool
	Location *SourceLocation
}

func (e *ContinueException) Error() string {
	if e.Target != nil && !e.Target.Active {
		switch e.Target.Kind {
		case BlockInvocationFrame:
			return "continue from expired block invocation"
		}
	}
	return "continue outside of block-taking call"
}

func breakValueType(br *Break) hm.Type {
	if br == nil {
		return nil
	}
	if br.ValueType != nil {
		return br.ValueType
	}
	if br.Value != nil {
		return br.Value.GetInferredType()
	}
	return nil
}

func continueValueType(cont *Continue) hm.Type {
	if cont == nil {
		return nil
	}
	if cont.ValueType != nil {
		return cont.ValueType
	}
	if cont.Value != nil {
		return cont.Value.GetInferredType()
	}
	return nil
}

func collectBreakStatements(root Node, target *InferControlTarget) []*Break {
	if root == nil {
		return nil
	}

	var breaks []*Break
	root.Walk(func(node Node) bool {
		if node != root {
			switch node.(type) {
			case *FunDecl, *NewConstructorDecl, *ObjectDecl:
				return false
			}
		}

		if br, ok := node.(*Break); ok {
			if target == nil || br.Target == target {
				breaks = append(breaks, br)
			}
			// A break's value is evaluated before the break is raised, so
			// nested breaks inside the value can be the one that actually
			// escapes and must be checked too.
			return true
		}

		return true
	})
	return breaks
}

func collectContinueStatements(root Node, target *InferControlTarget) []*Continue {
	if root == nil {
		return nil
	}

	var continues []*Continue
	root.Walk(func(node Node) bool {
		if node != root {
			switch node.(type) {
			case *FunDecl, *NewConstructorDecl, *ObjectDecl:
				return false
			}
		}

		if cont, ok := node.(*Continue); ok {
			if target == nil || cont.Target == target {
				continues = append(continues, cont)
			}
			// A continue's value is evaluated before the continue is raised, so
			// nested continues inside the value can be the one that actually
			// escapes and must be checked too.
			return true
		}

		return true
	})
	return continues
}

func nullableControlResultType(t hm.Type) hm.Type {
	switch typ := t.(type) {
	case hm.NonNullType:
		return typ.Type
	case hm.TypeVariable:
		return hm.NullableTypeVariable{TypeVariable: typ}
	default:
		return t
	}
}

func mergeControlResultTypes(current hm.Type, next hm.Type) hm.Type {
	merged, _, err := hm.MergeTypes(current, next)
	if err == nil {
		return merged
	}
	return hm.NewUnionType(current, next)
}

func mergeCallBreakTypes(retType hm.Type, body Node, target *InferControlTarget, subs hm.Subs, fresh hm.Fresher) hm.Type {
	for _, br := range collectBreakStatements(body, target) {
		breakType := breakValueType(br)
		if breakType == nil {
			breakType = hm.NullableTypeVariable{TypeVariable: fresh.Fresh()}
		}
		if subs != nil {
			breakType = breakType.Apply(subs).(hm.Type)
		}
		if br.HasValue {
			retType = hm.NewUnionTypeWithSources(
				[]hm.Type{retType, breakType},
				[]any{nil, armOrigin("break value", br.Loc)},
			)
		} else {
			retType = mergeControlResultTypes(retType, breakType)
		}
	}
	return retType
}

// TypeHint represents a type hint expression using :: syntax
type TypeHint struct {
	InferredTypeHolder
	Expr Node
	Type TypeNode
	Loc  *SourceLocation
}

var _ Node = (*TypeHint)(nil)
var _ Evaluator = (*TypeHint)(nil)

func (t *TypeHint) DeclaredSymbols() []string {
	return nil // Type hints don't declare symbols
}

func (t *TypeHint) ReferencedSymbols() []string {
	return t.Expr.ReferencedSymbols()
}

func (t *TypeHint) Body() hm.Expression { return t }

func (t *TypeHint) GetSourceLocation() *SourceLocation { return t.Loc }

func (t *TypeHint) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(t, func() (hm.Type, error) {
		exprType, err := t.Expr.Infer(ctx, env, fresh)
		if err != nil {
			return nil, err
		}

		hintType, err := t.Type.Infer(ctx, env, fresh)
		if err != nil {
			return nil, err
		}

		// Type hints are explicit runtime assertion/materialization boundaries.
		// First accept ordinary pure assignability (including type-variable binding
		// and T! -> T). If that fails, allow explicit scalar/enum coercions. Do not
		// strip non-null wrappers here: nullable-to-non-null casts must either be
		// rejected statically or checked by Coerce for deferred values.
		subs, err := hm.Assignable(exprType, hintType)
		if err != nil {
			subs, err = hm.AssignableWithCoercion(exprType, hintType)
		}
		if err != nil {
			return nil, NewInferError(fmt.Errorf("type hint mismatch: expression has type %s, but hint expects %s", exprType, hintType), t.Expr)
		}

		result := hintType.Apply(subs).(hm.Type)
		t.SetInferredType(result)
		t.Expr = wrapCoerce(t.Expr, result, "")
		return result, nil
	})
}

func (t *TypeHint) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, t, func() (Value, error) {
		// t.Expr is wrapped in a Coerce by TypeHint.Infer, so materialization
		// happens inside EvalNode.
		return EvalNode(ctx, scope, t.Expr)
	})
}

func (t *TypeHint) Walk(fn func(Node) bool) {
	if !fn(t) {
		return
	}
	t.Expr.Walk(fn)
}

// BlockArg represents a block argument expression with bidirectional type inference
// Block args are used in function calls like: numbers.map: { x -> x * 2 }
// They differ from lambdas in that they receive both parameter types AND
// expected return type from the function signature they're passed to.
type BlockArg struct {
	InferredTypeHolder
	Args     []*FieldDecl
	BodyNode Node
	Loc      *SourceLocation

	// ExpectedParamTypes are the parameter types expected by the function signature.
	// Set by FunCall.Infer() before calling BlockArg.Infer()
	ExpectedParamTypes []hm.Type

	// ExpectedReturnType is the return type expected by the function signature.
	// Set by FunCall.Infer() before calling BlockArg.Infer()
	ExpectedReturnType hm.Type

	// Inferred is the final inferred function type
	Inferred *hm.FunctionType

	// InferredScope is the environment with parameters in scope
	InferredScope TypeScope

	// ImplicitUnderscore is set during Infer when the block declares no explicit
	// parameters but references `_`, giving it a single implicit parameter `_`.
	ImplicitUnderscore bool
}

// blockArgUsesImplicitUnderscore reports whether the body references the
// implicit `_` parameter. References inside a nested param-less block belong to
// that inner block (it shadows), so descent stops there; blocks with explicit
// parameters are descended into, since `_` inside them refers outward.
func blockArgUsesImplicitUnderscore(body Node) bool {
	found := false
	body.Walk(func(node Node) bool {
		if found {
			return false
		}
		switch n := node.(type) {
		case *Symbol:
			if n.Name == "_" {
				found = true
			}
		case *BlockArg:
			if len(n.Args) == 0 {
				// Nested param-less block captures its own `_`; don't descend.
				return false
			}
		}
		return true
	})
	return found
}

var _ Node = &BlockArg{}
var _ Evaluator = &BlockArg{}

func (b *BlockArg) DeclaredSymbols() []string {
	return nil // BlockArgs don't declare symbols in the global scope
}

func (b *BlockArg) ReferencedSymbols() []string {
	// BlockArgs reference symbols from their body, but not their parameters
	bodySymbols := b.BodyNode.ReferencedSymbols()

	// Filter out parameter names since they're bound locally
	paramNames := make(map[string]bool)
	for _, arg := range b.Args {
		paramNames[arg.Name.Name] = true
	}

	var referenced []string
	for _, sym := range bodySymbols {
		if !paramNames[sym] {
			referenced = append(referenced, sym)
		}
	}

	return referenced
}

func (b *BlockArg) Body() hm.Expression { return b }

func (b *BlockArg) GetSourceLocation() *SourceLocation { return b.Loc }

func (b *BlockArg) Infer(ctx context.Context, env hm.Env, fresh hm.Fresher) (hm.Type, error) {
	return WithInferErrorHandling(b, func() (hm.Type, error) {
		// Check if block has too many parameters
		if len(b.Args) > len(b.ExpectedParamTypes) {
			return nil, NewInferError(
				fmt.Errorf("block has %d parameters but expected at most %d",
					len(b.Args), len(b.ExpectedParamTypes)),
				b,
			)
		}

		// A block with no explicit parameters that references `_` in its body
		// takes a single implicit parameter named `_` (Kotlin `it`-style). Every
		// `_` in the block refers to that same single argument; a nested
		// param-less block shadows it.
		b.ImplicitUnderscore = len(b.Args) == 0 && blockArgUsesImplicitUnderscore(b.BodyNode)

		// Clone environment for closure semantics
		newEnv := env.Clone()
		b.InferredScope = newEnv.(TypeScope)

		// Add user-provided parameters to environment with expected types
		argSchemes := []Keyed[*hm.Scheme]{}
		for i, arg := range b.Args {
			var paramType hm.Type
			if i < len(b.ExpectedParamTypes) && b.ExpectedParamTypes[i] != nil {
				// Use the expected type from the function signature
				paramType = b.ExpectedParamTypes[i]
			} else {
				// No expected type - create a fresh type variable
				paramType = fresh.Fresh()
			}

			// Add parameter to environment
			newEnv.Add(arg.Name.Name, hm.NewScheme(nil, paramType))
			argSchemes = append(argSchemes, Keyed[*hm.Scheme]{
				Key:   arg.Name.Name,
				Value: hm.NewScheme(nil, paramType),
			})
		}

		// The implicit `_` parameter consumes the first expected parameter slot.
		consumed := len(b.Args)
		if b.ImplicitUnderscore {
			var paramType hm.Type
			if len(b.ExpectedParamTypes) > 0 && b.ExpectedParamTypes[0] != nil {
				paramType = b.ExpectedParamTypes[0]
			} else {
				paramType = fresh.Fresh()
			}
			newEnv.Add("_", hm.NewScheme(nil, paramType))
			argSchemes = append(argSchemes, Keyed[*hm.Scheme]{
				Key:   "_",
				Value: hm.NewScheme(nil, paramType),
			})
			consumed = 1
		}

		// Add any remaining expected parameters to the function type signature
		// but NOT to the environment (they will be ignored by the block)
		for i := consumed; i < len(b.ExpectedParamTypes); i++ {
			paramType := b.ExpectedParamTypes[i]
			// Generate a parameter name for the type signature
			paramName := fmt.Sprintf("_unused%d", i)
			argSchemes = append(argSchemes, Keyed[*hm.Scheme]{
				Key:   paramName,
				Value: hm.NewScheme(nil, paramType),
			})
		}

		// Infer the body with parameters in scope. A block invocation target makes
		// `continue value` contribute to this block's return type, while `return`
		// still targets the enclosing function from the surrounding context.
		continueTarget := NewInferControlTarget(BlockInvocationFrame)
		bodyCtx := contextWithInferContinueTarget(ctx, continueTarget)
		bodyType, err := b.BodyNode.Infer(bodyCtx, newEnv, fresh)
		if err != nil {
			return nil, fmt.Errorf("BlockArg body: %w", err)
		}

		// Continue values are block-local results. Plain returns inside a block arg
		// are non-local and are checked against the enclosing function instead.
		continues := collectContinueStatements(b.BodyNode, continueTarget)
		for _, cont := range continues {
			contType := continueValueType(cont)
			if contType == nil {
				contType = hm.NullableTypeVariable{TypeVariable: fresh.Fresh()}
			}
			bodyType = mergeControlResultTypesTagged(
				bodyType, nil,
				contType, armOrigin("continue value", cont.Loc),
			)
		}

		// If we have an expected return type, unify with the block's normal result
		// plus any `continue value` results targeting this invocation.
		if b.ExpectedReturnType != nil {
			if _, expectedNonNull := b.ExpectedReturnType.(hm.NonNullType); expectedNonNull {
				for _, cont := range continues {
					if !cont.HasValue {
						return nil, NewInferError(
							fmt.Errorf("continue type mismatch: expected %s, inferred null", b.ExpectedReturnType),
							cont,
						)
					}
				}
			}
			for _, cont := range continues {
				contType := continueValueType(cont)
				if contType == nil {
					continue
				}
				if _, err := hm.Assignable(contType, b.ExpectedReturnType); err != nil {
					errorNode := Node(cont)
					if cont.Value != nil {
						errorNode = cont.Value
					}
					return nil, NewInferError(
						fmt.Errorf("continue type mismatch: expected %s, inferred %s", b.ExpectedReturnType, contType),
						errorNode,
					)
				}
			}

			subs, err := hm.Assignable(bodyType, b.ExpectedReturnType)
			if err != nil {
				return nil, NewInferError(
					withUnionProvenance(
						fmt.Errorf("block argument body has type %s but expected type %s",
							bodyType, b.ExpectedReturnType),
						bodyType,
					),
					b.BodyNode,
				)
			}
			bodyType = bodyType.Apply(subs).(hm.Type)
		}

		// Build the function type
		b.Inferred = hm.NewFnType(NewRecordType("", argSchemes...), bodyType)
		t := b.Inferred
		b.SetInferredType(t)
		return t, nil
	})
}

func (b *BlockArg) Eval(ctx context.Context, scope ValueScope) (Value, error) {
	return WithEvalErrorHandling(ctx, b, func() (Value, error) {
		if b.Inferred == nil {
			return nil, fmt.Errorf("BlockArg.Eval: function type not inferred")
		}

		// Extract all parameter names from the inferred function type
		// This includes both user-provided and unused parameters
		recordType, ok := b.Inferred.Arg().(*RecordType)
		if !ok {
			return nil, fmt.Errorf("BlockArg.Eval: expected RecordType for function arguments")
		}

		argNames := make([]string, len(recordType.Fields))
		for i, field := range recordType.Fields {
			argNames[i] = field.Key
		}

		return FunctionValue{
			Args:                argNames,
			Body:                b.BodyNode,
			Closure:             scope,
			FnType:              b.Inferred,
			Defaults:            make(map[string]Node), // Block args don't support defaults
			ArgDecls:            b.Args,
			IsBlockArg:          true,
			CapturedReturnFrame: currentReturnFrame(ctx),
			CapturedBreakFrame:  currentBlockCallFrame(ctx),
		}, nil
	})
}

func (b *BlockArg) Walk(fn func(Node) bool) {
	if !fn(b) {
		return
	}
	// Walk parameters
	for _, arg := range b.Args {
		arg.Walk(fn)
	}
	// Walk body
	b.BodyNode.Walk(fn)
}

// instantiateListMethod instantiates a list method's type by substituting
// the type variable 'a' with the actual element type of the list.
func instantiateListMethod(def BuiltinDef, elemType hm.Type) hm.Type {
	// Build a record type for the method arguments, replacing TypeVar('a') with elemType
	args := NewRecordType("")
	for _, param := range def.ParamTypes {
		paramType := substituteTypeVar(param.Type, 'a', elemType)
		args.Add(param.Name, hm.NewScheme(nil, paramType))
	}

	// Similarly, handle the return type
	returnType := substituteTypeVar(def.ReturnType, 'a', elemType)

	fnType := hm.NewFnType(args, returnType)

	// Copy the block type if present, substituting type variables
	if def.BlockType != nil {
		blockType := substituteTypeVar(def.BlockType, 'a', elemType).(*hm.FunctionType)
		fnType.SetBlock(blockType)
	}

	return fnType
}

// substituteTypeVar recursively replaces a type variable with a concrete type
func substituteTypeVar(t hm.Type, tv hm.TypeVariable, replacement hm.Type) hm.Type {
	switch typ := t.(type) {
	case hm.NullableTypeVariable:
		if typ.TypeVariable == tv {
			return Nullable(replacement)
		}
		return typ
	case hm.TypeVariable:
		if typ == tv {
			return replacement
		}
		return typ
	case hm.NonNullType:
		return hm.NonNullType{Type: substituteTypeVar(typ.Type, tv, replacement)}
	case ListType:
		return ListType{Type: substituteTypeVar(typ.Type, tv, replacement)}
	case MapType:
		return MapType{Type: substituteTypeVar(typ.Type, tv, replacement)}
	case *hm.FunctionType:
		newFnType := hm.NewFnType(
			substituteTypeVar(typ.Arg(), tv, replacement),
			substituteTypeVar(typ.Ret(false), tv, replacement),
		)
		// Preserve the block type
		if typ.Block() != nil {
			newBlockType := substituteTypeVar(typ.Block(), tv, replacement).(*hm.FunctionType)
			newFnType.SetBlock(newBlockType)
		}
		return newFnType
	case *RecordType:
		newRec := NewRecordType(typ.Named)
		for _, field := range typ.Fields {
			fieldType, _ := field.Value.Type()
			newFieldType := substituteTypeVar(fieldType, tv, replacement)
			newRec.Add(field.Key, hm.NewScheme(nil, newFieldType))
		}
		newRec.Directives = typ.Directives
		return newRec
	default:
		return t
	}
}
