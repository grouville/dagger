from pathlib import Path
import json,subprocess
base=Path('/tmp/rust-cache-sipsma-review');p=base/'go-discovery-generate-matches';p.mkdir(exist_ok=False);repo=Path('/tmp/dagger-go-discovery-generate-matches');file=repo/'go.dang';text=file.read_text()
# Extract the existing workspace/pattern calculation without changing it.
start=text.index('  # Match direct Go files to include the workspace root');end=text.index('  let discoveredGenerateDirectories',start);block=text[start:end];method=block[block.index('  let matchingGenerateDirectories'):].strip('\n')
text=text[:start]+text[end:]
start=text.index('  let selectGenerate(ws: Workspace!, dirs: [String!]!): [String!]! {');end=text.index('  let discoveredGenerateDirectories',start)
text=text[:start]+'''  let selectGenerate(ws: Workspace!, dirs: [String!]!): [String!]! {
    GoGenerateMatches(ws, generatePatterns).select(dirs)
  }

'''+text[end:]
text=text.replace('    let found = prepared.{{owner, paths(ws: ws)}}','''    # Matching depends on workspace and tool settings, not the module root.
    # Keep it local to this discovery; getters receive only owners and paths.
    let matches = if (prepared.length == 0) { null } else { GoGenerateMatches(ws, generate) }
    let found = prepared.{{owner, paths(ws: ws, matches: matches)}}''')
text=text.replace('let packagePaths(ws: Workspace!, files: [String!]!):','let packagePaths(ws: Workspace!, files: [String!]!, matches: GoGenerateMatches = null):')
text=text.replace(' + generatePackagesIn(ws, files)',' + generatePackagesIn(ws, files, matches)')
text=text.replace('let generatePackagesIn(ws: Workspace!, files: [String!]!):','let generatePackagesIn(ws: Workspace!, files: [String!]!, matches: GoGenerateMatches):')
text=text.replace('      selectGenerate(ws, dirs).map { dir => relativeDir(dir) }','      (matches ?? GoGenerateMatches(ws, generatePatterns)).select(dirs).map { dir => relativeDir(dir) }')
text=text.replace('let paths(ws: Workspace!): [String!]! {\n    owner.packagePaths(ws, files)','let paths(ws: Workspace!, matches: GoGenerateMatches = null): [String!]! {\n    owner.packagePaths(ws, files, matches)')
assert 'let found = prepared.{{owner, paths(ws: ws, matches: matches)}}' in text
assert text.count('owner.packagePaths(ws, files, matches)')==1
text+='''
# Immutable generation matches for one workspace and set of tool settings.
# Discovery shares this value locally; it is not stored in collection getters.
type GoGenerateMatches {
  let includeAll: Boolean!
  let included: [String!]!
  let excluded: [String!]!

  new(ws: Workspace!, patterns: [String!]!) {
    let include = patterns.filter { p => p.hasPrefix("!") == false }
    let exclude = patterns.filter { p => p.hasPrefix("!") }.map { p => p.trimPrefix("!") }
    self.includeAll = include.length == 0
    self.included = matchingGenerateDirectories(ws, include)
    self.excluded = matchingGenerateDirectories(ws, exclude)
    self
  }

  let select(dirs: [String!]!): [String!]! {
    dirs.filter { dir =>
      (includeAll or included.any { match => match == dir })
        and excluded.any { match => match == dir } == false
    }
  }

'''+method+'\n}\n';file.write_text(text)
parent=base/'go-shared-generate-matches'
for name in ['measure-source-edits.py','measure-test-edits.py','measure.py','capture.py','capture-all.py','analyze.py','analyze-all.py','verify-module.py','prepare-small.py','run-followup.py']:
 s=(parent/name).read_text().replace('go-shared-generate-matches','go-discovery-generate-matches').replace('SharedGenerateMatches','DiscoveryGenerateMatches').replace('shared_generate_matches','discovery_generate_matches')
 s=s.replace('Only generation-pattern directory matching moves from per-module local evaluation to a shared gomod Dagger function. The matching algorithm, each module selection, discovery, authored getters, source identities, execution, telemetry and cleanup remain. Metadata JSON reuse and clone-unlocked modes stay disabled.','Generation patterns are matched once inside the existing Go.packages discovery invocation and reused by its transient module-discovery objects. Every module still selects its own discovered generation directories. No extra Dagger API or builtin, no getter state or logic change. Both arms retain metadata, telemetry and cleanup settings.')
 (p/name).write_text(s)
(p/'prepare-study.py').write_bytes(Path('/tmp/prepare-discovery-generate-matches.py').read_bytes())
(p/'identity.json').write_text(json.dumps(dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),baseline_module='/tmp/dagger-go-indexed-owner-facts',candidate_module=str(repo),engine=json.loads((base/'sealed-metadata-json-engine/engine-build.json').read_text()),scope='Only local immutable generation matching preparation is shared. No new engine API, builtin, SDK request or stored getter field.',preceding_api_variant='go-shared-generate-matches: lower real-repository CPU and allocation, but regressed all small-repository pairs.'),indent=2)+'\n');print(p)
