from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent;rows=[]
steps=[('profiles',['python3',str(p/'capture-all.py')]),('small-1',['python3',str(p/'measure-small-1.py'),'--output',str(p/'small-source-1'),'--fixture','real','--arms','before','combined','--pairs','4']),('small-16',['python3',str(p/'measure-small-16.py'),'--output',str(p/'small-source-16'),'--fixture','real','--arms','before','combined','--pairs','4']),('analysis',['python3',str(p/'analyze-all.py')])]
for label,command in steps:
 tick=time.monotonic()
 with (p/(label+'-driver.log')).open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row=dict(label=label,command=command,seconds=time.monotonic()-tick,exit_code=r.returncode);rows.append(row);(p/'followup-steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((p/(label+'-driver.log')).read_text()[-2500:]);raise SystemExit(r.returncode)
