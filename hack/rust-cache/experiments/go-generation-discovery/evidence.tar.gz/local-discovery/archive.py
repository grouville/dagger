from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
p=Path(__file__).parent;base=p.parent;root=p/'evidence-root';root.mkdir(exist_ok=False)
out=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/go-generation-discovery');out.mkdir(parents=True,exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def ignore(directory,names):return [n for n in names if n in {'__pycache__','.git','dagger-engine','wcprof-complete.ndjson','evidence-root','archive-driver.log'} or n.endswith('.test')]
studies=[('native-sort',base/'go-native-string-sort-current'),('source-labels',base/'go-reduction-source-profile'),('shared-api',base/'go-shared-generate-matches'),('local-discovery',p)]
reconstruction=[]
for label,source in studies:
 for complete in sorted(source.glob('capture-*/wcprof-complete.ndjson')):
  folder=complete.parent;events=[];chunks=sorted(folder.glob('chunk-*.ndjson.gz'));assert chunks
  for chunk in chunks:
   with gzip.open(chunk,'rb') as stream:header=json.loads(stream.readline());events.extend(stream.readlines())
   assert header['dropped_events']==0
  assert not header.get('open_ops');header['event_count']=len(events);rebuilt=(json.dumps(header)+'\n').encode()+b''.join(events);assert rebuilt==complete.read_bytes()
  reconstruction.append(dict(capture=label+'/'+folder.name,chunks=[c.name for c in chunks],events=len(events),sha256=sha(rebuilt),exact_bytes_verified=True))
 shutil.copytree(source,root/label,ignore=ignore)
assert len(reconstruction)==14
write(root/'wcprof-reconstruction.json',reconstruction)
parent=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/sealed-metadata-json-engine');metadata=json.loads((parent/'archive.json').read_text());assert sha((parent/'evidence.tar.gz').read_bytes())==metadata['sha256'];write(root/'engine-source-parent.json',dict(path='../sealed-metadata-json-engine/evidence.tar.gz',**metadata))
# All engine source inputs match the archived benchmark engine except the
# dedicated diagnostic's List.reduce source-label wrapper.
original=json.loads((parent/'build-source-manifest.json').read_text());overlay=json.loads((base/'go-reduction-source-profile/overlay.json').read_text())['Replace'];delta=[]
for row in original:
 actual=Path(overlay.get(row['original'],row['actual']));data=actual.read_bytes()
 if sha(data)!=row['sha256']:delta.append(dict(original=row['original'],actual=str(actual),parent_sha256=row['sha256'],sha256=sha(data),archived='source-labels/stdlib.go'))
assert len(delta)==1 and delta[0]['actual']==str(base/'go-reduction-source-profile/stdlib.go');write(root/'diagnostic-source-delta.json',delta)
repos=[('baseline','/tmp/dagger-go-indexed-owner-facts'),('native-sort','/tmp/dagger-go-native-string-sort-current'),('shared-api','/tmp/dagger-go-shared-generate-matches'),('local-discovery','/tmp/dagger-go-discovery-generate-matches')]
identities={}
for label,repo in repos:
 repo=Path(repo);patch=subprocess.check_output(['git','diff','--binary','de633b12ed2aa02e42adb698a23fcecc13faf36d'],cwd=repo);dest=root/'module-source'/label;dest.mkdir(parents=True)
 (dest/'candidate.patch').write_bytes(patch)
 files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');rows=[]
 for name in filter(None,files):
  f=repo/name
  if not f.is_file():continue
  d=dest/name;d.parent.mkdir(parents=True,exist_ok=True);data=f.read_bytes();d.write_bytes(data);rows.append(dict(path=name,bytes=len(data),sha256=sha(data)))
 identities[label]=dict(path=str(repo),commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),patch_sha256=sha(patch),files=rows)
write(root/'module-identities.json',identities)
files=[f for f in sorted(root.rglob('*')) if f.is_file()];manifest=[dict(path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in files];mbytes=(json.dumps(manifest,indent=2)+'\n').encode();archive=out/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in files:
  info=tar.gettarinfo(str(f),arcname=str(f.relative_to(root)));info.mtime=0
  with f.open('rb') as stream:tar.addfile(info,stream)
 info=tarfile.TarInfo('manifest.json');info.size=len(mbytes);info.mtime=0;tar.addfile(info,io.BytesIO(mbytes))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)+1
 for row in manifest:
  payload=tar.extractfile(row['path']).read();assert len(payload)==row['bytes'] and sha(payload)==row['sha256']
(out/'manifest.json').write_bytes(mbytes)
for name in ['assessment.json','final-state.json','module.patch']:(out/name).write_bytes((p/name).read_bytes())
for name in ['wcprof-reconstruction.json','module-identities.json','engine-source-parent.json','diagnostic-source-delta.json']:(out/name).write_bytes((root/name).read_bytes())
record=dict(bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(files)+1,all_member_hashes_verified=True,lossless_streams_reconstructed=len(reconstruction),binaries_excluded=True);write(out/'archive.json',record);print(json.dumps(record),flush=True)
