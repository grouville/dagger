from pathlib import Path
import json,statistics,subprocess
p=Path(__file__).parent;base=p.parent

def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def cohort(folder):
 rows=json.loads((folder/'samples.json').read_text());blocks=sorted({r['block'] for r in rows if not r['warmup']});d=[]
 for b in blocks:
  r={r['arm']:r for r in rows if r['block']==b};d.append(r['before']['seconds']-r['combined']['seconds'])
 assert all(r['exit_code']==0 and not r['cancelled'] and r['correct_names'] and r['same_full_rows'] for r in rows)
 return dict(medians=json.loads((folder/'summary.json').read_text()),commands=len(rows),all_correct=True,pairs=len(blocks),faster_pairs=sum(x>0 for x in d),paired_seconds=d,median_paired_saving=statistics.median(d))

j=json.loads((p/'assessment.json').read_text())
for r in j['diagnostics']:
 if 'seconds' in r:r['analysis_seconds']=r.pop('seconds')
 folder=p/('capture-'+r['arm']);r['command_seconds']=json.loads((folder/'result.json').read_text())['seconds'];a=json.loads((folder/'attribution.json').read_text());r['getters']=a['selected_calls']['go:GoPackages.get'];r['discoveries']=a['selected_calls']['go:GoPackage.tests'];assert a['dropped']==0 and a['open_ops']==0
j['timings']={w:cohort(p/(w+'-edit-paired')) for w in ['test','source']};assert all(r['faster_pairs']==4 for r in j['timings'].values())
j.update(selected=True,reason='All eight real-repository measured pairs improve, with substantially lower CPU and allocation. Sharing remains local to existing discovery and removes 79 SDK requests; no authored getter or selection is suppressed.',small_repositories={'one_module':cohort(p/'small-source-1'),'sixteen_modules_initial':cohort(p/'small-source-16'),'sixteen_modules_followup':cohort(p/'small-source-16-followup')},small_repository_assessment='One module is flat at about 0.57s. Sixteen-module results are mixed: the separate eight-pair follow-up is faster in five pairs, with a 23ms median paired saving. This does not establish a reliable small-repository latency gain or universal absence of outliers.',conditions='Fresh CLI processes and real edits on one warm isolated engine. Normal telemetry, GC, output, final flushing and session cleanup retained. Before each cohort, both modes complete test addition and removal. No simultaneous heavy work, no cache clearing or widened limits.',cold_measured=False,rust_latency_measured=False,new_engine_change=False,new_builtin=False,new_dagger_api=False,shared_state_lifetime='One Go.packages invocation; readonly arrays and boolean, not stored in collection getter results.')
checks=json.loads((p/'checks.json').read_text())+json.loads((p/'discovery-checks.json').read_text());assert len(checks)==27 and all(r['exit_code']==0 and not r['cancelled'] for r in checks);j['functional_gates']={'successful_checks':len(checks),'new_discovery_regression_passes_baseline_and_candidate':True,'existing_go_checks':25,'coverage':['discovery and ownership','selected test execution and expected failures','source overrides and layout changes','binary execution','generation execution, globs, exclusions and cwd','independent workspace and selection inputs']}
for r in j['diagnostics']:
 if r['arm'] in ['before','candidate']:assert r['getters']=={'executed':800} and r['discoveries']=={'hit':799,'executed':1}
write(p/'assessment.json',j)
api=base/'go-shared-generate-matches';a=json.loads((api/'assessment.json').read_text());a.update(selected=False,reason='Sharing through a new gomod API reduces work on the large repository, but its extra SDK requests regress all small-repository measured pairs.',small_repositories={str(n):cohort(api/f'small-source-{n}') for n in [1,16]},go_successful_checks=26,new_engine_change=False,stock_new_builtin_required=False)
for row in a['diagnostics']:
 if 'seconds' in row:row['analysis_seconds']=row.pop('seconds')
 row['command_seconds']=json.loads((api/('capture-'+row['arm'])/'result.json').read_text())['seconds']
write(api/'assessment.json',a)
for name,repo in [('local-discovery','/tmp/dagger-go-discovery-generate-matches'),('shared-api','/tmp/dagger-go-shared-generate-matches')]:
 dest=p if name=='local-discovery' else api
 patch=subprocess.check_output(['git','diff','--binary','de633b12ed2aa02e42adb698a23fcecc13faf36d'],cwd=repo);(dest/'module.patch').write_bytes(patch)
print(json.dumps({'selected':True,'full_real_command_pairs_faster':8,'successful_checks':27,'timing_commands':sum(x['commands'] for x in j['timings'].values())+sum(x['commands'] for x in j['small_repositories'].values()),'cold_or_rust_latency_claim':False}),flush=True)
