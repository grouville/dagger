from pathlib import Path
import json,os,signal,subprocess,time,urllib.request
p=Path(__file__).parent;base=p.parent;debug='http://127.0.0.1:16112/debug/'
def get(route,data=None):
 with urllib.request.urlopen(urllib.request.Request(debug+route,data=data),timeout=15) as f:return json.load(f)
routes=['collection-item-content','coerced-method-hoisting','lazy-eval-error-context','shared-function-metadata','shared-receiver-decode','prepared-schema','callback-caller-reuse','interface-candidate-pruning','interface-field-snapshots','metadata-snapshot-json'];flags={r:get(r)['enabled'] for r in routes}
assert not get('wcprof/enabled')['global_enabled'];assert not get('metadata-snapshot-unlocked')['enabled'];assert not get('parallel-client-admission')['enabled'];assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
env=dict(os.environ,RUST_CACHE_BENCH_RUNNER='tcp://127.0.0.1:16284',RUST_CACHE_BENCH_CLI=str(base/'typed-artifact-metadata/dagger'),RUST_CACHE_BENCH_COLLECTOR='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')
repos={'before':Path('/tmp/dagger-go-indexed-owner-facts'),'candidate':Path('/tmp/dagger-go-discovery-generate-matches')}
saved={arm:(repo/'.dagger/modules/go-dev/main.dang').read_bytes() for arm,repo in repos.items()};rows=[]
def run(arm,repo,check):
 tick=time.monotonic();label=arm+'-'+check.replace(':','-')
 with (p/(label+'.log')).open('w') as out:
  process=subprocess.Popen(['python3',str(base/'local_cli_collector.py'),'check',check],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  cancelled=False
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait(timeout=60)
 row=dict(arm=arm,check=check,seconds=time.monotonic()-tick,exit_code=code,cancelled=cancelled);rows.append(row);(p/'discovery-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code or cancelled:print((p/(label+'.log')).read_text()[-3000:]);raise SystemExit(code or 1)
try:
 for route in routes:get(route+'?enabled='+str(route not in ['shared-function-metadata','shared-receiver-decode','interface-field-snapshots','metadata-snapshot-json']).lower(),b'')
 before=repos['before']/'.dagger/modules/go-dev/main.dang'
 text=saved['before'].decode().rstrip()
 before.write_text(text[:-1]+(p/'discovery-check.dang').read_text()+'}\n')
 for arm,repo in repos.items():run(arm,repo,'go-dev:generation-discovery-check')
finally:
 (repos['before']/'.dagger/modules/go-dev/main.dang').write_bytes(saved['before'])
 for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
 (p/'discovery-checks-restoration.json').write_text(json.dumps(dict(baseline_checker_restored=(repos['before']/'.dagger/modules/go-dev/main.dang').read_bytes()==saved['before'],flags_after={r:get(r) for r in routes},lifecycle=get('client-lifecycle')),indent=2)+'\n')
