pub const EDIT: u64 = 209729972938423;
pub fn value() -> u64 { shared::value().wrapping_add(EDIT) }
