pub const EDIT: u64 = 92645183571948;
pub fn value() -> u64 { shared::value().wrapping_add(EDIT) }
