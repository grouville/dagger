pub const EDIT: u64 = 0;
pub fn value() -> u64 { shared::value().wrapping_add(EDIT) }
