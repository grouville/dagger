from pathlib import Path
import hashlib
import json

p = Path(__file__).parent
parent = p.parent / 'interface-candidate-index-engine'
repo = Path('/tmp/dagger-filesync-snapshot-seeds')
overlay = json.loads((parent/'overlay.json').read_text())
replace = overlay['Replace']

key = str(repo/'engine/clientdb/store_spill.go')
old = Path(replace[key]).read_text()
needle = '\tscanner := newFrameScanner(s.file, 1, size)\n'
assert old.count(needle) == 1
candidate = old.replace(needle, needle+'\tif spillRecoveryReaderReuse.Load() {\n\t\tdefer scanner.release()\n\t}\n')
(p/'engine-store.go').write_text(candidate)
replace[key] = str(p/'engine-store.go')
mode = (p.parent/'spill-batch-buffers-engine/mode.go').read_text()
mode = mode.replace('spillBatchBuffers', 'spillRecoveryReaderReuse').replace('SpillBatchBuffersDiagnostic', 'SpillRecoveryReaderDiagnostic')
(p/'engine-mode.go').write_text(mode)
replace[str(repo/'engine/clientdb/spill_recovery_reader_mode.go')] = str(p/'engine-mode.go')
key = str(repo/'cmd/engine/debug.go')
debug = Path(replace[key]).read_text()
needle = '\tm.HandleFunc("/debug/spill-batch-buffers", clientdb.SpillBatchBuffersDiagnostic)\n'
assert debug.count(needle) == 1
(p/'engine-debug.go').write_text(debug.replace(needle, needle+'\tm.HandleFunc("/debug/spill-recovery-reader", clientdb.SpillRecoveryReaderDiagnostic)\n'))
replace[key] = str(p/'engine-debug.go')
(p/'engine-enabled_test.go').write_text('''package clientdb
import "os"
func init() {
 if os.Getenv("DAGGER_TEST_SPILL_RECOVERY_READER") == "1" {
  spillRecoveryReaderReuse.Store(true)
  nativeTelemetryStorageEnabled.Store(true)
  attributeArrayDecodeEnabled.Store(true)
  batchMetadataFast.Store(true)
 }
}
''')
replace[str(repo/'engine/clientdb/spill_recovery_reader_enabled_test.go')] = str(p/'engine-enabled_test.go')
(p/'overlay.json').write_text(json.dumps(overlay, indent=2)+'\n')

plan = json.loads((parent/'engine-plan.json').read_text())
plan.update(new_engine='dagger-collection-recovery-reader-oct19', ports={'runner':16282,'debug':16110},
            scenario='Only return of the pooled recovery reader changes. Indexed matching, Go module, CLI, getter logic, telemetry and cleanup are common to both arms.')
plan['flags']['spill-recovery-reader'] = False
(p/'engine-plan.json').write_text(json.dumps(plan, indent=2)+'\n')

def common(source):
    return source.replace('dagger-collection-interface-index-oct18','dagger-collection-recovery-reader-oct19').replace(':16109',':16110').replace(':16281',':16282').replace('/interface-candidate-index-engine/', '/telemetry-recovery-reader/')

for name in ['verify-module.py','verify-rust.py','measure-test-edits.py','measure-source-edits.py','capture.py']:
    text = common((parent/name).read_text())
    text = text.replace("'interface-field-snapshots']", "'interface-field-snapshots','spill-recovery-reader']")
    text = text.replace("mode('interface-candidate-pruning',arm=='combined')", "mode('interface-candidate-pruning',True)\n            mode('spill-recovery-reader',arm=='combined')")
    text = text.replace("mode('interface-candidate-pruning',options.arm=='candidate')", "mode('interface-candidate-pruning',True)\n    mode('spill-recovery-reader',options.arm=='candidate')")
    text = text.replace("get('interface-candidate-pruning?enabled='+str(arm=='candidate').lower(),b'')", "get('interface-candidate-pruning?enabled=true',b'')\n  get('spill-recovery-reader?enabled='+str(arm=='candidate').lower(),b'')")
    text = text.replace('interface-candidate-index-pipeline-oct18','telemetry-recovery-reader-pipeline-oct19')
    if name.startswith('measure-'):
        old_scope = "Complete getter-preserving listing on one isolated engine: original structural interface matching versus the indexed algorithm. Identical module, source protocol, CLI, compiler settings and all other modes. Prepared schema and callback-caller reuse are common; old snapshot-only matching is off. Both arms finish test addition and removal before four measured pairs. Fresh CLI and real edits on a warm engine, normal telemetry and GC, output and complete cleanup included."
        assert old_scope in text
        text = text.replace(old_scope, plan['scenario']+' Both arms finish test addition and removal before four balanced measured pairs, on a warm engine with a fresh CLI and real edit.')
    (p/name).write_text(text)
    compile(text, str(p/name), 'exec')

text = common((parent/'start-engine.py').read_text()).replace('127.0.0.1:16281:1234','127.0.0.1:16282:1234').replace('127.0.0.1:16109:6060','127.0.0.1:16110:6060')
needle = "('dagger-collection-receiver-decode-oct18','3d1c4deeef3ca394ac64302263ff1d9a30b4b6e18c740ecb5b9d55ef64a784b1'),"
assert needle in text
text = text.replace(needle, "('dagger-collection-interface-index-oct18','0df377c84e39ae7f85914fa1eb6b8eeb425c7e50454cb55db8e4742db5c8e856'),"+needle)
(p/'start-engine.py').write_text(text)
for name in ['measure.py','capture-all.py']:
    (p/name).write_text((parent/name).read_text())
(p/'rust-cache-query.py').write_bytes((parent/'rust-cache-query.py').read_bytes())
print('Prepared engine overlay and full-pipeline protocols; indexed matching stays common to both arms.')
