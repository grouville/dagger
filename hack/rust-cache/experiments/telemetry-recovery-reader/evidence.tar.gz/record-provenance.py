from pathlib import Path
import hashlib
import json
import shutil
import subprocess

p = Path(__file__).parent
parent = p.parent / 'interface-candidate-index-engine'
durable = Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/interface-candidate-index-engine')
def sha(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()

rows = []
for target, source in json.loads((p/'overlay.json').read_text())['Replace'].items():
    f = Path(source)
    rows.append(dict(target=target, source=source, bytes=f.stat().st_size, sha256=sha(f)))
(p/'overlay-sources.json').write_text(json.dumps(rows, indent=2)+'\n')
(p/'parent-evidence.json').write_text(json.dumps(dict(
    root_fork_commit='2a8d1efbc1',
    engine_build_inputs='hack/rust-cache/experiments/interface-candidate-index-engine/evidence.tar.gz',
    archive=json.loads((durable/'archive.json').read_text()),
    source_manifest_sha256=sha(parent/'build-source-manifest.json'),
    changes='engine-store.go adds only the conditional recovery release; engine-mode.go and engine-debug.go expose its diagnostic toggle. engine-enabled_test.go enables the candidate and native codec for tests. Everything else is inherited.',
), indent=2)+'\n')
for name in ['engine.go.mod','engine.go.sum','module-identities.json']:
    shutil.copy2(parent/name, p/name)
shutil.copytree(parent/'module-source', p/'module-source')
repo = Path('/tmp/dagger-telemetry-recovery-reader')
(p/'standalone-source').mkdir(exist_ok=True)
for name in ['store_spill.go','store_spill_benchmark_test.go']:
    shutil.copy2(repo/'engine/clientdb'/name, p/'standalone-source'/name)
print('Recorded overlay source hashes, standalone inputs and parent build-source archive reference.')
