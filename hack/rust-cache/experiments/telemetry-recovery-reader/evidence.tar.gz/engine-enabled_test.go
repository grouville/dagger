package clientdb
import "os"
func init() {
 if os.Getenv("DAGGER_TEST_SPILL_RECOVERY_READER") == "1" {
  spillRecoveryReaderReuse.Store(true)
  nativeTelemetryStorageEnabled.Store(true)
  attributeArrayDecodeEnabled.Store(true)
  batchMetadataFast.Store(true)
 }
}
