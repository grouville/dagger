from pathlib import Path
import gzip, json
import hashlib

p=Path(__file__).parent
for folder in sorted(p.glob('capture-*')):
    merged=folder/'wcprof-complete.ndjson.gz'
    raw=folder/'wcprof-complete.ndjson'
    if merged.exists() or raw.exists():
        data=gzip.decompress(merged.read_bytes()) if merged.exists() else raw.read_bytes()
        provenance=json.loads((folder/'recorded-chunks.json').read_text())
        assert hashlib.sha256(data).hexdigest()==provenance['combined_raw_sha256']
        header=json.loads(data.split(b'\n',1)[0])
        assert header['dropped_events']==0 and not header.get('open_ops')
        assert header['event_count']==provenance['events']
        for chunk in provenance['chunks']:
            strings=header['strings'][:chunk['string_count']]
            assert hashlib.sha256(json.dumps(strings).encode()).hexdigest()==chunk['canonical_strings_sha256']
        (folder/'wcprof-complete.ndjson').write_bytes(data)
        print(folder.name,provenance['events'])
        continue
    chunks=sorted(folder.glob('chunk-*.ndjson.gz'))
    if not chunks:continue
    headers=[];events=[]
    for filename in chunks:
        lines=gzip.decompress(filename.read_bytes()).splitlines()
        headers.append(json.loads(lines[0]));events.extend(lines[1:])
    last=headers[-1]
    assert last['dropped_events']==0 and not last.get('open_ops')
    for header in headers:
        assert header['dropped_events']==0
        assert header['epoch_unix_nano']==last['epoch_unix_nano']
        assert header['strings']==last['strings'][:len(header['strings'])]
    combined=dict(last,event_count=len(events))
    data=(json.dumps(combined)+'\n').encode()+b'\n'.join(events)+b'\n'
    (folder/'wcprof-complete.ndjson').write_bytes(data)
    print(folder.name,len(events))
