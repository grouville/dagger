from pathlib import Path
import hashlib, json, tarfile, time

p=Path(__file__).parent
destination=Path('/home/dagger/dagger_otra/hack/rust-cache/experiments/collection-work-amplification')
destination.mkdir(exist_ok=True)
members=[]
for filename in sorted(p.rglob('*')):
    if not filename.is_file():continue
    relative=filename.relative_to(p)
    if any(part in ['.git','.codex','.claude','__pycache__'] for part in relative.parts):continue
    if filename.name=='wcprof-complete.ndjson.gz':continue
    if filename.name.startswith('chunk-') and filename.name.endswith('.ndjson.gz'):continue
    data=filename.read_bytes()
    members.append(dict(path=str(relative),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
archive=destination/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as output:
    for row in members:output.add(p/row['path'],arcname='evidence/'+row['path'],recursive=False)
with tarfile.open(archive,'r:*') as stored:
    entries=stored.getmembers();assert len(entries)==len(members)
    actual={entry.name:entry for entry in entries}
    for row in members:
        with stored.extractfile(actual['evidence/'+row['path']]) as stream:
            assert hashlib.sha256(stream.read()).hexdigest()==row['sha256']
manifest=dict(created_unix=time.time(),archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,verified_members=len(members),uncompressed_member_bytes=sum(row['bytes'] for row in members),scope='Diagnostic decomposition, no selected optimization. Captures retain lossless combined traces and per-chunk metadata, string prefixes, open operations, original hashes and event boundaries. rebuild-traces.py verifies the combined traces without duplicate headers. Source module snapshots and failed setup attempts included. No binary, cache volume, credentials or Git metadata.',engine_dependency_context='../log-flush-buffer/',members=members)
(destination/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
(destination/'README.md').write_text('''# Collection work amplification

See [the assessment](../../NATIVE_COLLECTION_WORK_AMPLIFICATION.md). The normal command remains 35.12 seconds median. Real discovery without artifact rows takes 25.02 seconds; frozen names in normal nested collections take 9.40 seconds. These are diagnostic controls, not additive phases or an optimization result.

The archive preserves all fifteen final commands, the failed initial block, API/schema/harness corrections, source and frozen fixtures, four lossless wcprof captures, source-aligned CPU reports, exact identities, added/removed-test checks, restoration and the next experiment's acceptance criteria. No PR is opened and no engine implementation or default module changes.

MANIFEST.json verifies each archive member and the archive itself. Extract evidence.tar.xz and run evidence/rebuild-traces.py to verify the combined recorder traces. Every event is retained; per-chunk metadata preserves string prefixes, open-operation snapshots, event boundaries and original hashes without storing duplicate headers. Original absolute paths and the local telemetry receiver need adapting for replay. The exact engine source and dependency context remain in the preceding [log flush archive](../log-flush-buffer/); binaries and the engine volume are excluded.
''')
(destination/'evidence.tar.gz').unlink(missing_ok=True)
print(json.dumps({k:manifest[k] for k in ['archive_bytes','verified_members','uncompressed_member_bytes','archive_sha256']}),flush=True)
