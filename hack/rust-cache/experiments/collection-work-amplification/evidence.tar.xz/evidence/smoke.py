from pathlib import Path
import hashlib, json, os, signal, subprocess, sys, time, urllib.request

p = Path(__file__).parent
base = p.parent
workspace = Path('/tmp/dagger-go-real-repository-main')
cli = base/'filesync-literal-pathwalk/dagger-after'
module = p/'go-probes'
removed = {'DAGGER_SESSION_PORT','DAGGER_SESSION_TOKEN','SSH_AUTH_SOCK','DAGGER_CLOUD_TOKEN','DAGGER_CLOUD_URL','DAGGER_ENGINE','DAGGER_CLOUD_ENGINE','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'}
env = {k:v for k,v in os.environ.items() if k not in removed and not k.startswith('OTEL_EXPORTER_')}
env.update(DAGGER_CLOUD_URL='http://'+(base/'otlp-null-address.txt').read_text().strip()+':43184',DAGGER_CLOUD_TOKEN='local-benchmark-token',XDG_CONFIG_HOME='/tmp/rust-cache-oct13-filter/local-client-config',NO_PROXY='*',_EXPERIMENTAL_DAGGER_RUNNER_HOST='tcp://127.0.0.1:16276',_EXPERIMENTAL_DAGGER_CLI_BIN=str(cli),_EXPERIMENTAL_DAGGER_VERSION='v1.0.0-beta.15')

def get(route, data=None):
    with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:16104/debug/'+route,data=data),timeout=30) as r:
        return json.load(r)

saved = {name:(workspace/name).read_bytes() if (workspace/name).exists() else None for name in ['dagger.toml','dagger.lock']}
edit=workspace/'dagql/types.go'; original=edit.read_bytes()
routes=['batch-metadata','attribute-array-decode','native-telemetry-storage']
flags={route:get(route)['enabled'] for route in routes}
assert not get('wcprof/enabled')['global_enabled']
assert get('client-lifecycle')['active_requests']==0
label=sys.argv[1] if len(sys.argv)>1 else 'discovery-smoke'
command=[str(cli),'api','with-session','--load-workspace-modules','python3',str(p/'query.py'),str(p/'parallel-discovery.graphql')]
start=None
try:
    for route in routes: assert get(route+'?enabled=true',b'')['enabled']
    (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(module)+'"\n[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n')
    edit.write_bytes(original+f'\n// Discovery diagnostic edit {time.time_ns()}\n'.encode())
    (p/(label+'-command.json')).write_text(json.dumps(dict(command=command,workspace=str(workspace),module=str(module),flags_during={r:get(r) for r in routes},engine_sha256=subprocess.check_output(['docker','exec','dagger-rust-parser-state-pool-oct14','sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0],wcprof=False,fresh_edit=True,telemetry=True),indent=2)+'\n')
    before=get('vars')['memstats']; start=time.monotonic()
    with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:
        process=subprocess.Popen(command,cwd=workspace,env=env,stdout=out,stderr=err,start_new_session=True)
        try: code=process.wait(timeout=240)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGINT);code=process.wait()
    seconds=time.monotonic()-start;after=get('vars')['memstats']
    result=dict(command=command,seconds=seconds,exit_code=code,allocated_bytes=after['TotalAlloc']-before['TotalAlloc'],allocations=after['Mallocs']-before['Mallocs'])
    if code==0:
        (p/(label+'-result.json')).write_text(json.dumps(result,indent=2)+'\n')
        payload=json.loads((p/(label+'.stdout')).read_text())
        result['payload_type']=type(payload).__name__
        groups=payload.get('go',{}).get('diagnosticPackages')
        if groups is not None: groups=[dict(path=g['path'],names=g['tests']['keys']) for g in groups]
        if groups is not None:
            (p/'discovered-groups.json').write_text(json.dumps(groups,indent=2)+'\n')
            result['packages']=len(groups);result['names']=sum(len(g['names']) for g in groups)
    (p/(label+'-result.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
finally:
    edit.write_bytes(original)
    for name,data in saved.items():
        if data is None:(workspace/name).unlink(missing_ok=True)
        else:(workspace/name).write_bytes(data)
    for route,enabled in flags.items():get(route+'?enabled='+str(enabled).lower(),b'')
    (p/(label+'-restoration.json')).write_text(json.dumps(dict(source_restored=edit.read_bytes()==original,config_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items()),flags={r:get(r) for r in routes}),indent=2)+'\n')
