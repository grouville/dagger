from pathlib import Path
import collections, hashlib, json, os, signal, statistics, subprocess, sys, time, urllib.request

p=Path(__file__).parent
protocol=p.parent/'rust-go-test-collections/measure.py'
exec(protocol.read_text().split('fixtures = [f for f')[0])
cli=base/'filesync-literal-pathwalk/dagger-after'
env['_EXPERIMENTAL_DAGGER_CLI_BIN']=str(cli)
env['_EXPERIMENTAL_DAGGER_VERSION']='v1.0.0-beta.15'
workspace=Path('/tmp/dagger-go-real-repository-main')
modules={'normal':Path('/tmp/dagger-go-module-test-name-index'),'discovery':p/'go-probes','known':p/'known-collections'}
commands={arm:[str(cli),'check','--module','go','--check','test','--list','--all'] for arm in modules}
commands['discovery']=[str(cli),'api','with-session','--load-workspace-modules','python3',str(p/'query.py'),str(p/'parallel-discovery.graphql')]
routes=['batch-metadata','attribute-array-decode','native-telemetry-storage']
flags={r:get(r)['enabled'] for r in routes}
other_routes=['gc-metadata-read-ahead','reusable-declarations','telemetry-flush-coalescing','callback-caller-reuse','lazy-type-maps','span-lookup-fanout','otel-evicted-queue','single-toml-parse','parallel-client-admission','restored-posting-removal','prepared-schema','usage-sampling','builtin-receivers','config-declarations','trivial-scalar-fields','direct-span-protobuf','scalar-list-projection','upstream-leaf-arrays','native-search-projection','restored-data-list-projection','span-row-sharing','interface-field-snapshots','compaction-digest-sets','metric-flush-pruning','metadata-snapshot-unlocked','upstream-log-queue','recovered-schema-templates','canonical-core-providers','lazy-schema-candidates','schema-read-buffers','queued-log-flush-buffer']
saved={n:(workspace/n).read_bytes() if (workspace/n).exists() else None for n in ['dagger.toml','dagger.lock']}
edit=workspace/'dagql/types.go';original=edit.read_bytes()
expected_lines=[line for line in (base/'glob-literal-prefix/full-command-paired/0-before.stdout').read_text().splitlines() if line.startswith('go ')]
expected=[tuple(line.split()[1:3]) for line in expected_lines]
orders=[['normal','discovery','known'],['known','discovery','normal'],['discovery','normal','known'],['known','normal','discovery'],['normal','discovery','known']]
assert not get('wcprof/enabled')['global_enabled']
assert get('lock-profiler')==dict(mutex_fraction=0,block_profile_rate_ns=0)
assert get('collection-expansion-limit')['limit']==0
state={r:get(r) for r in other_routes}
for route in ['gc-metadata-read-ahead','telemetry-flush-coalescing','callback-caller-reuse','lazy-type-maps','single-toml-parse','parallel-client-admission','prepared-schema','direct-span-protobuf','upstream-leaf-arrays','native-search-projection','restored-data-list-projection','interface-field-snapshots','compaction-digest-sets','metric-flush-pruning','metadata-snapshot-unlocked','upstream-log-queue','recovered-schema-templates','canonical-core-providers','lazy-schema-candidates','schema-read-buffers','queued-log-flush-buffer']:
    assert not state[route]['enabled'],route
for route in ['reusable-declarations','span-lookup-fanout','restored-posting-removal','usage-sampling','builtin-receivers','config-declarations','trivial-scalar-fields','scalar-list-projection']:
    assert state[route]['enabled'],route
metadata=dict(scope='Diagnostic decomposition, not before/after optimization. Normal real Go collection listing; concurrent real Go discovery projected as package paths and test names; frozen names in ordinary nested generic collections. Every fresh CLI and source comment, same warm engine, telemetry and ordinary GC. Includes command exit and final log flush. No timing result is a selected product speedup.',orders=orders,warmup_block=0,measured_blocks=4,commands=commands,modules={a:str(m) for a,m in modules.items()},setup=json.loads((p/'setup.json').read_text()),expected_rows=len(expected),engine_sha256=subprocess.check_output(['docker','exec',record['Id'],'sha256sum','/usr/local/bin/dagger-engine'],text=True).split()[0],cli_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),wcprof=False,cpu_profile=False,telemetry=True,normal_gc=True,flags_before={**state,**{r:get(r) for r in routes}},source_sha256=hashlib.sha256(original).hexdigest())
(root/'driver.py').write_bytes(Path(__file__).read_bytes());(root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
rows=[]
try:
    for route in routes:mode(route,True)
    for block,order in enumerate(orders):
        for arm in order:
            label=f'{block}-{arm}'
            edit.write_bytes(original+f'\n// Collection decomposition edit {time.time_ns()}\n'.encode())
            settings='[modules.go.settings]\nversion = "1.26.6"\ngoflags = "-p=8"\ntest = ["."]\n' if arm!='known' else ''
            (workspace/'dagger.toml').write_text('[modules.go]\nsource = "'+str(modules[arm])+'"\n'+settings)
            idle(label)
            gc_before=get('snapshot-collection');before=heap();before_cpu=cpu();before_pressure=pressure()
            timed=['/usr/bin/time','-f','{"user_seconds":%U,"system_seconds":%S,"max_rss_kib":%M}','-o',str(root/(label+'-cli-resources.json')),'--',*commands[arm]]
            tick=time.monotonic()
            with (root/(label+'.stdout')).open('w') as out,(root/(label+'.stderr')).open('w') as err:
                process=subprocess.Popen(timed,cwd=workspace,env=env,stdout=out,stderr=err,start_new_session=True)
                cancelled=False
                try:code=process.wait(timeout=240)
                except subprocess.TimeoutExpired:
                    cancelled=True;os.killpg(process.pid,signal.SIGINT);code=process.wait()
            cli_seconds=time.monotonic()-tick
            get('upstream-log-queue',b'')
            seconds=time.monotonic()-tick;after=heap();after_cpu=cpu();after_pressure=pressure()
            output=(root/(label+'.stdout')).read_text()
            if arm=='discovery' and code==0:
                groups=json.loads(output)['go']['diagnosticPackages']
                actual=[(g['path'],name) for g in groups for name in g['tests']['keys']]
                same_order=None;package_count=len(groups)
            else:
                lines=[line for line in output.splitlines() if line.startswith('go ')]
                actual=[tuple(line.split()[1:3]) for line in lines]
                same_order=actual==expected;package_count=None
            correct=collections.Counter(actual)==collections.Counter(expected)
            row=dict(label=label,block=block,arm=arm,warmup=block==0,seconds=seconds,cli_seconds=cli_seconds,exit_code=code,cancelled=cancelled,rows=len(actual),same_names=correct,same_order=same_order,packages=package_count,engine_cpu=after_cpu-before_cpu,heap_delta={k:after[k]-before[k] for k in before},pressure={k:(after_pressure[k]-before_pressure[k])/(seconds*1e6) for k in before_pressure},gc_before=gc_before,gc_after=get('snapshot-collection'),cli_resources=json.loads((root/(label+'-cli-resources.json')).read_text().splitlines()[-1]))
            rows.append(row);(root/'samples.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['label','seconds','rows','exit_code','same_names','engine_cpu']}),flush=True)
            assert code==0 and not cancelled and correct,(label,'command failed or names differ')
            assert arm=='discovery' or same_order,(label,'row order differs')
    summary={arm:dict(median_seconds=statistics.median(r['seconds'] for r in rows if r['arm']==arm and not r['warmup']),median_engine_cpu=statistics.median(r['engine_cpu'] for r in rows if r['arm']==arm and not r['warmup']),median_allocated_bytes=statistics.median(r['heap_delta']['TotalAlloc'] for r in rows if r['arm']==arm and not r['warmup']),commands=sum(r['arm']==arm and not r['warmup'] for r in rows)) for arm in modules}
    (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
finally:
    edit.write_bytes(original)
    for name,data in saved.items():
        if data is None:(workspace/name).unlink(missing_ok=True)
        else:(workspace/name).write_bytes(data)
    for route,enabled in flags.items():mode(route,enabled)
    (root/'restoration.json').write_text(json.dumps(dict(source_restored=edit.read_bytes()==original,config_restored=all((workspace/n).read_bytes()==d if d is not None else not (workspace/n).exists() for n,d in saved.items()),flags_after={r:get(r) for r in routes},other_flags_unchanged=all(get(r)['enabled']==state[r]['enabled'] for r in other_routes),lifecycle=get('client-lifecycle')),indent=2)+'\n')
