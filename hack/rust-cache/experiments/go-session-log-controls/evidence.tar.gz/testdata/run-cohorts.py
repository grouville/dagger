from pathlib import Path
import json
import subprocess
import time
import urllib.request

p = Path(__file__).parent
debug = 'http://127.0.0.1:16104/debug/'
rows = []

def get(route):
    with urllib.request.urlopen(debug + route, timeout=20) as response:
        return json.load(response)

for label, command in [
    ('install', ['python3', str(p / 'install-engine.py')]),
    ('metadata', ['python3', str(p / 'measure-metadata.py'), '--output', str(p / 'metadata-paired'), '--pairs', '5', '--languages', 'go']),
    ('logging', ['python3', str(p / 'measure-logging.py'), '--output', str(p / 'logging-paired'), '--pairs', '5', '--languages', 'go']),
]:
    if label != 'install':
        assert not get('metadata-snapshot-unlocked')['enabled']
        assert not get('upstream-log-queue')['enabled']
        assert not get('wcprof/enabled')['global_enabled']
        assert get('lock-profiler') == dict(mutex_fraction=0, block_profile_rate_ns=0)
    tick = time.monotonic()
    with (p / (label + '-driver.log')).open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic()-tick))
    (p / 'pipeline.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '-driver.log')).read_text()[-5000:]
