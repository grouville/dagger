from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent
go = '/home/dagger/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOMAXPROCS='8', CGO_ENABLED='1')
subprocess.run([str(Path(go).with_name('gofmt')), '-w', *[str(p / name) for name in [
    'controlled-client_scope.go', 'metadata_snapshot_mode.go', 'log_queue_mode.go',
    'log_queue_mode_test.go', 'main.go', 'debug.go']]], check=True)
rows = []
tests = [
    ('upstream-writer-race', './engine/slog', '^Test', {}),
    ('writer-control-race', './cmd/engine', '^TestControlledLogWriter', {}),
    ('metadata-control-off-race', './engine/server', '^(TestClientMetadata.*|TestClientScope.*|TestNestedClient.*|Test.*Client.*Lease.*)$', {'DAGGER_TEST_UNLOCK_METADATA_SNAPSHOT': 'off', 'DAGGER_TEST_PARALLEL_CLIENT_ADMISSION': 'on'}),
    ('metadata-control-on-race', './engine/server', '^(TestClientMetadata.*|TestClientScope.*|TestNestedClient.*|Test.*Client.*Lease.*)$', {'DAGGER_TEST_UNLOCK_METADATA_SNAPSHOT': 'on', 'DAGGER_TEST_PARALLEL_CLIENT_ADMISSION': 'on'}),
]
for label, package, pattern, extra in tests:
    command = [go, 'test', '-p', '2', '-buildvcs=false', '-modfile',
               '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
               '-overlay', str(p / 'engine-overlay.json'), '-race', '-count=1', '-run', pattern, package]
    tick = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd='/tmp/dagger-filesync-snapshot-seeds', env=dict(env, **extra), stdout=output, stderr=subprocess.STDOUT)
    rows.append(dict(label=label, command=command, environment=extra, exit_code=result.returncode, seconds=time.monotonic()-tick))
    (p / 'validation.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]

steps = [
    ('retained-before', ['python3', '/tmp/rust-cache-sipsma-review/trivial-scalar-projection/verify_retained_first.py', 'go-session-log-controls-before'], None),
    ('engine-build', [go, 'build', '-p', '2', '-buildvcs=false', '-modfile',
                      '/tmp/rust-cache-sipsma-review/otel-evicted-queue/engine.go.mod',
                      '-overlay', str(p / 'engine-overlay.json'), '-o', str(p / 'dagger-engine'), './cmd/engine'], '/tmp/dagger-filesync-snapshot-seeds'),
]
rows = []
for label, command, cwd in steps:
    tick = time.monotonic()
    with (p / (label + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic()-tick)
    if label == 'engine-build' and result.returncode == 0:
        row['sha256'] = hashlib.sha256((p / 'dagger-engine').read_bytes()).hexdigest()
    rows.append(row)
    (p / 'engine-builds.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, (p / (label + '.log')).read_text()[-5000:]
